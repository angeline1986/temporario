Capítulo 308 — Quero que os médicos imperiais sintam na pele as cólicas menstruais

As homenagens à nova imperatriz não podem ser adiadas nem por um instante.

Ao meio-dia, as concubinas se reuniram no Palácio Fengluan para prestar suas homenagens a Ning Xiaoxiao.

Contudo, a pessoa que estava sendo venerada naquele momento não se encontrava no salão principal.

Todas imaginaram que Ning Xiaoxiao, recém-nomeada imperatriz, quisesse fazer pose e impor autoridade. Por isso, nenhuma ousou reclamar.

Na verdade, ela já havia terminado de se arrumar há muito tempo.

Mas essa beldade tola só se lembrou, quando estava prestes a sair, de que aparentemente havia colocado a "Pílula da Empatia" sobre a mesa.

Quando voltou para buscá-la, porém, não conseguiu encontrar a pílula em lugar algum.

— Onde foi parar?

"Lembro-me claramente de tê-lo colocado aqui..."

Ela sempre fora um tanto descuidada.

Sabia perfeitamente que o efeito da pílula era absurdo: se alguém sem qualquer ligação afetiva com ela a ingerisse, Ning poderia até perder a vida.

Mas, quando Gu Sijin a chamara à porta, pensara que não sairia do palácio e deixara essas preocupações de lado.

Só agora, com a pílula desaparecida, percebeu a gravidade da situação.

Ning Xiaoxiao levantou a saia e deitou-se no chão para procurar com cuidado.

Ela vasculhou cada canto e recanto do quarto, mas não conseguiu encontrar a pílula em lugar nenhum...

Depois de quase meia hora de procura, Qiqi veio chamá-la.

Quando Qiqi entrou, viu Ning com metade do corpo debaixo da cama e o traseiro arredondado balançando para fora. Ficou perplexa:

"Majestade, o que está fazendo?"

Ao ouvir isso, Ning Xiaoxiao saiu de debaixo da cama.

"Perdi alguma coisa. Você pode pedir para a Qiaqia e as outras virem aqui me ajudar a procurar?"

Ela fez um gesto com a mão.

— Uma pílula pequenina, mais ou menos deste tamanho, rosa e azul.

Qiqi concordou com o pedido dela.

— Esta serva obedecerá.

"No entanto, as concubinas estão esperando no salão principal há meia hora. Vossa Majestade, gostaria que elas lhe prestassem suas homenagens primeiro, ou que continuassem a esperar?"

— Se quiser que esperem mais, pedirei à cozinha menor que sirva o almoço. Não podemos deixar Vossa Majestade passar fome.

Se Qiqi não tivesse mencionado isso, ela teria esquecido que ainda havia um monte de monstros e demônios esperando para serem enfrentados por ela no salão principal.

Ela instruiu Qiqi:

— Peça a Qiaqia e Lala para ajudá-la. Até encontrarem a pílula, ninguém poderá pôr os pés no meu quarto.

Pelo tom sério dela, Qiqi percebeu que a pílula devia ser extremamente importante, então assentiu vigorosamente.

— Fique tranquila, Majestade. Esta serva vai encontrá-la.

Ning Xiaoxiao conseguiu ficar tranquila por um momento e foi ao salão principal para lidar com as concubinas.

Enquanto isso, Qiqi e as outras vasculharam o quarto inteiro, de cima a baixo, sem achar sinal da pílula.

'Rangido'

Enquanto procuravam, a porta do quarto foi subitamente aberta.

Os três olharam na direção do som e viram que era Xiao Yinzi quem havia entrado.

"O Departamento da Casa Imperial quer que você recolha o salário deste mês, você..."

"Oh, céus, o eunuco Yin não pode entrar!"

Qiqi correu para impedir Xiao Yinzi de entrar, empurrando-o para fora.

"Sua Majestade a Imperatriz decretou que nenhum estranho poderá entrar nos aposentos da Imperatriz hoje..."

Xiao Yinzi: "Certo, então não vou entrar. Lembre-se de ir buscar rapidinho!"

Assim que o mandou embora, ouviu Lala gritar de alegria.

"Achei!"

Ela ergueu entre os dedos uma pílula rosa e azul e a mostrou às companheiras.

"É este que você está procurando?"

Qiqi e as outras se aproximaram para examiná-la de perto. Era rosa-azulada e tinha aproximadamente o mesmo tamanho que a de Ning Xiaoxiao, então devia ser esta.

Onde você encontrou isso?

— Estava na fresta entre o armário e a parede — explicou Lala, apontando o lugar.

— Estranho... — Qiaqia coçou a nuca. — Eu tinha procurado justamente ali e não vi nada...

Qiqi riu dela: "Você é sempre tão descuidada. Eu já te disse antes e você não quis admitir, mas agora você deveria admitir, não é?"

Qiaqia mostrou a língua para Qiqi. As três guardaram cuidadosamente a pílula e voltaram às tarefas.

Xiao Yinzi, após sair do Palácio Fengluan, relatou o ocorrido a Sanfu no portão do palácio.

— Mestre, fiz como o senhor mandou: joguei a pílula lá dentro.

"Mas eu não entendo muito bem por que você jogaria essa coisa estranha no quarto da Imperatriz?"

*Pá!*

Mal Xiao Yinzi terminou de perguntar, Sanfu lhe deu um belo tapa na cabeça.

"Não faça perguntas que não deveria fazer!"

Xiao Yinzi fez beicinho, magoado, e seguiu Sanfu como um cachorrinho.

Mal sabia ele que seu mestre fizera a mesma pergunta a Lu Linyuan pouco antes e recebera exatamente o mesmo tipo de resposta...

*

Palácio de Chaoyang.

Diante de Lu Linyuan estava uma enorme panela de grânulos medicinais chamados “Tesouro contra cólicas menstruais”; sobre a escrivaninha imperial havia quatro tigelas vazias.

Incluindo a tigela que está bebendo agora, ele já tomou cinco tigelas de remédio...

Sanfu achou que estava vendo coisas quando viu a cena diante de si, então esfregou os olhos vigorosamente.

Quando Sanfu saíra, o caldeirão estava cheio. Ao voltar, viu que Lu Linyuan havia tomado mais da metade do conteúdo!

Por que um homem adulto tomaria remédio para tratar fluxo menstrual anormal em mulheres?

— Charlatães!

Lu Linyuan subitamente ficou agitado, quebrando tigelas e xícaras no chão e enxugando impacientemente o suor da testa.

"Não admira que não tenham conseguido curar a Imperatriz depois de tratá-la por tanto tempo, são todos inúteis!"

— Quem preparou o remédio hoje? Vá! Mande o responsável ao Departamento de Punições receber umas bastonadas!

Sanfu engoliu em seco e, reunindo coragem, falou:

"Vossa Majestade... acha possível que este medicamento tenha sido usado para tratar as irregularidades menstruais da Imperatriz...?"

— Se Vossa Majestade também está com dor de barriga, talvez beber isso... Bem, talvez o remédio simplesmente não funcione no seu caso?

Uma única frase fez o grande azarado cair em si.

O raciocínio de Sanfu fazia tanto sentido que o imperador ficou sem resposta...

A causa das cólicas menstruais era Ning Xiaoxiao, não ele.

Ele era apenas o sujeito que assumira a dor da esposa...

Por mais remédio que tomasse, enquanto a causa estivesse em outra pessoa, seria como tratar o sintoma sem resolver a origem.

Ao pensar em como sua esposa costumava sofrer assim todos os meses, Lu Linyuan sentiu uma pontada de tristeza.

— Vá à Farmácia Imperial. Diga ao diretor Song para reunir todos os médicos imperiais especializados em ginecologia e obstetrícia e descobrir um tratamento de efeito imediato para esses distúrbios menstruais!

"Só lhes darei dez dias. Se ainda assim não tiverem uma resposta definitiva, deixarei que experimentem em primeira mão a dor do fluxo menstrual anormal!"

— Mas, Majestade... essa condição afeta mulheres, não homens. Como fará com que eles sintam essa dor?

Lu Linyuan pressionou a parte inferior do abdômen, cerrou os dentes e disse, palavra por palavra:

— Mandarei alguns brutamontes, armados com marretas, se revezarem golpeando-lhes a barriga durante doze horas por dia, sem descanso!

— Só quando sentirem a dor na própria pele é que se dedicarão de verdade a encontrar um tratamento adequado!

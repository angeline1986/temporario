# Validação do capítulo 309

- **Original:** `novel_capitulos_301_a_360(20261107-181903).docx` (chinês).
- **Tradução-base:** `novel capitulos 301 a 360 - ch.epub` (`index_split_008.html`).
- **Índices absolutos no DOCX:** 622–707 (base zero, com índices de parágrafos vazios preservados como lacunas).
- **Unidades textuais não vazias:** 84 no original e 84 na saída, incluindo título e eventuais marcadores.
- **Correções dirigidas:** 31 unidades substituídas, além de ajustes automáticos de nomenclatura e marcação de pensamentos.

## Decisões editoriais e problemas identificados

- A antiga imperatriz Zhu Xihua recebeu o posto de Dama, não o de Consorte ou Imperatriz.
- Corrigido o sentido da fala sobre os registros apagados e referências de gênero das concubinas.
- A humilhação final envolve provar água usada no escalda-pés, não comer ou deixar secar a água.

## Escopo da validação

O texto chinês foi usado como autoridade para correções semânticas dirigidas, com leitura comparativa e preservação das unidades na mesma ordem. Conferência estrutural: contagens, preservação de índices absolutos e título, verificações de UTF-8, CSV e ZIP. **Não houve auditoria semântica independente, frase a frase, de cada unidade mantida do EPUB**; podem restar problemas de fluência, escolhas lexicais e erros sutis. As unidades sem correção dirigida conservaram essencialmente a tradução-base.

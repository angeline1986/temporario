Capítulo 309 — Já que está tudo bem, beba um pouco da água de lavar os pés

Palácio Fengluan.

Ning Xiaoxiao estava sentada no trono da fênix. Lideradas pela Consorte Duan, as mulheres do harém ajoelharam-se para prestar as três genuflexões e nove reverências cerimoniais.

Após a cerimônia, todos disseram respeitosamente em uníssono:

— Esta humilde serva apresenta seus respeitos à imperatriz. Que Vossa Majestade desfrute de incontáveis bênçãos e paz!

— Podem se levantar e tomar seus assentos.

Os criados do Palácio Fengluan começaram a servir chá às concubinas, uma a uma. Quando Qiqi serviu chá a Ning Xiaoxiao, sussurrou algo:

— Majestade, encontramos a pílula. Guardei-a numa caixa de brocado, junto ao corpo. Quando as saudações terminarem, eu a entregarei à senhora.

Só então Ning Xiaoxiao finalmente se sentiu aliviada.

Ela lançou um olhar para as concubinas lá embaixo com seus olhos de fênix, mas não viu Zhu Xihua.

Nem no primeiro dia de Ning como imperatriz ela viera prestar reverências. Estava cansada de viver?

Enquanto pensava nisso, viu subitamente uma figura simples passar rapidamente pela porta e entrar no palácio.

Todos os olhares se voltaram para Zhu Xihua.

Hoje ela estava vestida de forma muito simples.

Ela vestia apenas uma capa fina azul-clara, sem bordados elaborados, apenas alguns tênues padrões de nuvens como enfeites.

Seu cabelo estava preso em um coque simples, semelhante a uma nuvem, com um grampo de cabelo prateado sem qualquer decoração adicional de ouro ou prata.

As proteções de unhas de suas mãos foram removidas e suas unhas, que originalmente tinham uma polegada de comprimento, foram cortadas em mais da metade.

Desde que entrara no palácio, Ning sempre vira Zhu Xihua adornada com riqueza e joias.

Hoje, apesar de estar vestida de maneira adequada, sua aparência denunciava uma pobreza difícil de disfarçar.

Ela caminhou até o salão e ajoelhou-se respeitosamente diante de Ning Xiaoxiao, realizando a cerimônia das três ajoelhadas e nove reverências.

Ning Xiaoxiao fingiu não saber o que havia acontecido.

O que você está fazendo aqui?

— O imperador não a destinou a servir como criada pessoal da imperatriz-viúva? Veio trazer alguma ordem dela?

A consorte Duan explicou em nome dela:

— Majestade, a imperatriz-viúva concedeu a Xihua o posto de Dama e a instalou no Palácio Yingquan. Como a senhora entrou no palácio há pouco, talvez não saiba, mas a imperatriz-viúva tem...

"Eu falei com você?"

Ning Xiaoxiao lançou-lhe um olhar frio. — Dê dois tapas na própria cara.

"Sua Majestade a Imperatriz?"

— Mandei você se esbofetear! Tem pelo de burro entupindo esses seus ouvidos de cachorro?

“......”

A princípio, a Consorte Duan queria discutir um pouco mais, mas, pelo canto do olho, percebeu que Bengbeng, parado ao lado, já esfregava as mãos em antecipação...

Sem alternativa, a Consorte Duan engoliu a humilhação e deu dois tapas no próprio rosto.

Ning Xiaoxiao desviou o olhar dela e sorriu para Zhu Xihua, dizendo:

— Antes você era imperatriz. Agora é uma Dama, no posto mais baixo do harém. Deve ser uma situação bastante humilhante.

— Não me sinto injustiçada — respondeu Zhu Xihua, com expressão desolada.

— Sua Majestade apagou todos os registros sobre mim, tanto da corte quanto do harém. Os livros de história já não dizem que um dia fui imperatriz; eu própria já não me lembro do passado...

— Agora só desejo permanecer no harém como uma das consortes e poder servir ao imperador e à imperatriz. Isso me basta.

— Foi culpa desta humilde concubina chegar atrasada às reverências. Se Vossa Majestade me punir, não discutirei.

— Só que me atrasei porque...

"Você não disse que não ia discutir?" Ning Xiaoxiao a interrompeu. "O quê? Não consegue resistir a tagarelar mais um pouco?"

Zhu Xihua parecia envergonhada e sem jeito: "..."

Ning Xiaoxiao riu: — Estava só brincando. Ora, por que ficou tão contrariada?

— Já que a imperatriz-viúva a tornou novamente uma mulher do harém, serei magnânima e não discutirei. Levante-se e sente-se.

Zhu Xihua já previa há muito tempo que sua visita para prestar homenagem a Ning Xiaoxiao seria inevitavelmente recebida com ridículo.

Inesperadamente, depois de se sentar, Ning Xiaoxiao apenas conversou com as pessoas ao seu redor e a ignorou.

Após conversarem por um tempo, Ning Xiaoxiao de repente se lembrou de algo e perguntou à Consorte Li:

"Ouvi dizer que você está apresentando sintomas de sensibilidade ao frio da primavera?"

Desde que foi desfigurada, a Consorte Li sempre cobriu o rosto com um véu, relutante em mostrar sua face deformada aos outros.

O fogo-fátuo que apareceu do nada em seu rosto roubou-lhe a beleza e a deixou com pesadelos sem fim.

Ela frequentemente acordava no meio da noite, aterrorizada com a imagem de seu rosto queimado pelas chamas naquele dia.

Com o tempo, ela desenvolveu um fardo mental, e seu mau humor levou a um desequilíbrio físico. Mesmo com o verão se aproximando, ela ainda sentia frio o tempo todo.

Naquele dia, até para prestar homenagem ela continuava usando as roupas do inverno, inclusive meias e sapatos forrados de algodão.

Ning Xiaoxiao ouviu dizer que ela nunca tira as meias quando dorme porque tem medo de que seus pés fiquem frios.

Usar meias de algodão nos pés por longos períodos inevitavelmente produzirá um cheiro forte e azedo que atingirá você em cheio.

Quando Ning Xiaoxiao passou pela Consorte Li a caminho do salão principal hoje, pensou que alguém tivesse trazido o pote de chucrute do palácio.

"Eu também já senti medo do frio da primavera. Mergulhar os pés em água quente até suar alivia bastante esse sintoma."

— Agradeço a preocupação de Vossa Majestade — disse a Consorte Li. — Assim que voltar, mandarei preparar tudo.

Ning Xiaoxiao: "Por que esperar para voltar ao palácio? Se você não está se sentindo bem, deve cuidar disso o mais rápido possível. Qiqi, vá buscar uma bacia de água quente para a Consorte Li."

Após a água quente ser trazida, a Consorte Li disse, constrangida:

"Majestade, Qiqi é sua criada pessoal. Como posso permitir que ela me sirva lavando meus pés? Isso..."

— Qiqi não vai lavar seus pés, naturalmente. Mas alguém não acabou de dizer que voltou ao harém justamente para nos servir?

Ning Xiaoxiao lançou um olhar sorridente a Zhu Xihua. — Dama Zhu, não estava mentindo quando me disse aquilo, estava?

"Não... não, estou falando sério."

"Então mostre-nos seus verdadeiros sentimentos e deixe que todos os vejam."

Algumas risadas zombeteiras vieram de baixo do salão; todos estavam esperando para ver Zhu Xihua pagar mico.

Na cerimônia de nomeação de Ning como imperatriz, Lu Linyuan declarara que os decretos dela teriam a mesma autoridade que os seus.

Ela ordenou que Zhu Xihua lavasse os pés da Consorte Li. Se Zhu Xihua se recusasse, seria considerado desobediência ao decreto imperial, uma questão grave que poderia lhe custar a cabeça.

"Esta concubina... obedece respeitosamente ao decreto de Sua Majestade a Imperatriz..."

Ela tirou os sapatos e as meias da Consorte Li, e o cheiro forte fez seus olhos lacrimejarem.

Zhu Xihua não teve escolha a não ser prender a respiração e colocar lentamente os pés da Consorte Li na bacia.

A água na bacia estava tão quente que chegava a queimar. Assim que os dedos dos pés de Li Fei tocaram a água, ela os retirou bruscamente, respingando água no rosto de Zhu Xihua.

Afinal, Zhu Xihua era a Imperatriz. Vendo isso, a Consorte Li ficou um tanto constrangida e disse a Ning Xiaoxiao:

"Majestade, esta água está muito quente. Talvez devêssemos parar por aqui?"

A voz de Ning Xiaoxiao era fria: "Ela é uma empregada doméstica, nem sabe se a temperatura da água está certa, como pode servir as pessoas?"

— Dama Zhu, a Consorte Li está reclamando que você queimou os delicados pés dela.

"Então... então esperarei até a água esfriar um pouco antes de servir a Consorte Li..." disse Zhu Xihua timidamente, com a cabeça baixa.

— Esperar a água esfriar dá muito trabalho. Leve a bacia para um canto e sopre até ficar morna. Depois prove um gole; quando achar que a temperatura está certa, traga-a de volta.

Zhu Xihua apertou os lábios com força, engolindo a humilhação.

Ela não se atreveu a responder, pegou a bacia com água e foi para o lado soprar nela.

Ning Xiaoxiao ergueu preguiçosamente as pálpebras para olhá-la, esboçando um sorriso fraco e indiferente.

Ela não disse uma palavra, apenas esperou.

Sem alternativa, Zhu Xihua tomou um golinho da água usada para lavar os pés. Mas o cheiro forte dos pés da Consorte Li era tão terrível que, mal o líquido lhe chegou à garganta, ela começou a ter ânsias de vômito.

Ning Xiaoxiao olhou para ela com desdém e a repreendeu:

"Será que esse vira-lata está arrotando porque comeu cocô demais?"

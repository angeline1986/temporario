# Validação do capítulo 308

- **Original:** `novel_capitulos_301_a_360(20261107-181903).docx` (chinês).
- **Tradução-base:** `novel capitulos 301 a 360 - ch.epub` (`index_split_007.html`).
- **Índices absolutos no DOCX:** 533–620 (base zero, com índices de parágrafos vazios preservados como lacunas).
- **Unidades textuais não vazias:** 86 no original e 86 na saída, incluindo título e eventuais marcadores.
- **Correções dirigidas:** 39 unidades substituídas, além de ajustes automáticos de nomenclatura e marcação de pensamentos.

## Decisões editoriais e problemas identificados

- Corrigidas alternâncias indevidas de pessoa narrativa, gêneros e designações de Qiqi/Qiaqia/Xiao Yinzi.
- A pílula é uma unidade rosa e azul, não várias; identificada a manobra de recolocá-la em cena.
- Sanfu é homem; o castigo corresponde ao Departamento de Punições, não a um “censo”.

## Escopo da validação

O texto chinês foi usado como autoridade para correções semânticas dirigidas, com leitura comparativa e preservação das unidades na mesma ordem. Conferência estrutural: contagens, preservação de índices absolutos e título, verificações de UTF-8, CSV e ZIP. **Não houve auditoria semântica independente, frase a frase, de cada unidade mantida do EPUB**; podem restar problemas de fluência, escolhas lexicais e erros sutis. As unidades sem correção dirigida conservaram essencialmente a tradução-base.

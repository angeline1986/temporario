# Validação do capítulo 307

- **Original:** `novel_capitulos_301_a_360(20261107-181903).docx` (chinês).
- **Tradução-base:** `novel capitulos 301 a 360 - ch.epub` (`index_split_006.html`).
- **Índices absolutos no DOCX:** 458–531 (base zero, com índices de parágrafos vazios preservados como lacunas).
- **Unidades textuais não vazias:** 72 no original e 72 na saída, incluindo título e eventuais marcadores.
- **Correções dirigidas:** 29 unidades substituídas, além de ajustes automáticos de nomenclatura e marcação de pensamentos.

## Decisões editoriais e problemas identificados

- O título joga com 姨媽, que em linguagem coloquial pode referir-se à menstruação; o EPUB interpretou literalmente como “tia”.
- Gu Sijin é quem deixará o palácio, não Ning; corrigida a inversão de sujeito.
- Diálogos sobre a medicação e quem a recebe corrigidos; pensamentos de Lu preservados entre 【 】.

## Escopo da validação

O texto chinês foi usado como autoridade para correções semânticas dirigidas, com leitura comparativa e preservação das unidades na mesma ordem. Conferência estrutural: contagens, preservação de índices absolutos e título, verificações de UTF-8, CSV e ZIP. **Não houve auditoria semântica independente, frase a frase, de cada unidade mantida do EPUB**; podem restar problemas de fluência, escolhas lexicais e erros sutis. As unidades sem correção dirigida conservaram essencialmente a tradução-base.

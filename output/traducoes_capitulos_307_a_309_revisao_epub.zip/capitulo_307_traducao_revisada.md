Capítulo 307 — Deixe que eu cuide da sua menstruação

Ning Xiaoxiao pegou sua navalha e estava prestes a recitar silenciosamente o número pi para entrar em sua dimensão espacial quando de repente ouviu a voz de Gu Sijin do lado de fora da porta:

— Xiaoxiao? Já acordou?

— Acabei de acordar. Espere um instante, irmã~

Sem saber o motivo do desejo de Gu Sijin em vê-la, ela colocou casualmente a pílula de empatia sobre a mesa e saiu do quarto.

"Tenho uma coisa ridícula para te contar." Gu Sijin, apoiando o braço dela, sussurrou perto do ouvido dela:

"O Palácio Yingquan está desabitado há muito tempo e é quase um palácio abandonado. Mas adivinhe quem se mudou silenciosamente para lá ontem, enquanto você e o Imperador realizavam uma cerimônia de casamento plebeia?"

Ao perceber o comportamento misterioso de Gu Sijin, Ning Xiaoxiao teve uma boa ideia do que estava acontecendo:

“Zhu Xihua?”

Gu Sijin assentiu com a cabeça: "O Departamento da Casa Imperial também designou duas criadas do palácio para servi-la. Embora o Imperador a tenha concedido à Imperatriz Viúva como criada, a Imperatriz Viúva detém o verdadeiro poder."

— A imperatriz-viúva pode promover uma criada de quem goste a uma posição no harém sem consultar o imperador. Mas não pode lhe dar um posto elevado: ela precisa começar como Dama.

Ning Xiaoxiao soltou uma risada fria: — Antes, era a veneradíssima imperatriz. Agora, num piscar de olhos, tornou-se uma simples Dama, o posto mais baixo de todos. Que ironia! Eu não suportaria tamanha vergonha. Preferiria passar a vida servindo à imperatriz-viúva, fingindo não ver nem ouvir nada. Ao menos teria um pouco de sossego.

— Vergonha na cara é coisa que ela nunca teve — respondeu Gu Sijin. — De todo modo, agora que é Dama, não representa uma ameaça. Ela também virá prestar reverências. Se ousar dizer disparates, pode puni-la sem cerimônia.

Enquanto as duas conversavam, Ning Xiaoxiao sentiu repentinamente uma dor aguda na parte inferior do abdômen.

Este é um sinal que sempre aparece antes da menstruação, e os dois primeiros dias são os mais dolorosos.

Ao ver sua tez rosada empalidecer num instante e suas sobrancelhas delicadas se franzirem enquanto ela agarrava a parte inferior do abdômen, Gu Sijin sussurrou: "Chegou a hora de novo?"

Ning Xiaoxiao franziu os lábios e assentiu. Gu Sijin disse com pesar: "Seu corpo está realmente sofrendo. Você ainda não se recuperou totalmente, então por que disse ao médico imperial que suas irregularidades menstruais estavam completamente curadas?"

"Ai, esse remédio é muito amargo, não quero tomá-lo."

"O que tem de tão amargo? Não é como se eu nunca tivesse bebido antes. O médico imperial preparou muito bem. Embora não seja exatamente agradável ao paladar, não é tão amargo a ponto de ser impossível de engolir."

"Você acha que eu não sei?" Gu Sijin beliscou a bochecha dela e balançou a cabeça, impotente: "O motivo de você ter parado de tomar o remédio é porque você tinha medo que o Imperador se preocupasse com você."

"Eu sabia que não conseguiria esconder isso da minha irmã, então nem tentei."

Ning Xiaoxiao, tentando encontrar humor na situação, mostrou a língua para ela em tom de brincadeira:

"Nós, mulheres, sabemos disso melhor do que ninguém; não é algo que se cure com apenas algumas doses de remédio."

— Isso depende muito da constituição de cada pessoa e exige cuidados ao longo do tempo. Mas você sabe como A-Yuan fica quando me vê sofrer: ao me ver com cólicas, ele se preocupa mais do que eu.

— De qualquer modo, são só os dois primeiros dias de cólicas. Posso aguentar até passar. Por que deixá-lo preocupado à toa?

— Que desculpa esfarrapada! — Gu Sijin não conseguiu convencê-la e mudou de estratégia. — Se não quer pedir, posso dizer aos médicos imperiais que eu é que estou doente e conseguir o remédio para você. Assim serve?

Ela ajudou Ning Xiaoxiao a caminhar em direção ao sol. No centro do pátio do Palácio Fengluan, havia uma mesa octogonal de pedra, e as cadeiras de pedra azul ao lado estavam escaldantes por causa do sol.

Gu Sijin tocou a pedra com as costas da mão, testando a temperatura. — Quando eu tinha cólicas terríveis, minha mãe me mandava sentar numa pedra aquecida pelo sol. No inverno, punha uma bolsa de água quente no meu colo. Não resolvia a causa do problema, mas, quando o corpo aquecia, a barriga doía menos.

Depois de acomodar Ning Xiaoxiao no banco, Gu Sijin tomou-lhe a mão e pressionou o ponto Hegu, entre o polegar e o indicador.

"Tenha paciência, este ponto de acupuntura pode ser um pouco doloroso, mas é melhor do que ter dores intermináveis na parte inferior do abdômen."

Ning Xiaoxiao contemplou Gu Sijin agachada diante dela, contra a luz, e sentiu o coração apertar de emoção.

Gu Sijin era uma irmã mais velha exemplar — e também um pouco como uma mãezona, sempre cuidando até das necessidades mais banais de Ning.

Antes de ter A-Yuan, era a presença de Gu Sijin que lhe trazia segurança.

Mas, ao pensar que Gu Sijin logo deixaria o palácio para buscar a própria felicidade, Ning Xiaoxiao sentiu, além da alegria pela amiga, uma pontinha de tristeza.

As duas ficaram sentadas tomando sol no pátio, sem imaginar que Lu Linyuan, escondido atrás de uma coluna decorada com fênix, havia presenciado tudo.

【Então... ela mentiu para mim o tempo todo por medo de me deixar preocupado?】

【Sua bobinha...】

Suas mãos, que pendiam naturalmente ao lado do corpo, estavam cerradas em punhos, seus olhos cheios de relutância e ternura.

Nesse momento, ele desejava desesperadamente compartilhar a dor de Ning Xiaoxiao, mas infelizmente...

Hum?

Espere!

Não parece haver nada a lamentar!

Ele olhou para o quarto, um brilho ganancioso surgindo em seus olhos.

No passado, ele havia tanto roubado às claras quanto furtado às escondidas várias coisas de Ning Xiaoxiao: chá com leite, KFC, a pílula “Mandar você de volta para sua terra natal” e outras...

Quando ele fazia essas coisas "vulgares", não era realmente por ganância.

Ele só queria provocar Ning Xiaoxiao e irritá-la para que ela percebesse sua presença.

Desde que ele e Ning Xiaoxiao haviam declarado seus sentimentos, parara de fazer essas coisas que a levavam a chamá-lo mentalmente de “broxante”.

Mas hoje, ele decidiu voltar aos seus antigos hábitos!

*

Gu Sijin tinha mesmo um jeito especial com as coisas. Depois de ficar sentada no banco de pedra quente por um tempo e ter seus pontos de acupuntura pressionados, a dor abdominal desapareceu.

Sua tez recuperou o tom rosado e ela exclamou alegremente: "Irmã, você é incrível! Apenas duas pressionadas e realmente não dói mais!"

— Que bom que passou. Hoje é seu primeiro dia como imperatriz; ao meio-dia, as mulheres do harém virão prestar homenagens. Precisa mostrar autoridade e fazê-las entender que você não é fácil de provocar. Assim poderei deixar o palácio tranquila.

Vendo que estava quase na hora, Gu Sijin chamou Qiqi e as outras de volta ao quarto para ajudar Ning Xiaoxiao a se lavar e se vestir.

Lu Linyuan, por outro lado, escapuliu pela janela...

A carruagem imperial parou na esquina da longa rua em frente ao Palácio Fengluan. Quando Sanfu o viu novamente, percebeu que seu rosto estava pálido e que ele segurava a parte inferior do abdômen, como se estivesse sentindo muita dor.

Ele correu para ajudar, mas Lu Linyuan o empurrou.

"Vossa Majestade... o que houve?"

Lu Linyuan franziu a testa e disse impacientemente: "Estou bem!", antes de cambalear para a liteira.

Ele nunca imaginara que as irregularidades menstruais causassem uma dor tão terrível.

A sensação era como se vários homens fortes se revezassem brandindo martelos de ferro e golpeando-o na parte inferior do abdômen.

Ele se considerava capaz de tolerar a dor, mas quando se tratava de cólicas menstruais, era um completo novato!

Incapaz de suportar por mais tempo, Lu Linyuan levantou a cortina da liteira e perguntou a Sanfu:

"A decocção de ervas preparada pelo Hospital Imperial para aliviar irregularidades menstruais ainda está disponível?"

— Sim, está preparado. Conforme Vossa Majestade ordenou, calculamos a data da menstruação da imperatriz. Depois do almoço, os médicos imperiais levarão a decocção para ela.

— Não precisam levar! — Lu Linyuan rangeu os dentes e soltou as palavras com dificuldade.

— Tragam para mim...

Os olhos de Sanfu se arregalaram como pires: "??? Ah... isso não é um pouco inapropriado?"

— Quero dizer... tragam para mim, para que eu mesmo dê o remédio à imperatriz!

Sanfu deu uma risadinha ao ouvir isso: "O Imperador é tão atencioso com a Imperatriz! Oh, meu Deus!"

*Pá!*

Antes que ele pudesse terminar o elogio, Lu Linyuan estendeu a mão pela janela da liteira e lhe deu um tapa forte no rosto:

— Chega de conversa! Vá logo!

# Capítulo 195 — Um dia, eu lhes darei minha bênção

Hm... Essa era uma pergunta que se podia responder?

Ning Xiaoxiao ponderou: 【Ainda não posso contar diretamente que existe alguma coisa entre os dois, certo? E se ele ficar furioso e mandar matar os dois?】

Como o documento em sua mente já não permitia consultar livremente tantas páginas futuras, ela precisava recorrer às próprias lembranças da história original para reconstruir o romance de Gu Sijin e Chu Xingran.

Na história original, Lu Linyuan era um apaixonado obstinado por Gu Sijin (vou repetir: na obra original, Lu Linyuan também não era exatamente um capacho apaixonado; isso será explicado mais adiante, pois ele tem uma identidade secreta). Ao descobrir o envolvimento dela com Chu Xingran, enfureceu-se e condenou Chu à terrível execução por mil cortes.

Mas agora ela havia bagunçado tanto a trama que Gu Sijin e Lu Linyuan não tinham absolutamente nenhum envolvimento amoroso. Em vez de dizer que ele vivia atrás de Gu Sijin, seria mais correto dizer que vivia atrás de Ning Xiaoxiao.

Nessas circunstâncias, talvez Ning tivesse mesmo a oportunidade de mudar a situação e reescrever por completo o destino deles.

Por meio da leitura, já experimentara os conflitos, dilemas e a impotência de Gu Sijin diante do amor. Agora que vivia dentro daquela história, só desejava que a adorável Gu Sijin pudesse ficar com o homem que amava.

Pensou por alguns instantes e decidiu sondar o que Lu Linyuan acharia de receber um belo par de chifres.

— Majestade, e se... Estou dizendo só “se”, viu? Se uma das suas consortes se apaixonasse por outro homem, o que o senhor faria?

Depois de mais de meio ano dentro do livro, Ning já aprendera a dominar seu poder extraordinário.

Podia falar com toda a ousadia. Se as coisas começassem a dar errado, bastava apertar Retroceder ali mesmo.

Ao ouvir a pergunta, Lu Linyuan ergueu os cantos da boca num sorriso intrigado e fez sinal para ela se aproximar. — Venha. Sente-se aqui comigo.

— Ah, está bem... — Ning caminhou devagar até ele.

Assim que chegou ao alcance de sua mão, ele agarrou a faixa da cintura dela e a puxou para os braços.

Desequilibrada, ela acabou sentada de lado na coxa de Lu Linyuan.

A mão grande e firme do imperador segurou sua cintura fina e seus dedos apertaram de leve, fazendo cócegas na região sensível.

Ning tinha muitas cócegas; começou a rir e se debater para sair do colo dele.

— Não se mexa. — Lu Linyuan levou a outra mão ao queixo delicado dela e o acariciou com o polegar.

— Diga-me: por quem você se apaixonou?

A mão que repousava na cintura dela deslizou sobre o tecido macio da roupa de brocado. Ele arqueou uma sobrancelha; sua voz ficou gelada:

— Vou arrancar a pele desse homem e mandar fazer uma roupa para você.

Ning já estava tão acostumada à versão pateta de Lu Linyuan que quase se esquecera de que, originalmente, ele era um tirano violento...

Ainda assim, aquela repentina demonstração de autoritarismo, acompanhada da expressão tão séria, tinha para ela algo de ridículo.

Quanto mais sério ele ficava, mais difícil era conter o riso. Mas seria um pouquinho grosseiro rir bem naquele momento, não seria?

Ela se controlou e respondeu muito compenetrada: — Eu não disse que estava falando de mim...

— Não é você? — A testa franzida de Lu Linyuan relaxou imediatamente. Ele sorriu.

— Entre minhas consortes, você é a única que considero de verdade. As outras são apenas peças que uso para equilibrar as forças da corte. Não gosto delas. Por que me importaria com quem elas amam?

Em outras palavras: “Eu só amo você.”

O coração de Ning Xiaoxiao explodiu de alegria. Ela nem sabia dizer se era por aquela declaração de amor indireta, tão cuidadosamente insinuada, ou porque o romance de Gu Sijin e Chu Xingran finalmente tinha esperança.

Ning acabara de recordar mentalmente toda a história, e Lu Linyuan ouvira cada palavra com perfeita clareza.

Ao saber pelos pensamentos dela que Gu Sijin e Chu Xingran eram antigos apaixonados, achou estranho que Chu não tivesse lhe contado isso antes.

Se Chu tivesse revelado tudo antes de partir como espião para o território dos piratas japoneses, Lu Linyuan não teria chamado Gu Sijin para o palácio. Muito pelo contrário: teria enviado pessoas para protegê-la discretamente.

Mas bastava colocar-se no lugar do amigo para entender.

Infiltrar-se entre os piratas japoneses era uma missão praticamente suicida. Se Chu não sobrevivesse, como poderia suportar a ideia de deixar a mulher amada sozinha e desamparada para sempre?

Agora que Lu Linyuan sabia da verdade, porém, não podia simplesmente ignorá-la.

Primeiro, Chu Xingran era seu amigo íntimo, quase um irmão; um homem honrado não cobiça a esposa de um amigo.

Segundo, Gu Sijin havia arriscado a própria vida várias vezes para proteger Ning Xiaoxiao. Só por gratidão, Lu Linyuan já devia desejar a ela uma vida feliz.

Mas ainda não era o momento de uni-los.

Enquanto os dois não lhe contassem nada abertamente, ele fingiria não saber. De qualquer forma, nunca acontecera nada entre ele e Gu Sijin, portanto tampouco havia algo que precisasse esclarecer.

Enquanto o poder de Tong Guowei não fosse neutralizado na corte, ele não poderia conceder a mão de uma de suas consortes a Chu Xingran.

Caso contrário, Chu Xingran, comandante dos Nove Portões, e o pai de Gu Sijin, censor do Tribunal de Fiscalização, seriam denunciados pelos partidários de Tong Guowei na corte.

Afinal, permitir que uma mulher já incorporada ao harém imperial se casasse novamente com um ministro seria considerado um escândalo contrário à etiqueta e à tradição.

Somente depois de eliminar Tong Guowei, unificar o poder e garantir que ninguém ousasse contrariar suas decisões, Lu Linyuan poderia proporcionar ao amigo o casamento feliz que merecia.

Satisfeita com a resposta, Ning Xiaoxiao mudou de assunto: — Majestade, o Palácio Fengyi é tão grande que tenho medo de morar sozinha. Será que a irmã Sijin pode se mudar comigo?

Lu Linyuan voltou abruptamente ao presente; seu rosto escureceu e ele recusou sem hesitar: — Não!

【Será que a cabeça dessa garota está cheia de mingau? Eu lhe dei um palácio só para ela justamente para poder ficar a sós com ela! E ela insiste em levar a outra junto? Vai mesmo bancar a desentendida comigo?】

【Mas que absurdo! Vai me matar de raiva! Melhor entregar logo esse enorme lampião de presente a Chu Xingran! Assim ela para de ficar zanzando entre nós dois, atrapalhando minha vida!】

Os pensamentos dele fervilhavam, mas não resistiriam ao jeito manhoso de Ning Xiaoxiao.

Há pouco ela tentava escapar de seu colo. Agora, ao contrário, acomodou-se direitinho sobre sua coxa e passou a olhar para ele com olhos suplicantes, quase encostando o rosto no dele, enquanto implorava com voz doce:

— Aaaah, por favor, Majestade! O senhor é o melhor imperador do mundo! Deixa minha irmã morar comigo, vai? Por favooor!

Lu Linyuan: — ... Se tem medo, posso ir lhe fazer companhia todos os dias.

Ning Xiaoxiao: — Ah, mas o senhor precisa comparecer à audiência de manhã e receber ministros depois! Não pode ficar comigo o tempo todo. E sabe que gosto de companhia. Se não deixar minha irmã morar comigo, vou ter de ir a pé do Palácio Fengyi até Zhongcui, todos os dias, para visitá-la.

Ela fez um biquinho; os olhos de corça ficaram úmidos. — No inverno faz frio, no verão faz calor... Talvez eu morra de cansaço no caminho...

E continuou se remexendo no colo dele, fazendo manha.

Caramba, quem aguentaria aquilo?

O rosto de Lu Linyuan mudou ligeiramente. Havia constrangimento ali — e também certo “problema” difícil de mencionar.

Ele segurou Ning e ordenou: — Comporte-se. Pare de se mexer.

Se continuasse, o “irmãozinho” dele começaria a se comportar de maneira indecente.

# Capítulo 194 — Os dois têm alguma coisa?

Ao modificar a trama, Ning Xiaoxiao escrevera claramente que Xianglan deveria empurrar a Consorte Tong “com toda a força que usaria para mamar”.

Quem diria que aquele sistema maluco não entendia uma figura de linguagem? Depois de Xianglan derrubar Tong, o enorme alvoroço fez Gu Sijin e Ning Xiaoxiao se virarem para olhar.

Antes mesmo que Tong pudesse explodir de raiva, Xianglan se atirou sobre ela como se tivesse enlouquecido, abriu seu manto grosso e, por cima da roupa íntima, começou a mamar com voracidade...

Santo céu... Então era esse o sentido que o sistema dera à “força de mamar”...

A Consorte Tong gritava e a insultava, mas Xianglan não dava o menor sinal de que pretendia parar.

Gu Sijin ficou ruborizada de vergonha com aquela cena. Puxou Ning Xiaoxiao de lado e cochichou: — Como pode acontecer algo tão indecente? A Consorte Tong ficou confinada por apenas três ou quatro meses. Ficou tão carente assim? A ponto de fazer essas coisas às escondidas com uma criada?

Ning Xiaoxiao também estava boquiaberta. Mas, para falar a verdade, adorava aquele espetáculo.

Assistia tão entretida que, se Gu Sijin não a tivesse arrastado dali, talvez pegasse um saquinho de sementes e um banquinho para assistir ao show até o último ato.

No caminho de volta, Gu Sijin suspirou repetidas vezes: — Dizem que o harém é um lugar que devora pessoas. Hoje vi como é fácil também transformá-las.

— Que os outros mudem como quiserem. Nós duas podemos continuar sendo as mesmas de sempre — respondeu Ning, segurando a mão de Gu Sijin com um sorriso travesso.

Gu Sijin apertou a mão dela e sorriu com a mesma luminosidade. — É claro que sim.

Ao retornarem ao Palácio Zhongcui, encontraram muitos servos desconhecidos entrando e saindo. Assim que atravessaram o portão, Qiqi, Qiaqia, Bengbeng e Lala correram para recebê-las, radiantes: — Parabéns, Concubina Hua! Receba nossas respeitosas saudações!

Ning riu da brincadeira. — Seus bajuladores! Vieram correndo para não correr o risco de ganhar uma recompensa menor? Vocês cuidaram de mim e da minha irmã neste frio de inverno e suportaram muita perseguição da Consorte Duan, às claras e às escondidas. Sou muito grata.

Depois da brincadeira, ficou séria. — Vou dar a vocês todo o meu soldo deste mês. O frio apertou; mandem um dinheiro extra às famílias de vocês fora do palácio, para que tenham comida e roupas quentes e não precisem se preocupar.

Que senhor de palácio trataria seus criados dessa maneira?

Até Gu Sijin, embora gentil com seus servos, nunca esquecia a hierarquia entre senhores e criados. Não chegava, como Ning, a tratá-los verdadeiramente como iguais.

Qiqi, Qiaqia, Bengbeng e Lala ficaram tão emocionados que quase se abraçaram para chorar e se prostrar em agradecimento.

Ning começou a rir da reação. — Para quem está comigo, lágrimas são apenas enfeite. Daqui em diante quero ver todos sorrindo, e não chorando. Entenderam?

— Obedecemos às suas ordens, senhora!

Ning provocou: — E ainda não estão sorrindo? Vão! Cada um para seu quarto rir escondido cem vezes. Não podem sair antes de terminar.

Os quatro hesitaram por alguns segundos e então começaram, ao mesmo tempo, a soltar gargalhadas enquanto caminhavam para os próprios aposentos.

Os servos da Consorte Duan, que também trabalhavam no Palácio Zhongcui, morriam de inveja daquela convivência tão afetuosa.

Gu Sijin sorriu e deu uma palmadinha no ombro de Ning. — Você nunca respeita as regras, mas acaba deixando todo mundo feliz justamente por desrespeitá-las. Comigo é assim. Com Sua Majestade também.

— Irmã, não caçoe de mim. — Ning olhou ao redor. Os servos estavam praticamente esvaziando a ala oeste, mas ninguém ia à ala leste. Ela segurou um eunuco e perguntou:

— Vocês vão carregar até as lajotas da ala oeste? Andem logo com a ala leste também, senão depois terão de fazer várias viagens de ida e volta.

O eunuco respondeu, constrangido: — Bem... Concubina Hua, o decreto de Sua Majestade determina que a senhora more sozinha, portanto...

Antes que ele terminasse, Ning fechou a cara. — Se eu mandei levar tudo, levem. Com o imperador eu me entendo.

O eunuco logo mobilizou outros servos para arrumar também os aposentos de Gu Sijin. Mas ela não concordou: — Xiaoxiao, não acha inadequado? O decreto concede o Palácio Fengyi a você, não a mim. Se me levar sem pedir permissão primeiro, será que...?

— Ai, irmã! Não me importa! Onde a irmã estiver, eu quero estar também. Você sabe que gosto de movimento. Se tiver de morar sozinha, vou morrer de tédio!

Como Gu Sijin continuava irredutível, Ning agarrou seu braço e começou a fazer manha. — Ah, irmã, por favor! Fica comigo, vai? Por favooor?

Ainda esfregou a cabeça nela, como uma criança carente. Gu Sijin nunca conseguia resistir a Ning, mas sabia muito bem por que ela insistia tanto.

Quem gostaria de ter um enorme lampião brilhando ao lado quando estivesse a sós com a pessoa amada?

Ning insistia em levá-la porque estava preocupada.

Afinal, se Ning fosse embora, quem sabia quanto a Consorte Duan ainda maltrataria Gu Sijin?

Gu Sijin beliscou delicadamente a bochecha de Ning e sorriu com ternura. — Sei que está fazendo isso por mim. Mas, para eu ir, primeiro precisamos da permissão do imperador. Só porque ele a adora, você não deve tomar decisões por conta própria.

Mal terminou de falar e Ning já a arrastava apressadamente para o Palácio Chaoyang.

Quando chegaram, Sanfu pensou que Ning vinha agradecer pela promoção. Foi anunciar a visita a Lu Linyuan, que permitiu a entrada das duas.

Mas quem diria? Chu Xingran também estava lá.

Ele conversava com Lu Linyuan sobre a organização dos portões da cidade quando Ning Xiaoxiao e Gu Sijin entraram de mãos dadas.

No instante em que Gu Sijin viu Chu Xingran, Ning sentiu nitidamente a mão dela tremer. Seu rosto também ficou visivelmente desconfortável.

Chu Xingran, por sua vez, a encarou sem desviar os olhos. Seu olhar límpido revelava com franqueza o que sentia por Gu Sijin.

Gu Sijin sabia que sua força de vontade não era das maiores e também sabia que Chu Xingran era um louco capaz de arriscar a própria vida.

Respirou fundo e recuperou a compostura. — Xiaoxiao precisa conversar com Sua Majestade. Vim apenas acompanhá-la. Não vou interromper a conversa de vocês; peço licença para me retirar.

E saiu fugindo, praticamente correndo.

Ela mal tinha atravessado a porta quando Chu Xingran também pediu dispensa, alegando não querer atrapalhar Lu Linyuan. Até o almoço que os dois haviam combinado foi esquecido.

Ele dizia que não queria incomodar Lu Linyuan, mas parecia muito mais que considerava Lu Linyuan um obstáculo entre ele e Gu Sijin.

Lu Linyuan enxergava tudo com clareza. Se não percebesse aquela ligação amorosa escancarada diante de seus olhos, podia muito bem doar os dois olhos inúteis a alguém que precisasse.

Ficou momentaneamente surpreso. Ao perceber Ning olhando de soslaio para a porta, com aquele sorriso de tia que torce pelo casal, estalou a língua duas vezes para chamar sua atenção. Quando ela se virou, ergueu o queixo e as sobrancelhas, numa curiosidade digna do maior fofoqueiro:

— Os dois... estão tendo alguma coisa?

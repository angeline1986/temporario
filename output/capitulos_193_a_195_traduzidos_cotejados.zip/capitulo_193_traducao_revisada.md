# Capítulo 193 — Quem você pensa que está mandando?

Ning Xiaoxiao não era alguém destinada a permanecer numa posição insignificante. Era apenas uma questão de tempo até se tornar a senhora de um palácio.

Isso não surpreendeu a imperatriz.

O que realmente a espantou foi Lu Linyuan ter concedido, sem mais nem menos, o Palácio Fengyi inteiro para Ning Xiaoxiao morar sozinha.

Ao longo das dinastias, só uma Consorte Imperial Nobre tinha direito a residir no Palácio Fengyi.

Esse gesto deixava claro que a posição que Lu Linyuan desejava oferecer a Ning Xiaoxiao estava muito acima daquela que acabara de lhe conceder.

A imperatriz ponderou consigo mesma:

Lu Linyuan concedera a Ning Xiaoxiao apenas o posto de Concubina porque, ao promover uma consorte a senhora de um palácio, era preciso anunciar a nomeação a todo o império. Elevá-la de Nobre Dama a Concubina seguia, degrau por degrau, as normas ancestrais; não havia violação de protocolo. Mesmo que os ministros quisessem reclamar, não teriam por onde começar.

Já a concessão de uma residência a determinada consorte era assunto conhecido apenas dentro do harém.

Se alguém levasse essa informação à corte, ficaria evidente a troca indevida de notícias entre os aposentos internos e os ministros. Se a origem do vazamento fosse descoberta, os fofoqueiros seriam severamente castigados.

Assim, ao nomear Ning como Concubina e transferi-la para Fengyi, Lu Linyuan pretendia aplacar a opinião pública com um título formalmente adequado. Não queria que ela se destacasse demais perante os ministros e acabasse comparada às infames Bao Si e Daji, acusada de arruinar o país por seduzir seu soberano.

Mas seu propósito particular era ainda maior: demonstrar abertamente às consortes que Ning Xiaoxiao era, para ele, a futura Consorte Imperial Nobre, sua vice-imperatriz escolhida. Quem a importunasse estaria procurando problemas com o próprio imperador.

Depois de tantos anos no palácio, a imperatriz sempre pensava um passo além das outras e sabia melhor do que ninguém manter as aparências.

Enquanto a própria Ning Xiaoxiao ainda estava atônita, sem entender nada, a imperatriz foi a primeira a abrir um sorriso tão radiante que parecia ter acabado de ver a mãe sair da sepultura:

— Que maravilha! É uma ocasião de imensa alegria.

Em seguida, apressou-se a ordenar a Xiangling: — Vá buscar meu colar de turmalinas para presentear a Concubina Hua. Será minha pequena demonstração de felicitações pela promoção.

Depois que a imperatriz disse aquilo, as demais consortes enfim despertaram do choque.

As Consortes Yun e Li cumprimentaram Ning Xiaoxiao com sorrisos forçados. As nobres damas e atendentes pouco conhecidas, de posição inferior à de concubina, ajoelharam-se e saudaram em coro: — Que a Concubina Hua tenha longa vida, paz e prosperidade!

Foi essa saudação em uníssono que trouxe os pensamentos dispersos de Ning Xiaoxiao de volta à realidade.

Dessa vez, ela não tentou mais fugir das demonstrações tão explícitas de carinho de Lu Linyuan, nem inventou desculpas mirabolantes para imaginar que ele queria tirar alguma vantagem dela.

Ele não precisava obter nada dela. Se desejava alguma coisa, era apenas o coração dela — e nem ele sabia ao certo se já lhe pertencia.

No meio das felicitações, naturalmente, não se ouviu a voz da Consorte Tong.

Ela não disse nada, mas seu rosto estava sombrio ao extremo.

Ao ver a infelicidade da Consorte Tong, a imperatriz sentiu seu próprio desgosto diminuir um pouco.

— Consorte Tong, por que não parabeniza a Concubina Hua?

Com um olhar de desdém, a Consorte Tong ajeitou o grampo de ouro nos cabelos e respondeu languidamente: — Ela só virou concubina. Quando tiver a sorte de se tornar consorte e ficar no mesmo nível que eu, ainda haverá tempo para eu lhe dar meus sinceros “parabéns”.

A imperatriz sorriu. — Mesmo o posto de concubina já lhe garante um palácio sob sua administração. Mas, na minha opinião, receber o Palácio Fengyi é uma alegria ainda maior que a promoção. Consorte Tong, nem quando era Consorte Nobre o imperador pensou em instalá-la lá, não é?

A Consorte Tong soltou uma risadinha desdenhosa. — Nossa, como a imperatriz é generosa! Basta outra mulher receber um favor e a senhora corre para bajulá-la. Hoje Sua Majestade a manda para Fengyi; amanhã talvez mande a própria imperatriz desocupar o Palácio Fengluan para ela.

— Em vez de gastar tempo aqui me provocando e espalhando intrigas, seria melhor começar a decidir quais joias e objetos de valor são mais fáceis de carregar no dia em que tiver de se mudar.

A imperatriz tentara semear discórdia, mas acabara levando a pior no bate-boca. Sem resposta, mudou de assunto com certo constrangimento:

— Depois de amanhã teremos o banquete anual do Lago Imperial. Logo depois chegam os dias mais rigorosos do inverno. Neste ano, Sua Majestade pretende passar a temporada de festas de fim de ano na residência de águas termais. Preparem-se.

Naquela manhã, os servidores do imperador haviam entregue à imperatriz uma lista das consortes que iriam passar o inverno na residência termal.

Como se levantara cedo para se arrumar e enfrentar a Consorte Tong, não tivera tempo de examiná-la.

Agora Xiangling entregou a lista, e a imperatriz abriu o documento para dar uma olhada.

Para seu espanto, na coluna das consortes constava um único nome: Ning Xiaoxiao. Até alguém tão calculista quanto a imperatriz franziu discretamente a testa.

Mas sua indignação durou pouco. Ela fechou a lista e sorriu amavelmente:

— Nos outros anos, o número de pessoas que acompanhava Sua Majestade à residência termal era fixo. Neste ano, porém, ele não especificou quem poderá ir e quem terá de ficar.

— O banquete do Lago Imperial, depois de amanhã, será a oportunidade de vocês demonstrarem seu talento. Se conseguirem surpreender Sua Majestade e chamar sua atenção, talvez também possam acompanhá-lo para passar o inverno.

A imperatriz omitiu que apenas Ning Xiaoxiao estava na lista e, em vez disso, incentivou todas a disputar uma vaga.

Depois que passassem o banquete inteiro dando o melhor de si e descobrissem que Lu Linyuan levaria somente Ning à residência termal, o ressentimento contra ela não chegaria às alturas?

Quase todas levaram a sério as palavras da imperatriz. As únicas exceções foram Ning Xiaoxiao e Gu Sijin.

Até a Consorte Tong deu importância àquilo.

Ela já conhecia os altos e baixos da vida palaciana. Depois de meses confinada, continuava insegura.

Sabia perfeitamente que recém-chegadas como Ning estavam subindo acima dela. Se não recuperasse o favor de Lu Linyuan, nem todo o poder de sua família materna bastaria para garantir sua posição no harém por muito tempo.

Por isso, no banquete de depois de amanhã, estava decidida a superar todas as outras, prender o olhar de Lu Linyuan sobre si e conquistar, custasse o que custasse, uma vaga na viagem à residência termal.

Ao fim da visita matinal à imperatriz, a Consorte Tong atrasou o passo de propósito, fazendo as outras pensarem que queria conversar mais um pouco com ela.

Só depois que Ning Xiaoxiao e Gu Sijin saíram, Tong foi atrás delas. Lançou um olhar significativo para Xianglan e sussurrou: — Vá.

Xianglan entendeu imediatamente. Acelerou o passo para empurrar Ning Xiaoxiao e Gu Sijin pelas costas, derrubá-las e depois acusá-las de arrogância e desrespeito. Seria uma lição para Ning, recém-promovida.

Só que aquela idiota fez tanto barulho ao correr que Ning a percebeu pelo canto dos olhos e adivinhou o que pretendia.

Ning fechou os olhos imediatamente, apertou o botão de Retroceder em sua mente e usou na Consorte Tong a única oportunidade de modificar a trama que guardara durante toda a manhã.

A Consorte Tong lançou um olhar para Xianglan. Xianglan, por sua vez, deu-lhe uma bofetada daquelas, pôs as mãos na cintura como uma barraqueira de rua e começou a xingá-la na cara:

— Sua vadia! Quem você pensa que está mandando?!

Consorte Tong, caída no chão: — ???

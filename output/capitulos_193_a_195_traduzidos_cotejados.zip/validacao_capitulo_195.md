# Validação — Capítulo 195

- Fonte: `novel_capitulos_181_a_211(20261105-152737).docx`, chinês tradicional.
- Intervalo de parágrafos (índices base zero): 890–951; título incluído.
- Parágrafos não vazios no intervalo: **59**.
- Linhas no CSV: **59** (sem contar cabeçalho).
- Índices ausentes ou duplicados: **0**. Campos vazios: **0**.
- Fidelidade editorial: tradução integral preservando ordem, humor, sarcasmo, registros e diálogos, sem antecipar o capítulo posterior.
- Pontos de atenção: Nota parentética do texto sobre a suposta devoção do imperador no enredo original preservada; não é informação sobre a linha atual. Lu ouve os pensamentos de Ning e planeja ajudar Gu e Chu apenas quando neutralizar Tong Guowei. Pensamentos internos de Lu são distintos da fala audível.
- Limitação: revisão contextual durante a tradução; não houve segunda auditoria semântica independente integral. A correspondência 1:1 não garante por si só a ausência de erros de sentido.

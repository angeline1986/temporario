# Capítulo 131 — Xiaoxiao ganhou um espaço próprio!

Pai e filha estavam sentados juntos num banco aquecido, sob a luz de uma luminária e ao lado de um braseiro. Embora só conversassem sobre coisas absurdas, fazia muito tempo que Ning Xiaoxiao não se sentia tão feliz.

Estava feliz por rever o pai, e também porque Lu Linyuan já não corria perigo de vida.

Enquanto conversavam, ela de vez em quando corria até a cama de Lu Linyuan para verificar o soro.

Depois de tantas idas e vindas, Ning Dazhi brincou: — Filhinha, diga a verdade ao papai. Você se apaixonou por esse rapaz?

— Ai, pai, para de falar bobagem! — Ning Xiaoxiao abraçou o braço dele com manha. — Sei perfeitamente que ele é um personagem de papel. Como eu poderia me apaixonar por ele?

Era exatamente o que ela acreditava.

Mas, por algum motivo, ao dizer aquilo em voz alta, sentiu uma pontinha de tristeza no coração.

Apoiou-se no ombro do pai e fitou as estrelas espalhadas pelo céu noturno do lado de fora da janela. Disse, num tom tranquilo: — Só quero terminar logo a história, voltar ao mundo moderno e ficar com nossa família para sempre.

Ning Xiaoxiao era a menina dos olhos de Ning Dazhi. Ele a protegia como o maior tesouro do mundo. Como não perceberia quando a filha tinha algo no coração?

Com a ponta do indicador, tocou-lhe o nariz e sorriu: — Mesmo que volte para o mundo moderno, um dia você vai se casar. Vai ter sua própria família, e mais tarde seus próprios filhos. Como poderia ficar para sempre com seu pai e sua mãe?

Ning Xiaoxiao fingiu não se importar e respondeu entre risinhos: — Deixa o futuro para o futuro! Nossa família tem recursos. Na pior das hipóteses, arranjo um marido que venha morar na nossa casa. Assim não preciso me separar de vocês!

— Um genro que vá morar com os sogros? Hehe. — Ning Dazhi deu-lhe um peteleco na testa e ergueu as sobrancelhas na direção da cama de Lu Linyuan.

— Você quer trazer um imperador para morar com a gente? Sonhar não custa nada! Nosso templo é pequeno demais para abrigar um buda desse tamanho!

— Ai, pai! Por que você insiste em me relacionar com ele? Mesmo que não fosse um personagem de papel, ele é um idiota, um convencido meloso, um CEO dominador de romance barato que só fala asneira! Como eu poderia gostar dele? Sua filha tem padrões altos, sabia?

O olhar de Ning Dazhi aos poucos ficou turvo. Ver a filha naquela situação por causa de um erro cometido por ele e pela esposa também lhe apertava o coração.

Ele sabia melhor do que ninguém que, com a tecnologia atual, não havia outra maneira de trazê-la de volta ao mundo moderno além de deixá-la completar integralmente a trama.

E Ning Xiaoxiao só havia percorrido um décimo da história. Isso significava que ainda teria uma longa caminhada pela frente, que precisaria enfrentar sozinha.

Ele não podia estar ao lado da filha o tempo todo. Naturalmente, queria que ela tivesse alguém em quem se apoiar, mesmo dentro daquele livro.

— Se você gosta dele, seja corajosa. Não precisa se preocupar tanto. Seu pai só pode ficar aqui três dias e não sabe quando poderá voltar.

Apertou a mão da filha e aconselhou, com toda a sinceridade: — Faça o que gosta. Faça o que a deixa feliz. Você tem a mim e à sua mãe como apoio, então não precisa ficar se contendo. Afinal, vai passar dez anos aqui. Vai acabar entediada em algum momento. Por que não encontrar um homem e se divertir um pouco com o amor?

Ning Xiaoxiao: — ??? Isso é coisa que um pai diga à filha? Não sei nem o que responder, estou chocada! Mesmo supondo, por absurdo, que eu gostasse dele, o que mudaria? Existe uma barreira dimensional entre nós. Nós nem sequer somos...

Ning Dazhi a interrompeu: — Mesmo no mundo moderno, há poucos homens dispostos a levar um tiro por você.

Ning Xiaoxiao hesitou por um instante, mas logo rebateu: — Mas se um bandido apontasse uma arma para a mamãe, você se jogaria na frente dela sem pensar duas vezes!

Ning Dazhi estreitou os olhos e sorriu de um jeito sugestivo:

— Sim. Mas é porque, para mim, a vida da sua mãe vale mais que a minha.

Ning Xiaoxiao ficou sem resposta. Seu cérebro pareceu travar, sem encontrar um único argumento.

Lançou um olhar furtivo a Lu Linyuan, que dormia, com o coração tomado por sentimentos contraditórios.

Ela não gostava de complicações. Quando se deparava com algum problema que não conseguia resolver, simplesmente largava tudo de mão.

E agora, diante daquela relação indefinida com Lu Linyuan, decidiu com firmeza empurrar a questão para o fundo da mente e parar de pensar nela.

Como se os problemas fossem desaparecer sozinhos se ela deixasse de pensar neles.

Ao vê-la começar a cutucar as unhas, Ning Dazhi percebeu que o assunto a deixara ansiosa.

Por isso, não insistiu e mudou de assunto: — Desta vez, papai trouxe outra coisa para você. Um espaço que permite entrar em contato com o mundo moderno. Sempre que precisar de alguma coisa, escreva num papelzinho e coloque lá dentro. Eu e sua mãe vamos ver a mensagem e pôr o que você pedir no espaço, para enviar até você.

A ansiedade de Ning Xiaoxiao desapareceu num instante. Seus olhos brilharam: — Sério? Velhote, por que não falou antes?!

Ning Dazhi lançou-lhe um olhar de repreensão: — E pare de arrancar os cabelos do pobre Lu. Ele é o imperador! O que vai ser dele se você o deixar careca?

Ning Xiaoxiao olhou na direção de Lu Linyuan e mostrou a língua, toda faceira: — Fazer o quê? A culpa é dele por ser um trouxa tão prestativo!

Ning Dazhi tirou de sua bolsa de pano uma caixinha quadrada e a entregou a Ning Xiaoxiao: — Está aí dentro. Daqui para a frente, segure o objeto na palma da mão e recite mentalmente a senha 【3.1415926】. Assim você poderá entrar no espaço.

Ning Xiaoxiao abriu a caixa, ansiosa. Lá dentro, descansava tranquilamente um... barbeador elétrico?

Segurou o cabo do barbeador, petrificada, e o examinou por um bom tempo antes de dizer:

— Velhote... você acha mesmo adequado me dar esse negócio como espaço? Isso faz algum sentido?

— Se vai ficar escolhendo, devolva.

Ning Dazhi estendeu a mão para recuperá-lo. Ning Xiaoxiao recitou imediatamente os dígitos de pi na cabeça e, no instante seguinte, foi sugada para o espaço misterioso.

Parecia um depósito com luz: quadrado, vazio de ponta a ponta. Ela prometeu a si mesma que um dia o deixaria abarrotado de coisas!

Mais tarde, Lu Linyuan terminou de receber o soro e a febre baixa cedeu. Finalmente Ning Xiaoxiao conseguiu sossegar.

Ela continuou conversando com Ning Dazhi sobre tudo e nada até que o sono venceu. Deitou a cabeça no colo do pai e adormeceu.

Com movimentos delicados, Ning Dazhi a acomodou no banco aquecido, cobriu-a bem com um acolchoado e ficou sentado ao lado, velando o sono da filha.

— Bobinha... Papai sabe que você não quer começar um romance que acredita não ter futuro. Tem medo de se apaixonar por ele e depois assistir ao fim trágico que o espera, sem conseguir suportar.

— Mas... como papai poderia prejudicá-la? Como poderia permitir que você sofresse?

— Naquela época, a situação de sua mãe e minha era exatamente igual à sua e à do pequeno Lu agora.

— ...

Assim que disse aquilo, uma voz mecânica soou repentinamente na mente de Ning Dazhi:

【Aviso! Aviso! Se o hospedeiro revelar sua verdadeira identidade, a Administração do Espaço-Tempo aplicará imediatamente a punição prevista.】

Ning Dazhi: 【Já entendi, Lao Liu.】

Ele acariciou de leve a franja de Ning Xiaoxiao, com o olhar terno e a voz cheia de carinho:

— Minha menina, há coisas que você vai entender quando chegar a hora.

# Validação — Capítulo 132

## Fonte e limites

Original em chinês tradicional: `novel_capitulos_121_a_180(20261103-233558).docx`. Intervalo no DOCX: parágrafos de índice 742 a 815 (base zero); 71 parágrafos não vazios, incluindo título. Próximo capítulo começa no índice 816.

## Auditoria estrutural

- Parágrafos chineses não vazios: 71.
- Linhas de cotejo: 71.
- Índices duplicados: 0.
- Índices omitidos: 0.
- Campos vazios: 0.
- Alinhamento: uma tradução por parágrafo do DOCX, sem resumos substitutivos.

## Questões narrativas e editoriais

- O imperador ouve o pensamento de Ning, mas Ning Dazhi não revela abertamente seu parentesco.
- O humor envolve homofonia de 爸 (pai) com 霸 (dominador/soberano); tradução aproxima o efeito, com perda parcial da ambiguidade sonora.
- Os 500 taéis ofertados pelo imperador contrastam com os 1.000 taéis previamente prometidos ao médico; manter os valores.
- Nota da autora preservada como elemento extradiegetico.

## Escopo da revisão

Tradução elaborada diretamente da fonte chinesa com revisão de nomes, valores, elementos de enredo e cobertura estrutural. A igualdade de parágrafos e uma revisão única não certificam ausência absoluta de erros semânticos ou omissões internas; não houve segunda auditoria linguística independente integral.

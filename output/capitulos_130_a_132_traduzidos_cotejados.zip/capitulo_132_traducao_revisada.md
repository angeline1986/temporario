# Capítulo 132 — O primeiro encontro entre genro e sogro

Na manhã seguinte, bem cedo, Lu Linyuan despertou da inconsciência.

A dor nas costas o deixava quase sem ar, mas era justamente aquela dor que lhe recordava de forma concreta que continuava vivo.

Durante todo o tempo em que permanecera inconsciente, estivera preso num espaço fechado tão escuro que não conseguia enxergar a própria mão.

Tudo ao redor era silêncio. Apenas uma voz ressoava incessantemente em sua mente.

Era a voz firme de Ning Xiaoxiao, incentivando-o a resistir, dizendo que não permitiria que ele morresse.

Naquele confinamento, a princípio, a voz dela fora como um raio de luz, a força que o mantinha lutando.

Mas, aos poucos, depois de ouvir aquela voz repetindo-se vinte e quatro horas por dia, sem uma pausa sequer, Lu Linyuan só conseguia pensar numa coisa:

Essa mulher maluca não conhece nenhuma outra frase? Vai ficar repetindo essas duas falas até quando?!

Ela é mesmo a minha desgraça! Nem agora me deixa em paz! Quando eu acordar, vou costurar essa boca!

Pois bem. Agora ele estava acordado.

Imaginara que, depois de tê-la salvado, Ning Xiaoxiao estaria profundamente comovida e permaneceria à cabeceira de sua cama, cuidando dele sem se afastar nem um instante.

Por isso, sem sequer olhar, estendeu a mão com toda a confiança em direção à cabeceira... e não encontrou ninguém.

...

Ora essa! Onde ela foi parar?!

Virou devagar a cabeça e a cena diante de seus olhos o deixou simplesmente pasmo.

Ning Xiaoxiao estava deitada no banco aquecido. Ao seu lado, um homem a protegia, dando leves tapinhas em suas costas e, de vez em quando, afastando os fios de cabelo da testa dela. Eram gestos de uma intimidade absurda.

A fúria de Lu Linyuan disparou. Ning Xiaoxiao era uma consorte nomeada por ele próprio! Que libertino sem-vergonha ousava molestar a mulher do imperador bem diante de seus olhos? Tinha perdido o amor à vida?!

A raiva foi como uma injeção de analgésico poderosíssimo.

De repente não sentia mais dor. Levantou-se com o máximo de cuidado e se aproximou de Ning Dazhi na ponta dos pés.

Então ergueu a mão e lhe deu um tabefe capaz de abalar os céus e a terra.

*PÁ!*

O tapa fez Ning Dazhi ver estrelas. O barulho também despertou Ning Xiaoxiao, que dormia profundamente.

Ao abrir os olhos, ela viu o próprio pai sendo atacado de surpresa por Lu Linyuan. Os olhos do imperador soltavam faíscas; seu rosto estava sombrio, carregado de intenção assassina.

— De onde saiu esse canalha?! Como ousa cometer tamanho desaforo na minha frente?!

Ele arregaçou as mangas, pronto para dar uma surra em Ning Dazhi. Afinal, era jovem e forte; mesmo ferido, seu adversário não seria páreo para ele.

Em pânico, Ning Xiaoxiao se colocou entre os dois e explicou: — Majestade, não fique zangado! Este... este é o médico milagroso que retirou a bala do seu corpo e salvou sua vida!

Médico milagroso?

Ora, vá se catar!

Salvar minha vida dá a ele o direito de apalpar a minha mulher?!

Quanto mais Lu Linyuan pensava, mais furioso ficava. Aproveitou o embalo e se preparou para presentear Ning Dazhi com outro tapão.

Ning Xiaoxiao segurou seu pulso para impedi-lo: — Majestade, não!

【Seu peste! Meu pai salvou sua vida e você ainda bate nele!】

Lu Linyuan: — ???

Seu pai?

Que absurdo! Este mundo é meu, eu sou o soberano de todos, eu é que sou o seu “pai”!

E você ainda ousa chamar outro homem de pai?!

Pelo visto, está cansada de viver!

Sua fúria só aumentou. Lu Linyuan saltou no ar e lançou um chute voador direto ao rosto de Ning Dazhi.

【Minha nossa... Se esse chute pegar no meu pai, ele não vai acabar pegando o bisturi e picotando você inteiro?!】

Lu Linyuan ficou atônito ainda no meio do salto.

Como assim?! O pai dela?!

No instante em que o chute estava prestes a atingir o rosto de Ning Dazhi, Lu Linyuan desviou de repente a força do golpe e acabou caindo de costas no chão, todo esparramado.

Ning Xiaoxiao ajudou Lu Linyuan a se levantar com a mão esquerda e Ning Dazhi com a direita. Olhava de um para o outro, morrendo de constrangimento.

Quebrava a cabeça tentando encontrar uma explicação para dar ao imperador, mas aquele sujeito parecia ter tomado o remédio errado. Um segundo antes estava ameaçando matar; no seguinte, abriu um sorriso afável e ajudou Ning Dazhi a ficar de pé.

— Foi um mal-entendido, um mal-entendido! O médico divino salvou minha vida; eu deveria tê-lo tratado com toda a cortesia. Peço que não leve a mal.

Enquanto falava, ainda sacudiu a poeira acumulada na barra das roupas dele.

Ning Xiaoxiao ￣□￣｜｜: 【Será que o disparo fez a pólvora subir até o cérebro desse imperador maldito? Por que ele muda de humor de uma hora para outra?!】

Felizmente, embora tivesse levado um tapa daqueles, Ning Dazhi não guardou rancor de Lu Linyuan.

Sabia que não podia revelar sua identidade diante do imperador. Assim, curvou-se respeitosamente e perguntou: — Como Vossa Majestade está se sentindo?

Com a raiva dissipada, Lu Linyuan voltou a sentir uma dor surda na ferida das costas.

Ao saber que Ning Dazhi realizara uma cirurgia para extrair a bala, ficou maravilhado com sua perícia médica e acrescentou: — Com tamanha habilidade, o médico divino aceitaria servir no palácio? Posso nomeá-lo imediatamente para o cargo de vice-diretor da Academia Médica Imperial.

Ning Xiaoxiao ficou perplexa.

【O vice-diretor da Academia Médica Imperial foi substituído há apenas dois meses. Ele mal conheceu meu pai e já quer entregar o cargo a ele?】

【Isso não é... entusiasmo demais?】

【Além disso, o tirano não deveria ser desconfiado por natureza? Por que nem pergunta quem é meu pai ou de onde veio?】

【A personalidade dele... desandou de novo, droga?!】

Como era de esperar, Ning Dazhi recusou: — Fiz uma longa viagem até a capital e minha esposa e meus filhos estão me esperando em casa. Como Vossa Majestade já está recuperado, pretendo partir amanhã e voltar para minha terra.

Ao ouvir as críticas que Ning Xiaoxiao fazia mentalmente, Lu Linyuan percebeu de repente que seu comportamento estava mesmo estranho.

Assim, fechou a expressão imediatamente e disse num tom indiferente: — Nesse caso, ficará hospedado no palácio por mais uma noite. Como salvou minha vida, quando partir amanhã mandarei lhe entregar quinhentos taéis de ouro como recompensa.

Ning Dazhi balançou a cabeça. — Majestade, na verdade...

— Não diga mais nada! — Lu Linyuan o interrompeu com um gesto. — Você terá de aceitar esse ouro, queira ou não. Não admito recusas.

— Não... Vossa Majestade entendeu errado o que eu queria dizer. — Ning Dazhi apontou para Ning Xiaoxiao. — É que esta jovem senhora e aquele eunuco que o acompanha me prometeram... mil taéis de ouro.

Lu Linyuan: — ???

Mas que bela surpresa!

Então pai e filha estão trabalhando juntos para arrancar meu dinheiro, é isso?!

Ele dirigiu um olhar sombrio a Ning Xiaoxiao. Os cantos de seus lábios se ergueram com esforço, num sorriso que não tinha nada de feliz: — Dama Ning, você é mesmo muito generosa!

Ning Xiaoxiao coçou a nuca, sorrindo sem graça: — Ah, nem tanto, nem tanto. Aprendi tudo com Vossa Majestade! O imperador é generoso com as pessoas, então eu apenas sigo seu exemplo. Não posso envergonhá-lo e deixar que digam que nossa família imperial é mesquinha...

Lu Linyuan rangeu os dentes e conseguiu espremer algumas palavras entre eles:

— Então eu lhe agradeço muitíssimo!!

(Nota da autora: Eu pretendia deixar a identidade do velho Ning como uma pista oculta, mas esta é uma história leve e não quero fazer ninguém quebrar a cabeça. Resolvi entregar tudo de bandeja! Assim, tão fácil e direto, vocês já devem conseguir adivinhar, não é?)

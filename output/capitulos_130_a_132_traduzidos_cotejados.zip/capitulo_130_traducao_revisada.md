# Capítulo 130 — O segredo da transmigração para o livro

Ning Dazhi colocou Lu Linyuan no soro e deixou também duas caixas de anti-inflamatórios para Ning Xiaoxiao.

Ele não parava de tirar aqueles objetos modernos de dentro da bolsa, como um mágico fazendo truques. Ning Xiaoxiao ficou boquiaberta.

— Velhote, já está na hora de me explicar o que está acontecendo!

Ning Dazhi soltou um suspiro fingidamente constrangido. De repente, recostou-se com toda a tranquilidade e abriu as mãos.

— Chega de fingir. Vou abrir o jogo. Sua mãe é uma cientista de renome nacional, dessas que escondem o talento à vista de todos. Ela trabalha com tecnologia de distorção do espaço-tempo acima da velocidade da luz. Em outras palavras: é uma cientista que estuda viagens entre mundos e épocas.

Ning Xiaoxiao: — ???

Ela estendeu a mão para tocar a testa de Ning Dazhi. — Pai, você está bem?

— Tenha mais respeito! — Ning Dazhi afastou a mão dela num tapa e respondeu, muito sério: — Acha que eu brincaria com uma coisa dessas? Escondemos isso de você porque era um projeto de sigilo máximo do Estado. E, como você não sabe guardar segredo, é claro que não podíamos contar...

Ning Xiaoxiao ficou paralisada, como se tivesse levado um raio. Braços e pernas formigavam, e até a respiração lhe faltou por um instante.

Como é que é?!

Aquela mãe esquentadinha que ia de chinelo à feira brigar pelos preços, passava os dias lavando roupa, cozinhando, jogando mahjong e maratonando séries... era uma figurona da ciência?

Contar-lhe aquilo era praticamente o mesmo que dizer que o pai dos Sete Irmãos Calabash era o Xi Yangyang!

Nem uma webnovel melodramática do tipo Mary Sue ousaria escrever uma reviravolta tão absurda!

Mas o pai estava ali, diante dela, falando com tamanha convicção que era impossível simplesmente não acreditar.

Ela se esforçou para aceitar aquela revelação inacreditável. Ainda assim, bastava pensar um pouco para encontrar furos na história por todos os lados.

— Mas nós estamos dentro de um livro! Se a mamãe pesquisa viagens no tempo, podia muito bem me mandar para a Antiguidade assistir à coroação de Qin Shi Huang. Ou, sei lá, para o Jurássico, ver um tiranossauro fazendo cocô. Por que raios me mandou para dentro de um livro?!

Ao tocar nesse assunto, Ning Dazhi também se mostrou desolado. — Naquela noite, sua mãe estava ajustando em casa os parâmetros da máquina de viajar pelo espaço-tempo. Ela inseriu uma sequência de dados errada e estava tentando corrigir quando Bajie, aquele seu gatinho britânico gorducho, não sei de onde saiu, entrou sorrateiro na sala e deu uma patada no botão de ligar. Aí você fez *vuuuup* e desapareceu...

Ning Xiaoxiao: — ??? Vocês não conseguem inventar nada mais absurdo, não?

Ning Dazhi dominava a arte de inverter a culpa. Antes que a filha pudesse reclamar, assumiu o tom autoritário de pai:

— E ainda tem coragem de falar? Há quantos dias você vem adiando a monografia de conclusão de curso? Você se tranca no quarto dizendo que vai pesquisar para o trabalho e fica lendo essas novelas novelescas! Já que ia ler alguma coisa, não podia escolher uma história de juventude num colégio, cheia de energia positiva? Assim, mesmo entrando no livro, pelo menos cairia numa sociedade regida por leis, onde as pessoas não morrem a toda hora!

Ao ouvir aquilo, Ning Xiaoxiao sentiu o alívio de quem escapara por pouco de um desastre.

Ainda bem que, quando Bajie apertou o botão, ela estava lendo uma novel e acabou entrando no livro.

Antes de começar a ler, ela estava assistindo a *Resident Evil*... Se tivesse sido transportada enquanto assistia àquilo, não acabaria perseguida e devorada por zumbis assim que pusesse os pés no novo mundo?

Fazendo um biquinho, sentou-se ao lado de Ning Dazhi. — Está bom, está bom. Já vim parar aqui mesmo, não adianta falar disso. Agora que Lu Linyuan foi tratado, não corre mais risco de vida. Então...

Ela lançou um olhar na direção de Lu Linyuan. Saber que em breve poderia deixar aquele lugar — e aquele personagem bidimensional boboca — despertou nela uma pontinha de relutância.

Afinal, aquele mundo não era o seu. Mais cedo ou mais tarde, teria de voltar.

Tudo o que vivera até então podia ficar para trás como um sonho.

Permaneceu em silêncio por um longo tempo. Então respirou fundo e tomou uma decisão difícil.

Olhou para Ning Dazhi com firmeza e declarou, palavra por palavra: — Pai! Estou pronta! Vamos embora!

Ning Dazhi: — ...

Ele esboçou um sorriso sem graça, desviou o olhar e gaguejou: — Bem... filhinha, acho que você entendeu errado... Por enquanto, não pode voltar...

Ning Xiaoxiao: — ??? Como assim, não posso? Se você conseguiu vir, por que eu não posso ir embora?

— Eu vim com meu corpo inteiro, mas no seu caso é diferente. Você ocupou o corpo de uma personagem do livro. Para voltar, vai ter de aguentar até o grande final... A Administração do Espaço-Tempo deve ter designado um sistema para você. Basta seguir as instruções dele e concluir direitinho as missões que poderá voltar!

Ning Xiaoxiao abriu um sorriso que não chegava aos olhos. — Ah, muito obrigada mesmo...

Ning Dazhi deu uma palmadinha no ombro da filha. — Papai não pode ficar sempre ao seu lado. Com a tecnologia que sua mãe desenvolveu até agora, só consigo permanecer aqui por três dias. E nem sempre a viagem dá certo. Você vai ter de resolver muita coisa por conta própria.

— E a mamãe? Por que ela não veio pessoalmente?

— Sua mãe adora você. Como não ia querer vir? Ela... Hahahaha! — No meio da frase, Ning Dazhi pareceu se lembrar de algo tão engraçado que desatou a rir, dobrando-se ao meio.

Ning Xiaoxiao encarou o próprio pai como se olhasse para alguém que perdera completamente o juízo. — Pai, para de rir. Você está me assustando...

Depois de um bom tempo, Ning Dazhi conseguiu se recompor. — Na primeira vez que sua mãe entrou num livro, foi parar em *Jornada ao Oeste*, no corpo do Rei Chifre de Prata. Só que... como ele ficou delicado demais, o Rei Chifre de Ouro o espancou até a morte no primeiro dia...

Ning Xiaoxiao: — ...

— Na segunda vez, ela entrou em *À Margem da Água* e virou Li Kui, o Turbilhão Negro. Aí, sem ter o que fazer, começou a bordar flores no acampamento. Quando descobriram, expulsaram-na do grupo dos heróis do Monte Liang...

Ning Xiaoxiao: — ...

— Na terceira vez que sua mãe entrou num livro...

— Chega, chega! E você? Como conseguiu vir para cá?

Ning Dazhi estufou o peito, tomado subitamente pelo orgulho. — Vi sua mãe tentando de novo e de novo e falei: “Por que não me deixa tentar?”. E aqui estou!

Ning Xiaoxiao ainda estava desconfiada. — Acertou de primeira?

— Cof, cof... Claro! — Ning Dazhi elevou a voz em uma oitava. — Na primeira tentativa! Aterrissei no lugar certinho!

*Pensamento secreto:* E o que você queria? Que eu lhe contasse que...

Já virei um monstrinho esmagado no chão pelo Ultraman;

Também virei o Lobo Cinzento, chutado pelo Xi Yangyang até o espaço sideral;

E até aquele espírito de sapo que fica guardando a porta para a demônia serpente em *Os Irmãos Calabash*...

Eu também tenho uma reputação a zelar, está bem?! Cansei. Pode acabar com o mundo...

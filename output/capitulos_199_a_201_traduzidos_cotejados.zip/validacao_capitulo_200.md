# Validação do capítulo 200

- **Fonte primária:** `novel_capitulos_181_a_211(20261105-152737).docx` (chinês tradicional).
- **Limites no DOCX:** índices de parágrafo base zero de **1212** até **1271** (inclusive; podem conter parágrafos vazios).
- **Título original:** 第200章 俺是頭蠢驢
- **Unidades não vazias:** 57, incluindo título.
- **CSV:** capitulo_200_cotejo.csv; cabeçalho exato `indice_docx,original_chines,traducao_portugues`; 57 registros.
- **Integridade estrutural:** os índices do CSV coincidem exatamente com os índices não vazios do capítulo no DOCX; não há lacunas, duplicações ou campos vazios.
- **Markdown:** capitulo_200_traducao_revisada.md; todos os textos traduzidos do CSV constam integralmente no Markdown, preservando a ordem.
- **Decisões e ressalvas editoriais:** A brincadeira original é fonética: frases com aparência de versos eruditos soam como “não tenho cultura, minha inteligência é baixa; sou um burro muito burro”. Como não há equivalência fonética completa em português, a versão usa versos artificiosamente solenes e uma tradução cômica explícita. Esta é uma adaptação editorial de efeito, não uma reprodução exata da homofonia chinesa. O termo 貴妃 no original foi mantido implicitamente como cargo de consorte; há menção isolada que pode conflitar com a promoção de Tong a 妃, e não foi corrigida no chinês do CSV.
- **Limitação:** revisão contextual feita durante a tradução; não foi realizada auditoria semântica independente integral. A cobertura 1:1 de parágrafos não prova por si só ausência de erros internos de interpretação.

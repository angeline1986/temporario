# Capítulo 200 — Eu sou uma mula burra

A Consorte Tong acompanhou o olhar de Lu Linyuan e acabou fitando Ning Xiaoxiao, furiosa de dar dó.

Havia umas dez mil e oitenta e seis coisas que ela não conseguia entender. Por que, mesmo depois de exibir todos os seus talentos e se esforçar mais do que qualquer outra, não conseguia sequer um olhar de Lu Linyuan?

Enquanto Ning Xiaoxiao não precisava fazer coisa alguma: bastava sentar-se ali, saboreando a refeição, para conquistar toda a atenção dele?

No entender dela, sua origem, porte e beleza não eram inferiores aos de Ning Xiaoxiao em nenhum aspecto. Então por que Lu Linyuan a desprezava e tratava Ning Xiaoxiao como um tesouro?

Ressentida ao extremo, pigarreou de propósito e falou com Ning Xiaoxiao:

— Concubina Hua, já não comeu o bastante? Todas as outras compuseram poemas. Entre as senhoras que presidem os palácios, falta apenas você.

A Consorte Li tratou de jogar lenha na fogueira: — Isso mesmo. A irmã Concubina Hua demonstrou um talento literário tão “extraordinário” ao completar versos... Por que não improvisa agora um poema para abrir nossos olhos?

Muitas outras insistiram por bastante tempo. Mas foram apenas as palavras da imperatriz que acenderam o “espírito competitivo” de Ning Xiaoxiao.

— Parem de pressionar a Concubina Hua. Ela ainda é jovem, tem pouca experiência. Já foi muito difícil conseguir respostas tão bem construídas. Exigir agora que componha um poema não seria constrangê-la de propósito?

A provocação da imperatriz deu certo.

Ning Xiaoxiao, jovem chinesa que nunca aceitava perder, não suportava ouvir que era incapaz de alguma coisa.

Pousou os talheres, limpou a boca com um lenço e disse: — Compor um poema não é impossível. Só que meu talento literário é modesto e eu não saberia recitá-lo com a entonação expressiva de Vossa Majestade. Sinto que lhe faltaria a atmosfera adequada.

— Que tal fazermos assim? Eu componho, e Vossa Majestade recita por mim. Pode ser?

A imperatriz ainda não fazia ideia do que a aguardava e aceitou gentilmente: — Claro. Escreva o poema e entregue-o a mim. Eu o lerei para todas, para que conheçam suas impressões sobre a primavera.

De primavera, Ning Xiaoxiao não tinha grandes impressões. Mas conseguir que a imperatriz bancasse a palhaça? Isso ela sabia fazer.

Com toda a pose, pegou pincel, tinta, papel e pedra de tinta das mãos de um eunuco. Molhou o pincel, foi até a margem do Lago Imperial e contemplou o horizonte, ora balançando a cabeça, ora assumindo o ar pedante de um poeta cheio de si.

Logo escreveu um poema de uma só vez, com movimentos amplos e decididos, e entregou-o à imperatriz para que o recitasse.

A imperatriz observou a caligrafia toda torta de Ning Xiaoxiao e, sem ter elogio melhor, inventou: — A letra da Concubina Hua... é realmente bastante peculiar...

As consortes, ansiosas para rir dela, pediram que a imperatriz lesse o poema. Ela pigarreou e começou a recitá-lo com toda a solenidade:

(*Nota da autora: os versos a seguir vêm acompanhados de uma “tradução imperial”. Nota editorial: no chinês, caracteres aparentemente poéticos imitam foneticamente frases em que a recitadora se chama de burra; a adaptação abaixo procura reproduzir a pegadinha em português.*)

— “Eu sou a musa da cultura...” (*Eu sou uma mula sem cultura.*)

— “Minha mente é pura, sem agrura...” (*Minha mente é uma burrice pura.*)

— “A mula...” (*Sou mula.*)

— “A mula reluz...” (*Sou uma mula.*)

— “A mula, burra, à luz...” (*Sou uma mula burra.*)

Terminada a leitura, as consortes mais inteligentes ficaram estarrecidas: perceberam que Ning Xiaoxiao acabara de fazer a imperatriz insultar a si própria, diante de todos.

As menos espertas também ficaram atônitas, mas porque imaginavam que Ning Xiaoxiao fizera belos versos sobre o verde, a primavera e o renascimento da natureza.

A imperatriz, que recitara o poema sem perceber a armadilha, pertencia justamente ao segundo grupo.

Ela suspirou admirada: — Que poema maravilhoso! Verdadeiramente maravilhoso! A Concubina Hua não menciona a primavera diretamente, e ainda assim cada verso evoca a estação. O significado é excelente, e as palavras foram escolhidas com cuidado. Muito bom, muito bom!

Assim que disse isso, as consortes que tinham entendido a piada não conseguiram conter os risos. Lu Linyuan quase caiu para trás de tanto gargalhar.

Ao vê-lo rir, a imperatriz pensou que sua bajulação tivesse funcionado. — Majestade também gostou?

Lu Linyuan: — Hahahaha! É claro que gostei muitíssimo. Sobretudo porque você recitou tão bem.

Mesmo então, a imperatriz não entendeu o significado do poema. Como havia muito tempo que Lu Linyuan não sorria para ela, ficou ainda mais convencida de seu sucesso.

— Vossa Majestade e eu realmente pensamos em harmonia. Eu sabia que, se algo me agradasse, certamente agradaria também a Vossa Majestade.

Lu Linyuan conteve outra risada. — Não precisa exagerar. Sua erudição literária supera em muito a minha. Então gosta mesmo do poema que Xiaoxiao escreveu?

A imperatriz fez uma reverência: — Sim, Majestade.

Lu Linyuan riu em voz alta: — Nesse caso, preciso lhe dar uma recompensa!

Mandou trazer pincel, tinta, papel e pedra de tinta. Com caligrafia vigorosa e elegante, copiou o poema de Ning Xiaoxiao e ofereceu sua obra manuscrita à imperatriz.

Ela recebeu aquela caligrafia imperial transbordando de alegria, como se tivesse ganhado um tesouro inestimável. Ainda lançou um olhar de exibição para a Consorte Tong antes de dizer:

— Agradeço a Vossa Majestade pela preciosa caligrafia. É a primeira vez que recebo uma obra escrita por sua mão. Vou pendurá-la no lugar mais visível do Palácio Fengluan e admirá-la todos os dias.

Lu Linyuan já sentia o rosto doer de tanto segurar o riso. — Desde que isso a faça feliz.

A imperatriz segurou cuidadosamente o presente. Esperou a tinta secar por completo, enrolou o papel com delicadeza e voltou ao assento levando-o consigo.

A Consorte Tong, sentada ao lado dela, ria tanto que quase cuspia saliva.

A imperatriz lhe lançou um olhar atravessado e murmurou: — Consorte Tong, não seja tão deselegante. Sei que está ressentida porque o imperador me presenteou com sua caligrafia. Mas o que posso fazer?

Ela endireitou a postura, cheia de confiança. — Só eu possuo uma coisa dessas. Não adianta morrer de inveja.

A Consorte Tong cobriu a boca com o lenço e riu: — Inveja de quê? De você ser uma mula? Ou uma mula burra das grandes? Hahahaha!

Depois daquela explicação, a imperatriz notou que os outros tentavam abafar risadinhas. Só então compreendeu o que o poema realmente dizia.

Seu rosto ficou horrível. Escondeu a caligrafia embaixo da mesa e corou tanto que parecia o céu tingido de vermelho ao nascer do sol.

Quando o banquete no Lago Imperial terminou, Lu Linyuan levantou-se e chamou Ning Xiaoxiao para voltar com ele ao Palácio Chaoyang. Depois disso, ignorou todas as outras consortes.

Aquelas mulheres haviam passado o dia inteiro alimentando expectativas por causa da imperatriz, esperando impressionar o soberano e conquistar uma vaga na viagem à estância de águas termais. Como Lu Linyuan nem sequer mencionou o assunto, alguém acabou perguntando:

— Majestade... as vagas para a estância de águas termais ainda não foram definidas...

Lu Linyuan apertou a mão de Ning Xiaoxiao e respondeu friamente: — Só levarei Xiaoxiao comigo. O que ainda há para definir?

As consortes ficaram pasmas. A Consorte Tong, que mais se esforçara e já estava quase congelando, não suportou a injustiça: — Buaaa! Se Majestade já tinha decidido levar apenas a Concubina Hua, por que me fez apresentar tantas coisas hoje?

Lu Linyuan ficou ainda mais impaciente ao vê-la choramingar. — Foi você quem resolveu nadar no Lago Imperial. O que tenho a ver com isso? Além disso, há muito tempo entreguei à imperatriz a lista das consortes que iriam à estância. Como assim? Ela não contou a vocês?

Num instante, todos os olhares se voltaram para a imperatriz.

Havia raiva e hostilidade naqueles olhos, mas a imperatriz não se perturbou. Bebeu tranquilamente um gole de chá, sem demonstrar a menor intenção de lhes dar atenção.


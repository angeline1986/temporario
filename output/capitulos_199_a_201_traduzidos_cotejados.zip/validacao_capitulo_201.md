# Validação do capítulo 201

- **Fonte primária:** `novel_capitulos_181_a_211(20261105-152737).docx` (chinês tradicional).
- **Limites no DOCX:** índices de parágrafo base zero de **1272** até **1337** (inclusive; podem conter parágrafos vazios).
- **Título original:** 第201章 免死金牌
- **Unidades não vazias:** 63, incluindo título.
- **CSV:** capitulo_201_cotejo.csv; cabeçalho exato `indice_docx,original_chines,traducao_portugues`; 63 registros.
- **Integridade estrutural:** os índices do CSV coincidem exatamente com os índices não vazios do capítulo no DOCX; não há lacunas, duplicações ou campos vazios.
- **Markdown:** capitulo_201_traducao_revisada.md; todos os textos traduzidos do CSV constam integralmente no Markdown, preservando a ordem.
- **Decisões e ressalvas editoriais:** A medalha 免死金牌 foi traduzida como Medalha de Imunidade à Pena de Morte. Lu Linyuan ouve o pensamento romântico de Ning; ela não o declara em voz alta. O presente pertencia a Gu Sijin na trama original, mas é entregue a Ning na linha temporal atual. A expressão de finalidade penal foi mantida como alegação do narrador dentro do mundo ficcional.
- **Limitação:** revisão contextual feita durante a tradução; não foi realizada auditoria semântica independente integral. A cobertura 1:1 de parágrafos não prova por si só ausência de erros internos de interpretação.

# Capítulo 199 — A arte de ser uma comilona

Ning Xiaoxiao nem estava propriamente respondendo com versos. O que ela queria, muito descaradamente, era aproveitar a oportunidade para jogar na cara daquelas consortes tudo o que tinha vontade de lhes dizer.

Afinal, Lu Linyuan dissera que ela podia responder à vontade, mesmo que seus versos não fossem bons. Então por que haveria de se preocupar?

Já tinha respondido a três versos e insultado duas desgraçadas. Quanto mais fazia isso, mais empolgada ficava.

Foi a imperatriz quem percebeu que a situação estava saindo do controle e tratou de encerrar aquela parte da atividade:

— A irmã Concubina Hua realmente possui um talento literário extraordinário. Suas respostas em verso são... bastante bem construídas.

Ning Xiaoxiao sorriu: — Continue, Vossa Majestade! Acho que ainda consigo responder a uns setenta ou oitenta!

Imperatriz: — ...

Se deixasse você continuar, acabaria insultando até dezoito gerações dos meus antepassados!

Lu Linyuan, que havia rido tanto das duas respostas anteriores que quase caíra para trás, só então conseguiu se recompor:

— Seus versos foram excelentes. Gostei de ouvi-los. Continue.

O rosto da imperatriz alternou entre verde e branco. Ela forçou um sorriso sofrido.

— Majestade, receio que ninguém no harém seja capaz de competir com a irmã Concubina Hua nessa arte. Que tal compormos poemas em louvor à primavera, como um bom presságio para o ano que vem?

Lu Linyuan ignorou completamente a imperatriz e olhou apenas para Ning Xiaoxiao: — Você prefere completar versos ou compor um poema?

A pergunta dava a impressão de que todo o banquete no Lago Imperial havia sido organizado para Ning Xiaoxiao se apresentar, e mais ninguém importava.

Mas o pensamento dela era outro: 【Eu quero tanto fugir daqui...】

Ela fitou o novo prato de *Buda Salta o Muro* que acabava de chegar à mesa e quase começou a babar.

【Será que não posso comer primeiro o abalone desse ensopado? Daqui a pouco vai esfriar!】

【Essas mulheres do harém são doentes da cabeça? Em vez de comer uma coisa tão gostosa, ficam aqui implorando para levar desaforo...】

Depois de reclamar mentalmente, ela estava prestes a responder, quando o imperador disse: — Você já passou um bom tempo completando versos. Deve estar cansada. Vamos comer primeiro. Conversamos depois que estiver satisfeita.

Era como receber um indulto. Ning Xiaoxiao se apressou: — Muito obrigada, Majestade!

Mal terminou de falar e, antes mesmo de a imperatriz tocar nos talheres, já começou a devorar a comida como se alguém fosse roubá-la.

As consortes tinham de obedecer a regras à mesa: comer bocadinhos pequenos e esconder a boca ao mastigar, sem deixar que ninguém visse o movimento das mandíbulas.

Mas Ning Xiaoxiao nunca ligara para tais regras. Fazia de conta que estava na própria casa e comia como lhe desse vontade. Não mastigar fazendo barulho já era o último resquício de educação que oferecia.

Gu Sijin observou aquele apetite despreocupado e se inclinou para lhe recomendar baixinho: — Xiaoxiao, coma mais devagar. Cuidado para não se queimar.

De boca cheia, Ning Xiaoxiao respondeu embolando as palavras: — Irmã, essas coisas têm de ser comidas depressa! Se esfriam, perdem a graça.

Gu Sijin: — ...

Está bem. Finja que não falei nada.

Para Lu Linyuan, porém, até aquele jeito pouco elegante de comer era sinal de que a comida estava deliciosa, e lhe abria o apetite.

Ele não tirava os olhos de Ning Xiaoxiao, embora mantivesse uma expressão impassível.

A Consorte Tong percebeu e imaginou que Lu Linyuan estivesse achando os modos de Ning Xiaoxiao indecorosos. Já ia repreendê-la quando ouviu o imperador dizer:

— Este *Buda Salta o Muro* não é muito do meu gosto. Sanfu, leve esta tigela diante de mim à Concubina Hua. É um presente meu.

As regras para as refeições do imperador eram diferentes das aplicadas às consortes. Mesmo ao presentear alguém com comida, ele não deveria oferecer o próprio recipiente imperial de ouro.

Mas Sanfu levou diretamente à frente de Ning Xiaoxiao a tigela dourada de *Buda Salta o Muro* de Lu Linyuan.

Aquela comilona só enxergava a abundância de frutos do mar e esqueceu completamente todas as regras.

Agradeceu a graça de maneira protocolar e logo começou a comer com as duas mãos, sem fazer a menor cerimônia diante de Lu Linyuan.

Usar os utensílios de mesa do imperador constituía uma grave afronta ao protocolo.

A imperatriz vinha se contendo desde cedo, mas enfim abriu a boca:

— Majestade, mesmo que deseje presentear a Concubina Hua, não convém lhe dar seu próprio recipiente. Sanfu poderia transferir o ensopado para uma tigela de porcelana branca e só então entregá-lo a ela.

Pela primeira vez, a Consorte Tong ficou do mesmo lado da imperatriz: — Exatamente. Como os utensílios de Sua Majestade podem ser usados indiscriminadamente pelas consortes? Isso... não está de acordo com as regras.

Não está de acordo com as regras?

E por acaso Lu Linyuan já fizera poucas coisas contrárias às regras por Ning Xiaoxiao?

Mais do que mimá-la sem limites, o que ele menos suportava era ouvir outras mulheres dando palpites sobre seus atos.

Por isso, fingiu não ouvir os conselhos da imperatriz e da Consorte Tong. — Vejo que nenhuma de vocês tem vontade de comer. Ficam todas olhando para Xiaoxiao. Nesse caso, não precisam comer.

Com um gesto amplo, ordenou: — Retirem o *Buda Salta o Muro* da mesa de todas elas. Separem os pepinos-do-mar e os abalones e ofereçam tudo à Concubina Hua.

Ning Xiaoxiao, com um abalone enorme ainda preso entre os dentes, sem sequer ter conseguido mastigá-lo: — ???

【Tudo para mim??? Ele está tentando me matar de tanto comer...】

Mas os eunucos responsáveis pelos pratos não se preocupavam se ela morreria empanturrada. Como nenhuma das consortes havia sequer tocado no ensopado, separaram habilmente as iguarias — abalone, pepino-do-mar e outras delícias — e as dispuseram num prato vazio diante de Ning Xiaoxiao.

Num instante, todos os olhares se concentraram naquela comilona.

Por melhor que fosse a comida, era difícil engoli-la com tanta gente encarando.

Lu Linyuan pareceu perceber seu constrangimento e disse imediatamente: — A Concubina Hua não é a ancestral de vocês. Por que estão todas olhando para ela? Já que não querem comer, comecem logo seus poemas. Parem de ficar aí, como se nunca tivessem visto comida, observando os outros se alimentarem.

Depois de ouvirem aquilo, as consortes naturalmente não ousaram olhar mais.

Assim, Ning Xiaoxiao pôde se fartar sem constrangimentos. Só Gu Sijin continuava rindo, vendo-a encher as bochechas como um hamster.

— Xiaoxiao, coma devagar. Não foi ontem mesmo que você disse que queria emagrecer? Já esqueceu?

Ning Xiaoxiao abriu um sorriso sem-vergonha: — Fazer dieta é uma coisa, comer é outra. Não há conflito nenhum. Além disso, como vou ter forças para emagrecer se não comer bastante primeiro?

Gu Sijin: — ...

Está bem. O importante é você ser feliz.

Lu Linyuan observava as duas e ouviu tudo com clareza.

Isso mesmo. Sua Xiaoxiao não precisava emagrecer.

Não apenas não precisava, como devia comer ainda mais.

Vejam só, a pobre menina estava passando tanta fome que até o tamanho D parecia ter diminuído...

Enquanto Ning Xiaoxiao comia, as demais consortes compunham poemas dedicados à primavera do próximo ano.

Era preciso reconhecer que aquelas mulheres tinham algum talento. Seus poemas não chegavam ao nível dos grandes mestres, mas soavam agradáveis e tinham significado.

A Consorte Tong, em especial, era perita em adivinhar temas de provas. Desde cedo previra que a composição do ano teria algo a ver com a primavera e preparara muitos versos a respeito.

Todos haviam sido encomendados pela família dela a escritores de fora do palácio; sob todos os aspectos, superavam os das demais consortes.

Quando terminou de recitar, a Consorte Tong ergueu o queixo com arrogância, toda empertigada como uma galinha prestes a botar ovos. Mas recebeu apenas uns poucos elogios bajuladores da Consorte Li e de outras mulheres.

Quanto a Lu Linyuan, não prestou a mínima atenção aos versos dela. Passou o tempo inteiro olhando para o jeito desajeitado com que sua Xiaoxiao comia, os olhos brilhando de carinho e um sorriso indulgente nos lábios.


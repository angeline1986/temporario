# Capítulo 201 — A medalha que livra da morte

A profundidade dos cálculos da imperatriz não se limitava àquilo.

A cada movimento que fazia, já pensava em três possíveis saídas. Jamais se colocava de propósito numa situação passiva ou constrangedora.

Assim, mesmo agora que Lu Linyuan acabara de expor sua manobra diante de todos, ela estava absolutamente confiante de que conseguiria se justificar.

Somente depois de beber seu chá, disse calmamente: — Não contei a vocês com antecedência justamente porque receava que fizessem essas caras que estão fazendo agora. Num dia de festa tão bonito, isso estragaria o ambiente.

Lu Linyuan não tinha paciência para acompanhar os jogos da imperatriz com aquelas mulheres. Segurou a mão de Ning Xiaoxiao e foi embora.

Assim que desceram da plataforma do banquete no centro do Lago Imperial e entraram na carruagem imperial, começou a nevar.

Ning Xiaoxiao ainda trazia nos ombros a capa amarelo-viva com bordados de dragão de Lu Linyuan, por isso não sentia frio.

Mesmo assim, depois de ajudá-la a subir, Lu Linyuan a puxou para os braços.

Aquela gatinha pequenina, aninhada contra ele, achou o peito firme do imperador extremamente quente. E, além do calor, sentiu uma profunda segurança.

Se Lu Linyuan tivesse agido assim no passado, ela certamente o teria rejeitado.

Mas, ultimamente, talvez porque as investidas dele estivessem intensas demais, Ning Xiaoxiao vinha se acostumando aos poucos a ser abraçada por ele. Já nem achava aquilo impróprio.

Chegou até a lhe perguntar sem corar nem ter o coração acelerado... Não, pensando bem, sem a menor vergonha na cara:

— Majestade, nessa viagem à estância de águas termais, vai mesmo levar só a mim?

— Sim. — A voz grave de Lu Linyuan vibrou junto ao ouvido dela. — Está feliz?

A estância de águas termais recebera apenas umas poucas linhas de descrição no romance original. Ning Xiaoxiao tinha banheira na casa moderna, por isso não achava tomar banho em águas termais nada de especial.

No fundo, porém, havia outra questão: se Lu Linyuan levasse apenas ela, o que seria da adorável Sijin?

Na estância, Lu Linyuan não teria tantos compromissos de governo. Tirando a leitura dos memoriais, poderia passar bastante tempo com ela, que certamente não ficaria entediada.

Mas, se os dois fossem embora, Gu Sijin ficaria sozinha para enfrentar todos aqueles monstros do harém. Ning Xiaoxiao não conseguia ficar tranquila com essa ideia.

Por isso, começou a pensar em outra de suas ideias malandras.

— Majestade...

— Nem pense nisso.

— ...

Muito bem. Ele já aprendera a responder antes mesmo de ouvir a pergunta.

Lu Linyuan cortou o assunto antes que Ning Xiaoxiao pudesse falar e resmungou, com ciúme evidente: — Já que Gu Sijin é tão importante assim para você, por que não se casa logo com ela? Para que continuar sendo minha concubina?

Vejam só quanto ciúme havia naquelas palavras! Até parecia que Ning Xiaoxiao havia implorado para se tornar concubina dele.

Mas, por mais teimoso que fosse com as palavras, seu corpo era muito sincero. Com medo de que o comentário afastasse Ning Xiaoxiao, apertou-a ainda mais contra si, quase sem perceber.

Ning Xiaoxiao notou que a respiração de Lu Linyuan ficara mais pesada. Sempre que isso acontecia, era sinal de que ele estava aborrecido.

Pensando melhor, ela própria realmente não estava sendo muito romântica.

【Quantas vezes ele já se esforçou para criar oportunidades de ficarmos a sós?】

【Ah... Entre nós só falta romper aquela última película de papel. Esse imperador orgulhoso continua dando passos à frente. Não tenho motivo para ficar recuando o tempo todo, tenho?】

Ergueu discretamente a cabeça e espiou Lu Linyuan.

Como estava aninhada nos braços dele, precisava olhá-lo de baixo para cima: o famigerado ângulo que costuma destruir qualquer beleza.

Mas é por isso que personagens de papel são uma maravilha! Mesmo naquele ângulo desastroso, Lu Linyuan era tão bonito que parecia impossível encontrar um único defeito em qualquer dos seus 360 graus.

Depois de observá-lo por alguns instantes, ela própria ficou vermelha de vergonha e desviou o olhar.

【Além do mais... não é como se eu não gostasse dele...】

Ao ouvir aquele pensamento, Lu Linyuan sentiu o coração explodir em alegria.

Enquanto isso, o coraçãozinho de Ning Xiaoxiao batia tão descontrolado que parecia prestes a saltar pela garganta.

Num sobressalto, ela se desvencilhou dos braços dele, ajeitou a franja e sentou-se do outro lado da carruagem. Ficou olhando pela janela, tentando esconder a timidez e o constrangimento.

Lu Linyuan a observou e sorriu. — O que foi? Por que está fugindo?

Ning Xiaoxiao: — ???

Ele fez um gesto chamando-a com o dedo. — Venha cá. Tenho uma coisa para lhe dar.

Quando viu que ela não se movia, deu-lhe um leve peteleco na testa.

Por reflexo, Ning Xiaoxiao franziu a testa e fechou os olhos. Ouviu o roçar de roupas e logo sentiu alguma coisa fria tocar sua testa, como se alguém a estivesse batendo de leve com um objeto.

— Abra os olhos.

Ela os abriu, ainda apreensiva, e viu que Lu Linyuan estava segurando uma placa dourada e dando batidinhas na cabeça dela.

— O que é isso? — perguntou, curiosa.

Lu Linyuan lhe lançou a placa como se não tivesse importância. Ning Xiaoxiao a segurou e examinou com atenção. Nela estavam gravados quatro caracteres enormes:

— Medalha de Imunidade à Pena de Morte.

A mão que segurava a placa dourada tremia um pouco, tanto de alegria quanto de inquietação.

Afinal, no romance original, aquela medalha tinha um valor enorme. Existia apenas uma em todo o Império Qi. Na história original, Lu Linyuan a havia concedido a Gu Sijin. Agora, porém, estava entregando-a a ela?

Apresentar a medalha equivalia a apresentar-se em nome do próprio imperador. Ela podia livrar o portador de qualquer acusação, mesmo crimes capitais capazes de condenar todo o clã à execução.

Ning Xiaoxiao levou um bom tempo para se recuperar do espanto. — Mas por que Vossa Majestade está me dando uma coisa dessas, assim, do nada?

— Ora, ainda tem coragem de perguntar? — Lu Linyuan lhe lançou um olhar falsamente desdenhoso. — Conte você mesma quantas regras quebrou hoje diante de mim. Só porque eu estava presente ninguém ousou dizer nada. Mas e se um dia você se meter numa situação dessas quando eu não estiver ao seu lado?

— Mas... foram só coisinhas pequenas! — protestou Ning Xiaoxiao. — No máximo, falhas de etiqueta. Na pior das hipóteses, a imperatriz ou a Consorte Tong mandariam me dar umas palmadas com uma tábua. Para que eu precisaria de uma medalha que me salva da morte?

— Nem umas palmadas eu permito.

Lu Linyuan tornou a chamá-la para perto com um gesto.

Quando sua gatinha voltou a sentar-se ao lado dele, passou o braço pelos ombros dela, roçou o queixo em sua testa e falou com voz baixa:

— Se nem eu tenho coragem de bater em você, quem essas mulheres pensam que são?

Ele apertou firmemente a mão em que Ning Xiaoxiao segurava a medalha, fazendo-a agarrá-la com força.

— Guarde-a. Assim, quando eu não estiver ao seu lado, você poderá ficar tranquila.

Pouco depois, numa voz ainda mais baixa, quase um murmúrio dirigido a si próprio, acrescentou:

— Embora... eu vá estar sempre ao seu lado.


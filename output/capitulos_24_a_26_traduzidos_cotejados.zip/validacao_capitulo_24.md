# Conferência do capítulo 24

- Fonte primária: `novel_capitulos_1_a_60(20261103-131325).docx`, chinês tradicional.
- Limites: título do capítulo 24 até antes do título do 25.
- Unidades não vazias no DOCX (incluindo título): **72**.
- Correspondências não vazias no CSV: **72**.
- Unidades sem equivalente: **0**.
- Ordem preservada: sim, conforme o alinhamento sequencial do CSV.

## Revisão da tradução

Tradução realizada unidade a unidade a partir do chinês. Nomes de personagens e termos do sistema mantidos conforme o glossário. Diálogos, pensamentos marcados por 【 】, números, ações e o encadeamento da cena foram conferidos na preparação do cotejo.

## Decisões editoriais

- Título 朕不幹淨了: literalmente “já não estou limpo”, com conotação de pureza/contaminação cômica; escolheu-se “não sou mais puro”.
- A expressão inglesa “baby” aplicada a moscas foi adaptada a “bebeizinhos de mosca”.
- Mingau de fungo-prateado e ninho de andorinha preservado literalmente quanto aos ingredientes.

## Limites da validação

Cotejo estrutural integral e uma passagem de revisão semântica do próprio tradutor. **Não houve segunda auditoria independente**, por isso não há garantia de ausência de erros de interpretação e nuances. O CSV permite reavaliar cada unidade.

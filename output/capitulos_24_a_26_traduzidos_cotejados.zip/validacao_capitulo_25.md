# Conferência do capítulo 25

- Fonte primária: `novel_capitulos_1_a_60(20261103-131325).docx`, chinês tradicional.
- Limites: título do capítulo 25 até antes do título do 26.
- Unidades não vazias no DOCX (incluindo título): **67**.
- Correspondências não vazias no CSV: **67**.
- Unidades sem equivalente: **0**.
- Ordem preservada: sim, conforme o alinhamento sequencial do CSV.

## Revisão da tradução

Tradução realizada unidade a unidade a partir do chinês. Nomes de personagens e termos do sistema mantidos conforme o glossário. Diálogos, pensamentos marcados por 【 】, números, ações e o encadeamento da cena foram conferidos na preparação do cotejo.

## Decisões editoriais

- 四小天鵝舞: Dança dos Quatro Pequenos Cisnes, referência ao balé O Lago dos Cisnes; não é um balé genérico.
- 996: jornada de trabalho chinesa das 9h às 21h, seis dias por semana. Honor of Kings é citado diretamente no original.
- 完犢子10086 é exclamação cômica com número associado a serviço telefônico chinês; adaptado a “Ferrou! Ferrou bonito!”, com perda da referência numérica.

## Limites da validação

Cotejo estrutural integral e uma passagem de revisão semântica do próprio tradutor. **Não houve segunda auditoria independente**, por isso não há garantia de ausência de erros de interpretação e nuances. O CSV permite reavaliar cada unidade.

# Capítulo 26 — O tirano a “beijou à força”

Só quando chegou para entregar a sopa doce Ning Xiaoxiao percebeu que havia se precipitado.

Pensara que Lu Linyuan estaria sozinho no Palácio Chaoyang, examinando memoriais. Mas Sanfu também estava lá, servindo-o.

Ver a oportunidade escapar quando já parecia certa deixou-a profundamente desanimada...

Ao ouvir seu suspiro, Lu Linyuan ergueu os olhos e lançou-lhe um olhar irritado:

— Leve isso para a cozinha menor. Vou sair agora e não tenho tempo de tomar.

Ning Xiaoxiao perguntou, sorrindo: — Com esse sol forte do meio-dia, para onde Sua Majestade vai?

— O que você tem a ver com meus destinos? Cuide do próprio trabalho! Se continuar fazendo perguntas que não lhe dizem respeito, corto sua língua!

E saiu com um movimento brusco das mangas, deixando Ning Xiaoxiao sozinha, completamente perdida.

Não podia ser! Precisava concluir a missão em vinte e quatro horas, e já não lhe restava muito tempo!

Teria de seguir Lu Linyuan para ver se surgia outra oportunidade!

Assim, começou a acompanhá-lo sorrateiramente, feito uma sombra grudenta.

Lu Linyuan se dirigia ao lago imperial.

Ning Xiaoxiao lembrou-se de que a obra original descrevia alguns de seus hábitos.

Quando se cansava de ler memoriais ou encontrava um problema difícil de resolver, costumava caminhar às margens do lago imperial.

Para ter sossego, nunca permitia que ninguém o acompanhasse.

Ora, era como se ele próprio tivesse trazido a solução de bandeja!

Ao acompanhá-lo até o lago, ela o viu erguer a mão, ordenando aos guardas e eunucos que parassem ali, enquanto ele seguia sozinho até a água.

A entrada parecia fortemente vigiada, mas, para Ning Xiaoxiao, aqueles homens eram tão inofensivos quanto o ar.

Ela fechou os olhos, abriu o documento em sua mente, pressionou Pausar e passou bem diante de todos, sem se preocupar em se esconder.

Pouco adiante, encontrou Lu Linyuan parado junto ao lago.

Imobilizado pelo tempo, mantinha os belos olhos baixos, contemplando as pequenas ondulações na água, como se refletisse sobre alguma coisa.

Ning Xiaoxiao entrou nos arbustos atrás dele, arrancou duas flores ao acaso e apertou Reproduzir.

A trama voltou a avançar:

Ela provocou deliberadamente um farfalhar entre os arbustos, chamando a atenção de Lu Linyuan.

O homem virou a cabeça. Seus olhos penetrantes vasculharam os galhos de onde vinha o ruído, e sua voz soou fria:

— Quem está aí?

Ning Xiaoxiao pôs metade da cabeça para fora com a maior naturalidade. Ao encontrar os olhos dele, fingiu surpresa por um instante e logo sorriu, acenando:

— Ah, Majestade~ Que coincidência! Encontrá-lo até aqui!

Por que ela estava ali?

Lu Linyuan franziu as sobrancelhas, desconfiado.

Quando ele saíra do Palácio Chaoyang, ela ainda estava deixando a caixa de comida. Como poderia ter chegado ao lago antes dele?

— Você não estava no Palácio Chaoyang agora há pouco? Como é que...?

— A senhorita Gu mandou que eu colhesse flores no jardim imperial. Assim que deixei a caixa de alimentos, corri direto para cá.

Ning Xiaoxiao inventou a desculpa sem pestanejar e saiu dos arbustos para se aproximar.

Com medo de que não acreditasse, ainda sacudiu as duas flores diante dele: — Veja, Majestade~

Um cheiro estranhíssimo tomou o ar.

Lu Linyuan olhou as flores em sua mão e zombou com um sorriso frio:

— Então a Dama Gu gosta de cultivar fotínias? Hã. Que gosto peculiar. (Nota do original: a autora sugere pesquisar o cheiro dessas flores.)

Desviou o olhar, sem vontade de lhe dar mais atenção: — Se ela quer flores, continue colhendo. E não me incomode.

Agora que conseguira chegar tão perto dele, Ning Xiaoxiao podia executar a etapa seguinte do plano.

Pausou o tempo de novo, agachou-se e ergueu os pés do imperador, que estava imóvel e ereto, colocando-o na posição clássica do balé, com as pontas dos pés apoiadas no chão.

Ela também ficou na ponta dos pés e se posicionou diante dele, oscilando de um lado para o outro.

Quando terminou os preparativos, apertou Reproduzir. A trama prosseguiu:

Com a postura alterada de repente, Lu Linyuan ficou cambaleando, incapaz de manter o equilíbrio.

E justo naquele instante Ning Xiaoxiao ainda estendeu a mão e agarrou a dele:

— Ai, Majestade! Segure-me! Torci o pé...

Segurando sua mão, Ning Xiaoxiao inclinou o corpo para trás. Ao sentir que perdia o equilíbrio, Lu Linyuan teve a impressão de que ela o derrubaria a qualquer segundo.

Por puro instinto, soltou bruscamente a mão dela.

Bastou aquele pequeno movimento. Ning Xiaoxiao não conseguiu frear o próprio corpo, caiu de costas diretamente no lago imperial e levantou uma enorme quantidade de água.

Ela se debateu como um pato, agitando os braços de maneira desordenada: — Socorro! Socorro!!

Por mais desesperados que fossem seus gritos, Lu Linyuan não pretendia cair na armadilha.

Recordando todos os seus comportamentos esquisitos, ele tinha a impressão de que ela tentara deliberadamente puxá-lo para dentro do lago.

Com certeza quer fingir que está se afogando para me obrigar a salvá-la. Depois vai se agarrar a mim e me arrastar para a água!

Se eu acreditar nisso, sou um completo idiota!

Mas, daquela vez, Ning Xiaoxiao não estava fingindo!

Ela realmente não sabia nadar...

Tentou se obrigar a manter a calma, fechar os olhos, abrir o documento mental e usar o botão Retroceder.

Só que, sempre que parava de se debater, afundava. Assim, não conseguia se concentrar nem acessar o documento para usar sua vantagem especial.

Restou-lhe bater braços e pernas desesperadamente, gritando para Lu Linyuan: — Majestade, salve-me! Eu não sei nadar! Majestade!

Lu Linyuan não lhe deu atenção e se virou para ir embora.

Mas, justamente nesse instante, a superfície da água ficou quieta. Os gritos de Ning Xiaoxiao desapareceram, substituídos por alguns ruídos abafados de bolhas: glu, glu...

Ele se virou de repente e viu que Ning Xiaoxiao havia afundado.

O que o fez compreender de verdade a gravidade da situação foi que, dessa vez, não conseguia ouvir absolutamente nenhum pensamento dela.

Será que era verdade?

Naquele instante, todas as suas suspeitas desapareceram.

Uma única coisa ocupava sua mente: Ning Xiaoxiao não podia morrer de jeito nenhum!

Sem hesitar, mergulhou de cabeça no lago imperial.

De longe, Sanfu viu Lu Linyuan saltar na água e quase morreu de susto.

— Socorro! Rápido, rápido! Entrem na água e salvem Sua Majestade!

Assim que deu a ordem, mais de dez guardas pularam no lago, um atrás do outro, como bolinhos despejados numa panela.

A água do lago imperial estava longe de ser limpa. Principalmente no verão, quando algas boiavam sobre a superfície, conferindo-lhe um verde-escuro pouco agradável.

Com a obsessão de Lu Linyuan pela limpeza, até se a própria mãe caísse ali ele provavelmente pensaria duas vezes antes de salvá-la. Mas, quando se tratou de Ning Xiaoxiao, não hesitou nem um instante.

Felizmente, ela acabara de afundar. Lu Linyuan a encontrou rapidamente e, com a ajuda dos guardas, conseguiu trazê-la para fora da água.

— Ai, Majestade! Que susto o senhor me deu! — lamentou Sanfu.

Sanfu tirou a própria roupa para cobrir Lu Linyuan, mas ele o afastou com a mão. Ajoelhando-se parcialmente no chão, começou a sacudir Ning Xiaoxiao com força:

— Ning Xiaoxiao! Acorde agora mesmo! Eu não permito que você morra!

Se pudesse ouvir uma fala tão típica de um CEO mandão de romance, Ning Xiaoxiao certamente faria algum comentário sarcástico.

Mas dessa vez ela não reagiu nem um pouco.

Quando Lu Linyuan aprendera a nadar na juventude, os servos responsáveis pelos assuntos aquáticos também lhe haviam ensinado medidas de primeiros socorros para afogamentos.

Ele começou a pressionar vigorosamente o peito de Ning Xiaoxiao. No processo, achou que os seios enormes dela, tamanho D, estavam atrapalhando, e os empurrou para o lado com a mão.

Depois de duas ou três compressões, uma grande quantidade de água saiu da boca de Ning Xiaoxiao.

Então ele respirou fundo, inclinou-se e pressionou seus lábios contra os dela, soprando ar fresco para dentro de sua boca.

---

## Notas editoriais

- 石楠花: fotínia; o original traz uma observação da autora sobre o odor da flor, preservada em nota curta na narrativa.
- O título usa aspas para sugerir “beijo forçado”; o trecho final é respiração de resgate, não beijo romântico consentido.
- O original menciona literalmente seios tamanho D e descreve compressões e insuflação de ar. A tradução preserva o relato sem apresentá-lo como orientação médica.

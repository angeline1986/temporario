# Capítulo 24 — Eu não sou mais puro...

Ao presenciar aquela cena, os ministros primeiro ficaram perplexos. Logo, porém, assumiram a expressão de quem acabara de encontrar um casal pelo qual torcer.

Agora até os gemidos estranhos de Lu Linyuan e os tremores de seu rosto aparentemente tomado pelo prazer pareciam fazer sentido.

Afinal, se o imperador escondia uma mulher debaixo da mesa, bem junto à virilha, durante a audiência, o que mais poderia estar fazendo?

Nossa, Sua Majestade sabe mesmo se divertir~

Ning Xiaoxiao ainda estava apavorada com a barata e gritava, tremendo inteira.

Lu Linyuan rangeu os dentes e disse, sílaba por sílaba: — Me. Sol-te. A-go-ra!

Em seguida, contendo a própria repulsa à sujeira, esmagou a barata com o pé.

Quando viu o inseto morto, Ning Xiaoxiao finalmente conseguiu respirar aliviada.

Atordoada pelo susto, ela parecia ter se esquecido por completo de que estava em plena audiência imperial.

Murmurou um “quase morri de susto” e só então soltou Lu Linyuan.

Mas, no instante em que ia se virar, ele a agarrou pela nuca e pressionou seu rosto firmemente contra o peito.

Fez tanta força que quase enterrou o rosto inteiro dela nos músculos rígidos de seu tórax. Era de sufocar...

Até então, Lu Linyuan estivera de frente para os ministros, enquanto Ning Xiaoxiao se pendurava em seu pescoço, de costas para todos.

Assim, por mais escandalosa que tivesse sido a confusão, ninguém vira seu rosto com clareza.

Se ela se virasse agora e os ministros e servos a reconhecessem, tanto a corte quanto o harém ferveriam com fofocas.

Lu Linyuan não queria que ela arranjasse problemas desnecessários.

Ou, para ser mais preciso, não tinha a menor vontade de lidar com as consequências.

Ning Xiaoxiao pareceu compreender a razão daquele gesto e ficou quieta, deixando-o manter seu rosto contra o peito.

Lu Linyuan percorreu o salão com um olhar cortante: — A audiência matinal termina aqui. Dispensados!

Intimidados pelo tirano, os ministros não ousaram perder um segundo e se retiraram às pressas.

Depois da saída deles, Sanfu fechou as portas do Salão do Trono. Só então Lu Linyuan afastou Ning Xiaoxiao dos braços.

Encarou o rosto inocente dela, visivelmente irritado: — Mandei que registrasse os assuntos da audiência! Em vez disso, você beliscou minha coxa, virou a mesa e pulou em cima de mim! O que pretendia fazer?!

Ning Xiaoxiao puxou as próprias orelhas, com expressão sofrida, e confessou: — Perdoe-me, Majestade! Não fiz de propósito... É que...

Ela apertou os lábios, os olhos grandes cheios de lágrimas: — É que eu tenho muito medo de baratas!

Para as pessoas daquela época, encontrar baratas e ratos nos alojamentos dos servos de baixa categoria era algo perfeitamente comum.

Por isso, Lu Linyuan não conseguia entender tamanho pavor.

— Quanto medo você pode ter de uma barata? Por acaso ela vai devorá-la?!

— Me devorar, não... Mas pode me dar um nojo terrível... — Ning Xiaoxiao lançou um olhar ao cadáver da barata, reduzido a uma pasta pelo sapato imperial, e teve uma ânsia de vômito.

Depois, acrescentou: — Todo mundo tem medo de alguma coisa. Sua Majestade não tem?

Lu Linyuan respondeu com um olhar sombrio: — É claro que tenho...

— Pois é! Até Sua Majestade, que governa sobre todos, tem seus medos. Imagine uma criadinha como eu! Claro que sou ainda mais medrosa.

— Ah, é? — Ele abriu um sorriso ameaçador. — Então, agora que esmaguei a barata, ainda está com medo?

Ning Xiaoxiao balançou a cabeça: — Não...

— E como eu deveria lidar com aquilo que me dá medo?

— Do que Sua Majestade tem medo? — Achando que já conseguira enrolá-lo, ela apressou-se a mudar de assunto. — Também é um ser vivo?

Ele a observou por um longo momento, depois assentiu lentamente: — Pode-se dizer que sim.

— Ora, então é fácil! É só matar, como fez com a barata!

— Excelente sugestão. — O sorriso desapareceu de seu rosto. Ele estreitou os olhos. — Neste momento, o que mais temo é encontrar você!

Ning Xiaoxiao paralisou e fez um biquinho magoado.

— Majestade... Não vai querer me matar de novo, vai? Não faça isso! Toda vez que nos encontramos, o senhor quer me matar. Se me detesta tanto assim, não seria melhor nunca mais me ver? Assim eu não cometeria nenhum erro que o irritasse...

Olhem só! Agora ainda se fazia de ofendida!

Será que eu lhe dei liberdade demais? Ela acha que não posso fazer nada contra ela e por isso se comporta com tamanha insolência?

Lu Linyuan decidiu que, daquela vez, daria uma bela lição em Ning Xiaoxiao!

Mesmo sem poder matá-la, faria com que desejasse estar morta!

Ela não tinha pavor de coisas sujas?

Hehe.

O lugar do palácio com mais baratas, ratos e bebezinhos de mosca era, sem dúvida, a latrina dos servos.

— Não vou matá-la. Vou apenas fortalecer sua coragem. Um verdadeiro guerreiro enfrenta seus medos. Já que você teme tanto a sujeira, sua punição será limpar os penicos. Quando vir essas coisas todos os dias, deixará de ter medo.

Só de imaginar o cheiro, Ning Xiaoxiao já estava prestes a vomitar!

— Majestade! Eu errei! Pode me castigar de qualquer outra maneira, mas não me mande limpar penicos! Tenha piedade!

Piedade?

Lu Linyuan nem se deu ao trabalho de responder. Fez um gesto, e Sanfu a levou embora.

Sanfu, porém, sabia ler a situação. Já desconfiava que Lu Linyuan sentia algo por Ning Xiaoxiao; e, se ela saíra debaixo da mesa durante a audiência, só podia ter entrado lá com a permissão imperial.

Nunca vira o imperador “mimar” tanto uma mulher. Por isso, interpretou a ordem de limpar penicos como uma espécie de “brincadeira íntima” entre os dois.

Sem querer ofender aquela que talvez se tornasse uma consorte, Sanfu a designou para limpar os penicos do Palácio Chaoyang.

Afinal, como se tratava dos aposentos imperiais, os recipientes já estavam impecáveis. Bastaria fingir que trabalhava.

Ning Xiaoxiao agradeceu a Sanfu mil vezes e começou a esfregar de mentirinha os penicos, já tão limpos quanto possível e até perfumados com um leve aroma de gardênias.

Mas, quando Lu Linyuan voltou e soube que Sanfu a colocara para limpar os penicos do Palácio Chaoyang, explodiu de raiva!

Queria castigá-la, não lhe dar um serviço fácil para que descansasse!

Foi até a latrina e chamou Ning Xiaoxiao para fora.

Para mostrar como estava trabalhando duro, ela apareceu com uma escova na mão: — Sua Majestade me chamou?

Lu Linyuan ia falar quando ouviu, do lado de fora, a voz melosa da Consorte Nobre:

— Majestade~ Majestade~ Preparei um mingau de fungo-prateado e ninho de andorinha especialmente para o senhor~ Onde está, Majestade~?

Sem pensar, Lu Linyuan abriu a boca para responder.

Mas Ning Xiaoxiao não podia deixar a Consorte Nobre descobrir que estava ali!

A mulher já a detestava. Se a encontrasse nos aposentos do imperador, faria sabe-se lá que suposições e recorreria a toda sorte de artimanhas sujas para prejudicá-la!

Por puro reflexo, Ning Xiaoxiao avançou e tapou a boca de Lu Linyuan com a mão, fazendo sinal de silêncio:

— Majestade, Majestade! A Consorte Nobre não pode saber que estou aqui. Ela não gosta de mim! Se me encontrar em seu quarto, vai arranjar encrenca para o meu lado!

Lu Linyuan arregalou os olhos, empurrou-a violentamente e apontou, com o dedo trêmulo, para a mão que acabara de cobrir sua boca:

— V-você tapou a minha boca com a mesma mão que usou para esfregar os penicos?!

E então começou a vomitar sem conseguir se controlar...

---

## Notas editoriais

- Título 朕不幹淨了: literalmente “já não estou limpo”, com conotação de pureza/contaminação cômica; escolheu-se “não sou mais puro”.
- A expressão inglesa “baby” aplicada a moscas foi adaptada a “bebeizinhos de mosca”.
- Mingau de fungo-prateado e ninho de andorinha preservado literalmente quanto aos ingredientes.

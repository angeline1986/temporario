# Capítulo 25 — Dançando balé com o tirano

Ferrou! Ferrou bonito!

Ela se esquecera de novo da obsessão do tirano por limpeza!

— Majestade~ Sua consorte chegou para vê-lo~~

A voz da Consorte Nobre se aproximava cada vez mais. Ning Xiaoxiao se virou e correu de volta à latrina: — Majestade! Pode me castigar depois, agora preciso me esconder um pouquinho!

E fechou a porta.

Lu Linyuan olhou para a porta fechada e viu uma vassoura ao lado. Sem hesitar, enfiou o cabo na trava, bloqueando a porta pelo lado de fora. — Já que gosta tanto de se esconder, fique aí pelo resto da vida!

Voltou ao salão principal, dispensou em poucas palavras a Consorte Nobre, que estava toda assanhada, e começou a examinar os memoriais daquele dia.

Parecia ter esquecido completamente que deixara Ning Xiaoxiao trancada na latrina.

Cerca de duas horas depois, Sanfu trouxe uma tigela de leite fresco: — Majestade, o senhor não tem dormido bem nos últimos dias. Mandei a cozinha aquecer este leite com sementes de jujuba-azeda e casca de albízia, que ajudam a acalmar a mente. Beba enquanto está quente.

Lu Linyuan traçou uma anotação imperial com pinceladas vigorosas no memorial e respondeu distraidamente: — Está bem.

Sanfu deixou a tigela junto à mesa e já ia se retirar quando perguntou com cautela: — Majestade, Ning Xiaoxiao está trancada na latrina há duas horas. Implorou tanto por perdão que ficou rouca. Será que...?

A ponta do pincel de Lu Linyuan parou de repente. Ele ergueu uma sobrancelha e lançou a Sanfu um olhar de lado. — Você está cada dia melhor no seu trabalho, não é?

— Este servo não ousaria! — Sanfu se apavorou. — Falei demais! Não voltarei a importunar Vossa Majestade. Vou me retirar imediatamente...

Mal dera dois passos quando Lu Linyuan o chamou: — O Palácio Chaoyang fica silencioso à noite. Arranje um jeito de fazê-la calar a boca. Não quero que atrapalhe meu sono.

Sanfu sobrevivera tanto tempo a serviço do imperador que era capaz de adivinhar até quais vitaminas faltavam ao corpo dele pelo cheiro de um pum. Como não entenderia o significado oculto da ordem?

O imperador amolecera e queria libertar Ning Xiaoxiao, mas tinha vergonha de admitir. Por isso, deixava Sanfu bancar o benfeitor.

Sanfu compreendeu e respondeu sorridente: — Fique tranquilo, Majestade~ Sei exatamente o que fazer!

Nem o próprio Lu Linyuan sabia por que era tão tolerante com Ning Xiaoxiao.

Depois de pensar bastante, só encontrou uma justificativa que o convencesse:

Se ela passar a noite inteira naquela latrina e ficar impregnada daquele cheiro, quem vai acabar enjoado sou eu!

Quando Sanfu a “resgatou” da latrina, Ning Xiaoxiao quase se ajoelhou para bater a testa no chão em agradecimento.

Embora a latrina do Palácio Chaoyang fosse a mais limpa de todas, nem por isso deixava de ser uma latrina.

Era verão. Com a porta fechada durante tanto tempo, era inevitável sentir alguns odores esquisitos.

E, quando anoiteceu, moscas-varejeiras de cabeça verde vieram de todos os lados, entrando e voando desordenadamente. Ning Xiaoxiao quase perdeu a alma de tanto medo.

No caminho de volta aos próprios aposentos, ela amaldiçoou mentalmente Lu Linyuan e dezoito gerações de seus antepassados.

【Bip, bip, bip~ Anfitriã, anfitriã! Você recebeu uma nova missão~】

【Dançar a Dança dos Quatro Pequenos Cisnes com o tirano~】

【Se cumprir a missão, o índice de desvio da trama aumentará em 2%. Se falhar, perderá 50% de seus pontos de vida~ Conclua o quanto antes!】

As palavras de Xiao Qi foram a gota d'água.

Naquele momento, Ning Xiaoxiao teve vontade de pausar o tempo, correr até o Palácio Chaoyang e estrangular Lu Linyuan!

Justo agora Xiao Qi queria que ela dançasse com ele? E balé, ainda por cima?!

【O que uma missão dessas tem a ver com desviar a trama? Estou começando a achar que você está brincando comigo!】

Xiao Qi respondeu, desolado: 【Anfitriã! Eu também me mato de trabalhar no esquema 996, sabia? Você acha que eu não preferia jogar Honor of Kings ou comer um franguinho gostoso? Com tanta coisa divertida para fazer, por que eu ficaria trabalhando até tarde só para brincar com você?】

Ning Xiaoxiao: 【......】

Xiao Qi: 【Se quiser voltar para casa logo, é melhor obedecer e cumprir as missões direitinho.】

Se tivesse sucesso, o índice de desvio da trama aumentaria em 2%. Se falhasse, perderia metade dos pontos de vida.

Depois de se acalmar, Ning Xiaoxiao decidiu encarar a realidade.

Ela faria aquilo!

Mas havia um problema: como diabos concluir aquela missão?

Ela detestava o tirano, e ele a detestava igualmente.

Dançar juntos? Bastava encostar nele para correr o risco de perder a vida...

Xiao Qi estava mais esperto agora, então ela tampouco podia se aproveitar do tempo pausado para ficar passando a mão no imperador.

Enquanto caminhava, pensava:

【Balé não é tão difícil assim... O essencial dessa dança é ficar na ponta dos pés e dar uns pulinhos. Posso pausar o tempo, colocar o tirano numa pose e depois voltar a reproduzir a trama. Aí seguro a mão dele e pulamos uma vez. Pronto.】

【Mas não pode haver ninguém perto. O tirano se preocupa demais com a própria imagem. Se estivermos sozinhos, depois de arrumá-lo na pose, posso fingir que perdi o equilíbrio e vou cair, e então pegar na mão dele.】

【Mesmo que fique furioso, no máximo vai me mandar limpar penicos outra vez. Pelo menos saio viva.】

Sua prioridade agora era encontrar uma oportunidade de ficar a sós com o imperador o mais rápido possível.

Assim, concluiria a missão reduzindo ao mínimo os riscos para si mesma.

*

Na manhã seguinte, as dores no corpo de Gu Sijin haviam diminuído bastante.

Cailian lhe mostrou vários unguentos: — Senhorita, o imperador mandou entregar tudo isso para a senhora. São remédios da melhor qualidade. Dá para ver que ele se preocupa com a senhorita.

Preocupava-se com ela?

Provavelmente estava mais preocupado em saber se ela conseguia erguer as pernas na altura correta...

Tendo recebido presentes de Lu Linyuan, Gu Sijin achou que deveria retribuir de alguma forma. Preparou pessoalmente uma sopa doce e pediu a Cailian que a levasse.

Ning Xiaoxiao ouviu aquilo e se alegrou:

Levar uma sopa doce ao tirano no Palácio Chaoyang?

Não seria uma oportunidade perfeita de ficarem sozinhos?!

Então se ofereceu para o serviço:

— Minha senhora, deixe que eu leve. A perna de Cailian ainda não sarou. Ela anda mancando e não seria conveniente.

Tomou a caixa de alimentos das mãos de Cailian e partiu para o Palácio Chaoyang.

Cailian resmungou baixinho para Gu Sijin: — Senhorita, ela vive correndo para perto do imperador! Pega para si todas as tarefas que dão prestígio!

Gu Sijin franziu a testa: — Xiaoxiao se ofereceu para ajudá-la porque você está com dificuldade de andar. Como pode falar assim dela?

— Mas é verdade! Ela aparece diante do imperador mais vezes que a própria senhorita! É bom tomar cuidado. Podemos nos proteger de estranhos, mas é difícil nos defender de um ladrão dentro de casa. Vai saber se ela não está nutrindo alguma intenção imprópria em relação ao imperador!

Gu Sijin não quis ouvir mais e fez sinal para que se calasse:

— Nunca mais diga uma coisa dessas. Você não consegue enxergar a menor bondade nas atitudes dos outros. Quando morávamos na residência da família, ao menos sabia se comportar. Como foi ficar tão caprichosa depois que entramos no palácio?

Cailian fez beicinho. Não respondeu, mas a insatisfação estava estampada em seu rosto.

---

## Notas editoriais

- 四小天鵝舞: Dança dos Quatro Pequenos Cisnes, referência ao balé O Lago dos Cisnes; não é um balé genérico.
- 996: jornada de trabalho chinesa das 9h às 21h, seis dias por semana. Honor of Kings é citado diretamente no original.
- 完犢子10086 é exclamação cômica com número associado a serviço telefônico chinês; adaptado a “Ferrou! Ferrou bonito!”, com perda da referência numérica.

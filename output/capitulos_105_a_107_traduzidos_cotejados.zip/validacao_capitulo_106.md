# Validação do capítulo 106

- **Fonte primária:** `novel_capitulos_61_a_120(20261103-205857).docx` (chinês tradicional).
- **Limites no DOCX:** parágrafos 3332–3407 (índices iniciados em zero); capítulo seguinte em 3408.
- **Unidades não vazias (incluindo título):** 73.
- **Linhas de cotejo:** 73.
- **Índices ausentes:** 0; **traduções vazias:** 0.
- **Critério de alinhamento:** uma linha por parágrafo não vazio da fonte; a tradução literária utiliza espaçamento entre parágrafos.

## Revisão e decisões editoriais

A gravidez é apresentada como confirmada pelos personagens, mas sua origem e natureza permanecem incertas; o desejo é hipótese de Lu Linyuan. Os pensamentos com 【】 foram mantidos distintos das falas. Os títulos guannüzi e Daying foram preservados como categorias hierárquicas.

## Limitações

A equivalência estrutural foi verificada por contagem e inspeção dos limites; a tradução foi revisada durante a redação e não passou por uma segunda auditoria linguística independente, linha a linha. A contagem não comprova, isoladamente, ausência de erros semânticos internos.

# Capítulo 106 — Lu Linyuan, pai por vocação

Naquele instante, uma coleção de queixos despencou no chão do Palácio Fengluan.

Todos, inclusive a imperatriz-viúva, ficaram tão chocados que perderam a fala.

Lu Linyuan sabia perfeitamente quais seriam as consequências de sua declaração, mas não tinha outra escolha.

Para proteger Ning Xiaoxiao, precisava primeiro acalmar a imperatriz-viúva. E o jeito mais simples e direto era reconhecer que a criança no ventre dela era seu neto de sangue.

Desde que ele subira ao trono, a imperatriz-viúva sonhava em segurar um neto nos braços.

Ele conhecia bem o temperamento da mãe: quem quer que lhe desse um neto seria recebida com alegria.

Além disso, havia noventa e nove por cento de chance de que aquela gravidez estivesse relacionada ao desejo que ele fizera.

O problema era que nem ele entendia como funcionava o mecanismo daqueles desejos.

Por exemplo, quando ele próprio “engravidara”, a criança simplesmente desaparecera depois de uma ida ao banheiro.

Talvez, por não possuir os órgãos necessários, tivesse sido tão fácil resolver o problema?

Mas Ning Xiaoxiao era uma mulher, perfeitamente saudável e com tudo funcionando. A criança concedida pelo desejo dela seria apenas algo que sairia numa ida ao banheiro ou um ser humano de verdade?

E, se fosse uma pessoa, já que ele fizera o desejo, não seria natural que tivessem pelo menos algum parentesco de sangue?

Ai... Que constrangedor!

Nem sequer tive minha primeira experiência com uma mulher e já virei pai, droga!

Enquanto uma tempestade de pensamentos passava pela cabeça dele, a mente de Ning Xiaoxiao estava igualmente agitada.

A declaração de Lu Linyuan, reivindicando a paternidade, a deixara completamente em choque.

【Não pode ser, não pode ser!】

【Como assim, o filho é dele?】

【Na noite do aniversário dele... será que aquele desgraçado realmente fez aquilo comigo?】

【Socorro!!!】

【Eu fui de boa vontade levar um presente de aniversário! Não fui me oferecer como presente, caramba!】

【Esse imperador miserável arruinou minha honra! Vou matá-lo!!】

Lu Linyuan virou o rosto devagar e lançou-lhe um olhar de lado.

【Do que você está latindo aí?】

【De onde tirou essa confiança de que eu iria para a cama com você?】

【Se eu não tivesse sacrificado minha própria reputação para salvá-la, a imperatriz-viúva já teria mandado cortar sua cabeça e usá-la de bola!】

Depois de um longo silêncio, a imperatriz-viúva foi a primeira a desfazer o impasse.

— Médico imperial Li, examine-a novamente e veja se a gravidez está transcorrendo bem.

O médico Li obedeceu e, pouco depois, respondeu: — Imperatriz-viúva, o pulso é forte e regular. Não há sinal de problema.

Assim que o ouviu, a imperatriz-viúva deu uma demonstração espetacular da arte de mudar de cara num piscar de olhos.

O rosto antes fechado abriu-se num sorriso cheio de rugas. Ela mesma tomou Ning Xiaoxiao pelo braço, levou-a para sentar no lugar reservado à Consorte Yun e ordenou: — Rápido, tragam para a nossa Xiao'er uma almofada macia de penas de ganso! Ela precisa ficar confortável!

Consorte Yun: ??? Então quer que eu vá embora?

A Atendente Xiao não suportava ver uma mera criada prestes a ascender socialmente. Interveio: — Imperatriz-viúva, mesmo que Sua Majestade tenha se deitado com Ning Xiaoxiao, isso não prova que a criança seja dele.

*Pá!*

Antes que terminasse, Lu Linyuan virou-se e lhe acertou uma bofetada.

— Insolente! O que pretende insinuar? Que Xiaoxiao não tem decência ou que alguém me pôs chifres?

A Atendente Xiao ajoelhou-se aterrorizada e bateu a cabeça no chão: — Majestade, perdoe-me! Esta concubina... falei sem pensar...

A imperatriz, a Consorte Yun, a Consorte Li e a Concubina Shen estavam no harém havia muito tempo; todas se tornaram consortes depois que Lu Linyuan ascendeu ao trono.

Em mais de três anos como suas esposas e concubinas, conheceram seu temperamento explosivo, mas nunca o tinham visto agredir uma mulher.

Hoje, porém, bastara à Atendente Xiao expressar uma desconfiança para receber uma bofetada que lhe fizera sangrar o canto da boca.

Isso mostrava o lugar que Ning Xiaoxiao ocupava no coração do imperador. Talvez fosse tão importante quanto Gu Sijin.

Ninguém ousou insistir nas suspeitas. Restou-lhes oferecer parabéns falsamente animados.

A imperatriz, contudo, era uma jogadora de primeira. Depois de dispensar a Ning Xiaoxiao mil cuidados, observou pelo canto dos olhos que Gu Sijin continuava atordoada. Então comentou, como se conversasse despreocupadamente:

— Você tem muita sorte, mas deve agradecer também à sua senhora. Imagino que, por achar você tão bonita, ela a tenha recomendado ao imperador. Recebeu o favor imperial e, para completar, engravidou antes mesmo da Atendente Gu! Agora que carrega um descendente imperial, não podemos permitir que continue sendo apenas uma criada sem título, não é?

Ela fez uma reverência à imperatriz-viúva e a Lu Linyuan, demonstrando ostensiva felicidade: — Parabéns, Majestade! Parabéns, imperatriz-viúva! É uma alegria inédita para este harém. Pelas regras ancestrais, uma criada não pode saltar posições ao receber um título: deve começar como *guannüzi*, mulher de serviço reconhecida pela corte. Mas Ning está grávida. Ousarei pedir uma exceção: em vez de obrigá-la a começar desse posto, por que não conceder-lhe diretamente o título de *Daying*, uma Atendente de categoria superior?

A imperatriz escondia uma lâmina atrás daquele sorriso. Queria semear discórdia entre Gu Sijin e Ning Xiaoxiao sem que ninguém percebesse.

Era evidente que Gu Sijin nada sabia do ocorrido.

Se soubesse, teria revelado a verdade quando o escândalo cresceu e decidiram examinar Ning Xiaoxiao.

A imperatriz concluiu, portanto, que Ning Xiaoxiao subira às escondidas à cama do imperador, traindo sua senhora. Em que isso diferia da ingratidão de Cailian, que abandonara e traíra a própria patroa?

Quanto à ideia de se tornar uma consorte, Ning Xiaoxiao rejeitava-a com todas as forças.

Se entrasse para o harém, deixaria de ser companheira de equipe de Gu Sijin e passaria a ser sua adversária.

E Gu Sijin se tornaria uma chefona terrível mais adiante! Além disso, precisava sobreviver até o final da história para que Ning Xiaoxiao pudesse retornar ao próprio mundo.

Se as duas tivessem de lutar até a morte, a trama não ficaria completamente sem saída?

Se Ning Xiaoxiao vencesse, a protagonista original sairia de cena e ela jamais poderia voltar para casa.

Se perdesse, seria ela quem sairia de cena: fim de jogo, até a próxima vida.

De um jeito ou de outro, o resultado era a morte. Não podia aceitar aquele título de maneira nenhuma.

Então disse: — Imperatriz, o que aconteceu entre mim e Sua Majestade foi consequência de uma bebedeira. O coração do imperador nunca pertenceu a esta serva. Até quando esteve comigo, ele só chamava pelo nome de minha senhora. Tudo o que desejo é continuar servindo à Atendente Gu, não me tornar uma consorte. Peço que Vossa Majestade não me coloque nessa situação.

Lu Linyuan também não planejava fazer de Ning Xiaoxiao uma consorte. Afinal, se entrasse para o harém, ela passaria a tratá-lo com ainda mais insolência e falta de cerimônia.

Além disso, uma consorte seria inevitavelmente arrastada para o lamaçal das intrigas palacianas. Aquela boba seria capaz de enfrentar quem?

Mas, quando viu que Ning Xiaoxiao se apressara a recusar antes mesmo dele, ficou irritado.

【Desde quando eu chamei pelo nome de Gu Sijin?】

【O quê? Ser minha consorte seria um sacrifício tão grande assim?】

【Sempre sou eu quem rejeita os outros! Ninguém ousa me rejeitar!】

Como uma criança birrenta, quanto mais ela tentava escapar, mais ele queria mantê-la por perto.

Antes que a imperatriz ou a imperatriz-viúva respondessem, Lu Linyuan aproximou-se, tomou-lhe a mão e disse com uma ternura transbordante:

— Naquela noite, eu estava fingindo estar bêbado.

Ning Xiaoxiao o encarou como quem olha para alguém que perdeu o juízo.

【Não, espera... Mesmo que você tenha feito aquilo comigo naquela noite, como pode ter tanta certeza de que a criança é sua?】

【E se for de outro rapaz bonito por aí?】

【Ora, ora. Essa sua vocação para assumir a paternidade está mesmo consolidada...】

O olhar de Lu Linyuan mudou; seus olhos ficaram perigosamente frios.

【O quê? Outro rapaz? Que rapaz? Traga-o aqui! Eu mando castrá-lo e faço dele um eunuco para servi-la!】

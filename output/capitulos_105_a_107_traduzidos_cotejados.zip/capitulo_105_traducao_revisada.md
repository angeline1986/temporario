# Capítulo 105 — O filho que ela carrega é meu!

Lu Linyuan não acreditava que Ning Xiaoxiao tivesse engravidado assim, de repente.

Afinal, dois dias antes ela ainda estava menstruada. Mesmo que tivesse se envolvido com outro homem logo em seguida, seria impossível apresentar um pulso de gravidez tão depressa.

Portanto, talvez aquilo realmente tivesse alguma coisa a ver com ele.

Naquela noite, diante de tantos pregos, repetira incontáveis vezes o “desejo” de que Ning Xiaoxiao engravidasse. Fizera aquilo por diversão, mas quem garantia que, no meio de todos eles, não houvesse um prego divino capaz de realizar desejos?

Antes ele jamais teria acreditado numa coisa tão absurda. Só que, depois de ter passado pessoalmente por uma gravidez, era inevitável sentir certa identificação.

E agora a gravidez dela fora descoberta bem diante das consortes e da imperatriz-viúva.

A imperatriz-viúva detestava, acima de tudo, escândalos no harém. Se ele não aparecesse imediatamente, bastaria uma ordem dela para que Ning Xiaoxiao perdesse a vida.

— Preparem a comitiva para o Palácio Fengluan!

* * *

A oficial encarregada de examinar Ning Xiaoxiao recebeu a ordem e correu para o Palácio Fengluan.

Nesse meio-tempo, aproveitando a confusão, a Atendente Xiao instruiu discretamente sua criada Shuang'er a ir ao portão “receber” a oficial.

Ao avistar a oficial se aproximando, Shuang'er foi ao seu encontro com um sorriso. — A senhora é a tia Chun?

— Sou, sim. E você é...?

— Sou Shuang'er, criada da Atendente Xiao. Hoje aconteceu uma indecência no palácio, e acabaram perturbando o descanso da senhora sem necessidade. Aceite esta pequena lembrança.

Ela enfiou uma nota de cinquenta taéis de prata na mão da tia Chun e sussurrou junto ao ouvido dela: — Quem causou o problema lá dentro é a criada-chefe da Atendente Gu. Nenhuma das consortes gosta dela, muito menos a imperatriz-viúva.

— Quando examinar essa criada, não importa o que encontre: declare que ela já não é virgem. Se fizer isso, minha senhora, que serve à Consorte Yun, ficará agradecida. E a Consorte Yun tem o apoio da imperatriz. Com gente assim do seu lado, ainda vai faltar oportunidade para subir na vida?

A tia Chun olhou em volta, guardou furtivamente o dinheiro no peito e sorriu. — Fique tranquila, minha jovem. Sei exatamente o que fazer.

Depois de entrar e cumprir o ritual de cumprimentar as consortes, ouviu a imperatriz ordenar: — Leve Ning Xiaoxiao ao salão lateral e verifique se ela ainda é uma moça casta.

— Sim, Vossa Majestade.

A tia Chun era corpulenta, de rosto largo e carnudo; tinha uma aparência nada amigável.

Mal entraram no salão lateral, ela berrou: — O que está esperando? Tire a roupa!

Ning Xiaoxiao abaixou as roupas. Sentiu algum constrangimento, como quando precisava fazer um exame médico no hospital, em sua vida anterior.

A tia Chun mandou que se sentasse na cama e agachou-se para examiná-la.

A “flor” tinha uma delicada cor rosada e uma aparência bonita. Apesar de ter visto incontáveis “flores” ao longo da carreira, aquela era uma das mais bem-cuidadas que a oficial já encontrara.

Uma pena que, depois de passar pelas mãos dela, aquela flor viçosa logo seria considerada uma flor arruinada.

Tinha escondido uma agulha de aço dentro da manga. Enquanto fingia examinar Ning Xiaoxiao, aproveitou uma distração para enfiar a agulha nela de propósito.

Uma dor aguda e profunda atravessou o baixo-ventre de Ning Xiaoxiao, fazendo seus olhos se encherem de lágrimas na mesma hora.

Antes que ela pudesse reagir, a tia Chun escondeu a agulha de volta na manga e se virou para sair. — Já terminei. Vou apresentar o resultado à imperatriz.

Mas Ning Xiaoxiao não era idiota. Percebeu imediatamente que havia algo errado.

Suportando a dor intensa, avançou de uma vez, agarrou a mulher pelos cabelos e a arrastou até o chão.

Nesse instante, a agulha de aço escondida na manga da oficial caiu.

Ning Xiaoxiao a recolheu e desferiu uma enxurrada de espetadas. Em menos de um minuto, abriu dezenas, talvez uma centena de perfurações no corpo dela.

A tia Chun gritava de dor, fora de si: — Aaaah! Sua louca! Pare! Pare com isso!

Ning Xiaoxiao montou sobre ela e começou a espetar-lhe o rosto sem piedade.

— Você é a ama Rong, lá do lago Daming, ou algum torturador das prisões imperiais? [Nota editorial: referência à cruel ama Rong, da série chinesa *A Princesa Pearl*.]

— Gosta tanto de espetar os outros assim? Por acaso sua mãe era um ouriço híbrido criado nas pradarias das Filipinas?

O sangramento daquela “flor” mostrava que, por um instante de descuido, Ning Xiaoxiao caíra em outra armadilha. Mesmo que fosse virgem antes, a ação da tia Chun acabara de destruir a prova que pretendiam exigir dela.

Ela controlou o tempo. Depois de deixar a oficial ensanguentada da cabeça aos pés, apertou o botão Retroceder.

Três minutos antes, a tia Chun estava prestes a atacá-la.

Ning Xiaoxiao agarrou-lhe a mão, fitou a agulha reluzente e perguntou: — Quem lhe deu coragem para tentar me prejudicar tão descaradamente?

A tia Chun entrou em pânico e se debateu, tentando largar a agulha.

Só que toda aquela gordura não lhe dava força suficiente para vencer a pegada de Ning Xiaoxiao.

Ning Xiaoxiao torceu-lhe o pulso com força. A mulher abriu a mão de dor, deixando cair a agulha.

Ning Xiaoxiao a apanhou e, sem a menor hesitação, cravou-a na mão da tia Chun.

A ponta entrou pelo dorso, atravessou a mão e saiu pela palma, perfurando-a de lado a lado.

A oficial não parava de gritar. Ning Xiaoxiao ignorou seus protestos e, entre socos e pontapés, arrastou-a de volta ao salão principal.

Ao verem que a oficial enviada para examinar Ning Xiaoxiao voltava depois de levar uma surra dela, todas as consortes ficaram perplexas.

— Ning Xiaoxiao, o que você está fazendo? — perguntou a imperatriz.

— Respondendo à imperatriz: não sei de qual senhora essa oficial recebeu benefícios, mas ela escondeu uma agulha de aço na manga para destruir minha castidade durante o exame e me deixar sem nenhuma maneira de provar minha inocência!

A expressão da Atendente Xiao mudou imediatamente. Sentindo-se culpada, ela nem ousava encarar Ning Xiaoxiao.

A imperatriz olhou para a agulha que atravessava a mão da tia Chun e perguntou severamente: — O que significa isso?

A situação virara um caos. Mal tinham começado a esclarecer a suposta gravidez e já surgia outra acusação: uma oficial tentara prejudicar Ning Xiaoxiao por interesse próprio.

Foi então que a voz aguda de um eunuco anunciou da entrada:

— Sua Majestade, o imperador, chegou!

Exceto a imperatriz-viúva, a imperatriz, as consortes e os criados curvaram-se respeitosamente na direção da porta. — Recebemos Sua Majestade Imperial.

Mas nenhuma daquelas beldades atraiu a atenção de Lu Linyuan.

Ele encontrou Ning Xiaoxiao de imediato no meio da multidão e caminhou diretamente até ela, sem hesitar.

Antes mesmo que pudesse reagir, ele entrelaçou os dedos aos dela e a ergueu do chão frio.

Ele não havia mandado as consortes se levantarem. Até a imperatriz continuava curvada, enquanto Ning Xiaoxiao já estava de pé.

Então perguntou-lhe, numa voz surpreendentemente suave e profunda: — Você se machucou?

Ning Xiaoxiao ficou atônita. Sem conseguir responder, limitou-se a balançar a cabeça mecanicamente.

A imperatriz-viúva não entendeu o gesto. Irritada, protestou: — Todas as consortes ainda estão curvadas, e você ignora isso para perguntar primeiro se uma criada está bem? Sabe do que ela é acusada? De se envolver às escondidas com um guarda e engravidar dele! Pela lei, deve ser decapitada!

— Quero ver quem se atreve!

O grito furioso de Lu Linyuan fez a imperatriz-viúva estremecer.

Ele se virou bruscamente e a encarou com um olhar cortante. Cada palavra saiu firme e inequívoca:

— O filho que ela carrega é meu!

# Validação do capítulo 105

- **Fonte primária:** `novel_capitulos_61_a_120(20261103-205857).docx` (chinês tradicional).
- **Limites no DOCX:** parágrafos 3262–3331 (índices iniciados em zero); capítulo seguinte em 3332.
- **Unidades não vazias (incluindo título):** 67.
- **Linhas de cotejo:** 67.
- **Índices ausentes:** 0; **traduções vazias:** 0.
- **Critério de alinhamento:** uma linha por parágrafo não vazio da fonte; a tradução literária utiliza espaçamento entre parágrafos.

## Revisão e decisões editoriais

O original contém provável troca de pronome (她) para o imperador ao entrar no palácio; contexto indica Lu Linyuan. A primeira cena de ferimento é retrocedida e substituída por sua interceptação. A referência à ama Rong foi explicitada em nota editorial. A expressão C子 é uma grafia parcialmente censurada relacionada à virgindade.

## Limitações

A equivalência estrutural foi verificada por contagem e inspeção dos limites; a tradução foi revisada durante a redação e não passou por uma segunda auditoria linguística independente, linha a linha. A contagem não comprova, isoladamente, ausência de erros semânticos internos.

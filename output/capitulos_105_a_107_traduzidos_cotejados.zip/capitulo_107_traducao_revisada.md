# Capítulo 107 — Ousou tocar em Xiaoxiao? Receba a ordem de se matar!

Lu Linyuan se acalmou e ficou um bom tempo ouvindo os pensamentos de Ning Xiaoxiao.

Quando enfim confirmou que aquele “rapaz bonito” não existia e era apenas uma invenção com que ela o provocava, soltou um suspiro involuntário de alívio. O coração, que estivera suspenso, voltou ao lugar.

Lu Linyuan queria dar-lhe um título. A imperatriz também queria, e a imperatriz-viúva não era diferente.

Ning Xiaoxiao sacudia a cabeça como um chocalho e repetia sem parar que não, não e não.

A Consorte Yun, irritada com tanta resistência, comentou: — Pare de fazer cerimônia! O imperador a trata assim, e você não fica nem um pouco comovida?

Comovida? Ela não ousava nem se mexer!

Desde o início, os olhos de Gu Sijin permaneciam fixos nela.

Não se deixem enganar por aquela mulher, agora tão pura quanto uma flor de lótus branca. Mais adiante, as coisas que ela faria seriam simplesmente monstruosas.

A Consorte Yun teria mãos e pés cortados e seria conservada num jarro de vinho, transformada num “porco humano”.

A Consorte Li seria esfolada e teria os tendões arrancados. Gu Sijin ainda faria deles um cinto para presentear o próprio pai.

A Consorte Nobre teria a língua arrancada e os olhos vazados, sendo enviada à frente de batalha para servir de escrava sexual aos soldados.

...

E esses eram apenas alguns exemplos de uma lista interminável.

Até a imperatriz acabaria empurrada do alto da torre sudoeste. Cairia de cabeça no chão e se espatifaria como uma melancia madura, num espalhafatoso *bum, tchá, tchá*.

Ao lembrar as atrocidades que Gu Sijin cometeria na reta final da obra original, Ning Xiaoxiao sentiu um arrepio.

Se seu destino fosse mesmo morrer, preferia ter a cabeça cortada agora pela guilhotina imperial a ser torturada e morta mais tarde pela protagonista, protegida por sua aura de heroína, usando métodos tão desumanos...

Gu Sijin, que até então permanecera calada, falou de repente: — Xiaoxiao, está preocupada que eu fique triste?

Deu dois passos à frente, parou diante de Ning Xiaoxiao, tomou-lhe as mãos e sorriu, balançando a cabeça: — Se pensa isso de mim, está desprezando o afeto que construímos ao longo de tanto tempo. Embora sejamos senhora e criada, sempre fomos mais próximas do que irmãs.

— Minha senhora, eu...

— Não precisa dizer nada. Só me responda: no fundo do coração, você me considera sua irmã mais velha?

Ning Xiaoxiao apertou os lábios e assentiu. Gu Sijin continuou: — Então acha que uma irmã mais velha quer o bem da mais nova ou deseja que ela sofra?

— Mas, minha senhora...

— Nada de “mas”. Você carrega um descendente do imperador. Estou mais feliz do que qualquer outra pessoa! Antes, como criada, você tinha de respeitar a diferença de posição dentro e fora do palácio. Quando se tornar uma consorte, poderemos nos chamar de irmãs abertamente. O que há de ruim nisso?

Dito isso, Gu Sijin fez um pedido a Lu Linyuan: — Majestade, o salão lateral oeste do Palácio Zhongcui está desocupado. Gostaria de pedir permissão para que Xiaoxiao se instalasse lá e me fizesse companhia.

Lu Linyuan assentiu. A imperatriz sorriu e disse: — Será maravilhoso vê-las morando sob o mesmo teto, convivendo dia após dia e apoiando uma à outra.

A imperatriz-viúva concluiu: — Muito bem. No fim, o que aconteceu hoje não passou de uma confusão. A Atendente Ning está grávida e precisa voltar ao palácio para descansar. Mandarei o Departamento da Casa Imperial preparar o salão lateral oeste. Tudo deve ser da melhor qualidade. Nada de economizar com ela ou com a criança.

Mas Gu Sijin interveio: — Imperatriz-viúva, ainda não podemos dispensar todos. Há um assunto sério que falta resolver.

Ela lançou um olhar à tia Chun, ainda ajoelhada no chão, tremendo: — Se essa velha serva tivesse conseguido enfiar a agulha de aço nas partes íntimas de Xiaoxiao durante o exame, poderia ter prejudicado o feto imperial. Se Xiaoxiao não tivesse reagido a tempo, a alegria de hoje talvez tivesse terminado em tragédia.

Sua voz se elevou bruscamente, tornando-se severa: — Fale! Quem mandou você cometer uma maldade tão vil e repugnante?

Era a primeira vez que Ning Xiaoxiao via Gu Sijin mostrar publicamente aquele lado implacável.

Quando ela mesma era acusada injustamente, nem conseguia se proteger; só sabia chorar.

Mas, diante de alguém tentando ferir Ning Xiaoxiao, encontrava coragem para exigir justiça por ela.

Como é que alguém não ficaria balançado diante de uma protagonista assim?

A tia Chun começou negando tudo, insistindo em que era inocente e tinha sido injustiçada.

Ning Xiaoxiao tinha um temperamento explosivo e não suportava ver uma pessoa desprezível fingir pureza e inocência.

Pisou na mão da tia Chun, atravessada pela agulha de aço, e ameaçou com voz feroz: — Está dizendo que eu a acusei injustamente? Todos no palácio sabem o que aconteceu com Cailian! Se não contar a verdade, seu destino será ainda mais horrível que o dela!

— Aaaah! Minha senhora, tenha piedade! Tenha piedade! Foi... foi a Atendente Xiao! Ela mandou a criada me dar dinheiro para fazer isso!

A Atendente Xiao, tão agressiva na aparência e tão covarde por dentro, foi identificada de repente e nem teve coragem de se defender. Ajoelhou-se e bateu a cabeça no chão: — Imperador, perdoe-me! Imperatriz, perdoe-me! Esta concubina... esta concubina perdeu a razão por um instante...

A imperatriz franziu a testa e suspirou, com ar de quem lamentava a insensatez alheia: — Um instante de insensatez quase causou uma desgraça!

— Sim, sim! A culpa é toda minha! Vou me prostrar diante da Atendente Ning e implorar perdão!

Depois de testemunhar o quanto Lu Linyuan favorecia Ning Xiaoxiao, ela se acovardou imediatamente e começou a bater a cabeça no chão diante dela, submissa e desesperada.

Infelizmente, não era a antiga Consorte Nobre e não possuía uma família poderosa para protegê-la.

Lu Linyuan deu a ordem sem a menor hesitação: — Levem essa oficial e a criada da Atendente Xiao. Que sejam executadas pelo suplício dos mil cortes. Quanto a ela...

Ele lançou um olhar à Atendente Xiao, que tremia toda, e concluiu num tom despreocupado: — Levem-na. Concedo-lhe a morte pelas próprias mãos.

Ao ouvir aquilo, a Atendente Xiao agarrou a barra das roupas de Lu Linyuan como uma desesperada e chorou aos berros: — Majestade, tenha piedade! Esta concubina perdeu a razão por um instante! Foi só um instante, Majestade!

Com indiferença, Lu Linyuan a afastou com um chute e saiu acompanhado de Ning Xiaoxiao e Gu Sijin.

Xiao Yinzi e seus homens taparam a boca da Atendente Xiao e a arrastaram dali.

A imperatriz-viúva, feliz por ter ganhado um neto, anunciou sorridente que voltaria ao palácio para queimar incenso diante de Buda e cumprir uma promessa.

As consortes restantes demoraram a se recompor. Quando finalmente voltaram a si, começaram a comentar umas com as outras.

A Consorte Yun resmungou, ressentida: — Gu Sijin pensa rápido, não é? Agora só aquelas duas recebem os favores do imperador. Morando juntas, não fica ainda mais fácil se aliarem para disputar a atenção dele? E quem sai ganhando é a Consorte Duan. Desde que voltou da visita à família, vê o imperador passar os dias no Palácio Zhongcui. De vez em quando, consegue aparecer diante dele. Quem sabe, com o tempo, não acaba recebendo algum favor também?

A Consorte Li sorriu com sarcasmo: — Coitada da Gu Sijin. As criadas de seu palácio são todas tão talentosas! Uma serva nascida na casa tramava matá-la; a criada-chefe passava dia e noite sonhando em subir à cama do imperador. Com essas “mentes brilhantes” ao meu redor, eu morreria de raiva! Mas ela aguenta tudo, engole a humilhação e finge que está bem. Ninguém vai me convencer de que, depois do que aconteceu, ela estava sinceramente feliz por Ning!

A Concubina Shen acrescentou: — É apenas uma criada que conheceu depois de entrar no palácio. Que laço profundo poderiam ter? Uma serva que a atendia havia três ou quatro meses virou senhora de verdade e ainda engravidou. Humpf! Se querem minha opinião, Gu Sijin a convidou para morar com ela justamente porque, sob o mesmo teto, será mais fácil atingir aquela barriga.

Os comentários ficavam cada vez mais maldosos, até que a imperatriz os interrompeu com uma reprimenda:

— Calem-se! Ainda estou aqui, e vocês se atrevem a falar assim? Desde quando os assuntos dos herdeiros imperiais são motivo de brincadeira?

Ao verem a imperatriz irritada, todas fizeram uma reverência e responderam em coro: — Que Vossa Majestade acalme sua ira.

— Vou deixar bem claro: podem sentir quanta inveja quiserem, mas ninguém deve ousar fazer qualquer coisa contra um descendente imperial. Caso contrário, o destino da Atendente Xiao hoje será o de vocês amanhã. Estão dispensadas.

# Validação do capítulo 107

- **Fonte primária:** `novel_capitulos_61_a_120(20261103-205857).docx` (chinês tradicional).
- **Limites no DOCX:** parágrafos 3408–3467 (índices iniciados em zero); capítulo seguinte em 3468.
- **Unidades não vazias (incluindo título):** 57.
- **Linhas de cotejo:** 57.
- **Índices ausentes:** 0; **traduções vazias:** 0.
- **Critério de alinhamento:** uma linha por parágrafo não vazio da fonte; a tradução literária utiliza espaçamento entre parágrafos.

## Revisão e decisões editoriais

As atrocidades atribuídas a Gu Sijin são acontecimentos futuros da obra original lembrados por Ning, não ocorrências já realizadas na linha narrativa presente. As falas sobre intenções de Gu Sijin no final são especulações das consortes. A expressão 不敢動 contém jogo de palavras com “ficar comovida”/“não ousar se mexer”.

## Limitações

A equivalência estrutural foi verificada por contagem e inspeção dos limites; a tradução foi revisada durante a redação e não passou por uma segunda auditoria linguística independente, linha a linha. A contagem não comprova, isoladamente, ausência de erros semânticos internos.

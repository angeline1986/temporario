# Validação — Capítulo 158

- **Fonte primária:** `novel_capitulos_121_a_180(20261103-233558).docx`, chinês tradicional.
- **Limites no DOCX:** parágrafo 2588 (incluso) até 2650 (exclusivo), indexação base zero.
- **Unidades de origem não vazias, incluindo título:** 59.
- **Unidades traduzidas:** 59.
- **Índices ausentes, repetidos ou fora de ordem:** 0.
- **Campos vazios no cotejo:** 0.
- **Cabeçalho CSV:** `indice_docx,original_chines,traducao_portugues`.

## Atenções narrativas e editoriais

A referência recorrente a “21” tem conotação sexual; a ordem de expor a cabeça por dez anos é uma fala do imperador, não uma recomendação. As variantes 任斷離 e 陸弈秋 seguem Ren Duanli e Lu Yiqiu.

## Limitações

Foi realizada a tradução integral com comparação por unidade e teste automático de cobertura estrutural. Isso não constitui uma segunda auditoria linguística independente de cada oração. Referências culturais e passagens ambíguas foram adaptadas quando necessário para preservar o efeito narrativo, sem antecipar informações do capítulo seguinte.

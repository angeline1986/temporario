# Capítulo 158 — Estou começando a perder a vontade de viver...

Na noite anterior, Lu Linyuan se levantara sete ou oito vezes para cobrir Ning Xiaoxiao, que se remexia sem parar enquanto dormia. Mal conseguia passar meia hora sem acordar; não descansara direito a noite inteira.

Pela manhã, tinha olheiras discretas. Ao vê-las, Sanfu não conseguiu conter o sorriso malicioso. — Majestade, pelo visto trabalhou bastante esta noite~ No almoço, vou pedir à cozinha imperial que acrescente uma sopa de pênis de boi, para restaurar suas forças~

Restaurar mais ainda?

Seu “21” já passava mais de meia hora erguido logo ao acordar. Se ainda tomasse fortificantes, acabaria sangrando pelo nariz!

Assim, enquanto entrava no palanquim, dispensou Sanfu: — Não preciso disso. Guarde para você.

Sanfu: — Mas, Majestade... esse negócio não teria utilidade nenhuma para este servo...

Lu Linyuan: — Então não coma. Pegue e use você mesmo.

Sanfu: — ...

Desde que seu senhor começara a “se envolver” com Ning Xiaoxiao, as palavras que saíam de sua boca estavam cada vez mais... coloridas.

*

Ainda antes do amanhecer, no período da quinta vigília, os ministros se reuniram dentro e fora do Palácio Chaoyang. Somente depois que Lu Linyuan se acomodou no lugar de honra Sanfu anunciou solenemente: — Início da audiência imperial~~

Após os ministros se ajoelharem em saudação, o ministro do Tribunal dos Assuntos dos Povos Dependentes foi o primeiro a erguer a tabuleta cerimonial e apresentar seu relatório:

— Informo a Vossa Majestade que o soberano do Reino de Zhuyin faleceu ontem. A princesa Qingyang não teve descendentes e, segundo a lei, pode retornar ao palácio, receber uma residência principesca e viver sob os cuidados da corte. Peço a decisão de Vossa Majestade.

Zhuyin era um reino estrangeiro a sudeste de Qi e, entre todas as potências vizinhas, aquele que mais preocupava a dinastia.

A princesa Qingyang era a filha legítima mais velha do imperador anterior e irmã mais velha de Lu Linyuan.

Embora tivessem mães diferentes, os dois sempre foram muito próximos desde pequenos.

Quando o falecido imperador prometera Qingyang em casamento diplomático ao Reino de Zhuyin, Lu Linyuan chegara a discutir com o pai por causa disso.

Na ocasião, o pai o repreendera por sua imaturidade, dizendo que, se um conflito podia ser resolvido por meio de uma mulher, não havia necessidade de recorrer às armas.

Uma mulher nascida na família imperial podia ter a sorte de viver em tempos pacíficos, escolher um marido e desfrutar de um casamento feliz, invejado por todos.

Mas, se nascesse em tempos de guerra, casamentos diplomáticos eram comuns. Mesmo uma princesa criada entre honras e luxos podia acabar como consorte ou concubina em outro reino. Era um destino lamentável.

Ao ouvir a notícia, Lu Linyuan decretou imediatamente que Ren Duanli conduzisse pessoalmente tropas para escoltar Qingyang de volta a Qi.

Lu Yiqiu começou a protestar que também queria ir, mas Ren Duanli pressionou-lhe a tabuleta de audiência contra os lábios para calá-lo, provocando risos entre os ministros.

Em seguida, um oficial da Guarda Metropolitana apresentou outra petição: — Majestade, um criminoso que ataca mulheres surgiu na capital. Usa máscara, age com extrema crueldade e já cometeu três crimes em apenas dez dias. Todas as mulheres que violentou foram assassinadas para eliminar testemunhas. Como não conseguimos rastreá-lo, peço autorização para fechar temporariamente os portões e revistar as casas até capturá-lo.

A ordem pública em Qi sempre fora boa. Desde a ascensão de Lu Linyuan, a segurança se tornara tão rigorosa que os moradores podiam até dormir com as portas destrancadas.

Agora um único canalha ameaçava estragar tudo. Naturalmente, Lu Linyuan não permitiria que escapasse impune.

— Há testemunhas? Conhecemos alguma característica física do criminoso?

O oficial respondeu: — Os crimes ocorreram à noite e o agressor usava máscara. Existem testemunhas, mas nenhuma viu seu rosto. A única característica confirmada é que ele usa três pequenas mechas de cabelo caídas sobre a testa.

Lu Linyuan: — ???

Mantendo a compostura a duras penas, endireitou instintivamente seu chapéu cerimonial.

O oficial prosseguiu: — Majestade! Esse criminoso é um pervertido de primeira! Enquanto estiver solto, a população não terá paz!

Lu Linyuan: Tenho a impressão de que está me insultando, mas não posso admitir...

Ele pigarreou estrategicamente e ordenou em voz grave: — Isso envolve a segurança do povo e não admite negligência. Quero esse criminoso capturado em três dias! Decapitem-no no Mercado Oriental e exponham sua cabeça à entrada do mercado por dez anos, sem retirá-la! Que todos os malfeitores vejam o destino reservado àqueles que ultrapassarem os limites sob meu governo!

Os ministros louvaram a firmeza de Lu Linyuan, dizendo que suas recompensas e punições eram justas e beneficiavam a população.

Os assuntos da audiência estavam praticamente encerrados quando um censor do Departamento de Flores e Aves, que raramente se pronunciava, subitamente avançou:

— Majestade, o mel de Qi há muito não supre a demanda interna, e somos obrigados a importá-lo por preços elevados. Após quatro anos de trabalho, nosso departamento desenvolveu, por cruzamentos seletivos, uma nova variedade de abelhas. Elas polinizam com grande eficiência, constroem colmeias mais de três vezes maiores que as comuns e produzem mel mais doce e encorpado. São espécimes magníficos, a elite entre as abelhas.

O povo de Qi adorava doces, e o tesouro imperial realmente gastava muito com a importação anual de mel. Seria excelente se a produção nacional atendesse à demanda.

Lu Linyuan elogiou: — O Departamento de Flores e Aves trabalhou arduamente. Se até o próximo verão essa iniciativa der resultados, concederei mil taéis de ouro como recompensa.

Radiante, o censor retirou das roupas um recipiente de cristal translúcido. — Trouxe comigo uma das abelhas criadas para que Vossa Majestade possa admirá-la antecipadamente.

Ele avançou oferecendo o recipiente. Talvez estivesse eufórico pela promessa de recompensa, talvez não: tropeçou no tapete vermelho-escuro bordado com nuvens douradas, e o frasco voou de suas mãos. Caiu no chão com um estalo e se despedaçou.

A abelha lá dentro saiu zumbindo, voando de um lado para outro pelo salão.

Era duas vezes maior que uma abelha comum, quase do tamanho de uma vespa.

Os presentes ficaram apreensivos. A criaturinha poderia simplesmente ter voado para fora, mas, como se quisesse arranjar problemas, resolveu subir diretamente até a cabeça de Lu Linyuan.

Pousou no chapéu imperial sem se mover e ainda esfregou as patinhas como uma mosca.

Sanfu, que estava ao lado de Lu Linyuan, quase morreu de susto ao ver aquilo.

E se aquele bichinho picasse a cabeça do imperador?

Esquecendo-se de qualquer prudência, girou o espanador na mão e anunciou: — Majestade, não se mexa! Vou espantar a abelha!

Lu Linyuan percebeu imediatamente que uma calamidade se aproximava e tentou impedi-lo: — Não faça...

PÁ!

Antes que terminasse a frase, o espanador de Sanfu atingiu seu chapéu cerimonial.

A abelha foi espantada, sem dúvida. Mas o golpe inesperado também atirou o chapéu de Lu Linyuan ao chão.

As três miseráveis mechinhas, achatadas por tanto tempo, ficaram grudadas e espetadas em sua testa como três riscos negros de puro constrangimento. Aquele penteado singular lhe dava um ar de quem havia perdido o cérebro pelo caminho.

Todos os presentes ficaram boquiabertos. Sanfu, o “culpado” pelo desastre, quase teve um ataque cardíaco ali mesmo:

【O que eu faço? O que eu faço? Sou só um eunuquinho inofensivo! E como poderia imaginar que Majestade tinha esse tipo de gosto?!】

【O oficial da Guarda Metropolitana não acabou de dizer que homens com três mechinhas na testa são pervertidos?】

【Ai... por que Majestade está olhando para mim desse jeito???】

【Será que vou morrer??】

【Alguém me salve!】

【Aceito respostas agora mesmo, é urgente...】

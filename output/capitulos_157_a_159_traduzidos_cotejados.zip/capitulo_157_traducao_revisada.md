# Capítulo 157 — Boa noite, minha gatinha preguiçosa

Lu Linyuan ficou completamente sem palavras.

Era como se ela o considerasse um idiota e ainda quisesse obrigá-lo a admitir isso.

Ele soltou a mão de Ning Xiaoxiao e deu-lhe um peteleco na cabeça. — Só porque você é uma tola, acha que eu também sou?

Enquanto falava, desfez o penteado de três mechinhas sobre a testa e prendeu os cabelos novamente.

— Eu jamais iria à audiência da corte com um penteado desses!

— Ning Xiaoxiao, o que pensa que eu sou? Seu brinquedo?

Da boca para fora, Ning negou. Mas, por dentro, pensou:

【Bom... e por que não seria?】

Lembrou-se das Barbies com que brincava na infância: trocava-lhes as roupas, prendia-lhes os cabelos e usava a maquiagem da mãe para criar rostos que julgava lindíssimos, embora ficassem bastante esquisitos. Fazia com as bonecas o que bem entendia.

Foi ao recordar isso que percebeu, de repente, que Lu Linyuan não era uma de suas Barbies.

Pelo menos dentro daquele livro, ele era alguém com personalidade e vontade próprias.

As missões anteriores de Xiao Qi, por mais difíceis e constrangedoras que fossem, diziam respeito apenas a ela e ao tirano.

Dessa vez, porém, cumprir a missão significaria fazê-lo passar vergonha diante de toda a administração imperial, na presença de todos os seus ministros.

A dignidade era importante para qualquer pessoa. Imagine, então, para um imperador.

【Será que estou passando um pouquinho dos limites...?】

【Se ele aparecer assim na corte, a vergonha vai chegar até o topo do Himalaia!】

【Ah... deixa para lá. Melhor desistir dessa missão.】

【Se perder 10% da vitalidade, paciência. Na pior das hipóteses, passo mais três dias e três noites apagada!】

【Ainda tenho muita vitalidade. Desta vez vou poupar a honra do imperador cachorro e não dificultar as coisas para ele!】

Mudando de assunto, apressou-se a pedir desculpas. — Está bem, está bem! Não fique bravo, Majestade. Vou ler os memoriais para o senhor~

Pegou um memorial, sentou-se ao lado de Lu Linyuan e começou a ler com toda a atenção.

A luz vacilante das velas banhava-lhe a pele impecável, tornando-a ainda mais delicada, como porcelana macia.

Os cílios longos se curvavam para baixo, projetando uma fileira de sombras sobre os olhos.

Ela era diferente de todas as outras mulheres do harém.

Sua beleza impressionava à primeira vista, mas se revelava ainda maior quanto mais se olhava. E quanto mais se convivia com ela, mais encantadora parecia.

Aos olhos de Lu Linyuan, naquele momento, ela já ultrapassara qualquer escala: merecia doze pontos em dez.

Tanto que, sempre que a observava de perto, seu coração estremecia sem que pudesse controlar.

Naquela noite, ele mal prestou atenção ao conteúdo dos memoriais lidos por Ning.

Em vez disso, repassava mentalmente os pensamentos que acabara de ouvir dela:

【Então ela faz todas aquelas coisas estranhas comigo porque precisa cumprir algum tipo de missão?】

【Se for assim, até faz sentido. Eu sempre achei que ela fosse uma pervertida por natureza...】

Ning já carregava tantos segredos e poderes incomuns que Lu Linyuan deixara de se espantar com qualquer coisa relacionada a ela.

【E, se não cumprir a missão, fica inconsciente durante três dias e três noites e ainda perde parte da vida?】

【No meu aniversário, quando tentou acertar meu rosto com um bolo e eu virei o jogo contra ela, depois dormiu por muito tempo sem explicação. Será que foi por ter fracassado na missão?】

Podia ser orgulhoso e teimoso, mas sabia distinguir o que realmente importava.

Não queria vê-la adormecida por três dias e três noites, muito menos que perdesse um décimo da própria vida.

Quase um shichen depois, Ning finalmente terminou de ler os memoriais.

Ela soltou um enorme bocejo. Reclinado no assento aquecido, com a cabeça apoiada na mão, Lu Linyuan a observava sem piscar.

— Cansada?

— Aaah... — Espreguiçou-se preguiçosamente e assentiu. — Já vai dar meia-noite. Majestade, não passe tantas noites em claro. Vai acabar morrendo de repente~

Lu Linyuan: — ...

Lá fora, a chuva de granizo parara havia bastante tempo.

Aquela altura, Lu Linyuan já poderia ter retornado ao próprio palácio para dormir. Mas, sob o olhar esperançoso de Ning, soltou calmamente: — Se está com sono, vá dormir. Por que fica me olhando?

— Majestade vai passar a noite aqui?

Lu Linyuan arqueou uma sobrancelha. — E onde mais?

— ...Ah.

Muito prática, Ning foi ao armário, pegou uma colcha nova e a estendeu sobre o assento aquecido. Depois trouxe um travesseiro macio de penas de ganso.

Lu Linyuan franziu a testa, intrigado. — Você vai dormir aí?

— Hã? Não... Preparei para Vossa Majestade...

Lu Linyuan: — ??? Você quer que eu durma nesse assento?

— E onde mais? — retrucou Ning, plenamente convencida de sua razão. — Acabei de sofrer um aborto! Vossa Majestade não vai querer que eu durma aí, vai?

Lu Linyuan: — ...

Dias antes, o médico imperial dissera que ele sofria de estagnação do qi do fígado. Até então, não sabia a origem do problema. Agora, olhando para Ning Xiaoxiao, finalmente encontrara a resposta!

Essa maluca só ficaria satisfeita quando o matasse de raiva!

Levantou-se de repente, puxou-a para junto de si e praticamente a arrastou até a cama, onde ergueu a coberta e a enfiou debaixo dela.

— Eu não vou dormir no assento aquecido! Se você gosta tanto dele, fique lá à vontade!

— Agora, aqueça a cama para mim! Quando estiver quentinha, pode se mudar para o assento!

Buááá! Que homem bravo!

Ning respondeu um “tá bom” bastante magoado e se enfiou sob as cobertas até metade da cabeça, assumindo o papel de instrumento humano para aquecer a cama.

Enquanto isso, Lu Linyuan continuou no assento aquecido, examinando os memoriais cuja leitura ele não ouvira. Cerca de quinze minutos depois, quando a respiração de Ning se tornou profunda, ele soltou um risinho satisfeito.

Era o que imaginava: aquela gatinha preguiçosa passava os dias sem se preocupar com nada e bastava encostar a cabeça no travesseiro para cair nos braços de Morfeu.

Ele abriu a janela e jogou lá fora a colcha e o travesseiro que Ning havia preparado no assento.

Dormir separada de mim sem minha permissão?

Nem em sonho!

Depois, apagou as luzes e se esgueirou para a cama, movimentando-se com toda a delicadeza para não acordá-la.

Como os dois dividiam uma única coberta, era inevitável que algum pedaço ficasse descoberto.

Para que nenhum dos dois sentisse frio, o tirano, em um enorme “sacrifício”, não teve alternativa senão abraçar Ning e oferecer o próprio braço como travesseiro sob a cabecinha dela.

Ning murmurou alguma coisa durante o sono. Ao sentir aquele abraço tão seguro, aconchegou-se instintivamente ainda mais contra o peito de Lu Linyuan.

Ele riu baixinho, roçou-lhe a ponta do nariz com o dedo e sussurrou:

— Boa noite, minha gatinha preguiçosa.

*

Na manhã seguinte, Sanfu levou as vestes e o chapéu cerimoniais ao Palácio Zhongcui.

Preparava-se para ajudar Lu Linyuan a se lavar e vestir, mas o imperador declarou: — A Nobre Dama Hua vai cuidar de mim. Espere do lado de fora.

A Nobre Dama Hua ia ajudá-lo?

A tal nobre dama dormia profundamente, sonhando que atravessava sozinha uma viela escura. Como poderia se ocupar das roupas dele?

Depois de se lavar rapidamente, Lu Linyuan sentou-se diante do espelho, penteou os cabelos com cuidado e, desajeitadamente, separou três mechinhas sobre a testa.

Ao ver o próprio reflexo ridículo, ficou vermelho de vergonha.

Felizmente, o chapéu cerimonial cobria quase toda a testa, deixando à mostra apenas a região das sobrancelhas.

Se escondesse um pouco aquelas três mechinhas por baixo do chapéu, não haveria grandes problemas.

Colocou-o e conferiu o reflexo mais de dez vezes. Só depois de se certificar de que ninguém perceberia nada vestiu o traje cerimonial e saiu discretamente para a audiência matinal.

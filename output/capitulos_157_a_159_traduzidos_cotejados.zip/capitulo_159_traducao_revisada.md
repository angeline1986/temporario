# Capítulo 159 — Xiaoxiao está prestes a voltar para casa!

Sanfu esperou cerca de um minuto, mas nenhum leitor que terminara o capítulo anterior apareceu para salvá-lo. Então cerrou os dentes e decidiu salvar a própria pele!

Ծ‸Ծ

Sob o olhar faiscante de Lu Linyuan, avançou devagarzinho até ele, agachou-se, recolheu o chapéu imperial e tirou cuidadosamente a poeira antes de recolocá-lo na cabeça do soberano.

— Majestade... há pouco, este servo...

— Você ficou ousado, não foi? — Lu Linyuan falou entre dentes, baixinho, para que apenas os dois ouvissem. — Até na minha cabeça se atreve a bater! Parece que não há mais lugar para você neste palácio!

Sanfu cambaleou de medo e aproveitou para se ajoelhar. — Majestade, tenha piedade!

— Saia da minha frente! Oitenta golpes de bastão e mais cem palmadas com a régua!

Sanfu agradeceu pela “graça” e fugiu quase rolando pelo chão.

Afinal, servia Lu Linyuan desde a infância. Se fosse qualquer outro, provavelmente já teria sido esfolado vivo pelo imperador.

Depois daquele episódio embaraçoso, os ministros desviaram os olhos de Lu Linyuan em perfeita sincronia. Todos seguravam o riso com tanta força que quase sofreram lesões internas, mas ninguém se atreveu a gargalhar.

O censor do Departamento de Flores e Aves, que provocara o incidente, continuava ajoelhado, batendo a testa no chão e implorando perdão ao tirano.

Lu Linyuan soltou uma risada fria. — Humpf. Esqueça os mil taéis de ouro. Se até o próximo verão essas abelhas não dobrarem a produção de mel, vou triturá-lo e transformá-lo em geleia real!

O oficial da Guarda Metropolitana, que acabara de afirmar que um homem com três mechinhas na testa só podia ser um pervertido, estava ainda mais apavorado.

Lembrava-se de que, logo após subir ao trono, Lu Linyuan fora insultado em plena corte por um velho ministro que servira três reinados e se julgava intocável. O homem dissera que o jovem imperador “ainda nem tinha pelos suficientes”. Em resposta, Lu Linyuan mandara arrancar todos os pelos do corpo do ancião, inclusive os do nariz. Com isso, ensinara de uma vez por todas aos ministros veteranos que seus serviços prestados não lhes davam licença para desrespeitar o soberano.

O oficial conhecia bem a brutalidade do tirano. Era apenas porque o reino desfrutava de paz e prosperidade nos últimos anos e quase todos os opositores da corte haviam sido eliminados que o temperamento do imperador parecera um pouco mais brando.

Seu cérebro girava desesperadamente. Antes que Lu Linyuan pudesse falar, começou a distribuir elogios exagerados:

— Majestade, seu penteado hoje está magnífico! Parece que os bigodes de um dragão adornam sua fronte, irradiando auspícios celestiais! É a própria imponência de quem governa o mundo! Ao contemplá-lo, meu coração estremece, e fico profundamente rendido ao encanto imperial!

Falou com uma sinceridade tão convincente que Lu Linyuan talvez tivesse acreditado, caso não tivesse contraído nenhuma espécie de estupidez contagiosa de Ning Xiaoxiao!

Mas ele tampouco era alguém que punia indiscriminadamente. Assim, limitou-se a declarar:

— Já que acha tão bonito, concedo a você esse penteado como recompensa. A partir de amanhã, deverá prepará-lo em casa antes de comparecer às audiências.

O oficial: — Ah... Majestade, este humilde servo não possui a beleza celestial de Vossa Majestade. Minha aparência comum não faria justiça a um penteado tão grandioso. Talvez...

Lu Linyuan interrompeu, com frieza: — Se sabe que é feio, mais uma razão para caprichar num penteado extravagante. Do contrário, não ficaria ainda mais evidente que você não serve para nada?

O oficial exibiu uma expressão de imensa “felicidade”:

— ...Este humilde servo... agradece a imensa graça de Vossa Majestade!

*

Enquanto a audiência matinal transcorria em clima “caloroso”, Ning Xiaoxiao dormia no palácio toda esparramada, com braços e pernas abertos.

De repente, um estrondo de fogos de artifício estalou bem junto de seus ouvidos, quase a deixando surda.

Ela soltou um palavrão dos bons e se sentou na cama. Ao perceber o silêncio estranho ao redor, ouviu a voz de Xiao Qi ecoar em sua mente:

【Bip, bip, bip~ Os fogos foram um presente meu para a anfitriã! Parabéns por concluir a missão “fazer o tirano comparecer à corte com o penteado de três mechinhas”.】

【Você ganhou 4 pontos percentuais de desvio da trama, elevando o índice acumulado para 30%!】

Ning revirou os olhos. 【Se completei, completei! Precisava soltar fogos? Se sua anfitriã fosse uma pessoa idosa, teria morrido de susto! Primeiro os fogos, depois o banquete fúnebre... Você sabe mesmo fazer economia!】

Depois de resmungar sem parar, ela subitamente se deu conta de algo:

【Espere! O que você disse? Como assim? Como é que eu completei a missão?!】

Tinha certeza de que Lu Linyuan prendera o cabelo novamente diante dela no dia anterior!

Além disso... ele não mandara que ela aquecesse a cama para depois dormir no assento aquecido enquanto ele ficava na cama?

Por que havia acordado na cama?

Instintivamente, olhou as próprias roupas. Ufa, ufa... a parte do corpo coberta pelo tamanho D permanecia bem escondida. Nada fora revelado!

【Mas eu nem fiz o penteado nele... Ontem adormeci sem perceber e só acordei agora...】

Xiao Qi riu às escondidas. 【Anfitriã, pense mais longe! Vai ver ele próprio gostou do penteado!】

Ning Xiaoxiao: 【...】

De qualquer modo, melhor assim! A missão estava completa!

O tirano já tinha uns parafusos soltos. Quem poderia saber que esquisitices fazia ao longo do dia?

Ela se lembrava de que, sempre que o índice acumulado de desvio da trama alcançava um número redondo, uma roleta de prêmios era ativada.

Por isso se apressou a cobrar a recompensa de Xiao Qi: 【Cadê a roleta? Que prêmios tem desta vez?】

Xiao Qi: 【Preparei tudo desde cedo! Os prêmios desta vez são ainda melhores que os anteriores. Por favor, gire a roleta e escolha sua recompensa!】

Ning fechou os olhos, e a grande roleta familiar apareceu novamente em sua mente.

Os nomes dos prêmios eram todos tão estranhos que ela não entendia quase nada. Resolveu simplesmente girar e aceitar aquilo em que o ponteiro parasse.

Após girar por alguns instantes, a roleta coberta de luzes coloridas parou em um prêmio chamado “Pílula de Volta à Terra Natal”.

Ning ficou perplexa. 【Que raio de coisa é essa?】

Xiao Qi explicou: 【Uau! Que sorte, anfitriã! A “Pílula de Volta à Terra Natal” faz exatamente o que o nome diz: depois de tomá-la, você poderá retornar à sua terra natal por um dia e uma noite~】

Aquilo era maravilhoso!

Com ela, Ning não precisaria sobreviver até o final da história para rever o pai e a mãe!

Só de pensar na mãe, que para encontrá-la tivera de se transformar ora em Li Kui, o “Turbilhão Negro”, ora no Rei do Chifre de Prata, Ning sentia pena... e também uma vontade irresistível de rir!

Como de costume, porém, para receber o prêmio era necessário cumprir antes uma missão com prazo definido.

Xiao Qi não perdeu tempo e foi direto ao assunto:

【Anfitriã, você precisa completar em 24 horas a missão “beijar o tirano 99 vezes”. Ao concluí-la, receberá a “Pílula de Volta à Terra Natal”.】

Ning Xiaoxiao: 【??? Você tem algum problema na cabeça?! Noventa e nove beijos num dia? Acha que eu sou um pica-pau e ele é um tronco podre?!】

Xiao Qi: 【Hehe, isso já é problema seu, anfitriã~ Já disse tudo o que precisava. Vou sair agora, tá? Tchauzinho~】

*

Lu Linyuan, que perdera a dignidade diante de toda a corte, decidiu descontar a humilhação em Ning Xiaoxiao, provocando-a até recuperar um pouco do orgulho ferido.

Chegou furioso ao Palácio Zhongcui e já estava diante da porta do pavilhão lateral leste, pronto para abri-la com um pontapé.

Foi então que os pensamentos de Ning chegaram aos seus ouvidos:

【Meu Deus do céu! Como vou conseguir beijar o tirano noventa e nove vezes em um único dia?!】

Nem mesmo Lu Linyuan percebeu que, ao ouvir aquilo, metade de sua raiva desapareceu instantaneamente.

Ele até apertou os lábios num sorriso feroz que escondia certa expectativa.

Mas a expectativa não durou sequer alguns segundos: logo ouviu o pensamento seguinte.

【E se eu der uma paulada nele e o deixar inconsciente?】

Lu Linyuan: — ???

Está sonhando acordada, é?!

Eu é que vou acertar sua cabeça com uma paulada primeiro!!!

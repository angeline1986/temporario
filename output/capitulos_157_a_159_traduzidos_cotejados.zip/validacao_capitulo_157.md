# Validação — Capítulo 157

- **Fonte primária:** `novel_capitulos_121_a_180(20261103-233558).docx`, chinês tradicional.
- **Limites no DOCX:** parágrafo 2504 (incluso) até 2588 (exclusivo), indexação base zero.
- **Unidades de origem não vazias, incluindo título:** 81.
- **Unidades traduzidas:** 81.
- **Índices ausentes, repetidos ou fora de ordem:** 0.
- **Campos vazios no cotejo:** 0.
- **Cabeçalho CSV:** `indice_docx,original_chines,traducao_portugues`.

## Atenções narrativas e editoriais

A perda de 10% de vitalidade é uma penalidade potencial discutida por Ning, não uma perda efetiva neste capítulo. Lu Linyuan decide usar as três mechinhas voluntariamente, após perceber a motivação dela. A expressão 三毛 alude ao visual com três tufos de cabelo.

## Limitações

Foi realizada a tradução integral com comparação por unidade e teste automático de cobertura estrutural. Isso não constitui uma segunda auditoria linguística independente de cada oração. Referências culturais e passagens ambíguas foram adaptadas quando necessário para preservar o efeito narrativo, sem antecipar informações do capítulo seguinte.

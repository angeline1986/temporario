# Validação — Capítulo 66

- Fonte primária: `novel_capitulos_61_a_120(20261103-184549).docx`.
- Unidades não vazias originais (incluindo título): **76**.
- Unidades traduzidas: **76**.
- Lacunas estruturais: **0**.
- Limites verificados pelos títulos dos capítulos 66 e 67.
- Cada registro CSV usa o índice do parágrafo real no DOCX (base zero).
- Revisão feita durante a tradução e checagem estrutural; **não foi realizada auditoria linguística independente**. A igualdade da contagem não garante fidelidade semântica absoluta.

## Observações

- O original contém “她一把將寧瀟瀟拉入自己懷中” em uma ação de Ning Xiaoxiao, literalmente “ela puxou Ning Xiaoxiao para os próprios braços”, incongruente na cena. Tradução contextual: “puxou a outra mulher para junto de si”; alteração interpretativa explicitada aqui.
- O título evoca o serviço de lavar o cabelo do tirano; 21 permanece sem resolução explícita neste capítulo, como no original.
- O episódio do lago é resolvido pelo botão Retroceder, sem identificar o agressor.

# Capítulo 66 — A nova lavadora de cabelos do tirano

Ning Xiaoxiao arrancava os cabelos do tirano com a mesma concentração de quem conta um maço de notas de cem.

Mas, quanto mais contava, menos empolgada ficava:

【97, 98, 99, 100... Hã? Acabou?】

Ela continuou vasculhando o couro cabeludo de Lu Linyuan, na esperança de encontrar mais uns dois fios brancos.

【Ah, fala sério, cara! Trabalhei esse tempo todo e você não vai me pagar nem um fio de comissão?】

【Quer dizer que seus cabelos brancos nasceram sob medida para pagar seu tratamento? Cem fios, cravados! Nem meio fio a mais!】

Lu Linyuan escutava os pensamentos dela em silêncio, um sorriso satisfeito surgindo nos lábios.

Você acha que foi fácil pintar cada fio de branco com um pincel?

Quer tirar vantagem de mim de graça? Nem sonhando!

Ning Xiaoxiao: 【E se eu arrancar uns pretos? Já tem tanto cabelo branco por aqui que ele nem deve perceber...】

Com essa ideia, estendeu suas garras malignas aos fios negros e saudáveis de Lu Linyuan e arrancou alguns de uma vez.

Lu Linyuan franziu o cenho. — Ainda não terminou?

— Quase, Majestade~ O senhor tem bastante cabelo branco. Preciso tirar tudo direitinho. Aguente só mais um pouquinho~

— ...

Assim, Ning Xiaoxiao fez os cabelos pretos passarem por brancos e arrancou mais de uma dezena de fios do pobre tirano.

Lu Linyuan suportou tudo calado.

Afinal, e se ela arrancasse seus cabelos e não lhe desse nada em troca, gastando tudo com comidas e bebidas em vez de curá-lo?

Só quando ela chegou ao vigésimo fio preto ele achou que já tinha concedido vantagem suficiente e falou:

— Venha cá. Mostre-me os cabelos que arrancou.

— Hã? Pra que o senhor quer ver isso...? — Enquanto falava, Ning Xiaoxiao enrolou os fios pretos e os escondeu na cintura, entregando a ele apenas o pequeno tufo branco.

— Olhe, Majestade! Todos brancos, nem um preto!

Lu Linyuan lançou um olhar e assentiu. — Pelo menos seus olhos funcionam. Leve-os e queime-os para mim.

Ning Xiaoxiao recebeu os fios com o respeito de quem segura dinheiro vivo, os olhos brilhando:

【Uma fortuna!】

【Hmm... E se eu não comprar o remédio para ele?】

【Ele nem sabe que posso curar a impotência dele. Pra que arrumar trabalho à toa?】

【Com esses 120 fios, não seria muito melhor comprar umas coisas de que gosto?】

Lu Linyuan: — ...

Eu sabia! Essa louca não tinha tão boas intenções!

— Hum, hum. — Ele limpou a garganta. — Você tem servido bem diante de mim e cuidado da sua senhora com dedicação. Pensei em aumentar seu pagamento mensal. Em vez de cinco taéis de prata, receberá sete. O que acha?

Ning Xiaoxiao abriu um sorriso que não chegou aos olhos. — Agradeço imensamente a graça de Vossa Majestade.

【Em vez de sete taéis, prefiro que me dê sete fios de cabelo por mês...】

— Mas, se vou aumentar seu pagamento, precisarei lhe dar mais trabalho. Pensei bem: você entende de xampu e disse conhecer técnicas profissionais de lavagem que ajudam a relaxar. De agora em diante, ficará responsável por lavar meus cabelos.

Ning Xiaoxiao: ???

Lavar o cabelo dele?

Eu ouvi direito?

Esse trouxa acabou de me dar a responsabilidade de lavar o próprio cofre?

Qual é a diferença entre isso e o presidente milionário de uma novel romântica entregar à protagonista um cartão sem limite para ela gastar à vontade?

Apaixonada! Simplesmente apaixonada!

Ning Xiaoxiao se animou na mesma hora, incapaz de esconder o sorriso.

— Mesmo sem o aumento, eu ficaria feliz em lavar os cabelos de Vossa Majestade. Afinal, poder servi-lo já é uma honra imensa!

Lu Linyuan olhou de lado. Você acha que tenho cara de idiota? Só um fantasma acreditaria nisso!

Era importante agradar o tirano.

Naquele momento, Ning Xiaoxiao parecia um tigrezinho criado e alimentado no zoológico.

Ela sabia muito bem o que era melhor: comer até se empanturrar numa única refeição ou garantir comida todos os dias.

Apertando o pequeno tufo de fios brancos, pensou: 【Está bem, já que ele aceitou ser meu patrocinador, vou fazer a caridade de curá-lo! Seria uma pena deixar aqueles 21 sem serventia.】

Lu Linyuan contraiu as sobrancelhas.

Meus 21?

Que 21?

Que apelido esquisito ela inventou para mim agora?

Por que está me olhando desse jeito?

Por que tenho a impressão de que ela está pensando em indecências??

*

Naquela noite, enquanto retornava ao palácio com Gu Sijin, esta perguntou casualmente:

— Xiaoxiao, tem uma coisa que acho estranha. Toda vez que você me acompanha quando sou chamada para passar a noite com o imperador, eu fico lá dentro fazendo exercícios. E você? O que faz lá fora? Hoje saí para ir ao banheiro e não encontrei você.

Ning Xiaoxiao não podia contar que, naqueles momentos, ficava jogando par ou ímpar com o tirano, arrancando os cabelos dele e lendo memoriais, podia?

Então improvisou: — O imperador me manda limpar as colunas do corredor. Passo a noite inteira esfregando...

— Coitada de você. — Gu Sijin tomou sua mão, penalizada. — Por minha causa, você passa por isso. Enquanto faço exercícios lá dentro, você fica limpando colunas do lado de fora. Acho que a culpa é minha. Talvez o imperador perceba como você é cuidadosa e competente, por isso sempre exige que me acompanhe. Mesmo quando tento dispensá-la, ele não permite.

— Não se preocupe, minha senhora. Trabalhos pesados fazem parte dos meus deveres. Não estou cansada.

Gu Sijin apertou a mão dela. — Ter você comigo é uma bênção.

Enquanto conversavam à beira do lago imperial, uma sombra negra surgiu de repente dos arbustos.

Aproveitando a distração das duas, a figura as empurrou com força, tentando derrubá-las na água.

Ambas perderam o equilíbrio e estavam prestes a cair no lago.

Naquele instante decisivo, Gu Sijin empurrou Ning Xiaoxiao para a frente, mantendo-a na margem, enquanto ela própria caiu na água.

A figura já havia desaparecido. Ning Xiaoxiao não sabia nadar. Gu Sijin também não.

Mesmo assim, sem hesitar, Gu Sijin havia deixado para Ning Xiaoxiao a chance de sobreviver.

Sua bondade ultrapassava o próprio instinto de sobrevivência e, mais uma vez, comoveu Ning Xiaoxiao.

Ela gritou para Gu Sijin, que se debatia na água: — Não tenha medo, minha senhora! Vamos fazer isso de novo!

Fechou os olhos e apertou o botão Retroceder.

A trama voltou três minutos.

Gu Sijin apertou a mão dela. — Ter você comigo é uma bênção.

Um brilho astuto cruzou os olhos de Ning Xiaoxiao. — E o melhor dessa bênção ainda está por vir.

Agora que sabia de onde a figura sairia, Ning Xiaoxiao estava preparada.

Ela puxou a outra mulher para junto de si e deu um chute violento no peito da figura que avançava por trás delas. — Vai se ferrar!

Com um splash, a figura caiu na água. Mas sabia nadar muito bem: mergulhou e desapareceu.

# Capítulo 68 — O tirano fazia xixi na cama desde pequeno

Essa mulher enlouqueceu!

Enlouqueceu de vez!

Lu Linyuan se levantou da cama e avançou furioso na direção de Ning Xiaoxiao.

Parecia prestes a arrancar os braços e pernas dela ali mesmo.

Assustada, Ning Xiaoxiao fez uma careta, ergueu a tigela diante do rosto como escudo e implorou em voz alta:

— Majestade, o senhor entendeu errado! Isto... isto é um remédio para tratar as sequelas da sua doença...

— Sequelas?

Lu Linyuan parou diante dela, soltou o ar com força e perguntou, impaciente: — O que quer dizer?

Ning Xiaoxiao: — Quando eu tratei a alergia de Vossa Majestade, o remédio era forte demais. Ele pode deixar umas sequelazinhas...

Ela espiou Lu Linyuan e baixou a voz: — Só não sei se Vossa Majestade... percebeu alguma mudança no próprio corpo ultimamente.

Ouvir Ning Xiaoxiao falar tão abertamente daquilo já bastava para fazer Lu Linyuan querer desaparecer de vergonha.

Então aquele era o remédio que ela havia comprado com os cabelos dele para tratar seu... problema íntimo?

Se fosse verdade, teria de bebê-lo, por mais repugnante que fosse!

Mas não podia admitir pessoalmente que sofria daquele problema. Limitou-se a dizer:

— De fato, fiquei com algumas sequelas... Insônia, irritação e outras coisas. Este remédio realmente funciona?

Ning Xiaoxiao não o desmascarou. Apenas assentiu vigorosamente: — Funciona! Se não funcionar, Vossa Majestade pode mandar cortar minha cabeça!

Lu Linyuan soltou uma risada fria.

Ótimo. Ela até aprendera a responder antes que ele perguntasse.

Recebeu a tigela das mãos dela, franziu a testa, fechou os olhos e, prendendo a respiração, engoliu tudo de uma vez...

Ning Xiaoxiao ficou boquiaberta com a façanha.

Observou-o tomar o remédio com o rosto todo contorcido, sentindo náuseas só de imaginar o gosto...

Assim que ele terminou, pegou outra tigela, encheu-a de água limpa e ofereceu: — Majestade, enxágue a boca.

Lu Linyuan estava indignado. Sentia que já havia perdido toda a dignidade diante daquela louca.

Afastou a mão dela com um movimento brusco da manga. Mas empregou força demais: Ning Xiaoxiao escorregou e caiu para a frente, direto em cima dele.

Vendo que estava prestes a aterrissar de cara no chão, estendeu instintivamente as mãos para agarrar qualquer coisa ao alcance.

Acabou segurando a cintura das calças de Lu Linyuan. Ao puxá-la, afrouxou a roupa sem querer, fazendo metade das calças dele cair e revelando suas roupas íntimas amarelo-imperiais.

— ...

Lu Linyuan cerrou os dentes e pronunciou o nome dela, sílaba por sílaba:

— Ning! Xiao! Xiao!

Depois de recuperar o equilíbrio, Ning Xiaoxiao também ficou morta de vergonha e disse depressa: — Perdoe-me, Majestade! Vou arrumar suas calças agora mesmo...

Bum!

Com um ruído abafado, a porta se abriu.

A imperatriz-viúva entrou conversando e rindo com as consortes e encontrou Ning Xiaoxiao com ambas as mãos na cintura das calças de Lu Linyuan, aparentemente tentando despi-lo.

— Craaá, craaá~

Os dois corvos que há muito não apareciam para comentar o clima do palácio voltaram a empoleirar-se nos galhos diante do Palácio Chaoyang. Aninhados um no outro, assistiam à humilhação de Lu Linyuan e Ning Xiaoxiao.

Todas as consortes ficaram paralisadas. — M-mas o que está acontecendo aqui?

A imperatriz-viúva ficou furiosa e bateu a bengala com cabeça de fênix no chão. — Criada insolente! Você ousa tirar as calças do imperador em plena luz do dia? Que indecência! Não tem vergonha na cara?!

Ning Xiaoxiao tremeu de susto, ajoelhou-se e protestou: — Vossa Majestade, a imperatriz-viúva, faça justiça! Eu... eu estava tratando uma doença do imperador!

— Tratando a doença dele? Você estava era cobiçando o corpo do imperador!

Lu Linyuan percebeu que a discussão estava ficando cada vez mais acalorada, enquanto os olhares das consortes continuavam presos às suas calças imperiais...

O rosto dele ficou vermelho. Pensou em puxar primeiro as calças para cima e só então defender Ning Xiaoxiao.

Mas Ning Xiaoxiao esperou e esperou, sem ouvi-lo dizer uma só palavra em sua defesa. Ficou indignada.

Eu nem tive medo de ganhar um terçol só de olhar ao te dar uma injeção no traseiro, e você não diz nada enquanto sua mãe me esculacha?!

Que desperdício da minha preocupação!

Primeiro pensou em retroceder a trama para escapar do constrangimento. Mas, ao refletir, por que deveria livrar alguém daquele vexame?

Afinal, quem estava passando vergonha era Lu Linyuan, não ela.

Quanto à possibilidade de a imperatriz-viúva puni-la, isso era ainda mais fácil de resolver.

Fazia muito tempo que não alterava a trama. Já que Lu Linyuan se recusava a defendê-la, ela mudaria o enredo para fazê-lo morrer de vergonha!

Ning Xiaoxiao abriu o documento mental e começou a alterar o texto freneticamente, gastando quase todos os cerca de duzentos caracteres que havia acumulado. Restaram apenas três.

A trama continuou:

A imperatriz-viúva, que um instante antes estava tomada pela fúria, de repente abriu um sorriso radiante. Aproximou-se, ajudou Ning Xiaoxiao a se levantar e disse com carinho:

— Minha boa menina, sei perfeitamente o que você está fazendo. Com certeza está tratando o péssimo hábito que o imperador tem de fazer xixi na cama, não é?

Lu Linyuan: ???

As consortes: — ...

A imperatriz-viúva prosseguiu: — O imperador tem muitas qualidades, mas sempre fez xixi na cama. Desde pequeno, urinava tanto que parecia capaz de abrir um buraco no colchão. Como isso me preocupava...

Ela segurou a mão de Ning Xiaoxiao e deu-lhe palmadinhas no dorso. — Se conseguir curá-lo desse problema, prestará um grande serviço. Ficarei muito contente.

Lu Linyuan ficou verde de vergonha. — Mãe! Que absurdos a senhora está dizendo?!

A imperatriz-viúva fingiu não ouvi-lo. Lançou um olhar à bandeja de frutas sobre a mesinha e ordenou:

— Alguém traga minha bengala com cabeça de fênix e quebre umas nozes para Xiaoxiao!

Apesar da ordem imperial, ninguém no aposento ousou se mexer.

A imperatriz-viúva se irritou. — O quê? Minhas palavras já não valem nada?

Só então o jovem eunuco que a servia pegou, tremendo, a bengala com cabeça de fênix e quebrou várias nozes para Ning Xiaoxiao...

Lu Linyuan levou a mão à testa.

Então... a loucura realmente era contagiosa?

Cansei. Que o mundo acabe logo.

As outras consortes esperavam que a imperatriz-viúva aproveitasse a oportunidade para mandar espancar Ning Xiaoxiao até a morte e, de quebra, implicar Gu Sijin.

Nunca imaginaram que ela teria aquela reação.

A imperatriz era esperta e ficou em silêncio ao lado delas.

Já a Consorte Nobre não resistiu e murmurou: — Majestade, ela realmente veio tratar seu problema de fazer xixi na cama...?

Lu Linyuan, naturalmente, negou. Mas a imperatriz-viúva o conhecia desde pequeno e, depois da declaração dela, qualquer explicação soava inútil.

Ning Xiaoxiao comia nozes enquanto assistia à fúria impotente do tirano, exultando por dentro.

O episódio daquela tarde terminou com Ning Xiaoxiao devorando uma travessa de nozes.

No caminho de volta ao palácio com Gu Sijin, esta perguntou: — Xiaoxiao... você estava mesmo tratando o imperador para ele parar de fazer xixi na cama?

Ning Xiaoxiao reprimiu o riso. — Isso mesmo. Estava tratando esse probleminha dele~

Gu Sijin suspirou, tomada mais uma vez de compaixão: — Quem diria que, na idade dele, o imperador ainda sofreria de um problema tão íntimo? Coitado. Já sei: quando eu o encontrar a sós, costurarei umas duas fraldas de pano e levarei para ele. Molhar a cama ainda vai, mas imagine a vergonha se ele fizer xixi nas calças durante a audiência da corte...

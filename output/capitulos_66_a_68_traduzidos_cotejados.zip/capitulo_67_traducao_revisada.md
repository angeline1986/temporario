# Capítulo 67 — O que você está tentando me fazer beber?

Gu Sijin estava apavorada. Apertando com força a mão de Ning Xiaoxiao, exclamou: — Xiaoxiao! Alguém quer me matar!

— Não tenha medo, minha senhora. Estou aqui com você.

É só uma pessoa que quer matar você?

Entre todas as mulheres deste harém, qual delas não quer?

No romance original, Gu Sijin se tornara inimiga de todo o harém devido ao favoritismo de Lu Linyuan. Sua vida no palácio era repleta de perigos.

Num dia, alguém a envenenava; no seguinte, outra pessoa a incriminava.

A trama ainda estava bem no começo. Ela teria muito sofrimento pela frente.

Ning Xiaoxiao pensou em retroceder mais uma vez e, usando também o botão Pausar, descobrir o rosto da pessoa mascarada.

Mas Xiao Qi apareceu para detê-la:

【É melhor a anfitriã não interferir nas partes da trama em que não deve se meter. A protagonista precisa passar por essas provações para crescer. Se a história ficar travada, você nunca conseguirá sair deste livro.】

No fim, Ning Xiaoxiao apenas confortou Gu Sijin e a aconselhou a tomar cuidado ao sair, pois alguém poderia voltar a atacá-la a qualquer momento.

Gu Sijin poderia ter feito um escândalo e pedido que Lu Linyuan investigasse tudo.

Mas preferiu não agir assim.

Afinal, não tinha provas e não sofrera nenhum ferimento. Mesmo que descobrissem o culpado, o que poderia fazer?

Pior: alertaria o inimigo e faria ainda mais rivais no harém.

Por isso, quando voltou ao palácio e recuperou a calma, disse a Ning Xiaoxiao: — Vamos fingir que nada aconteceu. Se aquela pessoa tentou me matar, vai tentar de novo. Só se ela acreditar que baixei a guarda é que conseguirei fazê-la revelar suas intenções.

Ao vê-la ficar cada vez mais prudente, Ning Xiaoxiao finalmente entendeu a alegria de acompanhar o crescimento de uma personagem.

Afinal, ver uma coelhinha inocente se transformar aos poucos numa chefona também parecia bem divertido.

*

Quem recebe dinheiro precisa fazer o serviço.

Depois que Gu Sijin adormeceu, Ning Xiaoxiao organizou cuidadosamente os cabelos do tirano sobre a mesa.

Vinte fios eram sua poupança; os outros cem serviriam para comprar o remédio dele.

Ela entrou na loja de conveniência dentro de sua mente e, seguindo as orientações de Xiao Qi, encontrou uma caixa branca com o preparado medicinal para tratar a impotência.

Pagou cem fios de cabelo e abriu a caixa. Dentro havia um pequeno frasco de vidro medicinal contendo cerca de 5 ml de um líquido amarelo-escuro.

【É só isso?】

Xiao Qi: 【Isso mesmo! Cura garantida~】

Ning Xiaoxiao sacudiu o frasco e ficou observando o líquido, pensativa. 【É só dar para ele beber?】

Xiao Qi: 【Se ele beber puro, morre! Primeiro você precisa diluir em cerca de 300 ml de água.】

Ning Xiaoxiao: 【Tudo bem. Então eu pauso o tempo e faço ele engolir o remédio diluído. Pronto, resolvido, não?】

Xiao Qi: 【Não pode pausar! Se o tempo estiver parado, o tirano não conseguirá engolir. Tudo o que você colocar na boca dele vai sair de novo e o remédio será desperdiçado!】

Então... teria de fazê-lo beber enquanto estivesse consciente?

Vendo assim, não parecia tão complicado.

Era só inventar uma maneira de convencê-lo a tomar o remédio!

Ning Xiaoxiao pretendia ministrá-lo naquele mesmo instante, mas estava exausta após um dia agitado. Resolveu dormir e deixar para depois.

Na manhã seguinte, Gu Sijin levou Cailian para apresentar seus cumprimentos à imperatriz.

A reunião daquele dia tinha como assunto principal o aniversário de Lu Linyuan, que seria celebrado dali a dois dias. Por isso, a imperatriz-viúva também apareceu na metade da audiência.

Ao completar mais um ano, Lu Linyuan entraria no ano de seu signo no zodíaco chinês. Todas levavam a ocasião muito a sério e apresentavam ideias para tornar a comemoração especial.

Depois de ouvir tantas opiniões, a imperatriz-viúva não conseguia se decidir. — Afinal, é o aniversário do imperador. O melhor é fazer tudo de acordo com os desejos dele. Muitas de vocês já não o veem há algum tempo. Quando ele acordar da sesta, irei com vocês ao Palácio Chaoyang. Cada uma poderá lhe apresentar suas ideias, e ele decidirá.

As consortes ficaram radiantes com a proposta.

*

Naquele dia, depois da audiência matinal e do almoço, Lu Linyuan voltou ao quarto para descansar.

Ning Xiaoxiao escolheu o momento exato para pausar o mundo do livro e colocar seu plano em prática.

Entrou sem obstáculos nos aposentos do tirano e, ao vê-lo cochilando de lado, não conseguiu evitar admirar aquele rosto perfeito de todos os ângulos. Mais uma vez, teve de reconhecer: a autora original realmente sabia criar um homem bonito!

Antes, quando lia romances com descrições de centenas de palavras sobre a aparência do protagonista, Ning Xiaoxiao achava que os autores só estavam enchendo linguiça. Nem prestava atenção.

Só depois de vê-lo pessoalmente entendeu que aquilo não era enrolação nenhuma.

Era como se a própria deusa Nüwa tivesse esculpido aquele homem com as mãos!

Depois de admirar a paisagem por mais um tempo, lembrou-se de que tinha algo a fazer.

Pegou o frasco do remédio, quebrou o vidro e despejou o líquido amarelo-escuro numa tigela.

Assim que o líquido caiu no recipiente, porém, um odor penetrante subiu até seu rosto.

Cheirava exatamente à amônia de uma latrina seca...

Com os olhos lacrimejando, cobriu o nariz e chamou Xiao Qi: 【Que história é essa? Que porcaria é essa?!】

Xiao Qi: 【A fórmula tem esse cheiro mesmo. Foi por isso que eu disse para diluir em 300 ml de água...】

Ning Xiaoxiao ficou sem palavras.

Despejou bastante água na tigela. O cheiro diminuiu um pouco, e a cor também ficou mais clara...

Mas por que aquela coisa parecia tanto urina de alguém desidratado?

Segurando a tigela, pensou: 【Você quer que eu faça ele beber isso? Aposto que ele vai me matar com um soco!】

Xiao Qi: 【Bom, você também pode optar por não tratá-lo...】

Ning Xiaoxiao: 【Você...!】

Enfim, seguindo a lógica de que o dinheiro já fora gasto e ela já estava ali...

Era melhor terminar o que havia começado!

Respirou fundo, reuniu coragem e caminhou até a cama de Lu Linyuan.

Então apertou o botão Reproduzir.

A trama continuou:

O cheiro terrível da poção na tigela arrancou Lu Linyuan de seus sonhos no mesmo instante.

Ao encontrar Ning Xiaoxiao de pé diante da cama, segurando uma tigela e sorrindo de um jeito suspeito, ele estremeceu de corpo inteiro...

— O que você está fazendo?!

Por reflexo, empurrou a tigela. Se Ning Xiaoxiao não a segurasse bem, todo o remédio teria derramado...

Na mesma hora, Lu Linyuan viu o líquido amarelo-claro e associou imediatamente aquilo a certas imundícies inconfessáveis...

Ning Xiaoxiao, surpreendida por ele acordar de repente, abriu um sorriso constrangido, acenou e, com o cérebro em pane, soltou:

— Hi, Majestade~ Que coincidência... O senhor também está tirando uma soneca?

Coincidência uma ova!

Ele arregalou os olhos e a encarou. — Ning Xiaoxiao! Que porcaria você está tentando me fazer beber?!

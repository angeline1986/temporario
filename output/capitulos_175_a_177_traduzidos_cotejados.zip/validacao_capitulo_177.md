# Validação — capítulo 177

- Fonte primária: `novel_capitulos_121_a_180(20261105-150504).docx`, em chinês tradicional.
- Faixa real dos parágrafos no DOCX (base zero): **3898–3960**; capítulo seguinte inicia em **3961**.
- Unidades não vazias, incluindo título, marcadores e eventual nota da autora: **60**.
- Linhas de cotejo: **60**.
- Cabeçalho CSV: `indice_docx,original_chines,traducao_portugues`.
- Índices faltantes, repetidos ou campos vazios: **nenhum detectado**.
- Alinhamento 1:1 entre original e tradução: **conferido estruturalmente**.
- Observações de continuidade: Pensamentos entre colchetes e palavrões; a palavra insultuosa é transliterada no diálogo para preservar a pergunta sobre seu significado.
- Limitação: o cotejo e a revisão contextual não equivalem a uma segunda auditoria semântica independente integral.

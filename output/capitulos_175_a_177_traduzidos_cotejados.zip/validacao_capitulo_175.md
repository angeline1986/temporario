# Validação — capítulo 175

- Fonte primária: `novel_capitulos_121_a_180(20261105-150504).docx`, em chinês tradicional.
- Faixa real dos parágrafos no DOCX (base zero): **3770–3831**; capítulo seguinte inicia em **3832**.
- Unidades não vazias, incluindo título, marcadores e eventual nota da autora: **59**.
- Linhas de cotejo: **59**.
- Cabeçalho CSV: `indice_docx,original_chines,traducao_portugues`.
- Índices faltantes, repetidos ou campos vazios: **nenhum detectado**.
- Alinhamento 1:1 entre original e tradução: **conferido estruturalmente**.
- Observações de continuidade: Distinção entre transmigração da alma e do corpo; revelação da origem de Ning Dazhi; mudança operada pela mãe.
- Limitação: o cotejo e a revisão contextual não equivalem a uma segunda auditoria semântica independente integral.

# Capítulo 176 — Você só poderá abraçar a mim

Já que Lu Linyuan havia atravessado para aquele mundo, o melhor era aceitar a situação. Por que não aproveitar o pouco tempo disponível para lhe mostrar as maravilhas da modernidade?

Quando desceram, Ning Xiaoxiao perguntou: — Ei, aonde você quer ir?

Ela ainda estava encantada com sua atuação digna de um prêmio, fingindo não conhecer o imperador. Lu Linyuan, por sua vez, estava disposto a levar a encenação até o fim.

— Em primeiro lugar, meu nome não é Ei. É Lu Linyuan.

— Tá bom, Lu. Não vou ficar discutindo como você apareceu lá em casa. Por acaso tenho a tarde livre. Se você também não tiver nada para fazer, venha passear comigo.

Lu Linyuan a fitou intensamente e soltou uma risadinha maliciosa. — Heh. Passear como?

— É só vir comigo!

Com aquele tempo maravilhoso, nem frio nem quente, e o movimento reduzido de um dia útil, não havia destino melhor que um parque de diversões.

Ning Xiaoxiao chamou um táxi. Durante o trajeto, Lu Linyuan ficou grudado à janela, admirando aquele mundo extraordinário e surpreendente.

Então era assim a terra natal dela. Ele é que conhecia pouco do mundo.

Quanto mais impressionantes eram as paisagens, mais ele considerava Ning Xiaoxiao um verdadeiro tesouro.

Arranha-céus, automóveis, aviões... Ele queria tudo!

Se ela fora capaz de lhe dar projetos de armas de fogo, provavelmente também conseguiria lhe proporcionar aquelas maravilhas.

Pensando nisso, tirou os olhos da janela e passou a observar Ning Xiaoxiao.

Sentados lado a lado, ela percebeu perfeitamente a intensidade invasiva daquele olhar.

— O que foi? Por que está me olhando?

— Tem uma sujeirinha no seu rosto.

Ele estendeu a mão de dedos longos e, cheio de boas intenções, arrancou um dos pequenos tufos dos cílios postiços delicados que Ning Xiaoxiao levara vinte minutos para colar. Eram cílios em tufinhos, mais naturais que uma faixa inteira.

Ao ver o pequeno tufo repousando na ponta dos dedos dele, Ning Xiaoxiao quase perdeu a cabeça.

— LU LINYUAN! VOCÊ TEM ALGUM PROBLEMA?!

O motorista, no banco da frente, observou o casal às turras pelo retrovisor e não conseguiu conter um sorriso.

Problema ele não sabia se tinham, mas nenhum dos dois parecia muito esperto...

*

Quando chegaram ao parque, Ning Xiaoxiao ainda lamentava o buraco nos cílios postiços.

Lu Linyuan, recém-chegado àquele mundo, nunca vira nada parecido. Um carrinho de montanha-russa passou disparado pelos trilhos sobre sua cabeça, acompanhado de um estrondo e dos gritos dos passageiros. Era uma cena de tirar o fôlego.

— O que é aquilo? — perguntou ele.

Ela pensou em responder normalmente, mas logo percebeu que ele certamente nunca andara numa montanha-russa. Se o levasse numa volta, não morreria de susto?

Sorrindo, respondeu: — Montanha-russa! É divertidíssimo. Quer experimentar?

Como uma criança diante de uma novidade, Lu Linyuan não conseguia tirar os olhos do brinquedo.

Assentiu com vigor, cheio de expectativa.

Ning Xiaoxiao se virou para esconder uma risada e o puxou para comprar ingressos.

A princípio, queria mandá-lo sozinho, já que também morria de medo daquela atração. Mas temia que ele reagisse de maneira imprevisível durante o percurso e provocasse algum acidente. Cerrou os dentes e decidiu acompanhá-lo.

Para pregar uma peça em outra pessoa, acabara se metendo na própria armadilha. Era um sacrifício e tanto.

Só não imaginava que Lu Linyuan não tivesse o menor medo de altura!

Pelo contrário: parecia adorar aquela sensação de perigo!

Ning Xiaoxiao passou o trajeto inteiro sem abrir os olhos, gritando feito louca e apertando a mão dele com tanta força que quase deixou marcas vermelhas.

Ao descer, ela sentia que perdera metade da vida. Lu Linyuan, no entanto, mal podia esperar para ir de novo.

— Não, não! Se quiser outra volta, vá sozinho! Eu não aguento mais...

Ela se afastou depressa, e Lu Linyuan olhou para as marcas avermelhadas no dorso da própria mão, abrindo um sorriso doce.

Não era que gostasse tanto assim de montanhas-russas. O que ele adorava era a sensação de ter sua Xiaoxiao agarrada à mão dele.

Mais tarde, sempre que passavam por brinquedos radicais, torres de queda livre ou plataformas de bungee jumping, ele parava e olhava para ela com expectativa. — Quero ir.

Mas a medrosa Ning Xiaoxiao só tinha coragem de dar umas voltas no carrossel. E, mesmo ali, se agarrava ao pescoço do cavalo como se pudesse cair a qualquer segundo.

Foi quando ela viu uma multidão diante de uma barraca. Ao se aproximar, descobriu um jogo de estourar balões com dardos.

O prêmio principal era um urso de pelúcia quase tão alto quanto ela. Seus olhos se iluminaram, e ela ficou pregada no chão.

— Você quer? — perguntou Lu Linyuan.

Ela assentiu com força. — Quero! — Mas logo balançou a cabeça, desanimada. — Ah, deixa. Não está à venda. Olha a regra: só ganha o ursão quem acertar dez balões com dez dardos. Eu...

Antes que terminasse, Lu Linyuan entregou ao dono da barraca o trocado que ela lhe dera. Pegou dez dardos e, sem sequer mirar, lançou todos de uma vez. Os projéteis voaram e estouraram os dez balões com uma precisão absurda.

Aquela façanha atraiu instantaneamente os olhares ao redor.

— Caraca! Tenho certeza de que nem pisquei... Como ele fez isso?!

— Aaaaa! Amiga, olha! Que homem lindo!

— ...

Até Ning Xiaoxiao ficou de queixo caído.

Antes, seus olhos brilhavam por causa do ursão. Agora, brilhavam por causa de Lu Linyuan.

Enquanto a multidão comentava a proeza, o dono da barraca resmungou alguns palavrões e entregou o urso a Lu Linyuan.

Lu Linyuan passou o prêmio diretamente para Ning Xiaoxiao. — Pegue.

Ela pôs a cabecinha para fora por baixo do braço do urso. — Se eu soubesse que você era tão bom nisso, teria levado você à barraca de argolas!

Lu Linyuan não entendeu. — O que tem de tão interessante nesse troço feio e peludo?

— Ah, você não entende! — Ela fez um gesto displicente. — Gosto de dormir abraçada a alguma coisa. Só assim consigo descansar bem.

Lu Linyuan a observou com interesse e sorriu de maneira sugestiva, sem dizer nada.

Pode abraçar à vontade.

Quando voltar comigo à dinastia Qi amanhã, sem esse urso, só poderá abraçar a mim.

(Nota da autora: Amanhã eles voltam à antiguidade, mas ainda vão retornar ao mundo moderno mais adiante! E hoje eu NÃO terminei num suspense! Me elogiem!!)

# Capítulo 177 — O que significa essa palavra?

Pensando bem, fazia muito tempo que Lu Linyuan, sempre ocupado com os assuntos de Estado, não deixava tudo de lado para se divertir sem preocupações com a pessoa que amava.

Com o sol da tarde, a temperatura continuou subindo.

Ning Xiaoxiao, com os cabelos ondulados na altura dos ombros, sentia como se houvesse uma panela de vapor atrás de seu pescoço. Suava sem parar; os fios molhados grudavam desagradavelmente na pele.

Tirou um elástico da bolsa e prendeu os cabelos num coque improvisado.

Lu Linyuan pegou um panfleto que alguém lhe entregara na rua, dobrou-o numa espécie de leque e caminhou ao lado dela, abanando-a em silêncio.

Ning Xiaoxiao reclamou que estava morrendo de calor. Comprou dois picolés de um vendedor e, ao avistar um fliperama, puxou Lu Linyuan na direção da entrada.

Mas ele parou diante da porta e começou a lhe dar uma explicação muito séria. — Ao ar livre, o calor é intenso, mas o ar não fica abafado. Basta ficar à sombra de uma árvore, longe dos raios do sol, para sentir o frescor.

Ele a conduziu para debaixo de uma árvore e apontou para a parede do fliperama. — Esse lugar não tem janelas para ventilação. Passou o dia inteiro sob o sol e continua recebendo gente. A esta altura, deve estar quente feito um forno. Melhor nós... Hm?

Antes que terminasse, Ning Xiaoxiao enfiou um picolé na boca dele.

— Vem com a sua mestra! Vou te mostrar o que é um lugar com ar-condicionado!

Ela saiu na frente, toda orgulhosa, com a mão esquerda nas costas e o dedo fazendo um gesto para chamá-lo. Parecia exatamente o gesto com que Lu Linyuan costumava convocá-la, como se chamasse um cachorro.

Enquanto isso, o picolé que lhe fora empurrado boca adentro provocou em Lu Linyuan um choque gelado que subiu direto ao cérebro, deixando sua cabeça zunindo.

Ele viu Ning Xiaoxiao pôr o próprio picolé na boca e chupá-lo, satisfeita.

Arrepiante! Estremeceu e atirou o picolé longe como quem se livra de uma granada.

【...】

【Tsc, tsc. Não imaginava que ela tivesse esse tipo de gosto...】

Ele apressou o passo, arrancou também o picolé das mãos dela e, murmurando que os costumes modernos estavam completamente corrompidos, jogou-o fora.

Ning Xiaoxiao ficou paralisada. — Mas você é idiota?! Eu paguei por aquilo! Por que jogou fora? Você já não tinha o seu?

O rosto de Lu Linyuan ficou vermelho num instante.

Franziu as sobrancelhas e falou baixinho, muito sério: — Fale mais baixo! Que vergonha!

Dessa vez, Ning Xiaoxiao não conseguiu nem acompanhar a lógica tortuosa do imperador.

Ela estava quase derretendo de calor e não tinha energia para ficar discutindo com aquele bobão debaixo do sol.

Se havia salvação para o verão, ela vinha na forma de picolés, sorvetes e ambientes com ar-condicionado.

Lu Linyuan jogara os picolés fora, mas ao menos ainda poderiam aproveitar o ar fresco do lado de dentro!

Ao entrarem no fliperama, o ar-condicionado central, regulado para dezesseis graus, começou a mostrar todo o seu encanto.

Ning Xiaoxiao fechou os olhos, satisfeita, deixando o vento gelado acariciar sua pele e secar o suor pegajoso. (Nota da autora: Não imitem a nossa Ning fazendo isso! Cuidado para não ficarem doentes.)

Não teve nem dois segundos de sossego antes de ouvir uma onda de risadas ao redor.

Quando abriu os olhos, Lu Linyuan já estava em pé em cima de uma cadeira da área de descanso, mexendo na saída de ar do aparelho.

Nem precisava perguntar: o idiota estava tentando entender como aquilo funcionava.

Morrendo de vergonha, Ning Xiaoxiao correu para tirá-lo da cadeira e sussurrou ao ouvido dele: — Para de ficar pulando por aí que nem um macaco do monte Emei! Está cheio de gente aqui. Tenha um pouco de noção!

Lu Linyuan era curioso como uma criança, mas também um imperador dedicado ao bem-estar de seu povo.

Mesmo naquela situação, continuava pensando na seca que atingira o norte no ano anterior e nos numerosos súditos que morreram de calor durante o auge do verão. Como seria bom poder levar aquele aparelho para a dinastia Qi!

No mundo há gente gentil, mas também há gente desprezível.

Como o casal que vinha na direção deles. O homem levantava a camiseta para expor uma barriga redonda, tinha um dragão azul de tatuagem barata no braço e uma enorme falha no cabelo. A mulher carregava três camadas de pó no rosto, e seu perfume vagabundo era tão forte que fazia os olhos lacrimejarem.

Ao passar por Ning Xiaoxiao e Lu Linyuan, o homem cuspiu no chão de propósito, soltando uma risada debochada. A mulher acrescentou, num tom venenoso:

— Aff, que imbecil do caralho.

Ao ouvir aquilo, Ning Xiaoxiao explodiu!

Porra! Quem essa mulher pensa que é para xingar o meu homem?!

Tomada pelo instinto de protegê-lo, deixou qualquer cautela de lado. Alcançou a mulher, bloqueou sua passagem e disparou:

— Ah, você é inteligente? Tão inteligente que parece uma flor carnívora de Ordos!

A mulher: — Você...

— Você o quê? Olha para esse seu namorado! Parece um bagre gigante da Sibéria! Quando sai de casa para retocar a maquiagem, você nem precisa levar espelho, né? A careca brilhante dele reflete tanta luz que basta inclinar a cabeça do sujeito para se maquiar!

Afinal, ela tinha ido parar dentro daquele romance graças a uma sessão de comentários sarcásticos sobre Lu Linyuan. Sua língua afiada poderia representar a população inteira da internet. Quem conseguiria vencer uma discussão com ela?

Ao ver a namorada humilhada, o homem soltou um palavrão e avançou contra Ning Xiaoxiao com o punho erguido.

Num piscar de olhos, Lu Linyuan se colocou diante dela, agarrou o soco do homem com a palma da mão e apertou com tanta força que os ossos estalaram.

O homem começou a gritar de dor, enquanto a mulher berrava para que Lu Linyuan o soltasse.

Ora, ele era um tirano, lembram? Quem aqueles dois insolentes pensavam que eram para continuar dando chilique?

A crueldade surgiu no olhar de Lu Linyuan, e o canto de seus olhos ganhou um leve tom avermelhado.

A expressão foi tão assustadora que até Ning Xiaoxiao sentiu os pelos se arrepiarem.

Mas eles estavam no mundo moderno! Se ele ficasse furioso e torcesse o pescoço dos dois, amanhã os dois voltariam à dinastia Qi sem consequências; só que, quando a polícia examinasse as câmeras de segurança, não acabaria indo atrás dos pais dela?

Por isso, segurou o antebraço dele, onde as veias saltavam, e pediu baixinho: — Deixa pra lá. Manda esses dois sumirem.

Como um cavaleiro obediente protegendo sua princesa, Lu Linyuan olhou para Ning Xiaoxiao com ternura e assentiu. Depois soltou o homem e ordenou ao casal, com o mais puro desprezo: — Sumam.

As pessoas que assistiam à cena começaram a aplaudir. Lu Linyuan, sob todos aqueles olhares, fez a Ning Xiaoxiao uma pergunta capaz de matá-la de vergonha cem vezes:

— Aquela palavra que eles disseram antes, «shǎbī», o que significa?

Os aplausos viraram gargalhadas. Vermelha até as orelhas, Ning Xiaoxiao correu para puxá-lo para um canto.

Mas ele insistiu, sem lhe dar descanso: — Você não respondeu. O que significa «shǎbī»?

Ning Xiaoxiao suspirou. — Não é nada demais... Quer dizer que alguém não é muito inteligente, que demora a entender as coisas. Enfim, não é elogio. A pessoa te xingou uma vez e você quase esmagou os ossos da mão dela. Já está bom, né?

Não muito inteligente. Lento para entender.

Lu Linyuan assentiu pensativo. Então fixou os olhos em Ning Xiaoxiao e, sem mais nem menos, sorriu.

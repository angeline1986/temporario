# Capítulo 175 — Xiaoxiao: corpo e alma finalmente unidos

O clima ficou um tanto constrangedor. Ning Dazhi, que saiu logo depois, parecia ter virado irmão de Lu Linyuan. Passou um braço pelos ombros dele com toda a naturalidade e ergueu as sobrancelhas para Ning Xiaoxiao, orgulhoso. — E aí? Seu pai não deixou esse bonitão um espetáculo?

Como pai, ele não tinha um pingo de seriedade. Diante do silêncio da filha, simplesmente empurrou Lu Linyuan na direção dela. — Você não disse que ele é seu namorado? Então cuide do rapaz, em vez de ficar aí plantada! Essa menina...

Ning Xiaoxiao: — ???

【Que história é essa, velhote? Foi você que costurou um laço nas costas dele, e agora vem se fazer de desentendido...】

Lu Linyuan aproveitou a deixa. Virou o rosto, baixou os olhos para ela e abriu um sorriso encantador. — Acho que meu sogro tem razão.

A testa de Ning Xiaoxiao se encheu de pontos de interrogação. — Sogro?!

Lu Linyuan assentiu com um sorriso sinceríssimo. Nem precisava perguntar: aquele tratamento idiota só podia ter sido ensinado pelo pai sem-vergonha dela.

Dizem que, quando uma filha se casa, o pai costuma ser o que mais chora.

O meu, não. Parece doido para me despachar. Nem se importa que o sujeito seja um personagem de papel! É como se a própria filha estivesse atrapalhando a vida dele...

Quem salvou Ning Xiaoxiao foi Qi Meijuan, que chamou da cozinha:

— Filhota, pega o iPad da mamãe lá no quarto! Preciso ver uma receita!

— Tááá!

Como uma prisioneira recém-indultada, Ning Xiaoxiao escapuliu dali a toda velocidade.

No quarto, tirou o tablet da mesinha de cabeceira e, sem querer, acendeu a tela.

Foi então que descobriu que sua mãe também gostava de ler romances.

Deu uma olhada por alto. Parecia ser uma história sobre a vida no campo.

O curioso era que o protagonista tinha exatamente o mesmo nome de seu pai: Ning Dazhi.

Segurando o tablet, Ning Xiaoxiao fez a expressão de quem acabara de descobrir um casal perfeito.

Olha só! Dizem que quem implica é porque ama. A mãe vivia implicando com o pai, mas, na hora de ler, escolhia justamente uma fanfic estrelada por ele?

Tsc, tsc. Acho que já sei de quem herdei essa mania de negar o que sinto!

*

Qi Meijuan cozinhava muito bem, e a refeição dos quatro transcorreu num clima alegre e familiar.

Ao ver Ning Dazhi servir comida no prato de Qi Meijuan, Lu Linyuan o imitou, servindo Ning Xiaoxiao. Ainda a avisava quando um prato estava quente e pedia que comesse devagar.

Ele a tratava com todo o cuidado, mas Ning Xiaoxiao ficou incomodada:

【Desde quando esse imperador desgraçado ficou tão atencioso? Lá na dinastia Qi, só servia comida para mim. Nem olhava para as outras mulheres.】

【Agora chega ao mundo moderno, nem sabe que sou eu e já fica me cercando de cuidados?】

【É só para mim que você serve comida ou todas as outras mocinhas também ganham?】

Os pensamentos dela transbordavam ciúme, para a enorme satisfação de Lu Linyuan.

Depois do almoço, Ning Xiaoxiao pretendia passar algum tempo com os pais. Afinal, já havia perdido metade do dia em confusões e só lhe restava mais meio dia no mundo moderno.

Mas Ning Dazhi e Qi Meijuan pareciam ter combinado expulsá-la de casa.

Qi Meijuan segurou o braço do marido e anunciou, toda convencida:

— Eu e seu pai já compramos ingressos para a sessão das três. Você pode não ter homem, mas eu tenho.

Ning Dazhi foi mais longe: atirou um cartão bancário para a filha e declarou, com pose de magnata:

— Tem um milhão nessa conta! Não volte antes de gastar tudo!

Ning Xiaoxiao: — ???

Ah, entendi! Vocês dois são o amor da vida um do outro, e eu fui um acidente?!

Finalmente volto para casa e é assim que me recebem?

Fui traída pelo próprio amor!

Com o cartão na mão esquerda e a mão de Lu Linyuan na direita, Ning Xiaoxiao se despediu, indignada, e o arrastou para fora.

*

Quando os dois saíram, Qi Meijuan e Ning Dazhi não foram ao cinema. Seguiram direto para o laboratório escondido atrás de uma porta secreta no quarto.

Os dedos de Qi Meijuan dançavam pelo teclado de um supercomputador.

Ning Dazhi não entendia nada daquilo. Restava-lhe servir chá, buscar água, cortar frutas e ficar bajulando a esposa.

O que Qi Meijuan pretendia fazer era alterar um dado no livro para o qual Ning Xiaoxiao havia transmigrado.

Ela queria transformar a transmigração da alma da filha numa transmigração de corpo inteiro.

— Amor, acha mesmo que vai dar certo? — perguntou Ning Dazhi.

— Por que não daria? Basta alterar as lembranças dos personagens sobre a aparência original de Xiaoxiao. Assim, ela terá atravessado com o próprio corpo sem que ninguém perceba nenhuma diferença.

Qi Meijuan continuou operando o computador e aceitou uma fruta que Ning Dazhi levou à sua boca com um garfo.

— Você não percebeu que nossa filha já está apaixonada por ele? Se o corpo não for realmente o dela, não fica esquisito? Eu não consigo trazê-los definitivamente para cá, mas alterar alguns dados não é difícil.

Ning Dazhi não entendeu. — Mas, no fim das contas, não é tudo a mesma pessoa? Faz diferença?

Qi Meijuan respondeu, impaciente: — Como não faria? A alma pode ser a mesma, mas o corpo não é. Você quer que ele se envolva com aquela criada figurante lá na dinastia Qi e, depois de sair do livro e vir ao mundo moderno, se envolva também com nossa filha? Que nojo!

— Homem que não se respeita é igual a repolho podre. Nem cachorro quer.

Ning Dazhi: — Mas...

— Por que tanta pergunta? — Qi Meijuan lançou um olhar fulminante ao marido e suspirou.

— Se eu soubesse que você falava tanto, nunca teria tirado você de dentro daquele livro!

Ning Dazhi: — ... Não, não, calma! Eu me respeito! Não sou repolho podre! Vou ficar quietinho!

Ele cobriu a boca com as mãos, fingindo ser um coitadinho.

Mas, assim que Qi Meijuan voltou os olhos para o computador, ele a contemplou com um olhar apaixonado e um sorriso cheio de ternura.

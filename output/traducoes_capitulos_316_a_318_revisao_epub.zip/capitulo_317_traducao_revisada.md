Capítulo 317 — Gu Sijin volta a atacar

Embora Xiao Qi, aquele velho espertalhão, só dissesse disparates, dessa vez acertara em um ponto.

Ela já estava grávida. Não podia simplesmente abortar por medo do futuro nem, depois do parto, enfiar a criança de volta na barriga, podia?

A vida precisava continuar. Como Xiao Qi dissera, as coisas acabariam se ajeitando; viver preocupada com o futuro só a deixaria deprimida.

Não vale a pena o incômodo e a angústia.

*

Naquele dia, a mãe do adorável príncipe Jing estava à beira da morte.

Sua saúde já era frágil; era apenas questão de tempo até que sua vida chegasse ao fim.

Atualmente, Lu Yiqiu raramente entra no palácio, por isso tem agido como um filho filial, passando todos os dias ao lado de sua mãe.

Ao saber da notícia, Lu Linyuan decidiu deixar o palácio para visitá-la.

Inicialmente, Ning Xiaoxiao também queria ir, afinal, ela e o Príncipe Jing eram bons amigos.

Mas Lu Linyuan não permitiu que ela o acompanhasse.

"O médico imperial informa que a mãe do príncipe Jing pode ter apenas alguns dias de vida. Você está grávida e seria inconveniente para você comparecer a tais ocasiões."

Essas regras não são muito diferentes das regras dos tempos modernos.

Uma pessoa sai, outra chega. Mesmo que Ning Xiaoxiao não se importe, as pessoas ainda podem fofocar, dizendo que a criança em seu ventre drenou o último resquício de força vital da pessoa gravemente doente, o que seria ruim.

Ning Xiaoxiao acatou o conselho e permaneceu no palácio.

Após Lu Linyuan deixar o palácio, as concubinas finalmente tiveram tempo de vir prestar suas homenagens a Ning Xiaoxiao.

Ela engravidou e todos estavam ocupados tentando ganhar sua simpatia.

Os presentes de felicitações trazidos naquela visita eram incontáveis: alimentos, objetos de uso diário e artigos preciosos de toda espécie, tantos que Ning Xiaoxiao mal sabia para onde olhar.

Ela não ofendeu ninguém, aceitou tudo e até pediu para Qiqi escolher alguns presentes para retribuir.

Somente depois que as concubinas partiram, ela ordenou que todos os presentes de felicitações do dia fossem enviados para o depósito e lacrados, proibindo que qualquer um deles fosse usado.

Lala era a responsável por lidar com essa questão e não entendia muito bem a abordagem de Ning Xiaoxiao:

"Vossa Majestade, estes são todos itens de altíssima qualidade, alguns deles até com ingredientes nutritivos. Seria um desperdício guardá-los no depósito e deixá-los estragar!"

Nesse instante, Gu Sijin entrou e continuou de onde Lala havia parado, respondendo-lhe:

— Você sabe quantas armadilhas podem estar escondidas nesses presentes?

— Armadilhas? — Lala ficou ainda mais perplexa. — Tudo o que entra no depósito fica registrado com o nome de quem enviou. E o imperador ordenou que qualquer presente destinado ao nosso palácio seja examinado três vezes pelos médicos imperiais antes de entrar...

Ning Xiaoxiao balançou a cabeça e zombou: "Algumas coisas se reforçam e se restringem mutuamente. Funcionam bem quando usadas sozinhas, mas se forem usadas juntas, podem causar um grande desastre."

Lala finalmente compreendeu e apressou-se a dizer: — Esta serva vai lacrar tudo no depósito imediatamente. Não usaremos nada.

Depois que ela saiu, Gu Sijin balançou a cabeça, impotente: "Por que você faz isso consigo mesma? Mesmo como imperatriz, você ainda precisa estar em guarda contra vilões dia e noite."

— Ouvi Xiao Yinzi comentar que o imperador já falou com você sobre dissolver o harém, mas foi você quem não concordou. Por quê?

Ning Xiaoxiao: "O Imperador veio me ver e disse que queria dissolver os seis palácios. Mas o Imperador não é apenas meu marido, é também o governante do país. Administrar um país não é algo que o Imperador possa fazer sozinho."

— As consortes do harém, por um lado, dão prestígio às famílias de origem; por outro, funcionam como uma forma de contenção política. Com suas filhas no palácio, as famílias pensam duas vezes antes de criar problemas.

— Até Tong Guowei, tão arrogante e tão indiferente a Tong Yuanyuan, se manteve na linha enquanto ela ainda conservava sua posição, não foi?

Ning Xiaoxiao está completamente diferente agora em comparação com quando ela transmigrou pela primeira vez para dentro do livro.

Naquela época, o mundo do livro nada tinha a ver com ela. Agora, porém, o governante daquele país era seu marido, e Ning também sentia sobre os ombros parte da responsabilidade pelo reino.

— Se o imperador dissolvesse o harém, eu seria a única a comemorar. Mas, a longo prazo, haveria mais prejuízos do que benefícios.

— De todo modo, ele não dará atenção a nenhuma delas. Basta que eu seja cuidadosa para evitar problemas.

Ao ouvir isso, Gu Sijin não ousou persuadi-la mais e apenas provocou: "Notei que quanto mais tempo você passa comigo, mais você se parece comigo."

*

Naquela noite, por volta da meia-noite, Gu Sijin saiu discretamente de seus aposentos, sem deixar que ninguém a acompanhasse.

Ela caminhou todo o caminho até o Lago Imperial, tirou ração para peixes da manga e alimentou as carpas koi no lago.

De repente, uma pessoa vestida com uma capa preta surgiu dos arbustos à distância.

A mulher se aproximou por trás de Gu Sijin e fez uma reverência. — Nobre Dama Gu.

Gu Sijin nem se voltou; continuou alimentando os peixes e perguntou, com frieza: — Que assunto era tão urgente que você precisou me mandar um recado?

A recém-chegada tirou o capuz, revelando-se Xiu’er, a criada pessoal da Consorte Duan.

"A previsão de Vossa Excelência estava correta; a Consorte Duan de fato pretendia prejudicar o filho ainda não nascido da Imperatriz."

"Oh?" Gu Sijin parou de se mover ao ouvir isso e disse com um meio sorriso: "Gostaria de saber, com o Palácio Fengluan sob tanta segurança, que método a Consorte Duan tem para prejudicar o filho que Xiaoxiao espera?"

Xiu’er: — Todos os objetos que entram no Palácio Fengluan passam por três inspeções. Qualquer coisa suspeita seria barrada.

— Por isso, a Consorte Duan pretende colocar uma mistura especial de incensos, comprada de um médico especializado em venenos fora do palácio, junto a uma formação de rochas artificiais a oeste do Palácio Fengluan.

"Quando o vento soprar para baixo, o cheiro entrará no palácio da Imperatriz. Com o tempo, a Imperatriz inevitavelmente terá problemas com seu filho ainda não nascido, como aborto espontâneo ou defeitos congênitos."

"Eu pensei que fosse um plano brilhante?" Gu Sijin zombou com desdém. "Com essa cabeça oca, ela acha que pode machucar a Xiaoxiao?"

"Bem, vamos ver se ela consegue viver para ver o nascer do sol amanhã."

Vendo que havia apaziguado Gu Sijin, Xiu'er ajoelhou-se apressadamente e começou a implorar por misericórdia:

— Nobre Dama Gu, fiz tudo o que me ordenou... Por favor, tenha misericórdia e peça a seu pai que poupe Aye...

Aye era o amado de Xiu’er, um guarda de baixa patente da instituição de fiscalização imperial, incumbido de pequenos serviços no palácio.

Gu Sijin vinha observando secretamente os movimentos no palácio da Consorte Duan, então, mesmo que o pequeno truque de Xiu’er pudesse enganar a Consorte Duan, não conseguiria enganá-la.

Nesse instante, ela olhou para Xiu’er com um toque de pena:

— Ora, ora! Você se importa mesmo com seu amado. Uma pena que tenham mantido esse relacionamento clandestino no palácio — e que ele trabalhe justamente sob as ordens de meu pai. Que azar o seu!

— Mas prometi: se cumprir sua parte, não apenas pouparei a vida dele como farei com que vocês se reencontrem.

Xiu’er, com lágrimas de gratidão, fez repetidas reverências. — Esta serva agradece a bondade da Nobre Dama!

Gu Sijin estreitou ligeiramente os olhos enquanto examinava Xiu’er, que se curvava e se prostrava diante dela.

Uma reles criada que agora Gu Sijin controlava como bem entendia antes ousara humilhá-la e lhe dar ordens só por ser uma favorita da Consorte Duan!

Após ver Xiu’er sair, Gu Sijin agiu como se nada tivesse acontecido e continuou alimentando os peixes.

Observando as carpas saltarem do lago para abocanhar a comida, ela exibiu um sorriso sinistro e murmurou para si mesma:

— Claro que vou reuni-la ao seu amado.

— Afinal, com alguém para acompanhá-la no caminho para o mundo dos mortos, nenhum dos dois se sentirá sozinho.

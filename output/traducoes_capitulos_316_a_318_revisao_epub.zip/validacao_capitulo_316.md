# Validação do capítulo 316

- **Original:** `novel_capitulos_301_a_360(20261107-181903).docx` (DOCX chinês).
- **Tradução-base:** `novel capitulos 301 a 360 - ch.epub` (EPUB português, `index_split_015.html`).
- **Índices absolutos base zero do DOCX:** 1243–1313 (lacunas para parágrafos vazios mantidas).
- **Unidades não vazias:** 69 no DOCX; 69 no EPUB; 69 linhas no cotejo (incluem título, divisórias e marcações).
- **Unidades com intervenção textual:** 28 (inclui normalização superficial).

## Decisões editoriais e problemas identificados

Corrigida confusão grave: 顧似錦 pede ser tia da criança, não encontrar uma concubina para casar. Mantida a decisão de adiar sua saída do palácio, com anuência de Chu Xingran. O índice sobe **3 pontos percentuais**, chegando a **68%**, sem confundir aumento e total. Corrigida a agência do gesto: Ning acaricia o próprio ventre.

## Método e limite real

Todas as unidades foram alinhadas estruturalmente por ordem. Foi realizada conferência semântica focalizada sobre os trechos de maior risco e correções dirigidas, com preservação dos demais segmentos do EPUB. **Não foi realizada auditoria semântica independente, integral, frase a frase de todas as unidades.** Podem persistir erros de tradução, omissões internas ou problemas de fluência nos trechos não retrabalhados. Não usar o alinhamento estrutural como certificado de fidelidade integral.

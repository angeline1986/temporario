Capítulo 318 — Ajoelhe-se e implore

Por ter uma constituição debilitada e tendente ao frio, Ning Xiaoxiao recebeu do diretor Song a orientação de tomar, todas as noites, uma dose de medicamento para proteger a gestação.

Qiqi levou o remédio ao quarto na hora certa, acordou a preguiçosa Ning Xiaoxiao, deu-lhe o remédio e depois ajudou-a a enxaguar a boca e escovar os dentes. Quando ela estava prestes a voltar a dormir, Xiao Qi apareceu de repente novamente:

【Bip, bip! Anfitriã, anfitriã! Chegou uma nova missão para você!】

【“Mandar a Consorte Duan para o outro mundo em 48 horas.” Recompensa: acréscimo de 5 pontos percentuais ao índice de desvio da trama. Penalidade por fracasso: perda de 20% da vitalidade da anfitriã.】

Ning Xiaoxiao terá que lidar com a cascavel da Consorte Duan mais cedo ou mais tarde.

Ela simplesmente não esperava que Xiao Qi tomasse a iniciativa de lhe dar tal tarefa.

【Aquela cascavel está pulando de um lado para outro bem debaixo do meu nariz há séculos. Faz tempo que quero mandá-la para o outro mundo! Só me contive porque você disse que as regras me proíbem de usar meus poderes especiais para eliminar antes da hora personagens importantes do livro.】

【O que há de errado com você hoje? Por que você me mandou um presente tão grande de repente? Eu estava me sentindo entediada durante a gravidez e queria fazer algo divertido.】

Xiao Qi explicou: 【O sistema detectou que a Consorte Duan pretende ferir o bebê que a anfitriã carrega. A Agência de Administração do Espaço-Tempo proíbe, sob qualquer circunstância, que crianças inocentes sejam envolvidas nisso.】

【Por isso lhe enviaram essa missão. Em outras palavras, estão ajudando você a proteger a gravidez!】

Ao ouvir isso, Ning Xiaoxiao comentou que a Administração do Tempo e do Espaço era bastante humana.

Mas não era exatamente por bondade da Agência de Administração do Espaço-Tempo.

Se Xiao Qi permitisse que a Consorte Duan machucasse Ning Xiaoxiao, Qi Meijuan certamente mandaria desmontá-lo e reconstruí-lo se soubesse!

Para Ning Xiaoxiao, uma vez que Xiao Qi lhe designara aquela missão, tirar a Consorte Duan de cena seria moleza.

Quando as concubinas imperiais vierem prestar suas homenagens a Ning Xiaoxiao amanhã, ela só precisa mudar algumas palavras para fazer com que a Consorte Duan comece a cortejar a morte de várias maneiras:

Por exemplo, fazer a Consorte Duan beber água quente sem parar durante a visita de cumprimentos;

Ou talvez ela devesse ser obrigada a comer todas as mesas e cadeiras do Palácio Fengluan na frente de todas as concubinas.

Ou fazê-la plantar bananeira e abrir um espacate tão violento que acabasse se partindo ao meio.

Esquema ilustrativo da Consorte Duan fazendo um espacate de cabeça para baixo:

(ጿ ኈ ቼ)

Com uma imagem tão absurda em mente, Ning Xiaoxiao dormiu excepcionalmente bem naquela noite.

Naquele momento, Ning nem imaginava que a intervenção de Gu Sijin faria a diversão planejada simplesmente...

*Estalo*, ┓(￣□￣｜┏

... desaparecer!

*

Era tarde da noite no Palácio de Zhaochun.

Durante muitos anos, a Consorte Duan teve o hábito de se levantar no meio da noite para beber água.

Ao despertar, ainda sonolenta, naquela noite, ela percebeu que o jarro de jade roxo sobre a mesinha ao lado da cama estava vazio. Então chamou:

"Alguém, traga-me uma xícara de água morna."

Naquela noite, Xiu’er estava encarregada da vigília. Normalmente, bastava a consorte chamá-la para que viesse imediatamente atendê-la.

Mas, por mais que gritasse, não obtinha resposta.

Sua boca já estava seca, e agora sua garganta estava ressecada, então ela ficou ainda mais impaciente e praguejou:

"Xiu’er! Onde você esteve?"

'Rangido'

Assim que ela terminou de proferir palavrões, a porta do quarto foi aberta.

Xiu’er segurava um pote de jade na mão, baixou a cabeça e caminhou até o leito da Consorte Duan, enchendo sua xícara com água.

A Consorte Duan olhou para ela com seus olhos de fênix, pegou sua xícara, terminou sua água e perguntou:

"Aquilo já foi colocado na abertura de ventilação da colina artificial atrás do Palácio Fengluan?"

Xiu’er se comportou de maneira muito estranha hoje. Ela não respondeu à pergunta da Consorte Duan, mas, em vez disso, colocou o vaso de jade sobre a mesinha e saiu apressadamente.

A Consorte Duan gritou para a figura que se afastava: "Xiu’er! Você é muda?! Estou lhe fazendo uma pergunta! Volte!"

— Consorte Duan, não se irrite.

Logo após Xiu’er sair, outra voz feminina suave respondeu ao acesso de raiva da Consorte Duan.

A Consorte Duan franziu a testa e olhou fixamente para a porta, apenas para ver Gu Sijin entrar com um sorriso.

Gu Sijin fez uma leve reverência à Consorte Duan junto à porta e, ao entrar, fechou-a delicadamente atrás de si.

"É você? O que te traz a me ver no meio da noite?"

Gu Sijin permaneceu em silêncio, mas sorriu, depois caminhou graciosamente até a mesa no centro do salão, sentou-se e acendeu casualmente uma vela vermelha.

Uma luz amarela e quente tremeluzia, preenchendo a penumbra do lugar.

O rosto de Gu Sijin, de uma beleza estonteante e de outro mundo, estava meio escondido na escuridão e meio visível à luz de velas, conferindo um toque misterioso à cena.

A Consorte Duan ficou furiosa. "Saia! Como ousa invadir o Palácio de Zhaochun sem minha permissão? Não pense que só porque tem uma relação próxima com a Imperatriz, pode agir com arrogância na minha frente."

Gu Sijin permaneceu em silêncio, apenas virando a cabeça para olhá-la com um sorriso.

Aquele sorriso arrepiante fez o coração da Consorte Duan estremecer, de modo que ela só conseguiu elevar a voz para projetar uma aura imponente:

"Eu te disse para sair! Você não me ouviu? Você..."

De repente, seus gritos estridentes cessaram abruptamente.

Era como se algo lhe obstruísse o peito; não conseguia respirar.

Ela agarrou com força a gola de sua camisola, respirando pesadamente e com avidez, o rosto corado e a respiração ofegante.

Gu Sijin então começou a falar calmamente:

"O pó medicinal que Sua Majestade obteve do Médico Venenoso é realmente muito eficaz."

"O pó em si tem uma fragrância suave, mas quando submerso em água, dissolve-se perfeitamente, tornando-se incolor e inodoro."

A Consorte Duan olhou fixamente, com os olhos arregalados, para o vaso de jade sobre a mesa e para a tigela que já havia esvaziado. Um medo avassalador surgiu de todas as direções e a dominou.

Ela entrou em pânico e caiu da cama sem querer. Em seguida, ficou deitada no chão, tentando desesperadamente limpar a garganta.

Com as unhas finas, compridas mais de uma polegada, ela começou a enfiar os dedos na garganta na tentativa de provocar vômito. Feriu a garganta, partiu as unhas e só conseguiu expelir um pouco da água que bebera, misturada a sangue.

Gu Sijin se levantou e caminhou até ela, olhando-a com um olhar ligeiramente piedoso:

"Que patético."

"Você não sabe o quão potente é o remédio que você implorou para ter?"

"Mesmo que colocada na colina artificial, essa coisa poderia ser levada pelo vento oeste até o Palácio Fengluan e ferir o filho de Xiaoxiao."

— Você bebeu tudo de uma vez. Como ainda pode ser tão ingênua a ponto de acreditar que conseguirá sobreviver só por vomitar?

Até mesmo a pessoa mais capaz fica perplexa e impotente diante da ameaça da morte.

A voz da Consorte Duan estava rouca enquanto ela se esforçava com todas as suas forças para gritar em direção à porta:

"Socorro! Socorro! Alguém me salve!"

— Hahaha! Chamar alguém? — Gu Sijin zombou. — Quem viria? Xiu’er dispensou todos. Aqui só estamos nós duas.

Ela piscou seus olhos brilhantes e claros para a Consorte Duan duas vezes, depois ergueu levemente uma sobrancelha. "No entanto, você também pode me implorar para salvá-la. Que tal isso? Ajoelhe-se e implore, me faça feliz, e eu pouparei sua vida."

Nesse momento, a Consorte Duan já não se importava com as aparências.

Naquele momento, o mais importante era salvar a própria vida.

Então ela se obrigou a ajoelhar-se diante de Gu Sijin, seu corpo já mole como uma poça de lama, e prostrou-se repetidamente.

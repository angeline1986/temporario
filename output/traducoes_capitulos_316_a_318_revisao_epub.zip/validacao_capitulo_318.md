# Validação do capítulo 318

- **Original:** `novel_capitulos_301_a_360(20261107-181903).docx` (DOCX chinês).
- **Tradução-base:** `novel capitulos 301 a 360 - ch.epub` (EPUB português, `index_split_017.html`).
- **Índices absolutos base zero do DOCX:** 1384–1460 (lacunas para parágrafos vazios mantidas).
- **Unidades não vazias:** 75 no DOCX; 75 no EPUB; 75 linhas no cotejo (incluem título, divisórias e marcações).
- **Unidades com intervenção textual:** 34 (inclui normalização superficial).

## Decisões editoriais e problemas identificados

Missão para eliminar a Consorte Duan em 48 horas, recompensa +5 pontos percentuais e penalidade -20% da vitalidade. Corrigidos pensamento 【】, instituição do Espaço-Tempo, narração em primeira pessoa indevida, gênero e a ação de induzir vômito; preservados o desenho em caracteres e a marcação de divisão.

## Método e limite real

Todas as unidades foram alinhadas estruturalmente por ordem. Foi realizada conferência semântica focalizada sobre os trechos de maior risco e correções dirigidas, com preservação dos demais segmentos do EPUB. **Não foi realizada auditoria semântica independente, integral, frase a frase de todas as unidades.** Podem persistir erros de tradução, omissões internas ou problemas de fluência nos trechos não retrabalhados. Não usar o alinhamento estrutural como certificado de fidelidade integral.

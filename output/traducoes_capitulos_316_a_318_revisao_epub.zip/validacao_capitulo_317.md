# Validação do capítulo 317

- **Original:** `novel_capitulos_301_a_360(20261107-181903).docx` (DOCX chinês).
- **Tradução-base:** `novel capitulos 301 a 360 - ch.epub` (EPUB português, `index_split_016.html`).
- **Índices absolutos base zero do DOCX:** 1315–1382 (lacunas para parágrafos vazios mantidas).
- **Unidades não vazias:** 66 no DOCX; 66 no EPUB; 66 linhas no cotejo (incluem título, divisórias e marcações).
- **Unidades com intervenção textual:** 36 (inclui normalização superficial).

## Decisões editoriais e problemas identificados

O título não informa literalmente que Gu Sijin matou alguém nesse capítulo: “volta a atacar” conserva o tom sem antecipar um desfecho. Corrigidos presentes de congratulação, hipótese de dissolver o harém versus ação consumada, status de Gu Sijin como Nobre Dama, e o sentido sombrio de “reunir” Xiu’er e seu amado no caminho da morte.

## Método e limite real

Todas as unidades foram alinhadas estruturalmente por ordem. Foi realizada conferência semântica focalizada sobre os trechos de maior risco e correções dirigidas, com preservação dos demais segmentos do EPUB. **Não foi realizada auditoria semântica independente, integral, frase a frase de todas as unidades.** Podem persistir erros de tradução, omissões internas ou problemas de fluência nos trechos não retrabalhados. Não usar o alinhamento estrutural como certificado de fidelidade integral.

Capítulo 316 — O índice de desvio da trama se aproxima de 70%

Embora já suspeitasse disso desde o início, Lu Linyuan ficou extasiado ao ouvir a confirmação do diretor Song.

"Será mesmo verdade?"

— Não há dúvida! Exerço a medicina há décadas e tenho plena confiança no meu diagnóstico. Sua Majestade, a imperatriz, está grávida há pouco mais de um mês!

Lu Linyuan estava feliz feito um bobo. Apertou a mão de Ning Xiaoxiao e seus olhos pareceram se encher de lágrimas.

Ele queria dizer algo, mas seus lábios tremiam enquanto tentava falar, e no fim, restou-lhe apenas um silêncio alegre.

Ele era o imperador e precisava controlar suas emoções; não podia chorar na frente de estranhos.

Qiqi e as outras ficaram radiantes e correram em círculos. Algumas foram buscar almofadas para Ning Xiaoxiao se apoiar, enquanto outras foram fechar as janelas para evitar que ela pegasse um resfriado. Em pouco tempo, todo o Palácio Fengyi estava repleto de atividade.

Quem visse aquela agitação sem saber de nada talvez pensasse que a boa notícia fosse de Gu Sijin.

Como era de se esperar, Gu Sijin, a chorona, foi a primeira a desabar em lágrimas.

Ela parecia ainda mais agitada do que Lu Linyuan, chorando incontrolavelmente como se a criança na barriga de Ning Xiaoxiao fosse dela...

— Quando a criança nascer, quero ser a tia dela. Você não pode me negar isso.

Todos estavam radiantes de sorrisos, exceto Ning Xiaoxiao, que olhou para sua barriga lisa incrédula e disse:

— Então... eu estou grávida mesmo?

*

A notícia da gravidez de Ning Xiaoxiao espalhou-se pelo palácio como uma brisa suave no início do verão.

Por um tempo, todos no palácio a rodeavam, sem mencionar Lu Linyuan, que estava sempre por perto.

Para que ela pudesse cuidar da gestação com tranquilidade, Lu Linyuan voltou a agir como um “imperador incapaz de governar”, aos olhos dos outros.

Mudou-se para o Palácio Fengluan e ordenou que os memoriais da corte fossem enviados para lá, onde os examinaria e despacharia.

O médico imperial afirmou que os três primeiros meses de gravidez são os mais importantes e requerem proteção para evitar o aborto espontâneo.

Chegou a suspender as audiências matinais por três meses. Ministros com assuntos urgentes deveriam procurá-lo individualmente em um salão lateral do Palácio Fengluan.

Além dele, Gu Sijin também estava muito preocupado com essa gravidez.

Ela decidiu adiar sua partida do palácio quase sem qualquer hesitação ou angústia.

Ela queria estar ao lado de Ning Xiaoxiao durante esse período tão importante de sua vida, para garantir um parto seguro, para que ela pudesse partir em paz.

Ela contou a Ning Xiaoxiao sobre isso, e Ning Xiaoxiao, embora comovida, também a aconselhou:

— Irmã, você não precisa ficar por minha causa. Você e o comandante Chu já perderam tanto tempo! Agora que finalmente podem ficar juntos, se perderem essa oportunidade de novo por minha causa, não seria...

— Atrasar o quê? — Gu Sijin acariciou o ventre de Ning, sorrindo. — Você não está gestando um Nezha! Quanto tempo acha que isso vai me atrasar? Pare de pensar bobagens e cuide bem do herdeiro imperial. Ainda terá muitos dias de felicidade pela frente.

Embora Gu Sijin tenha dito isso a Ning Xiaoxiao, ela também tinha suas próprias preocupações.

Afinal, o Festival das Lanternas estava a apenas dois dias de distância e, de acordo com o combinado, esse deveria ter sido o dia em que ela deixaria o palácio.

Ela sabia há quanto tempo Chu Xingran esperava por esse dia.

Tomar essa decisão de última hora era, de certa forma, injusto com ele.

Assim, enquanto Chu Xingran fazia suas rondas pelo palácio naquela noite, ela ficou de guarda na entrada do Palácio Fengyi.

Chu Xingran liderava a equipe de patrulha. Ao avistar Gu Sijin, ordenou que os Guardas Imperiais continuassem patrulhando a rota original. Diminuiu o passo e esperou até que a força principal estivesse bem distante antes de se aproximar de Gu Sijin.

Naquele dia, Gu Sijin parecia diferente do habitual.

Antes, sempre recebia Chu Xingran sorrindo; naquela noite, porém, estava séria.

"O que houve?" Ele acariciou suavemente os cabelos da garota, que estavam despenteados pela brisa da noite. "Você parece preocupada?"

Gu Sijin não tinha intenção de ficar dando voltas com ele, então foi direto ao ponto: "Xiaoxiao está grávida."

Chu Xingran assentiu com a cabeça: "É uma ocasião de grande alegria que Sua Majestade a Imperatriz esteja grávida, é claro que eu sei disso."

"Como você sabe, Xiaoxiao não tem parentes próximos no palácio. Além do Imperador, sou a única pessoa com quem ela pode conversar. Agora que ela está grávida, eu..."

— Você quer ficar para cuidar dela e só sair do palácio depois que ela der à luz em segurança? — Chu Xingran completou por ela.

Gu Sijin sentiu-se em dívida com ele, então baixou os olhos e assentiu levemente, sem ousar encará-lo nos olhos.

Ela pensou que Chu Xingran a repreenderia, mas, para sua surpresa, ele riu alto.

Ele cutucou os lábios de Gu Sijin com o dedo indicador, curvando-os desajeitadamente em um sorriso.

— Por que essa cara de desânimo? Está com medo de eu ficar zangado?

Gu Sijin ergueu os olhos marejados e disse fracamente:

— Sei que ficar comigo sempre foi seu desejo. Se eu adiar nossos planos assim, é natural que você fique chateado.

"Era isso que você também esperava." Chu Xingran a corrigiu, estendendo a mão para tocar sua testa, com voz suave:

"Menina tola, tudo o que sei é que você está destinada a ser minha, e isso basta. Quando o Imperador me disse que me daria você, o peso enorme no meu coração desapareceu."

“Sei que você e Sua Majestade a Imperatriz têm um laço profundo. Portanto, desde o momento em que soube que Sua Majestade a Imperatriz estava grávida, eu sabia que você escolheria ficar até que ela desse à luz em segurança.”

Gu Sijin ficou tocada pela compreensão de Chu Xingran. — Você não está nem um pouquinho aborrecido?

"Haha, por que ficar com raiva?" Chu Xingran riu casualmente.

"Você é minha esposa, então, naturalmente, sempre colocarei sua felicidade em primeiro lugar."

"Além disso, Sua Majestade a Imperatriz fez muito por nós. Se você optar por deixá-la agora, não será como a Jin'er que eu conheço."

Sob a luz tênue do luar, os dois ficaram à sombra de uma árvore e se abraçaram levemente.

Quem é verdadeiramente afetuoso nunca precisa de mil palavras para se expressar.

Às vezes, um simples olhar basta para compreendermos os pensamentos e sentimentos um do outro.

Encontrar alguém que te entenda e te valorize dessa forma, mesmo depois de você ter passado por tantas dificuldades, é, em última análise, uma bênção para ambos.

*

Ao cair da noite, Lu Linyuan, que havia passado o dia servindo sua jovem esposa, estava bastante exausto.

Cuidar de uma grávida dava muito mais trabalho do que passar um dia inteiro “cultivando” sua jovem esposa na cama.

Deitada nos braços dele, Ning Xiaoxiao ouvia sua respiração regular e acariciava o próprio ventre. Era para estar tranquila, mas uma ansiedade inexplicável lhe apertava o peito.

【Bip, bip! Parabéns, anfitriã! Missão “Impedir Gu Sijin de deixar o palácio” concluída. O índice de desvio da trama aumentou 3 pontos percentuais e agora soma 68%, quase 70%! Parabéns, anfitriã: você está mais perto de voltar para casa!】

【E um parabéns especial pela chegada do bebê!】

Ao ouvir as felicitações, Ning Xiaoxiao ficou ainda mais preocupada:

【Xiao Qi, há dias estou com uma sensação ruim.】

【Se eu tiver este bebê e depois voltar ao mundo moderno, vou perder meu marido e meu filho, não vou?】

【Mas, se eu não voltar, o que será dos meus pais?】

Xiao Qi: 【Anfitriã, essa pergunta está além da minha competência. Nunca fiquei grávido, então não sei responder. Só sei que as coisas acabam se ajeitando. Aproveite cada dia. E agora que engravidou, não dá para se arrepender depois do parto e enfiar o bebê de volta na barriga, dá?】

Ning Xiaoxiao: 【... Esqueça. Finja que não perguntei. Pode se retirar.】

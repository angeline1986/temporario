# Validação — capítulo 51

- **Fonte primária:** `novel_capitulos_1_a_60(20261103-183111).docx` (chinês tradicional).
- **Limites no DOCX:** parágrafos 3828 a 3918, encerrando antes do capítulo 52.
- **Unidades originais não vazias (título incluído):** 88.
- **Linhas de cotejo:** 88.
- **Unidades sem tradução:** 0.
- **Unidades extras no cotejo:** 0.
- **Correspondência estrutural:** 1:1, preservando parágrafos do original como unidades de cotejo. Quando uma fala foi dividida para leitura em português, a unidade correspondente permanece reunida no CSV.
- **Nomes, gênero e terminologia:** Ning Xiaoxiao, Lu Linyuan, Lu Yiqiu, Sanfu, Gu Sijin, Xiao Qi, Atendente Gu, príncipe Jing.
- **Revisão textual:** tradução redigida diretamente do chinês, priorizando integridade do sentido, humor, pensamentos entre 【 】 e continuidade narrativa.
- **Ressalva:** a conferência de cobertura é automática; a revisão semântica foi realizada no processo de tradução, não constitui auditoria linguística independente ou garantia de equivalência perfeita.

# Capítulo 51 — Escondendo um homem no guarda-roupa do tirano

O Palácio Chaoyang era rigorosamente vigiado. Para qualquer outra pessoa, entrar ali sem ser notada seria mais difícil do que subir aos céus.

Mas, para Ning Xiaoxiao, aquilo era moleza.

Ela vivia circulando na presença do imperador, e os guardas e criadas já conheciam muito bem seu rosto.

Além disso, naquele dia Sanfu havia alertado especialmente as criadas do Palácio Chaoyang para que abrissem bem os olhos e reconhecessem aquela galinha caipira prestes a se transformar em fênix. Por isso, ao vê-la, todas a trataram com uma gentileza especial.

— Ora, Xiaoxiao! O que a traz aqui?

Uma criada com uma pinta entre as sobrancelhas veio recebê-la, segurou-a pelo braço e assumiu uma intimidade de velhas amigas.

— Na época em que estávamos no alojamento das criadas, eu era sua melhor amiga! Depois que você foi cuidar da Atendente Gu, fiquei sem ninguém com quem conversar. Que tédio!

Ning Xiaoxiao ficou um bom tempo encarando a pinta entre as sobrancelhas da moça.

Minha senhora, quem é você mesmo?

E por que parece um pouco com a atriz Siqin Gaowa?

Ah, tanto faz. Quem quer que fosse, Ning precisava entrar nos aposentos do tirano. Se a outra queria fingir intimidade, melhor ainda.

Assim, retribuiu o sorriso:

— E não foi justamente para lhe fazer companhia que vim hoje?

Pegou a vassoura das mãos da criada.

— Olhe só como você está cansada! Até ficou com a pele enrugada. Que tal eu varrer o pátio enquanto você vai cuidar de outra coisa?

— De jeito nenhum! — A criada se apressou em recuperar a vassoura. — Sua posição agora é diferente. Como eu poderia deixar que fizesse esse serviço?

Sem entender do que ela falava, Ning Xiaoxiao fingiu estar ofendida:

— Se não me deixar ajudar nem com uma coisinha dessas, é porque não me considera sua irmã!

— Não fique brava! Então faça assim: se quer mesmo me ajudar, vá limpar as mesas e cadeiras do salão principal. É um trabalho mais leve.

Os olhos de Ning Xiaoxiao brilharam.

— Pode deixar! Vou esfregar até as mesas e cadeiras brilharem como espelhos!

Nem ela imaginara que conseguiria entrar com tanta facilidade.

O salão principal ficava separado dos aposentos de dormir por um longo corredor. Ning Xiaoxiao fingiu limpar as mesas e os bancos e, assim que a criada que varria o pátio desapareceu de seu campo de visão, disparou para o quarto do tirano.

Lu Linyuan não era apenas obcecado por limpeza; também tinha uma leve mania de organização.

Havia três guarda-roupas em seu quarto: um para as roupas de cima, outro para as calças e um terceiro reservado às roupas de baixo.

Com a desenvoltura de quem conhecia o lugar, Ning Xiaoxiao abriu o armário das roupas íntimas. Diante dela surgiu uma coleção de cuecas amarelo-imperiais, em todos os modelos e tons possíveis.

Tonta diante de tantas opções, pegou uma qualquer e escondeu-a dentro da manga.

Missão cumprida! Mas, quando estava prestes a fugir, ouviu um ruído na porta do quarto.

Droga!

Como ele voltou tão depressa?

Se fosse pega ali, estaria acabada!

Sem alternativa, Ning Xiaoxiao entrou no guarda-roupa e se viu obrigada a uma intimidade indesejada com as cuecas do tirano.

Não havia tantas peças naquele armário, de modo que sobrava espaço para ela.

Cobriu a boca e o nariz, tentando respirar o mais silenciosamente possível.

Ficou atenta aos sons do lado de fora. Se Lu Linyuan voltara àquela hora, provavelmente não era para dormir. Talvez apenas quisesse trocar de roupa ou buscar alguma coisa antes de sair de novo.

Só que então ouviu alguém remexendo gavetas e armários.

Espiando pela fresta da porta, viu um jovem eunuco muito bonito, vestido com o uniforme do palácio.

Ele abriu a gaveta da cabeceira de Lu Linyuan e começou a procurar alguma coisa.

Pouco depois, tirou dali várias notas de prata e as enfiou dentro da roupa.

【Caramba! Esse eunuquinho é corajoso mesmo! O sujeito tem coragem de roubar Lu Linyuan? Não tem medo de ser esquartejado por cinco cavalos?】

【Ei, isso não é nada bom! Talvez Lu Linyuan nem perceba o sumiço de uma cueca, mas, se perder dinheiro, vai investigar com certeza! E, se ninguém tiver visto esse eunuco, a única pessoa que entrou escondida no Palácio Chaoyang hoje terá sido eu!】

【Não, não, não! Preciso dar um jeito de impedir esse sujeito!】

Enquanto Ning Xiaoxiao pensava em como deter o jovem eunuco, outro ruído veio da porta.

Dessa vez, ouviu a voz de Lu Linyuan.

— Vou descansar um pouco. Tragam os memoriais da sala de estudos.

【Morri! Morri! O dono da casa voltou!】

Ela entrou em pânico. O jovem eunuco ficou ainda mais apavorado.

Com os grandes olhos úmidos, ele procurou um esconderijo por toda parte, até fixar o olhar no armário onde Ning Xiaoxiao estava.

【Nem pense em vir para cá!】

*Clique!*

O rapaz escancarou a porta do guarda-roupa. Os dois se encararam, constrangidos.

O jovem eunuco ficou atônito por um instante e depois sorriu, acenando:

— Que coincidência! Você também veio roubar?

E já foi se enfiando no armário.

— Socorre um colega de profissão! Abre um espacinho!

Antes que Ning Xiaoxiao pudesse reagir, ele se agachou ao lado dela e fechou a porta.

O rapaz era uma cabeça e meia mais alto que ela. Espremido no armário, não parava de mudar de posição.

O problema não era ele se mexer, mas o fato de que, a cada movimento, derrubava as cuecas imperiais cuidadosamente empilhadas.

E todas caíam bem na cabeça de Ning Xiaoxiao.

Furiosa, ela lhe deu um beliscão forte.

— Dá para ficar quieto?!

Apontou para as duas cuecas imperiais penduradas na própria cabeça e lançou ao rapaz um olhar ressentido.

Ele cobriu a boca para abafar uma risadinha e sussurrou:

— Desculpa, desculpa. É minha primeira vez roubando, então estou nervoso. Na próxima vai ser melhor.

Ning Xiaoxiao: ???

Mas que criatura sem noção era aquela?!

Ela ia começar a xingá-lo quando o rapaz tapou sua boca com a mão e fez um gesto de silêncio.

— Shh! Cala a boca! Ele entrou...

Sem ousar falar, Ning Xiaoxiao só pôde reclamar em pensamento:

【Dá para tirar essa mão da minha boca? Você vai me sufocar!】

【E para de esfregar a cueca dele na minha cara!】

【Seu cotovelo está esmagando meu peito!】

Na verdade, Lu Linyuan havia voltado naquele momento justamente para apanhar Ning Xiaoxiao em flagrante.

Quando não viu ninguém no quarto, pensou a princípio que ela já tinha ido embora.

Até ouvir aquelas reclamações tão familiares.

Do que aquela maluca estava resmungando agora?

Não bastava vir roubar as cuecas dele sozinha? Precisava trazer um comparsa e formar uma quadrilha?

Lu Linyuan lançou um olhar de soslaio ao armário de roupas íntimas e, num salto rápido como um raio, chegou diante dele e abriu a porta de supetão.

— Puta que pariu!

Ning Xiaoxiao e o jovem eunuco despencaram do guarda-roupa sem qualquer aviso, caindo empilhados aos pés de Lu Linyuan.

O rapaz ficou por baixo e Ning Xiaoxiao por cima. Presas no penteado dela, uma de cada lado e em perfeita simetria, estavam as duas cuecas preferidas do imperador...

Lu Linyuan rugiu:

— Insolentes! Em plena luz do dia, o que vocês dois estão fazendo escondidos no meu guarda-roupa?

【Estou morta! Estou morta!】

No meio do desespero, Ning Xiaoxiao percebeu que estava sentada em cima do jovem eunuco e teve uma ideia.

【Desculpa, eunuquinho! Tomara que na próxima vida você consiga ser um homem de verdade!】

Imitando os movimentos de defesa pessoal feminina que vira em vídeos, ela imobilizou o rapaz que estava embaixo dela.

Ele soltou gritos de dor. Ning Xiaoxiao, por sua vez, assumiu a postura imponente de uma heroína que não devia nada a homem nenhum:

— Quietinho! Majestade, esta criada flagrou esse eunuco roubando seu dinheiro. Eu estava justamente tentando prendê-lo!

O jovem implorou por clemência e ergueu a cabeça para olhar Lu Linyuan, com uma expressão digna de pena:

— Irmão! Que espécie de tirana você anda criando aqui no palácio...?

— Aaaah! Dói, dói, dói!

Ning Xiaoxiao: ???

Nani?!

Como foi que você o chamou?

Irmão????

Ela olhou para Lu Linyuan, depois para o jovem eunuco que mantinha imobilizado sob o corpo, e sentiu que sua cabeça estava prestes a explodir...

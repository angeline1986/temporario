# Capítulo 53 — Quem presenteia com cuecas deixa um perfume nas mãos

Lu Linyuan pretendia obrigar os dois a ficar de pé por pelo menos duas horas. Mas, depois de apenas um quarto de hora, os cabelos de Ning Xiaoxiao, antes leves e soltos, já estavam grudados de suor em seu pescoço.

Não podia deixar aquela pequena ancestral sofrer uma insolação!

Então gritou pela janela: — Só de olhar para vocês já fico irritado! Sumam da minha frente, e quanto mais longe, melhor!

Ning Xiaoxiao parecia um coelho pronto para disparar. Assim que Lu Linyuan deu a ordem, arrancou numa corrida de cem metros e desapareceu.

Lu Yiqiu também se preparou para fugir, mas Lu Linyuan se apoiou com uma mão na moldura da janela, saltou com sua técnica de leveza e aterrissou bem à frente dele, bloqueando a passagem.

Lu Yiqiu aplaudiu com um sorriso bobo. — Uau! Suas habilidades melhoraram de novo, irmão! Que incrível!

Deu alguns passinhos discretos em direção à saída. — Continue treinando, irmão. Não quero atrapalhar!

Terminou de falar e tentou correr, mas Lu Linyuan o agarrou pelo colarinho e o puxou de volta, arrancando rapidamente as notas de prata que ele guardava na manga.

— Irmão! Você... você está jogando sujo!

— No começo do mês, o Departamento de Assuntos Internos lhe deu mil taéis de prata de mesada. Os outros príncipes recebem apenas seiscentos. Isso sem contar o que eu lhe dou por fora de tempos em tempos. Quase dois mil taéis por mês ainda não bastam?

Lu Yiqiu fez um biquinho, com o rosto cheio de mágoa. — Mas no mês passado houve aquelas enchentes no sul, e eu doei quinhentos taéis de prata...

— Você faz a doação e eu pago a conta? — Lu Linyuan apertou os lábios emburrados do irmão. — Que fantasias são essas que passam por essa sua cabeça o dia inteiro? Além disso, se está precisando de dinheiro, pode me pedir. Pegar sem pedir é roubo. Não vou deixar que adquira esse hábito.

— Mas aquela criada roubou sua cueca agora há pouco, e você não disse nada a ela!

— Eu...

— Se pegar sem pedir é roubo, então você está dizendo que concordou em dar a cueca para ela?

Lu Yiqiu fez uma careta para ele. — Tsc! Se não quer me dar dinheiro, tudo bem! Vou conversar com a imperatriz-viúva e aproveitar para contar que você anda dando cuecas de presente às criadas!

Dito isso, virou-se e partiu a passos rápidos. Lu Linyuan entrou em pânico e o chamou de volta: — Volte aqui!

Atirou as notas de prata no rosto do irmão. — Se ousar mencionar o que aconteceu hoje outra vez, corto sua mesada por um ano inteiro!

Lu Yiqiu abriu um sorriso de orelha a orelha. Guardou o dinheiro, deu um abraço apertado em Lu Linyuan e estalou um beijo sonoro em sua bochecha.

— Mua!

— Pode ficar tranquilo, irmão! Embora eu não compreenda esse seu pequeno fetiche de “quem presenteia com cuecas deixa um perfume nas mãos”, respeito suas escolhas! Não vou contar para ninguém, prometo!

Lu Linyuan: ...

Não quero mais esse irmão. Alguém aceita? Vendo baratinho...

---

De volta ao Palácio Zhongcui, Ning Xiaoxiao ofereceu a cueca em sacrifício e conseguiu finalmente trocar com Xiao Qi pela pulseira de jadeíta que sua mãe lhe dera.

Levou a pulseira ao nariz e a cheirou. Ainda parecia haver nela um vestígio de perfume.

Era o cheiro de casa.

Uma saudade infinita da família inundou seu coração e deixou seus olhos vermelhos.

Ela depositou um beijo delicado na pulseira e murmurou, quase sem voz:

— Pai, mãe... Eu vou voltar. Prometo!

— Esperem por mim!

Nos dois dias seguintes, usou a pulseira durante o dia. Como sabia que se mexia muito ao dormir e que as camas antigas eram duras, tinha medo de bater a peça e danificá-la. Por isso a tirava à noite e a deixava ao lado da cama.

A jadeíta da pulseira era de qualidade excepcional. Quando Qiqi e as outras a viram enquanto Ning Xiaoxiao trabalhava, cercaram-na de elogios.

— Uau! Nunca vi uma pulseira de jadeíta tão linda! Xiaoxiao, quem lhe deu?

Diante dos olhares invejosos de todas, Ning Xiaoxiao respondeu com imenso orgulho: — Foi minha mãe. É parte do meu enxoval de casamento.

Cailian viu a roda de conversa e se aproximou também. Depois de dar uma olhada na pulseira, disse com desprezo: — Tsc! E daí? Quando minha senhorita ainda vivia na residência da família, me presenteava com joias sem parar. Algumas eram de qualidade ainda melhor!

Qiqi lançou-lhe um olhar. — Então por que nunca vimos você usando nenhuma?

— Vim ao palácio para servir à minha senhorita, não para ficar me exibindo toda enfeitada! Não sou como certas pessoas! — rebateu Cailian.

Ning Xiaoxiao não tinha paciência para discutir. Levou Qiqi e as demais para alimentar a alpaca e deixou Cailian sozinha, parada ali numa situação constrangedora.

Naquela noite, depois que Ning Xiaoxiao adormeceu, Cailian se levantou durante a segunda vigília noturna para ir ao banheiro. Ao passar, lançou um olhar ao quarto de Ning e teve uma ideia maldosa.

Não suportava o jeito arrogante de Ning Xiaoxiao. Assim, entrou furtivamente no quarto e roubou a pulseira que ela deixara ao lado da cama.

Pensou que, afinal, todas as pulseiras de jadeíta eram parecidas. Se roubasse aquela e passasse a usá-la, ninguém teria provas de que a tirara de Ning Xiaoxiao.

Na manhã seguinte, quando acompanhou Gu Sijin para prestar cumprimentos à imperatriz, estava usando a pulseira.

Naquele dia, a imperatriz havia recebido uma remessa de lichias da variedade Feizixiao, oferecidas como tributo por Diannan, e distribuiu algumas entre as consortes.

A imperatriz explicou sorrindo: — Esta remessa de lichias Feizixiao veio de Diannan em apenas três dias, trazida por mensageiros a cavalo. Foram conservadas em gelo durante a viagem, de modo que chegaram tão frescas quanto se tivessem acabado de ser colhidas. A polpa é firme, suculenta e deixa um perfume delicioso na boca. Experimentem.

Todas descascaram as lichias e as provaram, elogiando o sabor sem parar.

Só a Consorte Nobre cuspiu a fruta depois da primeira mordida. — Doce demais.

Ergueu os olhos amendoados, cheios de uma doçura insinuante, para a imperatriz. — Vossa Majestade acha que basta ser doce para ser bom? Em tudo na vida, o excesso é tão ruim quanto a falta. Quando algo é doce demais, chega a enjoar. Talvez só alguém como a imperatriz, tão acostumada a uma vida amarga, consiga apreciar tamanho excesso de açúcar.

Parecia que, se passasse um dia sem provocar a imperatriz, perderia toda a alegria de viver.

Gu Sijin, em mais um acesso de seu complexo de santa salvadora, não conseguiu ficar calada. Sorriu para a imperatriz: — Acho estas lichias doces na medida certa, sem serem enjoativas. São excelentes.

— Ora, claro que a Atendente Gu vai achá-las excelentes. — A Consorte Nobre apoiou a cabeça na mão e ergueu uma sobrancelha para ela. — Você serviu o imperador no leito seis vezes em um mês e, no primeiro mês desde sua entrada no palácio, já subiu de Respondente a Atendente. Com todo esse favor imperial, vive mergulhada num pote de mel. Não admira que nem a fruta mais doce lhe pareça enjoativa! Mas, já que gosta tanto, vou lhe conceder as minhas também.

Consciente da posição superior da Consorte Nobre, Gu Sijin só pôde aceitar com um sorriso. — Agradeço a generosidade de Vossa Alteza. Não ousaria recusar tamanha gentileza.

Fez um sinal com os olhos para Cailian, que compreendeu imediatamente e se adiantou para receber as frutas.

Ao pegar as lichias, Cailian deixou à mostra um trecho do antebraço. A Consorte Nobre notou de imediato a pulseira de jadeíta em seu pulso.

— Humm... Essa sua pulseira...?

A Consorte Nobre tomou-lhe a mão e examinou a joia atentamente.

A jadeíta tinha um verde límpido e translúcido, sem impurezas, e uma transparência excepcional. Nem ela, que sempre gostara de artigos luxuosos, tinha visto uma peça tão fina.

— Gostei desta pulseira. Façamos assim: já que fui tão generosa a ponto de dar à sua senhora todo esse saco de lichias Feizixiao, você pode trocar sua pulseira por elas. Não sairá perdendo.

Cailian era valente com os fracos e covarde diante dos poderosos. Como ousaria negar algo que a Consorte Nobre desejava?

Por isso, tirou rapidamente a pulseira e a ofereceu com toda a deferência.

Gu Sijin, porém, tinha visto tudo com clareza.

Ela jamais dera a Cailian uma pulseira de jadeíta.

E aquela peça se parecia muito com a que Ning Xiaoxiao vinha usando nos últimos dois dias.

# Capítulo 52 — Espalhem a notícia: o tirano é um trouxa de primeira!

Ning Xiaoxiao se apressou em ajudar o jovem eunuco a se levantar e até tirou cuidadosamente a poeira da roupa dele. — E-eu não o reconheci, Alteza! Perdoe esta criada pela ofensa!

O rapaz afastou a mão dela e soltou um resmungo indignado.

— Humpf! Não pense que só porque sou bonito você pode se aproveitar de mim!

— Aham, aham. — Lu Linyuan pigarreou, estendeu a mão e agarrou a orelha do rapaz. — Lu Yiqiu, você está ficando muito ousado! Agora anda se fantasiando de eunuco? Não sabia que tinha esse tipo de gosto.

Ao ouvir Lu Linyuan pronunciar o nome do rapaz, Ning Xiaoxiao arregalou os olhos. 【Então este é o príncipe Jing... Lu Yiqiu?】

— Ai! Dói, dói! Irmão, não me bate! — Com uma mão, Lu Yiqiu segurou a que lhe puxava a orelha; com a outra, protegeu o rosto. — Se for bater, pelo menos não acerte minha cara! É com ela que ganho a vida!

Lu Yiqiu era o irmão mais novo de quem Lu Linyuan mais gostava na história original.

Mais adiante na trama, sua mãe consorte seria envenenada por um medicamento do palácio. Manipulado por pessoas mal-intencionadas, ele passaria a acreditar que Lu Linyuan havia planejado tudo e acabaria se tornando um vilão.

Mas o escândalo do falso ginseng fora revelado antes do previsto. Isso significava que sua mãe não morreria envenenada.

Então ele já não teria motivos para passar para o lado sombrio... certo?

Lu Linyuan soltou a orelha do irmão e lhe deu um forte tapa na nuca. — O que veio fazer no meu quarto em plena luz do dia?

Lu Yiqiu encolheu os ombros, esfregou a nuca e abriu um sorriso abobalhado, exibindo dois caninos encantadores. — Hehe! Estava com saudade de você, irmão! Faz tanto tempo que não venho ao palácio... Então entrei escondido para fazer uma surpresa!

Lu Linyuan franziu ligeiramente a testa. Seu olhar dizia, com todas as letras: *Mentira deslavada.*

O irmão sempre fora preguiçoso e despreocupado. Só havia um motivo capaz de fazê-lo procurar o imperador por vontade própria: estava sem dinheiro.

Lu Linyuan começou a revistá-lo de cima a baixo, sem deixar nem a região entre as pernas de fora.

Lu Yiqiu protegeu as partes íntimas com as duas mãos e, corando, apertou os lábios. — Irmão... aí não pode...

Ao ver aquela demonstração de “amor fraternal”, Ning Xiaoxiao de repente começou a torcer pelo casal.

Socorro! Que enredo divino era aquele, com um imperador dominador e um príncipe orgulhosinho?

Alguém podia pegar uma caneta e escrever essa história? Ela queria ler!

Como fujoshi iniciante, já começara a imaginar cenas “doces” da vida dos dois.

E todas aquelas imagens picantes que ela inventava estavam sendo transmitidas diretamente à mente de Lu Linyuan, em gloriosos 1080p de altíssima definição.

Lu Linyuan estremeceu de repulsa e lançou a Ning Xiaoxiao um olhar cortante. — Você! Por que estava escondida no meu guarda-roupa?

Interrompida em suas fantasias, Ning Xiaoxiao só pôde inventar uma desculpa às pressas.

— Respondendo a Vossa Majestade: vim ao Palácio Chaoyang ajudar na limpeza. Mas vi esse pequeno eunuco, que na verdade era o príncipe Jing disfarçado, entrando furtivamente no quarto imperial. Pensei que fosse um ladrão e o segui para capturá-lo...

— Irmão! Ela está mentindo! — Lu Yiqiu a interrompeu. Levantou o braço de Ning Xiaoxiao, puxou a cueca escondida na manga e a sacudiu diante de Lu Linyuan, sorrindo descaradamente. — Olha só! Ela veio foi roubar suas cuecas!

Lu Linyuan: ...

Ning Xiaoxiao: 【... Muito obrigada mesmo, viu?!】

Lu Yiqiu ainda estava saboreando sua vitória quando Ning Xiaoxiao se abaixou, tirou de surpresa a bota dele e a sacudiu. Várias notas de prata dobradas caíram e flutuaram até o chão.

Sob o olhar chocado de Lu Yiqiu, ela recolheu as notas e as ofereceu a Lu Linyuan. — Majestade! O príncipe Jing também não veio porque estava com saudade! Veio roubar seu dinheiro!

Lu Linyuan franziu a testa, tapou o nariz e recuou vários passos. Não tinha a menor intenção de tocar naquelas notas.

Será que a loucura era contagiosa dentro do palácio?

Por que, desde que Ning Xiaoxiao aparecera, todas as pessoas ao redor dele pareciam estar ficando meio esquisitas?

Bastava olhar para os dois para sentir o sangue ferver.

Mas um era seu irmão de sangue e a outra era aquela ancestral que ele precisava tratar com todo cuidado. Não podia punir severamente nenhum dos dois.

Só lhe restou explodir de raiva sem poder fazer grande coisa. Apontou para fora e gritou: — Vocês dois! Vão ficar de castigo, de pé, debaixo do sol!

---

Ficar de pé não era um castigo muito severo, mas o sol do meio-dia no verão era suficiente para deixar qualquer um zonzo.

Ning Xiaoxiao suava em bicas e ainda tinha de aguentar o príncipe Jing, aquele tagarela, falando besteira sem parar junto ao seu ouvido.

— De qual palácio você é criada? Por que nunca te vi antes?

— Você até que é bonitinha, só tem um temperamento horrível.

— Ei, só agora percebi! Por que meu irmão mandou você ficar de castigo comigo? Com aquele gênio dele, não deveria ter mandado te matar na hora?

— Humm... Será que você tem no coração dele a mesma importância que eu?

Lu Yiqiu não parava de tagarelar. Ning Xiaoxiao não tinha a menor vontade de lhe responder.

Desesperado, ele pulou duas vezes no mesmo lugar. — Ei! Estou falando com você! Não pode ao menos me dar atenção? Sou um príncipe, sabia? Mostre um pouquinho de respeito!

Ning Xiaoxiao olhou de lado. 【Ele está tentando fazer charme comigo?】

Pois com ela aquela estratégia não funcionava!

Se Lu Yiqiu não tivesse surgido do nada, ela já teria roubado a cueca do tirano, trocado pela pulseira e estaria esparramada na cama, dormindo o sono dos justos.

Em vez disso, precisava ficar torrando sob o sol do meio-dia com ele!

Diante da cara fechada dela, Lu Yiqiu também pensou em deixá-la em paz.

Mas então percebeu que aquele maço de notas de prata, que Lu Linyuan recusara por ter saído de dentro de sua bota, estava preso à cintura de Ning Xiaoxiao.

Ele encarou o dinheiro e roeu a unha do indicador.

Humm... Precisava recuperar aquela grana!

Então abriu para Ning Xiaoxiao um sorriso descarado. — Ah, vai! Não fica brava, está bem? Quer que eu faça uma careta para você?

Aproximou o cabeção do rosto dela, arregalou os olhos, pôs a língua para fora e contorceu todos os músculos da face numa tentativa de ser engraçado...

Parecia um pervertido.

Os olhos de Ning Xiaoxiao se encheram de horror. 【Será que ele acha isso fofo?】

Como ela não riu, Lu Yiqiu tentou outra abordagem. — Então que tal uma mágica?

Balançou as duas mãos diante dela e, de repente, estendeu uma para trás da orelha de Ning Xiaoxiao, fazendo surgir do nada uma cueca imperial.

— Tcharam! Surpresa! Não é incrível?

Os olhos de Ning Xiaoxiao brilharam ao ver a cueca do tirano. Lu Yiqiu sorriu, orgulhoso. — Você quer, não quer? Hehe! Na verdade, até entendo esse seu gosto peculiar. Afinal, meu irmão é tão perfeito que não seria estranho você estar apaixonada por ele!

Apontou para as notas de prata presas à cintura dela. — Que tal um acordo? Depois de tudo que passamos juntos, somos praticamente companheiros de infortúnio. Eu te dou a cueca do meu irmão, você me dá as notas. Uma troca justa, e ainda ficamos amigos. Que acha?

Sim! Claro que sim!

Sem pensar duas vezes, Ning Xiaoxiao entregou as notas a Lu Yiqiu e arrancou a cueca das mãos dele.

Com a peça enfim em seu poder, sorriu feliz como uma criança.

— A cueca nem é importante! O que esta criada queria mesmo era a honra de se tornar amiga de Sua Alteza, o príncipe Jing!

Lu Linyuan observava tudo em silêncio, através da janela de treliça, com o rosto cheio de pontos de interrogação.

Vocês estão usando *meu* dinheiro e *minha* cueca para fazer amizade?

Quer dizer que, aos olhos de vocês, eu não passo de um trouxa completo?!

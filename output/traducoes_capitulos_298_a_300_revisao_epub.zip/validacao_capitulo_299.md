# Validação — capítulo 299

- Original chinês: `novel_capitulos_271_a_300(20261106-202952).docx`.
- Tradução-base: `novel capitulos 271 a 300 - ch.epub`, `index_split_028.html`.
- Índices do DOCX: 1892–1969 (fim exclusivo: 1970).
- Unidades não vazias: **75**, incluindo título; corpo: **74**.
- Alinhamento estrutural EPUB–DOCX: **74 para 74**.
- Unidades com alterações textuais diretas frente ao EPUB: **27**; posições relativas: 4, 5, 9, 10, 11, 12, 14, 23, 27, 31, 33, 34, 37, 38, 43, 44, 45, 49, 53, 54, 55, 56, 58, 61, 64, 72, 74.

## Decisões editoriais

- Preservados título, ordem dos parágrafos e marcadores, inclusive notas da autora.
- Corrigidos erros evidentes de sujeito, gênero, títulos e inconsistências de tradução identificadas no confronto com o chinês.
- Nomenclatura *tianmaren* preservada como substância interna ao romance; não foi presumida identificação botânica.
- Correções específicas de sentido: a confissão no fim significa “Fui eu que fiz isso”, não “Eu consegui”.

## Escopo e limitações

- Verificação estrutural de todas as unidades e revisão semântica dirigida, **não auditoria semântica independente frase a frase**.
- A manutenção de texto do EPUB em parágrafos não retrabalhados não certifica ausência de erros remanescentes.
- O cotejo por índice de parágrafo não comprova, isoladamente, equivalência de sentido.

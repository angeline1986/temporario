# Capítulo 300 — A deposição da imperatriz

O trovão cessou abruptamente e as nuvens escuras se dissiparam.

Restou apenas a imperatriz, encolhida num canto, protegendo a cabeça com os braços e implorando aos gritos para que os céus parassem de atingi-la.

Ela mesma confessou seus crimes, e tantas pessoas no palácio ouviram, que não houve espaço para contestação.

Ao ouvir a confissão, Ning Xiaoxiao sentiu despertar sua veia de atriz. Encolheu-se nos braços de Lu Linyuan e começou a fazer um escândalo sem derramar uma lágrima sequer.

"Waaaah~ A-Yuan, será que é porque eu não me saí bem o suficiente? Por que a Imperatriz me odeia tanto...? Eu não guardo rancor da Imperatriz, por que ela quer me matar?"

Um brilho malicioso surgiu nos olhos de Lu Linyuan enquanto ele encarava sua pequena esposa em seus braços. "De novo, hein?"

Ele apertou o abraço em sua cintura, exibindo uma expressão terna enquanto a consolava:

"Não chore."

"Você não me prometeu que, de agora em diante, só choraria na cama?"

Ning Xiaoxiao: “...”

【Eu não aguento esse seu jeito sem-vergonha! Será que não dá para cuidar do assunto sério primeiro?!】

Ela apertou o peito de Lu Linyuan com força, fazendo com que seu rosto empalidecesse, suas sobrancelhas se franzissem e seus dentes se cerrassem, à beira de gritar.

Aproveitando a dor, Lu Linyuan transformou-a em indignação e gritou para a imperatriz:

"Como alguém com o seu caráter e conduta pode ser digna de ser imperatriz depois de um ato como esse?"

As palavras dele soaram como um trovão nos ouvidos da Imperatriz. Sua cabeça zumbia, e ela só percebeu em choque que tinha acabado de dizer algo que não devia.

Ela se arrastou até os pés de Lu Linyuan, agarrou a barra da veste imperial e suplicou, chorando:

"Vossa Majestade, por favor, acalme sua raiva... Eu apenas me confundi por um instante. Imploro a Vossa Majestade que me perdoe desta vez, considerando que sempre segui as regras do palácio e me comportei adequadamente..."

A expressão de Lu Linyuan tornou-se cada vez mais de desgosto.

Ele detesta quando outras mulheres têm contato físico com ele!

*Eu tenho uma obsessão por limpeza! Como essa velha atrevida ousa agarrar meu manto imperial com as mãos sujas de tanto rastejar pelo chão?*

Ele chutou a imperatriz para o lado. — Você, que sempre segue as regras? Vive inquieta, tramando confusões! Mais parece uma tartaruga se arrastando com a bunda à mostra! [Trocadilho vulgar com 規行矩步 e 龜行菊/部.]

A Imperatriz continuou a argumentar: "Mas... esse pensamento só me ocorreu por um instante fugaz. A Consorte Nobre Imperial... no fim, eu não a machuquei de verdade..."

"Você tem muita sorte de Xiaoxiao não ter se machucado. Você deveria ir ao Salão Fahua para agradecer a todos os deuses e Budas por sua extraordinária misericórdia para com você!"

— Caso contrário, você acha que ainda estaria viva para ficar tagarelando diante de mim?

Ele estava repreendendo a Imperatriz quando Sanfu entrou novamente para relatar:

— Majestade, Xia Guo morreu sob tortura. Mas, antes de morrer, revelou mais uma coisa.

"Você diz."

— Xia Guo disse que foi a própria imperatriz quem matou a Concubina Tong. Ela descreveu detalhadamente como cometeu o crime. Peço que Vossa Majestade examine o depoimento.

Ele entregou a Lu Linyuan uma confissão coberta de marcas de mãos ensanguentadas. Depois de lê-la, Lu Linyuan amassou-a e atirou-a na cara da Imperatriz.

— Você é mesmo cheia de estratégias! Até recorre a manuais de guerra para conspirar contra as consortes. Que desperdício tê-la feito imperatriz! Com tamanha habilidade, eu deveria nomeá-la general da fronteira!

Ela ainda poderia tentar argumentar que a tentativa contra Ning Xiaoxiao não deu certo. Mas Xia Guo revelara todos os detalhes do assassinato da Concubina Tong. Com uma morte nas costas, nem os grandes méritos militares recentemente conquistados pela família da imperatriz na corte seriam suficientes para salvá-la.

Lu Linyuan, com as mangas esvoaçando ao vento, disse solenemente:

"Já que você gosta de falar sobre regras em tudo, então hoje vou lhe explicar as regras da Dinastia Qi."

— A partir de hoje, retirem os documentos de investidura e os selos da imperatriz. Anunciem a todo o império: estou destituindo a senhora do clã Zhu do posto de imperatriz e escolherei outra para ocupar seu lugar!

Quanto a você...

Seu olhar percorreu o corpo de Zhu Shi com ferocidade.

"Até o imperador está sujeito às mesmas leis que os plebeus, e os assassinos devem pagar com a própria vida."

"Você tem uma audição e visão aguçadas, entende o que quero dizer?"

P.S.: Tenho alguns assuntos pessoais para tratar hoje, então esta é a única atualização.

Na atualização da madrugada de amanhã, 31 de agosto, Xiaoxiao será nomeada imperatriz. Assim vocês poderão vê-la coroada antes do início das aulas.

Sobre quando a história termina: a narrativa principal terá cerca de 850 mil caracteres chineses; ainda faltam aproximadamente 200 mil.

Os extras terão cerca de 150 mil caracteres chineses, e cada casal secundário receberá seu próprio especial completo. Portanto, ainda falta bastante para o encerramento definitivo.

Não me pressionem pelo novo livro! Com certeza ficará pronto antes do feriado de 1º de outubro. Por algum tempo, provavelmente publicarei as duas obras simultaneamente.

Amo vocês! Um coraçãozinho para todos~

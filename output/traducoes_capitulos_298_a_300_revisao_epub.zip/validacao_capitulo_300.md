# Validação — capítulo 300

- Original chinês: `novel_capitulos_271_a_300(20261106-202952).docx`.
- Tradução-base: `novel capitulos 271 a 300 - ch.epub`, `index_split_029.html`.
- Índices do DOCX: 1970–2016 (fim exclusivo: 2017).
- Unidades não vazias: **45**, incluindo título; corpo: **44**.
- Alinhamento estrutural EPUB–DOCX: **44 para 44**.
- Unidades com alterações textuais diretas frente ao EPUB: **19**; posições relativas: 2, 4, 11, 13, 16, 20, 21, 22, 24, 26, 28, 30, 31, 34, 40, 41, 42, 43, 44.

## Decisões editoriais

- Preservados título, ordem dos parágrafos e marcadores, inclusive notas da autora.
- Corrigidos erros evidentes de sujeito, gênero, títulos e inconsistências de tradução identificadas no confronto com o chinês.
- Nomenclatura *tianmaren* preservada como substância interna ao romance; não foi presumida identificação botânica.
- Correções específicas de sentido: 8.31 indica 31 de agosto, não 8h31; as quantidades da nota autoral são caracteres chineses, não contagem literal de palavras portuguesas.

## Escopo e limitações

- Verificação estrutural de todas as unidades e revisão semântica dirigida, **não auditoria semântica independente frase a frase**.
- A manutenção de texto do EPUB em parágrafos não retrabalhados não certifica ausência de erros remanescentes.
- O cotejo por índice de parágrafo não comprova, isoladamente, equivalência de sentido.

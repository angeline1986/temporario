# Capítulo 298 — Imperatriz, você é bondosa demais. Eu farei justiça por você

Gu Sijin não tinha noção do que havia acontecido e presumiu que a Imperatriz estivesse usando sua dor de cabeça como desculpa para convocar pessoas para se revezarem em atendê-la. Portanto, ela disse friamente:

— Que coisa tão grave aconteceu para você estar tão aflito?

"Sua Majestade a Imperatriz... está doente..."

— Se ela está doente, por que vir procurar a Consorte Nobre Imperial? Os médicos imperiais não vão se recusar a tratá-la.

— Mas desta vez... a situação é diferente...

O jovem eunuco explicou, entre gaguejos, toda a situação às duas. Depois de ouvi-lo, Gu Sijin e Ning Xiaoxiao trocaram um olhar, e Gu Sijin comentou com sarcasmo:

— Como dizem, o céu tem seus acertos de contas, e quem procura a própria desgraça não tem salvação. Ela tentou tirar vantagem e acabou se prejudicando.

"Vamos, irmã." Ning Xiaoxiao pegou a mão de Gu Sijin e disse com um sorriso: "Vamos ver o que está acontecendo."

*

Quando chegaram ao Palácio de Fengluan, todas as concubinas imperiais já haviam chegado ao saber da notícia.

Ao ver as outras consortes choramingando à porta, Ning Xiaoxiao repreendeu-as: — Por que estão chorando? A imperatriz ainda nem morreu! Que mau agouro!

A Concubina Shen se aproximou, sacudindo a cabeça: — Consorte Nobre Imperial, é melhor não entrar... A imperatriz está coberta de ataduras. Tirando o rosto, o corpo inteiro está cheio de feridas e crostas. É assustador...

A consorte Li disse com a voz rouca: "Sua Majestade a Imperatriz não costumava dizer que meu rosto era extremamente bonito, para me consolar? Agora que a boa sorte lhe sorriu, Sua Majestade a Imperatriz deve estar chorando de alegria neste exato momento."

O tianmaren não matava: fazia a pele ulcerar, formar crostas rapidamente e deixar cicatrizes horríveis.

As roupas de dormir leves da primavera aderiam mais ao corpo que as peças acolchoadas de inverno. Por isso, embora o rosto da imperatriz tivesse sido poupado, o restante da pele parecia queimado pelo fogo, numa visão aterradora.

Ela foi uma mulher de personalidade forte durante toda a sua vida, como poderia querer que os outros a vissem em um estado tão desgrenhado?

Muito antes da chegada de Ning Xiaoxiao, ela já havia expulsado furiosamente de seus aposentos todas as concubinas que correram para lá ao saber da notícia.

Ning Xiaoxiao disse: "A Imperatriz está nesse estado, por que vocês não vão todos servi-la? O que estão fazendo parados na porta?"

Consorte Duan: "Sua Majestade a Imperatriz disse que ninguém tem permissão para entrar..."

Ning Xiaoxiao lançou-lhe um olhar de lado. — Ela já não governa os assuntos dos seis palácios. Minhas ordens, portanto, têm força de decreto. Agora mando que entrem para consolá-la. Vão ou não?

Ela emitiu o decreto; quem ousaria desobedecer?

Então as concubinas foram em grupos e se aglomeraram no quarto.

A imperatriz estava trocando os curativos. Quando viu as consortes entrarem novamente, escondeu sob o cobertor o corpo coberto de feridas e gritou, fora de si:

"Saiam daqui! Eu mandei vocês saírem! Quem entrar de novo, eu arranco os olhos!"

Ning Xiaoxiao a ignorou e deu alguns passos à frente, sentando-se diretamente na beirada da cama:

"Majestade, por que se incomodar? Somos todos família, quem ousaria rir de você?"

'Pfft'

No entanto, antes que ela pudesse terminar de falar, caiu na gargalhada.

Ning apressou-se a explicar, depois de rir: — Não me entenda mal, Majestade. Não estou rindo de você. É que me lembrei de que a alpaca do meu palácio não faz cocô há três dias e achei engraçado.

— Imagine só! A criatura rejeita a própria ração para comer arroz e farinha. Não é procurar sarna para se coçar?

“......”

Após terminar de falar, ela olhou para Xia Guo, que estava ao lado com a mão enfaixada e uma expressão de horror, e perguntou novamente: "O que aconteceu com a sua mão? Ela tocou em algo que você não deveria ter tocado?"

"Esta serva... esta serva também não sabe." Ela irrompeu em lágrimas após apenas algumas palavras. "Ontem, senti como se estivesse possuída. Quando acordei, não me lembrava de nada. Não sei por que Sua Majestade a Imperatriz ficou ferida assim..."

Ela chorou tão amargamente que a Imperatriz viu e presumiu que ela estava fingindo.

No entanto, a Imperatriz ainda era racional; ela não ousava expô-la diante de tantas pessoas.

Afinal, se esse incêndio se alastrasse para Xia Guo, e Lu Linyuan a questionasse sobre a origem das sementes de tianmaren, ela inevitavelmente confessaria seu envolvimento.

Não seria como atear fogo em si mesmo?

"O Imperador chegou!"

Ao ouvir anunciar a chegada de Lu Linyuan, as lágrimas da imperatriz transbordaram imediatamente.

Ela pensou consigo mesma que, acontecesse o que acontecesse, o imperador ainda se importava com ela e que estava disposto a vê-la assim que soubesse que ela estava ferida.

Lu Linyuan entrou correndo no quarto com passos extremamente rápidos, como se estivesse com pressa para proteger sua amada.

Para espanto de todos, ele pareceu ignorar completamente a lamentável Imperatriz deitada na cama e, em vez disso, caminhou diretamente para o lado de Ning Xiaoxiao, puxou-a da cama da Imperatriz e cobriu seus olhos.

"A-Yuan?"

"Não olhe", disse Lu Linyuan gentilmente, tentando acalmá-la. "Você é tímida e não suporta coisas sujas."

Imperatriz: "???"

Lu Linyuan não queria que sua Xiaoxiao visse a aparência repugnante da Imperatriz e tivesse pesadelos com isso...

Ele pegou na mão de Ning Xiaoxiao, com a intenção de levá-la de volta ao palácio primeiro e dizer-lhe para não se envolver nesse assunto.

Ao vê-lo prestes a ir embora, todas as mágoas acumuladas da imperatriz explodiram.

Ela gritou com Lu Linyuan a plenos pulmões, num soluço de partir o coração:

— Majestade! Afinal, eu sou sua imperatriz! Fizeram isso comigo, e o senhor não é capaz sequer de me oferecer uma palavra de consolo?

Lu Linyuan estava de costas para ela, com um sorriso enigmático nos lábios.

Era exatamente o que Lu Linyuan esperava que a imperatriz dissesse. Ela acabara de cair, por vontade própria, na armadilha.

Lu Linyuan virou-se subitamente, olhando para a Imperatriz com um toque de pena nos olhos:

— Que palavras são essas, imperatriz? Você é minha imperatriz. Como eu poderia saber que alguém tentou prejudicá-la e não fazer nada?

Enquanto falava, ele apertou a mão de Ning Xiaoxiao com mais força.

Seu instinto de sobrevivência era extremamente forte, como se ele estivesse usando essa ação para explicar a Ning Xiaoxiao:

*Minha esposa, aguente só um instante. Deixe seu marido bancar o poderoso e depois vou chutar a imperatriz do posto que sempre deveria ter sido seu.*

Ning Xiaoxiao vislumbrou Sanfu parado do lado de fora da porta. Ele estava fazendo um sinal de "OK" que havia aprendido com ela, e ela entendeu imediatamente.

Embora Ning Xiaoxiao tivesse insistido repetidas vezes com Sanfu para que não contasse nada a Lu Linyuan, a fim de não preocupá-lo...

Mas Sanfu, com pena de Ning Xiaoxiao, contou tudo a Lu Linyuan mesmo assim.

Lu Linyuan prosseguiu: — Não apenas vou intervir como ordenarei uma investigação completa, para descobrir como aquela substância imunda foi parar no corpo da imperatriz. Se alguém neste palácio foi capaz de tamanha crueldade, não escapará de uma punição severa.

Ao ouvir isso, a Imperatriz entrou em pânico imediatamente: "Vossa Majestade... acredito que essa pessoa não fez isso intencionalmente. Sou uma budista devota e não desejo dar prosseguimento a este assunto. Imploro a Vossa Majestade que..."

"Não." Lu Linyuan a interrompeu bruscamente: "Agora que sei sobre isso, preciso cuidar do assunto."

— Imperatriz, você é bondosa demais. Mas fique tranquila: eu farei justiça por você e não deixarei que sofra essa afronta em vão.

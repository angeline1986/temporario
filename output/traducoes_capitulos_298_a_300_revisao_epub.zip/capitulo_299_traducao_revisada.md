# Capítulo 299 — A imperatriz é perseguida pelos raios

O Palácio da Fênix ficou em silêncio por um instante.

Lu Linyuan estava furioso, e era a primeira vez que ele protegia a Imperatriz da mesma forma que protegia Ning Xiaoxiao.

A Imperatriz deveria ter se comovido, afinal, sua saúde estava em tal estado, e Lu Linyuan ainda estava disposto a defendê-la. Isso não demonstra que Lu Linyuan não a desprezava por causa disso?

Mas as outras consortes notavam uma estranha apreensão no semblante da imperatriz.

— Isso certamente foi obra de alguém próximo da imperatriz — declarou Lu Linyuan solenemente, antes de ordenar:

"Guardas, levem todos os servos do Palácio Fengluan para a prisão imperial e interroguem-nos severamente. Certifiquem-se de que confessem honestamente quem usou um método tão cruel para envenenar a Imperatriz e quem os instruiu."

Ao receber a ordem, Sanfu obedeceu imediatamente e liderou os guardas para que começassem a prender pessoas dentro do Palácio da Fênix.

O Palácio da Fênix estava um caos completo. A Imperatriz, esforçando-se para manter a calma, dirigiu-se a Lu Linyuan, dizendo:

— Majestade, no estado em que estou, não posso ficar sem alguém para cuidar de mim.

— Compreendo que todos sejam interrogados. Mas permita que Xia Guo fique aqui para me servir de perto.

— Ela ficou comigo ontem o tempo inteiro e, assim como eu, foi ferida pelo tianmaren. Tenho certeza de que não foi ela.

— Imperatriz, sua bondade é tamanha que suas palavras chegam a ter a beleza de quem não tem cérebro — disse Lu Linyuan, balançando a cabeça. — Justamente por ela ter ficado ao seu lado o tempo todo, é a principal suspeita.

"Além disso, o ferimento foi na mão dela. Como podemos ter certeza de que ela não se feriu acidentalmente ao envenenar? Na minha opinião, ela é quem deveria ser interrogada com mais rigor."

A imperatriz ainda tentou encontrar uma forma de manter Xia Guo junto de si.

Afinal, se ela fosse julgada, seu plano para assassinar Ning Xiaoxiao certamente viria à tona.

Mas antes que ela pudesse sequer falar, Ning Xiaoxiao a interrompeu, dizendo:

"Vossa Majestade, fique tranquila. Se está preocupada com a possibilidade de não ter ninguém para cuidar de si, posso enviar meus competentes servos do palácio para seu uso imediato."

Ela se virou e gritou:

"Qiqi, Qiaqia, Lala, vocês três ficarão no Palácio Fengluan pelos próximos dois dias para cuidar bem de Sua Majestade a Imperatriz. Não pode haver nenhum imprevisto, entenderam?"

Os três responderam em uníssono, e Lu Linyuan imediatamente disse: "Sanfu, levem essa pessoa embora!"

Sanfu reagiu e, junto com dois guardas, arrastou e puxou Xia Guo para fora.

Nesse momento, todos os funcionários do Palácio da Fênix foram retirados do local, e o rosto do Imperador ficou extremamente sombrio.

Sanfu deveria levar os servos ao Departamento de Punições para interrogatório. Mas guardava rancor da imperatriz pela tentativa anterior de prejudicar Ahuan e nem sequer levou os detidos até lá.

Ele usava o método de tortura mais simples empregado no palácio para extrair confissões: perfurar as pontas dos dedos com agulhas de prata.

Os dez dedos estão ligados ao coração. Até a pessoa mais teimosa terá que confessar a verdade quando algumas agulhas de prata forem inseridas em seus dedos.

Lu Linyuan e suas concubinas estavam sentados no quarto, enquanto gritos de agonia dos servos do palácio ecoavam pelo pátio.

A resistência psicológica da imperatriz desmoronou num instante.

Ao longo dos anos, ela provavelmente cometeu tantos atos hediondos que mal consegue se lembrar de todos eles.

Quem sabe o que esses criados do palácio irão confessar sob tortura?

Agora que Xiangling está morta, quem mais seria leal o suficiente para arriscar a própria vida para provar sua inocência?

Como era de esperar, Xia Guo não suportou a tortura e foi a primeira a confessar.

Sanfu entrou e relatou: "Vossa Majestade, Xia Guo confessou."

— Ela confessou que a imperatriz pretendia aplicar o tianmaren às vestes cerimoniais da investidura da Consorte Nobre Imperial. A imperatriz planejou prejudicá-la desde o início. Xia Guo recorreu a Ahuan, responsável pela Oficina de Bordados, para executar o plano. Já mandei trazê-la.

Após entrar, Ahuan ajoelhou-se diante de Lu Linyuan e prostrou-se repetidamente, explicando-lhe todo o processo.

Todas as concubinas voltaram seus olhares para a Imperatriz, que, após se recompor, retrucou em voz alta:

"Majestade! Este assunto não tem nada a ver comigo!"

Seu olhar recaiu sobre Ahuan, seus olhos arregalados, e ela a questionou: "Não guardo rancor de você, por que está me incriminando sem motivo?"

Ela murmurou algo e, de repente, voltou sua atenção para Ning Xiaoxiao: "Consorte Nobre Imperial! É você!?"

"Foram vocês, junto com aquela empregada desprezível, Xia Guo, e essa bordadeira, que armaram tudo isso para me incriminar!"

"Se o que ela diz é verdade, e eu queria te prejudicar, então eu te pergunto, por que essas coisas acabaram acontecendo comigo?!"

Ela sabe atuar, mas Ning Xiaoxiao atua ainda melhor.

Ela se sentiu extremamente injustiçada e se aconchegou nos braços de Lu Linyuan, soluçando baixinho.

— Buááá, A-Yuan, ela está me acusando injustamente! Sou tão bondosa! Como poderia armar uma coisa dessas para incriminar alguém?

Ning exalava aquela falsidade melosa de quem finge inocência; e Lu Linyuan adorava justamente esse teatrinho.

Ele acariciou os ombros de Ning Xiaoxiao e a consolou com doçura: — Não fique magoada, Xiaoxiao. Não chore, não chore. Um beijinho.

Depois de dizer isso, ele aproveitou a oportunidade para se aproveitar da esposa e lhe deu um beijo na bochecha.

Imperatriz: "???"

As concubinas: "￣□￣｜｜"

Assim se criou um mundo em que só a imperatriz saía perdendo.

Na verdade, Lu Linyuan sempre soube que o estado atual da Imperatriz era obra de Ning Xiaoxiao.

Mas ele não só não culpou Ning Xiaoxiao, como também ficou muito satisfeito por sua esposa saber se proteger e lhe dar uma provinha do próprio veneno.

Além disso, essa questão foi inteiramente de responsabilidade da Imperatriz, e ela não tinha mais ninguém a quem culpar.

Mesmo que a imperatriz não tivesse provocado esse episódio, Lu Linyuan encontraria algum pretexto para destituí-la o quanto antes.

Afinal, sua adorada Xiaoxiao precisava se tornar imperatriz dentro de um mês.

Ele não suportaria ver sua esposa entrar em hibernação!

Se a esposa hibernasse, até seu “21” ficaria cabisbaixo por sabe-se lá quanto tempo!

A imperatriz chorou amargamente, tentando desesperadamente encontrar brechas em toda a situação, numa tentativa de se livrar das suspeitas.

Lu Linyuan perguntou-lhe: "Não quero saber como a tianmaren foi parar ao seu corpo, só quero saber se isto lhe pertence?"

A Imperatriz, é claro, jamais admitiria isso, aconteça o que acontecer.

Ela se esforçou para se levantar da cama, ajoelhando-se, ergueu três dedos da mão direita e fez um juramento aos céus:

— Juro pela minha vida! Se fui eu quem fez isso, aceito ser atingida pelos cinco trovões celestiais e morrer de forma horrível!

Ning Xiaoxiao fez uma pausa por um momento:

Meu Deus, nunca vi um pedido tão absurdo.

*Já que você pediu com tanta sinceridade, seria falta de educação da minha parte não atender, não é?*

Então ela fechou os olhos, abriu o documento e modificou o enredo com facilidade.

Quando ela abriu os olhos novamente, o sol, que brilhava intensamente, foi subitamente encoberto por nuvens escuras.

'Boom!'

Vários trovões ecoaram ao longe, seguidos por um estrondo alto, quando um raio desceu, atravessou o telhado do Palácio da Fênix e atingiu em cheio o lado da Imperatriz.

Todos: "???"

A imperatriz ficou apavorada e correu descontroladamente, enquanto os raios a perseguiam, atingindo o palácio e rachando tijolos e telhas. Várias vezes, quase a atingiram no rosto, explodindo sua cabeça.

Ela nunca tinha visto nada parecido antes.

Ela só conseguiu chorar e gritar a plenos pulmões:

"Que os céus tenham misericórdia! Que os céus tenham misericórdia de mim!"

— Fui eu! Fui eu que fiz isso!

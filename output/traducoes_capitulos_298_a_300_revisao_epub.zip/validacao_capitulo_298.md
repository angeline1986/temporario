# Validação — capítulo 298

- Original chinês: `novel_capitulos_271_a_300(20261106-202952).docx`.
- Tradução-base: `novel capitulos 271 a 300 - ch.epub`, `index_split_027.html`.
- Índices do DOCX: 1824–1891 (fim exclusivo: 1892).
- Unidades não vazias: **65**, incluindo título; corpo: **64**.
- Alinhamento estrutural EPUB–DOCX: **64 para 64**.
- Unidades com alterações textuais diretas frente ao EPUB: **23**; posições relativas: 2, 4, 5, 6, 7, 11, 12, 14, 15, 20, 23, 29, 30, 36, 39, 48, 50, 52, 54, 57, 59, 61, 64.

## Decisões editoriais

- Preservados título, ordem dos parágrafos e marcadores, inclusive notas da autora.
- Corrigidos erros evidentes de sujeito, gênero, títulos e inconsistências de tradução identificadas no confronto com o chinês.
- Nomenclatura *tianmaren* preservada como substância interna ao romance; não foi presumida identificação botânica.
- Correções específicas de sentido: a frase final pertence a Lu Linyuan; a imperatriz é a beneficiária irônica da promessa.

## Escopo e limitações

- Verificação estrutural de todas as unidades e revisão semântica dirigida, **não auditoria semântica independente frase a frase**.
- A manutenção de texto do EPUB em parágrafos não retrabalhados não certifica ausência de erros remanescentes.
- O cotejo por índice de parágrafo não comprova, isoladamente, equivalência de sentido.

Capítulo 216 — Não gostou? Engula a insatisfação!

A Consorte Nobre cambaleou e quase caiu na neve.

As criadas correram para ampará-la. Ning Xiaoxiao comentou, solícita: — Cuidado, Consorte Nobre. Não vá cair.

Absurdo!

Um absurdo dos grandes!

Lu Linyuan escolhera a placa dela para passar a noite em seu palácio e aparecia trazendo outra pessoa? Que história era aquela?

O que ele pensava? Que o Palácio Zhaochun era uma pousada aberta a qualquer hóspede?

A Consorte Nobre sabia que Lu Linyuan favorecia Ning Xiaoxiao, mas jamais imaginara um favoritismo tão absolutamente desmedido.

Ainda assim, era uma mulher experiente. Recuperou-se do choque em instantes, abriu um sorriso postiço e procurou uma desculpa para salvar as aparências:

— Ah, vejam só como Sua Majestade é atencioso com a irmã Hua!

Aproximou-se, segurou a mão de Ning Xiaoxiao e fingiu grande intimidade. — Com certeza, por causa da neve e do caminho escorregadio, Sua Majestade resolveu acompanhar a irmã Hua de volta aos aposentos, não é?

— O Palácio Zhaochun fica bem perto do Fengyi. Xianglan, mande trazer minha liteira e acompanhe pessoalmente a Concubina Hua até seu palácio.

Ning Xiaoxiao afastou bruscamente a mão dela. Segurou o braço de Lu Linyuan, apoiou a cabecinha em seu ombro e começou a se esfregar nele como uma gatinha fazendo manha com o dono.

Nada era mais irresistível do que o denguinho de uma garota meiga.

Lu Linyuan ergueu a mão e, sorrindo cheio de carinho, coçou o queixo dela. Então recolheu o sorriso e olhou para a Consorte Nobre. — Você entendeu errado. Esta noite, Xiaoxiao e eu vamos dormir aqui no Palácio Zhaochun.

Consorte Nobre: — !!!

— Majestade... C-como assim vamos dormir? Nunca ouvi falar de uma coisa dessas... Além disso, minha cama não é tão larga. Acho difícil acomodar três pessoas...

— Você entendeu errado. Eu e Xiaoxiao vamos dormir juntos. Você não está incluída.

A expressão da Consorte Nobre ficou ainda pior do que se um raio a tivesse atingido. Após um longo silêncio, perguntou, perplexa: — Ainda não entendi o que Vossa Majestade quer dizer.

Lu Linyuan sorriu, um pouco constrangido. — É o seguinte: eu e Xiaoxiao acabamos de quebrar a cama do Palácio Fengyi enquanto a usávamos. Como o seu palácio é o mais próximo de lá, resolvemos vir para cá.

Consorte Nobre: — ???

— M-mas... Vossa Majestade poderia levar a Concubina Hua ao Palácio Chaoyang. Por que precisam vir ao meu?

Ao ouvir aquilo, Ning Xiaoxiao soltou um murmúrio tímido, em tom de protesto.

Baixou os longos cílios. Suas bochechas estavam rosadas como o céu ao entardecer, a cor espalhada sobre a pele delicada, tornando-a ainda mais adorável.

Lu Linyuan deslizou a mão de seu ombro até a orelha, brincando com o lóbulo que começara a esquentar, e explicou:

— A culpa é minha. Perdi o controle da paixão.

— A cama do Palácio Chaoyang também quebrou...

Consorte Nobre: — ￣□￣||

— Mas os aposentos laterais ainda não foram arrumados! Se Vossa Majestade e a Concubina Hua vão dormir no quarto principal, onde eu dormirei?

— Não precisa se preocupar. Já pensei nisso por você. Entrem!

Ao chamado de Lu Linyuan, Sanfu entrou acompanhado de alguns eunucos carregando grandes e pequenos sacos de tecido.

Lu Linyuan ordenou: — Levem as cobertas e os travesseiros da cama da Consorte Nobre para os aposentos laterais. Depois, arrumem a cama principal com estes artigos novos. Xiaoxiao tem a pele sensível e não pode dormir em roupas de cama usadas por outras pessoas.

Consorte Nobre: — ∑(￣□￣*|||

A cada pergunta que fazia, Lu Linyuan lhe dava mais uma bofetada figurada, sem sequer se dar ao trabalho de disfarçar. Ela já não conseguia responder a nada.

Se continuasse perguntando, talvez ele arrancasse de vez a pele do rosto dela para transformá-la numa bolsinha para sua adorada Xiaoxiao carregar...

Restou-lhe calar-se e assistir, impotente, enquanto Lu Linyuan e Ning Xiaoxiao entravam em seus aposentos.

Uma rajada de vento oeste soprou, lançando cristais de neve no rosto da Consorte Nobre, cortantes como lâminas.

Mas a mesma rajada trouxe do salão o aroma da comida, que alcançou certeiro o nariz de Ning Xiaoxiao.

Aquela comilona não havia feito um lanchinho noturno. Assim que sentiu o cheiro, parou de andar, e sua barriga soltou um sonoro ronco.

Lu Linyuan ouviu e parou também. Deu um tapinha no ventre plano dela e provocou: — Com fome de novo?

Ning Xiaoxiao passou a pontinha rosada da língua pelos lábios e o encarou com os olhos brilhando, assentindo sem parar.

Lu Linyuan afastou uma mecha de cabelo junto à orelha dela e sussurrou com um sorriso:

— Quer ir primeiro ao quarto para um “aperitivo especial” ou prefere jantar no salão?

Era para ser um segredo ao pé do ouvido, mas o Palácio Zhaochun estava tão silencioso que o volume foi exatamente suficiente para a Consorte Nobre, parada ao lado, escutar cada palavra.

Ning Xiaoxiao empurrou-o de leve, fazendo charme. — Majestade... Que coisa feia!

A Consorte Nobre sentiu vontade de vomitar ao ver aquele jeito sedutor. Ia se virar para sair quando ouviu Lu Linyuan continuar:

— Ótimo que esteja com fome. A Consorte Nobre não mandou preparar comida? O cozinheiro daqui foi trazido de fora do palácio pelo ministro Tong. Cozinha melhor até que os chefs imperiais. Hoje você vai comer muito bem.

Então ele olhou para a Consorte Nobre. — Quer jantar conosco?

Jantar com eles?

Ele a achava idiota?

Os dois estavam naquele grude. Ela iria fazer o quê? Servir comida no pratinho dos pombinhos?

Reprimindo a amargura que subia pela garganta, a Consorte Nobre respondeu num tom gelado: — Não estou me sentindo bem. Vou descansar no meu quarto.

— Então vá descansar. Depois de amanhã partirei para a propriedade das fontes termais. Amanhã à noite também ficarei aqui. Terá de se acomodar nos aposentos laterais durante esses dois dias.

O que mais a Consorte Nobre poderia dizer?

Além de “Obedeço às ordens de Vossa Majestade”, o que lhe restava? Amaldiçoar os antepassados de Lu Linyuan e Ning Xiaoxiao até a décima oitava geração?

Lu Linyuan conduziu Ning Xiaoxiao ao salão principal. Só quando os criados terminaram de servir a comida, fecharam as portas e saíram, os dois se entreolharam e finalmente desataram a rir, incapazes de se conter.

Ning Xiaoxiao riu tanto que se dobrou para trás. Esqueceu que sua cadeira não tinha encosto e quase caiu de costas no chão.

Se Lu Linyuan não a tivesse agarrado a tempo, talvez aquela alegria toda tivesse terminado em tragédia.

— Vá com calma. Você vive se atrapalhando, nunca dá sossego a ninguém.

Ning Xiaoxiao mostrou a língua de maneira travessa. — Majestade, não tem medo de que a Consorte Nobre fique tão furiosa que acabe se matando aqui mesmo?

— Ela não ousaria. — Lu Linyuan falou com indiferença. — O suicídio de uma consorte é um crime grave. Se ela se matar, eu exterminarei os nove ramos da família Tong.

Não havia um pingo de emoção naquelas palavras, mas ouvi-las provocava arrepios.

Ning Xiaoxiao, contudo, não sentia a menor pena da Consorte Nobre. Muito menos a considerava uma pobre mulher que tivera o azar de se apaixonar por alguém que não a amava, nem achava que Lu Linyuan tivesse ido longe demais.

Incontáveis consortes haviam sofrido nas mãos daquela mulher. Duas levas de criados eram substituídas no palácio dela a cada ano; mais da metade morria espancada por faltas insignificantes.

Quem sentiria compaixão por uma assassina? Não era melhor aproveitar uma boa refeição?

E, de fato, o cozinheiro daquele palácio era tão habilidoso quanto Lu Linyuan dissera.

Ning Xiaoxiao comia com satisfação. Com as bochechas estufadas como as de um esquilinho, continuava enfiando comida na boca sem dar sinais de saciedade.

Lu Linyuan não sabia o que fazer com ela. A cena o irritava e divertia ao mesmo tempo.

— Coma devagar. Vai acabar engasgando.

Mas ficou só no aviso.

Assim que terminou de falar, aquele homem de obsessão extrema por limpeza limpou com os próprios dedos o óleo do canto da boca dela e ainda colocou em seu prato dois camarões cozidos em molho, que acabara de descascar.

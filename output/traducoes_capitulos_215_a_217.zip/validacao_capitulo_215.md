# Validação — capítulo 215

- Fonte: `novel_capitulos_212_a_270(20261105-204934).docx` (chinês tradicional).
- Limites: índices DOCX base zero 203 a 284.
- Unidades não vazias traduzidas: **79**. Primeiro índice: 203. Último: 283.
- Cabeçalho CSV: `indice_docx,original_chines,traducao_portugues`.
- Índices duplicados: **0**. Traduções vazias: **0**. Parágrafos originais omitidos: **0**.
- O Markdown segue exatamente a sequência dos campos portugueses do CSV.

## Decisões editoriais

Preservado o humor sobre “ancestral” e a piada de Xiaoyinzi; a cena do golpe nos genitais é desfeita pelo recurso Retroceder, não permanece na linha temporal após a correção. O suposto encontro íntimo com a Consorte Nobre não ocorre neste capítulo. Incluídos PS, título do livro recomendado, autora e descrição.

## Limites da validação

Verificação automatizada de cobertura estrutural 1:1, ordem, índices, integridade dos arquivos e da compactação. Revisão tradutória durante a elaboração, sem alegar auditoria semântica independente integral. A correspondência estrutural não comprova por si só ausência de erro de interpretação.

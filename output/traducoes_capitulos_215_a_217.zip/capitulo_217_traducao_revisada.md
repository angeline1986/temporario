Capítulo 217 — Estou zangado agora. E você vai fazer o quê?

Depois de comer e beber à vontade, a pequena ancestral não parava de arrotar.

Com medo de que ela tivesse comido até morrer, Lu Linyuan segurou sua mão e a obrigou a dar algumas voltas pelo corredor para ajudar na digestão.

Antes de terem definido a relação, parecia que sempre havia milhares de coisas sobre as quais conversar quando se encontravam.

Mas agora aquela barreira fina e ambígua entre os dois parecia ter sido finalmente rompida, não?

E, por alguma razão, quando ficavam sozinhos, surgia um constrangimento que antes não existia.

Nem todos se adaptam rapidamente a uma mudança na relação. Ainda mais aqueles dois, completos novatos em assuntos amorosos.

Enquanto caminhavam pelo corredor, Ning Xiaoxiao, do lado de fora, observava sem parar a neve sob os beirais. Lu Linyuan, por sua vez, só tinha olhos para ela. Suas mãos permaneceram entrelaçadas o tempo todo.

Afinal, por que o amor precisaria ser uma sucessão de grandes acontecimentos?

Poder viver todos os dias uma vida simples ao lado da pessoa amada, passear de mãos dadas depois do jantar e de um dia de trabalho... Isso também não seria uma bela felicidade?

Mas havia uma condição indispensável para que fosse uma bela felicidade:

NÃO! TER! AS! MÃOS! SUADAS!!

Como Ning Xiaoxiao sofria de cólicas menstruais, Lu Linyuan sempre a fazia tomar muitos remédios fortificantes.

Eles eram excelentes para regular seu organismo. Ela os tomava durante todo aquele inverno e, aos poucos, deixara de sentir tanto frio.

Só que, agora que seu corpo ficara mais quente e ela ainda andava de mãos dadas com aquele verdadeiro aquecedor humano, como poderia evitar o suor?

Sentindo claramente a palma da mão ficar úmida, Ning Xiaoxiao tentou soltá-la por um instante.

Mas Lu Linyuan não permitiu. Ao perceber que ela queria soltar sua mão, apertou-a de repente com mais força.

— Majestade...

— Não solte.

— Mas minha mão está suan...

Antes que ela terminasse, Lu Linyuan pressionou-lhe a mão contra o próprio manto imperial e usou o tecido amarelo-vivo, caríssimo, para enxugar a fina camada de suor.

Ning Xiaoxiao ficou boquiaberta diante daquele gesto.

【Desde quando a personalidade desse maníaco por limpeza se desfez de maneira tão completa?】

Depois de enxugar a palma dela, Lu Linyuan ainda a levou aos lábios e soprou suavemente antes de dizer:

— É só suor. Hoje eu não sinto nojo de você. No futuro, você também não poderá sentir nojo de mim.

Ning Xiaoxiao perguntou, curiosa: — Majestade, suas mãos também suam?

Lu Linyuan negou com a cabeça. Então parou, examinou-a com um brilho malicioso nos olhos por alguns instantes e se inclinou para sussurrar com atrevimento em seu ouvido:

— Quando você estiver por baixo, meu suor sempre vai pingar em cima de você.

Ning Xiaoxiao: — ???

【Você é um pervertido?! Não consegue se comportar como uma pessoa normal?!】

Ela deu um empurrão nele. Lu Linyuan rapidamente segurou seu pulso, aproveitou para entrelaçar os dedos novamente e soltou uma gargalhada:

— Hahaha! Se não aguenta nem uma provocação dessas, da próxima vez farei menos piadas e passarei mais à prática.

— ...

Depois de passearem o suficiente e retornarem ao quarto, Lu Linyuan perguntou a Ning Xiaoxiao:

— Sabe por que fiz questão de escolher a placa da Consorte Nobre e dormir no palácio dela esta noite?

Mais cedo, quando Lu Linyuan escolhera a placa da Consorte Nobre bem diante dela, Ning Xiaoxiao já estava pronta para fazê-lo sofrer outra vez aquele terrível acidente com seus “ovos”.

Felizmente, o pobre coitado percebeu o perigo. Bastou notar sua mudança de expressão para anunciar que a levaria junto para passar a noite no Palácio Zhaochun.

Ning Xiaoxiao conseguia adivinhar parte do motivo. Certamente era alguma manobra política na corte.

Mas uma mulher precisava saber quando preservar o orgulho do namorado. Às vezes, era bom fingir ignorância para que ele tivesse a satisfação de explicar.

Fora sua mãe que lhe ensinara esse truque. Embora Qi Meijuan jamais tivesse feito questão de preservar o orgulho de Ning Dazhi...

Ning Xiaoxiao balançou a cabeça, apoiou o queixo na mão e fitou Lu Linyuan com um olhar cheio de curiosidade.

Lu Linyuan fizera questão de passar aquela noite no palácio da Consorte Nobre porque conhecia perfeitamente o caráter dela.

A Consorte Nobre sonhava em ocupar o posto de imperatriz. Considerava-se superior à atual imperatriz em família, beleza e tudo mais; não aceitava ficar abaixo dela.

Assim, sempre que tinha algo de que pudesse se vangloriar, ampliava a história até proporções absurdas para humilhar publicamente a imperatriz.

E todos no harém sabiam que, com exceção de Ning Xiaoxiao, Lu Linyuan jamais convocara outra consorte para passar a noite com ele.

Portanto, se ele pernoitasse no Palácio da Consorte Nobre, todos acreditariam que alguma coisa acontecera entre eles.

Por orgulho, mesmo depois da humilhação sofrida naquela noite, ela certamente andaria de cabeça erguida no dia seguinte, proclamando a todos que havia servido o imperador na cama.

Com isso, a imperatriz ficaria ainda mais alarmada e procuraria a imperatriz-viúva para discutir contramedidas.

Quando Lu Linyuan levasse Ning Xiaoxiao para a propriedade das fontes termais, o palácio estaria mergulhado no caos. A corte e o harém eram inseparáveis; enquanto todos se atacassem, ele poderia desfrutar a tranquilidade com sua mulher e assistir à confusão de longe.

Na verdade, Lu Linyuan poderia explicar tudo isso a Ning Xiaoxiao. Confiava nela inteiramente.

Mas, pensando melhor, aquelas maquinações não eram exatamente honrosas. E se Xiaoxiao passasse a gostar menos dele ao descobri-las?

Assim, mudou de assunto: — Não é nada. Só preciso que me ajude com uma coisa amanhã. Não conte a ninguém o que aconteceu esta noite. Finja que passei a noite sozinho no palácio da Consorte Nobre, está bem?

Ning Xiaoxiao assentiu prontamente, com um sorriso luminoso. — Está bem!

Lu Linyuan ficou um pouco atônito. — Por que... você nunca pergunta o que estou fazendo? Não quer saber?

Ning Xiaoxiao encostou obedientemente a cabeça no peito dele. — Quando quiser me contar, vai me contar. Para que ficar perguntando tanto?

Era sempre assim. Parecia não conhecer regras e vivia fazendo maluquices, mas enxergava as coisas com mais clareza do que qualquer outra pessoa.

Lu Linyuan a abraçou, acariciando sua clavícula com os dedos. — Ah, é verdade. Onde está a medalha de imunidade à morte que lhe dei?

A pergunta repentina deixou Ning Xiaoxiao paralisada. Ela sabia perfeitamente o valor daquele presente. Se Lu Linyuan descobrisse que ela o havia entregado a Gu Sijin, não morreria de raiva?

Por isso, gaguejou por um bom tempo sem conseguir dar uma explicação convincente.

Lu Linyuan observou seu constrangimento e soltou um riso frio: — O que foi? Deu a medalha para outra pessoa?

Ning Xiaoxiao se apressou em explicar: — Majestade... Nós não vamos à propriedade das fontes termais daqui a pouco? Estou preocupada com Sijin. Você sabe como ela é delicada, até uma criada tem coragem de maltratá-la. Então... então emprestei a medalha de imunidade à morte para ela...

Enquanto falava, observava atentamente o rosto de Lu Linyuan. Ao ver as sobrancelhas dele se juntarem, acrescentou depressa: — Mas não se preocupe! É só emprestada! Daqui a uns dois dias vou pegá-la de volta!

— Humpf! É bom mesmo! — Lu Linyuan bufou, com uma expressão fechada e contrariada.

— Já que a emprestou, também não fica bem eu mandá-la pegar de volta. Mas você entregou a outra pessoa uma coisa que eu lhe dei. Agora estou zangado. Diga-me: o que pretende fazer a respeito?

# Validação — capítulo 216

- Fonte: `novel_capitulos_212_a_270(20261105-204934).docx` (chinês tradicional).
- Limites: índices DOCX base zero 285 a 358.
- Unidades não vazias traduzidas: **71**. Primeiro índice: 285. Último: 357.
- Cabeçalho CSV: `indice_docx,original_chines,traducao_portugues`.
- Índices duplicados: **0**. Traduções vazias: **0**. Parágrafos originais omitidos: **0**.
- O Markdown segue exatamente a sequência dos campos portugueses do CSV.

## Decisões editoriais

O relato das camas quebradas é fala de Lu Linyuan, não comprovação narrativa de que tal evento ocorreu. Preservado o contraste entre a humilhação pública da Consorte Nobre e a brincadeira privada do casal. Os detalhes de violência histórica da Consorte Nobre não foram suavizados.

## Limites da validação

Verificação automatizada de cobertura estrutural 1:1, ordem, índices, integridade dos arquivos e da compactação. Revisão tradutória durante a elaboração, sem alegar auditoria semântica independente integral. A correspondência estrutural não comprova por si só ausência de erro de interpretação.

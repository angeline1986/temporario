Capítulo 215 — A Consorte Nobre passou a noite com o imperador?

Sanfu, naturalmente, sabia que, naquela provocação amorosa, “ancestral” se referia a uma pessoa bem específica.

O problema era que Xiaoyinzi era um homem completamente literal... Não, melhor dizendo, um eunuco completamente literal. Acreditou mesmo que Lu Linyuan queria que trouxesse as tábuas dos ancestrais ao Palácio Chaoyang.

Estava prestes a ir ao Salão dos Ancestrais Imperiais quando encontrou Sanfu. Assim que explicou a situação, recebeu um belo tabefe na nuca, sem sequer poder se defender.

— Seu pirralho, um cavalo desembestado deu um coice na sua cabeça?! O imperador mandou buscar a Concubina Hua! Você está indo ao Salão dos Ancestrais para procurar a própria morte?!

— A Concubina Hua? — Xiaoyinzi esfregou a nuca, indignado. — Desde quando a Concubina Hua virou ancestral do nosso imperador?

Sanfu: — ...

Silêncio. Um silêncio interminável...

O silêncio daquela noite veio em forma de tabefe.

Sanfu lhe deu mais um, inconformado com tamanha burrice.

— Com esse cérebro de porco que não entende nem o óbvio, você jamais chegará à minha posição! Pare de perguntar e vá logo!

No inverno, escurecia sempre muito cedo.

Quando foram buscar Ning Xiaoxiao, o céu já estava escuro.

Ao entrar no salão principal do Palácio Chaoyang, ela encontrou mais de uma dezena de lamparinas acesas. O salão imenso estava tão iluminado quanto ao meio-dia.

Lu Linyuan não estava sentado no trono. Na verdade, ela não o via em lugar nenhum.

Caminhou à frente, chamando com cautela: — Majestade? Majestade, está aí? O senhor... Ah!!

Um ruído às suas costas foi seguido por uma sombra que surgiu de repente diante dela.

Alguém a agarrou pela cintura e cobriu seus olhos. Como era medrosa, o susto repentino quase fez seu coração saltar pela garganta.

Lu Linyuan estivera escondido atrás da porta, querendo brincar com ela. Aproximava-se de seu ouvido, prestes a perguntar “adivinhe quem sou eu” com aquela voz grave e sedutora.

Mas, antes de abrir a boca, Ning Xiaoxiao desferiu para trás um golpe com toda a força que tinha.

*Crac!*

Ouviram isso? Foi o som de ovos e pepino esmagados juntos.

Lu Linyuan agachou-se, agarrando a região atingida, o rosto contorcido de dor e os olhos quase marejados.

Ning Xiaoxiao se virou, percebeu quem era e ficou petrificada.

Naquele instante, compreendeu perfeitamente que talvez tivesse acabado de destruir a própria felicidade com as próprias mãos...

Ajoelhou-se depressa ao lado dele, afagou-lhe a cabeça e exclamou, aflita:

— Ai, ai, Majestade! Com tanta brincadeira para inventar, por que resolveu fazer uma dessas idiotices? Não sabe que um susto desses pode matar alguém?

— Pronto, viu só? Agora os ovos foram para o espaço!

Ela passou a mão pelos cabelos dele, alisando-os.

— Aguente firme, está bem? Vou reiniciar isso para você!

Fechou os olhos, abriu o documento, acionou Retroceder e retomou a trama.

Tudo num único movimento, sem hesitar.

Dessa vez, estava completamente preparada. Quando Lu Linyuan a surpreendeu e cobriu seus olhos, como uma criança travessa, ela não se assustou. Apenas disse, com um suspiro resignado:

— Majestade, se está sem nada para fazer, procure uns memoriais para despachar...

Lu Linyuan: — ... Que sem graça.

Ele tirou a mão dos olhos dela, mas apertou ainda mais o braço em torno de sua cintura.

— O que foi? Por que está falando com tanta ironia? Não gostou que eu tenha restituído o título da Consorte Nobre?

— Claro que não. — Ning Xiaoxiao respondeu com toda a sinceridade. — Se tomou essa decisão, deve ter seus motivos. Por que eu ficaria chateada?

Ela realmente não estava chateada. Mas, em vez de se tranquilizar ao ouvir isso, Lu Linyuan assumiu uma expressão preocupada.

【Ela não está chateada? O pensamento corresponde ao que diz. Não está mentindo?】

【Não faz sentido... Dei um título a outra mulher. Por que ela não está com ciúmes?】

【Será que não se importa comigo?】

Aquele ciumento acabou sendo o primeiro a se irritar. — Não ficou chateada? Nem vai perguntar por que fiz isso?

Ning Xiaoxiao permaneceu serena. — Para que perguntar? Se quiser me contar, eu escuto. Se não quiser, mesmo perguntando, você vai inventar alguma mentira para me enganar. Para que me dar ao trabalho?

Ela sabia que Lu Linyuan usava aquilo como uma peça em seu jogo, esperando que a família Tong subisse cada vez mais alto para depois cair com mais força.

Mas, naquele momento, sua mente estava tranquila, sem pensar em nada. Por isso Lu Linyuan não sabia a razão daquela atitude.

No mundo moderno, um homem cuja namorada não se metesse em seus passos nem questionasse suas decisões e lhe desse liberdade total não ficaria nas nuvens?

Mas Lu Linyuan era completamente apaixonado pela namorada. O que queria mesmo era vê-la sentir ciúmes por ele.

Justamente então, um servo do Departamento de Assuntos da Alcova chegou com as placas de ponta verde para que o imperador escolhesse uma consorte.

Embora Lu Linyuan escolhesse Ning Xiaoxiao todos os dias, o protocolo precisava ser cumprido.

Quando entrou e a viu ali, o eunuco sorriu: — Ora, a Concubina Hua já está aqui. Então Sua Majestade não precisa escolher nenhuma placa hoje!

— Quem disse que não vou escolher? Traga-as!

Lu Linyuan o repreendeu num tom grave e soltou Ning Xiaoxiao.

O eunuco percebeu imediatamente que algo estava errado, apagou o sorriso e apresentou respeitosamente a bandeja com as placas verdes.

Lu Linyuan olhou de relance, pegou diretamente a placa da Consorte Nobre, virou-a e declarou: — Com um frio desses, não quero que a Consorte Nobre passe frio. Preparem a carruagem imperial. Hoje dormirei no palácio dela.

Ning Xiaoxiao franziu ligeiramente a testa e lançou-lhe um olhar assassino.

Ele, porém, fingiu não notar e foi embora.

*

Ao virar a placa da Consorte Nobre, Lu Linyuan fez com que a notícia chegasse aos espiões que cada palácio mantinha no Departamento da Alcova. Em menos de meia hora, o harém inteiro já sabia.

A Consorte Nobre nunca havia servido o imperador à noite. Estava exultante, mas também nervosa.

Mandou preparar uma mesa cheia de comida e ficou desde cedo à porta, esperando Lu Linyuan.

Ao avistar a carruagem imperial ao longe, arrumou depressa as roupas, incapaz de conter a alegria. Esperou que ela parasse diante da entrada e fez uma reverência cuidadosa, dizendo com voz melosa:

— Esta concubina dá as boas-vindas a Sua Majestade! Que Vossa Majestade tenha mil felicidades!

Lu Linyuan levantou a cortina, lançou-lhe um olhar e respondeu sem emoção: — Pode levantar-se. Está frio lá fora; a carruagem seguirá diretamente para dentro do seu palácio.

A carruagem imperial simbolizava a autoridade do soberano. Mesmo favorecendo Ning Xiaoxiao sem limites, Lu Linyuan jamais permitira que ela entrasse no Palácio Fengyi.

A Consorte Nobre ficou radiante. Seguiu a carruagem quase saltitando, até vê-la parar em frente aos seus aposentos.

— Majestade, preparei muitos dos pratos de que costuma gostar, além de um excelente vinho. Faz tanto tempo que não vem ao meu palácio. Eu...

— Não é preciso. — Lu Linyuan abriu a porta da carruagem e desceu. — Estou cansado. Vou direto dormir.

A Consorte Nobre ficou toda envergonhada. Baixou os olhos e mordeu o lábio. — Ai, Majestade! Com tantos criados por perto... Que homem terrível! Que maldade a sua!

Rebolando, aproximou-se para se enlaçar ao braço dele.

Mas, quando estava quase alcançando-o, viu Lu Linyuan estender a mão de volta para dentro da carruagem.

Em seguida, uma mão delicada entrelaçou os dedos aos dele. Ning Xiaoxiao pôs metade da cabeça para fora da carruagem e acenou com um sorriso:

— Oi! Boa noite, Consorte Nobre!

Consorte Nobre: — ?????

*

P.S.: Vou recomendar um livro de uma amiga escritora! Quem gosta de protagonistas fofinhas e delicadas pode conferir.

Título: *Depois de beijar à força o tirano obsessivo, a delicada inútil desatou a chorar*.

Autora: Shuowang Zhihui.

Romance doce e exclusivo, casal 1x1, ambos sem outros parceiros: tirano cruel e obsessivo × mocinha delicada, chorona e desajeitada.

# Validação — capítulo 217

- Fonte: `novel_capitulos_212_a_270(20261105-204934).docx` (chinês tradicional).
- Limites: índices DOCX base zero 359 a 425.
- Unidades não vazias traduzidas: **64**. Primeiro índice: 359. Último: 424.
- Cabeçalho CSV: `indice_docx,original_chines,traducao_portugues`.
- Índices duplicados: **0**. Traduções vazias: **0**. Parágrafos originais omitidos: **0**.
- O Markdown segue exatamente a sequência dos campos portugueses do CSV.

## Decisões editoriais

Os planos políticos de Lu Linyuan são apresentados como raciocínio interno, não acontecimentos já concluídos. Mantida a distinção entre empréstimo e presente da medalha conforme as falas de Ning Xiaoxiao, sem presumir sua devolução. O trocadilho sexual e as exclamações em colchetes foram preservados.

## Limites da validação

Verificação automatizada de cobertura estrutural 1:1, ordem, índices, integridade dos arquivos e da compactação. Revisão tradutória durante a elaboração, sem alegar auditoria semântica independente integral. A correspondência estrutural não comprova por si só ausência de erro de interpretação.

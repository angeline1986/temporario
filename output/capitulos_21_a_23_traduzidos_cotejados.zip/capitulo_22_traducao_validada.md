# Capítulo 22 — Você é o máximo, é grandioso, você e sua mãe pariram seu pai!

Lu Linyuan estendeu o punho, ansioso para começar. Um sorriso confiante e malicioso lhe iluminava o rosto, como se já tivesse a vitória garantida.

Ning Xiaoxiao pensou: 【Muito bem. Já que esse idiota quer tanto brincar, vou ter a bondade de lhe ensinar uma lição de vida!】

— Majestade, precisamos acertar as regras. Vamos decidir em uma rodada ou em melhor de três?

— Melhor de três. Vou lhe dar uma chance de resistir — respondeu Lu Linyuan.

Os dois se prepararam e a partida de pedra-papel-tesoura começou oficialmente.

Três, dois, um.

Os dois mostraram as mãos ao mesmo tempo.

Na primeira rodada, Lu Linyuan mostrou tesoura; Ning Xiaoxiao, papel.

Na segunda, Lu Linyuan mostrou pedra; Ning Xiaoxiao, tesoura...

A disputa inteira durou três segundos. Ao final, Lu Linyuan venceu, sem a menor surpresa.

Batendo os dedos compridos sobre a mesa, ele ergueu uma sobrancelha para ela. — Você perdeu.

Ning Xiaoxiao inclinou a cabeça e sorriu. — Não aceito. Essa não valeu. Vamos de novo.

Lu Linyuan franziu a testa e a encarou como se estivesse diante de uma louca. — O que disse? Repita.

— Eu disse que essa não valeu. Vamos de novo! Tem pelo de burro entupindo seus ouvidos?

— Que insolência! — Lu Linyuan bateu com força na mesa e se levantou, furioso como um leão de juba eriçada.

Diante do olhar espantado dele, Ning Xiaoxiao estendeu a mão e lhe afagou a cabeça, sorrindo toda travessa. — Calminha, bichinho. Não precisa se irritar!

Lu Linyuan estava no limite. Mas, bem quando ia explodir, Ning Xiaoxiao estalou os dedos diante dele.

O tempo retrocedeu instantaneamente três minutos.

Lu Linyuan estava sentado, imóvel, no trono. — Melhor de três. Vou lhe dar uma chance de resistir.

Os dois se prepararam e a partida começou outra vez.

Como já sabia o que Lu Linyuan ia escolher, Ning Xiaoxiao repetiu mentalmente:

【Primeiro, pedra. Depois, papel! Vitória garantida!】

Lu Linyuan lhe lançou um olhar de lado e abriu um sorriso divertido. *Heh. Que idiota.*

Três, dois, um.

Os dois mostraram as mãos ao mesmo tempo.

Na primeira rodada, Lu Linyuan mostrou papel; Ning Xiaoxiao, tesoura.

Na segunda, Lu Linyuan mostrou tesoura; Ning Xiaoxiao, papel...

Outra vitória esmagadora dele. Ning Xiaoxiao ficou completamente atônita.

【Ué! Por que ele não seguiu o roteiro? Por acaso a ficha desse personagem diz que ele ganha cem por cento das partidas de pedra-papel-tesoura?】

【Não! Vamos mais uma vez!】

Dessa vez, ela havia gastado algum tempo com a discussão. Quando retrocedeu três minutos, os dois já estavam prestes a mostrar as mãos.

Sem tempo para pensar, Ning Xiaoxiao fez sua jogada e, inesperadamente, venceu duas rodadas seguidas. Ficou tão entusiasmada que soltou uma gargalhada.

Ela ria, mas agora era Lu Linyuan quem estava à beira da depressão.

*O que há de errado com essa maluca?*

*Antes de jogar, ela nem pensa no que vai mostrar?*

Imitando a postura anterior dele, Ning Xiaoxiao bateu de leve os dedos na mesa e ergueu uma sobrancelha. — Majestade, o senhor perdeu. Aposta é aposta! Disse que, se eu ganhasse, me daria tudo o que pedisse. Nada de voltar atrás!

— Sou o soberano deste império. Minha palavra tem o peso de nove tripés de bronze. É claro que não vou quebrá-la — respondeu Lu Linyuan com um sorriso frio.

— Então eu quero...

— Um instante. — Lu Linyuan ergueu a mão e pousou o indicador sobre os lábios finos e rosados de Ning Xiaoxiao. — Mas, para isso, você precisa ganhar.

— E eu ganhei! Era melhor de três!

— Melhor de três, sim. Só que, no palácio, a regra do pedra-papel-tesoura é vencer quem perder mais rodadas. Eu perdi duas agora, logo fui quem mais perdeu. Portanto, a vitória é minha, não sua.

— Desde quando existe uma regra dessas? Majestade, isso é trapaça!

Lu Linyuan recostou-se preguiçosamente na cadeira com uma expressão irritantemente convencida, como quem dizia: *Estou trapaceando. E o que você vai fazer a respeito?*

— As regras deste mundo são determinadas por mim.

— Minha palavra é a lei!

As duas frases soaram tão imponentes que praticamente transbordavam autoridade.

Mas Ning Xiaoxiao não sentiu autoridade nenhuma. O que quase transbordou foi a vergonha alheia.

Ela revirou os olhos para Lu Linyuan e, furiosa, soltou um palavrão em pensamento:

【Ah, você é o máximo! É grandioso! Você e sua mãe pariram seu próprio pai!】

Lu Linyuan não compreendeu a segunda metade daquela frase. Afinal, ainda não sabia o significado das palavras modernas *pai* e *mãe* que ela empregara.

Mas a primeira metade ele compreendeu.

Ela vivia usando a expressão *o máximo* quando encontrava alguma coisa extraordinária. Devia ser um elogio.

E *grandioso* era ainda mais óbvio: também era um elogio.

*Ela está dizendo que sou o máximo?*

*Que sou grandioso?*

Lu Linyuan a examinou, bastante satisfeito.

*Será que finalmente reconheceu meu charme pessoal? Será que vai parar de me chamar de imperador idiota e, até nos próprios pensamentos, só terá palavras de admiração por mim?*

【Por que esse imperador idiota está sorrindo para mim? Ficou doente?】

Lu Linyuan: "..."

*Que raiva! Mas preciso continuar sorrindo.*

— Você perdeu. E aposta é aposta. A partir de amanhã, virá comigo às audiências da corte para registrar tudo o que acontecer por lá.

Ning Xiaoxiao fez uma cara aflita. — Majestade... não é que esta serva não queira acompanhá-lo. Mas... mulheres não podem interferir nos assuntos de Estado. Além disso, sou apenas uma criada de condição humilde. Como poderia...?

— Não tem problema. Já pensei nisso. Você se vestirá de homem e fingirá ser um eunuco.

Ning Xiaoxiao olhou para o próprio busto. Tamanho D... ou seria E? Depois olhou para Lu Linyuan, constrangida. — Majestade... acha mesmo que um eunuco com peitorais deeeeeeste tamanho pareceria convincente?

— Cof! Cof! Cof!... — Lu Linyuan se engasgou com a própria saliva e tossiu várias vezes.

Realmente, Ning Xiaoxiao era bastante... avantajada.

Além disso, tinha feições delicadas e pele clara. Qualquer um perceberia de imediato que não era um eunuco.

Vendo o silêncio dele, Ning Xiaoxiao aproveitou para insistir. — Então é melhor Vossa Majestade procurar um eunuco de verdade para fazer os registros. Não é que eu não queira ajudar. É que... minhas características físicas impõem várias limitações.

Lu Linyuan segurou o queixo com a mão esquerda e refletiu um instante. De repente, seus olhos brilharam: tivera uma ótima ideia.

— Não importa. Já que deseja tanto ajudar, encontrarei uma maneira de mantê-la escondida durante as audiências.

— Hein? Que maneira?

Lu Linyuan deu algumas batidinhas na superfície da mesa diante dele e olhou para Ning Xiaoxiao com um sorriso enigmático, sem dizer palavra.

— O que isso quer dizer?

Lu Linyuan enfiou a mão por baixo da mesa e bateu na parte inferior do tampo.

Ning Xiaoxiao entendeu na hora.

【Esse imperador idiota não está querendo que eu me enfie debaixo da mesa, está?】

— Majestade... não vai me mandar ficar escondida debaixo da sua mesa amanhã, vai?

— Inteligente — respondeu Lu Linyuan, sorrindo. — Há bastante espaço debaixo da mesa imperial do Palácio Chaoyang, e você é pequena. Vai caber perfeitamente. Assim, ninguém a verá.

Ning Xiaoxiao: "???"

【Você está maluco?! Me enfiar debaixo da mesa não é quase a mesma coisa que me enfiar entre as suas pernas? Nem morta!】

— Ou se enfia debaixo da mesa ou perde a cabeça. Escolha.

【Imperador maldito! Isso é o que você chama de me dar uma escolha?!】

Por dentro, Ning Xiaoxiao amaldiçoou as dezoito gerações de antepassados de Lu Linyuan. Mas, em voz alta, disse com um sorrisinho:

— Perder a cabeça ou não é o de menos, Majestade. O importante é que esta serva adora se enfiar debaixo de mesas...

Lu Linyuan lançou-lhe um olhar de lado e soltou um risinho desdenhoso. — Heh. Que bom que gosta.

---

## Notas editoriais

- 你牛逼，你偉大，你和你媽生你爸: insulto absurdo com elogios aparentes e inversão da genealogia, preservado o nonsense em português.
- A regra inventada pelo imperador inverte o critério do pedra-papel-tesoura; a protagonista ganha as rodadas mas o imperador impõe a vitória a quem mais perdeu.
- 一言九鼎: idiomatismo sobre a palavra de uma autoridade, vertido com referência aos nove tripés de bronze.
- O retrocesso de três minutos é repetição narrativa deliberada.

# Relatório de cotejo e revisão — Capítulo 23

**Fonte primária:** `novel_capitulos_1_a_60(20261103-131325).docx` (chinês tradicional).

**Unidades textuais chinesas não vazias:** 77 (título incluído).

**Correspondências no arquivo CSV:** 77 de 77.

**Unidades sem tradução:** 0.

## Verificações realizadas

- A seção foi delimitada entre `第23章` e `第24章`.
- Cada unidade do DOCX foi traduzida individualmente e registrada na sequência original, incluindo o título.
- Foi feita revisão editorial da coerência dos nomes, do andamento cronológico, dos sujeitos e de quantidades, diálogos e falas internas.
- As notas editoriais se encontram fora do corpo da narrativa.

## Pontos sensíveis da tradução

- O título usa 那事 (“aquilo”) para insinuar uma atividade íntima; a cena é uma série de mal-entendidos em audiência imperial.
- 水陸大法事: grande ritual budista de água e terra, mantida a natureza ritual.
- 三合星鎖饕餮: ocorrência celeste fantástica envolvendo Taotie; mantida a referência sem inventar interpretação astronômica.
- 左D / 右D: referência humorística aos seios da protagonista; não converter em medida física.
- O imperador permite que Gu Sijin descanse para liberar Ning Xiaoxiao para o trabalho de escrivã secreta.

## Limites e conclusão

O capítulo tem **cotejo estrutural completo** e revisão semântica pelo próprio tradutor. Não foi executada uma segunda auditoria linguística independente, de modo que não há certificação de precisão absoluta. Revisões futuras podem corrigir nuances e formulações preservando o original como referência.

# Capítulo 23 — Chocante! O tirano faz aquilo com uma criada em plena audiência imperial!

Gu Sijin ficou doente outra vez.

Dessa vez, o médico imperial diagnosticou uma distensão dos ligamentos causada por exercícios físicos intensos.

A notícia se espalhou imediatamente pelo palácio.

Quando as consortes dos seis palácios foram apresentar seus respeitos à imperatriz, a Consorte Nobre olhou para o assento vazio de Gu Sijin com uma expressão de desprezo. — Ela faltou de novo?

A Consorte Li comentou: — Quem dera tivéssemos a habilidade dela! Toda vez que passa a noite servindo o imperador, recebe permissão para não comparecer aos cumprimentos à imperatriz no dia seguinte.

A Consorte Yun disse: — Ouvi dizer que está doente outra vez. Parece que distendeu os ligamentos depois de uma atividade física intensa. Consorte Duan, você mora com ela. Sabe o que aconteceu exatamente?

A Consorte Duan baixou a cabeça, um pouco envergonhada. — Quando voltou dos aposentos do imperador, depois de servi-lo, mancava tanto que mal conseguia andar. Os dois são jovens e cheios de energia. Sua Majestade gosta dela e talvez... tenha se deixado levar pela paixão e exagerado na força...

As outras consortes: "..."

Mas Lu Linyuan não havia autorizado Gu Sijin a descansar por estar preocupado com ela.

Era porque, se Gu Sijin ficasse de repouso e não precisasse ir cumprimentar a imperatriz, Ning Xiaoxiao teria tempo para se enfiar debaixo da mesa imperial.

Assim, ainda era madrugada e nem tinha amanhecido quando Lu Linyuan levou Ning Xiaoxiao ao Salão Jinluan.

Era a primeira vez que Ning Xiaoxiao entrava naquele lugar, verdadeira vitrine do palácio imperial da dinastia Qi. Como esperado, a decoração era tão luxuosa e dourada que quase lhe cegou os olhos.

A mesa imperial de Lu Linyuan ficava no centro, no fundo do grande salão.

Atrás dela havia uma parede com nove dragões, e diante da mesa, apenas o trono imperial.

Era ali que Lu Linyuan se sentava durante as audiências.

Depois de se acomodar no trono, ele chamou Ning Xiaoxiao com um gesto do dedo. — Venha. Entre aí embaixo.

Com uma expressão de quem estava prestes a chorar, Ning Xiaoxiao rastejou para debaixo da mesa, contrariada.

Só então percebeu que Lu Linyuan já deixara papel e pincel preparados para ela desde cedo.

Não havia muito espaço para se mexer sob a mesa. Além disso, as pernas de Lu Linyuan bloqueavam parte da passagem: bastava um movimento um pouco mais amplo para os dois entrarem em contato físico bastante íntimo.

E o pior era que ela não podia virar a cabeça. Se olhasse para trás, ficaria cara a cara com a... virilha de Lu Linyuan.

*Com aquele volume todo... nada de pensamentos indecentes!*

Cerca de quinze minutos depois, os ministros que aguardavam do lado de fora começaram a entrar, ao som do anúncio de Sanfu: — Começa a audiência imperial!

Todos se reuniram no salão, ajoelharam-se e saudaram: — Prestamos nossos respeitos a Vossa Majestade! Que o imperador viva dez mil anos, dez mil anos, dez mil vezes dez mil anos!

— Podem levantar-se, meus ministros.

Sanfu anunciou: — Quem tiver assuntos a apresentar, que fale. Se não houver, encerraremos a audiência!

Ning Xiaoxiao começou a escrever freneticamente. Só que não estava acostumada a usar um pincel de caligrafia. Quando Sanfu já tinha terminado de dizer "encerraremos a audiência", ela ainda estava escrevendo "dez mil anos, dez mil anos, dez mil vezes dez mil anos".

A intenção inicial de Lu Linyuan era fazê-la distinguir os ministros leais dos traidores à medida que apresentassem seus relatórios.

Mas, para sua surpresa, Ning Xiaoxiao não revelou um único detalhe da trama. Ficou apenas registrando tudo o que os ministros diziam.

Enquanto escrevia, reclamava mentalmente:

【Você está fazendo um número de comédia, por acaso?】

【Alugou essa boca por dez moedas ao dia e precisa devolvê-la daqui a pouco? Por que fala tão depressa?!】

【Meu camarada, você é rapper agora?!】

Mas aquilo não era nada. Ning Xiaoxiao só entrou em verdadeiro desespero quando o diretor do Observatório Astronômico Imperial começou a apresentar seu relatório sobre os fenômenos celestes.

— Majestade, ao observar as estrelas durante a noite, este humilde ministro percebeu alterações no fenômeno dos três astros combinados que aprisionam Taotie. Peço que Vossa Majestade ordene uma grande cerimônia ritual de água e terra e sele as criaturas malignas, para assegurar a prosperidade do império.

Ning Xiaoxiao: "..."

Ela ficou sem reação.

Não bastava falarem depressa. Ainda precisavam usar justamente caracteres que ela nem sabia escrever!

O próximo a falar foi um general, um homem rude, que abria a boca sem passar as palavras pela cabeça.

Era colega de Wei Yan e mantinha com ele uma amizade muito próxima.

Ao saber que Lu Linyuan mandara executar Wei Yan secretamente, não resistiu à vontade de defendê-lo.

— Este ministro considera que Vossa Majestade foi longe demais ao executar o general Wei! Wei Yan lutou por todos os cantos do império durante tantos anos! Mesmo que não tivesse grandes méritos, seus esforços deveriam ser reconhecidos! Vossa Majestade o condenou à morte só por suspeitar que ele fugiria levando dinheiro, sem lhe dar sequer a oportunidade de se explicar! Isso só vai desanimar os nossos comandantes militares!

Lu Linyuan fitou-o com frieza. — É um fato incontestável que Wei Yan tentou fugir levando trinta mil taéis de prata. O sul sofre com uma calamidade natural, o povo está na miséria, e ele ousou desviar dinheiro destinado a salvar vidas. Qual é o problema de eu tê-lo executado?

— Sou um soldado grosseiro e não entendo dessas coisas, mas acredito que o general Wei jamais faria algo assim!

Lu Linyuan se irritou. — Você acredita? Está disposto a garantir a inocência dele com a própria cabeça e a vida da sua esposa e dos seus filhos?!

— Isso...

Lu Linyuan ordenou que Sanfu apresentasse ao general a mensagem enviada por pombo-correio pelo guarda de elite que executara Wei Yan naquele dia. Mandou que a lesse com atenção.

Depois de ler, o homem descobriu que havia provas irrefutáveis de que Wei Yan desviara os recursos que devia proteger. Ele realmente merecera a morte.

O general caiu de joelhos e se desculpou depressa. — Este ministro foi cego como um cão e confiou na pessoa errada! Ousei ofender Vossa Majestade por causa de um verme desprezível! Peço que me puna!

Como o general era leal, Lu Linyuan não o castigou. Apenas declarou: — Se houver outros na corte que, como Wei Yan, desviem recursos sob sua guarda e desprezem a vida do povo, não terei piedade! Desta vez mandei cortar a cabeça de Wei Yan. Agora que ele serviu de exemplo, quem ousar seguir seus passos terá a pele arrancada!

Ao terminar, bateu na mesa com raiva, deixando clara sua autoridade imperial.

Só que parecia ter se esquecido completamente de que Ning Xiaoxiao ainda estava escondida lá embaixo.

O estrondo assustou tanto Ning Xiaoxiao que ela soltou, sem pensar: — Nossa senhora!

A voz nitidamente feminina foi ouvida por todos. Os presentes olharam em volta, desconfiados, procurando de onde vinha o som.

Lu Linyuan deu um chute em Ning Xiaoxiao, pretendendo apenas avisá-la para ficar quieta.

Só que o pé acertou em cheio o lado esquerdo de seu busto, tamanho D.

Ning Xiaoxiao arregalou os olhos, horrorizada, e protegeu o peito com as duas mãos.

Lu Linyuan sentiu o pé tocar alguma coisa macia e pensou que não havia acertado Ning Xiaoxiao. Por isso, deu mais um chute.

Dessa vez, por puro azar, atingiu o lado direito do busto, também tamanho D.

*De propósito! Ele só pode estar fazendo isso de propósito!*

Furiosa, Ning Xiaoxiao estendeu a mão e beliscou com toda a força a coxa de Lu Linyuan.

— Aaaaaah!

Pego de surpresa pelo beliscão, Lu Linyuan deu um grito uma oitava mais agudo, com um tremor na voz que o deixava um tanto... sugestivo.

Os ministros o encararam, perplexos. — Majestade, o que aconteceu?

Lu Linyuan ficou tão constrangido que seu rosto se tornou vermelho. Agitou a mão. — Nada! Eu só estava limpando a garganta. Continuem!

Ning Xiaoxiao também deixou de lhe dar atenção e voltou a registrar as falas dos ministros com o pincel.

Enquanto escrevia, começou a sentir uma coceira no pescoço.

Sem pensar, levou a mão até lá e coçou.

Quem diria que acabaria agarrando uma barata do tamanho de um terço da palma da sua mão?!

Ela, que vinha do norte, nunca tinha visto uma coisa daquelas!

O susto foi tão grande que sua alma quase abandonou o corpo!

— AAAAAAAAAAAH!!!

Um grito ensurdecedor escapou de sua garganta.

No instante seguinte, como se tivesse despertado uma força sobre-humana, Ning Xiaoxiao ergueu a mesa imperial e a virou de uma vez. Depois saltou para cima de Lu Linyuan, passou os braços ao redor do pescoço dele e ficou pendurada em seu corpo feito um coala.

— AAAAAH! U-UMA BARATA!!!!

Lu Linyuan: "!!!"

Os ministros: "???"

---

## Notas editoriais

- O título usa 那事 (“aquilo”) para insinuar uma atividade íntima; a cena é uma série de mal-entendidos em audiência imperial.
- 水陸大法事: grande ritual budista de água e terra, mantida a natureza ritual.
- 三合星鎖饕餮: ocorrência celeste fantástica envolvendo Taotie; mantida a referência sem inventar interpretação astronômica.
- 左D / 右D: referência humorística aos seios da protagonista; não converter em medida física.
- O imperador permite que Gu Sijin descanse para liberar Ning Xiaoxiao para o trabalho de escrivã secreta.

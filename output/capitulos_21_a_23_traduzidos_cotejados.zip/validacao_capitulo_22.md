# Relatório de cotejo e revisão — Capítulo 22

**Fonte primária:** `novel_capitulos_1_a_60(20261103-131325).docx` (chinês tradicional).

**Unidades textuais chinesas não vazias:** 86 (título incluído).

**Correspondências no arquivo CSV:** 86 de 86.

**Unidades sem tradução:** 0.

## Verificações realizadas

- A seção foi delimitada entre `第22章` e `第23章`.
- Cada unidade do DOCX foi traduzida individualmente e registrada na sequência original, incluindo o título.
- Foi feita revisão editorial da coerência dos nomes, do andamento cronológico, dos sujeitos e de quantidades, diálogos e falas internas.
- As notas editoriais se encontram fora do corpo da narrativa.

## Pontos sensíveis da tradução

- 你牛逼，你偉大，你和你媽生你爸: insulto absurdo com elogios aparentes e inversão da genealogia, preservado o nonsense em português.
- A regra inventada pelo imperador inverte o critério do pedra-papel-tesoura; a protagonista ganha as rodadas mas o imperador impõe a vitória a quem mais perdeu.
- 一言九鼎: idiomatismo sobre a palavra de uma autoridade, vertido com referência aos nove tripés de bronze.
- O retrocesso de três minutos é repetição narrativa deliberada.

## Limites e conclusão

O capítulo tem **cotejo estrutural completo** e revisão semântica pelo próprio tradutor. Não foi executada uma segunda auditoria linguística independente, de modo que não há certificação de precisão absoluta. Revisões futuras podem corrigir nuances e formulações preservando o original como referência.

# Relatório de cotejo e revisão — Capítulo 21

**Fonte primária:** `novel_capitulos_1_a_60(20261103-131325).docx` (chinês tradicional).

**Unidades textuais chinesas não vazias:** 67 (título incluído).

**Correspondências no arquivo CSV:** 67 de 67.

**Unidades sem tradução:** 0.

## Verificações realizadas

- A seção foi delimitada entre `第21章` e `第22章`.
- Cada unidade do DOCX foi traduzida individualmente e registrada na sequência original, incluindo o título.
- Foi feita revisão editorial da coerência dos nomes, do andamento cronológico, dos sujeitos e de quantidades, diálogos e falas internas.
- As notas editoriais se encontram fora do corpo da narrativa.

## Pontos sensíveis da tradução

- O título usa “aquela coisa” (那事) como isca de duplo sentido; a revelação é um jogo de pedra-papel-tesoura, não uma cena íntima.
- 黃燜雞米飯: arroz com frango ensopado de preparação chinesa; mantida descrição compreensível.
- 顧答應: Atendente Gu, título palaciano inferior, distinto de consorte.
- Conferir a continuidade da confissão e da lesão de Cailian com o capítulo 20.

## Limites e conclusão

O capítulo tem **cotejo estrutural completo** e revisão semântica pelo próprio tradutor. Não foi executada uma segunda auditoria linguística independente, de modo que não há certificação de precisão absoluta. Revisões futuras podem corrigir nuances e formulações preservando o original como referência.

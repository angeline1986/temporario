# Capítulo 21 — O tirano me obriga a fazer aquilo no meio da noite, em vez de dormir

Cailian podia quebrar a cabeça quanto quisesse: jamais imaginaria que toda aquela encenação de Ning Xiaoxiao tinha servido para obrigá-la a confessar o próprio crime.

Com uma confissão escrita de próprio punho, para que precisariam de outras provas?

Tanto ferir o magnífico cavalo presenteado pelo imperador quanto fazer o animal se assustar e avançar contra Lu Linyuan eram crimes puníveis com a morte.

Cailian perdeu toda a cor do rosto. Mal conseguia articular as palavras: — Xiaoxiao, você... você não pode fazer isso... Eu só estava brincando com você. Se... se fizer isso, vai acabar me matando!

— Já passou pela sua cabeça que talvez seja exatamente isso que eu queira?

Ning Xiaoxiao deixou aquelas palavras geladas para trás e caminhou decidida até a porta.

Quanto mais cedo uma encrenqueira como Cailian, que já causava tantos problemas no romance original, saísse de cena, menos dores de cabeça haveria depois.

Ning Xiaoxiao não era Gu Sijin. Não ia amolecer só porque Cailian chorava como uma desesperada.

Só não esperava que, assim que abrisse a porta, a primeira pessoa que encontraria seria justamente Gu Sijin.

Ao ver Cailian prostrada no chão, banhada em lágrimas e ainda com um grampo de cabelo cravado na coxa, Gu Sijin correu para ajudá-la a se erguer. — O que aconteceu aqui?

Cailian agarrou o braço dela e implorou entre soluços: — Senhorita! Impeça Xiaoxiao! Se ela for me denunciar diante do imperador, Sua Majestade certamente vai me matar!

Ning Xiaoxiao já sabia: a santa ia entrar em ação mais uma vez com seu milagroso dom de salvar a humanidade inteira.

Gu Sijin se apressou em segurar Ning Xiaoxiao. Com expressão séria, perguntou: — Xiaoxiao, o que aconteceu entre você e Cailian?

Ning Xiaoxiao lhe contou tudo, do começo ao fim, sem esconder nada. Gu Sijin voltou o olhar grave para Cailian. — Você fez mesmo uma coisa dessas?

Cailian baixou os olhos. Lágrimas enormes começaram a rolar pelo rosto.

Ela apertou os lábios e assentiu de leve, parecendo até arrependida. — Senhorita, esta serva sabe que errou... Buááá... Tive inveja de Xiaoxiao e perdi a cabeça. Quando morávamos na residência, eu era a pessoa mais próxima da senhorita. A senhorita me contava tudo. Mas, depois que entramos no palácio, a senhorita passou a ter Xiaoxiao e já não é tão próxima de mim.

Soluçou como se o mundo estivesse acabando. — E Qiqi, Qiaqia e as outras também preferem Xiaoxiao. Quase nunca me dão atenção... Fiquei tão cega de ciúme que cometi essa besteira. Por favor, senhorita, lembre-se de todos esses anos em que cuidei da senhora e me perdoe!

Cailian conhecia bem o coração mole de Gu Sijin. Por isso, resolveu apelar para o sentimentalismo.

Na antiga residência, Gu Sijin não tinha escolha: Cailian era sua única criada pessoal, de modo que naturalmente se apoiava nela para tudo.

Mas, agora no palácio, a divertida e extrovertida Ning Xiaoxiao contrastava demais com a preguiçosa Cailian, que vivia reclamando. Sem perceber, Gu Sijin se aproximara mais de Xiaoxiao.

Depois de ouvir aquela história, Gu Sijin realmente achou que tinha sido culpa sua e que sua conduta havia provocado o ciúme de Cailian.

Por isso, disse: — Não é a mim que você deve pedir desculpas, mas a Xiaoxiao.

Cailian se ajoelhou diante de Ning Xiaoxiao e começou a bater a testa no chão. — Xiaoxiao, eu errei! Me perdoe! Eu juro que nunca mais faço isso!

Diante de tantas lágrimas e súplicas, o coração de Ning Xiaoxiao permaneceu absolutamente imóvel. Na verdade, ela estava até com vontade de comer uma bela tigela de arroz com frango ensopado.

Por fim, Gu Sijin interferiu para reconciliá-las. — Eu também tenho parte da culpa por Cailian ter agido assim. Xiaoxiao, perdoe-a desta vez. Afinal, quem nunca errou? O importante é reconhecer o erro e mudar.

Com a maior naturalidade, ela tirou o documento das mãos de Ning Xiaoxiao. — Vou guardar esta confissão. Se ela continuar teimando e não se arrepender, eu mesma a entregarei ao imperador. O que acha?

Ning Xiaoxiao ficou sem palavras.

Nunca tinha visto alguém tão irremediavelmente incapaz de aprender uma lição.

Já que Gu Sijin fazia tanta questão de manter aquela bomba-relógio ao seu lado, Ning Xiaoxiao nem se daria ao trabalho de discutir.

Afinal, quem ia sofrer as consequências no futuro era Gu Sijin, não ela. Por que se meter em problema alheio?

De todo modo, Gu Sijin não deixou Cailian completamente impune. Entregou a Ning Xiaoxiao o cargo de criada encarregada. Daquele momento em diante, todos os servos que atendiam o pavilhão oriental do Palácio Zhongcui, em assuntos grandes ou pequenos, teriam de obedecer às suas ordens. Era também uma forma de cortar as asas de Cailian.

Na hora do jantar, enquanto Gu Sijin comia com a Consorte Duan, um eunuco do Departamento dos Aposentos Imperiais apareceu novamente com um recado.

Naquela noite, Lu Linyuan havia escolhido mais uma vez a placa de Gu Sijin.

A Consorte Duan sorriu para ela. — Você tem sorte! O imperador não a tira da cabeça. Mal se recuperou da doença e ele já escolheu sua placa de novo. Até eu fico com inveja!

Gu Sijin, porém, estava com o rosto tomado pela preocupação. Não conseguia esboçar um sorriso.

Afinal, a última coisa que queria era voltar ao Palácio Chaoyang para passar outra noite inteira fazendo ginástica aeróbica...

Conforme as regras, ainda precisava levar uma criada para permanecer de vigília no Palácio Chaoyang.

Cailian tinha a coxa ferida e mal podia se movimentar. Qiqi, Qiaqia e Lala eram criadinhas que se atrapalhavam diante de qualquer imprevisto, ao contrário de Ning Xiaoxiao, que sabia resolver as coisas com competência.

Por isso, Gu Sijin disse a Ning Xiaoxiao: — Esta noite, venha comigo ao Palácio Chaoyang outra vez.

Ao ouvir aquilo, Ning Xiaoxiao teve vontade de morrer.

Mas não encontrou uma desculpa para recusar. Só lhe restou aceitar, rezando para que Lu Linyuan não inventasse mais nenhuma maluquice naquela noite.

O problema é que, quando estava de vigília, voltou a escutar sons muito esquisitos vindos dos aposentos:

— Isso! Pule! Um, dois, três, quatro! Cinco, seis, sete, oito!

— Levante mais as pernas! Controle a respiração!

— Seu pai disse que sua constituição é fraca e pediu que eu cuidasse melhor de você. Se está fraca, é porque lhe falta exercício. Veja só: hoje já não está indo melhor que da última vez?

Ning Xiaoxiao levou a mão à testa.

【O pai dela pediu para você cuidar melhor dela NA CAMA, não para obrigá-la a fazer exercícios FORA DA CAMA!】

【Desse jeito, você vai transformá-la numa Barbie bombada. Quando ela finalmente vier lhe servir de verdade, vai acabar dando um chute que vai mandar você pelos ares. Aí quero ver se não foi você mesmo que procurou sarna para se coçar!】

Ela estava no auge dos comentários indignados quando a porta se abriu. De novo.

Dessa vez, Lu Linyuan nem se deu ao trabalho de falar com ela. Simplesmente agarrou-a pela gola e a levou dali...

Depois do caso de Wei Yan, já não havia dúvida para Lu Linyuan de que Ning Xiaoxiao sabia o que aconteceria no futuro.

Entretanto, se apenas a fizesse ler memoriais, muitos dos funcionários que moravam na capital e compareciam diariamente à audiência já teriam apresentado suas questões pessoalmente. Eles raramente precisavam enviar documentos escritos.

Lu Linyuan queria descobrir quantas correntes traiçoeiras se escondiam sob a aparente tranquilidade da corte.

E o jeito mais simples de distinguir os ministros leais dos traidores seria levar Ning Xiaoxiao às audiências, para que tivesse contato com eles.

Assim, ele disse: — O funcionário encarregado de registrar os acontecimentos das audiências adoeceu gravemente e não poderá comparecer nestes dias. Ainda não encontrei alguém adequado para substituí-lo. A Atendente Gu disse que você é inteligente e escreve depressa. Acho que esse trabalho combina com você.

*Combina comigo?*

*Combina é com a mãe que te pariu!*

— Majestade, esta serva já passa o dia atendendo a Atendente Gu. O palácio tem tantas tarefas que mal dou conta delas. Como encontraria tempo para registrar tudo o que os ministros dizem nas audiências? E se, por um instante de distração, eu escrever alguma coisa errada? Isso não provocaria uma grande confusão?

Lu Linyuan lançou-lhe um olhar. No instante seguinte, um punho do tamanho de uma pedra surgiu diante do rosto dela.

Ning Xiaoxiao achou que ele ia lhe dar um soco e se acovardou imediatamente!

Já estava prestes a aceitar quando o ouviu dizer:

— Vamos disputar no pedra-papel-tesoura. Se você ganhar, eu lhe darei qualquer coisa que pedir. Se perder, fará o que eu mandar, sem mais desculpas.

*???*

【Esse imperador idiota sacudiu tanto a cabeça fazendo ginástica com Gu Sijin que acabou deslocando o cérebro?】

【No meio da madrugada, em vez de dormir, ele quer brincar de pedra-papel-tesoura comigo?】

【Dá para ficar mais absurdo que isso...?】

---

## Notas editoriais

- O título usa “aquela coisa” (那事) como isca de duplo sentido; a revelação é um jogo de pedra-papel-tesoura, não uma cena íntima.
- 黃燜雞米飯: arroz com frango ensopado de preparação chinesa; mantida descrição compreensível.
- 顧答應: Atendente Gu, título palaciano inferior, distinto de consorte.
- Conferir a continuidade da confissão e da lesão de Cailian com o capítulo 20.

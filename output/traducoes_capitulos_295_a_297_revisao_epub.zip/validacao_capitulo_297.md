# Validação — capítulo 297

- Fonte chinesa: `novel_capitulos_271_a_300(20261106-202952).docx`.
- Tradução-base portuguesa: `novel capitulos 271 a 300 - ch.epub`, arquivo `index_split_026.html`.
- Índices globais do DOCX: 1762 a 1823, com fim exclusivo em 1824.
- Unidades não vazias: **59**, sendo um título e 58 parágrafos de corpo.
- Correspondência de corpo EPUB–chinês: **58 para 58**.
- Unidades alteradas frente ao EPUB: **13** (inclui padronizações lexicais, não somente erros de sentido).
- Índices relativos das unidades alteradas: 8, 11, 12, 15, 17, 23, 24, 26, 27, 35, 42, 43, 46.

## Correções editoriais

- Nomes de Sanfu e Ahuan e posto de Consorte Nobre Imperial padronizados.
- Corrigidos trechos de gênero ou referente mal atribuído e expressões culturalmente imprecisas onde detectados.
- Conservadas a progressão narrativa, as quebras e as unidades do documento chinês.
- *Tianmaren* mantém a referência à substância do romance, sem equipará-la sem ressalvas a uma espécie botânica cientificamente identificada.
- Preservada a possessão de Xia Guo por Ning; corrigido o palácio em que Ning desperta.

## Escopo e limites

- Os CSVs mantêm o índice real base zero de cada parágrafo do DOCX, inclusive título e marcador.
- Confronto estrutural integral; revisão semântica **dirigida**, não uma auditoria frase a frase independente. Trechos da tradução-base podem ainda conter falhas não identificadas.
- A correspondência 1:1 de parágrafos não prova fidelidade semântica.

# Validação — capítulo 296

- Fonte chinesa: `novel_capitulos_271_a_300(20261106-202952).docx`.
- Tradução-base portuguesa: `novel capitulos 271 a 300 - ch.epub`, arquivo `index_split_025.html`.
- Índices globais do DOCX: 1697 a 1761, com fim exclusivo em 1762.
- Unidades não vazias: **62**, sendo um título e 61 parágrafos de corpo.
- Correspondência de corpo EPUB–chinês: **61 para 61**.
- Unidades alteradas frente ao EPUB: **21** (inclui padronizações lexicais, não somente erros de sentido).
- Índices relativos das unidades alteradas: 3, 4, 7, 8, 11, 13, 14, 17, 24, 25, 27, 28, 33, 34, 36, 40, 43, 44, 46, 47, 53.

## Correções editoriais

- Nomes de Sanfu e Ahuan e posto de Consorte Nobre Imperial padronizados.
- Corrigidos trechos de gênero ou referente mal atribuído e expressões culturalmente imprecisas onde detectados.
- Conservadas a progressão narrativa, as quebras e as unidades do documento chinês.
- *Tianmaren* mantém a referência à substância do romance, sem equipará-la sem ressalvas a uma espécie botânica cientificamente identificada.
- Corrigidas as acusações hipotéticas contra Ning, o sujeito dos pensamentos e a ordem da imperatriz para eliminar uma testemunha.

## Escopo e limites

- Os CSVs mantêm o índice real base zero de cada parágrafo do DOCX, inclusive título e marcador.
- Confronto estrutural integral; revisão semântica **dirigida**, não uma auditoria frase a frase independente. Trechos da tradução-base podem ainda conter falhas não identificadas.
- A correspondência 1:1 de parágrafos não prova fidelidade semântica.

# Capítulo 297 — Pagar na mesma moeda

"Socorro! Socorro! Alguém me salve!"

Talvez porque seus ferimentos estivessem gradualmente infeccionando e se aprofundando, a Imperatriz sentia dores extremas e gritou por socorro.

Quanto mais alto ela gritava, mais sinistro se tornava o sorriso de Xia Guo.

Ela chamou três ou quatro vezes, mas ninguém respondeu. A dor lancinante em seu corpo a impedia de falar uma frase completa; ela só conseguia arfar e gemer.

Xia Guo deu dois tapas na bochecha com a mão ensanguentada, ergueu uma sobrancelha e sorriu.

"Por que você parou de gritar? Está sem energia? Devo te ajudar?"

Ela imitou o tom da Imperatriz e gritou de forma afetada: "Socorro! Estou com tanto medo!"

Quando terminou, o sorriso lhe desapareceu do rosto, e Xia Guo empurrou a imperatriz violentamente ao chão.

A camisola da Imperatriz estava encharcada de sangue. Xia Guo aproximou-se dela passo a passo, com um tom brincalhão:

"Vossa Majestade sabe por que não consegue convocar ninguém?"

— Tudo o que esta serva faz é pelo bem de Vossa Majestade. A imperatriz não adora as flores de jasmim-de-inverno?

— As flores de jasmim-de-inverno do Jardim Imperial desabrocharam. Como criada-chefe, conheço os gostos de Vossa Majestade; por isso mandei todos os servos do Palácio Fengluan colhê-las para a senhora.

Ela se agachou, ergueu o queixo da Imperatriz, piscou seus olhos amendoados e estreitos e falou suavemente:

"Sua Majestade está satisfeita por as flores serem usadas como metáfora para as pessoas?"

— Por que está fazendo isso comigo?!

Com seu último resquício de força, a Imperatriz afastou a mão de Xia Guo: "Não guardo rancor de você, por que você...?"

— Ora! — Xia Guo cobriu a boca, surpresa, com um ar falsamente arrependido. — Vossa Majestade não gosta? Que erro terrível... Sempre pensei que adorasse ver o *tianmaren* aplicado à própria pele.

"Você não disse todos os dias que olhar para o rosto da Consorte Li, queimado pelo fogo, era como contemplar uma bela pintura?"

"Sou leal a você e, naturalmente, quero que seu corpo seja tão belo quanto uma pintura, agradável aos seus olhos, não é?"

O corpo da Imperatriz estava coberto de feridas purulentas por onde quer que seu camisolão a tivesse tocado. Ela tremia de dor e gemia lamentavelmente de vez em quando. Ela não tinha mais forças para discutir com Xia Guo.

"Você... tire meu camisolão rapidinho e vá chamar o médico imperial! Quaisquer que sejam seus motivos para fazer isso, contanto que me salve agora, não vou te culpar..."

"Hehe~ Sua Majestade acha este servo muito tolo?"

Xia Guo riu e balançou a cabeça. Depois exibiu diante da imperatriz as duas mãos ensanguentadas e feridas:

— Quando o *tianmaren* toca a pele, ela logo ulcera, sangra, cria crostas, cicatriza e deixa marcas. Se Vossa Majestade foi capaz de usar esse método para ferir outras pessoas, deve saber que a crueldade dele está em não matar, mas deixar cicatrizes horríveis por todo o corpo.

"Então, qual a utilidade de convocar o médico imperial?"

Ela observou a testa franzida da imperatriz e seus lábios mordidos até sangrar, exibindo uma expressão de falsa compaixão.

— Tsc, tsc... Ver Vossa Majestade sofrendo tanto parte o coração desta serva. Mas não tema: preparei de manhã um remédio para aliviar sua dor. Vou trazê-lo agora.

Ela se levantou e voltou para a mesa, tirando uma tigela de sopa de ervas da caixa de comida.

A imperatriz ficou tão assustada que recuou rastejando. "Você... o que você vai fazer? Vai me matar?"

"Você tem sido tão bom para mim, como eu poderia te matar?"

Xia Guo sentou-se sobre ela e a acalmou com uma voz que parecia falar com uma criança: "Majestade, comporte-se, tome seu remédio e descanse um pouco. Não vai doer tanto quando a senhora acordar."

A Imperatriz não era tola, então, naturalmente, cerrou os dentes e se recusou a beber.

A paciência de Xia Guo estava se esgotando. Vendo que ela não beberia, ergueu a mão e lhe deu dois tapas fortes. Em seguida, beliscou suas bochechas com o polegar e o indicador, forçando-a a abrir a boca e despejando à força a tigela de remédio em sua garganta.

Assim que tomou o remédio, a Imperatriz lutou simbolicamente por alguns instantes antes de, fracamente, baixar as pálpebras.

Xia Guo ainda lhe deu dois tapinhas no rosto e, quando constatou que ela realmente adormecera, soltou um resmungo e jogou a tigela de lado.

Ao mesmo tempo, ouviram ruídos de farfalhar do lado de fora da porta.

Devem ser as criadas do palácio que foram enviadas para colher flores e que já retornaram.

Xia Guo espiou pela fresta da porta do quarto e viu vasos de forsítia sendo levados para o pátio do Palácio da Fênix. Ela abriu a porta, recolheu as mãos manchadas de sangue para dentro da manga e instruiu os servos do palácio:

"Sua Majestade a Imperatriz está cansada hoje, portanto não jantará esta noite. Por favor, façam silêncio e não perturbem o descanso de Sua Majestade."

Seu status atual é o de criada-chefe do Palácio Fengluan. Suas palavras representam as da Imperatriz, e quem ousaria desobedecê-las?

Então todos concordaram em uníssono, e ela então retornou ao quarto e trancou o portão do palácio.

O que Xia Guo dera à imperatriz não era veneno, apenas um sedativo comum em dose elevada o suficiente para fazê-la dormir até o meio-dia seguinte.

Se o sistema não proibisse antecipar a saída de personagens importantes da história original, Ning Xiaoxiao, que havia tomado o corpo de Xia Guo, teria eliminado aquela mulher perversa ali mesmo.

Ela sentia que simplesmente usar os próprios métodos deles contra eles não era suficiente.

Após organizar tudo, Ning Xiaoxiao bebeu outra tigela de pó calmante, planejando dormir com a Imperatriz até o meio-dia do dia seguinte e, em seguida, retornar à sua forma original para presenciar a agitação.

Ao abrir os olhos no dia seguinte, Ning Xiaoxiao percebeu que estava deitada em sua própria cama, no Palácio Fengyi.

Todos no palácio sabiam do seu hábito de dormir até tarde, então, mesmo quando o sol estava a pino, ninguém vinha acordá-la.

Ning Xiaoxiao se espreguiçou preguiçosamente e saiu da cama bocejando.

Ao ouvirem a comoção, Qiqi e as outras entraram para ajudá-la com a maquiagem e a se vestir.

Mais tarde, durante o almoço com Gu Sijin, Gu Sijin notou um leve sorriso no rosto dela e perguntou:

"Que boas notícias você recebeu? O sorriso no seu rosto não desapareceu nem um pouco hoje!"

Ning Xiaoxiao brincou: "Foi tão raro o Príncipe Jing e a Princesa Mais Velha virem ao palácio ontem. O Imperador conversou e bebeu com eles sem me incomodar. Claro que estou feliz por ter conseguido dormir bem à noite. Irmã não sabe, mas fazia muito tempo que eu não dormia tão bem."

Gu Sijin cobriu a boca com a mão e deu uma risadinha: "Você pode não estar dormindo o suficiente, mas isso não impede o Imperador de lhe alimentar bem, não é?"

Ela estendeu a mão e cutucou a pele lisa e delicada de Ning Xiaoxiao. "Veja como o Imperador a nutriu bem; você está ficando ainda mais radiante!"

Ning Xiaoxiao corou instantaneamente: "Oh, irmã! Por que você anda dizendo essas bobagens ultimamente?"

Enquanto as duas irmãs trocavam provocações, uma criada do palácio entrou cambaleando no Palácio da Fênix.

Ele ajoelhou-se apressadamente diante dos dois homens, gaguejando:

"Vossa Majestade, Nobre Consorte Imperial... a senhora deve ir depressa! Algo aconteceu no Palácio Fengyi..."

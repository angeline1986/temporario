# Capítulo 296 — Então que a imperatriz fique coberta de feridas

Sanfu e Ahuan pararam de se curvar e se encararam, momentaneamente atônitos.

Ah, isto...

A imperatriz está tentando prejudicar Vossa Alteza, ora!

Parece que a Consorte Nobre Imperial está preocupada com a coisa errada!

"Estou te fazendo uma pergunta! Aconteceu alguma coisa?"

Ning Xiaoxiao pegou um punhado de sementes de girassol e começou alegremente a quebrá-las.

Ahuan estava chorando agora há pouco, mas agora corou timidamente e não ousou levantar a cabeça.

Sanfu cerrou os dentes, segurou a mão de Ahuan e a ajudou a se erguer do chão frio. Em seguida, assentiu vigorosamente para Ning Xiaoxiao e reuniu coragem: — Sim! Ah... Vossa Alteza, isso...

Assim que ele reconheceu o gesto, Ning Xiaoxiao jogou casualmente as cascas de sementes de girassol da palma da mão para ele.

"Você é incrível! Uma garota tão bonita como ela está disposta a ficar com você. Eu nunca imaginei que você tivesse tanta sorte."

Sanfu coçou a nuca sem jeito e perguntou: "Vossa Alteza, Ahuan... ela realmente não quis dizer isso."

"Não é nada demais", disse Ning Xiaoxiao, com desdém.

— O fato de você tê-la trazido para me contar tudo não é uma falta, mas um mérito dos dois. Sempre retribuo a quem me faz o bem. Se vocês têm dificuldade para tratar de seu casamento com o imperador, eu mesma resolvo isso.

Os dois a olharam incrédulos, com espanto nos olhos. — Vossa Alteza...

Ning Xiaoxiao: "Por que você ainda está aí parado? Não precisa preparar um dote quando for se casar? Está pensando em deixar essa garota se casar com você sem pedir nada em troca?"

Radiante de alegria, Sanfu chorou, curvou-se três vezes diante de Ning Xiaoxiao e proferiu muitas palavras sentimentais sobre retribuir sua gentileza servindo-a como um escravo no futuro.

Ning Xiaoxiao não aguentava tanta declaração melosa. Fingiu impaciência e os mandou embora.

Quando Sanfu lhe disse essas coisas, Gu Sijin estava, na verdade, em seu palácio.

Ela estava podando o bonsai atrás do biombo e não saiu.

Ela só saiu de trás do biombo depois que Sanfu e os outros já tinham ido embora.

Ela viu Ning Xiaoxiao usando um grampo de cabelo de prata para pegar as sementes em pó de gastrodia elata e imediatamente deu um passo à frente para puxá-la para o lado:

"O que você está fazendo? Sanfu não te contou o quão poderoso isso é?"

Ning Xiaoxiao zombou: "A Imperatriz realmente nunca para de causar problemas."

— Era de esperar: depois que a mulher do clã Tong morreu, a imperatriz pensou que eu não tivesse família materna para me proteger e ficou ansiosa para me eliminar. Parece até que reduziram à força a inteligência dela; seus métodos estão cada vez mais rasteiros.

Gu Sijin perguntou: — Por que não manteve Sanfu e Ahuan aqui para levá-los diante do imperador e contar tudo? Ele a estima tanto, e a imperatriz tentou matá-la repetidas vezes. Acho que Sua Majestade já não a toleraria.

Uma luz sinistra brilhou nos olhos de Ning Xiaoxiao:

"De que adiantaria contar ao Imperador? No fim das contas, ela não me fez mal. Eu me atirei e acusei a Imperatriz, mas que provas eu tenho? Só este pacote de pó de tianmaren?"

— A imperatriz poderia simplesmente alegar que não teve nada a ver com isso, que Xia Guo jamais deu pó algum a Ahuan. Pior: poderia me acusar de ter armado tudo com Sanfu e Ahuan para incriminá-la e tomar seu lugar como imperatriz.

“Na dinastia anterior, tanto a família Zhu quanto a família Guo contribuíram para suprimir a rebelião do clã Tong. Agora, tomar medidas contra qualquer uma delas afetaria a reputação do Imperador. O Imperador me tem em alta estima, e eu não quero colocá-lo em uma posição difícil, então é melhor não deixar o Imperador saber disso.”

Gu Sijin perguntou: "Então, o que você pretende fazer? Vai deixá-la sair impune assim? Você já não se cansou de ser difamada sem motivo?"

Ning Xiaoxiao ficou genuinamente surpresa ao ouvir Gu Sijin dizer aquelas palavras.

Mas, na verdade, é bastante razoável.

Afinal, aquela irmãzinha de coração tão puro só mostrava os dentinhos de coelho, feroz de um jeito adorável, quando alguém maltratava Ning Xiaoxiao.

Se a própria Gu Sijin fosse a vítima, provavelmente ficaria tomada de compaixão pelo mundo e pediria até ao grande Buda de Leshan que cedesse o lugar para ela se sentar.

Ning Xiaoxiao não mencionou isso a Lu Linyuan porque não queria causar-lhe problemas desnecessários.

Embora Lu Linyuan provavelmente nem visse isso como problema, ele a protegeria sem hesitar.

Mas Ning Xiaoxiao não precisa pedir ajuda ao seu homem para coisas que ela mesma pode resolver.

Uma boa faca deve ser usada onde for mais necessária. Quanto a esses monstros e demônios, chegou a hora de ela mesma intervir e lhes dar uma lição de boas maneiras.

Ela abriu o documento em silêncio, e o "botão de posse", que estava inativo havia um mês, acendeu-se novamente...

Uma ideia divertida lhe ocorreu de repente; só de imaginá-la, ela começou a rir sozinha.

*

Naquele momento, a Imperatriz estava ouvindo Xia Guo lhe contar boas notícias no Palácio da Fênix.

— Vossa Majestade, Ahuan concordou em nos ajudar. No dia da cerimônia de elevação de Ning ao posto de Consorte Nobre Imperial, bastará que ela vista os trajes cerimoniais para que sua pele se abra em feridas e ela passe vergonha diante de todos!

— Além disso, as cicatrizes provocadas pelas sementes de *tianmaren* são ainda mais difíceis de eliminar que as de queimaduras. A Consorte Li finalmente terá alguém para lhe fazer companhia.

Seu sorriso era sinistro, e a Imperatriz, aliviada, soltou um breve suspiro e disse:

— Não deixem vestígios. No dia da elevação de Ning, mande alguém espancar até a morte aquela moça da oficina de bordados; depois invente uma desculpa, tire o corpo do palácio e enterre-o.

Xia Guo concordou. — Esta serva sabe como agir para proteger Vossa Majestade.

A imperatriz admirou muito sua competência e a recompensou com um punhado de sementes de melão douradas antes de se levantar e caminhar em direção à cama:

"Se você me seguir e fizer as coisas bem, com certeza colherá os frutos no futuro, entendeu?"

Xia Guo sorriu obsequiosamente e ajudou a Imperatriz a se sentar ao lado da cama. "Está ficando cada vez mais quente com a chegada da primavera. Vossa Majestade gostaria de vestir a camisola leve e fresca que o Departamento da Casa Imperial enviou recentemente para usar durante seu cochilo da tarde?"

A Imperatriz assentiu com a cabeça, e então Xia Guo encontrou a camisola e ajudou a Imperatriz a vesti-la.

A Imperatriz, depois de vestir sua camisola, estava prestes a se deitar quando vislumbrou duas tênues marcas de mãos vermelhas na manga da camisola amarela brilhante. Ela ficou imediatamente furiosa.

— Que espécie de serviço o Departamento da Casa Imperial está fazendo? Enviam uma peça dessas, coberta de sinais de mau agouro? Querem perder a cabeça?

Assim que terminou de falar, sentiu uma dor ardente na pele, como se estivesse sendo escaldada pelo fogo.

Num momento de choque, seu olhar recaiu sobre a mão de Xia Guo, apenas para descobrir que a palma dela estava pingando sangue.

"Você... você é... ah!"

Ela gritou de dor e tentou tirar a camisola. De repente, Xia Guo saltou sobre ela e agarrou sua mão, impedindo-a de tirar a roupa.

O sorriso dela era sinistro e aterrador:

"Será que Vossa Majestade não sabe por que minhas mãos estão assim?"

"Minhas mãos foram infectadas com sementes de gastrodia quando eu estava te ajudando a se trocar, por isso estão doloridas..."

"Hehe, Majestade, então adivinhe, o que vai infeccionar mais, seu corpo belo e delicado como jade, ou minhas mãos?"

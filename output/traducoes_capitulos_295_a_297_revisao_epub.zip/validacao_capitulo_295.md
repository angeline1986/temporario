# Validação — capítulo 295

- Fonte chinesa: `novel_capitulos_271_a_300(20261106-202952).docx`.
- Tradução-base portuguesa: `novel capitulos 271 a 300 - ch.epub`, arquivo `index_split_024.html`.
- Índices globais do DOCX: 1633 a 1696, com fim exclusivo em 1697.
- Unidades não vazias: **61**, sendo um título e 60 parágrafos de corpo.
- Correspondência de corpo EPUB–chinês: **60 para 60**.
- Unidades alteradas frente ao EPUB: **32** (inclui padronizações lexicais, não somente erros de sentido).
- Índices relativos das unidades alteradas: 2, 3, 5, 6, 9, 13, 15, 16, 18, 19, 21, 23, 24, 27, 28, 29, 30, 32, 38, 40, 42, 43, 44, 45, 46, 49, 50, 51, 54, 56, 58, 60.

## Correções editoriais

- Nomes de Sanfu e Ahuan e posto de Consorte Nobre Imperial padronizados.
- Corrigidos trechos de gênero ou referente mal atribuído e expressões culturalmente imprecisas onde detectados.
- Conservadas a progressão narrativa, as quebras e as unidades do documento chinês.
- *Tianmaren* mantém a referência à substância do romance, sem equipará-la sem ressalvas a uma espécie botânica cientificamente identificada.
- Sanfu é homem e Ahuan é mulher; corrigidos os pronomes, a referência ao casamento e o sentido de *duishi* (união de palácio).

## Escopo e limites

- Os CSVs mantêm o índice real base zero de cada parágrafo do DOCX, inclusive título e marcador.
- Confronto estrutural integral; revisão semântica **dirigida**, não uma auditoria frase a frase independente. Trechos da tradução-base podem ainda conter falhas não identificadas.
- A correspondência 1:1 de parágrafos não prova fidelidade semântica.

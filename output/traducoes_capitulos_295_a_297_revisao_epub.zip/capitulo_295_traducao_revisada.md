# Capítulo 295 — A imperatriz recorre a mais um golpe sujo

Após a morte de Xiangling, Xia Guo a sucedeu como chefe das criadas do Palácio Fengluan e agora é a pessoa de maior confiança da Imperatriz.

Os habitantes do Palácio Fengluan nunca tiveram muita interação com os funcionários da Oficina de Bordados de Seda. Eles apenas enviam pessoas ocasionalmente para supervisionar o trabalho quando a Imperatriz precisa confeccionar roupas novas com urgência para festivais.

Mas agora, quem em todo o palácio não sabe que Lu Linyuan emitiu um decreto imperial, ordenando ao Departamento da Casa Imperial, à Oficina Imperial e à Oficina de Bordados de Seda que interrompam todo o seu trabalho e concentrem todos os seus esforços na promoção de Ning Xiaoxiao a Consorte Nobre Imperial?

Tendo servido como eunuco-chefe perante o imperador por tantos anos, Sanfu possuía visão aguçada, raciocínio rápido e a capacidade de ler nas entrelinhas — essas eram suas habilidades mais básicas. Ele imediatamente ficou desconfiado.

Quando ele foi ao quarto procurar Ahuan, Ahuan estava se apressando para terminar os últimos detalhes bordados nas vestes da Consorte Nobre Imperial.

Ao vê-lo chegar, Ahuan sorriu e disse: "Você chegou cedo hoje. Não está ocupado diante do Imperador?"

Enquanto falava, ela não negligenciou a habilidade com que fazia trabalhos de costura.

Sanfu tirou a sopa tônica de ginseng e galinha preta da caixa de comida e disse, preocupado: "Ainda está quente, beba antes de começar a trabalhar."

Ahuan então parou o que estava fazendo, esfregou o pescoço dolorido e caminhou até a mesa para se sentar.

Ela saboreou com carinho a sopa que Sanfu havia preparado para ela, enquanto apreciava as massagens que Sanfu lhe fazia nos ombros e nas costas por trás, parecendo completamente satisfeita.

Sanfu hesitou por um instante, mas decidiu esclarecer suas dúvidas diretamente:

"Quando cheguei aqui agora há pouco, vi Xia Guo vindo te ver?"

Ahuan ficou claramente surpresa ao ouvir isso, mas depois riu e mudou de assunto: "Ah, é que ela me pediu para ajudar Sua Majestade a Imperatriz a consertar suas vestes auspiciosas. Eu disse a ela que estive ocupada com os assuntos da Consorte Nobre Imperial nos últimos dois dias e que não tenho tempo, então pedi que ela deixasse as vestes primeiro e eu as consertarei e as enviarei a Sua Majestade a Imperatriz assim que terminar com esses assuntos."

Ela era claramente culpada e, depois de falar, apontou deliberadamente para o manto de fênix na caixa de brocado ao lado dela: "Veja, o manto auspicioso ainda está lá."

A culpa dela era evidente. Depois de falar, apontou de propósito para o manto de fênix na caixa de brocado ao lado. — Está vendo? As vestes cerimoniais continuam ali.

Ahuan entrou em pânico, seus olhos se movendo rapidamente ao redor, e ela gaguejou: "Eu... eu não..."

“Diga-me a verdade”, interrompeu Sanfu com voz grave. “Xia Guo veio vê-la, mas Sua Majestade a Imperatriz tem algo a lhe pedir?”

— Diga-me a verdade — interrompeu Sanfu, em tom grave. — Xia Guo veio procurá-la porque a imperatriz mandou que você fizesse alguma coisa?

Ahuan conhecia Sanfu havia anos e nunca o tinha visto ser tão duro com ela.

Ela pegou um pacote de pó do fundo da caixa de brocado e entregou a Sanfu:

"Xia Guo quer que eu acrescente algo ao vestido da Consorte Nobre Imperial..."

Sanfu abriu o pacote de pó; era marrom escuro, com partículas finas e uniformes, e exalava um leve aroma frutado.

Este produto é feito a partir de sementes trituradas de tianmaren. Se entrar em contato com a pele, pode causar úlceras de difícil cicatrização e que levam muito tempo para cicatrizar.

Era um pó feito de sementes de *tianmaren* trituradas. Em contato com a pele, provocava ulcerações difíceis de cicatrizar.

Sanfu sabia o quão poderosa era aquela coisa e olhou para Ahuan com uma expressão confusa: "Você concordou com o pedido dela? Por que você concordou com o pedido dela?"

Na visão de Sanfu, essa questão era simplesmente incompreensível.

Ahuan era órfã e não tinha parentes. Ela estava apaixonada por ele há algum tempo e, embora já tivesse passado da idade de deixar o palácio, não queria partir e preferia ficar para lhe fazer companhia.

Como eunuco-chefe, ele entregava quase todo o seu salário mensal a Ahuan para que este o guardasse em segurança.

Como eunuco-chefe, ele entregava quase toda a remuneração mensal a Ahuan para que ela a guardasse.

Ao ouvir Sanfu questioná-la dessa forma, Ahuan ficou com os olhos cheios de lágrimas.

"Você me pergunta por quê? Então eu lhe direi por quê! Porque ela me disse que, depois que as coisas se resolverem, a Imperatriz intervirá e aprovará nosso relacionamento!"

— Quer saber por quê? Então eu digo! Xia Guo prometeu que, se eu cumprisse a tarefa, a imperatriz autorizaria oficialmente nosso *duishi*, nossa união!

"Não quero mais ficar me escondendo de você! Completei vinte e cinco anos no ano passado e não saí do palácio desde então, esperando por você."

"Você sabe que eu não quero nada de você, eu só gosto de você e quero estar com você!"

"Mas você sempre se recusou a mencionar esse assunto ao Imperador, e me fez sofrer com os olhares frios de tantas pessoas no palácio."

"Eles podem até me tratar com respeito quando me veem, porque você é o chefe dos eunucos, mas e pelas minhas costas? Você sabe como eles riem de mim pelas minhas costas?"

"Não fizemos nada de errado! Por que não podemos ficar juntos de forma aberta e honesta!?"

Diante das repetidas perguntas de Ahuan, Sanfu entrou em pânico instantaneamente.

Ele não suportava ver a mulher que amava chorar, então só lhe restava abraçá-la, enxugar suas lágrimas desajeitadamente e repetir mecanicamente as palavras "Me desculpe" várias vezes.

Ele hesitou em mencionar o assunto com Lu Linyuan porque temia não ser uma pessoa perfeita e acabar incriminando Ahuan para sempre.

No fundo, ele queria convencê-la a deixar o palácio e começar uma nova vida, mas depois do incidente de hoje, percebeu que era tão importante para ela quanto ela.

No íntimo, ele pretendia convencê-la a deixar o palácio e começar uma nova vida. Mas, depois do ocorrido, percebeu o quanto também era importante para ela.

Ela abraçou Ahuan com força, dizendo: "Menina tola, eu prometo que pedirei imediatamente ao Imperador por você. Se você estiver disposta a me seguir e não tiver medo de ser injustiçada, meu sonho sempre foi tê-la como minha esposa."

Ele abraçou firmemente Ahuan, que tremia em seus braços. — Sua bobinha. Eu prometo que pedirei imediatamente ao imperador permissão para me casar com você. Se estiver disposta a me acompanhar sem temer as dificuldades, saiba que meu maior sonho é recebê-la como esposa.

"A Consorte Nobre Imperial é a única mulher que o Imperador realmente ama e preza, e ela sempre foi muito gentil comigo. Ela é uma pessoa excelente. Não podemos agir contra a nossa consciência e prejudicar os outros para nosso próprio benefício egoísta."

Ahuan era uma mulher bondosa e, na verdade, arrependeu-se no momento em que concordou com o pedido de Xia Guo.

Mesmo que Sanfu não tivesse descoberto isso, ela não teria feito mal a Ning Xiaoxiao.

*

Mais tarde naquele dia, Sanfu levou Ahuan ao Palácio Fengyi.

Ele contou toda a história para Ning Xiaoxiao, incluindo o pacote de pó de sementes de tianmaren.

"Vossa Alteza, foi um erro de Ahuan que causou isso."

Ele não se inocentou de nenhuma culpa; em vez disso, ajoelhou-se repentinamente diante de Ning Xiaoxiao:

"Por favor, Alteza, tenha misericórdia. Se deseja me punir, que toda a culpa recaia sobre este servo. Este servo se curva perante Vossa Alteza."

— Peço a misericórdia de Vossa Alteza. Se quiser punir alguém, que toda a culpa recaia sobre mim. Este servo se prostra diante da Consorte Nobre Imperial.

Ela também se ajoelhou diante de Ning Xiaoxiao, implorando que ela se punisse e não descontasse sua raiva em Sanfu.

Ahuan também se ajoelhou diante de Ning Xiaoxiao, implorando que a punisse, sem envolver Sanfu.

Ning Xiaoxiao era a única que tinha acabado de acordar de seu cochilo da tarde e ainda estava um pouco atordoada. Ela estava comendo sementes de melão há um bom tempo, mas ainda não entendia o que estava acontecendo.

Ning Xiaoxiao, porém, acabara de acordar do cochilo da tarde e ainda estava meio zonza. Assistira àquela fofoca toda sem sequer entender direito o que estava acontecendo.

Ela inclinou-se para a frente novamente, com as sobrancelhas ligeiramente arqueadas, revelando um sorriso despreocupado:

Ela se inclinou para a frente, arqueou as sobrancelhas delicadas e abriu um sorriso de quem está adorando uma boa fofoca:

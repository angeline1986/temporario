# Capítulo 74 — Eu amo Lu Linyuan

O rosto de Lu Linyuan alternava entre o verde e o branco de tanta raiva.

Ele apertava o burro azarado com tanta força que as veias saltavam no dorso da mão, como se quisesse torcer o pescoço do boneco.

Na antiguidade, pessoas mal-intencionadas recorriam a feitiços e maldições: escreviam o nome e os dados de nascimento da vítima num boneco de pano e o usavam para amaldiçoá-la.

Lu Linyuan lançou a Ning Xiaoxiao um olhar assassino.

Então, nem para me amaldiçoar ela se deu ao trabalho de usar um boneco de gente? Tinha de ser um burro?

Ning Xiaoxiao se apressou a explicar: — Majestade, escute a história que esta serva vai inventar... quer dizer, a explicação desta serva!

— A expressão “yuan zhong” significa “ressentir-se da falta de sementes”. Ao escrevê-la antes do seu nome, esta serva quis dizer que Vossa Majestade ama seu país e seu povo. Afinal, recentemente houve fome no norte. Vossa Majestade certamente se ressente da falta de sementes para os agricultores plantarem, então...

Enquanto inventava aquela desculpa absurda, ela não parava de observar a expressão de Lu Linyuan.

Viu a sede de sangue dele saltar de 50% para 90%, e aqueles olhos tão bonitos quase pareceram sangrar.

Por fim, desistiu: — Ai, quer saber? Não consigo inventar mais nada! Melhor recomeçar!

Estalou os dedos e fez o tempo retroceder três minutos.

Lu Linyuan ainda não chegara ao quarto. Ela pensou em jogar o burro azarado pela janela, mas, quando abriu a vidraça, viu o tirano caminhando em direção à sua moradia.

Se ele a visse jogando o boneco fora agora, não seria ainda pior?

Ning Xiaoxiao fechou a janela depressa e olhou em volta, procurando outro lugar para esconder o burro.

De repente, teve uma ideia brilhante!

Ora, por que precisava escondê-lo? Não bastava apagar o que estava escrito?

Pegou o pincel embebido em tinta e cobriu os cinco caracteres 【冤種陸臨淵】 com cinco manchas pretas.

Acabara de terminar quando alguém bateu à porta.

— Já vai, já vai!

Ela enfiou o burro azarado novamente sob as cobertas e correu para abrir.

— Majestade? O que faz aqui a esta hora?

— Passei pelo Palácio Zhongcui e resolvi almoçar com sua senhora.

...

— Ontem... eu não deveria ter interpretado mal suas intenções.

Como era de esperar, depois de dizer isso, Lu Linyuan começou a olhar em volta do quarto e, por fim, fixou os olhos na cama.

Ele ergueu as cobertas, e o burro azarado apareceu.

Desta vez, porém, as letras tinham virado borrões de tinta, de modo que ele não conseguia ver o que estava escrito.

Antes que pudesse perguntar, Ning Xiaoxiao se adiantou: — Majestade, este é o brinquedo preferido desta serva. Durmo abraçada a ele todas as noites!

Lu Linyuan ergueu a sobrancelha e a olhou com diversão. — Você gosta de burros?

Com medo de despertar mais suspeitas, Ning Xiaoxiao improvisou imediatamente: — Ah... sim! Burros são ótimos! Comem pouco, trabalham muito, são diligentes e aguentam dificuldades. Uma criada deve ser como um burro diante de seu senhor! Essa é a consciência que uma boa serva precisa ter.

— Vejo que tem consciência de suas obrigações — disse Lu Linyuan, com um sorriso frio. — Os outros se contentam em trabalhar feito bois e cavalos; você já se promoveu a burra. O título de trabalhadora exemplar da Cidade Imperial, na próxima edição, certamente será seu.

Lu Linyuan ia devolver o boneco ao lugar quando percebeu que seus dedos ficaram manchados de tinta.

Sem demonstrar nada, refletiu:

Esses cinco borrões de tinta parecem recentes. Será que ela tentou esconder alguma coisa?

Então, antes, havia palavras escritas aí?

Esfregou a superfície com o polegar. Os dois últimos caracteres, que Ning Xiaoxiao cobrira às pressas, perderam parte da tinta, deixando entrever os contornos.

Pareciam os caracteres 【臨淵】, “Linyuan”.

Esse é... o meu nome?

E quais seriam os dois primeiros caracteres?

Como não conseguia enxergá-los, Lu Linyuan começou a inventar explicações em sua cabeça.

【Ela disse que dorme abraçada a este boneco todas as noites. E nele está escrito o meu nome. Então... isso não significa que, indiretamente, ela dorme abraçada a mim?】

【Será que os dois caracteres apagados eram “eu amo”? “Eu amo Lu Linyuan”?】

Só de imaginar, ele estremeceu e atirou o burro de volta sobre a cama.

【Não quero ter nada a ver com ela! Não me ame, porque esse romance não vai dar em nada!】

Com esse pensamento, voltou a olhar para Ning Xiaoxiao.

Sem fazer ideia do que ele pensava, Ning Xiaoxiao lhe ofereceu um sorriso profissional, exibindo os oito dentes.

Aquele sorriso falso de atendimento ao público, porém, pareceu aos olhos de Lu Linyuan transbordar de intenções indecentes.

É claro!

Agora tudo fazia sentido: ela não parava de se aproveitar de mim e de me tocar sem permissão!

Ela está é de olho no meu corpo!

Vendo que ele continuava parado feito uma estátua, Ning Xiaoxiao sorriu:

— Majestade, que tal a gente se sentar um pouquinho?

Lu Linyuan: “???”

Fazer um pouquinho?

Quem diabos iria “fazer” alguma coisa com você?!

Cada poro do corpo dele expressava rejeição. — Não vou fazer nada com você!

Dito isso, com o rosto vermelho, transformou-se numa rajada de vento e saiu correndo num zunido.

Ning Xiaoxiao ficou ali, sem graça, por dois segundos, antes de resmungar:

— Se não quer se sentar, fique em pé! Para que sair correndo? Está maluco?

*

O aniversário de Lu Linyuan seria dali a dois dias. A imperatriz já tinha organizado todos os preparativos do banquete.

Naquele dia, durante a saudação das concubinas à imperatriz, a imperatriz-viúva também mandou chamar Lu Linyuan.

Queria principalmente saber que apresentações ele gostaria de assistir durante o banquete familiar de aniversário.

Lu Linyuan não tinha o menor interesse nos números artísticos. À medida que as concubinas anunciavam o que haviam preparado, ele nem se dava ao trabalho de responder: apenas lia um tratado militar, de cabeça baixa.

Quando chegou a vez de Gu Sijin anunciar seu número, a Consorte Nobre a interrompeu antes mesmo que abrisse a boca, com evidente ironia:

— Ouvi dizer que, no dia da seleção, a Atendente Gu impressionou a todos com uma abertura de pernas e assim conquistou seu posto. Parece que sua habilidade nessa posição encantou Sua Majestade e a imperatriz-viúva. Que tal repetir a abertura de pernas no aniversário do imperador, daqui a dois dias, para alegrá-lo e nos permitir admirar seu talento?

A Consorte Yun concordou, sorrindo: — Exatamente! Também acho uma apresentação muito original. Bem mais interessante que cantar ou dançar!

A Consorte Li acrescentou: — Eu também gostaria de conhecer a especialidade da Atendente Gu. Quem sabe, quando houver tempo, não possa pedir umas aulas?

Era evidente que as três estavam caçoando de Gu Sijin. A imperatriz, incapaz de continuar assistindo àquilo, interveio:

— A Atendente Gu já preparou sua apresentação. Parem de criar confusão.

A Consorte Nobre sorriu. — Mas Sua Majestade ainda não disse que não gostou da ideia. Por que Vossa Majestade, imperatriz, já está com tanta pressa de arranjar uma desculpa para a Atendente Gu?

Aquelas mulheres grasnavam como patos e estavam deixando Lu Linyuan com dor de cabeça.

Ele pousou o livro militar e disse, em tom grave: — Acho excelente a sugestão da Consorte Nobre. Mas seria monótono deixar apenas a Atendente Gu fazer a abertura de pernas.

— Já que a Consorte Nobre, a Consorte Yun e a Consorte Li acham que a Atendente Gu faz isso tão bem e desejam aprender, não há por que adiar. Comecem a treinar com ela hoje mesmo. No meu aniversário, quero ver as quatro abrindo as pernas juntas.

A Consorte Nobre e suas aliadas se entreolharam, constrangidas. A armadilha que haviam preparado se voltara contra elas, e só lhes restou responder a contragosto: — Sim, obedeceremos à ordem de Vossa Majestade...

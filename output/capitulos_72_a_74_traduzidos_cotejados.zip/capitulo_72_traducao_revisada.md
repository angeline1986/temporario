# Capítulo 72 — O tirano ficou comovido?

O ferimento de Lu Linyuan não estava nada bem.

A pele estava bastante lesionada, o corte era profundo e, mesmo depois de tanto tempo enfaixado, ainda deixava escapar sangue fresco.

Ning Xiaoxiao espalhou cuidadosamente o remédio para feridas sobre a lesão. O tirano soltou um quase imperceptível “ss”, e ela parou imediatamente.

— Dói muito, Majestade? Aguente um pouquinho. Esse remédio arde quando toca na ferida, mas é ótimo para estancar o sangue e ajudar na cicatrização.

Enquanto falava, mostrou a marca do corte que fizera no dedo com a pulseira de jade. — Veja, Majestade. A ferida desta serva já cicatrizou tanto que mal dá para enxergá-la.

Lu Linyuan soltou um riso frio: — Você não disse que tinha usado todo o remédio no Cao Ni Ma?

Ning Xiaoxiao ficou assim: ￣□￣｜｜ — Ah... isso não vem ao caso!

Ela tentou continuar o curativo, mas ele recolheu a mão, aparentemente sem apreciar sua ajuda.

— Se acha que esta serva é desajeitada, Majestade, pode pedir a um médico imperial que aplique o remédio. Uma ferida tão funda vai deixar cicatriz se não for tratada a tempo.

— Não é necessário.

Lu Linyuan recusou friamente. Pousou a mão ferida sobre o colo, um tanto rígido, e ergueu a sobrancelha para ela: — Tem mais alguma coisa?

— Majestade, já que esta serva veio até aqui, talvez fosse melhor...

— Já disse que não precisa, então não precisa! — A impaciência era evidente em sua voz. Ele desviou os olhos de Ning Xiaoxiao e fingiu concentrar-se nos memoriais. — Pode se retirar.

Nos últimos tempos, Ning Xiaoxiao convivera com o tirano praticamente todos os dias. Apesar de sua língua afiada, ele não costumava ser alguém completamente insensível ou impossível de abordar.

Pensando melhor, porém, sempre que alguém demonstrava preocupação com ele, ficava estranhamente irritadiço.

Lembrando-se do que Sanfu lhe contara sobre a infância de Lu Linyuan, Ning Xiaoxiao percebeu que o problema não era apenas a relutância em aceitar tratamento: ele rejeitava qualquer demonstração de cuidado.

Após um breve silêncio, perguntou com cautela: — Majestade, posso lhe contar uma história?

Lu Linyuan não respondeu, e ela prosseguiu por conta própria: — Quando eu era pequena, conheci um garoto de nossa aldeia. Desde criança ele acompanhava os pais no trabalho no campo e quase não convivia conosco. Minha mãe dizia que seus pais eram muito rigorosos: bastava ele errar a menor coisa para apanharem dele. E, quando sorriam para o menino, ou era porque ele se saíra excepcionalmente bem, ou porque queriam obrigá-lo a fazer ainda mais tarefas.

— Anos depois, ele cresceu, deixou a aldeia e mudou-se para uma cidade. Era excelente em tudo, e todos à sua volta gostavam dele. Ainda assim, mantinha as pessoas afastadas. No auge do inverno, um vizinho lhe levou uma cesta de carvão por bondade, mas o rapaz preferiu passar frio a aceitar.

— Porque sempre acreditava que a gentileza e a preocupação dos outros escondiam algum interesse.

— Até que, certa vez, adoeceu sozinho em casa e só foi encontrado dois dias depois. Os vizinhos se reuniram: uns chamaram o médico, outros cozinharam, outros se ofereceram para cuidar dele. Com a ajuda de todos, logo se recuperou.

— Assim que sarou, foi procurá-los para lhes dar dinheiro. Mas nenhum deles aceitou uma única moeda. Foi então que ele compreendeu que, na verdade, a maioria das pessoas cuida dos outros sem esperar receber nada em troca.

Quanto mais ela falava, mais sombrio ficava o rosto de Lu Linyuan.

Quando Ning Xiaoxiao se preparava para concluir a moral da história, ele a interrompeu, severo: — Que bobagens Sanfu andou lhe contando?

Ela balançou a cabeça: — Ninguém me contou nada, Majestade. Esta serva só está narrando uma história.

Lu Linyuan sorriu com frieza: — O rapaz da sua história era um plebeu. Eu sou o imperador, o homem de mais alta posição sob os céus.

— Se ocupo este cume solitário e detenho o poder sobre tudo sob o céu, devo suportar também o frio que existe nas alturas.

— Na juventude vi incontáveis rostos ferozes, de pessoas que desejavam me devorar vivo. Quando me tornei imperador, aquelas mesmas caras contorcidas e ameaçadoras se transformaram, de uma noite para outra, em expressões amáveis.

— O que pensam aqueles que se aproximam de mim e tentam me agradar? Mesmo quando não consigo descobrir, não tenho interesse em adivinhar. Não preciso da preocupação de ninguém, pois quem sabe se por trás desse cuidado não existe uma lâmina envenenada?

O olhar cortante de Lu Linyuan atingiu Ning Xiaoxiao em cheio. Em seguida, ele baixou a cabeça e voltou a folhear os memoriais.

— Nesta vida, confio apenas em mim mesmo e só a mim permito proximidade. Não faço questão da bondade dos outros.

Ning Xiaoxiao perguntou: — Então acha que esta serva também tinha segundas intenções ao trazer o remédio?

A ponta do pincel de Lu Linyuan parou por um instante. Ele não lhe respondeu diretamente.

Ao terminar um memorial, lançou-o de lado. Sem querer, a borda do documento atingiu o frasco do remédio para feridas, derrubando-o no chão.

Ning Xiaoxiao contemplou o pó espalhado, com o coração apertado.

Afinal, comprara aquilo com todas as suas economias! Talvez não valesse nada aos olhos de Lu Linyuan, mas era tudo o que ela podia oferecer.

Nunca tinha visto alguém tão teimoso!

【Se é para ser tão cabeça-dura, melhor nem ser gente! Vire um boi! Não, melhor um burro! Um burro empacado combina perfeitamente com você!】

— Majestade, a forma como enxergamos o mundo depende do que trazemos no coração. O mundo pode ser terrível, mas não é tão terrível assim.

Ela lançou um olhar pesaroso ao frasco no chão. — Não faz mal se não quiser o remédio, Majestade. Mas a ferida na sua mão certamente deixará uma cicatriz.

— E essas cicatrizes e dores poderiam ter desaparecido. É Vossa Majestade quem insiste em guardá-las. Depois ainda terá de olhar para elas e lamentar a própria sorte. Agindo assim, Majestade...

— Chega! — Lu Linyuan a cortou em voz baixa, porém dura. — Não preciso que venha me dar lições.

Depois daquele grito, Ning Xiaoxiao achou que devia estar com algum parafuso solto.

【Por que estou falando tanto? O que me importa se ele é feliz ou não?】

【Não passo de uma criada! É só cumprir minhas obrigações, sobreviver até o fim da história e voltar para casa. Para que ficar procurando bronca?】

Ela fez uma reverência e se virou para sair.

Antes de atravessar a porta, porém, não resistiu a dar um último aviso, por pura boa vontade: — Se não quiser passar o remédio, tudo bem. Mas não molhe a ferida. Se infeccionar, quem vai sofrer é Vossa Majestade.

Pelo canto dos olhos, Lu Linyuan acompanhou sua saída.

Desde que subira ao trono, ninguém jamais ousara lhe dar sermões.

Somente ela podia dizer coisas tão atrevidas e ainda sair ilesa.

Se fosse outra pessoa, já teria morrido sabe-se lá quantas vezes.

Mal Ning Xiaoxiao saiu, Sanfu percebeu sua expressão estranha e entrou depressa para verificar o que acontecera.

Ao ver o remédio espalhado no chão, lamentou: — Ai, como é que foram derramar esse remédio?

Lu Linyuan desdenhou: — Foi algo que lhe dei de presente. Ela só tentou me impressionar oferecendo o que já era meu. Para que tanto lamento?

— Majestade, houve um engano... — Sanfu explicou. — Esta serva perguntou por aí. O remédio que Vossa Majestade lhe deu antes já havia sido todo usado no Cao Ni Ma. Este frasco... ela comprou especialmente para Vossa Majestade, usando todas as suas economias.

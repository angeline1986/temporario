# Relatório de validação — Capítulo 73

**Fonte:** DOCX chinês (capítulos 61–120).

**Cobertura estrutural:** 85 unidades originais (título incluído), 85 traduções correspondentes, 0 vazias.

**Conferência:** alinhamento individual por índice de parágrafo DOCX. A equivalência semântica foi revista durante a tradução, mas **não houve uma segunda auditoria linguística independente**; a correspondência 1:1 não comprova ausência de erros de sentido.

**Notas de tradução:** “冤種” (azarado, desgraçado) mantido em caracteres no boneco por ser fundamental à leitura parcial no capítulo seguinte; referência à LV preservada e adaptada, conservando o mal-entendido de Bengbeng.

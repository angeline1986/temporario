# Capítulo 73 — O azarado Lu Linyuan virou um burro

Todas as economias dela... usadas para comprar aquilo especialmente para mim?

Uma pessoa tão pão-dura quanto ela... Isso...

O olhar de Lu Linyuan se fixou no pequeno frasco de porcelana sobre o chão. A luz do sol atravessou as treliças esculpidas da janela e se refletiu na superfície, produzindo um brilho claro.

Aquele feixe discreto pareceu atravessar suas pupilas e chegar ao lugar mais sensível de seu coração.

Sem demonstrar nada, disse a Sanfu: — E daí que ela tenha comprado? Foi uma gentileza que ninguém lhe pediu. Retire-se.

Sanfu coçou a nuca, sem compreender.

Seu senhor tinha mesmo um humor impossível de prever.

Não fazia muito, parecia completamente apaixonado e até mandara Ning Xiaoxiao se despir em seu colo, em plena luz do dia. Agora dizia que ela estava se iludindo sozinha?

Ah, como era fascinante o mundo dos homens que não entendiam os próprios sentimentos!

Assim que Sanfu fechou a porta, Lu Linyuan, que dizia uma coisa e fazia outra, agachou-se e começou a reunir com cuidado o remédio derramado. Com as pontas dos dedos, recolheu a camada limpa do pó e a devolveu ao pequeno frasco.

Depois, recostou-se na cadeira imperial, brincando com o recipiente entre os dedos.

Após hesitar, destampou-o novamente e espalhou o remédio sobre a parte da ferida que Ning Xiaoxiao não chegara a tratar.

Ela dissera várias coisas atrevidas, mas cada uma fazia sentido.

Especialmente a última.

Muitas dores poderiam ser evitadas. Ele próprio insistia em conservá-las e depois se lamentava, olhando para a própria sombra: vejam, o imperador parece glorioso por fora, mas na verdade é o mais infeliz de todos os homens.

Ao longo daqueles anos, Lu Linyuan tecera, com frieza e violência, um casulo em torno de si.

Lá dentro, isolara-se de toda boa vontade vinda de fora e acreditava apenas naquilo em que queria acreditar.

As palavras de Ning Xiaoxiao haviam sido como uma pedra lançada do alto, acertando em cheio o teto daquele casulo e abrindo um buraco.

A luz do sol atravessou a fresta.

Lu Linyuan ainda não conseguia sair inteiramente dali, mas agora bastava erguer a cabeça para enxergar a claridade.

Como a luz radiante que entrava pela janela naquele instante.

Uma luz cálida e suave, nem sempre encoberta pela névoa.

*

Como diz o ditado:

Dar um passo atrás dá nódulo no peito; aguentar calada dá cisto no ovário; engolir a raiva acaba com o fígado.

De volta ao palácio, Ning Xiaoxiao continuava remoendo a própria irritação.

A Consorte Duan foi conversar com Gu Sijin. Depois de preparar frutas, chá e petiscos para as duas, Ning Xiaoxiao saiu para varrer o pátio.

Foi justamente quando Bengbeng apareceu correndo e esbarrou nela sem olhar por onde ia.

O ombro doeu bastante com a pancada. — Que é isso? Por que está correndo desse jeito?

— N-não é nada. Desculpe, Xiaoxiao, eu não estava olhando. Você se machucou?

Bengbeng desviava os olhos, falando com preocupação, mas insistia em esconder as mãos atrás das costas.

— O que está escondendo? Mostre.

De início, Ning Xiaoxiao pensou que ele tivesse roubado alguma coisa. Mas, quando mostrou o objeto, viu que segurava um burro de pano.

— Para que você quer um burro?

Bengbeng ficou envergonhado. — Eu... queria dar de presente para Qiqi.

Não era incomum que jovens eunucos e criadas do palácio formassem casais de companhia. Se os sentimentos fossem recíprocos, até um romance platônico podia ser duradouro.

Ning Xiaoxiao não achou estranho. O que não lhe agradou foi aquele presente horroroso.

— Vai dar um burro para uma garota? Está achando que isso é uma bolsa da Louis Vuitton?

— Hã? Quem você quer enforcar?

Ning Xiaoxiao: “...” — Arrume uma corda e se enforque você mesmo.

Ela tomou o burro das mãos de Bengbeng. — É melhor não dar isso para Qiqi. Ela vai ficar furiosa. Faça o seguinte: fico com este e depois faço um boneco bonito para você dar a ela. Que tal?

Bengbeng agradeceu imediatamente.

Ning Xiaoxiao voltou ao quarto com o burro de pano e o jogou sobre a cama. Por algum motivo, olhar para ele lhe lembrava Lu Linyuan e sua teimosia de burro.

Ainda estava irritada. Já que não podia insultá-lo na cara, podia descontar no burro, não podia?

Pegou um pincel e escreveu, com grandes traços, cinco caracteres no peito do boneco:

—【冤種陸臨淵】— “Lu Linyuan, o azarado.”

Ainda deu duas palmadas na cabeça do burro. — Se eu voltar a me preocupar com você, sou uma idiota!

*

No dia seguinte, depois da audiência matinal, Lu Linyuan já se livrara completamente do problema de não conseguir “se erguer”.

Sanfu perguntou o que ele desejava para o almoço. Lu Linyuan ia responder “qualquer coisa”, mas então se lembrou de que não tratara Ning Xiaoxiao muito bem no dia anterior.

Afinal, ela só tentara cuidar dele. E se aquela criatura ficasse tão brava que nunca mais o ajudasse a prever o futuro?

Chamou Sanfu de volta. — Faz alguns dias que não vejo a Atendente Gu. Prepare a comitiva para o Palácio Zhongcui.

Quando chegou ao Palácio Zhongcui, Gu Sijin conversava com a Consorte Duan. As duas ficaram desnorteadas ao vê-lo aparecer.

— Majestade? O que o traz aqui?

A Consorte Duan não via Lu Linyuan fazia algum tempo e ficou especialmente animada.

— Faz dias que não venho me sentar um pouco no Palácio Zhongcui — respondeu ele. — Hoje passei por aqui justamente na hora do almoço. Pensei em comer com vocês.

Encantada, a Consorte Duan se apressou a preparar alguns de seus pratos especiais.

Gu Sijin disse: — Então, Majestade, descanse um instante. Esta concubina irá ajudar a Consorte Duan.

Mal as duas saíram, Lu Linyuan ouviu o pensamento de Ning Xiaoxiao:

【Vou te encher de pancada!】

Hã?

Quem ela estava espancando no quarto, em plena luz do dia?

Naquele momento, Ning Xiaoxiao ainda ignorava a chegada de Lu Linyuan e se distraía espancando o burro azarado no quarto.

De repente, ouviu a voz do imperador do lado de fora. Quase morreu de susto.

Enfiou o burro azarado debaixo das cobertas e correu para abrir a porta.

— Majestade? O que faz aqui a esta hora?

— Passei pelo Palácio Zhongcui e resolvi almoçar com sua senhora.

Ning Xiaoxiao o convidou a entrar. Só então notou que a mão dele estava enfaixada novamente e apresentava sinais de tratamento. — Majestade, foi consultar o médico imperial?

Lu Linyuan guardou silêncio por um momento. — Usei o remédio que você me deu.

— Hã?

— Ontem... eu não deveria ter interpretado mal suas intenções.

【Que história é essa? Ele está se desculpando comigo?】

【Não estou enganada, estou? Desde quando a palavra “desculpa” existe no dicionário do tirano?】

Lu Linyuan realmente pretendia pedir desculpas. Mas, para um imperador, desculpar-se diante de uma simples criada era humilhante demais.

Por isso, interrompeu a frase e passou a examinar o quarto com os olhos.

Estranho. Quem ela dissera que ia espancar? Não havia mais ninguém ali...

Ao vê-lo procurar alguma coisa, Ning Xiaoxiao ficou apreensiva.

【O que ele está procurando? Tomara que não veja o que escondi debaixo das cobertas. Senão, estou ferrada de novo...】

Outra vez debaixo das cobertas...

Por que ela tinha mania de esconder tudo ali?

Num instante, Lu Linyuan avançou até a cama de Ning Xiaoxiao e, antes que ela pudesse reagir, ergueu as cobertas.

O burro azarado apareceu diante de seus olhos.

Lu Linyuan pegou o boneco e se deparou com os cinco caracteres escritos em seu peito:

“Azarado... Lu Linyuan?”

# Relatório de validação — Capítulo 74

**Fonte:** DOCX chinês (capítulos 61–120).

**Cobertura estrutural:** 76 unidades originais (título incluído), 76 traduções correspondentes, 0 vazias.

**Conferência:** alinhamento individual por índice de parágrafo DOCX. A equivalência semântica foi revista durante a tradução, mas **não houve uma segunda auditoria linguística independente**; a correspondência 1:1 não comprova ausência de erros de sentido.

**Notas de tradução:** O falso desdobramento de “冤種” em “ressentir-se/falta de sementes” foi mantido como desculpa inventada; o contraste entre 坐 (sentar) e 做 (fazer) foi adaptado para preservar o equívoco insinuante, com alguma perda fonética em português.

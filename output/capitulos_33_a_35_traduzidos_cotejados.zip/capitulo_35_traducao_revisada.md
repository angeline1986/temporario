# Capítulo 35 — Frente a frente com o tirano, sem nada para esconder

Mesmo depois de encontrar uma vaca de verdade, Ning Xiaoxiao teve um trabalhão para tirar leite.

Quando finalmente levou o leite ao Palácio Chaoyang, Lu Linyuan já a esperava havia quase uma hora.

Nem dava para contar quantas vezes tinham trocado a água da tina.

Ao vê-la chegar correndo, com suor na testa e ofegante, Lu Linyuan lançou-lhe um olhar de lado:

— Mandei que fosse tirar leite. Demorou tanto porque não encontrou a vaca?

Ning Xiaoxiao respondeu, constrangida: — Não foi a vaca que eu não encontrei... Foi o leite...

Lu Linyuan: — ...

Ning Xiaoxiao despejou o leite na tina. Os servos então abriram o biombo dourado de nove painéis, decorado com dragões entre nuvens, para ocultar a tina e garantir a privacidade de Lu Linyuan durante o banho.

Lu Linyuan passou para trás do biombo e começou a tirar as roupas, peça por peça.

A silhueta de seu corpo vigoroso projetava-se sobre o biombo: ombros largos, cintura estreita e pernas intermináveis. Bastava a sombra para pôr a imaginação de qualquer um para trabalhar.

Quando o tirano se preparou para começar o banho, os servos se retiraram, um após o outro.

Normalmente, só Sanfu tinha permissão para permanecer e servi-lo durante o banho. Por isso, Ning Xiaoxiao seguiu no fim da fila, também pretendendo sair.

Mas, antes de chegar à porta, ouviu o tirano ordenar: — Sanfu, um botão de fio de ouro na aba esquerda do meu manto imperial está frouxo. Leve-o ao Departamento das Vestimentas e mande consertá-lo e devolvê-lo o mais depressa possível.

— Este servo obedece. Mas... se eu sair, quem servirá Sua Majestade durante o banho?

— Deixe aquela que foi tirar o leite.

【Deixar eu aqui...? Para quê? Para esfregar suas costas?】

— Majestade, esta serva nunca ajudou ninguém a tomar banho. Eu...

Lu Linyuan a interrompeu sem cerimônia:

— Justamente por nunca ter feito isso é que precisa aprender. Senão, seria melhor usar toda a prata que o palácio lhe paga por mês para alimentar porcos!

Sanfu examinou Ning Xiaoxiao e soltou uma risadinha escondida, com a expressão de quem estava torcendo por um casal. — Certinho~ Já vou levar o manto imperial para o conserto. Tenha um ótimo banho, Majestade~

Ao sair, ainda fechou a porta.

Ning Xiaoxiao ficou imóvel perto da entrada, sem saber como agir.

*O romance original nunca explicou como os servos atendiam o imperador durante o banho...*

*E agora, o que faço?*

Lu Linyuan perguntou: — Por que está aí parada?

— Ah? — Ning Xiaoxiao se aproximou do biombo com passinhos miúdos e arriscou: — Então... Majestade quer que eu esfregue suas costas?

*Esfregar coisa nenhuma, sua idiota!*

Lu Linyuan respondeu impaciente: — Passe-me a toalha!

— Ah, tá...

Ning Xiaoxiao ergueu os olhos para a toalha pendurada no biombo. Estava um pouco alta.

Ela ficou na ponta dos pés e conseguiu alcançá-la. Mas então surgiu outro problema...

Como faria para entregar a toalha a Lu Linyuan?

Não podia simplesmente dar a volta no biombo, podia? Assim veria tudo!

Embora tivesse uma vontadezinha — só um tiquinho — de olhar umas coisas indecentes, não dava para fazer isso tão descaradamente.

Enquanto hesitava, Lu Linyuan soltou um grito irritado: — Estou falando com você! Ficou surda?!

— Ah? Sim, sim! Pegue, Majestade!

Ela lançou a toalha com força para cima, fazendo-a passar por cima do biombo num arco perfeito.

E então... a toalha acertou bem em cheio o rosto de Lu Linyuan.

O estalo foi mais alto que o de um tapa na cara.

Lu Linyuan ficou petrificado e levou alguns segundos até retirar lentamente a toalha do rosto.

Soltou um longo suspiro e lamentou em silêncio:

*Se os céus consideram que cometi algum pecado, podem muito bem me fulminar com um raio. Não havia necessidade de mandar uma imbecil dessas para me torturar!*

— BRUUUUM!

Mal terminou de pensar isso e um trovão ensurdecedor retumbou no céu.

Ele imediatamente mudou de ideia:

*Er... pensando bem, uma imbecil também não é tão ruim... Depois de algum tempo de convivência, chega até a ser um pouco adorável!*

O ar se encheu do cheiro fresco de terra molhada. Em pleno verão na capital, as tempestades surgiam de repente.

Mal o trovão cessou, uma chuva pesada começou a cair.

Ning Xiaoxiao adorava dias de chuva.

Antigamente, quando estava em casa, sempre que chovia ela se aninhava confortavelmente debaixo das cobertas, bebendo chá com leite e assistindo à televisão.

Estalou os lábios. *Droga, agora fiquei com vontade de tomar um chá com leite!*

Enquanto pensava nisso, começou a cantarolar mentalmente:

【Você me ama~ Eu te amo~ Mixue Bingcheng, docinho, docinho~】

Ao ouvir aquela “bela” canção, Lu Linyuan ficou sem reação:

*Que maluquice ela está cantando?*

*Eu a amo? Só nos sonhos dela!*

Ning Xiaoxiao, desejando ardentemente uma bebida com leite, começou a fazer planos:

【Isso mesmo! Se o imperador desgraçado lavar o cabelo, com certeza alguns fios vão cair! Então, se eu procurar os cabelos que caíram na água do banho dele, não vou poder trocá-los por chá com leite?】

Ela perguntou: — Majestade~ Vai lavar o cabelo?

Lu Linyuan começou a se arrepender de tê-la escolhido para ajudá-lo no banho.

Como já estava praticamente terminado, ordenou: — Pare de falar besteira e passe-me a roupa de dormir.

Ning Xiaoxiao olhou para cima. A roupa de dormir também estava pendurada no biombo.

Então retirou as peças, uma por uma, preparando-se para jogá-las na direção de Lu Linyuan.

Nesse instante, ele disse num tom carregado de ameaça: — Se ousar atirar mais alguma coisa aqui dentro, mando cortar suas mãos!

— Hã? Mas, se eu não jogar, como vou entregar a roupa a Sua Majestade...?

— Feche os olhos, entre aqui e me entregue.

— Ah... tá...

A última peça da roupa de dormir que Ning Xiaoxiao tirou do biombo era uma cueca amarelo-dourada, bordada com um dragãozinho dourado em miniatura, muito fofo.

Era a primeira vez que ela via com os próprios olhos a cueca de um imperador. E, bem... era até bonitinha, não?

Ela reprimiu uma risada, fechou os olhos e caminhou para dentro, segurando as roupas.

Lu Linyuan se ergueu de dentro da tina e estendeu a mão para pegá-las.

Foi exatamente então que uma costura da roupa de Ning Xiaoxiao, como se escolhesse o pior momento possível, se soltou e ficou presa no biombo.

Ela continuou avançando de olhos fechados. A força de seu movimento puxou o biombo, que tombou para a frente.

O estrondo a fez dar um pulo e abrir os olhos.

A primeira coisa que viu foi Lu Linyuan completamente nu, de pé dentro da água.

Uma névoa suave de vapor envolvia a cena, emprestando-lhe uma sensualidade ainda maior justamente pelo que tentava esconder.

A pele de Lu Linyuan era clara e delicada, e seu corpo, uma verdadeira obra-prima.

Clavículas bem desenhadas, peitorais perfeitos, abdômen marcado e linhas musculares que desciam até a virilha...

E também um pequeno “Lu Linyuan”.

Ning Xiaoxiao ficou hipnotizada e até engoliu saliva sem perceber!

Só voltou a si quando Lu Linyuan se sentou de novo, de uma vez, dentro da tina. Seu rosto estava vermelho, não dava para dizer se de raiva ou vergonha:

— NING XIAOXIAO!!!

Ning Xiaoxiao despertou do transe, virou depressa a cabeça e só então percebeu que ainda segurava a cueca de Lu Linyuan.

Estendeu a mão na direção dele e falou, morta de vergonha:

— Majestade...

— Sua cueca imperial de dragão...

...

---

## Notas editoriais

- 半個時辰 é meia hora dupla, equivalente a aproximadamente uma hora; o texto usa 'quase uma hora'.
- O refrão 你愛我~我愛你~蜜雪冰城甜蜜蜜 é associado à rede chinesa Mixue Bingcheng; sua presença moderna é intencional na narração.
- Ning Xiaoxiao menciona recolher cabelo do banho para trocar por chá com leite, em referência à lógica de missões já estabelecida.
- A última peça de roupa é uma cueca amarela bordada com um pequeno dragão; a revelação é acidental após a queda do biombo.

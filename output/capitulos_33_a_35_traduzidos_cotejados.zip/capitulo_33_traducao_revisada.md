# Capítulo 33 — O tirano vira pai de surpresa

Depois que o médico imperial partiu, a pulseira continuou caída no chão, imóvel.

Gu Sijin cobriu o nariz com a mão, os olhos se avermelhando sem que percebesse.

Cailian, de temperamento explosivo, apanhou a pulseira e disparou em direção à saída.

Ning Xiaoxiao a deteve. — Aonde você pensa que vai?

— Me solte! Vou tirar satisfações com a Consorte Duan! Quero saber que intenção ela tinha ao presentear nossa senhorita com uma coisa dessas!

Ning Xiaoxiao a repreendeu em voz baixa: — Você acha que ainda está na residência dos Gu? Quantas vidas tem para ir questionar a Consorte Duan? Nossa senhora agora ocupa apenas o modesto posto de Dama Gu (daying), enquanto a Consorte Duan é a primeira entre as quatro consortes, abaixo somente da imperatriz e da Consorte Nobre. Basta levantar um pouco a voz diante dela para que mande arrancar sua língua!

Quando recuperou a razão, Cailian ficou parada, sem saber o que fazer.

Ning Xiaoxiao ouviu vagamente os soluços de Gu Sijin. — Xiaoxiao, estou com tanto medo... Por que até a Consorte Duan é assim? Nunca ofendi ninguém. Por que todas elas, uma atrás da outra, querem me matar?

...

*Não tem jeito. Você é a protagonista.*

Conflitos intensos são o que mantém os leitores acompanhando uma história; por isso, é claro que vilãs de todos os tipos precisam aparecer para criar problemas para você.

Se tudo fosse paz e tranquilidade o tempo inteiro, os leitores achariam que a autora estava apenas enchendo linguiça. Quem continuaria lendo?

Ning Xiaoxiao consolou Gu Sijin com algumas frases protocolares que pouco ajudavam. Depois de um tempo, Gu Sijin respirou fundo, como se tivesse chegado a uma conclusão, enxugou as lágrimas e ordenou: — Cailian, traga a pulseira.

— Senhorita! Essa pulseira está cheia de coisa nociva por dentro! O melhor seria eu jogá-la bem longe...

— Eu mandei trazê-la!

Gu Sijin se irritou, e só então Cailian lhe devolveu a pulseira.

Gu Sijin a pegou e, pela fenda quase invisível a olho nu, despejou pouco a pouco todo o almíscar guardado em seu interior. Depois voltou a colocar a pulseira vazada no pulso.

— Senhorita! O que está fazendo? — perguntou Cailian.

O olhar de Gu Sijin se tornou sombrio. — Se eu não usar o presente que ela me deu, ninguém sabe que outros métodos inventará para me prejudicar. Só poderei me proteger se fingir que não sei de nada e representar bem meu papel diante dela.

Ela embrulhou o almíscar em papel e pediu a Ning Xiaoxiao que o enterrasse em algum lugar discreto perto do lago imperial.

Mal Ning Xiaoxiao saiu, Cailian disse a Gu Sijin: — Senhorita, seu pai tinha razão. Cada passo neste palácio é como atravessar montanhas de lâminas e mares de fogo. A única maneira de se proteger é conquistar o favor do imperador.

— Eu sei disso tão bem quanto você. Mas, se me entregar aos braços de outro homem, como poderei encarar Chu Xingran?

— Senhorita, acorde! Há dois anos não recebemos notícia alguma do jovem senhor Chu. Você sabe como são pequenas as chances de ele ainda estar vivo! E, mesmo que esteja, acha que sobreviverá a essas conspirações intermináveis das outras consortes até o dia em que puder reencontrá-lo?

As palavras de Cailian eram duras de ouvir, mas eram a mais pura verdade.

Gu Sijin já havia afundado no lamaçal do harém. O fato de não querer disputar nada não significava que aquelas mulheres a deixariam em paz.

Agora precisava primeiro aprender a se defender. Só continuando viva teria esperança de rever o homem que amava.

Após uma breve luta interior, Gu Sijin tomou uma decisão difícil:

Ela disputaria o favor imperial.

*

Depois de dar um destino ao almíscar, Ning Xiaoxiao voltava ao palácio quando passou pelo jardim imperial e viu Qiqi, Qiaqia, Bengbeng e Lala caçando borboletas com redes nas mãos.

Curiosa, perguntou: — Por que vocês saíram para pegar borboletas a esta hora?

— Nossa senhora disse que precisa delas. Mandou a gente capturar o máximo possível.

*Caçar borboletas... Gu Sijin precisa delas...*

Ning Xiaoxiao lembrou-se imediatamente de uma cena famosa do romance original.

Na primeira vez em que Gu Sijin decidia conquistar o favor do imperador, não era justamente quando ia servi-lo à noite usando uma capa enorme, cheia de borboletas escondidas por baixo?

Assim que Lu Linyuan se aproximava, ela abria a capa, e um enxame de borboletas saía voando graciosamente ao redor dela, deixando o tirano fascinado.

A autora original praticamente copiara essa cena célebre de *A Lenda de Zhen Huan*, provocando uma enxurrada de críticas.

E Ning Xiaoxiao ainda se lembrava perfeitamente de como o original descrevia o encontro íntimo daquela noite:

〈Naquela noite, Lu Linyuan foi especialmente impetuoso. Possuía Gu Sijin de maneira dominadora, como se quisesse penetrar por uma abertura, atravessar todos os seus órgãos internos e sair pela outra. Como se só assim pudesse possuir aquela mulher por completo. O amor do tirano era obsessivo e insano.〉

*Obsessivo uma ova...*

*A autora acha que o negócio dele é um foguete de festa? Vai explodir dentro do corpo da Gu Sijin, por acaso?*

Ning Xiaoxiao fechou os olhos e consultou os próximos acontecimentos da história. Era mesmo aquela cena absurda.

Mas, críticas à parte, ela estava um pouquinho empolgada.

Afinal, também queria espiar como o tirano faria seu “foguete” decolar em cima de Gu Sijin.

Enquanto comemorava silenciosamente a fofoca das boas que presenciaria naquela noite, a voz de Xiao Qi surgiu:

【Bip, bip, bip! Anfitriã, você tem uma nova missão~】

【Impedir Gu Sijin de conquistar o favor imperial e fazer sua tentativa de seduzir o tirano fracassar.】

【Missão cumprida: índice de desvio da trama +1%. Missão fracassada: pontos de vida da anfitriã −10%.】

*Pronto. Lá se foi a fofoca.*

Por um instante, ela até havia se esquecido de que precisava continuar desviando a trama.

Não tinha jeito: embora Gu Sijin finalmente tivesse tomado a iniciativa de perseguir seus objetivos, aquela empreitada estava destinada ao fracasso.

Porque, se ela fosse bem-sucedida, seria a vida de Ning Xiaoxiao que acabaria.

À noite, quando Gu Sijin foi ao Palácio Chaoyang servir o imperador, já estava com tudo preparado.

Vestia uma capa ampla e escondia debaixo dela incontáveis borboletas de todas as cores.

Ning Xiaoxiao espiava da entrada. Esperou até Lu Linyuan se aproximar de Gu Sijin e ela estar prestes a abrir a capa para libertar as borboletas. Só então apertou o botão Pausar.

Soltou um longo suspiro, balançou a cabeça e disse: — Foi mal~

O texto da cena seguinte dizia:

〈Gu Sijin abriu a capa, e as borboletas escondidas dentro dela saíram voando graciosamente...〉

*Hum. Se eu trocar apenas “borboletas” por “mariposas”, a cena vai ficar bem diferente.*

Se o tirano visse tantas mariposas saindo de cima de Gu Sijin, aquelas mariposas enormes, cinzentas e poeirentas seriam um pesadelo para alguém com sua obsessão por limpeza.

Depois de alterar a trama, Ning Xiaoxiao apertou Reproduzir.

Gu Sijin abriu a capa e, de repente, um menininho de sete ou oito anos saiu lá de dentro.

Ele estava praticamente nu, usando apenas uma fralda. Dançando, lançou-se em direção a Lu Linyuan.

Assustado com a cena, Lu Linyuan recuou e gritou, horrorizado: — Dama Gu! Que diabos está fazendo?! De onde saiu essa criança?!

Gu Sijin também ficou paralisada. Que droga, de onde tinha brotado aquele menino?

Ning Xiaoxiao ficou tão chocada que quase deixou o queixo cair. Correu para conferir o documento e então descobriu que havia feito uma besteira enorme!

Ao editar o documento, não tinha prestado atenção: usara o teclado com sugestões automáticas.

Pretendia digitar “mariposas”, mas, sem querer, a sugestão transformara a palavra em “filho”. Ela nem conferiu antes de apertar Reproduzir.

Depois de terminar a dancinha, o menino deslizou até Lu Linyuan, ajoelhou-se diante dele e bateu a testa no chão numa saudação solene:

— Este vosso filho saúda o Pai Imperador!

Lu Linyuan: ???

---

## Notas editoriais

- Gu Sijin decide disputar o favor imperial depois de remover o almíscar da pulseira; o conteúdo prejudicial e seu efeito são elementos da narrativa, não orientação médica.
- O trecho entre 〈 〉 é uma citação fictícia do romance dentro da história e foi mantido como tal.
- O erro de entrada do texto é o centro da piada: 蛾子 (ézi, mariposas) é convertido em 兒子 (érzi, filho) por sugestão do teclado. Como as palavras não se parecem em português, a relação sonora foi registrada nesta nota.
- O termo 答應 é uma posição baixa do harém imperial, não uma criada comum; adotado Dama Gu para a personagem.

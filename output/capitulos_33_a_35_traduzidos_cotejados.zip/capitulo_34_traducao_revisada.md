# Capítulo 34 — Tirando leite para o tirano

Dentro dos aposentos, um homem, uma mulher e uma criança formavam uma família “feliz e harmoniosa”.

O menino se levantou e deu uma voltinha diante de Lu Linyuan. — Pai Imperador, veja! Cresci mais um pouco!

Lu Linyuan não tinha tempo para lhe dar atenção. Perguntou à igualmente perplexa Gu Sijin: — Diga-me de onde veio esse menino.

Gu Sijin: — Bem...

O menino: — Pai Imperador, o que houve? Por que está fazendo uma pergunta dessas à minha mãe consorte?

Ele pegou as mãos de Lu Linyuan e Gu Sijin ao mesmo tempo, entrelaçou-lhes os dedos e riu: — Hehe! É claro que sou o filhão querido de vocês dois~

Lu Linyuan arrancou a mão dali e apontou para Gu Sijin, furioso: — Esse menino parece ter sete ou oito anos! Oito anos atrás, você tinha apenas dez! Gosta tanto assim de ser mãe?!

*Droga. A trama está começando a tomar um rumo esquisitíssimo.*

Embora a cara verde de ciúme do tirano fosse uma delícia de ver, se Ning Xiaoxiao não apertasse Retroceder naquele instante, Lu Linyuan provavelmente mandaria decapitar Gu Sijin por causa daquela criança surgida do nada.

E Ning Xiaoxiao não queria receber outra missão de salvar a protagonista.

Apertou imediatamente Retroceder. Três minutos antes, Gu Sijin estava justamente prestes a abrir a capa.

Para não correr o menor risco naquela alteração, Ning Xiaoxiao trocou “borboletas” por “mariposas grandes e desengonçadas” e conferiu o texto três vezes, com mais rigor do que quando revisava a prova do vestibular.

A história voltou a correr:

Gu Sijin abriu a capa e as mariposas enormes escondidas dentro dela bateram suas asas cinzentas e voaram na direção de Lu Linyuan.

Lu Linyuan tentava se proteger por todos os lados, mas as mariposas pareciam ter uma dívida de sangue com ele: não paravam de se jogar contra seu rosto.

O resultado foi exatamente o que Ning Xiaoxiao esperava. O plano de Gu Sijin de agradar Lu Linyuan fracassou completamente.

E não foi só isso: as mariposas que saíram da capa quase mataram Lu Linyuan de nojo.

Por isso, em sua imensa “benevolência”, ele recompensou Gu Sijin com mais uma noite inteira de exercícios físicos.

Em seguida, saiu furioso daqueles aposentos já conquistados pelas mariposas.

Ao ouvir seus passos se aproximarem, Ning Xiaoxiao se escondeu depressa atrás de uma coluna.

【Não posso deixar o tirano me ver! Senão ele vai me obrigar de novo a ler memoriais, jogar pedra-papel-tesoura, me enfiar debaixo da mesa...】

Lu Linyuan estava coberto pelo pó acinzentado das mariposas. Se não tivesse ouvido aquele pensamento, teria seguido direto para o aposento lateral e pedido que preparassem seu banho.

Mas agora, já que ela estava tentando se esconder de mim, faço questão de encontrá-la!

Seu olhar percorreu rapidamente as fileiras de colunas esculpidas com dragões e fênix ao longo do corredor.

Era preciso reconhecer: Ning Xiaoxiao escolhera um ótimo esconderijo.

O único problema é que seus seios tamanho D estavam naquele estado de “o primeiro brotinho de lótus desponta acima da água”: apareciam pela lateral da coluna.

Lu Linyuan aproximou-se na ponta dos pés e, num movimento brusco, agarrou Ning Xiaoxiao pela gola e a puxou para fora.

— Ah? M-Majestade?

— O que está fazendo escondida aqui?

— Não estou escondida! Eu... — Ning Xiaoxiao teve uma ideia e começou a esfregar a coluna com a manga. — Vi que esta coluna estava suja e vim limpá-la!

Lu Linyuan soltou uma risada fria. — Como você é trabalhadora.

— Sempre fui assim. Majestade me elogia demais.

— Já que gosta tanto de esfregar, limpe todas as cento e oito colunas de pedra do Palácio Chaoyang. Aproveite para capturar os mosquitos também.

Ning Xiaoxiao: ???

【Imperador desgraçado! Some, some, some daqui!】

Só que, na cabeça dela, o “some, some, some” saiu tão depressa que Lu Linyuan ouviu algo parecido com um “coá, coá, coá”.

*Eu apenas mandei que ela caçasse mosquitos. Por acaso vai se transformar num sapo?*

Com um sorriso no rosto, Ning Xiaoxiao respondeu: — Sim, esta serva obedece~

Ela fingiu estar se esforçando bastante enquanto esfregava cuidadosamente a coluna.

De repente, uma força irresistível puxou seu braço e a arrastou para perto.

— Majestade? Não mandou que eu limpasse as colunas?

— Isso você fará depois que eu adormecer. Agora tem uma tarefa mais importante.

— Qual?

— Vá preparar a água do meu banho!

— ...

*

Lu Linyuan tomava banho mergulhado numa tina no aposento lateral.

Era preciso acrescentar a água balde por balde, com muita rapidez, para que ela não esfriasse.

Depois de encher a tina, ainda era necessário acrescentar flores frescas de roseira, rosas, osmanto, jasmim, magnólias e outras flores perfumadas, além de leite recém-tirado das tetas de uma vaca.

Cada etapa tinha responsáveis próprios, e Lu Linyuan incumbiu Ning Xiaoxiao justamente de tirar o leite.

Era a primeira vez que ordenhava uma vaca. Sem experiência alguma, ela acariciou a cabeça do bovino que estava prestes a cair em suas “garras” e disse:

— Vaquinha corajosa não tem medo de dificuldades! Força!

Pôs uma bacia de madeira embaixo do animal e tateou até encontrar suas “tetinhas”.

Ao apalpá-las, percebeu que não pareciam muito cheias. — Pobrezinha! Aposto que aquele tirano mão de vaca nem lhe dá ração direito. Olhe como está magra! Ficou até sem peito.

Enquanto falava, ainda balançou orgulhosamente o próprio busto tamanho D na direção do animal.

Mesmo que aquelas “tetinhas” não fossem muito cheias, era preciso ordenhá-las.

Senão, com que leite o tirano tomaria banho? Ia usar o quê?

????

Ela reuniu coragem, pediu um “sorry” ao animal e apertou com força uma das “tetinhas”.

— Muuuu~~~

Ao sentir o aperto, o bovino começou a se debater. Deu um coice e quase despedaçou a bacia de leite.

Ning Xiaoxiao acariciou-lhe a cabeça para acalmá-lo. — Vaquinha, eu sei que você não gosta que apertem suas tetinhas, mas precisa aceitar seu destino. Fique boazinha, tá? Desta vez vou apertar mais forte; aguente só um pouquinho e a gente termina rapidinho!

Quando viu que o animal estava se acalmando, aproveitou a distração para dar outro aperto, com sua técnica de garra de dragão!

— Muuuuuu~~~

Dessa vez, o pobre bovino chegou a derramar lágrimas cristalinas.

E nem uma gota de leite saiu...

Ning Xiaoxiao estava prestes a investigar o motivo quando ouviu a voz de Sanfu atrás dela:

— Ning Xiaoxiao! Por que está demorando tanto para tirar leite? Sua Majestade já perdeu a paciência!

— Ei, ei, ei! Você! Em vez de ordenhar uma vaca, o que está fazendo no curral dos touros?!

Ning Xiaoxiao congelou. — O quê? Touros?

Não era de admirar que, por mais que apertasse, nada saísse...

Na vida moderna, só bebia leite de caixinha da marca Telunsu. Nunca precisara ordenhar animal nenhum!

E, no escuro daquele jeito, como ia distinguir um macho de uma fêmea?

Ela apanhou a bacia e lançou a Sanfu um sorriso constrangido, mas educado, antes de sair dali de fininho.

Depois que Ning Xiaoxiao partiu, Sanfu ouviu o touro continuar mugindo de maneira lastimável e aproximou-se para ver o que havia acontecido.

Meu Deus! Melhor teria sido nem olhar. O que viu foi de fazer perder a alma.

As partes íntimas do pobre touro tinham ficado inchadas de tanto que Ning Xiaoxiao as apertara.

Quem diria que ela tinha esse tipo de preferência?

Sanfu estremeceu. — I-isso... Será que Sua Majestade aguentaria uma técnica dessas...?

---

## Notas editoriais

- O menino surgido do erro no capítulo 33 deixa de existir nesta linha temporal após Retroceder; preservou-se o retrocesso de três minutos.
- A ordem de limpar exatamente cento e oito colunas foi mantida.
- O jogo sonoro original faz 滾啊 (gǔn a, suma daqui) parecer 呱呱 (guā guā, coaxar) quando a protagonista pensa rapidamente. A solução portuguesa aproxima 'some' e 'coá', e não reproduz literalmente a semelhança fonética chinesa.
- A revelação é que Ning Xiaoxiao tentava ordenhar um touro, não uma vaca. A cena contém humor corporal e alusões anatômicas grotescas.
- 特侖蘇 (Telunsu) é uma marca de leite citada no texto original.

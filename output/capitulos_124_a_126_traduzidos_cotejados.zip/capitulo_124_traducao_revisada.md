# Capítulo 124 — Um disparo acidental

Uma cantilena de xingamentos de nível avançado para alunos do primário, padronizada em todo o país.

Ao ouvi-la, as veias do pescoço do príncipe ocidental saltaram, suas têmporas latejaram e ele quase morreu de raiva ali mesmo.

Apertou tanto a taça de jade que teve vontade de esmagá-la.

Ning Xiaoxiao observava-o friamente. Ao perceber que ele estava prestes a perder o controle e arremessar a taça ao chão, apressou-se em dizer:

— Vossa Alteza acabou de dizer que o Ocidente tem seus próprios costumes. Pois a dinastia Qi também tem os seus.

— Aqui na dinastia Qi, cumprimentar a mãe de alguém é a maior demonstração de respeito possível. Se minhas palavras ou ações ofenderam Vossa Alteza, não foi de propósito.

— Agora há pouco, Vossa Alteza ofendeu Sua Majestade ao oferecer vinho ao Céu, e ele não reclamou, reclamou? Se agora for discutir com uma simples moça como eu, não estará demonstrando muita falta de elegância?

Com aquela língua afiada, Ning já deixara até Lu Linyuan, que se orgulhava da própria eloquência, sem resposta diversas vezes. Que chance teria um estrangeiro que mal conseguia se expressar em chinês?

O príncipe havia acabado de se comportar de maneira insolente. Agora que Ning usava contra ele exatamente a mesma desculpa, não lhe restou senão engolir a afronta calado e aceitar, com toda a “reverência”, o brinde que ela lhe oferecia.

De volta aos lugares, Lu Linyuan e Ning Xiaoxiao bateram discretamente as mãos debaixo da mesa. Trocaram sorrisos, e aquela sintonia de casal, unidos na mesma travessura, tinha algo inesperadamente doce.

A imperatriz viu tudo e sentiu uma amargura sem fim.

Em todos aqueles anos no palácio, nem sequer tocara na mão de Lu Linyuan. Seu título de imperatriz não passava de uma honraria vazia. Que ironia cruel.

Ela o amava de verdade. Quando ele ainda era príncipe, bastara vê-lo pela primeira vez para ficar completamente desnorteada por aquele rosto arrebatador.

Por causa daquela beleza, recorrera a toda sorte de intrigas e artimanhas. Chegara a permitir que sua família se aliasse à imperatriz-viúva, garantindo assim que ela a escolhesse e a elevasse ao posto de imperatriz.

Pensara que, mesmo sem amor no começo, a convivência diária acabaria por fazê-lo nascer.

Mas, depois da virada do ano, completaria quatro anos no palácio. E o homem que tanto desejava, embora tão perto, parecia viver além das nuvens, cada vez mais distante.

Primeiro Gu Sijin, depois Ning Xiaoxiao. Mulheres que chegaram depois dela haviam conquistado o homem que ela jamais conseguira alcançar.

Como não sentir raiva?

Desde o início do banquete, incontáveis iguarias cobriam as mesas e apresentações esplêndidas de música e dança animavam o salão. Nada disso, porém, atraía o olhar da imperatriz.

Ela não parava de espiar Ning Xiaoxiao pelo canto dos olhos.

Para manter a compostura em um banquete de Estado, as consortes quase não tocavam nos talheres. Quando comiam, levavam pequenas porções à boca e mastigavam devagar, cobrindo os lábios com a mão.

Já Ning Xiaoxiao devorava a comida com tanta vontade que parecia prestes a agarrá-la com as próprias mãos. A imperatriz, uma dama educada em família ilustre, não conseguia compreender tamanha falta de cerimônia.

Quanto a Ning Xiaoxiao, que se danassem as virtudes e a aparência femininas!

O importante era encher a barriga!

Se comesse como as consortes respeitáveis, a comida esfriaria antes que ela provasse dois bocados! Que desperdício imperdoável!

E a imperatriz não era a única a observá-la às escondidas. Lu Linyuan também.

Ao vê-la comer sem qualquer elegância, teve vontade de repreendê-la por suas maneiras, mas as palavras ficaram presas na garganta.

Falta de etiqueta era falta de etiqueta, sem dúvida. Só que aquela falta de etiqueta também tinha sua graça. Não fazia mal a ninguém.

Enquanto comia, Ning soltou um pequeno “ai” e fez uma expressão tão sofrida que começou a choramingar: — Buaaa...!

Assim que ouviu o choro, Lu Linyuan se alarmou. — O que foi?

— Buááá... A língúa... Mordi a língúa...!

Ela pôs metade da língua rosada para fora e ficou arfando como um cachorrinho.

Lu Linyuan balançou a cabeça, sem saber se ria. — Toda essa carne na mesa não basta? Precisava acrescentar um pedaço da sua? Foi grave? Quer que eu assopre?

Ning Xiaoxiao: — ???

Assoprar?

Como é que alguém assopra uma língua, seu maluco?!

Seu pervertido!

Ela recolheu a língua num instante e soltou um sorriso constrangido. — Não, não precisa... Acho que já nem dói tanto!

Lu Linyuan sorriu. — Coma mais devagar. Ninguém vai roubar sua comida.

A imperatriz assistiu à cena ao lado, azeda de ciúme.

Lançou os olhos para a sopa fumegante de galinha preta com cogumelos matsutake, recém-servida, e derramou de propósito um pouco do caldo quente sobre o dorso da própria mão.

— Aaaah...!

Seu gemido afetado atraiu não só a atenção de Lu Linyuan, mas também a dos ministros presentes.

O caldo escaldante deixou uma extensa área vermelha no dorso de sua mão.

Ela ia aproveitar para fazer manha quando ouviu a voz impaciente de Lu Linyuan:

— A imperatriz precisa mesmo soltar esse tipo de gemido indecoroso no meio de um banquete?

As palavras dele foram como um balde de água fria despejado sobre sua cabeça. A queimadura na mão só aumentou a sensação de injustiça que a consumia.

Com os olhos vermelhos, imitou o tom frágil de Ning Xiaoxiao: — Majestade, esta sua esposa se queimou sem querer com a sopa quente...

Ela fez questão de aproximar a mão queimada do imperador, mas ele nem se deu ao trabalho de olhar.

— A imperatriz consegue se queimar até tomando sopa? Onde foi parar sua compostura?

— Majestade...

— Se queimou a mão, vá procurar um médico imperial.

E ordenou friamente a Sanfu: — Leve a imperatriz de volta ao palácio e chame um médico para examiná-la.

— Às suas ordens.

Imperatriz: — ???

Antes mesmo de entender o que estava acontecendo, ela já havia sido conduzida para fora do Terraço Tonghua por Sanfu. Bem, de certa forma, conseguira exatamente o que pedira...

O pequeno escândalo não causou maiores perturbações. Todos continuaram comendo e bebendo, até que, perto do fim do banquete, o príncipe ocidental finalmente revelou o verdadeiro propósito da visita.

Ele fez um gesto ao velho de barba branca, que retirou da manga uma caixa preta de brocado.

Dentro dela havia uma arma de fogo pequena e delicada.

Era menos da metade do tamanho das armas que a dinastia Qi comprara anteriormente do Ocidente. Ao perceber os olhares curiosos dos ministros acompanhando a pistola, o príncipe ficou ainda mais arrogante:

— Esta é uma nova arma de fogo desenvolvida no Ocidente. É mais fácil de transportar que os antigos fuzis longos e ainda mais poderosa. O imperador gostaria de experimentá-la?

Com isso, pretendia demonstrar a Lu Linyuan que, mesmo que a dinastia Qi aprendesse a fabricar armas de fogo, o Ocidente continuaria na dianteira quanto aos equipamentos militares mais avançados.

Lu Linyuan reconheceu intimamente que os engenhos e técnicas ocidentais superavam em muito os de Qi. Mal sabia ele que, para Ning Xiaoxiao, aquele objeto era absolutamente comum.

【Não passa de uma pistola velha! Pra que tanta ostentação? No mundo moderno essa porcaria já seria peça de museu!】

Pensando nisso, Ning soltou um riso de desdém sem perceber.

O príncipe olhou-a de esguelha e apontou a arma em sua direção, embora mantivesse o dedo longe do gatilho. — Que esta consorte entregue a arma ao imperador para que ele a examine.

Lu Linyuan assentiu para Ning, que pousou os talheres e se levantou para receber a pistola.

Naquele instante, porém, por algum motivo a arma disparou sozinha. Ouviu-se um estrondo — BANG! — e a bala saiu do cano.

O cano estava apontado para Ning Xiaoxiao. Ela não teve sequer tempo de reagir.

Sentiu apenas uma força puxá-la de trás. Logo uma sombra se projetou sobre ela, interpondo-se diante de seu corpo.

Lu Linyuan se levantara quase por instinto e colocara Ning Xiaoxiao atrás de si para protegê-la.

A bala atravessou seu manto imperial e penetrou em suas costas...

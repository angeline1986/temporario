# Capítulo 126 — Preciso escolher um dia especial para bater em você?

A bofetada acertara o rosto de Ning Xiaoxiao, mas quem se deliciava era a imperatriz.

Assim que soubera do incidente no Terraço Tonghua, a primeira coisa que fizera fora procurar a imperatriz-viúva.

No caminho até ali, não poupara comentários sobre como Ning Xiaoxiao seduzira o soberano durante o banquete.

A imperatriz-viúva conhecia muito bem o Lu Linyuan de antigamente: um homem absolutamente egoísta.

Alguém com aquele temperamento jamais faria algo que colocasse a própria vida em risco.

Depois de ouvir as insinuações da imperatriz e presenciar os fatos, a imperatriz-viúva naturalmente chegou à conclusão de que, se Ning não tivesse enfeitiçado o filho, por que Lu Linyuan se atiraria diante de uma bala para protegê-la?

A bofetada fora desferida com toda a força. Ning ficou atordoada, parada no lugar, com a mão sobre a bochecha ardente e avermelhada.

Entre todas as consortes, só Gu Sijin ousou dar um passo à frente, colocar-se diante dela e dizer algumas palavras em sua defesa:

— Imperatriz-viúva, acalme-se. O mais importante agora é ver como está Sua Majestade.

A imperatriz-viúva lançou a Ning um último olhar atravessado e, sem dizer mais nada, correu para os aposentos internos.

Os médicos continuavam tentando salvar o imperador, mas ainda não havia notícia de seu estado.

Sentada no lugar de honra, a imperatriz-viúva juntou as mãos e girou as contas de seu rosário budista, recitando sutras e rezando para que Lu Linyuan superasse a crise sem sofrer danos.

A atmosfera no salão estava tão pesada que parecia ter endurecido. Todos tinham o coração na mão.

Foi então que um jovem eunuco desconhecido entrou às pressas e cochichou algumas palavras ao ouvido de Shuangruo, a servidora que atendia a imperatriz-viúva.

A expressão de Shuangruo se fechou. Ela se curvou e foi sussurrar algo à imperatriz-viúva.

Ninguém soube o que dissera, mas o rosto já sombrio da senhora se carregou ainda mais, como o céu antes de uma tempestade.

De sobrancelhas franzidas e olhos semicerrados, ela examinou Ning Xiaoxiao. — Foi você quem deu a ordem de prender o príncipe ocidental lá no Terraço Tonghua?

— Fui.

— E foi você quem disse que, por carregar um herdeiro imperial no ventre, sua palavra valia tanto quanto a do imperador?

— Fui.

— Ora, sua Ning Xiaoxiao! — A imperatriz-viúva bateu furiosamente na mesa, fazendo todas as consortes se ajoelharem. — Acalme sua ira, imperatriz-viúva!

A fúria da senhora não diminuiu. Ela apontou a bengala com cabeça de fênix para Ning e a insultou: — Você não passa de uma criada desprezível, vinda das servas do palácio! Bastou conquistar o favor imperial e receber um título para esquecer quem é?

A Consorte Yun acrescentou friamente: — Imperatriz-viúva, é verdade que ela é bonita, mas não é nenhuma fada incomparável. O harém está cheio de mulheres belas. Mesmo assim, Sua Majestade favorece essa criada vulgar e de origem tão baixa! Deve haver alguma coisa suspeita nisso.

A Consorte Li falou: — Ouvi dizer que o reino de Zhuyin possui uma técnica secreta semelhante à feitiçaria, só que ainda mais poderosa. Ela pode capturar a mente das pessoas e fazê-las perder a razão. Na minha opinião, essa Dama Ning é estranhíssima.

A Concubina Shen também se manifestou: — Num banquete de Estado, uma simples Dama jamais deveria ocupar um lugar entre os convidados. E os criados comentavam agora há pouco que ela discutiu abertamente com o príncipe ocidental, e Sua Majestade ainda a deixou fazer isso! As consortes representam a dignidade do país. Ela se comportou de maneira grosseira e envergonhou a corte, mas o imperador não se irritou; pelo contrário, tentou protegê-la! Como explicar algo tão esquisito?

As mulheres falavam todas ao mesmo tempo e não paravam. Só se calaram quando a imperatriz interveio:

— Basta. Parem de falar. Afinal, a Dama Ning está grávida; é natural que o imperador a trate com certa predileção.

Parecia estar defendendo Ning, mas, na verdade, deslocava o conflito para a suposta gravidez dela.

E a imperatriz-viúva caiu na armadilha, como era de esperar.

— Agora entendo por que o imperador se atirou diante daquela bala para protegê-la! Aposto que você usou alguma feitiçaria sedutora para enfeitiçá-lo e perturbar seu juízo! Só porque está grávida, acha que pode fazer o que quiser? Hoje não posso deixá-la sem castigo!

Ela chamou Shuangruo e ordenou: — Vá. Arrebente a boca dela para mim!

Ning Xiaoxiao já previra desde o início que acabaria numa situação em que todos a condenariam.

Shuangruo se aproximou, preparando as mãos para bater. Como sempre, Gu Sijin tentou proteger Ning. — Imperatriz-viúva! Xiaoxiao está grávida! Não pode apanhar!

A Consorte Yun soltou um riso frio: — É a barriga dela que está grávida, não a boca. O quê? Nem mesmo por ordem da imperatriz-viúva ela pode receber uns tapas? E mais: ela era sua criada. Se você não soube discipliná-la, quem garante que não foi você que planejou sua ascensão? Também tem sua parcela de culpa!

Shuangruo agia por ordem da imperatriz-viúva. Nem mesmo Gu Sijin, postada diante de Ning, conseguiu impedi-la.

A servidora golpeou com as duas mãos e, aproveitando-se de um momento de distração, deu uma bofetada em cada uma.

Aquele tapa fez Ning Xiaoxiao despertar de vez.

O filho da imperatriz-viúva estava lá dentro, entre a vida e a morte, e aquela mãe ainda tinha tempo para procurar culpados ao acaso e ostentar sua autoridade?

Era absurdo pra cacete...

Quando Shuangruo ergueu novamente a mão, Ning perdeu de vez a paciência. Agarrou-lhe o pulso, deu-lhe uma bofetada violentíssima no rosto envelhecido e, em seguida, um chute forte na barriga. Shuangruo caiu no chão, rolando de dor.

O salão inteiro ficou em choque.

Shuangruo fora encarregada de esbofeteá-las por ordem da imperatriz-viúva. Ao bater nela, Ning era como se tivesse esbofeteado a própria imperatriz-viúva.

Tomada pela fúria e pela humilhação, a senhora gritou: — Que insolência! Shuangruo age por ordem minha, e você ousa reagir?

Ning não tinha mais seu recurso extraordinário, mas ainda possuía o próprio cérebro.

Enquanto todos continuassem acreditando que ela carregava um “herdeiro imperial”, teria meios de enfrentar a imperatriz-viúva.

— Por que não ousaria? Se eu quiser bater nela, bato! Preciso escolher uma data especial? — Ning acariciou suavemente a própria barriga, assumindo a expressão desafiante de quem não teme nada, e devolveu a pergunta à senhora:

— Quem atirou e feriu Sua Majestade foi o príncipe ocidental. O que há de errado em ordenar sua prisão? Se a imperatriz-viúva tem tanta coragem, vá bater nele. Por que descontar sua raiva em mim?

— Ah, muito bem! Você ficou atrevida, não é? Agora ousa até me dar lições de moral?!

A imperatriz-viúva estava vermelha de tanta raiva quando o diretor-adjunto Song, do Instituto Médico Imperial, saiu dos aposentos internos em desespero e praticamente deslizou de joelhos até diante dela.

Seu rosto estava lívido, e sua voz tremia:

— I-imperatriz-viúva... A bala está alojada profundamente no corpo de Sua Majestade. Este humilde médico... não tenho capacidade de retirá-la. Felizmente, ela não atingiu nenhum órgão vital. Com todos os recursos de uma vida inteira de estudos, consigo garantir que Sua Majestade sobreviva pelos próximos três dias. Mas, se não encontrarmos uma forma de tratá-lo nesse prazo, temo que... que o pior aconteça...

Ao ouvir aquilo, a imperatriz-viúva sentiu a vista escurecer. Desabou na cadeira e quase desmaiou.

As consortes correram para cercá-la e demonstrar preocupação. Todos entraram em pânico, sem ninguém que lhes desse uma direção.

Ning Xiaoxiao, que ainda estava envolvida no confronto com Shuangruo, agarrou subitamente o pulso dela e a empurrou ao chão.

Ela e Gu Sijin ajudaram uma à outra a se levantar e caminharam, trêmulas, até a imperatriz-viúva. Ning falou com toda a seriedade:

— Sei que a imperatriz-viúva me odeia neste momento. Se quiser me punir, haverá tempo para isso depois. Mas agora o mais importante é tirar Sua Majestade do perigo.

Ainda sufocada de raiva, a imperatriz-viúva resmungou entre arfadas: — Cale a boca, sua...!

Ning Xiaoxiao respondeu: — A imperatriz-viúva esqueceu quem curou Sua Majestade da epidemia da última vez? Naquela ocasião, consegui tratar uma doença que nem os médicos imperiais sabiam curar. Desta vez também confio que posso trazer Sua Majestade de volta das portas da morte!

Ela apontou de repente para a porta fechada dos aposentos de repouso. Cada palavra soou firme e incontestável:

— Sua Majestade está deitado ali dentro! A imperatriz-viúva quer continuar mandando as pessoas trocarem tapas comigo ou prefere salvar a vida do imperador? A escolha é sua!

(*Nota da autora: Hoje tive alguns assuntos pessoais e não consegui chegar em casa a tempo de atualizar pelo computador. Só tenho um capítulo pronto no celular, então peço licença para publicar apenas uma atualização hoje. Um adiantamento: amanhã, o pai biológico de Xiaoxiao vai conhecer o genro!*)

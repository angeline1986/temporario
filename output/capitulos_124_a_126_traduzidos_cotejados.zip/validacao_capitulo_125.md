# Validação — capítulo 125

- **Fonte:** `novel_capitulos_121_a_180(20261103-233558).docx` (chinês tradicional, original DOCX).
- **Limites:** índices de parágrafo do DOCX de 285 a 358, zero-based; capítulo seguinte excluído.
- **Unidades de texto não vazias:** 71, incluindo título.
- **Unidades no CSV:** 71; **índices ausentes:** 0; **índices duplicados:** 0; **campos vazios:** 0.
- **Critério de cotejo:** uma linha para cada parágrafo não vazio e tradução correspondente, inclusive título.
- **Revisão:** tradução integral acompanhada de leitura do original e checagem estrutural programática. **Não equivale a uma auditoria linguística independente completa**.

## Notas editoriais e cuidados

- A gravidez é apenas aparente, conforme informação anterior de Xiao Qi; os ministros acreditam na gravidez, e Ning usa essa crença para legitimar a ordem.
- No original, a referência a “他懷中” no parágrafo 314 parece troca pronominal; o contexto indica que Lu Linyuan está nos braços de Ning.
- O pai mencionado no parágrafo 304 pertence ao passado de Ning; não confundí-lo automaticamente com o suposto pai entre os enviados ocidentais.
- Shut up bitch é mantido em inglês, acompanhado de sentido aproximado em português.

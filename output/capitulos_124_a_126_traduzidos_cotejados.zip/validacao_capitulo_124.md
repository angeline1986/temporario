# Validação — capítulo 124

- **Fonte:** `novel_capitulos_121_a_180(20261103-233558).docx` (chinês tradicional, original DOCX).
- **Limites:** índices de parágrafo do DOCX de 209 a 284, zero-based; capítulo seguinte excluído.
- **Unidades de texto não vazias:** 73, incluindo título.
- **Unidades no CSV:** 73; **índices ausentes:** 0; **índices duplicados:** 0; **campos vazios:** 0.
- **Critério de cotejo:** uma linha para cada parágrafo não vazio e tradução correspondente, inclusive título.
- **Revisão:** tradução integral acompanhada de leitura do original e checagem estrutural programática. **Não equivale a uma auditoria linguística independente completa**.

## Notas editoriais e cuidados

- Título 擦槍走火 alude a disparo acidental e pode carregar duplo sentido idiomático; optou-se por “Um disparo acidental”.
- Na cena final, o disparo é descrito como de causa não esclarecida. Não pressupor intencionalidade do príncipe.
- Os parágrafos 242 e 244 apresentam fala infantilizada e humor da língua mordida; adaptação preserva função cômica.
- A fala e o pensamento interior são mantidos separados; o pensamento está entre 【 】.

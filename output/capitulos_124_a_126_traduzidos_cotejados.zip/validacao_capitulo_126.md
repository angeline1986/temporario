# Validação — capítulo 126

- **Fonte:** `novel_capitulos_121_a_180(20261103-233558).docx` (chinês tradicional, original DOCX).
- **Limites:** índices de parágrafo do DOCX de 359 a 423, zero-based; capítulo seguinte excluído.
- **Unidades de texto não vazias:** 62, incluindo título.
- **Unidades no CSV:** 62; **índices ausentes:** 0; **índices duplicados:** 0; **campos vazios:** 0.
- **Critério de cotejo:** uma linha para cada parágrafo não vazio e tradução correspondente, inclusive título.
- **Revisão:** tradução integral acompanhada de leitura do original e checagem estrutural programática. **Não equivale a uma auditoria linguística independente completa**.

## Notas editoriais e cuidados

- No original, o parágrafo 415 volta a descrever Ning reagindo à agressão de Shuangruo, após a reação já descrita nos parágrafos 401–407. A repetição foi preservada, não corrigida silenciosamente.
- O parágrafo 422 contém nota da autora e foi traduzido integralmente, sem tratar a antecipação como fato já ocorrido no capítulo.
- As acusações de feitiçaria são especulações das consortes e da imperatriz-viúva, não fatos confirmados.
- O original usa “宮女所的賤婢”, redação possivelmente irregular; o trecho foi vertido pelo sentido contextual de criada de origem inferior.

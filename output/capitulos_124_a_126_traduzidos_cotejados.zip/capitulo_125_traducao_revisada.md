# Capítulo 125 — Lu Linyuan é baleado e perde a consciência

O salão mergulhou imediatamente no caos.

A bala penetrara no corpo de Lu Linyuan pela região da escápula direita, e o sangue jorrava sem parar.

Ele estava de frente para Ning Xiaoxiao. Ignorando os gritos e a confusão ao redor, fitou-a sem desviar os olhos e perguntou, numa voz muito fraca:

— Você está bem?

Ning estava paralisada de pavor. Sacudia a cabeça como um chocalho, os olhos brilhantes tremendo sob uma película de lágrimas.

Até aquele momento, nem percebera que Lu Linyuan havia sido atingido. Só quando recuperou um pouco a lucidez e ouviu alguém gritar entre a multidão — Depressa! Chamem os médicos imperiais! — foi que entendeu.

Finalmente compreendeu.

Uma bala segue em linha reta. Não desaparece no ar por encanto.

Se ela saíra ilesa, era porque alguém recebera o ferimento em seu lugar.

O rosto de Lu Linyuan empalideceu visivelmente. Antes que Ning conseguisse lhe fazer qualquer pergunta, ele cambaleou e tombou em sua direção.

O queixo dele pousou no ombro delicado da jovem e, como um balão que perdia o ar, seu corpo foi cedendo aos poucos até cair de joelhos no chão.

— Majestade? Majestade!

Ela passou os braços por baixo das axilas dele e o abraçou com força, tentando erguê-lo do piso gelado.

Mas, quando trouxe a mão de volta, encontrou um líquido morno e pegajoso.

Sangue.

Sangue demais.

O pai de Ning Xiaoxiao era diretor de cirurgia de um hospital de nível terciário classe A. Quando criança, ele costumava buscá-la na escola e levá-la ao hospital para fazer as tarefas. Ela vira muitas vítimas de emergências chegarem cobertas de sangue.

Desde pequena presenciara cenas sangrentas como aquela tantas vezes que já se acostumara.

Mas agora era Lu Linyuan quem estava ferido, e ela sentia um medo terrível.

Segurou o rosto dele entre as mãos e, com a voz rouca, chamou-o diretamente pelo nome: — Lu Linyuan! Olhe para mim! Não durma!

Com as mãos pequenas, bateu várias vezes nas bochechas dele, que já começavam a esfriar. E não foram tapinhas leves.

Depois de vários golpes, Lu Linyuan mal moveu os lábios para reclamar, numa voz quase inaudível:

— Estou nesse estado... e você ainda aproveita para me maltratar...

Assim que terminou, perdeu completamente a consciência.

— Você não pode morrer... Não pode morrer...

Os ministros se aproximaram para examinar o ferimento. Alguns que conheciam primeiros socorros começaram a pressioná-lo com peças de roupa, tentando conter a hemorragia.

Ning permanecia meio ajoelhada, com Lu Linyuan nos braços. Todos corriam ao redor dos dois, falavam ao mesmo tempo, aflitos e desesperados.

Mas, naquele instante, era como se Ning tivesse ficado surda. Até o mundo à sua volta parecia se mover devagar, em quadros isolados de uma apresentação de slides.

Mordeu o próprio lábio com tanta força que o sangue brotou e tingiu seus dentes brancos.

Fechou os olhos com força e continuou tentando tocar naquele documento cinzento dentro de sua mente:

【Por favor, eu quero voltar! Me deixe voltar! Preciso salvá-lo!】

Só que Xiao Qi estava de licença. Por mais que ela se desesperasse ou o chamasse mentalmente, ele não a ouviria. E o documento não se abriria naquele momento.

As lágrimas transbordaram e escorreram por seu queixo delicado, caindo em gotas grossas sobre os cabelos negros de Lu Linyuan.

A culpa, o desamparo e o pânico se abateram sobre ela de três direções, esmagando cada parte de seu corpo como forças insuportáveis, prestes a despedaçá-la.

Era a primeira vez, desde que entrara naquele livro, que Ning se sentia tão perdida.

Quando viu a gravidade da situação, o príncipe ocidental passou a repetir que a arma disparara acidentalmente e que ele não tinha culpa alguma, tentando se desvincular de tudo.

Chegou até a tentar sair dali como se nada tivesse acontecido.

Afinal, era um convidado de honra da dinastia Qi; o tratamento que Lu Linyuan lhe dispensasse representava a atitude da própria dinastia.

Os ministros também hesitavam: o príncipe era o único filho da família real ocidental. Sem uma ordem de alguém em posição de autoridade, ninguém ousava agir por conta própria.

Quando o grupo estava quase deixando o Terraço Tonghua, Ning Xiaoxiao despertou de seu torpor.

Enxugou as lágrimas com o dorso da mão, ainda manchado pelo sangue de Lu Linyuan. Seu olhar tornou-se feroz, carregado de uma sede sombria de sangue. A coelhinha dócil e delicada transformara-se numa figura aterradora que lembrava, em parte, o próprio Lu Linyuan.

Com os olhos injetados de sangue, encarou as costas do príncipe, que fugia às pressas, e bradou:

— Prendam os criminosos! Levem-nos à prisão imperial!

Ao ouvir a ordem, o príncipe parou e se virou, indignado: — Absurdo! Você não passa de uma consorte do grau mais baixo! Como ousa mandar nos prender?

— Shut up, bitch! [Cale a boca, seu desgraçado!]

Ning o interrompeu com um palavrão, agitou bruscamente a manga comprida e assumiu uma imponência digna de quem governava o mundo. Sua voz se elevou ainda mais:

— Carrego um herdeiro imperial em meu ventre! Minha palavra é a palavra do imperador! Escute bem: se alguma coisa acontecer a Sua Majestade, farei vocês serem cortados em mil pedaços!

— Guardas imperiais! Do que estão esperando? Ajam!

Embora fosse apenas uma Dama, Ning agia com mais autoridade que a própria imperatriz. Não só o príncipe ficou intimidado como os ministros presentes também se espantaram.

Mas o que ela dizia fazia sentido.

Apesar de seu posto baixo, todos acreditavam que ela carregava um herdeiro do dragão.

As armas ocidentais eram extremamente poderosas e o ferimento de Lu Linyuan parecia grave. Se ele não sobrevivesse e Ning viesse a dar à luz um príncipe, esse menino poderia tornar-se o próximo soberano de Qi.

Além disso, a imperatriz já havia se retirado. Naquele momento, a única integrante da família imperial presente no Terraço Tonghua era Ning Xiaoxiao.

Portanto, sua palavra tinha peso.

Depois de hesitar brevemente, os guardas imperiais desembainharam as espadas e detiveram o príncipe e seus enviados.

Nesse mesmo instante, o diretor-adjunto do Instituto Médico Imperial chegou apressado ao Terraço Tonghua, acompanhado por mais de dez médicos.

Ao verem a gravidade do ferimento, não ousaram mover Lu Linyuan de qualquer maneira. O médico ordenou: — Levem Sua Majestade numa maca até os aposentos de repouso do Terraço Tonghua. Com cuidado! Não encostem no ferimento!

Enquanto os médicos o atendiam lá dentro, Ning permaneceu o tempo todo do lado de fora da porta.

Seu coração não parava de disparar. Não conseguia ter um instante de paz.

Nesse intervalo, tentou de todas as formas chamar Xiao Qi de volta da licença.

Só então descobriu que, se Xiao Qi deixasse seu mundo, ela simplesmente não tinha como despertá-lo.

Quando entrara no livro, não tivera a menor sensação de perigo. Achava que, com uma vantagem tão poderosa a seu lado, não haveria obstáculo que não conseguisse superar.

Agora, diante de uma tragédia, percebeu que, por melhor que fosse aquela vantagem extraordinária, se dependesse dela o tempo todo e deixasse de pensar por si mesma, os desastres ainda aconteceriam, um após o outro.

Naquele mesmo dia, por exemplo, já sabia que o enredo seguinte estava todo coberto por mosaicos e que aquilo tinha relação com ela. Mesmo assim, não se mantivera alerta.

Quando o príncipe apontara a arma em sua direção, o simples fato de o dedo dele não estar no gatilho bastara para que ela não enxergasse o perigo.

Se a transmigração dela não tivesse alterado a linha narrativa, Lu Linyuan não teria sofrido aquela desgraça.

Acontecesse o que acontecesse, ela precisava salvá-lo!

Enquanto procurava uma saída, a imperatriz-viúva finalmente chegou, acompanhada da imperatriz e de várias consortes.

Ning foi ao encontro dela para tentar consolá-la, mas recebeu em resposta uma bofetada sonora:

— Sua sedutora maldita! Se acontecer alguma coisa com o imperador, vou arrancar sua pele!

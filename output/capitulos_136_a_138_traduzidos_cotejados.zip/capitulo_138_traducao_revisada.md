# Capítulo 138 — Xiao Qi volta com uma nova missão

Gu Sijin era mesmo bondosa.

Embora a imperatriz-viúva nunca tivesse gostado muito dela, ao vê-la desmaiar, Gu Sijin foi a primeira a se aproximar e ajudá-la. Acompanhou-a até seus aposentos e providenciou um médico imperial.

Quando todos se dispersaram, Ning Xiaoxiao também pediu licença a Lu Linyuan para se retirar.

Como era de esperar, ele a deteve: — Os outros se retiraram para cuidar da imperatriz-viúva. E você? Vai fazer o quê? Está com tanta pressa assim de voltar para o palácio e dormir?

Ning Xiaoxiao respondeu: — É que Sua Majestade acabou de se recuperar de uma doença grave e certamente tem muitos assuntos de Estado para resolver. Não queria atrapalhar...

— Assuntos importantes? — Lu Linyuan sorriu com uma malícia nada inocente e deixou o olhar pousar demoradamente no busto dela. — Se não tivesse mencionado, eu teria esquecido. De fato, tenho alguns assuntos muito importantes que preciso resolver com você.

Aquele olhar insinuante assustou Ning Xiaoxiao, que imediatamente cobriu os seios com as duas mãos. — Majestade... O que está fazendo...?

Lu Linyuan levantou-se e caminhou até ela. Afastou-lhe as mãos com firmeza e disse, autoritário: — O quê? Acabei de promovê-la a Nobre Dama. Não acha que deveria me recompensar devidamente?

Não pode ser! Não pode ser!

Eu sou uma “grávida”, pelo amor de Deus! Em plena luz do dia, você não tem um pingo de vergonha na cara?!

Lu Linyuan segurou-a pelo pulso com tanta força que a levou em direção aos aposentos internos sem que pudesse resistir. Enquanto tentava se desvencilhar, Ning Xiaoxiao suplicou:

— Majestade, não! Eu... estou grávida. Tenho medo de não poder fazer esse tipo de coisa...

— E por que não poderia? Se eu digo que pode, então pode!

Ele a levou para dentro e a atirou sobre um assento acolchoado e aquecido.

As descrições do “21” de Lu Linyuan no romance original ainda estavam vivas na memória de Ning Xiaoxiao. O medo quase a matou antes mesmo de qualquer coisa começar.

【Não, não, não! Eu não quero que você solte um foguete dentro de mim! Socorro!!】

Mas, embora pensasse assim, seu corpo parecia... contradizer um pouco o que dizia sua boca.

Ela franziu o rosto, fechou os olhos e repetiu que não queria, sem, no entanto, fazer qualquer movimento para se defender.

— Abra os olhos. Quero que veja com seus próprios olhos.

Com as bochechas coradas e os dentes prendendo o lábio, Ning Xiaoxiao murmurou: — Majestade... Talvez seja melhor eu ficar de olhos fechados. Eu... estou com medo...

Lu Linyuan inclinou-se, aproximou os lábios de sua orelha e sussurrou num tom provocador: — Não precisa ter medo. Vai demorar um pouco, mas ficarei com você o tempo todo.

Com as pontas quentes dos dedos, ergueu delicadamente as pálpebras dela. Ning Xiaoxiao imaginava que veria algo escandaloso. Mas o que surgiu diante de seus olhos foi uma montanha de memoriais oficiais, empilhados atrás do biombo...

【Eu já estava até tirando a calcinha e você me mostra ISSO, desgraçado?!】

Lu Linyuan percebeu os pensamentos indecentes dela e lhe deu um leve toque no nariz com o dedo curvado. — Vá fazer o que precisa fazer. Leia-os para mim!

Ning Xiaoxiao ficou muda por um instante. — Majestade, é melhor o senhor mesmo ler. Antes eu era uma criada, agora sou uma consorte. Se começar a examinar os memoriais, isso será uma verdadeira interferência do harém nos assuntos de Estado. Além disso... Hein?!

Ela não terminou de falar. De repente, sentiu um peso sobre o ombro, seguido de um sopro morno na pele delicada.

Virando um pouco a cabeça, incrédula, viu que o tirano apoiara o queixo em seu ombro. A barba recém-nascida roçou sua pele, e ele falou num tom quase manhoso:

— Ծ‸Ծ Mas eu levei um tiro por você e acabei de me recuperar de uma doença grave. Tem coragem de me fazer trabalhar tanto agora? Ler memoriais demais me dá dor de cabeça, e minhas costas ainda doem um pouco. Se... se você não quiser, eu mesmo leio, então.

Ele abaixou deliberadamente a voz, deixando a fala soprosa e sedutora, até quase roubar a alma de Ning Xiaoxiao.

Ela tremeu enquanto encarava aquele rosto bonito.

Droga, quem consegue resistir a isso?!

Sou uma tarada mesmo!

— Eu leio, eu leio, eu leio! — Agora era ela quem o mimava com uma autoridade carinhosa. Pegou um memorial ao acaso e começou a ler:

— Este é do ministro da Guerra. Ele diz que os ocidentais estão se movimentando e que, em apenas três dias, enviaram emissários duas vezes exigindo a libertação do príncipe ocidental. Caso contrário, vão entrar em guerra conosco.

【Minha nossa! Não havia essa parte sobre o Ocidente no romance original... As tropas de Qi são bem treinadas, mas usam espadas, lanças e outras armas tradicionais. As armas de fogo ocidentais podem atingir inimigos à distância e são menores e mais leves que as flechas incendiárias. Se a guerra realmente começar, não é nada garantido que Qi consiga derrotá-los.】

Ah, é?

Então havia coisas que nem ela sabia?

Lu Linyuan continuava com a cabeça apoiada no ombro dela, mas seu tom ficou um pouco mais sério:

— Já importamos muitas armas de fogo do Ocidente, mas os projetos de fabricação sempre foram mantidos em segredo. O pessoal do Departamento de Engenhos tentou desmontá-las para descobrir como são feitas. Contudo, as armas produzidas por eles ou falham ao disparar ou não alcançam uma distância suficiente. Ainda estão muito aquém do necessário.

Projetos de armas de fogo?

Para uma cientista renomada como a mãe dela, aquilo não seria resolvido num piscar de olhos?

Xiao Qi já lhe explicara que cada decisão que Ning Xiaoxiao tomasse dentro do mundo do livro provocaria uma reação em cadeia. Se Lu Linyuan não a tivesse flagrado comendo KFC e espalhado por toda parte o retrato do velhinho do KFC, aquele país ocidental não teria surgido do nada no mundo da história.

Ela mesma criara aquela confusão. Agora precisava resolvê-la. Já que o país aparecera, era só acabar com a ameaça que representava.

Então disse com toda a convicção: — Majestade, poderia me dar uma arma de fogo?

Lu Linyuan perguntou: — Para quê? Pretende atirar em mim?

Ning Xiaoxiao: 【Que conversa indecente é essa, seu sem-vergonha?! Até que eu gostaria! Pena que não tenho o equipamento necessário!】

— ...Quero examiná-la e ver se consigo desmontá-la e recriar os desenhos técnicos. Já que o pessoal do Departamento de Engenhos não encontrou uma solução, por que não me deixa tentar?

Lu Linyuan sabia que Ning Xiaoxiao não se ofereceria para fazer algo se não tivesse alguma confiança no resultado.

Se ela abrira a boca, certamente já tinha uma ideia de como resolver o problema.

Os céus lhe tinham enviado aquela pequena carpa da sorte. Seria desperdício não aproveitá-la.

Por isso, respondeu casualmente: — Está bem. Se quer tentar, leve uma. Não temos nada a perder. Pode ser nossa última esperança.

Na verdade, Ning Xiaoxiao só leu dez memoriais naquele dia. Depois, Lu Linyuan disse que estava cansado e a dispensou.

Ele não estava com sono. Apenas a ouvira tossir duas vezes e temia que ela passasse mal se continuasse lendo. Inventou uma desculpa para deixá-la ir.

No caminho de volta ao palácio, uma voz familiar e debochada surgiu de repente em sua mente:

【Anfitriã, anfitriã! Voltei! Sentiu saudade de mim?】

Depois de tantos dias sem ouvir a voz daquele pestinha, Ning Xiaoxiao precisava admitir que sentira um pouco de falta dele.

【Você já melhorou?】

Xiao Qi: 【Estou novinho em folha! Obrigado por me dar umas férias tão longas! Sei de tudo o que aconteceu enquanto estive fora. Você sofreu tanto! Vem cá, um abraço~~】

【Para agradecer, preparei especialmente para você uma missão de alto valor para o índice de desvio da trama. Quando concluí-la, a recompensa será contabilizada em dobro!】

Ning Xiaoxiao: 【Que missão?】

Xiao Qi: 【Bip, bip, bip! Anfitriã, você recebeu uma nova missão!】

【“Fazer o tirano cantar ‘Conquista’ enquanto abre um espacate.”】

【Conclusão: aumento de 3 pontos percentuais no índice de desvio da trama, contabilizados em dobro, totalizando 6 pontos. Fracasso: redução de 20% da vitalidade da anfitriã!】

Ning Xiaoxiao: 【??? Você chama isso de agradecimento? Está tentando me matar!】

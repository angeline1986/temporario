# Validação — capítulo 137

- **Fonte:** `novel_capitulos_121_a_180(20261103-233558).docx` — chinês tradicional, DOCX.
- **Limites:** parágrafos 1082 a 1140 do DOCX (índices reais, base zero); capítulo seguinte excluído.
- **Parágrafos não vazios:** 56, incluindo título e, quando presente, nota autoral.
- **Linhas de dados do CSV:** 56.
- **Índices ausentes:** 0; **duplicados:** 0; **campos vazios:** 0.
- **Método:** tradução integral e cotejo parágrafo a parágrafo com checagem automática dos índices, dos campos e da integridade dos arquivos.
- **Limitação:** o pareamento 1:1 e a revisão durante a tradução não constituem auditoria semântica independente integral; não se pode garantir inexistência de desvios internos apenas pela contagem de linhas.

## Notas editoriais

- 華貴人 é tratado como Nobre Dama Hua: Hua constitui título honorífico, não mudança adicional de grau.
- A promoção de Gu Sijin decorre de decisão expressa de Lu Linyuan e não de ação espontânea dela.
- 常在 equivale a Atendente, 貴人 a Nobre Dama; 官女子 foi apresentado como Serva Imperial, grau inferior à Dama.
- O original compara exemplos históricos ficcionais de consortes com o título Hua; a tradução não os apresenta como história real.
- A disputa sobre regras ancestrais e a mudança da imperatriz-viúva ao Palácio Shoukang mantêm a ordem causal da fonte.

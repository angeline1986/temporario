# Capítulo 136 — Xiaoxiao sobe de posição!

Mal essas palavras foram ditas, o salão inteiro entrou em alvoroço.

Lu Linyuan era um tirano, disso ninguém duvidava. Mas Shuangruo servia à imperatriz-viúva. Mandar cortar suas mãos sem mais nem menos não era o mesmo que dar uma bofetada na própria mãe?

Shuangruo empalideceu de terror, caiu de joelhos e começou a bater a testa no chão, implorando clemência.

A imperatriz-viúva gritou com os guardas que haviam entrado para cumprir a ordem: — Quero ver quem ousa tocar nela enquanto eu estiver aqui!

Ela se pôs diante de Shuangruo, lançando um olhar feroz e cortante. Os guardas ficaram paralisados, sem saber o que fazer.

Mãe e filho se encararam. Faíscas pareciam saltar de seus olhos, e o confronto estava prestes a explodir.

— Imperador! Exijo uma explicação razoável. O que Shuangruo fez para merecer uma punição tão brutal?

O que ela fez?

Por acaso você não sabe muito bem a merda que ela fez?

Lu Linyuan mandara Sanfu esperar mais um dia antes de anunciar aos seis palácios que havia despertado justamente para descobrir, com antecedência, tudo o que acontecera durante seu estado de inconsciência.

Os eunucos ocupavam uma posição muito baixa no palácio. Até Sanfu, chefe entre eles, era alvo das zombarias das consortes, que o ridicularizavam por ter sido castrado, não poder ter filhos e ser, segundo elas, uma aberração sem sexo.

De todas as mulheres do harém, só Ning Xiaoxiao tratava os criados com verdadeira bondade.

Aos olhos dela, não existiam pessoas superiores ou inferiores; dava-se bem com qualquer um. Por isso, Sanfu também estava do lado dela.

Além do mais, agora ela era a favorita do imperador. Quem a acompanhasse acabaria, mais cedo ou mais tarde, tendo sua parte nas coisas boas.

Assim, Sanfu contou a Lu Linyuan absolutamente tudo o que ocorrera durante sua inconsciência:

como a imperatriz-viúva atormentara Ning Xiaoxiao; como a Consorte Yun, a Consorte Li e a Concubina Shen se revezaram para atacá-la; como a imperatriz-viúva mandara Shuangruo esbofeteá-la; e como, quando Xiaoxiao foi humilhada, todos ficaram assistindo, exceto Gu Sijin, que a defendeu.

Em resumo, não escondeu nada — e, quando se empolgava, ainda carregava um pouquinho nas tintas.

Era por isso que Lu Linyuan estava vingando Ning Xiaoxiao publicamente naquele dia.

Ele sabia muito bem que ela já fora arrastada para o lamaçal do harém. Mesmo que demonstrasse menos interesse por ela, as outras mulheres não a deixariam em paz.

Sendo assim, melhor declarar abertamente sua preferência por ela.

Que qualquer um com más intenções até pudesse alimentar a vontade de prejudicá-la, mas não tivesse coragem de agir.

Ning Xiaoxiao ainda lhe seria muito útil. Precisava proteger aquele tesouro para poder continuar levando uma vida agradável.

(Nota da autora: Desculpem, até eu já cansei de usar essa justificativa, mas ele é teimoso desse jeito! Não posso fazer nada. Ou então vocês entram no livro e dão uma surra nele.)

Lu Linyuan sustentou o olhar furioso da imperatriz-viúva e respondeu com tranquilidade: — Vou explicar a Vossa Majestade como uma coisa levou à outra.

— Shuangruo bateu na Dama Ning. A Dama Ning carrega um descendente imperial no ventre; logo, Shuangruo agrediu indiretamente esse descendente. E, como o descendente é do meu sangue, isso significa que Shuangruo me esbofeteou indiretamente. Uma criada grosseira que ousa me desrespeitar! Poupar-lhe a vida já é consideração mais do que suficiente por Vossa Majestade.

A imperatriz-viúva ficou estarrecida. Evidentemente, não esperava que Lu Linyuan fosse acertar contas com ela por causa de Ning Xiaoxiao.

— Não pode cortá-las! Desde que entrei no palácio, Shuangruo serve a mim junto de Qingzhu. Imperador, como você pode...

— Eu não estou mandando matá-la. Por que tanta aflição, mãe? — Lu Linyuan interrompeu-a com um sorriso frio.

— Se ela não sabe controlar as mãos, também não fico tranquilo em deixá-la servir a Vossa Majestade. Sem elas, poderá continuar ao seu lado, e não precisarei me preocupar que essas garras desobedientes tornem a atingir alguém que não deveriam. Ferir qualquer outra pessoa já seria ruim; se ferisse minha mãe, isso sim seria uma falta imperdoável.

A imperatriz-viúva arfava de tanta raiva e só conseguiu permanecer de pé com o apoio da imperatriz.

Aproveitando que ela estava sem fôlego para protestar, Sanfu apressou os guardas: — O que estão esperando? Não entenderam a ordem de Sua Majestade?

Os guardas avançaram imediatamente, taparam a boca de Shuangruo e a arrastaram para fora.

O tirano acabara de ordenar uma punição sangrenta, e todos temeram pela própria pele.

A Consorte Yun, a Consorte Li e a Concubina Shen, que haviam se empenhado em pisotear Ning Xiaoxiao naquele dia, estavam especialmente apavoradas, quase sem alma no corpo.

Mas, com frequência, é justamente aquilo que se teme que acaba acontecendo.

No instante seguinte, Lu Linyuan voltou sua atenção para elas. Perguntou à imperatriz: — Se houver no harém pessoas que espalhem boatos, atiçem intrigas e façam questão de provocar o caos, como a imperatriz acha que devem ser tratadas?

Interpelada de repente, a imperatriz não se perturbou nem um pouco.

Afinal, quando todas se juntaram para atormentar Ning Xiaoxiao, ela não apenas deixara de atacá-la como até dissera palavras em sua defesa. — Penso que devem receber uma punição severa, para pôr fim a esse mau costume.

Os dedos de Lu Linyuan tamborilaram suavemente na mesa imperial, produzindo batidas secas.

Seu olhar passou devagar pelas consortes culpadas, e ele declarou em tom grave: — Fui eu quem, por vontade própria, recebeu a bala destinada à Dama Ning. Fiz isso para proteger o descendente imperial em seu ventre, ou seja, o sangue da dinastia Qi. De onde surgiu essa história de que ela usou feitiçaria para me enfeitiçar e confundir minha mente?

— Além disso, fui eu quem decidiu que a Dama Ning transmitiria minha ordem de prender o príncipe ocidental e lançá-lo à prisão imperial. Ela falou em meu nome. Afinal, vocês estão questionando a palavra dela ou a minha decisão? Hein?

A intenção ameaçadora cresceu a cada frase. As três se ajoelharam juntas, implorando: — Perdoe-nos, Majestade! Reconhecemos nosso erro...

— Já que reconhecem, recebam a punição. Transmitam meu decreto: a Consorte Yun, a Consorte Li e a Concubina Shen, por espalharem suspeitas infundadas, atacarem quem já estava em desgraça, transformarem boatos em supostas verdades e agirem de má-fé, perderão seis meses de estipêndio e receberão oitenta bofetadas na boca, como advertência às demais.

As três começaram a chorar e suplicar sem parar. Lu Linyuan, no entanto, resolveu bancar o surdinho adorável: não deu ouvidos a ninguém e mandou levá-las embora com um gesto.

Furiosa, a imperatriz-viúva praticamente rugiu: — Muito bem, imperador! Muito bem! Por causa dessa Ning, você chegou a esse ponto! Agora sim vi de tudo! Naquele dia, fui eu a primeira a esbofeteá-la. Já que se tornou tão poderoso, aproveite e castigue sua própria mãe também!

Lu Linyuan levantou-se, aproximou-se dela e afagou-lhe de leve as costas. Sua voz era gentil: — Minha mãe está exagerando. Como eu poderia castigá-la? Apenas me lembrei de que, desde minha ascensão ao trono, o Palácio Xianshou, onde Vossa Majestade mora sozinha, nunca passou por reformas. Imagino que não seja tão confortável.

— Portanto, determinei que, a partir de hoje, os departamentos de obras e da administração interna reformem inteiramente o Palácio Xianshou, para que minha mãe possa morar com toda a tranquilidade. Só há um inconveniente: ninguém poderá permanecer lá durante as obras. Peço que se mude temporariamente para o Palácio Shoukang e divida espaço com as consortes viúvas do falecido imperador.

Essas palavras, saindo da boca de Lu Linyuan, quase acabaram com a vida da imperatriz-viúva.

Ela dava enorme importância à própria posição. Fazer dela, esposa principal do falecido imperador, companheira de alojamento das antigas concubinas dele não equivalia a humilhá-la diante de todos?

A imperatriz-viúva bateu com força no chão usando a bengala com cabeça de fênix. Sua voz tremia: — Imperador! Por causa de uma simples dama, você vai mesmo contrariar sua mãe a esse ponto?

— Ah, esqueci de mencionar: ela já não é uma dama.

Lu Linyuan voltou os olhos para Ning Xiaoxiao, que estava pasma diante de todas aquelas manobras. Tomou-lhe a mão, ergueu-a ligeiramente e anunciou em tom solene: — A Dama Ning prestou serviços meritórios ao salvar minha vida. A partir de hoje, será promovida extraordinariamente ao posto de Nobre Dama e receberá o título honorífico de Hua.

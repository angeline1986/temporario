# Validação — capítulo 138

- **Fonte:** `novel_capitulos_121_a_180(20261103-233558).docx` — chinês tradicional, DOCX.
- **Limites:** parágrafos 1141 a 1208 do DOCX (índices reais, base zero); capítulo seguinte excluído.
- **Parágrafos não vazios:** 65, incluindo título e, quando presente, nota autoral.
- **Linhas de dados do CSV:** 65.
- **Índices ausentes:** 0; **duplicados:** 0; **campos vazios:** 0.
- **Método:** tradução integral e cotejo parágrafo a parágrafo com checagem automática dos índices, dos campos e da integridade dos arquivos.
- **Limitação:** o pareamento 1:1 e a revisão durante a tradução não constituem auditoria semântica independente integral; não se pode garantir inexistência de desvios internos apenas pela contagem de linhas.

## Notas editoriais

- A letra D usada no original é um eufemismo gráfico para os seios; a tradução explicitou o referente anatômico sem acrescentar acontecimentos.
- KZ (abreviatura de roupa íntima) é traduzido pela piada brasileira “já estava até tirando a calcinha”; é adaptação idiomática de humor.
- A fala sobre atirar (射) tem também duplo sentido sexual em chinês, preservado na troca de falas e pensamentos sem nota dentro da narrativa.
- “Conquista” traduz o título 征服, da canção mencionada na missão; não se adicionaram versos.
- A missão oferece 3 pontos percentuais em dobro, isto é, 6 pontos de aumento caso concluída; uma falha reduz 20% da vitalidade, não do índice.
- O capítulo apresenta o retorno de Xiao Qi e não a conclusão da missão; a tradução não antecipa o resultado.

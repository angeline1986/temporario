# Validação — capítulo 136

- **Fonte:** `novel_capitulos_121_a_180(20261103-233558).docx` — chinês tradicional, DOCX.
- **Limites:** parágrafos 1026 a 1081 do DOCX (índices reais, base zero); capítulo seguinte excluído.
- **Parágrafos não vazios:** 53, incluindo título e, quando presente, nota autoral.
- **Linhas de dados do CSV:** 53.
- **Índices ausentes:** 0; **duplicados:** 0; **campos vazios:** 0.
- **Método:** tradução integral e cotejo parágrafo a parágrafo com checagem automática dos índices, dos campos e da integridade dos arquivos.
- **Limitação:** o pareamento 1:1 e a revisão durante a tradução não constituem auditoria semântica independente integral; não se pode garantir inexistência de desvios internos apenas pela contagem de linhas.

## Notas editoriais

- A promoção ao posto 貴人 foi vertida como Nobre Dama; 答應 permanece Dama, sem confundi-la com 常在 (Atendente).
- O imperador afirma a gravidez como justificativa política, mas, conforme os capítulos anteriores, não há feto real; não se deve interpretar essa fala como prova de gestação.
- A punição de Shuangruo (霜若) é ordenada e ela é arrastada para fora; não se narra neste capítulo o resultado material da mutilação.
- O comentário entre parênteses da autora foi preservado e não se confunde com a voz narrativa.
- O original emprega expressões vulgares e anacrônicas; o registro de deboche foi conservado.

# Capítulo 137 — Xiaoxiao fica com a carne, e a pequena Gu ganha o caldo

As palavras de Lu Linyuan ecoaram pelo salão. Até Sanfu, que conhecia bem a preferência desmedida de seu senhor por Xiaoxiao, ficou surpreso.

Desde a fundação da dinastia Qi, nunca ocorrera uma promoção que pulasse graus na hierarquia.

As normas ancestrais estabeleciam uma progressão rigorosa para as mulheres do harém. Ning Xiaoxiao, nascida criada palaciana, já passara por cima do posto de Serva Imperial para se tornar diretamente Dama; agora saltava também o posto de Atendente e chegava a Nobre Dama. Não apenas o harém: a própria corte certamente discutiria aquilo. Quantos ministros conservadores não a chamariam de consorte demoníaca, responsável pela ruína do soberano?

Mas o que mais espantou a todos não foi a promoção extraordinária, e sim o título honorífico escolhido por Lu Linyuan para Ning Xiaoxiao:

— Hua.

Ao longo das dinastias, qual consorte que recebera o título Hua não se tornara uma potência dentro do harém?

A Consorte Imperial Nobre Hua, do imperador Gaozu, reduzira a imperatriz a uma figura decorativa e obtivera para si o controle exclusivo da administração dos seis palácios. A vida ou a morte de qualquer pessoa do harém dependia de uma palavra sua.

A Consorte Nobre Hua, do imperador Shengzu, vira seu sexto príncipe ser nomeado herdeiro do trono assim que nasceu. Por causa disso, o primogênito legítimo da imperatriz definhara de tristeza e sofrera inúmeras humilhações e zombarias.

Até a Consorte Hua do imperador anterior fora a mulher que a atual imperatriz-viúva mais temera. Se não tivesse morrido tão jovem, provavelmente nem seria Lu Linyuan quem ocuparia o trono hoje.

Os dedos da imperatriz apertaram quase imperceptivelmente o lenço de seda. Seu olhar percorria Ning Xiaoxiao, como se quisesse descobrir que artifícios extraordinários uma antiga criada possuía para transformar Lu Linyuan, antes indiferente às mulheres, num soberano apaixonado e insensato.

A antiga Consorte Nobre podia ser arrogante, e sua família materna, poderosa, mas jamais recebera de Lu Linyuan um título assim.

Mesmo Gu Sijin, que anteriormente gozara de grande favor imperial, fora promovida conforme todas as regras.

Bastara Ning Xiaoxiao aparecer e todas as normas tinham ido pelos ares. Parecia uma fora da lei imune a qualquer regulamento.

Por mais que a imperatriz estivesse profundamente insatisfeita, não demonstraria um pingo de desagrado naquele momento.

Em vez disso, seu rosto ganhou rapidamente um sorriso doce, e ela foi a primeira a se recuperar do espanto e felicitar Ning Xiaoxiao:

— Nobre Dama Hua, que ocasião feliz! Até eu me alegro por você.

— Por que continua parada? Ficou tão feliz que perdeu a fala? — perguntou, cobrindo a boca para rir, como se estivesse sinceramente radiante. — Agradeça depressa a imensa graça de Sua Majestade.

A imperatriz fazia aquilo de propósito, para que a imperatriz-viúva visse. Se ainda havia alguém capaz de reverter a situação, era ela.

Como esperado, ao ouvir a imperatriz praticamente bajular Ning Xiaoxiao, a imperatriz-viúva explodiu:

— O imperador pode jogar a etiqueta e as regras pela janela, mas eu não! Quando o falecido imperador vivia, administrei o harém por sete anos e nunca presenciei nada tão absurdo!

Encarou Ning Xiaoxiao com as sobrancelhas franzidas. — O título Hua só cabe a quem governa um palácio como consorte titular. As regras ancestrais estabelecem que uma mulher de origem servil só pode chegar, no máximo, ao posto de Nobre Dama. O imperador já concedeu uma honra extraordinária à família Ning, mas não pode atropelar as normas dos antepassados. Enquanto ela não for elevada a Concubina ou Consorte, não será digna do título Hua!

Para Lu Linyuan, aquela fúria não passava de um pum silencioso.

Com uma expressão indiferente, ele soltou três palavras num tom preguiçoso: — Porque eu quero.

— Você...

— Se minha mãe insistir em desobedecer publicamente ao meu decreto, alegando que o título Hua não combina com uma Nobre Dama, posso promovê-la imediatamente a Concubina ou Consorte. Assim, tudo ficará de acordo com o que deseja. — Lu Linyuan lançou à mãe um olhar provocador, erguendo uma sobrancelha. — Essa solução a satisfaz?

Os lábios da imperatriz-viúva ficaram arroxeados de raiva. — Imperador! Você já não se importa nem com as leis dos ancestrais?!

— Foram os soberanos que criaram essas leis, e eu também sou o soberano. Se o imperador Shengzu podia estabelecer normas, eu também posso revogá-las.

Enquanto os dois discutiam sem parar, Ning Xiaoxiao entrou em pânico.

【Você enlouqueceu, desgraçado?! Está fazendo questão de me transformar num alvo, é isso?】

【Eu só quero sobreviver discretamente até o fim da história! E você insiste em arrumar confusão e me obrigar a arrancar os cabelos dessas mulheres?!】

Ela fez uma reverência a Lu Linyuan e falou com todo o respeito: — Agradeço a imensa graça de Sua Majestade. Mas tenho uma origem humilde, não possuo bons modos e sei que minhas virtudes não fazem jus a essa posição. Suplico que Sua Majestade retire o decreto, para não me conceder uma honra que não mereço...

Lu Linyuan respondeu: — Se eu digo que você merece, então merece! E, se continuar dizendo que não merece, vou é cuspir em você!

Ning Xiaoxiao: — ...

【Arranje um tempinho para tratar dessa doença grave que você tem na cabeça, pelo amor de Deus!】

Ela lançou um olhar furtivo a Gu Sijin, que permanecera em silêncio. Sua expressão parecia normal, sem qualquer sinal de contrariedade.

Mesmo assim, Ning continuava preocupada: 【A pequena Gu ainda é Atendente, e eu virei Nobre Dama. E se ela ficar com ciúmes e romper comigo? A inveja é uma arma capaz de destruir a amizade entre garotas! Não vá forçá-la a virar vilã, seu maluco!】

Lu Linyuan não entendia por que Ning Xiaoxiao fazia tanta questão de agradar Gu Sijin, mas sabia que ela conseguia antever acontecimentos futuros.

Vivia ouvindo-a dizer que ele dedicaria todo o seu amor a Gu Sijin, embora não soubesse de onde vinha aquela conjectura.

Mas sabia que Gu Sijin era a única amiga com quem Ning Xiaoxiao podia conversar no harém.

Sempre que Xiaoxiao se metia em apuros, Gu Sijin corria para defendê-la.

Como imperador, ele não podia estar o tempo todo ao lado de Ning Xiaoxiao.

A maior solidão de um soberano era viver sem amigos, inteiramente sozinho, cercado de um silêncio interminável.

Ele já conhecera aquela solidão e não queria que Ning Xiaoxiao passasse pelo mesmo sofrimento.

Então pensou: 【Na pior das hipóteses, acrescento mais uma Nobre Dama. Não vai custar tanto assim. Desde que essa maluca continue feliz e me ajude a prever o futuro, posso arcar com a despesa!】

— Durante a gravidez da Nobre Dama Hua, a Atendente Gu cuidou dela com dedicação enquanto dividiam os aposentos. Além disso, embora o harém viva tomado por intrigas, a Atendente Gu nunca se envolveu nelas e sempre se mostrou respeitosa, comedida e digna. Decreto, portanto, que a Atendente Gu também seja promovida hoje ao posto de Nobre Dama.

Gu Sijin ficou atônita.

Ela não fizera absolutamente nada! Como tinha virado Nobre Dama de repente?

Ning Xiaoxiao, por outro lado, ficou ainda mais feliz com a promoção da amiga do que com a sua própria. Apressou-se a segurá-la pelo braço e a alertou:

— Irmã, não fique parada! Agradeça logo! — E sussurrou em seu ouvido: — Antes que ele mude de ideia!

Puxou Gu Sijin, ainda sem entender o que acontecia, e as duas se ajoelharam para agradecer juntas a graça imperial.

A intenção de Lu Linyuan ao tomar todas aquelas decisões era mais do que evidente.

Queria deixar claro a todos no harém que quem tratasse bem Ning Xiaoxiao poderia ascender rapidamente, ao passo que quem a maltratasse sofreria consequências desagradáveis.

A imperatriz-viúva soltou um ruído esquisito e desmaiou.

As consortes se reuniram ao redor dela para demonstrar preocupação. Lu Linyuan, incomodado com a gritaria, fez um gesto: — Levem a imperatriz-viúva de volta e chamem um médico imperial.

Quando estavam carregando-a até a porta, Lu Linyuan fez questão de acrescentar: — As reformas do Palácio Xianshou começam hoje. Não se esqueçam de levá-la ao Palácio Shoukang.

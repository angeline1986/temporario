# Validação do capítulo 289

- **Original chinês:** `novel_capitulos_271_a_300(20261106-202952).docx`.
- **Base portuguesa:** `novel capitulos 271 a 300 - ch.epub`, capítulo 289.
- **Índices reais do DOCX, base zero:** 1221–1289.
- **Unidades chinesas não vazias:** 66, incluindo o título.
- **Parágrafos de corpo do EPUB:** 65; título fornecido separadamente.
- **Pares em CSV:** 66; correspondência 1:1 entre título/corpo, índices reais preservados.

## Revisão editorial

Revisão focalizada a partir do EPUB e de cotejo de passagens com o DOCX chinês. Foram reescritos 35 parágrafos pontuais e normalizados alguns tratamentos imperiais.

**Pontos relevantes:** No início, a passagem 空城計 refere-se a uma estratégia em tratado militar, não ao título do livro; 金護甲 é protetor de unha, não armadura; a falsificação encontrada é um lenço, não uma moeda. A imperatriz arma a morte de Tong e incrimina Ning.

## Limites

A correspondência estrutural foi verificada para todas as unidades. **Não foi realizada segunda auditoria semântica independente de todas as frases.** Podem permanecer erros da tradução-base em trechos não reescritos; o cotejo 1:1 não certifica por si só fidelidade plena.

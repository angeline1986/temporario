# Validação do capítulo 291

- **Original chinês:** `novel_capitulos_271_a_300(20261106-202952).docx`.
- **Base portuguesa:** `novel capitulos 271 a 300 - ch.epub`, capítulo 291.
- **Índices reais do DOCX, base zero:** 1329–1404.
- **Unidades chinesas não vazias:** 73, incluindo o título.
- **Parágrafos de corpo do EPUB:** 72; título fornecido separadamente.
- **Pares em CSV:** 73; correspondência 1:1 entre título/corpo, índices reais preservados.

## Revisão editorial

Revisão focalizada a partir do EPUB e de cotejo de passagens com o DOCX chinês. Foram reescritos 36 parágrafos pontuais e normalizados alguns tratamentos imperiais.

**Pontos relevantes:** O título original contém a expressão “versão sem retrocesso”, mas o corpo narra explicitamente Ning retrocedendo três minutos: contradição preservada e sinalizada, não harmonizada. A frase original 1335 usa 貴妃 (Consorte Nobre) como vítima por aparente lapso, mas o sentido é claramente Concubina Tong. A nota autoral “0/1” foi preservada como trocadilho grosseiro de forma corporal.

## Limites

A correspondência estrutural foi verificada para todas as unidades. **Não foi realizada segunda auditoria semântica independente de todas as frases.** Podem permanecer erros da tradução-base em trechos não reescritos; o cotejo 1:1 não certifica por si só fidelidade plena.

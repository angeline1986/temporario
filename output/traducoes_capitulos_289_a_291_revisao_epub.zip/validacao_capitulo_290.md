# Validação do capítulo 290

- **Original chinês:** `novel_capitulos_271_a_300(20261106-202952).docx`.
- **Base portuguesa:** `novel capitulos 271 a 300 - ch.epub`, capítulo 290.
- **Índices reais do DOCX, base zero:** 1290–1328.
- **Unidades chinesas não vazias:** 36, incluindo o título.
- **Parágrafos de corpo do EPUB:** 35; título fornecido separadamente.
- **Pares em CSV:** 36; correspondência 1:1 entre título/corpo, índices reais preservados.

## Revisão editorial

Revisão focalizada a partir do EPUB e de cotejo de passagens com o DOCX chinês. Foram reescritos 19 parágrafos pontuais e normalizados alguns tratamentos imperiais.

**Pontos relevantes:** O texto da audiência 朝 é a sessão da corte imperial, não tribunal; o objetivo da imperatriz é prender Ning antes do retorno do imperador. O chinês emprega pronome 他 ao lançar depoimentos, mas a sequência aponta para a imperatriz; mantida a atribuição contextual. 

## Limites

A correspondência estrutural foi verificada para todas as unidades. **Não foi realizada segunda auditoria semântica independente de todas as frases.** Podem permanecer erros da tradução-base em trechos não reescritos; o cotejo 1:1 não certifica por si só fidelidade plena.

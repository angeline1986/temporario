# Capítulo 289 — A imperatriz mata a Concubina Tong com as próprias mãos

Palácio Fengluan.

Já passa da meia-noite e a Imperatriz ainda não dá sinais de que vai dormir.

Ela lia à luz de uma lamparina um tratado de estratégia militar. Havia chegado à passagem sobre a Estratégia da Cidade Vazia quando Xiangling entrou apressada.

“Majestade, exatamente como a senhora previu: a Consorte Nobre realmente foi ao Palácio Frio visitar a Concubina Tong.”

Enquanto a Imperatriz virava as páginas do livro, disse calmamente:

“Ela pediu ao imperador que perdoasse a condenação à morte da mulher do clã Tong e a confinasse no Palácio Frio. Que boas intenções poderia ter?”

"Ela odiava a Concubina Tong tanto quanto eu, e desejava que ela sofresse dia e noite, desejando estar morta. Deixar alguém tão mimada quanto a Concubina Tong viver no palácio frio, sem ninguém para servi-la, tendo que fazer tudo sozinha todos os dias, como lavar roupa e acender o fogo, não é pior que a morte?"

Ela fechou o livro militar com força, a voz endurecendo: "Mas eu não quero vê-la sofrer um destino pior que a morte; eu só quero que ela tenha uma morte horrível!"

"Como Imperatriz, sofri tanto nas mãos dela no palácio durante tantos anos. Só de pensar que ela ainda está viva e respirando o mesmo ar que eu, sinto nojo!"

Com a longa proteção dourada que usava sobre a unha, acariciou lentamente as páginas ásperas do tratado militar. Um meio sorriso surgiu em seus lábios.

“A Estratégia da Cidade Vazia ensina a jogar com o verdadeiro e o falso: a guerra não tem forma fixa, e às vezes se exibe a própria fraqueza para semear dúvidas no inimigo. A leitura me deu uma ideia interessante.”

“Faz muito tempo que ninguém mora no Palácio Frio. Os guardas trocam de turno na hora chou, por volta de uma da madrugada. De tão relaxados que ficaram, sempre passam cerca de meia hora matando tempo. Se eu for lá nessa hora, ninguém ficará sabendo.”

“A senhora vai visitá-la pessoalmente?” Xiangling se espantou. “Bastaria mandar esta serva executar suas ordens. A senhora é a imperatriz; rebaixar-se a ir ao Palácio Frio ainda pode trazer mau agouro...”

“Medo de quê? Por mais agourento que seja este palácio, sem aquela Tong tudo voltará a ser auspicioso. Só vou aliviar os anos de ressentimento que carrego se eu mesma lhe der cabo da vida. Se outra pessoa fizer isso, não será a mesma coisa.”

Entre as criadas que trouxera da família materna, havia uma especialmente habilidosa em imitar vozes.

A imperatriz mandou que a moça se deitasse em sua cama imperial, vestisse sua roupa de dormir, se cobrisse e ficasse de lado, fingindo dormir.

Ela deixou Xiangling para espalhar a notícia de que estava com dor de cabeça e convocou as concubinas para que se revezassem para cuidar dela.

Quando as concubinas foram convocadas uma a uma, Xiangling ficou de guarda ao lado da cama da Imperatriz, impedindo-as de se aproximarem. Além disso, a criada do palácio, que se fazia passar pela Imperatriz, dormia de lado, e as luzes do salão eram fracas e amareladas, tornando impossível vê-la claramente.

Ao ouvir os gemidos que pareciam sair da própria imperatriz, as consortes logo presumiram que fosse realmente ela quem estava na cama.

Entretanto, a verdadeira imperatriz havia trocado de roupa, vestindo trajes discretos do dia a dia, e, acompanhada por Xia Guo, dirigiu-se ao Palácio Frio.

Ela chegou justamente quando os guardas estavam trocando de turno, e o grupo de patifes encontrou um canto isolado para beber, o que deu à Imperatriz a oportunidade de tirar proveito da situação.

Ela tinha a chave do Palácio Frio, então abriu a porta e entrou direto.

Ao abrir a porta do aposento, viu Tong Yuanyuan sobre uma mesa. Da viga pendia uma tira resistente de tecido branco, feita com roupas que trouxera para o Palácio Frio.

Era como a seda branca usada nos enforcamentos: Tong Yuanyuan pretendia tirar a própria vida ali.

Tong Yuanyuan sabia que a imperatriz viria zombar de sua desgraça, sem conseguir esperar nem mais um instante. Desde que Ning Xiaoxiao partira, estava à espera dela.

Pretendia se enforcar diante da imperatriz no momento em que esta começasse a humilhá-la, para que sua morte recaísse sobre a rival.

Lu Linyuan não ordenara sua execução. Se morresse nas mãos da imperatriz, esta carregaria a culpa por sua morte.

Como Lu Linyuan adorava Ning Xiaoxiao, poderia usar o incidente como pretexto para depor a imperatriz e elevar Ning ao trono de imperatriz.

Tong Yuanyuan achava que tinha planejado tudo perfeitamente, e no momento em que seus olhos encontraram os da Imperatriz, ela riu arrogantemente:

“Sua desgraçada! Finalmente você veio!”

A Imperatriz olhou para ela. "Você quer se matar?"

“Eu não estou me matando! Foi você que me obrigou a morrer! Sua desgraçada! Nem depois de morta vou deixar você em paz!”

Ao terminar, chutou a cadeira sob os pés e deixou o pescoço preso na tira de tecido, debatendo-se por reflexo ao sentir o aperto.

A imperatriz não conseguiu conter uma risadinha. Cobriu a boca e lançou um olhar significativo a Xia Guo.

Xia Guo era uma criada do palácio que havia aprendido artes marciais com ela.

Empunhando uma adaga, ela usou o impulso para saltar, e seus passos leves permitiram que ela rasgasse facilmente a seda branca, fazendo com que Tong Yuanyuan caísse pesadamente no chão.

Ela caiu de uma altura e torceu o tornozelo, ficando sem conseguir se levantar por um tempo.

A imperatriz aproximou-se dela passo a passo, com os olhos cheios de uma luz gélida.

Ela caminhou até Tong Yuanyuan, pegou a adaga de Xia Guo e se inclinou para pressionar a lâmina fria e afiada contra o queixo de Tong Yuanyuan.

“Quer tanto assim morrer? Por que não me contou? Eu ficaria muito feliz em ajudá-la a partir desta vida.”

"Pah!" Tong Yuanyuan cuspiu no rosto da Imperatriz. "Hahahaha, sua velha, sua vadia! Acha que vai sair impune depois que eu morrer? Você... ahh!"

Rasgo!

Antes que ela pudesse terminar de falar, a Imperatriz cortou seu rosto duas vezes com uma lâmina afiada.

O sangue jorrou da ferida instantaneamente, e o rosto de Tong Yuanyuan se contorceu de dor. O corte de faca parecia uma centopeia ensanguentada serpenteando por seu rosto, uma visão horripilante.

“É verdade que já não sou tão jovem quanto você. Mas sua vida vai terminar hoje, enquanto eu continuarei vivendo muito bem!”

Após dizer isso, a Imperatriz ergueu sua adaga e a cravou com força no coração de Tong Yuanyuan.

Sua expressão era feroz, e ela parecia extremamente assustadora sob a luz do luar:

"Deixe-me dizer uma coisa: ninguém pode competir comigo! A única consequência de se opor a mim é a morte!"

A adaga foi desembainhada, espalhando sangue por todo o corpo dela, mas ela não demonstrou nenhum medo e a atacou novamente com um golpe violento.

Tong Yuanyuan nem teve tempo de gritar de dor antes de estar à beira da morte.

Hahahaha~

A imperatriz riu como uma louca. “Ninguém ficará sabendo do que aconteceu aqui esta noite, muito menos de minha visita. A última pessoa a vê-la foi Ning Xiaoxiao. Não tenho nada a ver com isso.”

“Amanhã, quando anunciarem sua morte, certamente vou vingar você — e mandar Ning Xiaoxiao para o outro mundo.”

“Assim você não ficará sozinha no caminho para o mundo dos mortos!”

Ela sacou o punhal e observou Tong Yuanyuan desabar diante dela como um monte de lama, sentindo uma imensa sensação de satisfação.

Xia Guo tirou a adaga da mão dela e lhe entregou um lenço para limpar as mãos.

O lenço trazia bordados auspiciosos de dragão e fênix, um desenho que Lu Linyuan mandara produzir na Oficina Imperial exclusivamente para o Palácio Fengyi, destinado ao uso de Ning Xiaoxiao.

O lenço nas mãos da imperatriz era uma imitação que mandara fazer às escondidas, perfeita o bastante para passar pelo original.

Ela limpou o sangue dos dedos e cobriu com o lenço o rosto de Tong Yuanyuan, morta de olhos abertos.

Depois disso, voltou às pressas ao Palácio Fengluan e entrou por um buraco de cachorro junto ao portão dos fundos.

Aproveitou a troca das consortes que cuidavam da suposta doente, passou por uma janela treliçada, trocou discretamente de roupa e se deitou.

Quando a Consorte Duan entrou para prestar cuidados, a imperatriz fez questão de chamá-la à cabeceira e trocar algumas palavras sem importância, só para que a visitante visse bem seu rosto.

Dessa forma, ninguém soube que a Imperatriz havia deixado o Palácio Fengluan esta noite.

Ninguém a associaria à notícia da morte de Tong Yuanyuan, que seria divulgada no Palácio Frio amanhã.

E, como Ning Xiaoxiao fora a última pessoa conhecida a visitar Tong Yuanyuan, dificilmente conseguiria provar sua inocência — nem se pulasse no Rio Amarelo para se lavar.

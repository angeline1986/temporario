# Capítulo 291 — Ning Xiaoxiao dá uma surra na imperatriz (versão sem retrocesso)

Ao ouvir o decreto da imperatriz, os eunucos que aguardavam do lado de fora do Palácio Fengluan entraram em massa.

Gu Sijin abriu os braços como uma enorme ave de rapina, protegendo Ning Xiaoxiao atrás de si, e se apressou a argumentar:

“Imperatriz, peço que examine bem os fatos! A Consorte Nobre jamais faria algo assim!”

“O imperador condenou as nove gerações do clã Tong à morte. Foi a Consorte Nobre quem implorou que poupasse a Concubina Tong! Como poderia pedir por sua vida num instante e, no seguinte, matá-la com as próprias mãos? Isso não faz sentido!”

Ning Xiaoxiao não suportava ver sua adorável Gu Sijin se humilhar assim diante da imperatriz.

Ela puxou o ombro de Gu Sijin, "Não se preocupe, irmã, eles não ousarão fazer nada comigo."

Lançando um olhar feroz aos eunucos que se aproximavam, ameaçou: “Aquele que ousar encostar um dedo em mim hoje será executado por esquartejamento!”

"Se você não acredita em mim, experimente."

Os eunucos ficaram em um dilema ao ouvirem isso. Eles sabiam o quanto Lu Linyuan favorecia Ning Xiaoxiao. Se Lu Linyuan ainda escolhesse protegê-la desta vez, não seriam eles, os que agiram, os primeiros a sofrer as consequências?

Ao vê-los hesitar, a imperatriz se enfureceu ainda mais. “Por que estão parados? As provas de que a Consorte Nobre matou a Concubina Tong são irrefutáveis! A Nobre Dama Gu talvez seja cúmplice. Prendam-na também e levem-na ao Departamento de Punições para ser torturada!”

Eles não ousavam tocar em Ning Xiaoxiao, mas não temiam pôr as mãos em Gu Sijin, uma consorte que Lu Linyuan aparentemente já esquecera.

Alguns avançaram e começaram a agarrar Gu Sijin.

Ning Xiaoxiao protegeu Gu Sijin, depois pegou casualmente uma xícara de chá da mesa e derramou o chá quente de dentro no rosto de um dos eunucos.

O eunuco, escaldado, rolou no chão, agarrando o rosto, enquanto outros eunucos aproveitaram a oportunidade para agarrar o braço de Gu Sijin.

Gu Sijin tropeçou e caiu no chão enquanto se debatia, arranhando o pulso.

Essa atitude enfureceu profundamente Ning Xiaoxiao.

Ela franziu a testa e olhou fixamente para os eunucos que haviam ferido Gu Sijin, depois fechou os olhos e retrocedeu três minutos.

Três minutos antes, a imperatriz acabara de dar a ordem:

“Por que continuam aí parados? As provas de que a Consorte Nobre matou a Concubina Tong são irrefutáveis! Quanto à Nobre Dama Gu...”

"Aaaaah!!!"

Antes que ela terminasse, uma sequência de gritos horríveis irrompeu no salão.

Ning Xiaoxiao tirou de algum lugar um martelo com cabo de ouro e começou a golpeá-lo repetidamente nas virilhas dos eunucos que haviam intimidado Gu Sijin.

Esse golpe devastador para eles, que já haviam perdido sua masculinidade, foi como acrescentar insulto à injúria.

Quatro ou cinco eunucos acabaram atingidos tão violentamente nas partes íntimas que parecia que tudo ali tinha sido esmagado.

O passarinho voou e os ovos foram quebrados... Hum, ovos já não havia, mas o passarinho certamente foi desta para melhor.

(Na antiguidade, ao castrar um eunuco, retirava-se o “zero” e deixava-se o “um”; não era tudo cortado de uma vez, viu?~)

Quem poderia prever que Ning Xiaoxiao de repente reagiria com tanta violência e lançaria um ataque tão poderoso?

Quando terminou, achou que o martelo estava sujo. Então apertou os olhos, mirou na imperatriz à distância e arremessou-o.

A imperatriz exclamou: "Ó, minha mãe!" e, apavorada, enterrou o rosto debaixo da mesa da fênix.

O martelo passou por ela e despedaçou o disco de jade decorado com o motivo “A fênix canta nos nove céus”.

A imperatriz endireitou a coroa às pressas e gritou: “Muito bem! Agora também quer me matar? Todos viram! A Consorte Nobre está fora de si e não hesita em agredir pessoas diante de tantas testemunhas. Só pode ter sido ela quem matou a Concubina Tong!”

"Como pode uma louca tão perigosa permanecer no harém? Ela deixou o Imperador completamente apaixonado por ela; como o harém poderá ter paz com ela por perto?!"

"Xiangling! Chame imediatamente a Guarda Imperial! Execute essa vadia agora mesmo!"

Ela queria provocar Ning Xiaoxiao deliberadamente para poder resolver a situação rapidamente.

Quando Lu Linyuan chegou, ela já havia obtido sucesso.

Lu Linyuan não poderia depô-la como imperatriz por causa disso; na pior das hipóteses, ele apenas a repreenderia e a ignoraria.

De qualquer forma, ele nunca demonstrou afeto por ela, então tudo o que ela precisa fazer é garantir que sua posição como esposa principal seja inabalável.

Xiangling correu para fora a fim de cumprir a ordem. Ning Xiaoxiao tentou detê-la, mas a criada teve a audácia de empurrá-la.

Parece que ela está perdendo a vontade de viver.

Ning Xiaoxiao agarrou o braço com que Xiangling a empurrara e a derrubou com um golpe de judô por cima do ombro.

Em seguida, pisou com força no rosto dela, deformando-lhe as feições.

A Imperatriz rugiu para ela: "Ning! Você enlouqueceu! Xiangling me representa, como ousa tocar nela?"

"Representando você? E pense bem sobre o que você realmente é?"

Ning Xiaoxiao cuspiu em Xiangling, arregaçou as mangas e caminhou diretamente em direção à Imperatriz.

Ao ver isso, a Imperatriz tentou escapar, mas Ning Xiaoxiao agarrou-a pelos cabelos e arrancou-lhe a coroa de fênix, atirando-a ao chão.

“Porra, como eu odeio gente que fica pagando de superior!”

Ela derrubou a imperatriz, montou sobre ela e começou dando-lhe dois tapas bem estalados na cara.

A rainha gritou de terror, como uma galinha cujas penas foram arrepiadas enquanto alguém a perseguia para roubar seus ovos.

Ning Xiaoxiao tirou um sapato da imperatriz e o enfiou na boca dela para calar seus gritos.

Então começou a espancá-la sem piedade, soltando insultos a cada golpe:

"Nem mesmo seus sapatos tamanho 38 conseguem calar sua boca fedorenta tamanho 42!"

“Você morre se passar um dia sem se achar a última bolacha do pacote? Se passar um dia sem causar confusão, apodrece por dentro?!”

“Eu te dei espaço para tagarelar e bancar a importante por mais de seiscentos mil caracteres de história, e você ainda vem se exibir para cima de mim?”

“Nunca levou umas boas porradas da vida desde que nasceu? Acha que sua existência fica incompleta sem isso?”

Ela acertava um golpe atrás do outro, deixando a imperatriz com o rosto inchado e arroxeado, incapaz de reagir.

As concubinas restantes ficaram atônitas. A consorte Duan não pôde deixar de oferecer um conselho:

"Vossa Alteza, por favor, pare de bater nela! Sua Majestade a Imperatriz é a senhora do harém e a mãe da nação, como pôde..."

"Cale a boca!" Ning Xiaoxiao se virou e lançou um olhar furioso para a Consorte Duan.

"Nem sequer te responsabilizei pela pulseira anticoncepcional que deste à minha irmã. É melhor não causar problemas sem motivo, ou te esfolo vivo e faço roupas para mandar aos teus pais para o inverno!"

A Consorte Duan, sempre a “filhinha que aquece o coração”, concluiu: melhor não provocar; pode continuar...

Ning Xiaoxiao ainda a espancou por algum tempo, até ouvir o anúncio estridente de um eunuco junto ao portão:

"Sua Majestade chegou!"

Todas as concubinas se levantaram e se curvaram em direção à porta. Lu Linyuan entrou lentamente, e Ning Xiaoxiao também ficou atônita por um momento, interrompendo o que estava fazendo.

Ela não tinha medo de que Lu Linyuan a acusasse de agredir a Imperatriz; ela apenas sentia que deixar Lu Linyuan vê-la naquele estado violento arruinaria sua imagem de "gentil e virtuosa" aos olhos dele...

Assim que Ning parou, a imperatriz aproveitou para arrancar o sapato da boca e implorar em lágrimas a Lu Linyuan:

"Waaaah~ Majestade! Majestade, salve-me!"

“A Consorte Nobre vai me espancar até a morte!”

Lu Linyuan olhou para ela calmamente e pronunciou uma frase simples:

“Mas você ainda não morreu, não é? Sem pressa. Quando estiver quase morrendo, naturalmente vou pensar se devo salvá-la.”

Depois disso, achando que faltava alguma coisa, ele acrescentou:

“Mas só pensar, viu? E nem por muito tempo.”

Imperatriz: "???"

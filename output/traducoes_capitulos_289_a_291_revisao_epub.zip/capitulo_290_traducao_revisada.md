# Capítulo 290 — Xiaoxiao: Achei que você tivesse morrido

O palácio da Imperatriz foi um alvoroço a noite toda. Além de Ning Xiaoxiao e Gu Sijin, todas as concubinas foram até lá para se revezarem nos cuidados com a mulher doente durante a noite.

Na manhã seguinte, chegaram notícias do Palácio Frio.

“Uma desgraça! A Concubina Tong... A Concubina Tong foi assassinada no Palácio Frio ontem à noite!”

Um jovem eunuco levou a notícia ao Palácio Fengluan. Quase todas as consortes ainda estavam lá, e a notícia deixou todas aterrorizadas.

Ao ouvir o relato da morte brutal de Tong, a imperatriz recitou uma invocação budista, fingindo piedade, e se levantou.

A consorte Duan aconselhou-a: "Majestade, a senhora não está se sentindo bem, deveria descansar mais."

“Como posso descansar?” A imperatriz pareceu tomada de angústia, com expressão tão devastada como se a morta fosse sua própria mãe.

"Esta é uma vida humana! Uma vida humana viva, que respira! Mesmo que eu e a Concubina Tong estejamos em desacordo, não posso ficar de braços cruzados enquanto ela é assassinada no palácio!"

Como Lu Linyuan estava em audiência na corte, a imperatriz ordenou que ninguém levasse o caso a ele por enquanto. Ela mesma faria a investigação primeiro.

Com a queda de Tong Guowei ainda recente, Lu Linyuan certamente aproveitaria a audiência para identificar e punir seus cúmplices; por isso, aquela sessão da corte seria longa.

Ela calculara tudo. Precisava prender Ning Xiaoxiao antes que Lu Linyuan encerrasse a audiência e tomasse conhecimento da morte.

Levou as consortes para o salão principal e ordenou que o caso fosse investigado minuciosamente.

Ela orquestrou todo o caso, e as provas são irrefutáveis, apontando todas para o Palácio Fengyi.

Os guardas do Palácio Frio testemunharam que apenas Ning Xiaoxiao foi ao Palácio Frio para ver Tong Yuanyuan na noite passada.

O legista examinou o corpo de Tong Yuanyuan e confirmou que ela morreu devido a um objeto cortante que perfurou seu coração. Um lenço de seda foi encontrado ao lado dela.

Os funcionários da Oficina Imperial afirmaram que o modelo do lenço fora concedido por ordem pessoal de Lu Linyuan e que só Ning Xiaoxiao tinha permissão para usá-lo no palácio.

Imediatamente, as concubinas começaram a fofocar, e a Imperatriz ficou furiosa. Ela ordenou que alguém convocasse Ning Xiaoxiao e Gu Sijin.

Quando chegaram, as duas já sabiam do assassinato da noite anterior e de todas as provas que pareciam incriminar Ning Xiaoxiao.

Do lado de fora do Palácio Fengluan, Gu Sijin aconselhou: “Não seria melhor procurarmos o imperador primeiro? A imperatriz preparou tudo e quer claramente jogar essa culpa em você.”

Gu Sijin se sentia culpada diante de Ning Xiaoxiao.

Anteriormente, ela havia manipulado a Consorte Li, levando-a a acreditar que Tong Yuanyuan era a responsável por sua desfiguração.

Ela fez isso para apressar a morte de Tong Yuanyuan, para que o clã Tong perdesse seu infiltrado no harém.

Gu Sijin acreditava que a Consorte Li matara Tong Yuanyuan. Por isso, temia que sua intervenção de antes acabasse fazendo a culpa recair sobre Ning Xiaoxiao.

Ning Xiaoxiao, no entanto, não se deixou abalar por esses comentários desfavoráveis. Ela sorriu, disse a Gu Sijin para relaxar e, em seguida, entrou com confiança no salão principal do Palácio Fengluan.

Todos os olhares das concubinas estavam fixos nela. Ela sorriu docemente, ergueu as sobrancelhas delicadas e perguntou à Imperatriz com seriedade:

“Ora, a imperatriz ainda está viva?”

"Você causou tanto alvoroço ontem à noite que pensei que não fosse viver muito mais tempo."

“Que insolência!”

A imperatriz bateu na mesa e berrou: “Como ousa, mulher do clã Ning! Você assassinou cruelmente uma consorte e ainda se atreve a me afrontar?”

Ela lançou ao chão os depoimentos das pessoas envolvidas. “Veja você mesma! O que ainda tem a dizer em sua defesa?”

Ning Xiaoxiao nem se deu ao trabalho de olhar para aquilo e disse com voz fria: "Não preciso discutir sobre coisas que não fiz."

A Imperatriz pareceu irritada com suas palavras, seus lábios tremendo enquanto dizia:

"Você pensa que só porque o Imperador a favorece, pode fazer o que quiser no harém? Como Imperatriz, tenho o direito de lidar com as concubinas!"

“Guardas! Prendam a Consorte Nobre! Levem-na imediatamente ao Departamento de Punições e a submetam a interrogatório sob tortura, até arrancarem uma confissão!”

(PS: Haverá uma terceira atualização à meia-noite de hoje~)

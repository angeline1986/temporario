# Validação editorial e estrutural — capítulo 246

- **Fonte:** `novel_capitulos_212_a_270(20261105-204934).docx` (chinês tradicional), índices reais dos parágrafos da biblioteca python-docx, base zero.
- **Intervalo bruto DOCX:** 2385–2474 (o próximo capítulo começa em 2475).
- **Unidades não vazias:** 87 (inclui o título, sem notas de autora quando não presentes no trecho).
- **Índices no cotejo:** 2385–2473, preservando saltos correspondentes a parágrafos vazios.
- **Cobertura:** 87 originais não vazios / 87 traduções não vazias; associação 1:1.
- **Integridade:** não há índices duplicados, campos de tradução vazios nem unidades não vazias do intervalo sem linha no CSV.
- **Markdown:** tradução organizada na mesma ordem do cotejo, com o título na primeira linha.

## Decisões e pontos de atenção

- Manteve-se a diferença entre a penalidade em vitalidade anunciada no 245 e a expectativa de Ning de desmaiar por dois dias; o segundo é temor dela, não regra nova confirmada pelo sistema.
- O fato de Lu ouvir os pensamentos de Ning explica sua decisão; não é apresentado como submissão forçada.
- A missão é marcada como concluída pelo sistema, com 50% de desvio acumulado (45% anteriores mais cinco pontos percentuais).
- “騾子和馬都在調上”: expressão inusitada de indignação no original; optou-se por representação aproximada e assinala-se a ambiguidade para revisão.
- 阿淵 transliterado A-Yuan; 小字 significa nome de infância/intimidade.
- “Sou seu pai” é piada de Ning sobre repetir a forma de tratamento usada pelo falecido imperador; não é relação genealógica.

## Escopo da validação

A inspeção feita confirma a cobertura de unidades, a existência dos arquivos, a ordem e a legibilidade estrutural. A tradução foi produzida com leitura e interpretação do original, mas **não foi realizada uma segunda auditoria semântica integral e independente**. Pontos idiomáticos sinalizados acima podem merecer nova revisão.

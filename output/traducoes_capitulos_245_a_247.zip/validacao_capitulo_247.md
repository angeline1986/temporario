# Validação editorial e estrutural — capítulo 247

- **Fonte:** `novel_capitulos_212_a_270(20261105-204934).docx` (chinês tradicional), índices reais dos parágrafos da biblioteca python-docx, base zero.
- **Intervalo bruto DOCX:** 2475–2556 (o próximo capítulo começa em 2557).
- **Unidades não vazias:** 79 (inclui o título, sem notas de autora quando não presentes no trecho).
- **Índices no cotejo:** 2475–2555, preservando saltos correspondentes a parágrafos vazios.
- **Cobertura:** 79 originais não vazios / 79 traduções não vazias; associação 1:1.
- **Integridade:** não há índices duplicados, campos de tradução vazios nem unidades não vazias do intervalo sem linha no CSV.
- **Markdown:** tradução organizada na mesma ordem do cotejo, com o título na primeira linha.

## Decisões e pontos de atenção

- “你禮貌嗎”: frase cômica recorrente, mantida como “Você acha isso educado?”.
- Duplo sentido de chorar na cama preservado; cenas são provocação e intimidade mútua.
- 長公主: “princesa mais velha”; não foi nomeada sem sustentação no original.
- A intimidade é interrompida pelo cuidado de Lu com o período menstrual de Ning; não inventar consumação.
- “D上加D”: piada sobre tamanho dos seios, adaptada pelo sentido em vez de criar uma medição real.
- A comparação com ratos segue como humor afetuoso, sem mudar o sentido da declaração final.

## Escopo da validação

A inspeção feita confirma a cobertura de unidades, a existência dos arquivos, a ordem e a legibilidade estrutural. A tradução foi produzida com leitura e interpretação do original, mas **não foi realizada uma segunda auditoria semântica integral e independente**. Pontos idiomáticos sinalizados acima podem merecer nova revisão.

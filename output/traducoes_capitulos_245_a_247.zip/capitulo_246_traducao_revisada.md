# Capítulo 246 — Arredondando as contas, isso praticamente faz de mim seu pai

Ning Xiaoxiao havia superestimado Xiao Qi.

O sistema só se comportara normalmente por um breve instante, antes de voltar a empurrá-la para a morte.

【Por que voltou a ser tão desgraçado...?】

【Não me xingue, hospedeira! Todas as missões são emitidas pela Administração do Espaço-Tempo. Sou apenas um sisteminha insensível encarregado de transmitir as ordens...】

Ning Xiaoxiao lançou um olhar furtivo para Lu Linyuan, que caminhava a seu lado segurando sua mão, e ficou pensativa.

E se... tentasse?

Afinal, ela também estava com vontade de ver!

Quando chegaram à Academia Bitong, já estava escurecendo.

Depois do jantar, Lu Linyuan começou a planejar como convencer sua esposa a vestir a «roupa nova».

Tirou o dudou do embrulho e o pendurou no indicador. Parecia não passar de um retalho de seda incapaz de cobrir coisa alguma. Com um sorriso malicioso, declarou:

— Está ficando tarde. É hora de trocar de roupa e ir dormir.

Apoiando o queixo nas mãos, Ning Xiaoxiao respondeu muito séria: — Quem comprou é que tem de vestir.

Lu Linyuan já estava acostumado às gracinhas dela e não levou a proposta a sério. Pelo contrário: aproximou o dudou do próprio peito, fingindo experimentar a peça para provocá-la.

— O tamanho não serve. Se quiser me ver usando, compre um maior da próxima vez.

Caramba... Ning Xiaoxiao não esperava que ele fosse entrar na brincadeira tão facilmente.

Pelo tom dele, parecia achar que ela estava brincando.

Mas ela falava com toda a sinceridade!

Percorreu a peça com os olhos várias vezes e sondou, sorridente: — Majestade... e se você vestisse só um pouquinho para eu ver?

O rosto de Lu Linyuan enrijeceu; uma sobrancelha arqueada tremeu involuntariamente. — Está falando sério?

Ning Xiaoxiao assentiu devagar.

No instante seguinte, o dudou foi atirado sobre a cabeça dela.

— Que absurdo! Sou um homem feito, de respeito! Como poderia vestir roupas femininas dessas?

Percebendo que ele parecia irritado, Ning Xiaoxiao ergueu logo as mãos e riu: — Ai, Majestade, que braveza! Foi só uma brincadeira!

【Você, um homem de respeito... Até grávido você conseguiu ficar! O que mais seria impossível para você?】

Lu Linyuan: — ...

Ele estava prestes a puxá-la para perto e dar dois petelecos na testa dela, para conferir se tinha mingau dentro da cabeça.

Mas então ouviu as reclamações que ela fazia em pensamento:

【Pensando bem, é melhor ele não vestir mesmo. Seria humilhante demais. Ele é o imperador, não pode simplesmente abrir mão de toda a dignidade, pode?】

【E eu também não posso aproveitar que ele gosta de mim para submetê-lo a pegadinhas cada vez mais absurdas só por causa das missões...】

【Deixa para lá. Posso abrir mão dessa missão. Na pior das hipóteses, fico desacordada por dois dias.】

【Mas preciso preparar o Lu para isso. Se eu desmaiar sem aviso, ele vai morrer de preocupação!】

Lu Linyuan permaneceu calado por um momento antes de dizer: — A água está aquecida no aposento lateral. Vá tomar banho primeiro.

Depois que Ning Xiaoxiao saiu, ele pegou o dudou e o examinou atentamente. Um rubor inexplicável lhe subiu ao rosto.

Seria mais uma daquelas missões sem pé nem cabeça?

Se ela não a completasse, ficaria inconsciente por dois dias?

A imagem da ocasião em que Ning Xiaoxiao ficara desacordada por não ter cumprido uma missão no aniversário dele ainda estava fresca em sua memória.

Daquela vez, durara apenas uma noite. Se passasse dois dias inteiros inconsciente, mesmo que não sofresse consequências graves, ficar sem comer e beber por tanto tempo certamente faria mal à saúde.

Ele segurou a peça e a balançou na mão.

Comparado com ver sua esposa comilona ficar dois dias desacordada, quase morrendo de fome, vestir o dudou escondido por um instante...

Não parecia grande coisa, certo?

Enquanto tomava banho, Ning Xiaoxiao convocou Xiao Qi.

【Será que você não consegue agir normalmente? Fale com a Administração do Espaço-Tempo! Tudo bem desviar a trama, mas parem de me obrigar a atormentar o Lu!】

Xiao Qi: 【Hospedeira! Isso realmente não está sob meu controle... E, além disso, aquelas outras missões nem chegam a desviar tanto a trama...】

Ning Xiaoxiao: 【Como não? Vou dar uns exemplos! Fazer a imperatriz-viúva ser montada por um porco; pendurar a imperatriz na torre do portão da cidade por três dias e três noites sob o sol; arrancar os dentes da frente da Concubina Tong; ou, sei lá, obrigar a Consorte Duan a raspar a cabeça, virar monja e depois procurar um monge para fazer sexo! Qual dessas missões não desviaria mais a trama do que as que você me dá?】

Xiao Qi: 【Calma, hospedeira... Que tal o seguinte? Na próxima reunião, vou tentar levar suas reclamações aos meus superiores e então... Hein?】

Ning Xiaoxiao: 【E então o quê? Desembucha!】

Xiao Qi: 【Bip, bip, bip! Parabéns, hospedeira! Você completou a missão «Vestir o tirano com o novo dudou». O índice de desvio da trama aumentou cinco pontos percentuais e agora soma 50%! Parabéns, você ganhou uma rodada na grande roleta de prêmios!】

Ning Xiaoxiao voltou lentamente o olhar para a direção do quarto e estremeceu.

【??? Até cavalo e mula estão entrando na dança! Que porra de absurdo é esse?!】

Enxugou-se rapidamente, vestiu a roupa de dormir e correu para o quarto para descobrir o que acontecera.

No instante em que abriu a porta, ficou petrificada.

Aquele dudou de centro vazado e bordas de nuvens estava esticado até o limite no corpo de Lu Linyuan...

Ele tinha ombros largos, cintura estreita e músculos peitorais bem definidos, que ameaçavam fazer a peça explodir.

— Majestade, você...

Com o rosto vermelho, Lu Linyuan respondeu, visivelmente envergonhado:

— Você não queria me ver vestindo isto? Então... achou bonito?

Mal terminou de falar, ouviu-se um «crac!». O dudou se rompeu no meio. Os pedaços que continuaram pendurados nele, somados à sua expressão ressentida, faziam-no parecer um pobre homem que cometera um erro do qual se arrependeria para sempre...

Ele pensou que, agora que a peça se rasgara, a missão dela certamente estaria concluída.

Por isso, apressou-se em arrancar do corpo os trapos restantes. Estava tão ridículo que parecia um palhaço.

Imaginou que Ning Xiaoxiao cairia na gargalhada e aproveitaria para debochar dele.

Mas, enquanto ainda tirava os pedaços de tecido, ela se aproximou e o abraçou de surpresa.

— Seu bobo...

Sua voz saiu fraquinha, embargada pelo choro.

Bastara que ela dissesse que queria vê-lo assim para ele deixar de lado até a dignidade de que os homens tanto se orgulhavam?

Era algo que muitos homens comuns jamais fariam; no entanto, Lu Linyuan, um imperador, fizera sem sequer hesitar.

Aquilo era engraçado?

Nem um pouco.

Ela só conseguia se perguntar, em silêncio, como poderia merecer um amor tão incondicional.

Quando ela começou a chorar, Lu Linyuan ficou desnorteado.

— Está tudo bem. Por que está chorando?

Acariciou seus cabelos macios e disse em voz baixa e gentil: — Nossa Xiaoxiao merece todas as coisas mais bonitas deste mundo.

Ning Xiaoxiao ficou sem palavras. Era como se Lu Linyuan pudesse enxergar suas dúvidas: ele sempre respondia precisamente às perguntas que ela fazia a si mesma e lhe dava respostas tão firmes que a tranquilizavam.

Fazia com que ela se sentisse escolhida, sem hesitação, todos os dias.

Enxugou as lágrimas e olhou para Lu Linyuan com ar choroso. — Você me fez chorar de susto... Majestade, não vista isso nunca mais. Foi assustador demais, buáá...

Lu Linyuan não sabia se ria ou chorava.

«Nunca mais»? Não haveria próxima vez. Aquela única experiência já o deixara tão envergonhado que parecia querer cavar um buraco com os dedos dos pés.

Ele roçou um dedo na ponta do nariz avermelhado de Ning Xiaoxiao e a repreendeu de leve: — Faz tanto tempo que deixei de me chamar de «este imperador» quando falo com você, mas você ainda insiste em me chamar de Majestade?

— De agora em diante, não me chame assim. Use meu nome de infância. Quando o imperador anterior era vivo, me chamava de A-Yuan. Depois que ele partiu, ninguém mais me chamou dessa maneira.

Contemplou Ning Xiaoxiao com um olhar cheio de expectativa e sinceridade:

— E só vou permitir que você me chame assim.

Numa história romântica normal, Ning Xiaoxiao ficaria corada, diria «A-Yuan» e os dois passariam um bom tempo se agarrando sem o menor pudor.

Mas Ning Xiaoxiao era praticamente imune ao romantismo e tinha ideias que não ocorriam às pessoas normais.

Refletiu cuidadosamente e declarou, com toda a seriedade:

— Mas se o imperador anterior chamava você assim e eu também chamar, não fica meio inadequado?

— Arredondando as contas... isso não faz de mim seu pai?

Lu Linyuan: — ................

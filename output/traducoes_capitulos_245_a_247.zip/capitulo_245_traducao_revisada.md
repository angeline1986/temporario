# Capítulo 245 — Nova missão: vestir o tirano com um dudou novo

Na manhã seguinte, Lu Linyuan e Ning Xiaoxiao decidiram ir à cidade de Xifeng.

Como pretendiam comprar artigos um tanto picantes, não seria conveniente levar os criados do palácio. A presença deles poderia atrapalhar o desempenho de Lu Linyuan.

Felizmente, Xifeng não ficava longe da propriedade das águas termais. Assim, Lu Linyuan montou a cavalo e levou Ning Xiaoxiao consigo.

Quando chegaram à entrada da propriedade, encontraram Lu Yiqiu saindo do Pavilhão Xiaoyao.

De longe, ele cumprimentou Lu Linyuan: — Hi, mano! Aonde vai levar minha cunhada tão cedinho?

Lu Linyuan nem precisou vê-lo: bastou ouvir sua voz para chicotear o cavalo e disparar, sumindo de seu campo de visão.

A aceleração repentina assustou Ning Xiaoxiao, que instintivamente se agarrou à cintura dele.

— Seu irmão chamou você. Por que saiu correndo?

— Se eu não corresse, ele ia insistir até conseguir vir conosco. Fala pelos cotovelos, e tenho medo de não resistir à vontade de lhe dar uma surra.

Esse era um motivo. O outro era que as «coisinhas boas» que compraria para a esposa não eram coisa para outro homem ficar olhando!

Com a aproximação das festividades de Ano-Novo, Xifeng estava especialmente movimentada.

Os visitantes iam e vinham sem parar. Diante da loja mais famosa de dudou, havia uma fila interminável. Mulheres das aldeias vizinhas tinham vindo de propósito para comprar ali, prova do sucesso do estabelecimento.

Os produtos daquela loja não eram baratos: até a peça mais simples custava mais de dez taéis de prata.

Uma pessoa comum podia trabalhar duro o ano inteiro sem ganhar sequer dez taéis.

Portanto, quem comprava ali eram pessoas de famílias abastadas.

Bastava observar as mulheres enfeitadas com ouro e jade para entender sua posição social.

A dinastia Qi, como muitos reinos da Antiguidade, não era exatamente liberal em seus costumes.

A maioria das mulheres comprava esses dudou para agradar aos maridos em casa.

Homens ricos e poderosos costumavam ter várias esposas e concubinas; para manter o interesse do marido, elas precisavam lançar mão de todos os recursos.

Por isso, entre todas as pessoas da fila, Ning Xiaoxiao era a única acompanhada por um homem: Lu Linyuan.

Mal chegaram, ouviram os cochichos ao redor.

Algumas, vendo a beleza de Ning Xiaoxiao, insinuaram que Lu Linyuan traía a esposa e estava tentando agradar alguma mulher da vida, dessas que trabalhavam em bordéis.

Outras comentaram que um homem crescido como ele devia ter vergonha de entrar numa loja de roupas íntimas femininas.

Por sorte, Lu Linyuan estava de ótimo humor naquele dia. Ouviu os comentários e não se incomodou.

Em vez disso, ergueu o queixo de Ning Xiaoxiao e aproveitou para provocá-la:

— Elas estão falando bobagens. Minha esposa é ainda mais bonita que a cortesã mais bela de todas.

Falou sem baixar a voz, como se quisesse ser ouvido por aquelas mulheres.

Depois, ignorando os mexericos, pegou a mão de Ning Xiaoxiao e foi direto para a loja, sem entrar na fila.

— Ei, ei! O que pensa que está fazendo? Não está vendo todo mundo na fila?

— Isso mesmo! Estou aqui desde a quinta vigília e só agora cheguei perto da porta! Se quer comprar, vá para o fim da fila!

Com o tumulto, a proprietária saiu para ver o que estava acontecendo.

Era uma mulher aparentemente na casa dos trinta, muito bem conservada, de curvas marcantes.

Cada gesto dela exalava charme. — Ora, ora! O rapaz veio comprar umas coisinhas especiais com a sua amada!

Ao notar como Lu Linyuan era bonito, ergueu a mão para lhe dar um tapinha no peito.

Ele já se preparava para se esquivar, mas Ning Xiaoxiao agiu antes.

Afastou a mão da proprietária com um tapa e reclamou, feroz à sua maneira adoravelmente infantil:

— Pode falar sem ficar passando a mão!

Lu Linyuan baixou os olhos para ela e não conteve o sorriso.

Constrangida, a proprietária disfarçou com outro sorriso. — Pela roupa de vocês, vejo que são clientes importantes. Mas nesta loja há uma regra: por mais dinheiro que tenham, todos devem ir para o fim da fila.

Apontou para a fileira que parecia não ter fim. — Por favor.

Lu Linyuan sorriu com malícia e tirou uma nota bancária de prata de dentro da roupa, oferecendo-a à mulher.

Ela não aceitou e manteve a pose altiva:

— Como eu disse, não se trata de dinheiro. Mesmo que vocês tenham... Hã?

No meio da frase, ela percebeu de relance o valor escrito na nota e quase morreu de susto ali mesmo.

Era uma quantia tão grande que ela nem ousaria sonhar com aquilo em toda a vida.

Mudou imediatamente de expressão e abriu um sorriso servil. — Ora, entrem, entrem, por favor! Quanto às senhoras da fila, podem voltar para casa. Hoje a loja atenderá apenas estes dois distintos clientes!

As mulheres que aguardavam havia horas ficaram furiosas e começaram a praguejar; a multidão entrou em alvoroço.

A proprietária fez ouvidos moucos e conduziu o casal para dentro com toda a solicitude, mandando os ajudantes acalmar as pessoas do lado de fora.

Ning Xiaoxiao ficou boquiaberta diante da variedade deslumbrante de dudou. Nunca imaginara que os antigos fossem capazes de tanta ousadia.

Lu Linyuan também teve a impressão de descobrir um mundo novo. Só que Xiaoxiao tinha um corpo extraordinário: não era qualquer paninho mundano que conseguiria acomodar aqueles seios generosos.

A proprietária se desdobrou em explicações, mas nenhuma das peças que mostrava agradou a Lu Linyuan.

De vez em quando ele ainda se inclinava para cochichar com Ning Xiaoxiao, discutindo coisas que só poderiam ser ouvidas por maiores de idade com acesso VIP.

Por fim, sem mais alternativas, a proprietária disse: — Quase sempre são as próprias mulheres que vêm escolher seus dudou. É a primeira vez que recebo um marido acompanhando a esposa. Pelo amor que demonstram, vou mostrar uma preciosidade que guardo a sete chaves!

Abriu um compartimento oculto no armário central e retirou um dudou novinho.

Era uma peça com a parte central vazada e bordas decoradas com desenhos de nuvens.

«Parte central vazada» significava que, tirando os pequenos pontos que deveriam ficar cobertos, o restante era confeccionado com seda em forma de rede. Em outras palavras...

Como uma montanha envolta em névoa, deixando entrever o tesouro escondido?

Os olhos de Lu Linyuan se arregalaram. Decidiu na mesma hora: — É este!

A proprietária ficou radiante enquanto embrulhava a peça. — O senhor tem um gosto refinadíssimo! Paguei dez taéis de ouro por ela. É a única do mundo, uma raridade que não se encontra duas vezes!

Entregou-lhe o embrulho e os acompanhou até a porta. — Voltem sempre que tiverem oportunidade, distintos clientes!

Quando ela ia abrir a porta, Ning Xiaoxiao arrancou de sua mão a nota entregue por Lu Linyuan. Em seguida, enfiou a mão no peito da roupa dele, tirou um punhado de notas e escolheu outra com cuidado.

O valor dessa era dezenas de vezes menor que o da primeira: equivalia a apenas doze taéis de ouro.

A proprietária se desesperou. — Ei! Menina, o que está fazendo?

— Você disse que pagou dez taéis de ouro. Receber doze já lhe dá lucro.

A mulher ficou verde de raiva. Lu Linyuan, por sua vez, olhou para Ning Xiaoxiao com admiração. — Ora, ora! Nossa Xiaoxiao sabe mesmo administrar a casa com economia.

Contendo o riso, ela aproveitou para enfiar a nota recuperada na própria bolsa.

Lu Linyuan: — ??? Você...

— Pronto, bonzinho... — Ning Xiaoxiao afagou a cabeça dele, alisando seus cabelos como quem acalma um bichinho. — Quando o dinheiro velho vai embora, o novo vem chegando!

Mal terminou de falar, a voz de Xiao Qi ressoou em sua mente:

【Bip, bip, bip! Hospedeira, chegou um novo pedido de missão!】

【Vista o tirano com o novo dudou. Se completar a missão, o índice de desvio da trama aumentará cinco pontos percentuais; se fracassar, sua vitalidade será reduzida em 20%. Conclua a missão em até vinte e quatro horas!】

— ...

# Capítulo 247 — Desde que seja você, eu gosto de tudo

Eu a trato como minha esposa e você quer ser meu pai?

Lu Linyuan encarou Ning Xiaoxiao por um bom tempo com um olhar de quem questionava toda a própria existência. Por fim, repetiu uma das expressões favoritas dela, num tom soturno:

— Você acha isso educado?

Ning Xiaoxiao riu. — Está bem, está bem, chega de brincadeira. A... A-Yuan?

Pronunciar aquele nome fez Ning Xiaoxiao, especialista em fugir de sentimentalismos, ficar toda arrepiada.

Mas Lu Linyuan, aquele verdadeiro rei da galanteação melosa dos dramas de época, adorou ouvir aquilo e ergueu as sobrancelhas com satisfação:

— Agora sim.

O dudou que seus músculos haviam arrebentado continuava jogado no chão. Ele se abaixou para pegá-lo e jogá-lo fora, mas Ning Xiaoxiao sentiu certa pena:

— Ah... Afinal, gastamos uma fortuna nele...

Espiou Lu Linyuan, que tentara levar vantagem e acabara no prejuízo, e o provocou com uma voz deliberadamente atrevida:

— E você nem chegou a me ver usá-lo, e já estragou tudo. Que desperdício...

Lu Linyuan arqueou a sobrancelha. — E como pretende compensar isso?

— Da próxima vez, está bem? Quando surgir outra oportunidade... prometo que vou vestir um para você ver!

Falou com firmeza, piscando seus inocentes olhos de corça na direção dele, como se lamentasse sinceramente não ter conseguido usar aquela peça.

Lu Linyuan estendeu o mindinho. — Promessa de mindinho. Nada de voltar atrás.

Era um gesto que Ning Xiaoxiao o obrigara a fazer tempos antes. No início, ele desprezara a brincadeira, chamando-a de infantil.

Mas, depois de aprender, vivia querendo entrelaçar o mindinho com o de sua esposinha.

Ning Xiaoxiao entrelaçou naturalmente o dedo ao dele. — Promessa de mindinho, quem quebrar não vale por cem anos!

Ia retirar a mão, mas Lu Linyuan continuou prendendo seu dedo com força, sem a menor intenção de soltá-la.

— E se você quebrar a promessa?

— Aí pode decidir o castigo que quiser!

— Ótimo. — Ele a puxou para perto pelo dedo entrelaçado e murmurou, escondendo um sorriso malicioso:

— Se voltar atrás, farei você chorar.

Depois, lançou um olhar para a cama macia. — Na cama.

Ning Xiaoxiao: — ???

Ela vacilou por um segundo, mas logo retrucou: — Ah, é? Ainda vamos ver quem vai acabar chorando!

Lu Linyuan não tentou vencer a discussão. Soltou-a com um sorriso provocador, inclinou-se e tirou de debaixo do travesseiro um tecido de um vermelho vivo.

Quando o jogou nas mãos de Ning Xiaoxiao, ela finalmente viu que era um dudou novinho, confeccionado em rede vazada com o desenho de peixes brincando entre peônias.

...

O clima ficou constrangedor num instante.

— Espere... Você passou o dia inteiro comigo. De onde tirou isto?

Lu Linyuan fechou a janela treliçada ao lado e a trancou:

— Dias atrás, quando a princesa mais velha e Huanü foram a Xifeng, viram essa peça. Ela tem olhos afiados: antes mesmo de conhecer aquela preciosidade que compramos hoje, percebeu que esta aqui teria exatamente o tamanho necessário para cobrir você.

— Por isso comprou e me deu em segredo.

Enquanto falava, também trancou a porta do quarto e guardou a chave presa à cintura.

As chamas das velas tremulavam, fazendo a luz amarelada dançar pelo rosto dele.

Naquelas circunstâncias, até o leve sorriso que se formava em seus lábios parecia indecente.

— Fizemos uma promessa de mindinho. Você não pode voltar atrás.

Ning Xiaoxiao gaguejou: — É que... Estou com sono. Que tal amanhã?

Lu Linyuan não respondeu.

Aproximou-se passo a passo até encurralá-la junto à parede e roçar o rosto no dela, sussurrando:

— Vai vestir ou vai chorar?

— Calma, calma! Vou vestir! Eu visto! Não precisa se exaltar!

Então mandou Lu Linyuan virar de costas e começou a trocar de roupa, fingindo timidez.

Na verdade, se quisesse escapar, sua cabecinha cheia de truques encontraria dez mil e oitenta e seis maneiras diferentes.

Afinal, seus poderes especiais não estavam ali só de enfeite.

Portanto, o fato de ela se fazer de difícil naquele momento só podia significar uma coisa.

Ela também queria vestir aquela peça.

Queria mostrá-la ao homem que amava.

O modelo do dudou era excelente e fazia seus seios generosos parecerem ainda mais volumosos.

Ning Xiaoxiao virou o rosto, um pouco envergonhada. Imaginava que Lu Linyuan avançaria mais, mas ele apenas olhou, assentiu com satisfação e uma pitada de malícia e disse: — Minha esposa é linda.

Em seguida, pegou sua roupa de dormir e a colocou sobre os ombros dela. — Mas sua menstruação ainda não terminou. Vista isto para não passar frio.

Ning Xiaoxiao ficou surpresa e achou estranho.

Ela só mencionara que estava menstruada no primeiro dia de sua visita à propriedade das águas termais. Depois, não voltara a falar sobre o assunto.

Como ele sabia que ainda não havia terminado?

— Nem eu contei há quantos dias estou menstruada. Como você sabe?

— Você não tem juízo, mas eu tenho. — Lu Linyuan passou o braço pelos ombros delicados dela e se sentou ao seu lado na beira da cama. — Existe uma coisa chamada matemática. Perguntei ao médico imperial que a acompanha quantos dias seu período costuma durar e fiz uma estimativa.

Virou-se para ela, sorrindo, e apertou seus lábios duas vezes, como se estivesse brincando com o bico de um pato:

— Ou por que você acha que os bolinhos de arroz glutinoso com fermentado doce que Qiqi preparou ontem à noite não tinham gosto de álcool e estavam mais doces, com bastante açúcar mascavo?

— Você não gosta do chá de gengibre com açúcar mascavo que preparo, e joga fora às escondidas os remédios enviados pelo Instituto Médico Imperial. Acha que não sei?

Então apontou para um vaso de planta perto da porta do quarto. — Se tivesse dois neurônios, talvez os usasse. Da próxima vez que jogar o remédio fora, escolha outro vaso de vez em quando, em vez de envenenar sempre o mesmo. Olhe só como as folhas estão murchas!

Todo amor bonito se revela nos menores detalhes.

Não há como escondê-lo: como o ar, ele nos envolve a cada instante.

Os olhos de Ning Xiaoxiao, que acabara de chorar, tornaram a ficar cobertos por uma fina camada de lágrimas.

Quando viu que ela estava prestes a chorar outra vez, Lu Linyuan começou a fazer cócegas em sua cintura, obrigando-a a cair na risada.

— Chorar, chorar, só sabe chorar! Quando eu a repreendo ou brigo com você, não chora. Basta demonstrar um pouquinho de carinho para começar a derramar lágrimas sem parar.

— Se é assim, a partir de amanhã vou insultá-la toda vez que a vir. Parece que só desse jeito você fica satisfeita!

Ela riu, fechou os olhos e esfregou as pálpebras ardidas. Depois se virou e apoiou a cabeça no ombro de Lu Linyuan.

— A-Yuan, às vezes há algo que não consigo entender.

— Eu não tenho nada de especial. Sou desleixada, não sigo regras, não entendo muito de literatura nem sou boa em artes marciais. E ainda falo palavrões a toda hora. Se for para mencionar uma qualidade, talvez a única seja ser um pouco bonita?

— Mas o palácio está cheio de mulheres lindas. Veja Sijin, por exemplo: ela é muito mais bonita que eu. Por isso, às vezes me sinto insegura.

— Não sei como alguém com tantos defeitos como eu pode merecer seu amor.

Ela, que normalmente fugia de sentimentalismos, finalmente tentava ter seu momento melancólico. Mas Lu Linyuan conseguiu desviá-lo para outro rumo:

— Seus defeitos não param por aí. Às vezes você range os dentes dormindo, igualzinha a um ratinho.

Ning Xiaoxiao detestava ratos mais do que tudo. — Mentira! Ratos são sujos e nojentos! Como pode comparar uma pessoa a isso?

Lu Linyuan não discutiu. Apenas sorriu com ternura, apoiou o queixo na testa dela e a roçou de leve:

— Mas você é você. A única você que existe neste mundo.

— Desde que seja você, não importa se é gato ou rato, eu gosto de tudo.

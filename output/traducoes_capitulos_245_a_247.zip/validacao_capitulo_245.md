# Validação editorial e estrutural — capítulo 245

- **Fonte:** `novel_capitulos_212_a_270(20261105-204934).docx` (chinês tradicional), índices reais dos parágrafos da biblioteca python-docx, base zero.
- **Intervalo bruto DOCX:** 2309–2384 (o próximo capítulo começa em 2385).
- **Unidades não vazias:** 73 (inclui o título, sem notas de autora quando não presentes no trecho).
- **Índices no cotejo:** 2309–2383, preservando saltos correspondentes a parágrafos vazios.
- **Cobertura:** 73 originais não vazios / 73 traduções não vazias; associação 1:1.
- **Integridade:** não há índices duplicados, campos de tradução vazios nem unidades não vazias do intervalo sem linha no CSV.
- **Markdown:** tradução organizada na mesma ordem do cotejo, com o título na primeira linha.

## Decisões e pontos de atenção

- 杜都: mantido como dudou, peça tradicional de roupa íntima chinesa, aqui em versões elaboradas e sensuais.
- 瑟瑟: expressão eufemística de teor erótico; traduzida pelo efeito como “artigos um tanto picantes”.
- 五更天: quinta vigília, no período anterior ao amanhecer.
- 兜得住D: jogo com a letra D e o busto; adaptado pelo sentido, sem inventar etimologia.
- 山霧朦朧，寶現其中: metáfora de nuvem/névoa e tesouro semioculto, preservada.
- Recompensa de 5% expressa como acréscimo de cinco pontos percentuais, não como valor acumulado.

## Escopo da validação

A inspeção feita confirma a cobertura de unidades, a existência dos arquivos, a ordem e a legibilidade estrutural. A tradução foi produzida com leitura e interpretação do original, mas **não foi realizada uma segunda auditoria semântica integral e independente**. Pontos idiomáticos sinalizados acima podem merecer nova revisão.

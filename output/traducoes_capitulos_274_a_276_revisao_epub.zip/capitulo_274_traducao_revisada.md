# Capítulo 274 — Mas A-Yuan disse que posso desobedecer a um decreto imperial

A mão do homem pousou sobre seu ombro, e a palma ardia de calor...

Ele fitou Ning Xiaoxiao com um olhar diferente da ternura habitual, tomado por uma agressividade inquietante.

Ning Xiaoxiao nunca tinha visto Lu Linyuan assim antes.

Ela sabia que, por mais cauteloso que seu A-Yuan tivesse sido, ainda acabara atingido pela armadilha da Concubina Tong.

O diretor Song da Academia Médica Imperial dissera que o efeito daquela substância era violento: bastava o menor contato para que a pessoa se visse dominada por seus efeitos.

Diante de seu estado, não era difícil imaginar como ele estava sofrendo.

Ela se virou lentamente para encará-lo...

Seus olhos estavam tão injetados de sangue que as pupilas pareciam envoltas num vermelho escarlate.

Ele ainda suportava a dor, rangendo os dentes, com as têmporas latejando e as veias do pescoço saltando, estendendo-se para cima e para baixo como trepadeiras...

Naquele estado, Lu Linyuan emanava uma ferocidade capaz de devastar tudo, semelhante a um asura sangrento que tivesse emergido do inferno...

No entanto, Ning Xiaoxiao não estava com medo nenhum.

Afinal, ele era o homem que amava. Como poderia ter medo dele?

Ela encarou aqueles olhos vermelhos e trêmulos sem recuar; em seu rosto havia apenas uma profunda preocupação por ele.

— A-Yuan... Eu...

Ela mal começara a dizer alguma coisa quando...

........

Ning Xiaoxiao recuou passo a passo até ficar pressionada contra a borda da banheira, sem ter para onde ir.

Ela não pretendia recorrer a nenhuma das vantagens especiais do sistema, tampouco fugir da chegada daquele dia.

Ela amava A-Yuan com o mesmo sentimento sincero e ardente com que ele a amava.

Seus braços macios enlaçaram o pescoço dele, e suas mãos acariciaram delicadamente as saliências de sua coluna.

O pouco de lucidez que restava a Lu Linyuan estava sendo consumido; naquele momento, seus sentidos reagiam intensamente a qualquer estímulo.

Ele estremeceu, e o longo beijo terminou abruptamente...

Lu Linyuan a soltou de repente e mergulhou a cabeça inteira na banheira, deixando a água cobri-lo.

Prendeu a respiração e sacudiu a cabeça, tentando a todo custo recuperar a lucidez.

Assustada, Ning Xiaoxiao agarrou a gola dele e tentou puxá-lo para fora da água:

— A-Yuan, o que está fazendo?!

Nem ela soube de onde veio tanta força, mas conseguiu arrancar aquele touro teimoso de dentro da banheira.

— A-Yuan, você...

— SAIA!!

Ele a empurrou, mas conteve cuidadosamente a força, fazendo-a apenas cambalear para trás.

— A-Yuan...

Ela tentou avançar ansiosamente para ver como ele estava, mas ele rosnou para ela com uma voz rouca:

— EU MANDEI VOCÊ SAIR!!

Cada palavra saiu de sua boca separadamente, carregada de uma ferocidade assustadora.

Ele nunca havia gritado com Ning Xiaoxiao daquela forma antes. Ela ficou atônita e parada ali, meio sem saber o que fazer.

*Splash!*

Lu Linyuan apanhou a veste de gaze pendurada no Biombo dos Nove Dragões e a lançou com precisão sobre Ning Xiaoxiao, cobrindo-lhe a pele alva.

Quando o olhar dela encontrou a ternura aflita nos olhos dele, Ning Xiaoxiao enfim compreendeu.

Ela tirou a veste, amarrotou-a e a jogou no chão. Então voltou a caminhar teimosamente na direção de Lu Linyuan.

A cada passo, ele ficava mais agitado. — Minhas palavras são decretos imperiais! Se der mais um passo, estará...

Antes que ele terminasse, Ning Xiaoxiao encostou o indicador delicado em seus lábios.

Ela não temia aquela ferocidade que ele fingia exibir. Seus olhos irradiavam uma ternura cálida quando disse, com toda a seriedade:

— Mas A-Yuan me disse que, diante de você, eu sempre poderia desobedecer a um decreto imperial.

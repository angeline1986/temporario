# Capítulo 275 — O casal “Yuanxiao”

A noite avançava, e o silêncio ficava cada vez mais profundo, quase assustador.

Lu Linyuan conseguia até mesmo ouvir claramente as batidas do seu próprio coração, que estavam descompassadas.

A água na banheira ainda conservava um pouco de calor, emitindo um vapor fino que pairava ao redor deles.

Ning Xiaoxiao estava diante dele e, entre as névoas de vapor, parecia tão bela quanto uma criatura celestial.

Ela entreabriu os lábios vermelhos. — Você sempre pensou que, enquanto não me desse o posto de imperatriz, não deveria me tocar. Mas agora quero lhe fazer uma pergunta. Responda sinceramente.

Fez uma breve pausa e ergueu a voz. — Mais cedo ou mais tarde, o posto de imperatriz será meu, não será?

Lu Linyuan cerrou os dentes. — Ning Xiaoxiao! Não pode me obedecer ao menos desta vez?

— Não! — retrucou ela, feroz como uma gatinha tentando mostrar as garras. — Só precisa responder sim ou não. Nada de conversa fiada!

A cena diante dos olhos de Lu Linyuan começou a se distorcer e ficar embaçada.

Sua mente tornou-se cada vez mais confusa, e nem ele mesmo sabia em que tipo de força de vontade terrível havia se apoiado para se manter firme até então.

Ele praticamente arrancou um “sim” do fundo da garganta, entre os dentes cerrados, para responder à insistência de Ning Xiaoxiao.

— Você acha que só estará fazendo justiça a mim quando eu me tornar imperatriz? — perguntou ela novamente.

Lu Linyuan assentiu pesadamente.

— Ah! — Ning Xiaoxiao soltou uma risadinha de desdém. — Então quer dizer que, a cada dia em que eu ainda não sou imperatriz, você está sendo injusto comigo?

Em um momento como este, como Lu Linyuan poderia ter energia para discutir com ela sobre essas coisas?

Ning Xiaoxiao estreitou ligeiramente os olhos brilhantes, um lampejo de astúcia predatória reluzindo neles:

— Se está sendo injusto comigo há tanto tempo, não acha que precisa me compensar?

— Eu sei. Vou compensá-la, prometo. — Lu Linyuan esgotou seu último resquício de lucidez ao responder. Em seguida, apanhou a veste de gaze, cobriu-a e agarrou seu braço, tentando conduzi-la para fora.

Ning Xiaoxiao se desvencilhou da mão dele e protestou, indignada:

— Não quero saber de depois! Sou impaciente e gosto de resolver hoje os assuntos de hoje.

— Quero agora, neste instante, imediatamente! Quero que você me compense agora!

Então segurou a mão dele com delicadeza e pronunciou cada palavra com firmeza:

— Agora. Compense-me agora.

❤

Naquela noite, Lu Linyuan e Ning Xiaoxiao só foram dormir muito tarde.

Tudo o que tinha de acontecer aconteceu naturalmente.

Outro efeito daquela substância afrodisíaca era provocar uma exaustão extrema depois da relação.

Sem conseguir controlar o próprio corpo, Lu Linyuan caiu imediatamente num sono profundo.

Antes de adormecer, ele ainda lutou para manter os olhos abertos e trocou algumas palavras com Ning Xiaoxiao.

Mas, enquanto falava, de repente ficou em silêncio.

A respiração dele foi ficando mais profunda. Aninhada em seus braços, Ning Xiaoxiao escutou o coração forte do amado e sentiu o calor de seu corpo.

Ela tinha a sensação de estar sonhando; tudo parecia irreal.

De repente, a voz de Xiao Qi surgiu em sua mente:

【Parabéns, anfitriã! Finalmente os apaixonados se uniram!】

Ning Xiaoxiao corou. 【Como você sabe? Não me diga que...】

Xiao Qi: 【Que ideias são essas, anfitriã?! Sou um sistema respeitável! Não falei que, sempre que você e o tirano ficassem juntos, eu seria trancado numa salinha escura?】

【Eu estava dormindo tranquilamente quando fui jogado lá dentro de repente! Até interromperam meu lindo sonho!】

Ning Xiaoxiao: 【... Não invente coisas! Eu e ele não fizemos nada...】

【Eu sei, eu sei~】 Xiao Qi a interrompeu, brincalhão. 【Você só estava salvando uma vida, não é? Hehehe~】

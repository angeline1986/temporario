# Capítulo 276 — A maior prova de amor é inscrever seu nome na história

No dia seguinte.

Ao amanhecer, os primeiros raios cálidos de sol atravessaram as frestas da janela e iluminaram os cabelos negros e soltos de Ning Xiaoxiao.

Lu Linyuan estava deitado de lado, com o olhar penetrante fixo nela.

Ele pegou uma mecha do cabelo dela e brincou com ela entre os dedos.

De vez em quando, ele levava aquela mecha até o nariz e inspirava profundamente seu perfume particular.

Um sorriso possessivo surgiu em seus lábios enquanto ele murmurava para si mesmo:

— Minha.

— Só minha.

Sua Xiaoxiao finalmente se tornou completamente sua Xiaoxiao.

Ning Xiaoxiao sentiu uma leve coceira no queixo. Ela tinha ido dormir muito tarde na noite anterior e estava com tanto sono que não conseguia manter os olhos abertos.

Ela só ergueu as pálpebras quando a sensação úmida envolveu seus lábios.

A primeira coisa que ela viu foi o rosto belíssimo de Lu Linyuan, tão perto do seu que parecia desfocado.

Aquele beijo breve e reconfortante contrastava nitidamente com a intensidade arrebatadora da noite anterior.

— Acordou?

Ning Xiaoxiao assentiu de leve. Talvez porque a escuridão da noite os impedisse de enxergar um ao outro com clareza, os dois haviam perdido a timidez e se entregado sem reservas.

Agora que estava claro lá fora, ela podia ver claramente o sorriso travesso nos lábios de Lu Linyuan e, em vez disso, sentiu-se tímida.

Corada, ela baixou os olhos e respondeu com um tímido “hum”.

A voz rouca foi como um anzol, provocando um arrepio de desejo no coração de Lu Linyuan.

Ele se encostou na cabeceira da cama, com uma mão em volta do ombro dela, acariciando suavemente sua clavícula, enquanto a outra alcançava a mesinha ao lado da cama, pegava a chaleira, enchia uma xícara com água morna e a entregava a ela.

"Beba um pouco de água para aliviar a garganta."

Ning Xiaoxiao sentiu a boca seca e a garganta ardendo como se tivesse sido polvilhada com pimenta em pó.

Ela tomou toda a água de um gole. O indicador dele deslizou com ternura pela garganta da jovem, em meio a carinho e preocupação.

"A culpa é toda minha."

Ao se lembrar dos excessos dele na noite anterior, comparáveis a uma explosão de fogos de artifício, Ning Xiaoxiao se irritou de novo.

Revirou os olhos e lhe devolveu a xícara. — Então sabe que a culpa é sua?

Lu Linyuan sorriu, cheio de carinho. — Não fique brava, meu amor. Hoje prometo me conter.

"???"

【Hoje também?! Está sonhando acordado! Eu pedi duas vezes e você ainda insistiu numa terceira! Se quiser mais, pode tirar o cavalinho da chuva!】

O sol subia cada vez mais alto, e a luz solar tornava-se cada vez mais ofuscante, deixando Ning Xiaoxiao um pouco tonta.

Ela estreitou os olhos e, ao se lembrar de algo, espiou rapidamente a clepsidra de bronze. Quase soltou um palavrão:

— Já estamos na hora *chen*! Por que ainda está deitado? Não vai à audiência da manhã?

Ela dormia do lado da cama junto à parede. Passou por cima de Lu Linyuan para apanhar depressa as vestes oficiais que ele usaria na audiência.

Mas, assim que passou uma perna por cima dele, Lu Linyuan a puxou de volta.

Ning Xiaoxiao perdeu o equilíbrio e caiu pesadamente sobre ele. Seus cabelos recém-lavados exalavam um leve aroma de gardênias, que invadiu as narinas de Lu Linyuan enquanto o ar girava ao seu redor.

Ele inspirou profundamente, insaciável. — Hoje não haverá audiência.

Ning Xiaoxiao estava com preguiça de se levantar, então simplesmente se esparramou em cima dele, apoiando os cotovelos em seus músculos peitorais finos e salientes, sustentando o queixo com a mão e olhando para ele com curiosidade.

"Por que?"

— Avisei aos ministros que hoje será dia de descanso.

Em termos simples, *xiumu* significava um dia de folga.

As leis da dinastia Qi eram rigorosas, e Lu Linyuan era conhecido por sua dedicação ao governo.

Exceto pelos dois dias de repouso depois da peste que quase o matou, ele trabalhava praticamente o ano inteiro sem parar.

Não era raro que passasse a noite examinando memoriais e, depois de lavar o rosto ao amanhecer, seguisse direto para a audiência da corte.

Por que, justamente hoje, depois de dormir apenas um pouco mais, ele havia dispensado a audiência?

Após muita reflexão, parece haver apenas uma explicação razoável para isso:

【Então... será que ele ficou sem forças?】

Lu Linyuan: “...”

Ele esfregou vigorosamente a ponta do nariz de Ning Xiaoxiao. — Seus olhinhos não param de se mexer. Que besteira está inventando sobre mim desta vez?

— Não é isso... Se faltar à audiência sem motivo, os historiadores vão registrar tudo. Ontem à noite eu estava com você no Palácio Chaoyang. Eles podem enfeitar a história e me retratar como uma sedutora que arruinou o reino!

— Hum, e não é? — Ele provocou, antes de sorrir. — Quero justamente que registrem tudo, para que o mundo saiba como o dia de ontem foi especial para mim.

— E não é só uma folga de hoje. Também promulguei um decreto: todos os imperadores da dinastia Qi que vierem depois de mim deverão suspender a audiência neste mesmo dia, todos os anos. Haverá benefícios distribuídos por todo o reino e clemência para prisioneiros condenados, para que a data seja celebrada por todos.

Ning Xiaoxiao ficou atônita ao ouvir essas palavras.

Quando lia romances, os presidentes milionários no máximo compravam diamantes de centenas de milhões para suas heroínas ou adquiriam sete ou oito mansões interligadas para que elas pudessem jogar futebol dentro de casa...

Mas aquele homem conseguira superar todos: queria registrar a intimidade dos dois diretamente nos livros de história?!

Será que havia alguma coisa muito errada com a cabeça dele?!

Pensando bem, porém, era uma loucura doce até demais.

Uma criada do palácio anunciou do lado de fora da porta que o café da manhã estava pronto. A barriguinha da pequena glutona roncou. Lu Linyuan deu uma risadinha, levantou-se e a pegou no colo.

— O que está fazendo? — perguntou Ning Xiaoxiao.

— Levando minha esposa para tomar café da manhã.

Com tantos criados do palácio do lado de fora, Ning Xiaoxiao ficou com medo de passar vergonha, então o empurrou:

"Me ponha no chão, eu consigo andar sozinha."

— Não vai conseguir. — Lu Linyuan roçou o nariz na testa dela. — Tenho medo de que suas pernas estejam bambas, você caia e acabe partindo meu coração.

“......”

O café da manhã incluía o mingau de frutos do mar de que Ning Xiaoxiao mais gostava.

A tigela vinha cheia de ingredientes, uma porção generosa que era pura felicidade.

Ela comia com a maior concentração, enquanto Lu Linyuan passava o tempo inteiro contemplando-a com um sorriso completamente apaixonado.

— Como hoje estamos de folga, que tal brincar comigo depois de comer?

"???"

Ning Xiaoxiao quase morreu engasgada com o mingau. — B-brincar de quê?

【Será que ele cancelou a audiência da manhã de propósito para tentar mais uma vez?!】

Lu Linyuan não havia pensado nisso. Queria apenas jogar algumas partidas de **gomoku**, o jogo de cinco pedras em linha, com sua Xiaoxiao.

Mas os pensamentos de Ning Xiaoxiao lhe deram uma ideia:

Hum... Pensando bem, não era uma má ideia.

Ele estendeu a mão e limpou o mingau do canto dos lábios dela com a ponta dos dedos, depois comeu o resto sem o menor sinal de repulsa.

Ele estalou os lábios e ergueu as sobrancelhas. — Doce.

— Como um mingau de frutos do mar pode ser doce?

Lu Linyuan sorriu e se aproximou de Ning Xiaoxiao, com a voz baixa e rouca:

— Xiaoxiao é doce.

“......”

— Quero mais.

*(PS da autora: mais uma atualização em breve~)*

# Validação editorial e estrutural — capítulo 274

## Fontes
- Tradução-base em português: `novel capitulos 271 a 300 - ch.epub`, `index_split_003.html`.
- Fonte primária chinesa: `novel_capitulos_271_a_300(20261106-202946).docx`; a outra cópia do DOCX é idêntica em SHA-256.
- Capítulo contido nos parágrafos DOCX **218 a 264** (índice base zero, inclusive vazios).
- Parágrafos não vazios do chinês: **44**; unidades textuais do EPUB: **44**. Alinhamento estrutural em ordem: **OK**.

## Controle de entregáveis
- CSV com cabeçalho `indice_docx,original_chines,traducao_portugues`: **44** registros; índices reais únicos/crescentes.
- Markdown: **44** unidades na mesma ordem do cotejo, inclusive título, notas, apartes e símbolos.
- Linhas em chinês preservadas sem alterações e associadas às revisões portuguesas: **OK**.

## Decisões e erros do EPUB identificados
- A reação à droga não significa dependência química: `沉溺其中無法自拔` descreve perda de controle sob o efeito, corrigido.
- `宋院判` é responsável pela Academia Médica Imperial; a tradução automática “Juiz Song” foi corrigida.
- `佟嬪` corresponde a **Concubina Tong**, não Consorte Tong.
- Preservado o conflito entre a recusa de Lu Linyuan, motivada pela intoxicação, e a insistência de Ning, sem inventar uma explicação ou transformar o efeito da droga em consentimento.

## Limites
O cotejo assegura correspondência estrutural, e as passagens problemáticas identificadas foram confrontadas com o original chinês. A versão em português foi revista editorialmente com ênfase em erros de sentido, continuidade e fluência. **Não há certificação de auditoria semântica independente integral oração a oração**. Os registros de alinhamento não constituem, por si, prova de equivalência semântica absoluta.

# Validação editorial e estrutural — capítulo 275

## Fontes
- Tradução-base em português: `novel capitulos 271 a 300 - ch.epub`, `index_split_004.html`.
- Fonte primária chinesa: `novel_capitulos_271_a_300(20261106-202946).docx`; a outra cópia do DOCX é idêntica em SHA-256.
- Capítulo contido nos parágrafos DOCX **265 a 307** (índice base zero, inclusive vazios).
- Parágrafos não vazios do chinês: **40**; unidades textuais do EPUB: **40**. Alinhamento estrutural em ordem: **OK**.

## Controle de entregáveis
- CSV com cabeçalho `indice_docx,original_chines,traducao_portugues`: **40** registros; índices reais únicos/crescentes.
- Markdown: **40** unidades na mesma ordem do cotejo, inclusive título, notas, apartes e símbolos.
- Linhas em chinês preservadas sem alterações e associadas às revisões portuguesas: **OK**.

## Decisões e erros do EPUB identificados
- O título `元宵夫婦` é referência ao casal e ao nome do Festival das Lanternas; mantido **Yuanxiao** para não apagar o jogo nominal.
- `對不起` significa ter sido injusto/ter falhado com alguém, não necessariamente “maltratar”.
- As falas de Xiao Qi e os pensamentos são `【 】` e foram restaurados, incluindo a frase que o EPUB deixava fora dos colchetes.
- `宿主` designa a anfitriã Ning, não “apresentador”; `正經統子` significa “sistema respeitável”.

## Limites
O cotejo assegura correspondência estrutural, e as passagens problemáticas identificadas foram confrontadas com o original chinês. A versão em português foi revista editorialmente com ênfase em erros de sentido, continuidade e fluência. **Não há certificação de auditoria semântica independente integral oração a oração**. Os registros de alinhamento não constituem, por si, prova de equivalência semântica absoluta.

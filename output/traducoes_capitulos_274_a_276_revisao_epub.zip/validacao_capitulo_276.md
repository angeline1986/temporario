# Validação editorial e estrutural — capítulo 276

## Fontes
- Tradução-base em português: `novel capitulos 271 a 300 - ch.epub`, `index_split_005.html`.
- Fonte primária chinesa: `novel_capitulos_271_a_300(20261106-202946).docx`; a outra cópia do DOCX é idêntica em SHA-256.
- Capítulo contido nos parágrafos DOCX **308 a 391** (índice base zero, inclusive vazios).
- Parágrafos não vazios do chinês: **81**; unidades textuais do EPUB: **81**. Alinhamento estrutural em ordem: **OK**.

## Controle de entregáveis
- CSV com cabeçalho `indice_docx,original_chines,traducao_portugues`: **81** registros; índices reais únicos/crescentes.
- Markdown: **81** unidades na mesma ordem do cotejo, inclusive título, notas, apartes e símbolos.
- Linhas em chinês preservadas sem alterações e associadas às revisões portuguesas: **OK**.

## Decisões e erros do EPUB identificados
- Corrigidas trocas de pessoa: `她` no EPUB para cabelo levado ao nariz, narração em primeira pessoa em `第一眼看見的`, e fala “doce” atribuída a Ning em vez de Lu.
- `五子棋` é **gomoku / cinco-em-linha**, não Go.
- `上朝` é audiência da corte imperial, não comparecimento a tribunal judicial; `奏折` são memoriais.
- `辰時` designa a hora tradicional *chen* (aproximadamente 7h–9h); o EPUB afirmou arbitrariamente “já passa das 7”.
- `【 】` restaurados nos pensamentos que o EPUB trazia como frases narrativas; o PS autoral foi preservado.
- O texto chinês menciona benefícios concedidos e clemência a condenados por decreto imperial, não “imperadores que iniciam uma nova dinastia”.

## Limites
O cotejo assegura correspondência estrutural, e as passagens problemáticas identificadas foram confrontadas com o original chinês. A versão em português foi revista editorialmente com ênfase em erros de sentido, continuidade e fluência. **Não há certificação de auditoria semântica independente integral oração a oração**. Os registros de alinhamento não constituem, por si, prova de equivalência semântica absoluta.

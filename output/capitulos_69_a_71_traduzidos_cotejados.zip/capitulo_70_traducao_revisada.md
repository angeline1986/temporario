# Capítulo 70 — Pareciam um casal de apaixonados

Com aquele visual esquisito, Lu Linyuan parecia ter engolido pólvora. Assim que viu Ning Xiaoxiao, começou a descarregar a irritação.

Nem precisava pensar para saber que ele a chamara por causa daquele problema de ficar “de pé” sem descanso.

Ela se fez de desentendida: — Majestade, por que tanta raiva?

Vermelho de constrangimento, Lu Linyuan baixou a voz para perguntar sobre um assunto difícil de pronunciar: — Aquele... aquele tratamento que você me deu pode causar sequelas? Algo como... um resultado excessivo?

Ning Xiaoxiao: 【Ora, vejam só! Como convém a um imperador, até para isso ele escolhe palavras refinadas. Por que não diz simplesmente que o negócio está anormal? “Resultado excessivo”...】

【Às vezes penso que os homens são as criaturas mais estranhas do mundo.】

【Quando o negócio não funciona, querem que funcione.】

【Quando funciona demais, não aguentam!】

Lu Linyuan: “???”

— Estou fazendo uma pergunta!

Ele bateu com força na mesa, derrubando o porta-pincéis. Os pincéis rolaram pelo chão.

— Ah? Sim... Majestade, não sei a que sequela se refere. Em teoria, não deveria haver nenhuma...

Numa hora dessas, Ning Xiaoxiao jamais poderia admitir que havia um efeito colateral.

Se confessasse, não conseguiria resolvê-lo e ainda correria o risco de ele achar que fizera aquilo de propósito. Para que se meter em mais problemas?

Lu Linyuan tinha agora absoluta certeza de que ela conhecia a sequela.

Só mantinha a boca fechada para poder rir de sua desgraça.

Sua paciência chegara ao fim. Aquela louca, aproveitando-se da pouca benevolência com que a tratara, ultrapassava seus limites repetidas vezes. Se não lhe desse uma lição, ela nunca aprenderia que fazer balé dentro da boca de um tigre era pedir para sair machucada!

Lu Linyuan agarrou seu pulso num movimento brusco. Seus olhos frios pareciam tingidos de vermelho. — Aconselho que não volte a desafiar meus limites. Caso contrário, eu a matarei!

— Ai, ai, ai! — Ning Xiaoxiao se debateu, mas, quanto mais tentava escapar, mais forte ele apertava.

Com ar choroso, implorou: — Majestade, solte primeiro esta serva. Preciso examinar seu pulso para descobrir o que houve de errado...

Lu Linyuan soltou-a com um resmungo. Ela avançou dois passos, pretendendo fingir um exame e inventar alguma desculpa convincente.

Só que, mal deu um passo, pisou num dos pincéis que haviam rolado pelo chão.

O cabo era liso. Seu pé deslizou sobre ele e seu corpo foi lançado de frente.

Tal como na primeira vez, quando caíra do céu diretamente nos braços de Lu Linyuan, ela foi parar outra vez no colo dele.

A diferença é que, dessa vez, sentiu claramente que esmagara algo que definitivamente não deveria.

Seus seios tamanho D bateram contra o peito dele com um *boing-boing* que fez o rosto de Lu Linyuan corar.

E, quando instintivamente tentou se apoiar na cintura dele para levantar, acabou pressionando com a mão o “21”, que estava em posição de sentido.

Os dois se encararam. O constrangimento era tão grande que até a autora, enquanto escrevia essa cena, poderia cavar com os dedos dos pés um castelo inteiro da Barbie no chão.

— Aaaah! — Aaaah!!

O grito comprido e ondulado era de Ning Xiaoxiao. O grito com dois pontos de exclamação, de Lu Linyuan.

Ning Xiaoxiao tentou se levantar sem perceber que os cintos dos dois, sabe-se lá como, haviam se enroscado.

Quando se ergueu de súbito, os cintos se apertaram num nó, e a força a puxou de volta para o colo de Lu Linyuan.

Dessa vez, seu contato com o “21” foi ainda mais íntimo.

Lu Linyuan arregalou os olhos: — Está querendo repetir a façanha?!

— Não, não! Majestade, deixe-me explicar! Não foi de propósito!

Ning Xiaoxiao ergueu os cintos amarrados e os balançou diante dele. — Eles... deram um nó!

O rosto de Lu Linyuan ficou vermelho como as nuvens incendiadas do pôr do sol. — Então desfaça logo!

— Sim... Já estou tentando!

Ela se atrapalhava cada vez mais. Lu Linyuan não parava de exigir rapidez, deixando-a ainda mais nervosa.

Depois de algum tempo, Ning Xiaoxiao percebeu uma coisa e parou de mexer no nó.

— Por que parou?! — perguntou Lu Linyuan.

— Majestade... Acho que... agora é um nó cego...

— Ning Xiaoxiao! Você fez isso de propósito! Com certeza fez! Eu... eu vou matá-la!!

— Não, não! Acalme-se, Majestade! Ainda há um jeito! Se o nó está apertado demais para soltar, podemos tirar um dos cintos do corpo!

Lu Linyuan ficou horrorizado e olhou para as próprias calças. — Não bastou se aproveitar de mim e agora quer que eu tire...? Por quê? É difícil me apalpar por cima do tecido?!

Ning Xiaoxiao: — ... Majestade, não se mexa. Basta eu tirar o meu.

Os cintos antigos eram enfeites; retirá-los não faria as calças caírem imediatamente.

Enquanto desatava o próprio cinto, Ning Xiaoxiao tentou explicar: — Isso tudo foi um mal-entendido. Majestade, não imagine coisas...

— Ande logo! Pare de enrolar! — exigiu Lu Linyuan.

— Majestade! Majestaaade!

Uma voz doce e afetada surgiu do lado de fora. A Consorte Nobre nunca tinha paciência para esperar que os servos anunciassem sua chegada.

Fizera doces novos para agradar Lu Linyuan. Ao entrar, porém, deu de cara com Ning Xiaoxiao sentada sobre ele, mexendo freneticamente nas roupas, como se estivesse tentando despi-lo, enquanto Lu Linyuan a apressava para que terminasse logo.

E, pior ainda: ela conseguiu ver o “21” por baixo da roupa!

Estava no palácio havia três anos. Era a primeira vez que via o “21”.

Quem diria que seria em circunstâncias como aquelas!

Ficou paralisada, e quase deixou cair a cesta de comida.

Mas não foi a única. Lu Linyuan e Ning Xiaoxiao também congelaram!

A Consorte Nobre cerrou os dentes; seus olhos ficaram úmidos de lágrimas.

Depois de tantos anos no palácio, possuía beleza, corpo e uma família das mais influentes. Mesmo assim, Lu Linyuan nem lhe dirigia o olhar. Preferia fazer aquilo com uma simples criada... em vez de procurá-la.

Vergonha e ressentimento lhe subiram ao peito. Com a voz trêmula, disse:

— Esta consorte chegou em má hora. Peço licença!

Ning Xiaoxiao tentou detê-la: — Consorte Nobre, espere! Esta serva já está quase acabando! Espere só mais um instante!

Consorte Nobre: “???”

O que ela estava dizendo?

Queria que eu ficasse aqui assistindo aos dois fazendo aquilo?!

Que absurdo!

Há humilhações piores do que a morte!

Lu Linyuan ficou ainda mais constrangido. Vendo o olhar da Consorte Nobre passear constantemente pelo seu “21”, quis desaparecer num buraco.

Disse: — Consorte Nobre, pode se retirar.

Ning Xiaoxiao olhou para os olhos flamejantes da mulher e sentiu um desespero profundo.

A Consorte Nobre era o alto-falante do harém. Se ficasse sabendo daquela história, espalharia tudo pelos quatro cantos.

As demais consortes passariam a tratá-la como inimiga, e até Gu Sijin poderia se voltar contra ela.

Não estaria completamente ferrada?

Não! Não podia deixar que ela tivesse visto aquilo!

Sem hesitar, Ning Xiaoxiao acionou Retroceder. O tempo voltou três minutos, para antes da entrada da Consorte Nobre no Palácio Chaoyang. Em seguida, apertou Pausar.

E começou a modificar a trama.

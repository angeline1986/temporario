# Capítulo 71 — Você é mesmo uma megera!

Bastava atrasar a Consorte Nobre por um minuto e fazê-la entrar um minuto depois.

Até lá, Ning Xiaoxiao já teria tirado o cinto. A mulher não veria aquela cena humilhante.

Na trama original, estava escrito:

〈A Consorte Nobre correu animada até os aposentos de Lu Linyuan. Diante da porta, ajeitou sua aparência e ficou tão comovida com a própria beleza que começou a chorar.〉

Depois da alteração de Ning Xiaoxiao, ficou assim:

A Consorte Nobre correu animada até os aposentos de Lu Linyuan. Diante da porta, ajeitou sua aparência de defunta e ficou tão horrorizada com a própria feiura que começou a chorar.

Ela se examinou no pequeno espelho de bronze que carregava e começou a soluçar alto, deixando Sanfu estarrecido.

Ele tentou consolá-la algumas vezes, mas ela não lhe deu ouvidos. Pelo contrário, chorou ainda mais.

Sanfu correu para avisar Lu Linyuan.

Só que, assim que entrou, viu exatamente a mesma cena que a Consorte Nobre testemunhara três minutos antes.

Ning Xiaoxiao estava sentada sobre Lu Linyuan, mexendo apressadamente nas roupas e nos cintos, enquanto ele insistia para que ela se apressasse.

O queixo de Sanfu quase caiu no chão.

Um eunuco como eu pode mesmo assistir a isso de graça?!

Lu Linyuan o fulminou com o olhar: — Saia daqui!

Sanfu: — Sim, Majestade! Podem continuar!

Ning Xiaoxiao: “...”

Depois de muito esforço, Ning Xiaoxiao conseguiu tirar o cinto. Então recuou vários passos, querendo ficar o mais longe possível de Lu Linyuan.

Mas o porta-pincéis que ele derrubara espalhara mais de um pincel pelo chão.

Sem prestar atenção onde pisava, Ning Xiaoxiao recuou sobre outro cabo. Perdeu o equilíbrio e caiu para trás, na direção da própria nuca.

— Ai, caramba!

Atrás dela havia uma decoração de bronze com cabeça de fera, cheia de pontas e quinas.

Lu Linyuan não teve tempo de pensar. Quase por instinto, usou sua técnica de leveza para chegar atrás dela e proteger-lhe a nuca com a mão.

A cabeça de Ning Xiaoxiao bateu na palma macia dele, sem sofrer qualquer ferimento.

A parte de trás da mão de Lu Linyuan, porém, foi lançada contra o chifre da fera de bronze. Um grande pedaço de pele se rasgou.

O sangue começou a jorrar imediatamente, escorrendo pelos dedos compridos até pingar no chão.

Quando Ning Xiaoxiao recuperou os sentidos e viu a mancha de sangue se espalhar pelo piso, sentiu uma culpa inesperada.

— Majestade... está bem?

— Estou. — Lu Linyuan escondeu a mão atrás das costas, com a expressão inalterada. — Mas você não estará se não me contar a verdade agora. Que método usou para curar minha doença? Se continuar escondendo, mandarei cortar sua cabeça!

Ning Xiaoxiao já estava acostumada com os ataques de fúria impotente dele.

Diziam que era um tirano, mas, no fim das contas, era mais feroz nas palavras do que nos atos.

Se quisesse mesmo matá-la, por que teria acabado de salvá-la? Bastava deixá-la bater a cabeça no bronze e morrer!

— Essa sequela de Vossa Majestade não é grave, mas não existe maneira de aliviar os sintomas. Depois de três dias, porém, o problema desaparecerá por conta própria. Por enquanto, só posso pedir que tenha um pouco de paciência...

Lu Linyuan estreitou os olhos e a observou.

Dessa vez, suas palavras e pensamentos coincidiam. Ela não estava armando nenhuma trapaça.

Ainda bem que eram só três dias. Se o problema durasse três anos, ele acabaria morrendo jovem de tanto desgosto...

Pensando bem, desde que conhecera Ning Xiaoxiao, não tivera mais um único dia tranquilo.

Ou estava sendo atormentado, ou prestes a sofrer alguma nova armação.

Às vezes se perguntava se aquela louca capaz de prever o futuro era sua estrela da sorte ou seu desastre pessoal...

*

Depois de escapar viva do Palácio Chaoyang, Ning Xiaoxiao sentiu alívio, mas também preocupação.

Lu Linyuan não permitira que ela examinasse a mão. Pela quantidade de sangue no chão, sabia que não era um ferimento pequeno.

Por isso, ao encontrar Sanfu junto à entrada, pediu: — Eunuco Sanfu, chame um médico imperial para examinar Sua Majestade. Ele machucou a mão.

Sanfu: — Nossa! Por que toda vez que você fica sozinha com Sua Majestade eu preciso chamar o médico? O que vocês fizeram lá dentro de tão intenso para ele machucar até a mão?

Só então Ning Xiaoxiao se lembrou de que Sanfu vira direitinho aquilo que ela impedira a Consorte Nobre de presenciar. Corando, disse: — Pare de falar bobagens! Não é nada disso que está pensando. Enfim... chame logo o médico.

Ela saiu quase correndo, em passinhos apressados.

Ning Xiaoxiao era do tipo que jamais esquecia uma gentileza recebida, mesmo depois de mil anos.

Retribuía as ofensas, mas também retribuía os favores.

Naquele dia, Lu Linyuan se ferira para protegê-la. Se não tivesse colocado a mão ali sem hesitar, ela teria batido a nuca contra o bronze e provavelmente morrido na hora, sem tempo de recorrer a qualquer poder especial.

Lembrou-se de Sanfu lhe contar que, desde pequeno, Lu Linyuan detestava chamar médicos mesmo quando sentia dor ou se machucava.

Então foi pessoalmente à farmácia imperial e trocou as sementes de ouro que Gu Sijin lhe dera por um frasco de pomada para ferimentos.

Quando voltou ao Palácio Chaoyang com o remédio, encontrou Sanfu andando de um lado para o outro, aflito, junto à porta.

— Eunuco Sanfu! O médico imperial já o examinou?

Sanfu balançou a cabeça, resignado. — Ele mesmo enrolou a mão em umas gazes, de qualquer jeito. Já falei até ficar sem saliva, mas Sua Majestade não permite que eu chame um médico...

Ning Xiaoxiao estranhou: — Consultar um médico não é motivo de vergonha. Por que ele se recusa?

Sanfu suspirou. — Vou lhe contar em segredo, mas não espalhe. A imperatriz-viúva sempre teve grandes ambições para o filho. Desde pequeno, Sua Majestade precisava ser melhor que todos os outros príncipes em tudo para merecer um sorriso dela.

— Mas Sua Majestade nasceu com a saúde frágil e vivia adoecendo. A imperatriz-viúva temia que o falecido imperador soubesse disso e achasse que ele não servia para ser príncipe herdeiro. Por isso, sempre que adoecia, ela proibia chamar um médico imperial. Duas ou três vezes por mês, mesmo com febre e dor, ele tinha de aguentar sozinho.

— Mais tarde, ele se tornou príncipe herdeiro. Depois, com a morte do antigo imperador, ascendeu ao trono. Mas o hábito adquirido na infância nunca desapareceu...

Ning Xiaoxiao não conseguia entender aquilo.

Lembrava que, aos cinco ou seis anos, tivera uma febre altíssima no meio da noite. A família ainda não possuía carro, e as ruas estavam completamente desertas.

O pai estava viajando a trabalho. Então a mãe a carregara nas costas e correra sozinha até o hospital.

Ela jamais esqueceria como, febril e quase delirando, apoiada nas costas da mãe, ouvira seus soluços abafados.

Como podia existir uma mãe capaz de colocar a vida do próprio filho em risco para conquistar posição e prestígio?

A opinião que Ning Xiaoxiao tinha da imperatriz-viúva já era negativa. Naquele instante, caiu mais dez mil e oitenta e seis pontos.

Sanfu viu o frasco em suas mãos e reconheceu de imediato a pomada para ferimentos. Perguntou:

— A última pomada que você tinha, ouvi Bengbeng dizer que usou toda no Cao Ni Ma. De onde veio esta?

Ning Xiaoxiao respondeu apenas “segredo” e seguiu diretamente ao encontro de Lu Linyuan.

Ao vê-la, ele ficou tão alerta como se tivesse diante de si um monstro alienígena. — O que veio fazer aqui?

Sem dizer nada, Ning Xiaoxiao caminhou depressa até ele e, antes que reagisse, segurou seu pulso ferido e começou a desfazer as ataduras mal colocadas.

— Vim cuidar do seu ferimento. Majestade se machucou para me salvar. Mesmo que não queira chamar um médico, pelo menos pode me deixar cuidar da sua mão, não é?

Você? Me tratar?

Veja só o que você fez com meu “21”! Já seria uma bênção dos céus se ficasse bem longe de mim!

Era isso que pensava, mas não tentou impedi-la. Apenas reclamou quando ela puxou a última camada de gaze e acabou esbarrando no ferimento.

— Ai! Tenha mais cuidado!

— Você não tem delicadeza nenhuma! É a reencarnação de uma megera, por acaso?!

# Validação — Capítulo 71

- Fonte: `novel_capitulos_61_a_120(20261103-184549).docx`, capítulo 71.
- Unidades originais não vazias, incluindo título: **75**.
- Unidades traduzidas alinhadas: **75**.
- Índices sem tradução: **0**.
- Índices excedentes: **0**.
- Método: cotejo por unidade textual do DOCX e revisão durante a redação. A correspondência 1:1 é estrutural; **não constitui auditoria semântica independente**.
- Expressões idiomáticas, trocadilhos e alusões contemporâneas foram adaptados visando legibilidade e preservação de humor, sem equivalência literal palavra por palavra.
- Nota: o contraste de 儀容 (aparência) com 遺容 (aparência de um morto) e 美 (beleza) com 醜 (feiura) é o mecanismo da edição de trama; preservado por adaptação. O original cita “草泥馬” como nome de uma criatura/personagem, mantido na transliteração Cao Ni Ma.

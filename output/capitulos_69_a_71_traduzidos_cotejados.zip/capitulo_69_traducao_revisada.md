# Capítulo 69 — Vergonha alheia em escala monumental. Recomenda-se nascer de novo

O boato de que Lu Linyuan havia molhado a cama não continuou se espalhando.

Ele decretou que, dali em diante, qualquer pessoa no palácio que ousasse juntar aquelas duas palavras teria a língua cortada.

As consortes não comentavam em voz alta, mas quem não pensava que ele estava praticamente anunciando a própria culpa?

Naquele dia, depois de voltar do Palácio Chaoyang, Ning Xiaoxiao desatava a gargalhar toda vez que se lembrava da expressão constrangida de Lu Linyuan.

Quase morreu de tanto rir.

Xiao Qi: 【Hospedeira, pega leve! Acabei de entrar no expediente e já estou ouvindo essas gargalhadas. Dá até medo...】

Ning Xiaoxiao: 【Medo de quê? Quem devia estar com medo é Lu Linyuan! Hahahahaha!】

Xiao Qi, confuso: 【A impotência dele foi curada. Por que você está tão feliz? E por que ele deveria ter medo? Humm... Hospedeira, tem alguma coisa estranha aí! Você não está planejando fazer alguma safadeza com ele, está?】

Ning Xiaoxiao: 【Impossível! Eu, Ning Xiaoxiao, prefiro morrer solteirona, viver como viúva pelo resto da vida! Nunca vou ter absolutamente nada com ele!】

Xiao Qi: 【Hospedeira, já ouviu falar de Wang Jingze?】

Ning Xiaoxiao: 【...】

No fim da conversa, Xiao Qi ainda a lembrou de algo: 【Hospedeira, você leu a bula antes de dar o remédio a ele?】

Havia uma pequena bula dentro da caixa, na verdade uma única folha dobrada.

Ning Xiaoxiao a jogara fora sem nem olhar.

Ao ouvir a pergunta, sentiu um calafrio. 【Não vai me dizer que tem mais alguma surpresa desagradável?】

【Nada de tão grave. É só que o remédio tem um efeitinho colateral... A partir do dia seguinte à dose, ele começa a agir. O tirano vai passar de incapaz de levantar a cabeça para ficar com ela erguida por três dias e três noites seguidos.】

Ning Xiaoxiao nem deu importância.

O que ela tinha a ver com ele ficar erguido por três dias e três noites?

Era até capaz de ele lhe agradecer pelo talento extraordinário que acabara de ganhar!

*

Na manhã seguinte à dose do antídoto, a primeira coisa que Lu Linyuan fez ao despertar foi estender a mão para conferir.

Quando constatou que recuperara sua antiga glória, finalmente tirou aquele peso do coração.

Desde que o tratamento funcionasse, a humilhação sofrida ontem por seu traseiro imperial não teria sido em vão!

Mas a alegria durou pouco. Logo percebeu que havia alguma coisa errada.

Antes, quando acordava especialmente animado, bastava ter uma conversa íntima com sua querida Senhorita Cinco Dedos para tudo voltar ao normal.

Naquela manhã, porém, já tinham conversado três vezes, e a cabeça altiva continuava se recusando a baixar.

Era uma vergonha ainda pior do que não conseguir levantá-la.

Daqui a pouco teria de comparecer à audiência no Salão Dourado. Com aquele volume saltando sob a roupa, era constrangimento além da conta!

Sanfu chamou do lado de fora: — Majestade, está quase na hora da audiência matinal!

— Eu sei! Pare de me apressar!

Aquilo só podia ser obra daquela louca!

Ela não teria sossego enquanto não o levasse à ruína!

Furioso, Lu Linyuan decidiu acertar as contas com Ning Xiaoxiao depois da audiência.

Mas seu “21” estava chamando atenção demais, e o traje de corte, justo ao corpo, só piorava a situação.

Para evitar um desastre público, amarrou outra peça de roupa comum à cintura, tentando esconder o problema.

Quando Sanfu o viu, examinou-o e sorriu: — Ora, Majestade! Que visual diferente o senhor escolheu hoje!

*Pá!*

Lu Linyuan lhe deu mais um tapa na cara. — Cuide da sua vida!

Na audiência, o traje peculiar do imperador também chamou a atenção dos ministros.

Ninguém, contudo, comentou. Como de costume, os que tinham assuntos apresentavam seus memoriais; os demais permaneciam em silêncio.

Nos últimos dois dias chegaram notícias de vitórias na campanha que Lu Linyuan enviara contra os bárbaros do sul.

Derrotados pelo reino de Qi, eles se dispunham a entregar anualmente duzentos mil taéis de prata em tributos e cinquenta mil *shi* de provisões, para encerrar a guerra.

Era sua maior demonstração de boa vontade: praticamente a maior parte da receita anual do país.

Mesmo assim, Lu Linyuan não cedeu: — Eu ordenei que as terras dos bárbaros do sul fossem arrasadas! Não haverá negociação de paz! Digam a Ren Duanli que não preciso ser consultado sobre nenhuma proposta deles. Se os exterminarmos, tudo que possuem pertencerá a Qi.

Um ministro aconselhou: — Majestade, nas guerras entre reinos, quem mais sofre são os inocentes. Os bárbaros do sul podem ter cometido erros, mas de que têm culpa seus súditos? Que Vossa Majestade considere a benevolência e lhes conceda uma saída. Assim...

— Sou eu que lhes nego uma saída? São eles que não querem viver! — retrucou Lu Linyuan, severo. — Qi nunca mata civis nas guerras. Se não tivessem pegado em armas, gritando que defenderiam sua terra, não estariam agora estendidos pelos campos. Sou o imperador de Qi, não o rei dos bárbaros do sul. Se hoje eu fraquejar e não acabar com eles, amanhã será meu povo a sofrer!

— Mas, Majestade, ouvi dizer que o general Ren vem promovendo massacres por onde passa nas terras do sul, sem deixar sequer um sobrevivente. Em que isso difere da carnificina de um demônio do inferno?

Lu Linyuan respondeu: — Ele age assim por minha ordem. Por quê? Está tentando me ensinar a governar?

— Jamais ousaria, Majestade...

Lu Linyuan bateu na mesa e se ergueu para advertir a corte: — Os bárbaros do sul são traiçoeiros e ardilosos! Tolerei seus abusos repetidas vezes, e eles só ficaram mais insolentes! Que fique claro: se alguém voltar a demonstrar a menor compaixão por eles, será exilado para as terras gélidas do extremo norte e jamais poderá retornar à capital!

Sua declaração foi imponente. Só que, assim que terminou, a peça de roupa que lhe cobria a cintura escorregou e caiu no chão.

O “21” estava de cabeça erguida, firme e orgulhoso. Qualquer pessoa com olhos seria capaz de perceber.

Todos os ministros fixaram o olhar no pequeno Lu Linyuan, e o Lu Linyuan grande ficou vermelho num instante.

Ele se sentou depressa, fingindo que nada acontecera.

Mas um ministro, ávido por bajulá-lo, achou que o imperador estava exibindo aquilo de propósito.

E se pronunciou:

— Majestade... Isso... isso é realmente...

— O vigor da Ásia, rugindo até os céus?

Lu Linyuan: “...”

Seu rosto ardeu de vergonha. Queria que o chão se abrisse para poder se esconder.

Ao mesmo tempo, sua determinação de “dar um jeito” em Ning Xiaoxiao só aumentou!

*

Naquela hora, Ning Xiaoxiao brincava de arremessar saquinhos de areia com Qiqi e as outras no Palácio Zhongcui.

Sabe-se lá de onde Sanfu surgiu. Um dos saquinhos voou direto em seu olho e o deixou com uma bela marca de panda.

— Ai! Eunuco Sanfu, está bem? Não fiz de propósito...

Com a mão sobre o olho, Sanfu acenou com a outra e ainda precisou sorrir para aquela peste: — Estou, estou. Vim procurar você por um assunto.

Ele a puxou e arrastou para longe das demais antes de dizer: — Sua Majestade quer vê-la.

Ele quer me ver?

Para quê?

Ele vai ficar daquele jeito por três dias e três noites! Não acho que seja uma boa hora para me receber!

Ei, pare de me empurrar!

E assim, Sanfu e alguns guardas a levaram, meio arrastada, meio empurrada, ao Palácio Chaoyang.

O olhar de Lu Linyuan naquele dia estava visivelmente assassino. Ning Xiaoxiao se ajoelhou depressa e saudou, obediente:

— Esta serva presta homenagens a Vossa Majestade! Que seja abençoado com toda a felicidade!

— Felicidade? Acha que eu pareço um homem feliz?

Lu Linyuan estava sentado numa cadeira de espaldar alto, com uma manta de lã sobre o colo para esconder seu “21” erguido. Disse, irritado:

— E se eu lhe oferecesse essa felicidade? Aceitaria?

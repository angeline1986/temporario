# Capítulo 325 — A morte do tirano foi antecipada na linha do tempo?

A flecha voou em sua direção a uma velocidade incrível e parecia que o atingiria no segundo seguinte.

Mas naquele instante, o tempo parou e tudo ao redor deles ficou congelado.

Ning Xiaoxiao abriu a porta da carruagem com um chute e saiu.

Ela agarrou a flecha suspensa no ar, prestes a atingir Lu Linyuan pelas costas, virou-se e a cravou no peito do chefe dos bandidos montados.

— Seus desgraçados! Como ousam atentar contra o meu marido?

— Acham que eu sou alguma fracote?

Ela agarrou a haste da flecha e a girou com força duas vezes contra o peito do bandido.

— Nem para assaltar vocês sabem escolher a vítima! Acabaram perdendo a vida por isso, seus idiotas!

Após dizer isso, ela recostou-se calmamente na liteira, fechou os olhos, abriu o documento e começou a revisar drasticamente o enredo.

Depois de terminar as alterações, ela apertou o botão Reproduzir, e a história continuou:

Uma rajada repentina de vento mudou a direção de todas as flechas.

Como se tivessem olhos, as flechas mudavam de rumo pouco antes de alcançar Lu Linyuan e seu grupo e buscavam os pontos vitais dos bandidos a cavalo.

Alguns tiveram suas cabeças perfuradas, alguns foram cobertos de espinhos e alguns foram até mesmo atravessados por mais de uma dúzia de flechas, seus corpos jorrando sangue como fontes humanas.

Num piscar de olhos, todos os bandidos armados com facas caíram no chão, transformando-se em cadáveres horripilantes.

Os bandidos arqueiros que se escondiam nas sombras da floresta e atiravam flechas não se saíram muito melhor.

O céu, que momentos antes estava limpo, escureceu repentinamente, com nuvens obscurecendo o sol e acompanhadas de relâmpagos e trovões.

Os raios atingiram o solo com uma precisão ainda maior do que quando atingiram Zhu Xihua naquele dia.

Eles perseguiram os bandidos arqueiros, golpeando-os impiedosamente, explodindo-os um a um até que estivessem carbonizados e rachados, transformando-os de pele amarela em pele negra, completando assim com sucesso a transformação racial.

A cena mágica que se desenrolou diante de seus olhos deixou todos sem palavras.

Até mesmo Ren Duanli, que já tinha visto muita coisa no campo de batalha, ficou atônito e piscou repetidamente, como se estivesse vendo coisas.

Em pouco tempo, os bandidos foram eliminados.

Ning Xiaoxiao espiou, fingindo não saber de nada, e perguntou:

"O que aconteceu?"

"volte."

Lu Linyuan pressionou a cabeça dela para baixo e a empurrou de volta para a carruagem.

Como ele pôde deixar sua jovem esposa presenciar uma cena tão sangrenta?

Gu Sijin e Lu Yiqiu também desceram da carruagem.

Gu Sijin subiu imediatamente na carruagem de Ning Xiaoxiao. O pequeno coelho branco não se intimidou com os cadáveres no chão e estava ansioso para confortar a mulher grávida.

Lu Yiqiu, por outro lado, voltou ao seu modo barulhento:

Uau! Irmão! Você realmente faz jus ao nome do Imperador!

Ele deu um tapinha forte no ombro de Lu Linyuan. "Eu espiei por trás da cortina da liteira agora mesmo! Parece que até os céus estão te protegendo! Aquele raio foi incrível!"

"Ei! Lilizinha, não me puxe!"

Antes que ele pudesse dizer duas palavras, Ren Duanli o agarrou pela gola e o jogou de volta na carruagem.

Chu Xingran examinou rapidamente as vestimentas dos bandidos e encontrou com eles um grande número de valiosos artefatos de jade e dinheiro, que deviam ter sido obtidos por meio de roubo.

"Majestade, esta é uma estrada oficial. Parece que não é a primeira vez que esses bandidos emboscam e cometem crimes aqui."

"Deveria haver soldados patrulhando as estradas oficiais, como podem ser tão arrogantes?"

Lu Linyuan zombou: "Ao longo do caminho para o território de Chonghai, você viu algum soldado patrulhando?"

Ren Duanli disse em voz grave: "Este lugar é uma rota necessária para muitos mercadores em suas viagens. A julgar pela situação atual, quem sabe quantas vidas foram perdidas nas mãos desses bandidos. Será possível... que os oficiais e os bandidos tenham se tornado um só e estejam conspirando aqui?"

Era exatamente isso que preocupava Lu Linyuan.

Ele permaneceu em silêncio por um instante, depois deu a ordem:

— Vamos manter isso em segredo por enquanto, para não alertar os envolvidos. Ainda estamos a quase cem li de Chonghai. Se os bandidos daqui já agem com tamanha impunidade, imagine o que não estará acontecendo na própria cidade.

"Duanli, envie imediatamente uma mensagem por pombo-correio e despache a Guarda Tigre para patrulhar e inspecionar secretamente esta área, e eliminar o covil dos bandidos, para que o povo não sofra novamente."

Ren Duanli curvou-se respeitosamente: "Seu humilde servo obedece ao decreto."

Após retornar à carruagem, Lu Linyuan perguntou, preocupado, se Ning Xiaoxiao estava ferida.

Ela balançou a cabeça e estendeu a mão para alisar as rugas da testa dele.

"Diante dessa situação, Chonghai provavelmente não é tão pacífica e próspera quanto Zhu Zhenshan descreveu."

Lu Linyuan assentiu em concordância: "Com Tong Guowei como exemplo primordial, se Zhu Zhenshan ousar seguir seus passos, garantirei que seu destino seja várias vezes mais trágico que o de Tong Guowei!"

A condição das pessoas comuns sempre teve grande importância para Lu Linyuan.

Como monarca, o que ele menos queria ver era uma situação em que o povo estivesse sofrendo sob seu governo.

Ning Xiaoxiao parou de se comportar mal e segurou sua mão em silêncio, permanecendo ao seu lado sem fazer barulho.

Ao mesmo tempo, uma grande questão surgiu em sua mente.

Ela chamou Xiao Qi e perguntou:

【Xiao Qi, tem uma coisa muito estranha... Entendo que, ao entrar no livro e desviar continuamente a trama, eu altere os acontecimentos originais. Mas há tantas coisas acontecendo que nunca li antes! Será que foram acrescentadas agora?】

Xiao Qi sabia naturalmente por que tudo aquilo tinha acontecido, mas não podia contar esse segredo para Ning Xiaoxiao naquele momento.

Sem poder revelar o segredo, Xiao Qi inventou uma explicação: 【Claro! Eu já não disse, anfitriã? Quando você desvia a trama, altera o rumo da história original. Não há nada demais em surgirem novos acontecimentos.】

Ning Xiaoxiao: 【Mas tem algo errado! Na obra original, A-Yuan subiu ao trono aos vinte e quatro anos e morreu repentinamente aos trinta e quatro. Agora ele só tem vinte e cinco, mas o índice de desvio da trama já acumulou 73%!】

【Em apenas um ano, já completei sete décimos da missão de desviar a trama. Então quer dizer que não vou receber missões nos próximos nove anos?】

Essa falha lógica sempre existiu, mas Ning Xiaoxiao nunca havia pensado nisso em detalhes antes.

O fim de Lu Linyuan foi uma morte súbita, cujo motivo não foi mencionado na obra original.

Portanto, ela precisa concluir a história do livro e inevitavelmente enfrentar aquele dia.

Mas, a julgar pelo atual estado de desmoronamento da trama, esse dia não terá que esperar nem nove anos.

Talvez o resultado aconteça mais cedo do que o esperado este ano?

Diante das repetidas perguntas de Ning Xiaoxiao, Xiao Qi começou a inventar histórias:

【Anfitriã, não precisa se preocupar com essas coisas. Mesmo me perguntando, não tenho uma resposta muito clara.】

【Mas você não recebeu antes um documento novo como recompensa? Quando o índice de desvio da trama atingir 80%, você obterá a senha. Ao abri-lo, todas as suas dúvidas serão esclarecidas.】

【Mas......】

【Bip bip bip, o sistema que você está tentando contatar não está em área de serviço. Tente novamente mais tarde.】

Ning Xiaoxiao queria fazer mais perguntas, mas Xiao Qi já havia se desconectado às pressas...

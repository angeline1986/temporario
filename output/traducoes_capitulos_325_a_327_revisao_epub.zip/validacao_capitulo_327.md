# Validação do capítulo 327

- **Original chinês:** `novel_capitulos_301_a_360(20261107-181903).docx`.
- **Tradução-base:** `novel capitulos 301 a 360 - ch.epub` (`index_split_026.html`).
- **Faixa de índices DOCX (base zero):** 2034–2103; unidades efetivas: 2034–2102.
- **Unidades textuais não vazias:** 67 no chinês; 67 na tradução-base; 67 no CSV.
- **Unidades com intervenção textual:** 16; índices relativos do capítulo: 0, 2, 15, 17, 19, 24, 25, 33, 35, 40, 43, 47, 50, 58, 61, 66.

## Decisões editoriais

Lu Linyuan tenta impressionar Ning, mas ela critica seu umbigo. A lembrança atribui à imperatriz-viúva a responsabilidade por provocar o nascimento prematuro enquanto mantinha cativa a mãe biológica de Lu. Ren Duanli e Chu Xingran encostam espadas no casal anfitrião.

Foram mantidos os parágrafos na ordem do original. As correções incidiram sobre os trechos identificados e a terminologia de continuidade; permanecem trechos do EPUB inalterados.

## Alcance e limitações

**Alinhamento estrutural integral, revisão semântica dirigida.** O cotejo 1:1 não prova equivalência semântica de cada frase nem ausência de omissões internas. Não foi realizada uma retradução integral independente do chinês. Erros de nuance e sentido podem persistir nos trechos conservados do EPUB.

## Verificações

- CSV em UTF-8 com índices absolutos do DOCX preservados.
- Título e todas as unidades não vazias incluídos.
- Markdown e CSV usam a mesma versão revista.

# Capítulo 327 — Mulher, vou deixar você caidinha por mim!

Após um breve momento de reflexão, Lu Linyuan rapidamente reconstituiu a sequência dos acontecimentos.

— Eles estão representando uma farsa, mas não começaram a fazê-lo só porque eu viria aqui.

“Quando eu estava na capital, enviei pessoas à cidade de Chonghai para investigar secretamente várias vezes. A resposta de todos foi exatamente a mesma que a relatada por Zhu Zhenshan no memorial.”

"Então, esta peça não começou hoje; ela está em cartaz sem parar desde que o palco foi montado."

A expressão de Ren Duanli brilhou em surpresa. "Vossa Majestade quer dizer que Zhu Zhenshan está fazendo com que todos na cidade representem suas peças todos os dias para evitar as inspeções surpresa da corte?"

Chu Xingran retomou de onde havia parado: "Mas se todos na cidade fingissem todos os dias, vestidos elegantemente e comendo e bebendo bem, isso não permitiria indiretamente que o povo de Chonghai vivesse e trabalhasse em paz e contentamento? Qual é exatamente a intenção de Zhu Zhenshan ao fazer isso?"

As perguntas deles são, de fato, o ponto crucial da questão.

Lu Linyuan: "Para desvendar esses mistérios, precisamos visitar as casas de pessoas comuns. Eventualmente, encontraremos algumas pistas. Está escurecendo e eles estiveram ocupados o dia todo. Devem estar indo para casa jantar. Vamos a qualquer casa na rua, dar-lhes algum dinheiro e dizer que nós três gostaríamos de fazer uma refeição simples em sua casa esta noite."

Ren Duanli e Chu Xingran aceitaram a ordem e foram cumpri-la. Depois de comer e beber até se fartar, Ning Xiaoxiao recostou-se na cadeira e acariciou suavemente a barriga redonda.

Ela olhou para aquilo e soltou um longo suspiro.

"Ai, meu Deus, não consigo mais comer! Minha barriguinha já está aparecendo, e não sei o quão redonda e saliente ela vai ficar quando eu estiver com três meses de gravidez."

Ao ouvir isso, Lu Linyuan levantou as roupas dela, colocou as mãos em brasa sobre a barriga dela e riu:

"Você não pode deixar seu estômago sofrer. Mesmo que você não coma, nosso filho ainda precisa comer. Além disso, acho que um pouco de carne nos ossos de uma mulher a torna ainda mais adorável."

Ele se inclinou repentinamente perto do ouvido de Ning Xiaoxiao, sua voz baixa e sedutora:

— Para falar a verdade, quando você tinha braços e pernas tão fininhos, eu não ousava fazer muita força quando estávamos juntos.

"Tenho medo de que, se usar muita força, quebre seus ossos e, no fim, serei eu quem sentirá a dor."

Ning Xiaoxiao: — ??? Você é idiota, por acaso?

Ela desabotoou os dois últimos botões da camisola de Lu Linyuan, enfiou a mão por dentro e apertou-lhe a barriga com força.

Ela mal conseguiu beliscar alguma carne, mas sentiu os músculos bem definidos do abdômen dele.

"Por que você come a mesma comida que eu todos os dias, e eu não te vejo se exercitando muito, e mesmo assim você não engorda?"

Lu Linyuan riu descaradamente: "Quem disse que eu não tenho feito muito exercício?"

Ele olhou para a cama enquanto falava: "Você não sabe se eu tenho feito exercício ou não?"

Ning Xiaoxiao: “...”

【Cansei, que o mundo acabe. De tanto convivermos, até esqueci que ele é um personagem de ficção! Enquanto sua caracterização não mudar, um personagem desses continua com o mesmo rosto e corpo absurdamente perfeitos...】

Lu Linyuan não sabia o que significava “personagem de ficção”, mas entendeu perfeitamente o elogio ao seu rosto e ao seu corpo.

Então, Xiaoxiao estava elogiando-o?

Ele era como uma criança que recebera elogios de um adulto, ansiosa para exibir suas qualidades superiores.

Já que Ning Xiaoxiao já tirou metade de sua camisola, vamos deixar que ela caia toda.

Ele se levantou e disse em voz baixa e afetada: "Vou trocar de roupa."

Então, diante de Ning Xiaoxiao, ele tirou sua camisola de seda, revelando seu físico perfeitamente proporcional.

O local em seu abdômen onde Ning Xiaoxiao o havia beliscado ainda estava um pouco vermelho, e a vermelhidão foi se espalhando gradualmente, alcançando sua linha em V, atraindo o olhar de Ning Xiaoxiao para sua cintura esguia.

Ao ver sua jovem esposa olhando para ele tão abertamente, Lu Linyuan se alegrou secretamente.

Mulher, agora você vai cair de amores por mim!

No entanto, as palavras de Ning Xiaoxiao, carregadas de um toque de impotência, esfriaram seu entusiasmo:

【Hum... o umbigo dele não parece muito bonito. Talvez não tenham cortado o cordão umbilical direito?】

Lu Linyuan: “???”

Ele olhou para o seu umbigo ligeiramente saliente e mergulhou em pensamentos profundos...

Caramba!

É tudo culpa daquela velha monstruosa Imperatriz Viúva!

Quando aquela velha me fez nascer às pressas, enquanto mantinha minha mãe biológica aprisionada, tudo aconteceu numa correria. É claro que não houve tempo para a parteira cuidar direito do meu cordão umbilical.

Agora, por causa do meu umbigo, Xiaoxiao está antipatizando comigo pela primeira vez...

Isso é um absurdo! Como podemos tolerar isso?

Quando eu voltar ao palácio, vou abrir o umbigo do filho daquela velha e costurar nele o desenho de uma tartaruga!

Ele agarrou o estômago, virou-se rapidamente, vestiu-se novamente e disse como se nada tivesse acontecido:

"Saio com eles mais tarde, e você pode descansar no quarto. Não fique perambulando por aí."

"Não!" Ning Xiaoxiao fez beicinho. "Sijin e Sua Alteza o Príncipe Jing foram às compras. Se você for embora, ficarei completamente sozinha..."

Ela sabia que, se usasse o argumento habitual, Lu Linyuan jamais a levaria consigo. Por isso, mudou de estratégia:

"E se você me deixar aqui sozinha e um bandido vier e me sequestrar?"

Quando ela age de forma fofa e lamentável, Lu Linyuan fica completamente impotente.

Embora soubesse que ela estava inventando desculpas, Lu Linyuan acabou cedendo.

*

Ren Duanli e seu grupo distribuíram dinheiro e rapidamente encontraram uma família disposta a "acolhê-los" para o jantar.

Era uma família de três: o velho He, o chefe da casa, sua esposa e seu filho rechonchudo de seis ou sete anos.

Após receber os quatro, a esposa de Lao He imediatamente pôs mãos à obra e logo preparou uma grande mesa repleta de pratos.

A casa deles não era grande; os três membros da família, mais os quatro, sentavam-se ao redor de uma mesa de madeira, e não ficava nada apertado.

A mesa estava repleta de uma grande variedade de pratos, incluindo peixe, carne, camarão e caranguejo, o que a fazia parecer ainda melhor do que as casas de comerciantes de terceira categoria em Kyoto.

Durante a refeição, Lu Linyuan sorriu e tentou se aproximar deles:

— Quando chegamos, vi vários produtos do mar pendurados diante da sua casa, senhora. Está secando tudo para vender na feira?

O velho disse: "Minha família ganha a vida pescando. Eu vou para o mar pescar durante a semana, e minha esposa me ajuda. Se não conseguirmos vender os frutos do mar naquele dia, nós os salgamos e os penduramos para secar por alguns dias, e então podemos vendê-los, mas a um preço mais baixo."

Enquanto Lao He falava eloquentemente, relatando suas habilidades de subsistência com grande familiaridade, o olhar de Lu Linyuan estava fixo nos pauzinhos que Lao He segurava.

Eram mãos de homem perfeitamente comuns.

Mas é precisamente por ser algo comum que parece ainda mais extraordinário.

Aqueles que ganham a vida pescando no mar frequentemente sofrem com descamação e até ulceração das mãos devido à imersão prolongada em água salgada. Essa é uma doença comum entre os pescadores. No entanto, as mãos do velho He, embora um pouco ásperas, não apresentavam sinais de pesca de longa duração.

Lu Linyuan tamborilou levemente com os dedos na mesa de madeira, sua expressão escurecendo enquanto perguntava:

"Por quanto tempo você pretende manter essa farsa?"

Mal ele terminou de falar, Ren Duanli e Chu Xingran sacaram as espadas ocultas nas mangas e encostaram as lâminas no pescoço do casal.

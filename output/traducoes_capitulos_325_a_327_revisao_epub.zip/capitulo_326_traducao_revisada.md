# Capítulo 326 — Todos os habitantes da cidade estão encenando uma farsa

O grupo viajou durante a noite e chegou à cidade de Chonghai na manhã seguinte.

Depois de entrarem na cidade, não encontraram a miséria e o deslocamento da população que haviam esperado ver.

Pelo contrário, todos na rua estavam bem vestidos, com as bochechas rosadas, e pareciam felizes enquanto se ocupavam com suas tarefas. Não se via sequer um mendigo miserável nas ruas, o que era um sinal de prosperidade.

Lu Linyuan levantou a cortina da liteira e deu uma breve olhada nela antes de ordenar que encontrassem um lugar para ficar em uma hospedaria.

Após uma longa e cansativa jornada, Lu Linyuan pediu a Ren Duanli e Chu Xingran que fossem à cidade para avaliar a situação, enquanto ele ficaria para trás para fazer companhia a Ning Xiaoxiao e ajudá-la a dormir.

Ning Xiaoxiao sabia que ele estava mais ansioso do que qualquer outra pessoa para descobrir a verdade sobre aquele lugar, então ela disse:

“Dormi em cima de você a noite toda passada, mas você não fechou os olhos nenhuma vez.”

"Sei que você tem guardado o assunto de Chonghai em seu coração. Você não conseguirá dormir em paz enquanto não investigar isso a fundo."

"Ou devo ir com você?"

"Está tudo bem." Lu Linyuan rejeitou a sugestão de Ning Xiaoxiao sem a menor hesitação.

“Você está grávida e não deveríamos tê-la levado nessa longa viagem ontem à noite. Mas você insistiu em usar seu desejo de ver o mar como desculpa para não deixar o grupo descansar.”

“Eu sei que você está fazendo isso por minha causa, então não discuti e concordei. Mas agora que estamos em Chonghai, Ren Duanli e Chu Xingran já foram investigar, então ir ou não não fará diferença.”

Ele pegou a mão de Ning Xiaoxiao e sentou-se ao lado dela na cama. "Já pedi para alguém ferver água. Tome um banho quente e durma bem. Vou ficar com você."

Ambos são teimosos.

Mas essa teimosia decorre inteiramente do fato de que ambos se importam um com o outro e colocam o outro em uma posição mais importante do que a deles próprios.

Desta vez, Ning Xiaoxiao não pôde contrariar seus desejos, então não teve escolha a não ser acompanhá-lo.

Após tomar banho e se trocar, ela se aconchegou nos braços de Lu Linyuan e o abraçou suavemente.

Ela fechou os olhos por um instante, depois sua mãozinha subiu até o rosto dele, acariciando-lhe os olhos suavemente e fazendo-o fechá-los novamente.

"Já que você disse que ficaria comigo, não pode simplesmente me deixar dormir enquanto você não fica, né? Não consigo dormir em paz com você desse jeito."

"Está bem, boa menina."

Lu Linyuan segurou sua pequena mão, puxou-a para debaixo das cobertas e então fechou os olhos para descansar.

Ele estava preocupado com os assuntos do tribunal e não conseguia dormir.

Mesmo de olhos fechados, ele continuava pensando nos assuntos de Estado.

Mas com Xiaoxiao ao seu lado, tudo era diferente.

Os nervos tensos de Lu Linyuan foram relaxando gradualmente ao sentir o leve aroma adocicado que emanava da garota.

Ele fechou os olhos, sua mente foi se clareando aos poucos, e o cansaço de ter passado a noite em claro o dominou repentinamente, e ele caiu num sono profundo.

Ele mal imaginava que aquele sono reparador, conquistado com tanto esforço, era inteiramente graças à sua esposa.

Ela está se tornando cada vez mais habilidosa no uso de códigos de trapaça para editar documentos.

Se ela quisesse que Lu Linyuan tivesse uma boa noite de sono, bastaria mudar duas palavras. Assim, não precisaria se preocupar com Lu Linyuan prejudicando sua saúde e poderia dormir em paz.

Quando os dois acordaram, já era crepúsculo.

Gu Sijin bateu à porta e chamou do lado de fora: — Majestade, Xiaoxiao, a hospedaria preparou o jantar. Já acordaram?

Lu Linyuan olhou para o céu nublado lá fora, pela janela. Ele próprio achou estranho ter conseguido dormir tão profundamente por tanto tempo.

Ning Xiaoxiao, aquela pequena glutona, virou-se e se aconchegou contra ele, choramingando docemente: "A-Yuan, estou com fome..."

Lu Linyuan ergueu a cabeça e esfregou a testa na ponta do nariz dela, depois a pegou no colo e a ajudou a se vestir. Enquanto a "ajudava", disse a Gu Sijin:

— Obrigado. Peça que tragam a comida. Xingran e os outros já voltaram?

Gu Sijin respondeu: — Acabaram de voltar. Estão pedindo uma audiência com Vossa Majestade.

Lu Linyuan: "Então vamos convidar todos e conversar enquanto comemos."

Lu Yiqiu, esse personagem animado, esquece todas as suas preocupações assim que chega a um lugar novo.

À tarde, enquanto Ning Xiaoxiao e Lu Linyuan dormiam, Chu Xingran e Ren Duanli saíram para investigar. Ele então arrastou Gu Sijin consigo para um passeio pela cidade de Chonghai.

Eles comeram inúmeros petiscos e, agora que ambos estavam satisfeitos, decidiram descer as escadas para ajudar na digestão.

Assim que a comida foi servida, Ren Duanli e Chu Xingran chegaram ao quarto de Lu Linyuan.

Os quatro comeram na mesma mesa, mas apenas Ning Xiaoxiao estava apreciando a refeição.

Ren Duanli: "Perguntei a muitas pessoas, e todas disseram que vivem bem na cidade de Chonghai. Eles têm colheitas abundantes todos os anos, e não têm dificuldade em ter o suficiente para comer e se vestir graças ao seu trabalho árduo."

Chu Xingran: "Não é diferente do que Sua Majestade viu hoje. Todas as pessoas só elogiam este lugar, sem qualquer queixa. Elas também agradecem especialmente ao Lorde Zhu, dizendo que o rápido desenvolvimento da cidade de Chonghai nos últimos anos se deve principalmente aos seus esforços. Superficialmente, o Lorde Zhu goza de grande prestígio em Chonghai e é muito querido."

Lu Linyuan sempre foi bom em captar os pontos principais.

Enquanto descascava camarões para Ning Xiaoxiao, ele perguntou com um sorriso: "Na superfície? Suas quatro palavras parecem bastante profundas."

Depois de alimentar o pequeno glutão com os camarões descascados e mergulhados em vinagre, ele olhou para Ren Duanli e perguntou:

— Diga-me, você considera boa a vida que leva?

Ren Duanli respondeu com sinceridade: — Tenho um cargo elevado e um bom salário, comida e roupas de sobra e a pessoa que amo ao meu lado... Não poderia estar melhor.

Então Lu Linyuan perguntou a Ning Xiaoxiao: "E você? Como você está?"

A boca de Ning Xiaoxiao estava cheia, fazendo-a parecer um pequeno hamster. "Ótimo! Quando posso comer comida deliciosa, sinto que a vida é perfeita!"

Lu Linyuan sorriu: "Sim, está tudo bem. Mas quando pergunto como você está, você só fala dos seus próprios sentimentos, da sua própria perspectiva. Não ouvi você dizer uma palavra sequer que todos esses dias bons são graças a mim e que você me é grata."

Chu Xingran e Ning Xiaoxiao compreenderam o significado por trás dessas palavras.

Só Ren Duanli, aquele cabeça-dura, achou que Lu Linyuan estava chateado por ele não o ter elogiado o suficiente, então imediatamente tentou se redimir:

"É claro que devo minha posição atual a Vossa Majestade..."

Antes que ele pudesse terminar de falar, as três pessoas à mesa caíram na gargalhada.

Chu Xingran deu um tapinha no ombro dele e ergueu uma sobrancelha, dizendo: "Sua Majestade não é esse tipo de pessoa pretensiosa. O que ele quis dizer com essa pergunta foi que a reação do povo da cidade de Chonghai foi anormal."

"Se fossem sinceros, poderiam simplesmente ter dito que estavam felizes com suas vidas. Por que quase todos tinham que elogiar Zhu Zhenshan?"

Ren Duanli então deu um tapa na própria coxa, percebendo: "É verdade! Zhu Zhenshan passa a maior parte do ano na capital. Embora a cidade de Chonghai esteja sob sua jurisdição, ele não vem aqui com frequência. Como é possível que as pessoas o elogiem tanto?"

"Será possível... que alguém tenha orquestrado isso com antecedência, tentando encenar uma farsa diante do Imperador?"

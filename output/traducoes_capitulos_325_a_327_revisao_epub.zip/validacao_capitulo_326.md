# Validação do capítulo 326

- **Original chinês:** `novel_capitulos_301_a_360(20261107-181903).docx`.
- **Tradução-base:** `novel capitulos 301 a 360 - ch.epub` (`index_split_025.html`).
- **Faixa de índices DOCX (base zero):** 1970–2033; unidades efetivas: 1970–2032.
- **Unidades textuais não vazias:** 61 no chinês; 61 na tradução-base; 61 no CSV.
- **Unidades com intervenção textual:** 8; índices relativos do capítulo: 0, 2, 23, 31, 35, 36, 48, 49.

## Decisões editoriais

Na chegada a Chonghai, o esperado quadro de miséria NÃO aparece: a prosperidade pública contrasta com a suspeita de encenação. Gu Sijin informa que os investigadores já voltaram; a resposta não se refere à própria chegada dela.

Foram mantidos os parágrafos na ordem do original. As correções incidiram sobre os trechos identificados e a terminologia de continuidade; permanecem trechos do EPUB inalterados.

## Alcance e limitações

**Alinhamento estrutural integral, revisão semântica dirigida.** O cotejo 1:1 não prova equivalência semântica de cada frase nem ausência de omissões internas. Não foi realizada uma retradução integral independente do chinês. Erros de nuance e sentido podem persistir nos trechos conservados do EPUB.

## Verificações

- CSV em UTF-8 com índices absolutos do DOCX preservados.
- Título e todas as unidades não vazias incluídos.
- Markdown e CSV usam a mesma versão revista.

# Validação do capítulo 325

- **Original chinês:** `novel_capitulos_301_a_360(20261107-181903).docx`.
- **Tradução-base:** `novel capitulos 301 a 360 - ch.epub` (`index_split_024.html`).
- **Faixa de índices DOCX (base zero):** 1898–1969; unidades efetivas: 1898–1968.
- **Unidades textuais não vazias:** 69 no chinês; 69 na tradução-base; 69 no CSV.
- **Unidades com intervenção textual:** 18; índices relativos do capítulo: 0, 3, 4, 5, 6, 8, 10, 12, 41, 53, 54, 55, 56, 57, 63, 64, 65, 67.

## Decisões editoriais

A intervenção de Ning ocorre durante a pausa temporal; os bandidos estão montados, não possuem cabeça de cavalo. O sistema esconde informações sobre os acontecimentos futuros, e o índice acumulado permanece em 73%. O original usa quase cem li, não 160 km.

Foram mantidos os parágrafos na ordem do original. As correções incidiram sobre os trechos identificados e a terminologia de continuidade; permanecem trechos do EPUB inalterados.

## Alcance e limitações

**Alinhamento estrutural integral, revisão semântica dirigida.** O cotejo 1:1 não prova equivalência semântica de cada frase nem ausência de omissões internas. Não foi realizada uma retradução integral independente do chinês. Erros de nuance e sentido podem persistir nos trechos conservados do EPUB.

## Verificações

- CSV em UTF-8 com índices absolutos do DOCX preservados.
- Título e todas as unidades não vazias incluídos.
- Markdown e CSV usam a mesma versão revista.

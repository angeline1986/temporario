# Capítulo 55 — O tirano se preocupa com ela às escondidas

Ning Xiaoxiao passou três minutos inteiros distribuindo socos e pontapés. Diante da Consorte Nobre, já toda inchada e coberta de hematomas, soltou:

— Acha que é grande coisa? Desça desse pedestal!

Então, sem hesitar, apertou Retroceder.

Três minutos antes.

Lu Linyuan saiu das sombras e bradou: — Comigo aqui, quem ousa tocar nela?

Todos fizeram uma reverência. — Que Sua Majestade tenha dez mil bênçãos e paz!

A Consorte Nobre foi a primeira a se aproximar. Agarrou o braço dele e começou a fazer dengos com uma voz artificialmente fina:

— Majestaaade! Olhe só a Atendente Gu! Eu, de tão boa vontade, fui devolver a pulseira, mas ela a deixou cair sem querer e agora quer pôr a culpa em mim! Estou tão magoadinha... Dá vontade de chorar!

Lu Linyuan afastou a mão dela com rigidez. — Se tem algum problema na garganta, vá se tratar. E fique longe de mim. Não quero pegar isso.

O sorriso da Consorte Nobre congelou no rosto.

Gu Sijin, por sua vez, era perspicaz.

A pulseira já estava quebrada, e era improvável que Lu Linyuan punisse severamente a Consorte Nobre por causa de uma simples joia.

Se fizesse uma denúncia naquele momento, além de não conseguir justiça para Ning Xiaoxiao, ainda poderia atrair a inimizade da Consorte Nobre.

Então declarou respeitosamente: — Majestade, fui desajeitada e não consegui segurar a pulseira que Sua Alteza me entregou. Ela caiu por minha culpa. Peço perdão por ter perturbado Sua Majestade.

A Consorte Nobre lançou-lhe um olhar e sorriu com arrogância: — Já que sabe onde errou, trate de corrigir isso. Afinal, você também serve ao imperador. Não fica bem ser tão desastrada.

Enquanto as duas discutiam, Ning Xiaoxiao estava estranhamente calada.

Agachada no chão, tinha os olhos avermelhados, como um coelhinho branco maltratado.

Ia recolhendo um a um os fragmentos da pulseira e guardando-os num lenço.

As lascas de jadeíta eram afiadas. Sem querer, cortou a mão.

Lu Linyuan franziu ligeiramente a testa, quase de modo imperceptível. Não disse nada; simplesmente se agachou para ajudá-la.

Ao perceber uma sombra cair sobre si, Ning Xiaoxiao ergueu a cabeça e deu de cara com o rosto absurdamente perfeito de Lu Linyuan, como se tivesse sido esculpido por um artista digital.

A pinta vermelho-cinábrio junto ao olho dele parecia ainda mais viva.

Ela paralisou por um instante e gaguejou: — M-Majestade?

Lu Linyuan manteve os olhos nos cacos. Seus dedos longos os apanhavam com todo o cuidado e os depositavam no lenço de Ning Xiaoxiao.

Delicadeza e ternura nunca deveriam constar da descrição daquele personagem.

No entanto, ao vê-lo agachado diante dela, recortado pela luz que vinha de trás, Ning Xiaoxiao sentiu o coração acelerar por um instante.

Até a Consorte Nobre e Gu Sijin interromperam a discussão e olharam, juntas, para os dois.

Quando terminou de apanhar os fragmentos, Lu Linyuan se levantou como se nada tivesse acontecido e comentou num tom perfeitamente audível:

— Essa jadeíta tem uma qualidade extraordinária. Uma pena que tenha se partido. Se estivesse inteira, eu até poderia pedi-la para apreciá-la.

Ning Xiaoxiao: "..."

【Então você passou esse tempo todo me ajudando só para examinar a qualidade da jadeíta, é isso?】

Mas, pensando melhor, ela também não tinha por que reclamar.

Afinal, ele não era obrigado a ajudá-la.

Lu Linyuan voltou-se para a Consorte Nobre. — Destruir uma jadeíta tão bela é um desperdício imperdoável!

— Majestade... A própria Atendente Gu admitiu que foi um acidente dela, não foi...

— Não me interessa o que os outros dizem. Acredito no que vi com meus próprios olhos. Assisti à discussão inteira daqui. Vi como você atormentou a Atendente Gu e como deixou a pulseira cair de propósito! Volte ao seu palácio e reflita sobre seus atos por quinze dias. Sem minha ordem, não poderá dar um passo para fora do Palácio Yaohua.

Terminada a sentença, ele se afastou sem olhar para trás, ignorando os dengos e súplicas da Consorte Nobre.

À primeira vista, parecia apenas lamentar a perda de uma jadeíta extraordinária.

Mas que tesouro um imperador nunca teria visto?

Naturalmente, a Consorte Nobre concluiu que ele a punira para proteger Gu Sijin.

Lançou à Atendente Gu um olhar venenoso. — Ainda teremos muitos dias neste palácio. Terei tempo de sobra para acertar as contas com você!

Depois que ela partiu, Gu Sijin ajudou Ning Xiaoxiao a se levantar. — Xiaoxiao, sei que a pulseira foi um presente da sua mãe. Pelo que aconteceu hoje, peço desculpas em nome de Cailian.

A pulseira já estava destruída e Ning Xiaoxiao ainda precisava se manter próxima de Gu Sijin. Não havia muito o que dizer.

Mas Cailian, além de ter se aproveitado da situação, ainda teve a desfaçatez de comentar com sarcasmo: — É só uma pulseira velha! Nossa senhora já pediu desculpas. Por que continua com essa cara feia?

— Cailian, cale-se! — Gu Sijin a repreendeu duramente. — O que você fez hoje foi longe demais. Ajoelhe-se aqui por uma hora inteira. Reflita sobre onde errou e sobre o que pode ou não fazer daqui em diante. Só depois volte ao palácio!

— Senhorita...

— Não me chame de senhorita! Estamos no palácio imperial, não na residência da família Gu.

Cailian nunca imaginara que a sempre gentil e serena Gu Sijin se enfureceria tanto por causa de Ning Xiaoxiao.

Primeiro lhe dera uma bofetada; agora a obrigava a se ajoelhar no caminho, passando vergonha diante dos outros.

Sentindo-se injustiçada, começou a soluçar, de olhos vermelhos. — Antes, minha senhora nunca falava comigo desse jeito...

Gu Sijin respondeu com severidade: — Se eu não for dura com você hoje, amanhã será outra pessoa quem mandará espancá-la até a morte. Fique aqui e pense muito bem no que fez.

Então tomou Ning Xiaoxiao pela mão e foi embora.

Ajoelhada no chão, Cailian observou as duas se afastarem e caiu num choro inconsolável.

Assim que voltaram ao Palácio Zhongcui, desabou uma tempestade inesperada.

Ao saber que Cailian continuava ajoelhada no caminho, Qiqi e as outras criadas perguntaram a Gu Sijin: — Minha senhora, a chuva está muito forte. Não seria melhor permitir que Cailian voltasse?

Gu Sijin a castigava justamente porque se importava com ela. Embora sofresse ao imaginá-la naquela situação, não cedeu. — Eu disse uma hora, e será uma hora. Faço isso para o bem dela. Se hoje teve coragem de roubar Xiaoxiao, amanhã roubará de mim e depois poderá tentar a mesma coisa no palácio da Consorte Duan. Se eu não a fizer aprender a lição agora e continuar deixando que se comporte assim, aí sim estarei prejudicando-a.

Mais tarde, Gu Sijin consolou Ning Xiaoxiao por um bom tempo e lhe ofereceu sua própria pulseira de jade vermelha.

Era uma joia que Gu Sijin usava todos os dias, e estava claro o quanto gostava dela.

Ning Xiaoxiao tentou recusá-la, mas Gu Sijin insistiu: — Aceite, senão não terei paz. Sei que o presente que sua mãe deixou e que você trouxe para o palácio era uma lembrança preciosa. Hoje a Consorte Nobre o destruiu. Cailian tem culpa, e eu também.

Ning Xiaoxiao não respondeu.

A seu ver, o castigo dado a Cailian era leve demais.

Gu Sijin podia continuar bancando a santa se quisesse; Ning Xiaoxiao não tinha intenção de mimar aquela criada.

Aquela desgraçada da Cailian... Mais cedo ou mais tarde, Ning Xiaoxiao encontraria uma oportunidade de fazê-la pagar de modo terrível, até não sobrar um pedaço inteiro do corpo!

Gu Sijin ainda tentou convencê-la por algum tempo, mas Ning Xiaoxiao estava com dor de cabeça e sem vontade de conversar. Disse que tinha sono e queria descansar um pouco.

Pouco depois que Gu Sijin saiu, Qiqi apareceu para visitá-la.

— Xiaoxiao, soube que você cortou a mão. Tenho aqui um pó cicatrizante de ótima qualidade. Use.

E lhe entregou um pequeno frasco de porcelana branca.

Na dinastia Qi, aquele remédio para ferimentos valia seu peso em ouro. Nem o salário anual de Qiqi pagaria uma garrafa. Como ela havia conseguido aquilo?

Mas Qiqi foi embora assim que entregou o presente. Quando Ning Xiaoxiao se levantou para perguntar, ouviu Qiqi cochichando com Qiaqia do lado de fora:

— Por que será que o eunuco Sanfu não entregou pessoalmente o remédio a Xiaoxiao? E ainda insistiu para você dizer que era seu?

— Vai saber! Talvez o eunuco Sanfu esteja apaixonado por Xiaoxiao!

Ning Xiaoxiao escutou tudo pela fresta da porta, olhou novamente para o frasco sobre a mesa e estremeceu.

【E se eu aceitar esse remédio e, outro dia, ele vier com aquele papo de “não há como retribuir tamanha bondade, a não ser me entregando em casamento”? Nem pensar! Não vou me casar com um eunuco!】

Com isso em mente, pegou o frasco e foi direto para o Palácio Chaoyang.

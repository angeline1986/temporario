# Capítulo 54 — Comigo aqui, quem ousa tocar nela?

A pequena confusão logo passou. Assim que terminou a cerimônia de cumprimentos, Gu Sijin mal havia deixado o Palácio Fengluan quando se virou para Cailian, muito séria:

— Nunca lhe dei uma pulseira de jadeíta. De onde veio aquela que você estava usando?

Cailian gaguejou: — F-foi... pedi ao eunuco Shun que comprasse para mim quando saísse do palácio.

— É mesmo? — Gu Sijin a interrogou. — Mas tenho a impressão de ter visto Xiaoxiao usando essa pulseira nos últimos dias. Diga a verdade: de onde ela veio?

— Eu... eu dei dinheiro ao eunuco Shun e pedi que a comprasse.

Embora insistisse na mentira, seu rosto transtornado denunciava a culpa.

Gu Sijin agarrou-lhe o pulso e ordenou com firmeza: — Muito bem. Então venha comigo procurar o eunuco Shun. Vamos esclarecer isso agora!

— Senhorita! Ai, senhorita! — Cailian se debateu para se soltar e, segurando o pulso, murmurou: — Fui eu que peguei a pulseira dela emprestada para usar... Mas aquela jadeíta é tão fina que até a Consorte Nobre a cobiçou! Como uma criada poderia pagar por algo assim? Vai ver foi ela quem roubou...

*Pá!*

Antes que terminasse, Gu Sijin lhe desferiu uma bofetada.

Encarou-a, com os lábios trêmulos: — Como você se tornou assim? Tem ideia do que está fazendo?

Com a mão sobre a face ardente, Cailian se sentiu injustiçada: — Senhorita... você me bateu por causa dela? Nunca tinha me batido antes...

— Não bati em você por causa dela. Bati em nome da sua mãe! Antes de morrer, ela confiou você à nossa família Gu. Todos esses anos, tratei você como minha irmã mais nova. É por isso que me dói tanto! Hoje você rouba uma coisa. Amanhã fará o quê? Vai assaltar alguém?

— Senhorita... sei que errei. Por favor, não fique zangada...

Gu Sijin ficou com dor de cabeça de tanta raiva. — Venha comigo. Vamos pedir à Consorte Nobre que devolva a pulseira!

Praticamente arrastou Cailian pela avenida do palácio. Dobrou três esquinas, atravessou dois portões e enfim alcançou o cortejo da Consorte Nobre.

Ao ouvir a movimentação, a Consorte Nobre ergueu a cortina de sua liteira e lançou-lhes um olhar. — O que foi?

Gu Sijin disse: — Vossa Alteza, essas lichias da variedade Sorriso da Concubina foram presenteadas pela imperatriz. Já recebi minha parte; não seria correto aceitar também a de Vossa Alteza.

Enquanto falava, Cailian entregou um saco de lichias aos serviçais da Consorte Nobre. Gu Sijin prosseguiu: — Há mais uma coisa. A pulseira que Cailian usava hoje não é dela. Pertence a outra criada do meu palácio, um presente deixado por sua mãe e muito precioso para ela. Por isso... poderia Vossa Alteza devolvê-la a mim?

— Outra criada? Aquela tal de Xiaoxiao?

— Sim, Vossa Alteza.

— Hã! — A Consorte Nobre soltou um riso frio, tirou a pulseira do pulso e a ergueu contra a luz do sol. — Atendente Gu, você acha que uma pessoa como ela merece algo tão bom?

— Mereça ou não, é uma lembrança que sua mãe lhe deixou. Imploro a Vossa Alteza que a devolva. Também trouxe muitas joias da casa de minha família; depois posso levá-las ao seu palácio para que escolha as que desejar.

A Consorte Nobre escarneceu: — Ora, veja só! Sou uma Consorte Nobre. Acha que preciso pedir joias a uma simples Atendente? Já que quer tanto a pulseira de volta, eu a devolvo.

Estendeu a mão com a pulseira. Mas, bem quando Gu Sijin ia pegá-la, soltou-a de repente.

A pulseira caiu e se partiu em vários pedaços com um estalo.

A Consorte Nobre suspirou teatralmente: — Ah, que pena! Quebrou.

---

Quinze minutos antes, no Palácio Zhongcui.

Ning Xiaoxiao havia dormido demais. Ao acordar, descobriu que sua pulseira desaparecera.

Tinha certeza de tê-la deixado à cabeceira antes de dormir, mas todos os criados a quem perguntou disseram que não a tinham visto.

Bengbeng comentou: — Ontem, quando me levantei à noite para ir ao banheiro, acho que vi Cailian saindo às pressas da direção do seu quarto. Será que foi ela que roubou?

Quem mais poderia ter sido?

Ning Xiaoxiao nem perdeu tempo se lavando. Trocou de roupa e correu para o Palácio Fengluan.

Só que, quando encontrou a Consorte Nobre e Gu Sijin no caminho, a pulseira já estava despedaçada.

Apertou desesperadamente o botão Retroceder, mas ele só permitia voltar três minutos. E três minutos antes a pulseira já estava quebrada.

Para ela, aquela pulseira não era apenas uma jadeíta rara e preciosa. Era o elo afetivo que ainda a ligava à família.

Depois de tanto esforço para trazê-la do mundo moderno àquela época, Cailian a roubara e a Consorte Nobre a destruíra assim, sem mais nem menos?

Toda a tristeza de Ning Xiaoxiao se transformou em fúria. Prestes a chorar de desespero, mordeu os lábios com força e avançou até o grupo que discutia.

Ao vê-la chegar enfurecida, Gu Sijin a segurou depressa. — Xiaoxiao, a pulseira já está quebrada. Diga o que deseja e eu compensarei você em nome de Cailian. Vamos voltar primeiro ao palácio.

A expressão de Ning Xiaoxiao era a de quem queria matar a Consorte Nobre. Gu Sijin temia que ela cometesse alguma loucura, irritasse a mulher e acabasse perdendo a própria vida.

Mas, quando Ning Xiaoxiao perdia a cabeça, nem nove bois a fariam mudar de ideia.

Ao perceber o olhar furioso, a Consorte Nobre endureceu a voz: — Criada insolente! Por que está me encarando?

Cailian também sussurrou: — Ning Xiaoxiao, peça desculpas a Sua Alteza! Não arraste a senhorita e a mim para essa confusão!

Ning Xiaoxiao já tinha feito seus planos. Talvez não pudesse de fato fazer nada contra a Consorte Nobre, mas podia enchê-la de pancadas, espancá-la até não aguentar mais!

Bastava manter tudo dentro de três minutos. Assim poderia repetir a cena à vontade e descarregar a raiva primeiro!

Irritada com aqueles olhos que não paravam de encará-la, a Consorte Nobre ordenou: — Guardas! Arrastem essa criada daqui e deem-lhe uma surra!

Os serviçais avançaram em massa. Ning Xiaoxiao ia apertar Retroceder quando Gu Sijin a puxou com força para trás de si, interrompendo-a antes que pudesse executar o plano.

Gu Sijin abriu os braços, protegendo Ning Xiaoxiao como uma galinha que defende o pintinho sob suas asas.

— Vossa Alteza! O que Xiaoxiao fez de errado? A única lembrança que a mãe lhe deixou acaba de ser quebrada! Vossa Alteza ainda pretende espancá-la até a morte?

— Saia da frente!

— Vossa Alteza não pode bater nela! Ela pertence ao meu palácio. Se realmente acha que ela errou, então bata primeiro em mim!

A Consorte Nobre soltou um riso de desprezo: — É a primeira vez que ouço um pedido tão miserável. Guardas, batam nas duas, senhora e criada!

Lu Linyuan, parado num canto, assistia a tudo.

Vira como a Consorte Nobre humilhara Gu Sijin e também compreendera o quanto aquela pulseira significava para Ning Xiaoxiao.

Por isso, ergueu a voz: — Comigo aqui, quem ousa tocar nela?!

A *ela* se referia a Ning Xiaoxiao.

Mas, como Gu Sijin estava à frente protegendo-a, todos presumiram que o imperador se irritara por causa de Gu Sijin.

Todos olharam ao mesmo tempo para Lu Linyuan. Aproveitando a distração, Ning Xiaoxiao agarrou a Consorte Nobre pelos cabelos, arrancou-a da liteira e começou a bater a testa dela no chão.

Sem perder tempo com discursos, entregou-se à sua especialidade: descer a mão em megeras. Os presentes ficaram petrificados, enquanto a Consorte Nobre gritava por socorro:

— Majestade! Majestade, salve-me!

— Nem o próprio rei dos céus conseguiria salvar você hoje! — Ning Xiaoxiao montou sobre ela e intensificou os golpes.

Afinal, só tinha três minutos para bater. Precisava aproveitá-los muito bem!

Lu Linyuan testemunhou a cena, de queixo caído.

*Que mulher selvagem...*

*E por que... parece que estou gostando disso?!*

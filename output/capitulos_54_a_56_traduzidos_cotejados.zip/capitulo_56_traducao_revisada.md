# Capítulo 56 — Então Sua Majestade acha que eu valho menos que um animal?

Palácio Chaoyang.

Lu Linyuan, ocupado examinando memoriais, ouviu movimento no salão e perguntou sem levantar a cabeça: — Entregou a coisa?

Sanfu fez uma reverência e respondeu: — Conforme as ordens de Vossa Majestade, entreguei o remédio a uma criada do pavilhão leste do Palácio Zhongcui e pedi que dissesse que o frasco era dela.

— Hum.

— Há mais uma coisa... Levei o desenho que Vossa Majestade fez aos artesãos da Oficina Imperial. Eles disseram que não há lá nenhuma pulseira parecida.

— Se não há, que fabriquem uma! — Lu Linyuan perdeu a paciência. — Mandei você conseguir uma pulseira idêntica, não voltar para jogar o problema em cima de mim!

— Peço perdão, Majestade! Vou providenciar imediatamente.

Sanfu recuou respeitosamente, pronto para fazer outra visita à oficina.

Mal saiu do salão principal, encontrou Ning Xiaoxiao atravessando o pátio a passos apressados.

Aproximou-se curvado, com um sorriso bajulador: — Xiaoxiao, o que a traz aqui?

Ao ver o rosto cheio de rugas que se formavam quando ele sorria, Ning Xiaoxiao estremeceu. — Eunuco Sanfu, daqui para a frente prefiro que me chame pelo nome completo.

Ela enfiou à força o frasquinho de porcelana branca nas mãos dele. — É valioso demais. Não posso aceitar.

Sanfu ficou perplexo. — Mas... mas não fui eu quem lhe deu! Você...

— Não precisa fingir, senhor. Ouvi Qiqi dizer que foi você quem lhe entregou o remédio. Meu machucado não é grave e não precisa de uma medicina tão cara. Agradeço a gentileza.

Devolvido o frasco, virou-se para ir embora.

Só que Sanfu entrou em pânico.

Lu Linyuan o encarregara de fazer o remédio chegar às mãos de Ning Xiaoxiao para que ela o usasse.

Agora ela o estava devolvendo. Se o tirano soubesse, não arrancaria a pele de Sanfu?

Desesperado, ele segurou o braço de Ning Xiaoxiao. — Xiaoxiao, fique com este remédio...

— Comporte-se, eunuco Sanfu! — Ning Xiaoxiao reagiu com intensidade, arrancando o braço das mãos dele. — A esta altura, não tenho medo de ser sincera. Reconheço toda a bondade com que me trata, mas nós dois... não combinamos.

Sanfu ficou com um ponto de interrogação estampado na cara. — Do que você está falando?

【Droga, preciso mesmo falar com todas as letras?】

— Estou dizendo que nós não combinamos! — Ning Xiaoxiao decidiu ser explícita. — Admito que o senhor é uma boa pessoa, mas eu sou uma mulher comum. Tenho desejos... carnais. Entende?

— Desejos mundanos? Claro que entendo! Eu também tenho.

Sanfu estava falando de comida, bebida, diversão e dinheiro. Ning Xiaoxiao se referia a namoro, romance e intimidade. Os dois estavam em frequências completamente diferentes.

Assim, quando ele disse que também tinha esses desejos, ela não conseguiu evitar uma olhadela para a região entre as pernas dele. Então comentou, constrangida:

— Sim, o senhor até pode ter... mas isso não adianta, entende? Enfim, procure outra pessoa. Eu... ainda quero ser mãe um dia...

Sanfu: ￣□￣｜｜

Só então ele percebeu o que Ning Xiaoxiao queria dizer e soltou uma risada entre espanto e incredulidade.

— Ah, então era disso que estava falando? Minha nossa, que mal-entendido enorme!

Ning Xiaoxiao era a mulher por quem Lu Linyuan se interessava. E agora estava achando que Sanfu queria formar com ela um casal de companheiros palacianos, um casamento informal envolvendo eunucos. Era um mal-entendido dos grandes!

Diante disso, só lhe restava puxar Ning Xiaoxiao para um canto e esclarecer tudo.

— Escute bem. Esse remédio não é um presente meu. Na verdade, tudo foi ideia do imperador.

【Ideia daquele imperador maldito? Ele teve um ataque de loucura? Por que me daria um remédio para ferimentos do nada?】

— O imperador? Por que ele me daria um remédio desses?

Sanfu tapou a boca para esconder uma risadinha e lhe lançou um olhar cheio de insinuação. — Ora, ainda não entendeu?

Ele já ia contar tudo sem rodeios quando uma voz gelada soou atrás deles:

— Sanfu, por que o remédio que mandei entregar a ela ainda está em suas mãos?

Os dois se viraram juntos. Lu Linyuan estava atrás deles sem que tivessem percebido, fitando-os com olhos penetrantes de falcão.

Sanfu gaguejou: — M-Majestade, eu estava justamente prestes a entregá-lo...

— Incompetente! — Lu Linyuan lhe aplicou uma sonora bofetada com as costas da mão, tomou o frasco de porcelana e o estendeu a Ning Xiaoxiao. — Você. Pegue.

— Hã?

Ning Xiaoxiao ficou pasma.

【O que deu nele? Então foi mesmo ele quem me deu o remédio? Eu...】

Enquanto sua imaginação disparava, ouviu o tirano dizer, com aquela voz grave e sedutora, algo de uma falta de humanidade inacreditável:

— Estes dias de calor extremo estão castigando a todos. Se o cavalo Caonima ficar muito tempo sob o sol, a pele pode ressecar e rachar. Leve este remédio, examine-o com cuidado e aplique nas feridas que encontrar.

— Nele? Majestade... ouvi dizer que esse pó medicinal custa uma fortuna. Não é um desperdício usá-lo num cavalo?

Lu Linyuan riu com frieza. — Desperdício, se for usado nele? Por acaso deixaria de ser desperdício se fosse usado em você? Está questionando minhas ordens?

— Ah! Eu jamais ousaria, Majestade...

【Então esse remédio não é para mim, mas para Caonima?】

【Quer dizer que fiquei me iludindo esse tempo todo e nem sequer valho tanto quanto um cavalo?】

【Espere... por que diabos estou me comparando com um animal?】

Ainda assim, ela estava realmente irritada.

Irritada porque Lu Linyuan parecia se importar mais com aquele cavalo do que com ela.

Pensando melhor, porém, na antiguidade, a vida de um servo do palácio muitas vezes valia menos que a de um animal criado por seus senhores.

Com toda a deferência, recebeu o frasco das mãos de Lu Linyuan. — Pode ficar tranquilo, Majestade! Vou cuidar muito bem das feridas de Caonima!

【Vou cuidar é uma ova! Aquele cavalo tem tanto pelo e o couro tão grosso que não vai se queimar no sol coisa nenhuma! Um remédio tão caro... Assim que voltar, vou passar tudo nos meus próprios machucados! Só para morrer de raiva!】

Ao ouvir seus pensamentos, os lábios de Lu Linyuan se curvaram num sorriso quase imperceptível.

*Hã. Sua bobinha.*

Sanfu acompanhou com os olhos Ning Xiaoxiao se afastando e sorriu para o imperador. — Majestade, o senhor adora brincar com ela! Eu só estava... Ai!

*Pá!*

Antes de terminar, Sanfu levou outra bofetada de Lu Linyuan. O sorriso morreu em seu rosto.

— Eu já disse que ela não poderia saber que fui eu quem mandou o remédio. Minhas ordens entram por um ouvido e saem pelo outro?

— Majestade, reconheço meu erro... — Sanfu ajoelhou-se, segurando as orelhas. Conhecia muito bem as regras habituais de Lu Linyuan.

Se dissesse algo indevido, devia se esbofetear oitenta vezes.

Desta vez, porém, mal dera a primeira bofetada quando Lu Linyuan mandou parar. — Não fique aqui se esbofeteando. Vá à Oficina Imperial. Dê suas bofetadas lá enquanto apressa os artesãos a fabricar minha pulseira.

Sanfu: "..."

Lu Linyuan se felicitou em silêncio pela própria esperteza.

Se não tivesse ouvido os pensamentos de Ning Xiaoxiao lá de dentro do salão, nem saberia que ela chegara.

Se não tivesse saído a tempo, Sanfu acabaria deixando escapar que era ele, Lu Linyuan, quem se preocupava com ela. E onde iria parar sua dignidade imperial?

*Hum?*

*Espere um instante...*

*Por que diabos estou me preocupando com ela?*

# Validação — capítulo 108

- **Fonte primária:** `novel_capitulos_61_a_120(20261103-205857).docx`, chinês tradicional.
- **Limites de parágrafos (índices reais de `python-docx`, base zero):** 3468 até 3531; capítulo seguinte começa em 3532.
- **Unidades não vazias, incluindo título:** 61.
- **Linhas do cotejo:** 61.
- **Unidades sem tradução:** 0.
- **Índices excedentes:** 0.
- **Cotejo:** correspondência estrutural 1:1 preservada, por unidade do DOCX.

## Observações editoriais

A imperatriz incentiva indiretamente a Concubina Shen a atingir Gu Sijin, sem lhe dar uma ordem explícita. A fala de Lu Linyuan sobre uma relação íntima é uma provocação: não transformá-la em confirmação. O capítulo encerra com o pedido de mudança de tratamento.

## Limitações da validação

A tradução foi revisada durante a redação e verificada estruturalmente, mas **não recebeu uma segunda auditoria linguística independente**; igualdade de contagem não demonstra, por si só, ausência de erros semânticos internos.

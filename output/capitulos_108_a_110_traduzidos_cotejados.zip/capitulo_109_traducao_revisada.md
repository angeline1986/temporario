# Capítulo 109 — Eu só queria abraçar você. Não posso?

Então era esse o tipo de cantada melosa dos protagonistas de dramas históricos?

Que vontade de vomitar...

Por que, quando assistia a séries, bastava o protagonista dizer algo parecido para ela apertar o pacote de salgadinhos e gritar, eufórica, que torcia pelo casal? Agora que tinha um homem de carne e osso dizendo aquilo na sua frente, não sentia entusiasmo algum. Só um constrangimento tão grande que queria abrir um buraco no chão e desaparecer.

Por isso, mudou de assunto: — Majestade, Vossa Majestade fez uma coisa tão descarada... quer dizer, aproveitou-se de mim enquanto eu dormia. Não tem medo de sofrer as consequências?

— Consequências? — Lu Linyuan riu com desprezo. — Tudo o que existe nesta Cidade Imperial me pertence. Desde o dia em que entrou no palácio, você passou a ser alguém de quem posso dispor para meu divertimento quando quiser.

Ele achava que aquela frase o fazia parecer imponente. Aos olhos de Ning Xiaoxiao, porém, era só um idiota com síndrome de protagonista de desenho animado.

Ela fingiu admiração, aplaudindo: — Uau! Que incrível, Majestade!

【Então as galinhas, os patos, os gansos, cavalos, porcos, cachorros e bois do palácio também são seus! E Sanfu, Xiao Yinzi, Xiao Kangzi e Xiao Fuzi também! Ninguém vai disputar com você! Pode dormir com todos, um por um, que eu fico do lado aplaudindo!】

Lu Linyuan: — ...

— E ainda fala em castigo? Castigo é punição dos Céus. Eu sou o Filho do Céu. Quem ousaria me punir?

Os Céus passaram por ali, lançaram um olhar ao mundo mortal e, vendo tanta arrogância, murmuraram: 【Nossa, como você é valentão...】

BRUUUM!

O céu retumbou, e um raio despencou sem aviso, atravessando o telhado dourado do Palácio Chaoyang e abrindo um buraco no chão a menos de uma *zhang* de Lu Linyuan.

O susto foi tamanho que o imperador saiu correndo feito um rato em fuga, saltou na direção de Ning Xiaoxiao e se pendurou nela.

Ning Xiaoxiao ￣□￣||: — Majestade... Vossa Majestade não disse que não tinha medo?

— Q-quem disse que eu tive medo?!

— Se não teve medo, por que está me abraçando?! Por que se pendurou em mim?!

— Eu... Eu só queria abraçar você! Não posso?!

— ...

Por que aquilo soou tão digno de pena?

E como ele conseguia ser um pouquinho fofo?

Ning Xiaoxiao simplesmente não sabia mais o que fazer com aquele *old dog king* sem um pingo de vergonha na cara.

Estava dentro de um livro ambientado na antiguidade. Não podia avaliar a maneira de pensar dos antigos pelos padrões da sociedade moderna.

Ainda não sabia que bicho havia mordido Lu Linyuan para que supostamente dormisse com ela naquela noite. Além da raiva, também sentia um certo inconformismo.

【Droga! Já que ia acontecer, custava escolher um momento em que eu estivesse consciente para sentir alguma coisa?!】

【Era a minha primeira vez, poxa! Com um “21”, poxa! Nem podia resistir, nem pude aproveitar nada! Vai se ferrar!】

Lu Linyuan: — ...

Por que parecia que ela estava até ansiosa por aquilo?

Ele soltou Ning Xiaoxiao e, por instinto, recuou dois passos para ficar longe dela.

Afinal, meninos também precisam se proteger quando saem de casa.

Ning Xiaoxiao começou a tentar convencer a si mesma:

【Bom, ser concubina é melhor que ser criada. Como criada, todo dia alguém pisa em mim. Como concubina, pelo menos a vida deve ser mais confortável: não preciso varrer nem limpar mesa, e ainda recebo dinheiro. Pensando bem, talvez não seja tão ruim. Desde que a pequena Gu não fique brava, tudo bem.】

【Só que...】 Ela acariciou o baixo-ventre, ainda incomodada. 【Eu não estava pronta para ser mãe tão cedo... Mas agora que aconteceu, a criança não tem culpa de nada. O imperador pode ser um cachorro, mas o bebê com certeza não vai puxar a ele!】

【Ouvi dizer que, depois da investidura, vêm os presentes. Estou precisando de dinheiro; assim que esse imperador maldito me recompensar, vou mandar vender tudo fora do palácio. Deve dar para comer à vontade por um bom tempo... Ah, mas meu estoque de cabelo está acabando...】

Seu olhar foi se deslocando lentamente para Lu Linyuan, fixando-se na cabeça dele com uma cobiça que ela nem tentava disfarçar.

— Majestade, quer lavar o cabelo?

Lu Linyuan sentiu o couro cabeludo se contrair. — Não quero! Vá procurar o que fazer bem longe daqui!

*

Quando Ning Xiaoxiao voltou ao Palácio Zhongcui, todos os criados a cercaram para parabenizá-la, radiantes: agora ela era uma senhora de verdade.

Não vendo Gu Sijin, perguntou: — Onde está a minha senhora?

Qiqi respondeu: — Ela voltou há pouco, mas logo saiu outra vez. Não deixou ninguém acompanhá-la, então não sabemos aonde foi.

— E... quando ela voltou, parecia aborrecida?

Ning Xiaoxiao ainda estava apreensiva. Temia que Gu Sijin a culpasse.

Qiaqia respondeu: — Não notei nada diferente. Estava igual a sempre.

Depois, o decreto de sua nomeação chegou ao Palácio Zhongcui. Vários criados vieram pôr o pavilhão lateral oeste em ordem. Ning Xiaoxiao passou o resto do dia ocupada, pensando em explicar tudo direitinho a Gu Sijin quando ela voltasse à noite.

Quando trocaram todos os móveis e adornos do pavilhão oeste, finalmente chegou o momento que Ning Xiaoxiao mais esperava.

Os criados do Departamento de Assuntos Internos chegaram trazendo os presentes concedidos por Lu Linyuan.

Uma procissão de servidores carregava bandejas de madeira preciosa, com adornos dourados, cada qual repleta de presentes cobertos por tecido vermelho.

Pelos volumes sob os panos, Ning Xiaoxiao começou a adivinhar:

【Esse comprido deve ser um cetro *ruyi* de jade, não é?】

【Aquele redondo, enorme, deve ser um bloco de jade bruto para entalhar e montar joias.】

【E aquelas dez ou mais bolinhas de tamanhos diferentes, lá na ponta... quem sabe um colar de turmalinas!】

【Finalmente esse imperador cachorro resolveu agir como gente! Qualquer um desses presentes deve render uma fortuna se eu vender fora do palácio!】

【Fiquei rica! Fiquei rica!】

Esfregou as mãos, empolgada, sentindo a alegria de quem está prestes a abrir uma caixa-surpresa.

O funcionário do Departamento de Assuntos Internos anunciou os prêmios, enquanto os criados retiravam um a um os panos vermelhos:

— Sua Majestade concede duas conservas de pepino azedo de Sumatra, duas melancias verdes de Java, três cachos de uvas estragadas das terras orientais e um saco de batatas brotadas do sul de Yunnan...

Ning Xiaoxiao encarou aqueles “tesouros”, petrificada.

Lu Linyuan continuava sendo um cachorro, o maior cachorro do mundo, o próprio imperador dos cachorros!

E o pequeno eunuco encarregado da entrega também parecia ter algum problema na cabeça. Depois de anunciar os presentes, ainda perguntou: — Dama Ning, está satisfeita com as recompensas de Sua Majestade?

Satisfeita uma ova, seu desgraçado!

Ela forçou um sorriso. — Satisfeitíssima! — Pegou os dois pepinos de Sumatra e os atirou ao pequeno eunuco. — Esses pepinos ficam de presente para você. Leve para casa e use.

— Este servo agradece a generosidade da Dama Ning.

Depois de agradecer, segurou os pepinos, intrigado. *Hum... Não era para comer? Por que ela disse para eu usar?*

Ning Xiaoxiao acrescentou: — Quando voltar para prestar contas, faça-me um favor e leve uma mensagem ao imperador. Diga que eu perguntei se ele me acha encantadora.

— Pode deixar, senhora! Este servo transmitirá suas palavras!

E foi embora todo contente, levando um pepino em cada mão.

(**Nota da autora:** Este capítulo já passou de duas mil palavras de narrativa, então queria comentar uma coisa. Em outra plataforma, já fiz experiências com histórias interativas e funcionou bem. Podemos tentar isso aqui também.)

(Vocês, leitores queridos, podem escrever no espaço de discussão ou nos comentários alguma situação que sempre quiseram ver numa história, mas nunca encontraram. Se a ideia receber muitas curtidas, tentarei encaixá-la de forma coerente no enredo principal e realizar esse desejo.)

(Vale tanto para protagonistas quanto para coadjuvantes. Para os protagonistas, podem sugerir romance fofo, humor absurdo ou cenas comoventes. Para os secundários, além de finais felizes, também aceito finais tristes, amores impossíveis e transformações do amor em ódio. Vou considerar tudo, desde que não tome espaço demais, dando preferência às ideias mais curtidas e pedidas.)

(Pronto, terminei de tagarelar! Bom fim de semana a todos!)

(ღ( ´･ᴗ･` ) Coraçãozinho!)

# Capítulo 110 — Um laço de irmandade vale mais que tudo

Naquela noite, Gu Sijin voltou muito tarde.

Quando chegou, não procurou Ning Xiaoxiao; foi direto para o próprio quarto.

Ning Xiaoxiao tentou falar com ela, mas a porta estava trancada. De dentro, recebeu uma resposta displicente: — Já fui dormir. Se houver alguma coisa, falamos amanhã.

Só que Ning Xiaoxiao podia ouvir claramente o barulho de objetos batendo lá dentro, como se Gu Sijin estivesse golpeando alguma coisa.

【Será que ela está espancando um bonequinho de vodu com a minha cara?】

【Socorro...】

*

Na manhã seguinte, a imperatriz estava dispensada de suas obrigações, e as consortes não precisavam comparecer para as saudações.

A Consorte Duan, que passara quase um mês visitando a família, também retornara naquele dia.

Assim que voltou, viu Ning Xiaoxiao sair do pavilhão lateral oeste. Olhando para a decoração, percebeu que não se parecia em nada com o prédio abandonado e malcuidado de antes; à primeira vista, era até mais suntuoso que seus próprios aposentos principais.

Curiosa, perguntou: — A Atendente Gu se mudou para o pavilhão oeste?

Ning Xiaoxiao respondeu, constrangida: — Minha senhora ainda mora no pavilhão leste.

— Então quem veio morar no Palácio Zhongcui? O pavilhão oeste ficou fechado por tantos anos... Que surpresa vê-lo em uso.

Uma criada dos aposentos principais veio recebê-la e murmurou: — Senhora, agora quem mora ali é a Dama Ning.

— Dama Ning? — A Consorte Duan examinou Ning Xiaoxiao de cima a baixo e sorriu sem sinceridade. — Ha, ha! Fiquei fora uns dias e perdi alguma coisa? Nunca imaginei que tivesse tamanha sorte. Se não me engano, você é a primeira consorte desta dinastia que veio da condição de criada, não? Pois seus bons tempos estão começando. Se conseguir dar ao imperador um filho ou uma filha, talvez até chegue à posição de Dama Nobre.

A criada lembrou-lhe baixinho: — Senhora... a Dama Ning já está grávida...

A expressão da Consorte Duan escureceu. Ela fixou os olhos no ventre ainda plano de Ning Xiaoxiao, soltou uma risada fria e nada mais disse.

Mais tarde, Xiao Yinzi veio instruir Ning Xiaoxiao sobre a etiqueta que deveria observar ao ir agradecer à imperatriz no Palácio Fengluan e à imperatriz-viúva no Palácio Xianshou. Depois disso, ao procurar Gu Sijin, Ning Xiaoxiao descobriu que ela conversava com a Consorte Duan em seus aposentos.

A Consorte Duan tentava, a cada frase, colocar uma contra a outra:

— Francamente, você é boba demais! Ning Xiaoxiao saiu de dentro dos seus aposentos, e você nem percebeu quando começou a seduzir o imperador? Mal teve alguns dias de favor imperial e já abriu caminho para outra mulher! Se eu tivesse uma criada tão ingrata, que se aproveitasse de mim pelas costas, faria questão de lhe dar uma lição!

Gu Sijin permaneceu calada. A Consorte Duan, encorajada, continuou:

— É evidente que ela quer subir pisando nos seus ombros! Qualquer um enxerga isso. Sei que você tem bom coração, mas gastar sua bondade com uma serva que trai a própria senhora... até eu fico indignada por você.

Gu Sijin manteve a expressão serena e acariciou a pulseira que a Consorte Duan lhe dera. Então respondeu, tranquilamente:

— Senhora Consorte Duan, não precisa me dizer essas coisas. Sempre considerei Xiaoxiao como minha irmã mais nova.

— Não creio que ela tenha agido de propósito. Mas, mesmo que fosse como Vossa Senhoria diz, mesmo que quisesse subir pisando nos meus ombros, se alcançar o lugar que deseja a fizer feliz, eu serviria de apoio de bom grado.

Aquelas palavras deixaram a Consorte Duan sem resposta e comoveram profundamente Ning Xiaoxiao, que ouvia escondida do lado de fora.

Percebendo que não conseguiria semear discórdia, a Consorte Duan suspirou: — Você ainda vai sofrer por causa desse coração bondoso.

Ao sair, deu de cara com Ning Xiaoxiao e fingiu preocupação: — Você está grávida, não deveria andar de um lado para outro. Agora é a pessoa mais preciosa do palácio, e...

— E o que você tem a ver com isso?

— Você...!

Ning Xiaoxiao deu-lhe um empurrão, ignorou-a por completo e entrou nos aposentos de Gu Sijin.

A Consorte Duan rangeu os dentes de raiva. — Mal se tornou Atendente e já não me respeita! Se um dia for promovida a concubina ou consorte, vai querer montar na minha cabeça?

Xiu'er tentou acalmá-la: — Não se zangue, senhora. Ela é jovem, impulsiva e está grávida; naturalmente, não sabe se controlar. Não tem modos nem medida no que diz e faz. Com o tempo, o imperador também perderá o interesse. Não passa de uma mulher sem família importante. Esse favor imperial será curto como rabo de coelho!

A Consorte Duan cuspiu no chão e riu friamente. — Vamos ver quanto tempo ela dura!

*

Ao ver Ning Xiaoxiao chegar, o rosto antes carregado de Gu Sijin se abriu num sorriso luminoso.

— Você veio? Sente-se, depressa.

Levantou-se para recebê-la e convidou-a a sentar-se de frente para ela, junto ao assento aquecido.

Mesmo quando Ning Xiaoxiao era criada, Gu Sijin sempre permitira aquela informalidade. Tudo parecia igual a antes e, ao mesmo tempo, alguma coisa havia mudado.

Ning Xiaoxiao baixou os olhos, incapaz de encarar o olhar afetuoso da outra. — Minha senhora... Esta serva realmente não quis subir na vida pisando nos seus ombros...

— Ainda vai me chamar de “minha senhora” e a si mesma de “esta serva”? — Gu Sijin a interrompeu. — Agora você também é uma senhora do palácio. Se não mudar logo essa maneira de falar, vou ter de puni-la com a autoridade de Atendente.

Ao vê-la sem reação, brincou: — Não dissemos diante do imperador que, daqui para a frente, seríamos irmãs? Mudou de ideia?

— Ir... irmã mais velha?

Ning Xiaoxiao era filha única. Até com as amigas íntimas se tratava por apelidos; nunca chamara ninguém de irmã mais velha.

Mas aquelas duas palavras, saindo de sua boca, despertaram uma sensação surpreendente.

Era como se, a partir daquele instante, algo ainda mais profundo a ligasse a Gu Sijin.

Gu Sijin segurou sua mão e sorriu radiante. — Naquele dia, você perguntou se eu a culpava. Como poderia não culpá-la?

— Culpo você por esconder de mim uma notícia tão boa, guardando tudo em segredo.

— Culpo você por subestimar tanto a nossa amizade, por me tratar com a mesma desconfiança que teria de uma estranha.

Ao ouvi-la, Ning Xiaoxiao sentiu uma pontada de culpa. — Irmã, não foi isso...

— Responda sinceramente: você realmente gosta do imperador?

Ela não ousava gostar dele. Por isso, balançou a cabeça em negativa.

Gu Sijin disse: — Mas consigo perceber que o imperador gosta muito de você.

— Ele gosta de mim? Não brinca! Gosta é de me atormentar...

— Quando alguém está apaixonado, é impossível esconder isso nos olhos. — Gu Sijin parecia triste por um instante, como se recordasse o passado. Sorriu, com o olhar perdido. — Já amei alguém. Ainda me lembro perfeitamente de como ele olhava para mim. Não posso me enganar. Quando o imperador olha para você, tem o mesmo olhar que aquele rapaz dirigia a mim: puro, sincero, cheio de uma alegria e de um carinho impossíveis de esconder. Na verdade, o imperador é um bom homem. Se ele for sincero com você, não o decepcione.

Ning Xiaoxiao respondeu, aflita: — Mas, se eu me tornar uma consorte, não vamos acabar em lados opostos?

Gu Sijin balançou a cabeça, sorrindo. — Isso não faz sentido. Se não for você, será outra. Uma estranha favorecida pelo imperador pode conspirar contra mim e tentar me matar. Mas confio que você jamais faria isso. Além do mais, você conhece meu desejo: quero evitar o favor imperial de todas as maneiras.

Ela apertou a mão de Ning Xiaoxiao e disse com toda a seriedade: — Comparado ao imperador, que para mim é alguém de quem posso abrir mão, o que mais valorizo é o laço de irmandade entre nós.

Ning Xiaoxiao sentiu o coração aquecer. Seus olhos de corça ficaram novamente vermelhos, cheios de lágrimas.

# Capítulo 108 — Você já deveria passar a se chamar de concubina

Depois que as consortes deixaram o Palácio Fengluan, a imperatriz foi até os aposentos internos acender incenso e fazer suas preces. Recitou especialmente um sutra pela alma da Atendente Xiao.

Quando estava na metade da recitação, sua criada Xiangling entrou às pressas, com uma expressão aflita.

Ao ver a imperatriz concentrada em suas orações, não ousou interrompê-la e permaneceu a um lado.

A imperatriz percebeu sua presença. Sem abrir os olhos, perguntou com indiferença: — O que houve?

— Majestade, aquela Atendente Xiao não está colaborando... Recusa-se a aceitar a execução e não para de dizer que agiu a mando de alguém. Está fazendo um escândalo, exigindo ver o imperador.

Os dedos da imperatriz apertaram as contas do rosário. — Gente inútil não merece sobreviver neste palácio. O irmão dela trabalha sob as ordens de meu pai. Vá perguntar se prefere morrer sozinha ou arrastar a família inteira com ela.

Depois de dizer isso, ainda murmurou, devotamente: — Amitabha.

Xiangling respondeu sorrindo: — Esta serva foi tola. Vou tratar disso imediatamente.

— Traga a Concubina Shen até mim. Tenho algo a lhe perguntar.

Quinze minutos depois, a Concubina Shen retornou ao Palácio Fengluan.

A imperatriz ordenou que preparassem o chá de que ela mais gostava.

A Concubina Shen era belíssima, a única mulher do harém cuja beleza podia rivalizar com a de Gu Sijin.

Mas inteligência não era seu forte. Antes, aliara-se à Consorte Yun e acabara ofendendo a Consorte Nobre; bastou uma pequena manobra desta para que a imperatriz-viúva a colocasse em confinamento.

Só havia recuperado a liberdade nos últimos dois dias.

Enquanto conversavam e tomavam chá, a imperatriz comentou: — Naquela época, a Concubina Tong fez você ser confinada. Agora, ela própria provou do mesmo veneno. Pode-se dizer que recebeu o que merecia. Durante seu confinamento, seu pai se preocupou muito. Frequentemente pedia ao meu pai que me trouxesse recados. Nas cartas, insistia para que eu intercedesse junto ao imperador e à imperatriz-viúva por sua libertação.

A Concubina Shen levantou-se e fez uma reverência. — Eu sabia que Vossa Majestade devia ter feito muito por minha libertação antecipada. Sou profundamente grata.

— Levante-se. Somos irmãs da mesma família imperial, não precisa de cerimônias comigo. Chamei-a hoje por causa de seu pai. Quando ele trabalhava no Tribunal de Assuntos dos Vassalos, no ano passado, a renda de sua família não aumentou bastante?

O pai da Concubina Shen aceitara muitos subornos naquela repartição e recomendara, às escondidas, vários funcionários sem mérito para seus cargos. Ela sabia disso.

Pensando que a imperatriz houvesse descoberto algo, respondeu, apavorada: — Majestade, meu pai sempre foi honesto em suas funções. Ele...

A imperatriz sorriu. — Dizem que três anos como magistrado honesto rendem cem mil taéis de prata. O que seu pai faz não é assunto meu. Mas o pai da Atendente Gu é censor do órgão fiscalizador, e esse assunto já chamou a atenção dos investigadores.

— Mas... Majestade, meu pai realmente não fez nada!

A imperatriz lançou-lhe um olhar de soslaio e retrucou: — Ele é tão inocente assim? Suportaria uma investigação minuciosa dos censores?

Desde os tempos mais antigos, a palavra “corrupção” serve para qualquer funcionário com inclinações desonestas; o que muda é apenas o quanto cada um embolsa.

Se investigassem uma pessoa de cima a baixo, seria possível contar nos dedos os que sairiam completamente limpos.

Ainda mais porque o pai da Concubina Shen não roubara pouca coisa.

Ela não era brilhante, mas tampouco era inteiramente tola. Percebendo que a imperatriz tinha algum propósito mais profundo, perguntou:

— Majestade, haveria alguma forma de proteger meu pai?

A imperatriz alisou devagar o adorno de veludo com fios dourados junto às têmporas. — Sou apenas uma mulher confinada no palácio. O que poderia fazer sobre assuntos da corte? Mas seu pai e o meu foram colegas, então não poderia deixar de alertá-la.

De repente, baixou a voz e se aproximou da Concubina Shen. — Enquanto você estava confinada, seu pai perdeu o apetite e a concentração até no trabalho. Isso mostra como os filhos são preciosos para os pais. Diga-me: se algo terrível acontecesse à Atendente Gu, será que o pai dela ainda teria ânimo para investigar o seu?

Os olhos da Concubina Shen se moveram rapidamente. Ela compreendeu. — Entendi, Majestade! Muito obrigada por seus ensinamentos!

— Ensinamentos? Estávamos apenas tomando chá e conversando. Eu disse qualquer coisa, e você ouviu por acaso. Não vá alimentar ideias erradas por causa disso, entendeu?

A Concubina Shen assentiu, mas a expressão sombria já revelava as maldades que começava a arquitetar.

A imperatriz nada disse. Sorriu de maneira sinistra e levou a xícara aos lábios.

*

Mais cedo, quando Ning Xiaoxiao e os outros dois saíram do Palácio Fengluan, Lu Linyuan mandara Gu Sijin voltar sozinha aos seus aposentos. Ainda tinha algo a tratar com Ning Xiaoxiao.

Agora, assim que chegaram ao Palácio Chaoyang e ele dispensou todos, Ning Xiaoxiao foi direto ao assunto: — Majestade, na noite do seu aniversário... será que Vossa Majestade realmente se aproveitou de eu estar dormindo para... comigo...?

Ninguém com dois neurônios faria uma pergunta dessas.

Se o “21” dele tivesse realmente entrado, por acaso você continuaria desmaiada? Não teria acordado num piscar de olhos?

Mas, ao ver seu rosto corado de vergonha, Lu Linyuan sentiu vontade de provocá-la. — Sim, eu dormi com você. E daí?

— Majestade... você...!

Envergonhada e furiosa, Ning Xiaoxiao sentiu os olhos grandes, de corça, brilharem com lágrimas.

As mãos, que pendiam ao lado do corpo, se fecharam em punhos. Depois de alguns instantes em silêncio, ela finalmente gritou, com os lábios trêmulos:

— Só porque uma pessoa não fica brava você acha que ela é idiota?! Agora eu fiquei brava de verdade!

E tinha motivos para isso.

Ser obrigada a aceitar algo tão íntimo sem nem ser consultada, como se tivessem decidido por ela, era uma afronta. Agarrar o que se quer à força até combinava com a personalidade do tirano, mas era justamente o tipo de coisa que ela mais detestava.

Esses homens possessivos, obcecados, de amor doentio? Para ela, era um “não” gigantesco.

Afinal, esses protagonistas masculinos que só parecem atraentes nos romances seriam, na vida real, agressores e criminosos. Não me digam que há mesmo garotas que sofreriam violência sexual e ainda ficariam com o coração aos pulos!

No entanto, embora demonstrasse tanta raiva, era estranho perceber que, no fundo, não sentia por Lu Linyuan toda a repulsa que imaginara sentir.

Lu Linyuan observou sua indignação e ainda teve a audácia de rir.

Ele afastou uma mecha de cabelo junto à têmpora dela, inclinou-se e murmurou ao seu ouvido, numa voz sedutora:

— Mesmo brava, você continua sendo uma bobinha aos meus olhos.

【Você dormiu comigo e ainda me chama de burra? Acha que só porque é bonito eu não tenho coragem de bater em você?!】

Lu Linyuan ainda saboreava mentalmente o elogio à sua beleza quando Ning Xiaoxiao, como se tivesse sido tomada por um ataque súbito, lançou a cabeça para a frente e acertou em cheio o nariz do tirano. Ele viu estrelas e levou as mãos ao rosto, contorcendo-se de dor.

Ele sofria. Ning Xiaoxiao se deliciava.

Com uma falsidade melosa, ela comentou: — Ai, que coisa! Meu pescoço deu um espasmo e acabei esbarrando um pouquinho em Vossa Majestade sem querer. Não vai ficar bravo, vai?

Ao ver o olhar assassino dele, fez um biquinho lastimoso. — Não me diga que vai! Um homem feito como o imperador não vai mesmo implicar com uma criada grávida, vai?

— O que foi que você disse? Repita!

— Esta serva... Hm?

Lu Linyuan pousou o indicador comprido sobre os lábios rosados dela e disse, em tom autoritário: — Você já deveria mudar a forma de se referir a si mesma. Agora é uma concubina imperial.

— ...

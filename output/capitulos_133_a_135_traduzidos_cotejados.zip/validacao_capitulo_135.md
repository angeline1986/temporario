# Validação — capítulo 135

- **Fonte:** `novel_capitulos_121_a_180(20261103-233558).docx` — chinês tradicional, DOCX.
- **Limites:** parágrafos 952 a 1025 do DOCX (índices reais, base zero); capítulo seguinte excluído.
- **Parágrafos não vazios:** 71, inclusive título e eventuais notas autorais.
- **Linhas de dados do CSV:** 71.
- **Índices ausentes:** 0; **duplicados:** 0; **campos vazios:** 0.
- **Método:** tradução manual integral seguida de cotejo parágrafo a parágrafo e checagem automática de índices e campos.
- **Limite da validação:** a correspondência 1:1 e a revisão durante a tradução **não equivalem a uma auditoria semântica independente integral**; não é possível excluir erros internos de interpretação apenas pela contagem de linhas.

## Notas editoriais

- A nota autoral inicial identifica o mascarado do capítulo 134 como Ning Dazhi; mantida integralmente e separada do texto narrativo.
- O ferimento da Consorte Li é consequência dos atos descritos no capítulo 134. A expressão 「豬臉」 é insulto cômico associado ao rosto inchado.
- O imperador reage com frieza aos cumprimentos das consortes e muda ao ver Ning Xiaoxiao; não adicionar explicações psicológicas.
- A ameaça dos ocidentais chega por mensageiro, segundo relato da Consorte Yun; a intenção de guerra não é confirmada de forma independente no capítulo.
- O capítulo termina numa ordem de mutilação contra Shuangruo (霜若); não antecipar se a ordem será executada.

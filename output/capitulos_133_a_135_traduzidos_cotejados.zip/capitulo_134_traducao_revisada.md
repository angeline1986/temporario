# Capítulo 134 — A imperatriz-viúva leva uma surra

Voltar agora?

Foi mal, já fui longe demais!

Como a maior especialista em não fazer nada de útil em todo o harém, Ning Xiaoxiao talvez não fosse boa em nenhuma outra coisa, mas fugir era sua especialidade.

De qualquer modo, Lu Linyuan acabara de se recuperar e não podia sair correndo atrás dela. E seu pai iria embora no dia seguinte. Não era mais importante aproveitar cada instante desse reencontro?

Quando se aproximava do Pavilhão Yinlü, esbarrou de frente na Consorte Li ao virar uma esquina.

Ao lado do pavilhão ficava o Jardim de Contemplação das Ameixeiras. Vendo as criadas da Consorte Li com uma cesta cheia de flores de ameixeira, era fácil concluir que a consorte viera passear.

A Consorte Li examinou Ning Xiaoxiao de alto a baixo, com os olhos carregados de hostilidade. — Esbarrou em mim e nem vai pedir desculpas?

Ning Xiaoxiao olhou a cesta de flores na mão da criada e não fez questão de poupar a dignidade da consorte. — O imperador está deitado, entre a vida e a morte, e Vossa Alteza ainda tem ânimo para vir admirar as flores de ameixeira?

Uma sombra de pânico atravessou os olhos da Consorte Li. Ela, porém, logo se recompôs e levantou a voz: — Estou colhendo flores para rezar pelo imperador, sua miserável! O que você sabe? E você? Por que está passeando por aí em vez de cuidar do tratamento dele?

Ning Xiaoxiao respondeu: — Colher flores para rezar? Que original. Só que o som de *mei*, de ameixeira, lembra o de *mei*, de má sorte. Quem conhece Vossa Alteza sabe que está rezando; quem não conhece pode pensar que usa as flores como metáfora para lançar uma maldição sobre Sua Majestade.

— Sua atrevida! Só porque está grávida acha que pode passar por cima de mim? Hoje vou lhe ensinar quem manda aqui!

A Consorte Li esfregou as mãos e ergueu o braço, pronta para desferir um tapa.

Ning Xiaoxiao já se preparava para a luta quando aconteceu algo inesperado: como se tivesse sofrido um ataque de convulsões, a consorte baixou a mão não sobre Ning Xiaoxiao, mas sobre o próprio rosto.

E bateu com tanta força que o canto de sua boca começou a sangrar.

— A culpa é minha! Sou uma desgraçada! O imperador está gravemente enfermo e eu tenho coragem de admirar flores! Mereço morrer!

Ela se esbofeteou várias vezes, feito uma enlouquecida, deixando Ning Xiaoxiao completamente atônita.

As criadas se apressaram em contê-la, mas ela parecia uma guerreira capaz de atacar em todas as direções: batia em quem quer que tentasse detê-la.

Como se não bastasse se esbofetear, começou a golpear a própria cabeça contra o muro do palácio. Sangrava tanto que Ning Xiaoxiao se viu obrigada a tentar dissuadi-la:

— Ah... Bem... Vossa Alteza não precisa fazer isso consigo mesma... Colher umas flores não é tão grave. Não precisa levar a coisa tão longe, não acha?

Batendo a cabeça na parede, a Consorte Li respondeu: — Sou desprezível demais! Dama Ning, dê-me um tapa! Ou um chute, se preferir! Assim talvez eu me sinta melhor.

— !!!

Caramba. É a primeira vez que vejo alguém fazer um pedido tão absurdo.

Depois de tanta insistência da Consorte Li, Ning Xiaoxiao só pôde aceitar, para não parecer mal-educada: deu-lhe dois tapas e mais dois chutes.

A consorte finalmente declarou que estava se sentindo bem melhor e foi embora toda contente, embora coberta de ferimentos.

Ning Xiaoxiao ficou olhando suas costas por um bom tempo, sem conseguir se recuperar do espanto. Concluiu que todas as histórias de personagens psicopatas que já havia lido eram brincadeira de criança. Autores, por favor, daqui para a frente escrevam seus malucos nesse nível, combinado?

O que ela não sabia era que, do outro lado da muralha, dentro do Pavilhão Yinlü, Ning Dazhi discutia mentalmente com seu sistema:

【Anfitrião, você não pode interferir na trama de outro livro! Pode até bater nela, mas pelo menos deixe a mulher viva!】

A voz de Ning Dazhi estava carregada de ferocidade: 【Qual dos seus olhos viu que ela morreu? Ousar mexer com a minha filha e sair só com isso foi até pouco!】

Então ouviu, do lado de fora, uma voz doce e dengosa: — Paaai! O que você está fazendo aí na neve?

Um sorriso surgiu imediatamente em seu rosto. — Queria ver se minha pestinha ia esquecer o pai só porque arranjou um homem!

Os dois entraram rindo e conversando. Naquela noite, pai e filha falaram sobre incontáveis assuntos, sem pregar os olhos até o amanhecer.

— O papai precisa ir. Ao atravessar do mundo do livro para o mundo moderno, vou simplesmente desaparecer num instante. Não seria bom se alguém daqui visse.

Relutante em se despedir, Ning Xiaoxiao deu-lhe um abraço apertado e perguntou, chorosa e manhosa: — Pai, você vai voltar?

Ning Dazhi afagou-lhe suavemente as costas, como fazia para fazê-la dormir quando era pequena. — Claro que vou. Quem sabe na próxima eu não trago sua mãe também? Tome cuidado com tudo por aqui.

— E mais uma coisa: acho o rapazinho Lu muito bom. Tirando essa língua insolente, não vejo grandes defeitos. O principal é que ele realmente a leva no coração. Não fique fazendo birra. Se gostar dele, vá em frente. Homem é assim mesmo: se obedecer, você lhe dá um agrado; se não obedecer, dá tchau e procura outro melhor.

Ning Xiaoxiao perguntou: — Então foi assim que a mamãe sempre tratou você todos esses anos?

Ning Dazhi soltou duas tossidinhas estratégicas, desfez o abraço e lhe deu uma batidinha na testa. — Não se meta no que não é da sua conta!

Dito isso, virou-se e saiu rapidamente.

Antes de atravessar a porta, acenou para Ning Xiaoxiao em meio à neve que caía por toda parte. — Se precisar de alguma coisa, jogue um bilhete no espaço de armazenamento. Cuide bem de você!

Mal terminou de falar, seu corpo se transformou num raio de luz e desapareceu num zunido.

*

Enquanto isso, no Palácio Xianshou.

Era a quarta vigília da noite. O céu ainda estava escuro.

Na noite anterior, a imperatriz-viúva havia rezado diante do altar budista pela recuperação de Lu Linyuan. Só fora dormir por volta da segunda vigília e, naquele momento, dormia profundamente.

Não fazia ideia de que uma figura mascarada estava sentada à beira de sua cama.

A figura lhe deu dois tapinhas no rosto e disse, rindo: — Acorda, bruxa velha. O vovô aqui quer trocar umas palavrinhas com você.

A imperatriz-viúva acordou num sobressalto e, ao ver um desconhecido junto à cabeceira, começou a gritar: — Guardas! Socorro! Protejam-me!

O mascarado a observou impassível, em tom zombeteiro. — Grite à vontade. Pode gritar até perder a voz que ninguém virá salvá-la.

— O que... o que você quer fazer? — A imperatriz-viúva puxou uma ponta da colcha para cobrir o corpo. — Minha... minha honra não pode ser maculada!

O mascarado levou a mão à testa, sem acreditar no que ouvia. — Você tem merda na cabeça? Acha que eu sentiria atração por uma porca siberiana gigantesca como você?

Imperatriz-viúva: "... E-então, o que quer?"

— Nada de mais. Quero ser seu avô!

Sem outra palavra, o mascarado agarrou a imperatriz-viúva pelos cabelos, arrastou-a para fora da cama e distribuiu uma saraivada de tapas em seu rosto envelhecido e sem maquiagem.

— Pare de bater! Pare! Tenha piedade, senhor!

Enquanto a esbofeteava, o mascarado ordenou: — Imite um porco! Agora!

Imperatriz-viúva: — Hã?!

— Hã é o cacete! — Veio outro tapa de fazer os ouvidos dela zumbirem. — Imite um porco!

Ele não pegava leve. Sem ter a quem recorrer, a imperatriz-viúva só pôde choramingar: — Oinc, oinc...

— Mais alto! Não estou ouvindo!

— OINC! OINC, OINC, OINC!

Só então o mascarado a soltou. Cuspiu em sua direção e ameaçou: — Escute aqui: se voltar a fazer suas maldades, na próxima vou arranjar um porco para montar em você! Entendeu?

A imperatriz-viúva tremia sem parar e repetia, apavorada, que nunca mais faria aquilo.

Embora nem sequer soubesse em nome de quem aquele homem a havia espancado.

Depois do aviso, o mascarado se transformou diante dela num fio de fumaça violeta, que se dissipou no ar.

A imperatriz-viúva achou que tinha visto um fantasma. Soltou um grito e desmaiou.

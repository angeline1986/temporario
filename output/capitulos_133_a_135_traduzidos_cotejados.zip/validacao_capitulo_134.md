# Validação — capítulo 134

- **Fonte:** `novel_capitulos_121_a_180(20261103-233558).docx` — chinês tradicional, DOCX.
- **Limites:** parágrafos 883 a 951 do DOCX (índices reais, base zero); capítulo seguinte excluído.
- **Parágrafos não vazios:** 66, inclusive título e eventuais notas autorais.
- **Linhas de dados do CSV:** 66.
- **Índices ausentes:** 0; **duplicados:** 0; **campos vazios:** 0.
- **Método:** tradução manual integral seguida de cotejo parágrafo a parágrafo e checagem automática de índices e campos.
- **Limite da validação:** a correspondência 1:1 e a revisão durante a tradução **não equivalem a uma auditoria semântica independente integral**; não é possível excluir erros internos de interpretação apenas pela contagem de linhas.

## Notas editoriais

- O trocadilho com 「梅」 (ameixeira) e 「黴」 (mofo/má sorte) é fonético no chinês; foi explicitado no diálogo para preservar a intenção da provocação, sem inventar homofonia em português.
- O comportamento compulsivo da Consorte Li é consequência da intervenção de Ning Dazhi, evidenciada pelo diálogo dele com o sistema através dos pensamentos.
- O mascarado não é identificado dentro deste capítulo; sua identidade é revelada expressamente pela nota da autora no início do capítulo 135.
- A despedida inclui uma instrução sobre bilhetes no espaço de armazenamento; não pressupor mecanismos não descritos pelo original.
- O capítulo alterna cenas no Pavilhão Yinlü e no Palácio Xianshou; o asterisco de separação foi preservado.

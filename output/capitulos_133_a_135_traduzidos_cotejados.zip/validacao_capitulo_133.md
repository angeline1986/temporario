# Validação — capítulo 133

- **Fonte:** `novel_capitulos_121_a_180(20261103-233558).docx` — chinês tradicional, DOCX.
- **Limites:** parágrafos 816 a 882 do DOCX (índices reais, base zero); capítulo seguinte excluído.
- **Parágrafos não vazios:** 64, inclusive título e eventuais notas autorais.
- **Linhas de dados do CSV:** 64.
- **Índices ausentes:** 0; **duplicados:** 0; **campos vazios:** 0.
- **Método:** tradução manual integral seguida de cotejo parágrafo a parágrafo e checagem automática de índices e campos.
- **Limite da validação:** a correspondência 1:1 e a revisão durante a tradução **não equivalem a uma auditoria semântica independente integral**; não é possível excluir erros internos de interpretação apenas pela contagem de linhas.

## Notas editoriais

- 「朕願為你抗下千夫所指」 exprime a intenção de Lu Linyuan de assumir a culpa pública por Ning Xiaoxiao; isso é explicitado pelos pensamentos dele.
- 「紅花油」 foi traduzido como óleo medicinal de cártamo; seu uso para produzir o suposto aborto pertence à lógica da ficção e não deve ser tratado como orientação médica.
- O feto continua inexistente: a referência a 「米田共戰士」 é um eufemismo cômico para fezes; a falsa gravidez persiste na percepção do harém.
- Ponto de vista: na linha iniciada por 「陸臨淵：【」, os pensamentos pertencem a Lu Linyuan, e não a Ning Xiaoxiao.
- A referência à ferida em formato de laço faz ligação direta com os capítulos anteriores.

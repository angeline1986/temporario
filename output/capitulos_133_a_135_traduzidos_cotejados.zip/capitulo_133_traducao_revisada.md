# Capítulo 133 — Estou disposto a enfrentar a condenação de todos por você

Ning Dazhi foi instalado por ordem de Lu Linyuan no Pavilhão Yinlü, a leste da Cidade Imperial, onde ficaria temporariamente. Xiao Yinzi o conduziu até lá.

Ao ver Lu Linyuan recobrar a consciência, Sanfu desandou a chorar, entre lágrimas e fungadas, insistindo em anunciar a boa notícia a todo o harém.

Lu Linyuan não tinha a menor disposição para suportar manifestações hipócritas de preocupação. — Por enquanto, guarde segredo. Avise a todos amanhã. Acabei de acordar; deixe meus ouvidos descansarem um ou dois dias.

Sanfu obedeceu e se retirou. Ning Xiaoxiao aproveitou para tentar escapar atrás dele.

Mal dera dois passos quando ouviu, às suas costas, uma voz grave: — Aonde pensa que vai?

— Sua Majestade não disse que queria um pouco de sossego? Então esta humilde concubina...

— Venha cá. — O tom de Lu Linyuan não admitia recusas. Ele curvou o indicador em sua direção, com a naturalidade de quem chama um gato ou cachorro.

— Ah, tá...

Ning Xiaoxiao obedeceu, aproximando-se em passinhos curtos.

Naquele momento, Lu Linyuan estava sentado no assento aquecido, com o torso descoberto e coberto de ataduras. A luz do sol passava pelas frestas da janela treliçada e lançava um brilho delicado sobre sua pele, destacando ainda mais os músculos firmes.

O olhar de Ning Xiaoxiao vagava de um lado para o outro. Queria admirar a vista, mas não ousava ser óbvia demais. De tanto espiar de relance, suas bochechas acabaram rosadas.

— Por que está com vergonha? — Lu Linyuan soltou uma risadinha desdenhosa. — Acabou de dizer que cuidou de mim durante estes dias. Já viu tudo o que devia e o que não devia. E agora resolveu bancar a donzela inocente? Está encenando para mim?

— Não... Antes, Sua Majestade estava inconsciente. Enquanto cuidava do senhor, eu só o enxergava como um paciente. Mas agora que acordou, um homem e uma mulher devem guardar o devido decoro, então eu...

— Decoro? Ah! — Lu Linyuan ergueu uma sobrancelha e riu. — Por acaso não apertou meu peito? Não andou brincando com minhas nádegas imperiais? Depois de aproveitar tudo, resolveu seguir as Virtudes Femininas?

Dito isso, fisgou a faixa da cintura de Ning Xiaoxiao e a puxou de uma vez para o colo.

Instintivamente, ela tentou afastá-lo, empurrando-lhe o peito sólido. Ele baixou a cabeça até o lóbulo frio de sua orelha e murmurou, numa voz grave e irresistivelmente provocante: — Estou ferido. Você está me machucando.

Ning Xiaoxiao: "..."

【Esse imperador cachorro enlouqueceu? Foi possuído por um poodle tarado?】

Ainda reclamava em pensamento quando sentiu uma pressão firme sobre o tornozelo.

Com um braço em volta de sua cintura, Lu Linyuan usou a outra mão para tirar, com destreza, o sapato e a meia de seu pé direito.

Para Ning Xiaoxiao, aquela atitude tinha um quê de perversão...

As pontas dos dedos dele deslizaram sobre o dorso pálido de seu pé. Ela morria de cócegas e começou a se contorcer, tentando prender o riso.

Lu Linyuan apertou-lhe a cintura. — Pare de se remexer.

Então pousou as pontas dos dedos sobre o osso saliente de seu tornozelo.

Só naquele instante Ning Xiaoxiao percebeu que o tornozelo estava um tanto vermelho e inchado. Quando ele pressionou a região, uma pontada a fez cerrar os dentes e soltar um gemido involuntário.

Lu Linyuan franziu as sobrancelhas e a repreendeu de leve: — Já faz três dias. Pretendia deixar essa torção sem remédio até acabar manca?

Torção...?

Foi só depois de ouvi-lo que Ning Xiaoxiao se deu conta de que realmente andava com alguma dificuldade nos últimos dias.

Tinha tanta coisa ocupando sua cabeça que nem prestara atenção em dores tão pequenas.

Pensando melhor, devia ter torcido o tornozelo no dia em que Lu Linyuan a puxara com força para protegê-la do disparo, fazendo-a perder o apoio do pé.

【Mas... como ele sabia que torci o tornozelo?】

【Naquele momento, ele tinha acabado de levar um tiro e estava entre a vida e a morte. Ainda teve tempo de reparar no meu pé?】

— Cof, cof. — Lu Linyuan tossiu duas vezes, fingindo naturalidade, e deu uma explicação tão suspeita que só faltou anunciar que escondia alguma coisa. — Vi que você estava mancando agora há pouco. Imaginei que tivesse machucado o pé.

Ordenou a Sanfu que trouxesse óleo medicinal de cártamo.

Ning Xiaoxiao pegou o frasco, disposta a aplicar o remédio por conta própria, mas Lu Linyuan o tomou de suas mãos.

Mandou que ela se recostasse no assento aquecido, despejou um pouco do óleo nas pontas dos dedos e o espalhou com movimentos extremamente delicados sobre a torção.

Suas mãos eram cuidadosas, mas a língua continuava afiada: — Se está ferida, vá se tratar. Caso contrário, vai ficar manca, e eu a mandarei para o Palácio Frio. Assim não terei de vê-la perambulando diante de mim todos os dias, ferindo meus olhos.

Ning Xiaoxiao contemplou aquele homem ao mesmo tempo insuportável e gentil, momentaneamente atordoada.

【Ele não é obcecado por limpeza? E não detesta, acima de tudo, o cheiro desse óleo? Na última caçada, torceu o pulso e deu um baita tapa no médico imperial quando este tentou aplicar o remédio. O que ele pensa que está fazendo agora...?】

Sanfu, que observava ao lado, também se desesperou. — Ai, Majestade! Não pode fazer isso! A senhora Ning está grávida! Esse óleo estimula a circulação e desfaz hematomas. Mesmo aplicado na pele, penetra nos tecidos; pode fazer mal ao herdeiro imperial...

— Se perdermos o herdeiro, podemos ter outro. Se ela ficar manca, será uma inútil, e eu não mantenho inúteis ao meu lado. — Lu Linyuan ergueu os olhos e lançou-lhe um olhar cortante. — Quem mandou você ficar aqui parado? Fora!

Sanfu ficou boquiaberto.

O imperador mimava Ning Xiaoxiao tanto assim?

Para cuidar de seu ferimento, aplicava pessoalmente o óleo que mais odiava e ainda dizia que, se o herdeiro fosse perdido, poderiam ter outro?

Se a imperatriz-viúva ouvisse aquilo, morreria de raiva ali mesmo...

Quando Sanfu saiu, Lu Linyuan terminou de aplicar o remédio.

Calçou com cuidado a meia e o sapato de Ning Xiaoxiao e recomendou: — Passe três vezes por dia. Se em três dias não estiver melhor, mude-se você mesma para o Palácio Frio. Entendeu?

Ning Xiaoxiao assentiu, meio aturdida. — Muito obrigada, Majestade... Só que estou grávida. Se usar esse óleo três vezes por dia e perder a criança, o que faremos?

Lu Linyuan: 【Não é justamente para você perder a criança que estou aplicando esse óleo? Se não houver um aborto, como vai explicar ao harém inteiro esses guerreiros de cocô que carrega na barriga?】

【Melhor deixar que ponham a culpa em mim. Enquanto eu estiver aqui, ninguém ousará criar problemas para você.】

Era ele quem devia resolver a confusão que havia provocado. Jamais permitiria que Ning Xiaoxiao voltasse a ser alvo da condenação de todos.

Por isso, mudou de assunto: — Se mandei usar o remédio, use. Podemos ter outro filho, mas você só tem duas pernas, e esse ferimento não pode ficar sem tratamento.

Aquelas palavras atingiram Ning Xiaoxiao bem no... fundinho do coração.

Ela ainda tentava entender aquela súbita demonstração de cuidado quando ele soltou as ataduras e estendeu a mão para tocar o ferimento nas costas. — A cicatriz está coçando muito. Vá buscar um espelho. Quero ver como ficou o ferimento.

Ning Xiaoxiao saiu instantaneamente do estado de comoção. — Ah? Sua Majestade disse que está com fome? Então vou preparar alguma coisa gostosa para o senhor!

Mudando descaradamente de assunto, disparou para fora do quarto como uma flecha.

Quanto mais ela agia assim, mais Lu Linyuan suspeitava que havia algo errado.

Ele se dirigiu ao espelho de bronze e torceu o pescoço para tentar enxergar as próprias costas. Depois de um esforço enorme, finalmente avistou aquele... lacinho de borboleta impecável!

Aquele laço... de onde tinha saído?

Nem precisava pensar: só podia ser mais uma das loucuras de Ning Xiaoxiao!

Que absurdo!

Quando fosse tomar banho nas fontes termais no futuro, o que os servos pensariam dele? E os ministros? E os macacos que viviam nas montanhas das termas?!

— NING XIAOXIAO! VOLTE AQUI AGORA MESMO!

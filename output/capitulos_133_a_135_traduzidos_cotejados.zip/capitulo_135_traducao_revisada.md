# Capítulo 135 — O tirano pune severamente todo o harém

(Um esclarecimento antes de começar: o mascarado que aparece no fim do capítulo anterior é Ning Dazhi, o pai de Xiaoxiao.)

— Imperatriz-viúva? Vossa Majestade, acorde.

A voz de Qingzhu junto ao ouvido deu tamanho susto na imperatriz-viúva que ela se sobressaltou.

Abriu os olhos de repente e puxou a colcha até cobrir a cabeça, escondendo-se debaixo dela enquanto gritava coisas desconexas:

— Não! Não bata mais em mim!

— Eu imito! Eu imito!

— Oinc, oinc! Oinc, oinc, oinc!

Qingzhu: ￣□￣｜｜ — Imperatriz-viúva? Vossa Majestade... está tudo bem?

Ela puxou delicadamente a colcha, procurando acalmar a senhora com a voz mais suave possível. — Vossa Majestade teve um pesadelo?

Quando se tranquilizou um pouco, a imperatriz-viúva percebeu que estava deitada, intacta, na própria cama. Até a ardência dos tapas no rosto havia desaparecido.

Então... tudo aquilo não passara de um sonho?

Observou o quarto perfeitamente arrumado, levou a mão ao peito e soltou um longo suspiro de alívio. — Quase morri de susto...

— Majestade, quer que eu chame um médico imperial para examiná-la? — perguntou Qingzhu.

— Não precisa. Por que me acordou tão cedo?

— O imperador despertou! E está fora de perigo!

Ao saber que Lu Linyuan escapara da morte, a imperatriz-viúva invocou Buda várias vezes, levantou-se às pressas, vestiu-se e saiu para visitá-lo.

Lu Linyuan já havia sido transferido de volta ao Palácio Chaoyang. Quando a imperatriz-viúva chegou, as consortes dos diversos palácios estavam reunidas ali, lideradas pela imperatriz.

Lu Linyuan ocupava o trono. Comparado ao estado de extrema fraqueza de antes, recuperara visivelmente boa parte do vigor.

As consortes lançavam mão de todos os truques imagináveis para agradá-lo.

A Consorte Yun chorava sem conseguir se controlar, lamentando-se numa voz arrastada: — Buaaa! Ainda bem que Vossa Majestade resistiu! Se alguma coisa lhe acontecesse, eu também não conseguiria continuar vivendo!

Lu Linyuan: — Ainda dá tempo de morrer agora.

Consorte Yun: "..."

Na véspera, a Consorte Li havia espancado o próprio rosto até ficar parecida com um leitão. Agora resolveu aproveitar os ferimentos para montar uma bela encenação. — Enquanto Sua Majestade estava gravemente enfermo, não parei de me culpar por não estar lá no dia do disparo, para receber a bala em seu lugar. Passei dias e noites sem paz, dando tapas em mim mesma e odiando minha própria inutilidade.

Lu Linyuan a examinou demoradamente antes de perguntar, num tom distraído: — Quem é você?

A Consorte Li ficou paralisada e apertou os lábios, magoada. — Majestade, sou a Consorte Li...

O olhar de Lu Linyuan se encheu de desprezo. — Com esse focinho de porco, ainda tem coragem de se chamar Consorte Li, a Bela?

Consorte Li: "..."

Recém-recuperado de uma doença grave, Lu Linyuan parecia ter engolido uma caixa de munição: não deixava ninguém abrir a boca sem levar uma resposta atravessada.

As demais consortes, mais espertas, desistiram de suas encenações e ficaram observando a imperatriz-viúva perguntar preocupada sobre os ferimentos dele.

Com a mãe, Lu Linyuan não chegou a dizer nada impróprio, mas suas respostas foram frias e protocolares.

Só quando Ning Xiaoxiao entrou no Palácio Chaoyang com uma tigela de medicamento apareceu no rosto dele o primeiro sorriso daquele dia.

Com toda a reverência, Ning Xiaoxiao colocou a tigela sobre a mesa imperial. — Majestade, o médico disse que o remédio funciona melhor se for tomado ainda quente.

Lu Linyuan não tocou na colher. Sorriu levemente e disse:

— Dê na minha boca.

A frase deixou todas as consortes de queixo caído.

Ning Xiaoxiao sentia os olhares assassinos vindos de todas as direções. Daqui a pouco estaria parecendo uma peneira de tanto ser perfurada por eles.

Mas, se Lu Linyuan insistia em ser alimentado por ela, não podia contrariar uma ordem imperial. Reuniu coragem e levou o remédio até os lábios dele.

Ela serviu uma colherada, mas Lu Linyuan franziu as sobrancelhas e recuou, fazendo uma careta.

— Está quente. Sopre para mim.

Ning Xiaoxiao: "???"

【Puta que pariu! Esse imperador cachorro está de sacanagem comigo? Desde quando somos tão íntimos assim? Fazer essa cena na frente dessas hienas do harém não é o mesmo que me jogar dentro de uma fogueira?】

Vendo que ela não se mexia, Lu Linyuan exigiu, impaciente: — Sopre logo! Quero tomar meu remédio!

"..."

【Vai tomar é no olho do seu...!】

Contrariada, Ning Xiaoxiao soprou o remédio na colher. Mas, ao levá-lo à boca de Lu Linyuan, derramou de propósito o líquido sobre ele.

— Ai! — Cobriu a boca, assustada, e se desculpou imediatamente. — Perdoe-me, Majestade! Sou muito desajeitada e não sei servi-lo direito. Talvez seja melhor pedir à imperatriz que lhe dê o remédio.

Quem diria que aquele sujeito estava completamente fora de si naquele dia? Não apenas deixou de se irritar como segurou a mão dela e a contemplou com toda a ternura do mundo.

— Sua bobinha, não se queimou, não é?

Ning Xiaoxiao: "..."

Todas as consortes: "???"

Imperatriz-viúva: "!!!"

A imperatriz-viúva já não suportava Ning Xiaoxiao. Ver Lu Linyuan perder o juízo de paixão e virar um soberano completamente rendido assim que a jovem aparecia só a deixava ainda mais furiosa.

— Cof, cof.

Tossiu duas vezes, tentando lembrá-lo de se comportar.

Lu Linyuan, porém, não apenas ignorou o aviso como lançou à mãe um olhar de soslaio e disse com indiferença: — Se a senhora está doente, mãe, procure um médico imperial.

A imperatriz-viúva fechou a cara, deu dois passos até a mesa e pegou a tigela. — Se o imperador ainda não se recuperou a ponto de precisar que alguém lhe dê o remédio, eu mesma posso servi-lo.

Lu Linyuan não lhe respondeu. Apenas tomou a tigela de sua mão com brusquidão, bebeu tudo de uma vez e bateu o recipiente com força sobre a mesa.

A imperatriz-viúva fuzilou Ning Xiaoxiao com o olhar. A jovem imediatamente se comportou como uma coelhinha assustada e se virou para voltar ao seu lugar, abaixo do estrado.

Lu Linyuan segurou seu pulso, e sua voz esfriou de repente: — Fique aqui. Ainda tenho algumas contas para acertar com você.

Ning Xiaoxiao ficou cheia de interrogações. Antes que pudesse perguntar qualquer coisa, a imperatriz-viúva tomou a palavra: — É mesmo hora de acertar as contas. Se não fosse por ela, o imperador jamais teria levado aquele tiro.

Vendo uma oportunidade, a Consorte Yun tratou de atacar: — Além de quase matar o imperador, ela enfureceu os ocidentais. Pelo que sabemos, o disparo foi acidental, sem intenção do príncipe. Mesmo assim, Dama Ning emitiu uma ordem por conta própria e mandou prender o príncipe ocidental na masmorra imperial. Ontem chegou um mensageiro do Ocidente exigindo que o entreguemos imediatamente. Caso contrário, declararão guerra.

A Consorte Li, fingindo estar muito aflita, acrescentou: — Não é que a dinastia Qi seja incapaz de enfrentá-los. Mas não vale o sacrifício. Cada soldado deles pode portar uma arma de fogo. Se houver guerra, mesmo vencendo, nossas perdas serão terríveis!

Lu Linyuan se recostou preguiçosamente no trono. — Não é disso que pretendo tratar. Lembro que entre as servidoras de minha mãe há uma chamada Shuangruo, não há?

A imperatriz-viúva confirmou. Shuangruo, que permanecia no fundo do grupo, avançou. — Sim, Majestade. Sou eu.

Lu Linyuan a observou por um instante e ordenou: — Levante as mãos. Quero vê-las.

Sem entender o motivo, Shuangruo obedeceu. Ergueu ambas as mãos acima da cabeça e as virou, mostrando as palmas e os dorsos ao imperador.

Lu Linyuan não economizou elogios: — Essas mãos são longas, delicadas e bem-feitas. Mais bonitas do que as de muitas moças.

Shuangruo ficou radiante. — Agradeço o elogio, Majestade!

Lu Linyuan continuou: — Mãos tão bonitas merecem ser cortadas e conservadas para sempre num jarro de vinho.

Um sorriso cruel se desenhou nos lábios dele quando ordenou: — Guardas! Levem-na daqui e arranquem essas duas patas para mim.

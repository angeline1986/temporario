# Capítulo 269 — Usurpar o trono

Lu Linyuan, é claro, sabia que aquilo não passava de desculpas de Tong Guowei. O homem certamente tinha algum plano em mente e queria chamar a Concubina Tong de volta para casa a fim de discutir algo que não podia vir à luz.

E era justamente por isso que Lu Linyuan pretendia lhe fazer a vontade.

Tong Guowei já percebera que havia movimentações na corte. Naquele momento, estava como um pássaro assustado pelo som de um arco.

Quanto mais agisse, mais erros cometeria.

E, quanto mais erros cometesse, mais depressa morreria!

*

No décimo quinto dia do primeiro mês lunar, durante o Festival das Lanternas, todo o palácio estava tomado por uma atmosfera de alegria e harmonia.

No Palácio Yaohua, a Concubina Tong se arrumava diante do espelho.

Naquele dia, fizera questão de vestir um traje de brocado de nuvens, bordado com uma centena de pássaros reverenciando o pavão, que Tong Guowei acabara de lhe enviar ao palácio.

As aves bordadas pareciam vivas; seus olhos reluziam tanto que se poderia imaginar que, a qualquer instante, abririam as asas e sairiam voando do tecido.

Entretanto, numa peça tão requintada e luxuosa, justamente o pavão, o motivo principal do bordado, parecia estranho tanto na forma quanto na expressão.

Enquanto lhe penteava os cabelos, Xianglan comentou, curiosa: — O traje de Vossa Alteza está belíssimo hoje. Só que esse pavão não parece muito um pavão. Parece mais...

O restante seria atrevido demais, e Xianglan não ousou pronunciá-lo.

A Concubina Tong ergueu uma sobrancelha diante do espelho e sorriu de lado. — Parece o quê, na sua opinião?

— Esta serva acha que... parece um pouco uma fênix...

Ela não estava errada. O pavão daquela roupa era uma fênix disfarçada sob penas de pavão.

A Concubina Tong fizera aquilo de propósito. Queria encontrar mais uma maneira de irritar a imperatriz bem diante de seus olhos.

E, de fato, quando foi prestar reverência à imperatriz logo cedo, conseguiu irritá-la.

Bastou à imperatriz olhar de relance para o traje para que sua expressão se tornasse péssima.

A Consorte Duan comentou: — Concubina Tong, essa sua roupa... Por que o pavão me parece uma fênix?

A Concubina Tong não se abalou. — Ah, é? Eu não reparei. Talvez a bordadeira não seja muito habilidosa. Esses pássaros reverenciando o pavão não ficaram lá grande coisa. Só resolvi vestir porque o tecido é confortável.

A família Tong era rica e poderosa, e empregava bordadeiras ainda melhores que as das oficinas do palácio. Como poderia ser falta de habilidade?

Com um sorriso frio, a Concubina Tong perguntou à imperatriz: — Vossa Majestade, acha bonito o meu traje?

A imperatriz estava prestes a responder quando uma voz zombeteira veio da entrada:

— Ora, ora! De que galinheiro escapou essa galinha careca que colou meia dúzia de penas no corpo?

Ning Xiaoxiao chegou atrasada. Depois de examinar a Concubina Tong, deu um tapinha teatral na própria boca.

— Ah, vejam só, meus olhos me enganaram! Era a Concubina Tong?

A Concubina Tong ficou furiosa. — Abra bem esses olhos e enxergue direito! Isto...

*PÁ!*

Antes que ela terminasse, Ning Xiaoxiao lhe acertou uma bofetada vigorosa no rosto.

— Você, uma simples concubina, ousa falar comigo sem o devido respeito? Está cansada de viver?

— Eu...

*PÁ!*

Mal a Concubina Tong abriu a boca, Ning Xiaoxiao lhe deu outra bofetada.

— “Eu” o quê? Sou a Consorte Nobre. Diante de mim, você deve se referir a si mesma como “esta serva imperial”.

Depois, imitando o gesto característico que a Concubina Tong costumava fazer, ajeitou os cabelos junto à têmpora, lançou-lhe um olhar arrogante e revirou os olhos com impaciência. — Diga de novo.

A Concubina Tong obviamente não aceitava aquilo de bom grado. Mas, se não cedesse diante de Ning Xiaoxiao, acabaria levando tantas bofetadas que a boca ficaria torta.

Então engoliu a indignação e murmurou: — Esta serva imperial reconhece seu erro...

— Se reconhece o erro, volte logo para casa. — Ning Xiaoxiao apontou para a carruagem estacionada diante do Palácio Fengluan. — Seu pai disse ao imperador que sua mãe está prestes a ir para o inferno... Ah, não, que está à beira da morte. Mandou você voltar para cumprir seus deveres filiais.

Em seguida, atirou-lhe a autorização de saída do palácio que Lu Linyuan pedira que entregasse. — É melhor se apressar. Talvez ainda consiga ver sua mãe pela última vez.

A Concubina Tong apertou o salvo-conduto na mão. Seu sorriso congelou imediatamente. Se Xianglan não a estivesse apoiando, talvez nem conseguisse ficar de pé.

Saiu do palácio cambaleando e correu para a residência Tong. Mas encontrou a propriedade toda decorada com lanternas e enfeites festivos, recebendo visitantes sem parar. Não havia o menor sinal de alguém gravemente enfermo na família.

Ela entrou a passos rápidos no salão principal e viu os pais sentados, perfeitamente bem, nos lugares de honra. O irmão caçula estava ajoelhado diante deles, fazendo reverências para ganhar seu envelope vermelho de Ano-Novo.

Ao vê-la, a mãe de Tong se alegrou. — Minha filha? C-como você voltou?

O irmãozinho, ainda ajoelhado no chão, virou a cabeça ao ouvir aquilo. Assim que avistou a irmã, correu feliz até ela e se aconchegou em seus braços.

— Irmã mais velha, senti tanta saudade!

A Concubina Tong afagou os cabelos da testa dele e olhou para a mãe, perplexa. — Mãe... você está bem?

A senhora Tong não compreendeu a pergunta. — Estou ótima. O que poderia ter acontecido comigo?

A expressão de Tong Guowei escureceu. Mandou a esposa levar o menino para fora, dispensou os criados e ordenou que fechassem as portas do salão.

Quando todos saíram, foi direto ao assunto:

— Sua mãe não está doente. Sou eu que tenho algo a lhe dizer.

Finalmente aliviada, a Concubina Tong levou a mão ao peito e soltou um longo suspiro. — Pai, se tinha algo a dizer, bastava mandar uma carta ao palácio. Essa história toda me deixou apavorada durante o caminho!

Tong Guowei tirou um pacote de remédio de uma gaveta e o entregou à filha. — Depois de amanhã é seu aniversário. Vou fazer o imperador ir ao seu palácio comemorá-lo com você. O que tem nas mãos é um afrodisíaco, e dos mais potentes. Faça-o ingerir. Ele não conseguirá conter o desejo e terá relações com você.

A Concubina Tong apertou o pacote, assustada, e baixou a voz. — Pai... Se descobrirem que droguei Sua Majestade, é um crime punível com a execução de todo o clã! Isso...

Tong Guowei respondeu asperamente: — Se você não fosse tão inútil, se em quase cinco anos no palácio tivesse conseguido que o imperador ao menos olhasse para você, eu não precisaria chegar a esse ponto!

Ele bufou, cruzou as mãos atrás das costas e começou a andar de um lado para o outro, ansioso.

— Acha que a família Tong ainda desfruta do prestígio de antes? A imperatriz, a imperatriz-viúva e os homens do Censorado estão de olho em mim. Pelo modo como agem, já devem ter descoberto muitos dos meus segredos.

— Aquele velho desgraçado Gu Yanchuan se aliou à família da imperatriz para acabar comigo! Pensei em matá-lo, para que jamais pudesse falar diante do imperador. Mas o comandante das Nove Portas mantém guardas imperiais vigiando a residência Gu dia e noite. Não consigo chegar perto daquele velho, por mais que tente!

— Você disse que drogar o imperador levaria à execução de nove gerações da família? Pois eu digo: se essa sua barriga continuar sem dar sinal de gravidez, mais cedo ou mais tarde toda a família Tong perderá a vida!

Vivendo dentro do palácio, a Concubina Tong não fazia ideia de que sua família enfrentava uma crise tão grave. Ainda atordoada, perguntou:

— Mas, mesmo assim, para engravidar é preciso que tudo dê certo... Como ter certeza de que acontecerá logo na primeira vez?

Tong Guowei respondeu: — Basta que tenha relações com o imperador uma única vez! Não importa se a criança será dele. O importante é que vocês tenham consumado a união. Depois disso, o filho que estiver em seu ventre poderá ser de qualquer homem.

Ele parou de andar e baixou a voz: — Vou providenciar para que um guarda entre escondido no Palácio Yaohua e a ajude a engravidar.

As pupilas da Concubina Tong se contraíram. Mesmo sendo tão ingênua, compreendeu o que Tong Guowei pretendia.

Ele queria que ela engravidasse de um suposto “descendente imperial”, para então aproveitar a oportunidade, levantar-se em rebelião contra Lu Linyuan e colocar no trono a criança que ela viesse a dar à luz.

Acuado, seu pai decidira usurpar o trono!

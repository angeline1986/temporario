# Capítulo 270 — Sou um machão incurável. Caia fora!

— Pai! Está me usando como instrumento para tomar o poder?

— Usurpar o trono é um crime gravíssimo! Não pode fazer isso! Você...

— Insolente!

Antes que a Concubina Tong terminasse de falar, Tong Guowei lhe deu uma bofetada brutal, derrubando-a no chão.

Apontando para o rosto da filha, gritou: — As mulheres nascem para dar descendentes aos homens! Que diferença faz para quem você dá um filho? Nasceu na família Tong; nós a alimentamos, vestimos e lhe demos uma vida de luxo. Já passou da hora de retribuir!

Sentada no chão, a Concubina Tong choramingou baixinho. Ao vê-la naquele estado, Tong Guowei ficou ainda mais irritado.

— Chorar, chorar, chorar! Só sabe chorar! Igualzinha à sua mãe! Mulheres são umas inúteis que, diante de qualquer problema, só sabem derramar lágrimas!

Ele lhe deu um chute violento na parte superior da coxa. — É tão humilhante assim dormir com um homem? Escute bem: você vai fazer isso, queira ou não! Se não fizer e a família Tong cair, você também não escapará da morte!

As lágrimas da Concubina Tong não despertaram qualquer afeto paterno nele. Apenas aumentaram seu desprezo.

Tong Guowei jamais tivera sentimentos familiares de verdade.

Só o poder supremo podia satisfazê-lo. Tudo o que fazia servia àquele único objetivo.

Se antes tratava bem a Concubina Tong, era porque esperava que a filha consolidasse uma posição no harém, conquistasse os favores do imperador e pudesse influenciá-lo.

Mas os anos haviam passado, e ela se tornara ainda mais detestada pelo imperador.

Agora, seu único valor restante era dar o passo decisivo naquela jogada da família Tong.

A Concubina Tong sabia que não podia recusar. Assim, assentiu entre lágrimas.

Assim que ela aceitou a exigência absurda, Tong Guowei mudou imediatamente de atitude.

Ajudou-a a se levantar do chão gelado. Seus olhos, antes cheios de ferocidade, recuperaram algo que se parecia com ternura. Ele acariciou de leve o rosto quente e avermelhado da filha.

— Boa menina. Não culpe seu pai. Faço tudo isso pela família Tong e também por você.

— Quando o plano der certo, seu filho será o novo soberano da dinastia Qi, e você será a única imperatriz-viúva do império.

A mão dele pousou no ombro da Concubina Tong e o apertou. — Lembre-se: seja rápida. No dia do aniversário, precisa manter o imperador lá a qualquer custo. O remédio que lhe dei é fortíssimo. Nenhum homem no mundo conseguirá resistir.

Ela apertou o pacote entre os dedos e concordou, encolhida de medo.

*

Depois daquele dia, Tong Guowei apresentou memoriais sucessivos ao trono, dizendo que a Concubina Tong sentia uma saudade enorme de Lu Linyuan. Pedia que o imperador, apesar dos muitos compromissos, arranjasse um momento para passar o aniversário com ela, ainda que fosse apenas para ficar sentado um pouquinho, antes que a filha adoecesse de tanta saudade.

Quanto mais próximo chegava o momento decisivo, mais Lu Linyuan precisava fingir obediência irrestrita a Tong Guowei.

Concordou com o pedido e avisou Ning Xiaoxiao antecipadamente.

— Não faço ideia da confusão que pode surgir no aniversário da Concubina Tong. Tong Guowei não gastaria tanto esforço com algo sem propósito. Por isso, só comparecendo poderei fazê-lo baixar completamente a guarda.

Ele segurou a mão de Ning Xiaoxiao, levou-a aos lábios e depositou nela um beijo suave. — Como da última vez, venha comigo.

Ning Xiaoxiao sabia que ele queria tranquilizá-la.

Lu Linyuan desejava lhe dar segurança, e ela também queria mostrar que confiava plenamente nele.

— O mais importante agora é fazer a família Tong baixar a guarda. Enquanto ele acreditar que você, A-Yuan, caiu na armadilha preparada por ele, não vai se precipitar. Se eu for junto, como da última vez em que você passou a noite no Palácio Yaohua, isso pode atrapalhar.

— Além disso, acredito que, mesmo sem mim, A-Yuan não vai ter a menor vontade de olhar para ela.

Ao ouvi-la, Lu Linyuan compreendeu suas intenções.

Com um sorriso carinhoso, deu um toque na pontinha do nariz dela e acabou cedendo, embora a contragosto.

— Então me espere em seu palácio esta noite. Vou apenas aparecer no Palácio Yaohua e depois volto para vê-la.

*

Desde cedo, a Concubina Tong se preparava para o acontecimento importante daquela noite.

Vestiu uma túnica no tom azul-esverdeado da água límpida, a cor que Ning Xiaoxiao mais gostava de usar antes de se tornar Consorte Nobre.

Não apenas a roupa: procurou reproduzir também a maquiagem e o penteado de Ning Xiaoxiao com a maior fidelidade possível.

Até Xianglan comentou: — Vista de longe, Vossa Alteza realmente se parece um pouco com aquela Ning.

Ao ouvir aquilo, a Concubina Tong sorriu com amargura. — Nunca imaginei que chegaria o dia em que precisaria viver como a sombra de outra pessoa.

Xianglan percebeu sua tristeza e logo mudou de tom. — Mas só de longe, naturalmente! De perto, Vossa Alteza é muito mais bonita que ela.

Aquela transformação fora ideia de Tong Guowei.

Desde a viagem à estância das fontes termais, o povo do palácio e da capital inteira comentava que Lu Linyuan mimava Xiaoxiao sem limites. Muitas moças da capital passaram a considerar Ning Xiaoxiao um modelo de beleza e competiam para imitar suas roupas e sua maquiagem.

A Concubina Tong estreitou os olhos, estudando no espelho aquela figura ao mesmo tempo familiar e estranha. Seu rosto não revelava emoção alguma.

Desde que voltara ao palácio, desaparecera a arrogância profundamente arraigada que antes a caracterizava.

Parecia uma marionete de fios, da qual alguém arrancara o coração.

Nem ela própria sabia mais o que buscara ao disputar poder no harém por tanto tempo.

Preparou pessoalmente uma mesa cheia de iguarias e misturou o afrodisíaco ao vinho aromático e aos pratos.

Naquela noite, bastaria que Lu Linyuan provasse qualquer coisa da mesa para que seu “plano perverso” desse certo.

Lu Linyuan chegou por volta do crepúsculo.

Atrás dele, o céu estava coberto por um mar de nuvens avermelhadas, tão deslumbrante que a Concubina Tong ficou por um instante ofuscada.

Ela ainda se lembrava do dia em que entrara no palácio e o vira pela primeira vez: também fora num belo entardecer de primavera.

A paisagem parecia a mesma, mas cinco anos haviam se perdido, e o homem que um dia sonhara ter como marido parecia cada vez mais distante.

Lu Linyuan sentou-se à mesa sem expressão. A Concubina Tong percebeu que, mesmo no aniversário dela, ele só viera cumprir uma obrigação.

Estava exausta e não tinha vontade de sorrir, mas era obrigada a fazê-lo.

— A presença de Vossa Majestade me deixa muito feliz.

Ela encheu a taça de vinho à frente dele e a ofereceu, mas Lu Linyuan fez um gesto de recusa.

— Prometi à Consorte Nobre que, salvo em ocasiões indispensáveis, não beberia uma gota de álcool, para não prejudicar a saúde.

Então pediu a Sanfu que pegasse o chá verde Longjing colhido antes das chuvas, que ele trouxera consigo, e preparasse uma infusão fresca na pequena cozinha. Só depois colocou uma xícara cheia a seu lado.

A Concubina Tong ficou paralisada e baixou lentamente a taça de vinho que segurava.

Ela sorriu. — Vossa Majestade, prove os pratos de hoje. Veja se são do seu agrado.

Lu Linyuan levantou os pauzinhos. Antes mesmo que tocasse na comida, ela acrescentou: — Fui eu mesma que preparei todos esses pratos. Quis agradar a Vossa Majestade e me esforcei muito em vários deles. Vossa Majestade... o que está fazendo?

Lu Linyuan pousou os pauzinhos, mantendo a expressão indiferente.

— Além da comida preparada pelos cozinheiros imperiais, só como o que a Consorte Nobre cozinha para mim. Se eu comesse algo feito por outra mulher, ela ficaria zangada comigo.

Só quando mencionou Ning Xiaoxiao seu rosto se iluminou com o primeiro sorriso desde a chegada ao Palácio Yaohua.

— Ela é toda sensível. Quando fica zangada, passo um tempão tentando agradá-la de novo. Só de pensar já me dá dor de cabeça~

— ...

Cada palavra carinhosa pronunciada por Lu Linyuan era como mais uma faca cravada no coração da Concubina Tong.

Enquanto isso, no Palácio Fengyi...

Ning Xiaoxiao se preparava para jantar com Gu Sijin quando a voz de Xiao Qi soou de repente em sua mente:

【Bip, bip, bip~ Anfitriã, chegou uma nova missão para você~】

【Nova missão — “Comemorar o aniversário da Concubina Tong e fazê-la passar a maior vergonha da vida”.】

【Recompensa pela conclusão: +5 pontos percentuais no índice de desvio da trama. Penalidade pelo fracasso: -10% de vitalidade da anfitriã.】

【Anfitriã, vá o mais depressa possível ao Palácio Yaohua para cumprir a missão!】

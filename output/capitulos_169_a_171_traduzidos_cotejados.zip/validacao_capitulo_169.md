# Validação — capítulo 169

## Fonte e delimitação

- Fonte: `novel_capitulos_121_a_180(20261103-233558).docx`, chinês tradicional.
- Título no índice DOCX (base zero): 3349.
- Limite do capítulo: índices 3349 a 3414 (próximo título no índice 3415).
- Unidades não vazias incluindo título: **63**.

## Conferência automática

- Linhas do CSV de cotejo (sem cabeçalho): 63.
- Índices duplicados: 0.
- Índices ausentes entre os parágrafos não vazios da faixa: 0.
- Campos originais/traduzidos vazios: 0.
- Correspondência: 1 unidade original para 1 unidade traduzida, inclusive título.

## Escolhas editoriais e pontos de atenção

- O autor faz o humor depender de dois sentidos do palavrão 臥槽/槽: uma interjeição de surpresa e uma leitura obscena equivocada de Lu Linyuan. A tradução preserva o palavrão e explica a interpretação nos pensamentos, sem inventar uma homofonia portuguesa.
- O primeiro ataque e a surra são apagados pelo Retroceder de três minutos. A linha temporal vigente termina com Ning chutando Bengbeng antes do ataque.
- No original, o personagem que age com o saco muda de Sanfu, inicialmente designado para a tocaia, para Bengbeng no desenrolar da ação. Preservado e registrado como possível inconsistência narrativa.
- A referência a 打人 no contexto final parece conter oscilação pronominal em relação a quem bateu; o texto traduz o sentido de que Ning feriu o imperador.
- 華貴人 e 顧貴人 foram mantidos como Nobre Dama Hua e Nobre Dama Gu: 貴人 é distinto de 答應 (Dama) e 常在 (Atendente).

## Escopo e limites da auditoria

- Foi realizada tradução com cotejo estrutural 1:1 e revisão de leitura no mesmo fluxo.
- A igualdade entre linhas não certifica ausência de problemas de sentido dentro de um parágrafo.
- Não houve segunda auditoria linguística independente integral.

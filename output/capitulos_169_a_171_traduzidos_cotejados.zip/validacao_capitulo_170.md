# Validação — capítulo 170

## Fonte e delimitação

- Fonte: `novel_capitulos_121_a_180(20261103-233558).docx`, chinês tradicional.
- Título no índice DOCX (base zero): 3415.
- Limite do capítulo: índices 3415 a 3485 (próximo título no índice 3486).
- Unidades não vazias incluindo título: **68**.

## Conferência automática

- Linhas do CSV de cotejo (sem cabeçalho): 68.
- Índices duplicados: 0.
- Índices ausentes entre os parágrafos não vazios da faixa: 0.
- Campos originais/traduzidos vazios: 0.
- Correspondência: 1 unidade original para 1 unidade traduzida, inclusive título.

## Escolhas editoriais e pontos de atenção

- 下麵 admite, no chinês coloquial, tanto «preparar macarrão» quanto um duplo sentido sexual. O texto conserva o sentido culinário e as reações insinuantes, sem fabricar frase homófona em português.
- A fala 朕知道她漂亮 apresenta «ela» como objeto do olhar de Lu Linyuan: ele contempla Ning, não os fogos.
- «星燃» designa os fogos de artifício na dinastia fictícia e integra o nome 楚星燃, Chu Xingran; preservado o vínculo poético entre nome e imagem.
- A duração dos fogos e do abraço é de cerca de um quarto de hora.
- A data 28 de novembro, mencionada no capítulo 169, é a referência do aniversário; no 170 a meia-noite já passou.

## Escopo e limites da auditoria

- Foi realizada tradução com cotejo estrutural 1:1 e revisão de leitura no mesmo fluxo.
- A igualdade entre linhas não certifica ausência de problemas de sentido dentro de um parágrafo.
- Não houve segunda auditoria linguística independente integral.

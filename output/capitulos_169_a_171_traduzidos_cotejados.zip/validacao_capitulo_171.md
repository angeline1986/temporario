# Validação — capítulo 171

## Fonte e delimitação

- Fonte: `novel_capitulos_121_a_180(20261103-233558).docx`, chinês tradicional.
- Título no índice DOCX (base zero): 3486.
- Limite do capítulo: índices 3486 a 3557 (próximo título no índice 3558).
- Unidades não vazias incluindo título: **69**.

## Conferência automática

- Linhas do CSV de cotejo (sem cabeçalho): 69.
- Índices duplicados: 0.
- Índices ausentes entre os parágrafos não vazios da faixa: 0.
- Campos originais/traduzidos vazios: 0.
- Correspondência: 1 unidade original para 1 unidade traduzida, inclusive título.

## Escolhas editoriais e pontos de atenção

- A ida «para casa» significa o retorno temporário de Ning ao mundo moderno mediante a pílula, não fuga ordinária do palácio. Lu Linyuan interpreta erroneamente seus pensamentos como desejo de abandoná-lo.
- A pílula efervescente de flor de cerejeira dissolve-se no bule e ambos ingerem parte da bebida; o imperador bebe o restante, levando os dois à transferência.
- O poder de Pausar deixa de funcionar quando a transferência ao mundo moderno está próxima; toda a realidade do livro fica congelada ao final do capítulo.
- YYDS é gíria chinesa equivalente a «a melhor de todas», apresentada com a sigla preservada. «Dame» é interjeição japonesa para rejeitar ser chamada de gordinha.
- O título 夫妻雙雙把家還 é vertido por «Marido e mulher voltam juntos para casa», sem pressupor casamento formal entre os protagonistas.

## Escopo e limites da auditoria

- Foi realizada tradução com cotejo estrutural 1:1 e revisão de leitura no mesmo fluxo.
- A igualdade entre linhas não certifica ausência de problemas de sentido dentro de um parágrafo.
- Não houve segunda auditoria linguística independente integral.

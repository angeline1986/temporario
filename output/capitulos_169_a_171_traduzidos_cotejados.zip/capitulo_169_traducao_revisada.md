# Capítulo 169 — Você anda ensinando os outros a fazer espacate de cabeça para baixo no meio da noite?

No palácio, os fogos de artifício ficavam a cargo de profissionais. Criados que serviam às consortes, como Bengbeng e os demais, costumavam conhecer apenas o esplendor dos fogos desabrochando no céu; nunca tinham visto como eram antes de serem acesos.

Como tampouco era época de festividades, ao depararem com aqueles objetos cheios de pólvora, naturalmente concluíram que alguém havia enterrado explosivos do lado de fora do Palácio Zhongcui.

No harém, as intenções das pessoas eram perversas. Gu Sijin e Ning Xiaoxiao haviam se tornado, uma após a outra, pedras no sapato das demais consortes; atrás das portas fechadas de seus palácios, elas certamente tramavam maneiras de prejudicá-las.

Mas nem Ning Xiaoxiao imaginava quem teria tido tamanha audácia de provocar uma confusão dessas dentro do palácio, disposto a reduzir Zhongcui a escombros com explosivos apenas para matá-las.

Ela enfrentaria qualquer golpe com outro golpe. Quem quer que tivesse feito aquilo não teria um dia de paz se dependesse dela.

Depois de acalmar os presentes, ordenou: — Se enterraram pólvora, alguém vai ter de vir acendê-la. Sanfu, pegue um saco e fique de tocaia nos arbustos. Quando alguém aparecer, enfie o saco na cabeça dele. Primeiro a gente desce a porrada sem perguntar nada; depois arrancamos o nome de quem mandou fazer isso e contamos tudo ao imperador!

*

Enquanto isso, Sanfu informou a Lu Linyuan que tudo estava pronto, e o imperador foi pessoalmente ao Palácio Zhongcui.

Era uma surpresa que ele preparara para Ning Xiaoxiao. Portanto, acender os fogos com as próprias mãos daria ao momento um ar mais cerimonioso.

Vestiu roupas simples, de cor discreta, e, ao chegar aos arredores de Zhongcui, recebeu de Sanfu um acendedor de fogo. Então caminhou de mansinho até a muralha do palácio.

Na escuridão, sem ninguém ao seu lado, nem Ning Xiaoxiao nem Gu Sijin, que observavam das sombras, reconheceram quem ele era. Bengbeng, escondido entre os arbustos à espera da oportunidade, tampouco.

Lu Linyuan foi se aproximando. Bengbeng mal conseguia conter a ansiedade; assim que o homem chegou ao pé do muro e se preparou para acender o pavio, ele saltou de repente, enfiou-lhe o saco na cabeça por trás e se atirou sobre ele, derrubando-o no chão.

— Senhora! Pegamos o sujeito! — gritou para Ning Xiaoxiao.

Com ares de chefe de gangue, Ning Xiaoxiao avançou a passos largos, agitando um bastão e acompanhada de um bando de moças armadas com toda sorte de objetos, até o homem caído com o saco na cabeça.

Não hesitou nem por um segundo. Ergueu o bastão e desceu-o sobre o saco.

Enquanto batia, xingava: — Você se atreve a armar contra mim? Está cansado de viver, seu desgraçado!

Empolgada com a surra, viu Gu Sijin segurando o bastão, frágil e assustada demais para atacar, e a incentivou: — Irmã, não fique parada! Bata também! Não precisa ter pena. Basta deixar o sujeito respirando!

Só então Gu Sijin, ainda relutante, deu uma batidinha experimental no saco.

Ning Xiaoxiao enfim descarregou toda a raiva acumulada. A última vez que se sentira tão satisfeita devia ter sido... na última vez mesmo.

Mas, por mais prazerosa que fosse a vingança, havia alguma coisa estranha naquela situação.

Parecia que... a voz do bandido debaixo do saco lhe era familiar.

— Ai, ai! Nobre Dama Hua! Nobre Dama Gu! O que estão fazendo? Parem, depressa! — gritou alguém.

Ao longe, Sanfu vinha correndo com um grupo de criados e lanternas.

Ao vê-lo, Ning Xiaoxiao o chamou: — Eunuco Sanfu, chegou na hora certa! Faça o favor de chamar o imperador. Preciso falar com ele.

O rosto de Sanfu ficou horrivelmente pálido. Apontando para Lu Linyuan, que se debatia no chão sob o saco, gaguejou: — M-mas... o homem em quem a senhora acabou de bater... é justamente Sua Majestade...

Ning Xiaoxiao: — ???

Gu Sijin: — !!!

Qiqi, Qiaqia, Bengbeng e Lala: — ┏┛TÚMULO┗┓

Todos correram para libertar Lu Linyuan do saco.

Ele saiu com o rosto inchado e coberto de hematomas, vendo estrelas. Cada bastonada havia sido mais uma contundente demonstração do amor de Ning Xiaoxiao.

Quando percebeu que o homem debaixo do saco era mesmo o imperador, ela não conseguiu conter um palavrão:

— Puta merda! M-m-m-majestade... Como é que era mesmo você?

Lu Linyuan: 【??? Você me espanca e ainda diz na frente de todo mundo que quer me comer? Eu lhe dei liberdade demais, não foi?】

A fúria parecia transbordar por todos os poros de seu corpo, e ninguém ao redor ousava sequer respirar alto.

Ele agarrou Ning Xiaoxiao pela orelha e berrou: — Ning Xiaoxiao! Por acaso matei sua família inteira na vida passada?!

— Ai, ai, ai! Dói, dói! — Ning Xiaoxiao inclinou a cabeça na direção do puxão do tirano. — Não, espere! Dessa vez a culpa não foi minha!

Num lampejo de inspiração, decidiu inverter a acusação: — Tenho me comportado tão bem ultimamente! Nem fiz nada para ofender Vossa Majestade. Então por que, de repente, o senhor queria me explodir?

Lu Linyuan: — ??? De onde aquela sua cabeça de porco tirou que eu pretendia explodir você?

— Então o que são essas coisas? — retrucou Ning Xiaoxiao, apontando, com toda a convicção, para os inúmeros tubos que despontavam do chão.

Lu Linyuan ficou sem palavras. Até Sanfu sentiu vergonha por ela: — Nobre Dama Hua! São fogos de artifício! Fogos! Uma surpresa que Sua Majestade preparou especialmente para a senhora!

Ning Xiaoxiao ficou imóvel, sem conseguir processar a informação.

Por que ele haveria de soltar fogos para ela, assim, do nada?

Fitou por um bom tempo o rosto machucado de Lu Linyuan — ainda absurdamente bonito, mesmo todo ensanguentado — até compreender de repente:

【Puta merda! Acho que realmente contei a ele que meu aniversário é em 28 de novembro. E-e-ele... guardou essa data esse tempo todo?】

A situação era constrangedora, mas uma onda de emoção tomou conta dela.

Lu Linyuan, porém, não ficou nem um pouco enternecido. Ao ouvir aquilo, enfureceu-se ainda mais:

【Numa hora dessas, você ainda está pensando em me comer? Enlouqueceu?】

【Ah, você é muito atrevida! Só espere! Hoje à noite vou dar um jeito em você!】

Ning Xiaoxiao estendeu a mão e limpou o sangue do canto da boca dele. Lu Linyuan soltou um «ai» abafado de dor.

— Desculpe, desculpe! Majestade, está doendo muito? — perguntou ela depressa.

Lu Linyuan afastou sua mão e soltou um riso frio:

— Não importa o quanto eu esteja doendo. O importante é que você vai sofrer muito esta noite!

Na verdade, Ning Xiaoxiao nem precisava perguntar se doía. Depois de deixá-lo naquele estado, seria difícil explicar por que não receberia uma sentença de decapitação pública.

Então disse: — Majestade, aguente só um pouquinho! Vou reiniciar tudo para você. A dor já vai passar!

Antes que Lu Linyuan entendesse o que ela queria dizer, Ning Xiaoxiao franziu as sobrancelhas, fechou os olhos, abriu o documento e apertou decididamente o botão Retroceder.

A trama voltou a três minutos antes:

Lu Linyuan caminhava devagar em direção ao muro do palácio, com o acendedor na mão.

Bengbeng estava agachado entre os arbustos, segurando um saco e ansioso para atacar. Bastava surgir a oportunidade para saltar e acertar o homem com o golpe do saco na cabeça.

Naquele exato instante, Ning Xiaoxiao, que estava escondida nas sombras, disparou numa corrida de cem metros e lançou um chute voador que mandou Bengbeng pelos ares.

Ele caiu de cabeça dentro dos arbustos, com apenas as duas pernas para fora, esperneando sem parar.

Lu Linyuan ficou tão atônito com aquilo que a observou de olhos arregalados:

— Você anda ensinando os outros a fazer espacate de cabeça para baixo na porta do seu palácio no meio da noite?

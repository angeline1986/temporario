# Capítulo 171 — Marido e mulher voltam juntos para casa

Aquelas palavras fizeram Ning Xiaoxiao corar até a raiz dos cabelos.

Ele tinha enlouquecido hoje?

Será que pretendia se oferecer como presente de aniversário para mim?

Sua imaginação disparou, criando um monte de cenas impróprias que não posso contar a vocês.

Mas todas aquelas fantasias picantes se desfizeram de vez quando o estômago de Lu Linyuan roncou alto: «Grrrr...».

Ah... Então ele estava com fome de verdade...

Mais tarde, quando os dois voltaram ao pavilhão lateral leste, Ning Xiaoxiao foi à pequena cozinha e lhe preparou uma tigela de macarrão instantâneo.

Era preciso admitir: qualquer porcaria industrializada dos tempos modernos, levada para a Antiguidade, virava uma maravilha absoluta. YYDS — a melhor de todas!

Talvez por nunca terem experimentado essas coisas, os antigos as considerassem irresistíveis. Lu Linyuan costumava não comer depois do meio-dia, mas, desde que descobrira que Ning Xiaoxiao possuía um espaço cheio de maravilhas, não perdia uma oportunidade de tirar proveito dela.

Se não se exercitasse com tanta disciplina, nesse ritmo acabaria perdendo o abdômen definido.

Depois de comer e beber à vontade, Lu Linyuan se recostou numa poltrona aquecida para fazer a digestão.

Vendo o jeito folgado com que se instalara, era bem provável que estivesse pensando em passar mais uma noite no Palácio Zhongcui.

Mas ele não podia ficar ali naquela noite!

Era a «grande noite» de Ning Xiaoxiao, e ela não podia permitir que ele estragasse seus planos.

Então sorriu: — Majestade, o senhor já comeu e está ficando tarde. Amanhã precisa comparecer à audiência matinal. Que tal voltar logo para descansar?

Lu Linyuan percebeu perfeitamente que estava sendo posto para fora. A contrariedade ficou estampada em seu rosto. — Não vou embora esta noite. Vou dormir aqui.

Ning Xiaoxiao: — ???

【Não faz isso comigo, meu irmão! Hoje à noite eu vou voltar para casa! Como vou conseguir ir se você não sair daqui?】

Aquela voz interior atingiu Lu Linyuan em cheio. Uma sensação desagradável e sufocante apertou-lhe o peito.

Voltar para casa?

Ela estava com tanta pressa assim de fugir do meu lado?

Lu Linyuan tinha um rosto perfeito, como o de um personagem modelado por computador. Mas rostos assim também tinham um defeito: todas as emoções ficavam visíveis, fáceis de perceber.

Ning Xiaoxiao notou que ele estava de mau humor. Sem saber como o ofendera daquela vez, perguntou com cuidado: — Majestade, o que houve?

Lu Linyuan a observou em silêncio por alguns instantes. Então agarrou seu pulso e a puxou autoritariamente para o colo.

Com uma mão, prendeu-lhe a cintura; com a outra, deslizou os dedos pelo pescoço dela, até parar no lóbulo da orelha.

Acariciou a pele delicada atrás da orelha e perguntou numa voz sedutora: — Quanto você recebe de mesada por mês?

— A dotação de uma Nobre Dama é de cento e cinquenta taéis, Majestade.

Lu Linyuan sorriu: — Eu pago sua comida, suas roupas, todas as suas despesas. Criei você tão branquinha e gordinha, e ainda assim...

— Pare, pare! — interrompeu Ning Xiaoxiao, corrigindo-o de propósito. — Branquinha, tudo bem! Gordinha, jamais! Dame!

Lu Linyuan não deu atenção e continuou: — O que quero dizer é que, se um dia você se atrever a fugir de mim, vou revirar o mundo inteiro até trazê-la de volta para o meu lado...

Ele interrompeu a frase. A ponta morna de seu dedo passou lentamente de trás da orelha para a bochecha dela, detendo-se sobre a pequena elevação de seu lábio, que acariciou de leve:

— E, depois de trazê-la de volta, vou atormentá-la como merece.

O movimento daquele dedo em seus lábios fez um arrepio elétrico percorrer o corpo inteiro de Ning Xiaoxiao.

【Você não tem nada melhor para fazer? Arranje um emprego, criatura! Pelo visto está com tempo livre demais!】

— Ora, Majestade, que coisa o senhor está dizendo? Aqui no palácio tenho comida e bebida à vontade. Para que eu iria embora?

Ela deu tapinhas no peito dele, como quem fazia uma promessa solene: — Pode ficar tranquilo, Majestade! Nunca vou embora, nem daqui a cem anos!

Falou com tamanha convicção que, se Lu Linyuan não conseguisse ouvir seus pensamentos, talvez até acreditasse naquela conversa fiada.

Ele soltou um riso frio e provocou: — Hmpf. É bom mesmo.

Mas em seu coração já estava arquitetando um plano:

【Já deixei o aviso. Se ela ainda ousar fugir, será reincidente deliberada, com pena agravada.】

【Vou sair agora e depois voltar de surpresa. Se ela estiver arrumando as coisas para escapar, hoje mesmo vou fazê-la minha! Assim não vai querer se separar de mim nunca mais!】

O plano parecia tão bom que ele mal conseguia conter a expectativa de vê-la tentar fugir, só para poder executá-lo.

Lu Linyuan bocejou, alegou estar cansado e se levantou para ir embora.

Mal ele saiu, Ning Xiaoxiao tirou apressadamente de seu espaço a «Pílula que Manda Você de Volta para Casa».

Pegou um bule de chá. Pretendia encher uma tigela de água pura para dissolver a pílula, mas sua mão tremeu e ela acabou deixando a «Pílula que Manda Você de Volta para Casa» cair dentro do bule.

Era um comprimido efervescente com sabor de flor de cerejeira. Assim que tocou a água, começou a reagir, e Ning Xiaoxiao não teve chance alguma de recuperá-lo.

Só pôde observar a água de todo o bule mudar de transparente para um rosa-claro.

【Vou ter que beber tudo, não é? E se eu deixar um pouco e voltar só pela metade, ficar presa num túnel do tempo e acabar devorada por um tiranossauro?】

Então pegou uma tigela maior do que seu próprio rosto, despejou nela toda a água do bule e se preparou para beber tudo de uma só vez.

Mas, quando ainda estava pela metade, alguém escancarou subitamente a porta em arco.

Aquele grande encrenqueiro do Lu Linyuan... aquele maldito tinha voltado mesmo?!

Por instinto, Ning Xiaoxiao escondeu a tigela atrás das costas e perguntou, gaguejando: — M-majestade? P-por que voltou?

Bastou Lu Linyuan vê-la daquele jeito para perceber que havia algo suspeito. Aproximou-se passo a passo. — O que você está escondendo aí atrás? Deixe-me ver.

Mostrar? Nem pensar! Se eu mostrar, você vai tomar de mim de novo!

Sem dar explicações, Ning Xiaoxiao fechou os olhos, abriu o documento e apertou desesperadamente o botão Pausar.

Mas, depois de tanto apertar, descobriu que não funcionava de jeito nenhum!

【Xiao Qi? Que diabos é isso? O que está acontecendo? Por que essa porcaria de poder sempre falha justo quando mais preciso?!】

Xiao Qi: 【Porque a anfitriã já bebeu isso e está prestes a voltar para casa. Os poderes especiais não podem ser levados ao mundo moderno, então deixaram de funcionar...】

Ela ainda queria fazer mais perguntas a Xiao Qi, mas Lu Linyuan já havia tomado a tigela que ela escondia atrás do corpo.

Nunca tinha visto uma água rosa-clara que ainda soltava bolhinhas. Aproximou o nariz e sentiu um delicado perfume de flores de cerejeira.

Nem precisava perguntar. Com certeza era outra delícia, como o chá com leite!

Ele soltou um risinho zombeteiro, franzindo as sobrancelhas enquanto a fitava: — Hmpf. Sempre que encontro alguma coisa boa, penso em dividir com você. Mas, quando é você que tem algo bom, esconde tudo só para si?

— Majestade, não beba! Isso o senhor não pode beber! Eu...

Tarde demais.

Bem diante de seus olhos, o tirano virou de uma vez todo o restante da água efervescente de flor de cerejeira. Depois, ainda fez questão de virar a tigela vazia de cabeça para baixo para lhe mostrar que não sobrara nem uma gota.

Ai, minha vida!!!

No instante seguinte àquela exibição provocadora da tigela vazia, os dois se transformaram num feixe de luz azul e desapareceram num zunido.

Ao mesmo tempo, tudo no mundo do livro ficou completamente congelado no tempo...

# Capítulo 170 — Um céu inteiro de fogos para você. Que sua vida seja repleta de paz e alegria

Bengbeng parecia uma tartaruga virada de casco para baixo. Se ninguém o ajudasse, provavelmente passaria a noite inteira fazendo espacate de cabeça para baixo entre os arbustos.

Um tanto constrangida, Ning Xiaoxiao arrancou aquela «cebolinha plantada de cabeça para baixo» do matagal, tirou alguns galhos presos em seus cabelos e lhe deu uns tapinhas no ombro, elogiando-o com a maior seriedade: — Nada mal esse espacate. Você até tem um pouco da graça da Senhora Gu.

Bengbeng: — ???

— Por hoje basta. Amanhã continue se esforçando. Pode voltar — disse Ning Xiaoxiao.

Bengbeng sacudiu o saco que ainda segurava firmemente: — Mas, senhora... ai!

Antes que terminasse de falar, Ning Xiaoxiao lhe deu um chute no traseiro e o despachou dali, entre afagos e empurrões.

Afinal, se ele revelasse para que servia realmente o saco, quem acabaria dentro dele, recebendo uma surra, provavelmente seria a própria Ning Xiaoxiao.

Só depois de mandá-lo embora ela acenou para Lu Linyuan, com um sorriso constrangido, mas educado: — Hi, Majestade! Que coincidência! — Seu olhar pousou sobre a mão direita dele, escondida na manga. Fingindo ignorância, perguntou: — O que o senhor está segurando aí?

Lu Linyuan enfiou o acendedor ainda mais fundo na manga. — O que você tem a ver com isso?

Sua expressão estava pouco natural, como se Ning Xiaoxiao o tivesse flagrado cometendo alguma coisa errada.

Se era uma surpresa, precisava acontecer de modo inesperado para merecer esse nome.

Agora que ela o encarava daquela maneira, se ele tirasse o acendedor, lançasse os fogos e lhe desejasse feliz aniversário, a moça não ficaria insuportavelmente convencida?

Lu Linyuan travou uma batalha consigo mesmo. Depois de ponderar bastante, resolveu simplesmente desistir.

Limpou a garganta e adotou um tom deliberadamente casual, sem sequer notar o esforço: — Eu não conseguia dormir, então saí para caminhar. Já estou indo embora.

Ao se virar, ainda fez questão de adverti-la: — E não exagere nesses espacates. Vai acabar machucando a virilha.

Ning Xiaoxiao estava farta daquele jeito complicado dele. Era cheio de cerimônias, todo acanhado, mais tímido até do que uma mocinha.

Os fogos já estavam preparados. Por que iria embora sem soltá-los, deixando tudo enterrado ao redor do palácio dela? Esperava o quê?

O funeral da imperatriz, para estourá-los durante o banquete fúnebre?

Ao vê-lo se virar para partir, Ning Xiaoxiao o segurou pelo braço. — Majestade, já que veio até aqui... que tal eu preparar uns guiozas de ceia para o senhor?

Só de ouvir falar em guiozas, Lu Linyuan sentiu a irritação subir.

Da última vez, também de madrugada, ela se oferecera para lhe preparar guiozas. No fim, separara o recheio da massa, comera tudo o que havia dentro e deixara apenas as massas para ele.

Lu Linyuan soltou um riso frio: — Você? Melhor não. Dos seus guiozas só sobraram as massas para mim. É melhor eu preparar um macarrão para você.

Ning Xiaoxiao: — ???

Lu Linyuan percebeu no olhar dela uma mistura de «curiosidade intelectual» e «segundas intenções». Ficou imediatamente envergonhado e sacudiu o braço para se livrar da mão que o segurava.

Só que usou força demais e, sem querer, lançou para longe o acendedor escondido na manga.

O objeto saiu voando, traçou uma parábola perfeita no ar e recebeu tanto ar pela abertura que a chama se acendeu. Então, com precisão inacreditável, caiu sobre o pavio de um dos tubos de fogos.

Fsssss...

Quando enterrara os tubos, Sanfu conectara todos os pavios com um fio oculto. Assim, ao acender um único tubo, todos os fogos dispostos em torno do Palácio Zhongcui seriam disparados sucessivamente.

Com um estrondo ensurdecedor, os fogos explodiram e subiram aos céus com ímpeto quase selvagem, rasgando a abóbada noturna azul-escura.

Ning Xiaoxiao estava perto demais. O estrondo a fez gritar de susto; num salto, virou-se e se atirou nos braços de Lu Linyuan.

Enlaçou as coxas dele com as pernas, passou os braços em volta do pescoço e enterrou a cabeça em seu peito.

Lu Linyuan paralisou por um instante. Então, com a maior naturalidade, sustentou as nádegas dela com uma mão. Só depois que a moça ficou firmemente agarrada a seu corpo é que ele resmungou, com ar de desagrado:

— Acabei de trocar de roupa. Não vá sujar tudo com seu ruge e seu pó de arroz!

O que Ning Xiaoxiao não conseguia ver era que, enquanto reclamava, ele exibia um sorriso de ternura profunda.

O céu, perto da meia-noite, estava extraordinariamente quieto, sem uma nuvem sequer, como uma pintura em tons de índigo tingidos de preto.

Os fogos se desdobraram lentamente em incontáveis flores de cores exuberantes.

Depois de seu brilho passageiro, caíram como estrelas cadentes, perdendo aos poucos a luz até se apagarem.

O silêncio durou apenas alguns instantes antes que novos fogos ocupassem a noite.

Como uma gatinha apavorada, Ning Xiaoxiao encontrou conforto e coragem nos braços de Lu Linyuan.

Ainda abraçada a ele, ergueu devagar a cabeça. Seus olhos se arregalaram, encantados com as luzes multicoloridas que iluminavam o céu da Cidade Imperial.

Jamais vira um espetáculo tão impressionante. Na cidade onde morava no mundo moderno, as normas municipais proibiam rigorosamente fogos de artifício. Era a primeira vez que contemplava uma apresentação daquela grandiosidade.

E assim permaneceu, pendurada em Lu Linyuan, contemplando o céu embevecida.

As luzes cintilantes iluminavam seu rosto de pele impecável como jade, realçando sua beleza extraordinária.

— Uau! Majestade, olha!

— Sim, estou olhando.

Mas Lu Linyuan não ergueu a cabeça. Baixou um pouco os olhos e contemplou sem desviar o olhar aquela coalinha agarrada a seu corpo.

— Majestade, olha aquele! Que coisa linda!

— Sim, eu sei que ela é linda.

*

Escondida um pouco mais longe, Gu Sijin observava silenciosamente a cena. Os fogos que enchiam o céu não eram novidade para ela; o que lhe arrancava sorrisos era a imagem daquele belo casal aconchegado sob a luz da lua e das explosões coloridas.

Depois de sorrir, porém, não conseguiu evitar uma pontada de tristeza.

A mão que segurava o lenço se fechou aos poucos. Ela ergueu os olhos para os fogos que se espalhavam como estrelas.

Na dinastia Qi, os fogos de artifício também tinham um belo nome: «estrelas flamejantes».

Mas, por mais que os fogos voltassem todos os anos, talvez ela jamais reencontrasse, nesta vida, a sua própria «Estrela Flamejante».

Nunca havia entendido por que sentia tanta alegria sincera sempre que via Xiaoxiao e Lu Linyuan juntos.

Só naquele dia finalmente percebeu:

Naquele casal, ela enxergava a si mesma e a Chu Xingran, como haviam sido no passado.

Sorriu com tristeza e disse a Qiqi e às outras, que ainda admiravam os fogos:

— Tudo isso não passou de um grande mal-entendido. Vamos voltar discretamente ao palácio, sem atrapalhar Sua Majestade e Xiaoxiao.

O espetáculo de fogos durou quase um quarto de hora inteiro.

E durante todo aquele quarto de hora Ning Xiaoxiao continuou pendurada no corpo de Lu Linyuan.

A princípio, não desceu porque estava tão fascinada que esquecera onde estava. Depois, porque a mão com que Lu Linyuan lhe sustentava o traseiro se apertou discretamente: ele não pretendia soltá-la.

— Hã... Majestade, os fogos já acabaram. Que tal me colocar no chão agora?

— Já passou da meia-noite. Feliz aniversário.

Ning Xiaoxiao ficou intrigada: — Eu só disse uma vez ao senhor a data do meu aniversário. O senhor guardou mesmo essa informação?

Lu Linyuan baixou a cabeça para fitá-la e, com um sorriso cheio de segundas intenções, desviou do assunto numa voz baixa, que lhe fazia cócegas nos ouvidos:

— Acho que estou com um pouco de fome. Que tal você preparar uma tigela de macarrão para mim?

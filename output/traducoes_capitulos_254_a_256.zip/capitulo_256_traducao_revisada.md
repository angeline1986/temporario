# Capítulo 256 — Se isso a faz feliz, que mal há em ser um imperador irresponsável?

A graça da semelhança entre os nomes “Consorte Zhang” e “Zhang Fei” era algo que só Ning Xiaoxiao podia entender.

Afinal, naquele universo fictício, a história não registrava a existência de Liu Bei, Guan Yu e Zhang Fei.

O que espantava os presentes era simplesmente o gosto peculiar de Huyan Zhu: como conseguia acolher uma mulher daquelas em seu harém como consorte?

Se todos pensavam que a chegada da Consorte Zhang já era surpreendente o bastante, estavam enganados. Aquilo era só o começo da comédia que Zhuyin apresentaria naquela noite.

Depois da Consorte Zhang, outra mulher extraordinária surgiu à porta.

Não era muito alta — chegava apenas à altura do peito da Consorte Zhang —, mas tinha músculos firmes por todo o corpo.

Os bíceps quase arrebentavam as mangas da roupa. E, diante do volume bem definido na parte da frente do torso, era difícil saber se aquilo eram seios ou músculos peitorais.

Huyan Zhu a apresentou: — Esta é uma das minhas concubinas, Liu Bei.

Aquele nome acertou em cheio o senso de humor de Ning Xiaoxiao mais uma vez.

No silêncio absoluto do salão, só se ouvia sua gargalhada incontrolável.

Lu Linyuan não fazia ideia do motivo de tanta graça. Mas, ao vê-la rir, também não conseguiu evitar um sorriso.

Por fim, surgiu à porta uma mulher gigantesca, de nada menos que dois metros de altura.

Talvez por ser tão alta, não encontrara calças compridas o bastante: um pedaço dos tornozelos ficava exposto.

Pelos grossos e numerosos escapavam do tecido liso das calças. Eram tão densos que, no verão, talvez nem um mosquito conseguisse encontrar espaço para pousar e picá-la...

A essa altura, Ning Xiaoxiao já aprendera a se antecipar. Perguntou: — Não me diga que esta é Guan Yu?

Huyan Zhu pareceu surpreso: — Como? Vossa Alteza já a conhecia? Exatamente! Esta é outra das minhas concubinas, chamada Wan Yu.

...

Caramba! Então você reuniu Liu, Guan e Zhang no harém para encenar o juramento de fraternidade do Jardim dos Pessegueiros na sua própria cama?

Quando todas estavam presentes, Huyan Zhu começou a explicar as regras da competição:

— Zhuyin apresentará três consortes. Qi também poderá escolher três mulheres. Elas disputarão quedas de braço em duplas, uma de cada lado, e vencerá quem ganhar duas das três partidas. O que Vossa Majestade acha?

Lu Linyuan examinou as três figuras de aparência tão pouco convencional diante do trono e perdeu a confiança.

Só pela constituição física, era fácil perceber que aquelas mulheres poderiam enfrentar sozinhas uma centena de inimigos no campo de batalha.

Se homens competissem contra elas, ainda haveria alguma possibilidade de vitória.

Mas em Qi, as mulheres da corte prezavam a delicadeza de gestos e a figura esbelta, pois a magreza era considerada bela. Como poderiam enfrentar adversárias daquelas?

Qingyang treinava artes marciais desde criança e sabia lutar.

Incomodada com a expressão presunçosa de Huyan Zhu, ofereceu-se: — Nesse caso, eu serei a primeira a...

— Deixa comigo.

Antes que terminasse a frase, Ning Xiaoxiao a interrompeu do lugar de honra.

Todos olharam ao mesmo tempo para Ning. Ela pegou um lenço, enxugou as mãos e aceitou a disputa com a maior naturalidade.

Ning Xiaoxiao comia bastante, mas tinha um metabolismo que a impedia de engordar.

Mesmo deixando a Consorte Zhang de lado, até Liu Bei, a mais “delicada” das três, parecia ter o dobro da largura de Ning. Como ela pretendia competir?

Lu Linyuan franziu a testa e tentou impedir a imprudência em voz baixa: — Por que vai se meter nisso? Com esses bracinhos e perninhas, elas vão desmontar você inteira!

Ning, porém, parecia absolutamente segura de si. Bateu no próprio peito e respondeu com confiança:

— Não se preocupe, Majestade! Sou capaz até de quebrar uma pedra enorme no peito. Uma simples queda de braço? Moleza!

Não era a primeira vez que Lu Linyuan lidava com a mania de sua esposa de se meter em toda confusão. Sentiu uma dor de cabeça e levou a mão à testa, pensando:

【Na disputa contra Xiliang, você só conseguiu quebrar aquela pedra porque seu busto enorme fez o milagre acontecer.】

【Agora é queda de braço! Você acha que eu não conheço a força de pintinho que tem?】

Sua expressão ficou severa: — Você não vai!

Mas nem toda a severidade de Lu Linyuan era páreo para a “diplomacia delicada” de Ning Xiaoxiao.

Ela se agarrou ao braço dele, fez um biquinho e o fitou com um ar tão pidão que parecia prestes a chorar:

— Ah, Majestade! Deixa eu ir! Deixa eu brincar só um pouquinho, vai?

Alguns ministros sentados abaixo não conseguiam disfarçar a reprovação. Afinal, tratava-se de um assunto de Estado. Como permitir que uma mulher o tratasse como uma brincadeira?

— Ah, Yuan! Meu Yuan é o melhor de todos! Um beijinho no meu Yuan querido!

Dizendo isso, inclinou-se diante de todos e deu um beijo estalado na bochecha esquerda de Lu Linyuan.

Os ministros: — !!!

Lu Linyuan: — ...

Eu sei que isso é assunto de Estado e que não posso permitir que ela faça o que quer... Mas ela está fazendo charme para mim! Ela me beijou!

— Cof, cof... Está bem, então. Vá se divertir um pouco. Mas tome cuidado para não se machucar.

Os ministros ficaram boquiabertos. Lu Linyuan sempre colocara os assuntos de Estado acima de tudo. Desde quando se tornara tão absurdo?

Estavam prestes a apresentar suas objeções quando Huyan Zhu se adiantou com um comentário mordaz:

— A Consorte Nobre parece não ter nem um punhado de carne nos ossos. Aconselho Vossa Alteza a não se meter nisso.

Ning Xiaoxiao sorriu com desdém e lançou-lhe um olhar de superioridade: — Então vamos aumentar a aposta? Eu, sozinha, enfrento as três. Se eu perder, o reino de Zhuyin será imediatamente transformado no condado de Zhuyin.

— Assim, seremos todos uma grande família. E, entre familiares, não precisamos ficar fazendo cerimônia: Sua Majestade poderá dispensar seus tributos e, se estiver de bom humor, talvez até ajudá-los a atravessar a calamidade da neve. Que tal?

Huyan Zhu examinou Ning. Com aquele corpinho franzino, bastaria o dedo mindinho da Consorte Zhang para derrubá-la.

Se ela própria fazia uma proposta tão presunçosa, por que ele não haveria de aceitar?

— E se Vossa Alteza vencer?

Lu Linyuan respondeu: — Se ela vencer, concederei a Zhuyin dez anos de isenção de tributos.

Os ministros não conseguiram mais ficar sentados: — Majestade, pense bem!

Huyan Zhu foi rápido em responder: — A palavra de um imperador tem o peso de ouro. Então faremos como a Consorte Nobre propôs!

No fundo, Lu Linyuan também sabia que Ning Xiaoxiao não tinha como vencer daquela vez.

Ela era esperta, cheia de truques e possuía capacidades estranhas, mas aquilo era uma disputa de força bruta. E ele conhecia perfeitamente a força da própria esposa.

Só que Xiaoxiao estava tão animada! Como poderia estragar sua diversão?

Se isso a fazia feliz, que mal havia em se comportar como um imperador irresponsável uma vez na vida?

Isso não significava, porém, que fosse abandonar de verdade os interesses do Estado.

E daí se Huyan Zhu acabasse vencendo?

Ele podia simplesmente deixar de agir com espírito esportivo.

Se Ning perdesse, ele poderia voltar atrás imediatamente, retirar a promessa e até se recusar, diante de todos, a reconhecer a validade da disputa.

Afinal, Zhuyin era um território minúsculo, com tropas derrotadas e um povo mergulhado na miséria. Mesmo que saltasse, não alcançaria sequer os joelhos de Qi. O que havia a temer?

A exigência de honrar compromissos numa disputa pressupunha forças relativamente equilibradas. Se um dos lados detivesse poder absoluto sobre o outro, a parte dominante nem precisava cumprir a palavra dada à parte mais fraca.

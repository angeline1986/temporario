# Capítulo 255 — Essa é a Zhang Fei!

Huyan Zhu estava prestes a perder a calma quando ouviu Qingyang dizer, sorrindo:

— Este vinho é uma homenagem a seu pai. Uma pena que tenha morrido sem deixar um sucessor à altura, tendo de escolher um inútil como você, sem beleza, competência ou sequer noção de etiqueta, para herdar seu trono.

Huyan Zhu a encarou com ódio e ameaçou entre os dentes: — Não vá longe demais!

Qingyang soltou uma risada fria. — Eu é que fui longe demais? Você não tem o menor respeito às regras e ainda vem a Qi se cobrir de vergonha?

— Eu era a rainha secundária de seu pai. Depois que ele morreu, a rainha principal faleceu de tristeza. Quando você ascendeu ao trono, eu me tornei sua mãe secundária, a consorte de posto mais elevado do harém de Zhuyin. Se não tivesse voltado a Qi, você não teria de me reverenciar como imperatriz-viúva?

Ela estendeu a mão e acariciou a cabeça dele com descarado ar de provocação.

— Bom menino, por que não chama a mamãe?

Humilhação!

Uma humilhação sem precedentes!

Huyan Zhu tinha apenas dezoito anos e ocupava o trono havia poucos meses. Estava naquela idade impetuosa em que se achava melhor do que todos.

Como poderia preservar a dignidade depois de ser humilhado publicamente por uma mulher?

Ergueu a taça, pronto para arremessá-la ao chão. Mal levantou o braço, porém, uma voz displicente soou do assento de honra. Era Lu Linyuan:

— Hoje é a véspera do Ano-Novo em Qi, uma ocasião festiva. Só lhe concedi a honra de se sentar à mesa porque veio de tão longe prestar suas felicitações.

— Se ousar fazer escândalo aqui, não me importarei de enviar tropas assim que o Ano-Novo passar e transformar o reino de Zhuyin no condado de Zhuyin.

Huyan Zhu perdeu imediatamente toda a coragem.

Viera pedir a Lu Linyuan que reduzisse os tributos de seu reino. Se tentasse obter vantagem e terminasse perdendo o próprio país, não se tornaria o maior pecador da história de Zhuyin?

Engoliu a raiva e abaixou a mão que segurava a taça. Lu Linyuan, percebendo que Qingyang não apenas deixara de fugir das lembranças humilhantes do passado, mas viera decidida a devolver cada afronta, resolveu lhe dar mais uma ajudinha.

— Xiao Yinzi, encha a taça dele novamente. Que faça primeiro um brinde à princesa mais velha.

Huyan Zhu, contrariado, aproximou sua taça cheia da de Qingyang. Ela permaneceu imóvel: — Que falta de educação! Chame-me como deve.

Huyan Zhu: — Você...!

Qingyang: — Você o quê? Não sabe como me chamar? Está querendo mesmo que seu reino vire um condado?

Huyan Zhu jamais imaginara que Qingyang se transformaria tanto depois de retornar a Qi.

Ouvira dizer que Qi tratava com generosidade os reinos submetidos à sua autoridade. Por que então encontrava obstáculos em tudo?

Sob o teto dos outros, era preciso abaixar a cabeça. Afinal, tinha um favor a pedir a Lu Linyuan.

Por isso, forçando-se a engolir o orgulho, murmurou quase inaudivelmente: — Mãe imperial...

— Pois não~ — Qingyang respondeu, satisfeita, e só então bebeu o vinho.

O banquete prosseguiu. Lu Linyuan se ocupava descascando camarões para Ning Xiaoxiao. Sanfu se ofereceu para assumir aquele trabalho grosseiro, mas o imperador rebateu: — A Consorte Nobre por acaso pode comer algo em que suas mãos tocaram?

Sanfu: — ...

As taças se cruzavam e os convidados conversavam animadamente. Quase ninguém dava atenção a Huyan Zhu.

Depois de beber três taças seguidas, ele se levantou para brindar com Lu Linyuan. Como o imperador estava com os dedos sujos de molho, não podia lhe dar atenção. Pediu então que Ning erguesse a taça, brindasse em seu lugar e depois a entregasse a ele para beber.

Quando terminaram o brinde, Huyan Zhu não voltou ao assento. Em vez disso, revelou o motivo da visita:

— Majestade, vim discutir um assunto com Vossa Majestade.

— O casamento diplomático da princesa mais velha foi uma decisão tomada pelos soberanos anteriores e nada tem a ver com a situação política atual. Além disso, Zhuyin já se submeteu a Qi, e a princesa regressou em segurança. É motivo de celebração.

— Mas Zhuyin enfrenta um inverno rigoroso. Há meses a neve não para de cair, e os danos são muito graves.

— Espero que Vossa Majestade considere reduzir os tributos que Zhuyin deverá pagar no próximo ano, para que nosso povo consiga superar esta calamidade.

Lu Linyuan permaneceu concentrado em descascar os camarões. Nem se deu ao trabalho de levantar os olhos.

Só depois de descascar sete ou oito camarões enormes, espetá-los num palitinho de bambu e entregá-los a Ning Xiaoxiao é que falou suavemente:

— Coma menos pimenta. Senão amanhã seu rosto vai ficar cheio de espinhas, e você vai passar um tempão reclamando comigo.

Ning Xiaoxiao comia e se divertia acompanhando a fofoca ao mesmo tempo. Não poderia estar mais satisfeita.

Ao ver a esposa feliz, Lu Linyuan enfim se dignou a responder ao visitante:

— Quem você pensa que é para continuar se chamando de “este rei” na minha presença?

Huyan Zhu ficou desconcertado e corrigiu-se: — Então... “seu súdito”?

Lu Linyuan: — Acrescente “humilde” antes de falar.

Com o rosto lívido, Huyan Zhu obedeceu: — ... Este humilde súdito implora que Vossa Majestade ajude Zhuyin a superar a crise.

Sanfu trouxe uma bacia de cobre com água perfumada de rosas para Lu Linyuan lavar as mãos. Só então o imperador ergueu o olhar para Huyan Zhu e respondeu com um sorriso frio:

— Zhuyin não se submeteu voluntariamente a Qi. Eu lhes dei um ultimato: curvem-se ou preparem-se para a guerra. Qi já não é o mesmo reino dos tempos de seu pai, quando uma naçãozinha como a sua ainda imaginava poder nos enfrentar de igual para igual.

— Vocês se renderam, e mesmo assim permiti que conservassem suas terras, em vez de anexá-las a Qi. Por isso, entregar tributos a Qi é sua obrigação.

— Simplificando: você me paga, e eu não ataco. Pretende deixar de me pagar e ainda quer que eu permita que continue existindo?

— Quer todos os benefícios sem cumprir dever nenhum. Isso lhe parece razoável?

Huyan Zhu esperava que Lu Linyuan não cedesse facilmente. Também sabia que Qi se orgulhava de ser uma nação rica, poderosa e sem rivais entre os povos vizinhos.

Então propôs: — Vossa Majestade aceitaria competir comigo? Se este humilde súdito vencer, Vossa Majestade atenderá ao pedido. Se eu perder, não apenas pagarei todos os tributos, como acrescentarei mais trinta por cento!

Lu Linyuan deu uma gargalhada: — Já ouvi isso antes. O rei de Xiliang fez a mesma proposta. Foi derrotado de forma tão humilhante que seu povo ainda trabalha para pagar a dívida com Qi. Tem certeza de que pensou bem?

Huyan Zhu conhecia a história de como o rei de Xiliang fora obrigado a imitar um cachorro aos pés de Lu Linyuan, na capital imperial. Mas dessa vez viera preparado e tinha certeza da vitória.

— Se fiz a proposta, é porque posso cumpri-la. Vossa Majestade não precisa se preocupar.

Lu Linyuan: — Então diga: em que deseja competir?

Huyan Zhu: — Algo simples: queda de braço.

A confiança do rapaz arrancou outra risada de Lu Linyuan: — Só isso?

Quando se tratava de força física, Ren Duanli era capaz de erguer com cada braço dois caldeirões de mais de cinquenta quilos e ainda correr algumas voltas como se não pesassem nada.

Numa competição dessas, Zhuyin não teria a menor chance.

Huyan Zhu esclareceu: — É uma disputa de força, sim, mas não entre homens. Será entre mulheres!

Ele bateu palmas três vezes. De repente, ouviram-se passos do lado de fora, tão pesados que pareciam fazer o chão tremer a cada pisada.

A música e a dança cessaram. Todos voltaram os olhos para a porta.

Uma “guerreira” de corpo robusto como o de um boi entrou no salão. Era tão larga que quase ficou entalada no batente.

Ao vê-la, Ning Xiaoxiao quase cuspiu a sopa que tinha na boca.

Não bastasse ser corpulenta, a mulher tinha uma aparência extraordinária: ostentava pelos tão abundantes acima dos lábios que, de longe, pareciam uma barba masculina.

Seus olhos já eram pequenos e, com as bochechas muito cheias, quase desapareciam entre as dobras do rosto.

E suas sobrancelhas eram tão espessas e indomáveis que talvez fossem duas vezes mais largas do que seus olhos...

Todos a observavam como se fosse um monstro. Diante da perplexidade geral, Huyan Zhu ficou ainda mais convencido de sua vitória:

— Permitam-me apresentá-la a Vossa Majestade. Esta é minha querida consorte, a senhora Zhang.

Ele ergueu as sobrancelhas em sinal para ela: — Consorte Zhang, cumprimente Sua Majestade.

— Pfff!

Ao ouvir aquele nome, Ning Xiaoxiao não conseguiu conter a gargalhada:

— Ótimo nome! Perfeito! A Consorte Zhang é mesmo a cara do nome que carrega.

A Consorte Zhang não percebeu o tom da brincadeira e achou que Ning a elogiava.

Com uma voz ainda mais grossa que a de muitos homens, gritou:

— Valeu!

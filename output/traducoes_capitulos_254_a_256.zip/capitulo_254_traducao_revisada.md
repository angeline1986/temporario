# Capítulo 254 — Você é meu filho

Qi Meijuan nunca fora de fazer drama. Além disso, naquela situação, quanto mais demorasse a partir, mais difícil seria para sua filha deixá-la ir.

Então endureceu o coração, tomou uma decisão e foi embora sem hesitar!

— Mãe, quando você vem me visitar de novo?

— Cunhada imperial? Por que está me abraçando?!

Lu Yiqiu empurrou Ning Xiaoxiao bruscamente, como se ele é que tivesse sido assediado, e protestou com uma ferocidade quase infantil: — E se o meu Li-Lizinho... Ah, não... E se meu irmão vir e entender tudo errado?

Ning Xiaoxiao: — ...

Ela chorava tanto que o nariz escorria. E sua mãe havia fugido depressa, como se receasse que ela limpasse o ranho em sua roupa...

Ning virou-se para enxugar as lágrimas e ouviu Lu Yiqiu resmungar consigo mesmo: — Que estranho... Eu estava dormindo. Como vim parar aqui?

— Você é sonâmbulo. Já que não tem nada melhor para fazer, procure um médico imperial especializado em proctologia e vá se tratar.

Lu Yiqiu: — ???

Ning Xiaoxiao ainda pretendia provocá-lo mais um pouco quando ouviu alguém chamá-la ao longe.

— Vossa Alteza, Consorte Nobre? Está por aí? Consorte Nobre!

Ela olhou na direção da voz e avistou Sanfu procurando de um lado para outro. Acenou: — Aqui! O que houve?

Sanfu correu até ela a passos largos e, sem nem se lembrar de cumprimentar Ning e Lu Yiqiu, falou antes de recuperar o fôlego: — Aconteceu uma coisa grave... O novo soberano de Zhuyin chegou à residência das fontes termais com suas consortes. Diz que veio pessoalmente felicitar Sua Majestade pelo Ano-Novo.

Lu Yiqiu não entendeu o alarme: — Hoje é o banquete da véspera do Ano-Novo. Todos os anos, povos e reinos estrangeiros enviam emissários para prestar homenagens a Qi. Quando muda o governante de um povo, o novo chefe deve comparecer pessoalmente perante meu irmão. É uma tradição antiga. Por que tanto nervosismo?

Sanfu suspirou: — Ai, tradição é tradição, mas veja que falta de sorte! Depois da morte do rei de Zhuyin, como a princesa mais velha não teve filhos, Sua Majestade a trouxe de volta ao palácio. Todos sabemos, porém, que o falecido imperador a obrigou a se casar em Zhuyin, onde ela sofreu incontáveis humilhações. Se encontrar alguém de lá, não vai acabar revivendo lembranças horríveis?

— Zhuyin veio conforme o protocolo, e Sua Majestade não pode simplesmente expulsar os visitantes. Por isso me mandou procurar Vossa Alteza, para ver se consegue manter a princesa ocupada e evitar um desgosto em plena festa de Ano-Novo.

Lu Linyuan sempre prestava atenção aos detalhes. Não admitia nem a possibilidade de que alguém que estimasse sofresse algum mal.

Desta vez, porém, parecia ter subestimado a capacidade da princesa de suportar o passado.

Ao menos para Ning Xiaoxiao, Qingyang definitivamente não era do tipo que ficaria para sempre aprisionada em antigas tristezas.

Pelo contrário. Com aquela personalidade de mulher imponente, se reencontrasse um velho inimigo agora em seu próprio território, provavelmente estaria ansiosa para esfregar a derrota na cara dele.

Ning foi até o Pavilhão das Flores Embriagadas. Encontrou Qingyang esplendidamente vestida, bela e radiante. A serenidade natural da princesa se tornava ainda mais evidente no sorriso discreto de seus lábios.

Huanü colocava um enfeite de flores na testa dela. Qingyang lançou um olhar de soslaio a Ning e sorriu: — Pequena, foi o imperador que mandou você aqui?

Ning Xiaoxiao aproximou-se e deu duas voltas ao redor da princesa. Faltava pouco para se jogar aos pés dela.

Que mulher linda e poderosa! Dava vontade de ficar bem agarradinha nela.

— Imagino que Vossa Alteza já saiba quem chegou à residência das fontes termais, não é?

Qingyang pegou um grampo em forma de fênix e o aproximou de seu penteado, como se avaliasse onde ficaria melhor. Respondeu, tranquila:

— Meu filho chegou. Como eu poderia deixar de recebê-lo?

Ning Xiaoxiao: — Hã?

Qingyang explicou: — Pouco depois da morte do antigo rei de Zhuyin, a rainha também morreu de tristeza. Naquela época, eu ainda estava lá. Como rainha secundária, naturalmente deveria ser reverenciada como imperatriz-viúva depois da ascensão do novo rei. O que há de errado em dizer que meu filho veio me procurar?

Seu sorriso era sereno, sem a menor sombra de desgosto.

Depois de terminar de se arrumar, Qingyang deu algumas instruções a Huanü e pediu que ficasse ali por enquanto. Assim que despachasse o novo rei de Zhuyin, mandaria chamá-la para participar do banquete no Terraço das Nuvens Azuis.

Temia que o jovem rei fizesse comentários maldosos, zombando das humilhações que ela sofrera em Zhuyin, e que Huanü se magoasse ao ouvi-los.

*

Quando Qingyang e Ning Xiaoxiao chegaram juntas ao Terraço das Nuvens Azuis, quase todos os convidados já estavam reunidos.

Bastava observar os lugares reservados para perceber que Lu Linyuan não pretendia tratar o novo rei de Zhuyin com cerimônia.

Seu assento ficava ainda mais distante da posição de honra do que o de Ren Duanli. Havia sido relegado a um canto, numa humilhação deliberada.

O lugar vazio ao lado de Lu Linyuan, naturalmente, estava reservado para Ning Xiaoxiao. Como todos haviam presumido que Qingyang não compareceria, não haviam preparado um assento para ela.

Lu Yiqiu, sempre atento a essas coisas, levantou-se e ofereceu seu lugar a Qingyang. Ela recusou sorrindo: — Fique onde está. Hoje há um velho conhecido meu no banquete. Naturalmente, quero me sentar ao lado dele.

— Xiao Yinzi, venha cá. Ponha uma cadeira ao lado de Huyan Porco. Quero colocar a conversa em dia com ele.

— ... — Huyan “Porco” ergueu a cabeça e a fulminou com olhos de águia, tão furiosos que pareciam prestes a sangrar. — Meu nome é Huyan Zhu!

Qingyang cobriu a boca com a mão e riu. Quando Xiao Yinzi trouxe a cadeira, ela se sentou tranquilamente.

— É mesmo? Mil perdões. Meu sotaque de Qi às vezes me atrapalha. Aqui em Qi, “bambu” e “porco” têm a mesma pronúncia.

Abriu as mangas com imponência e lançou um olhar aos presentes: — Algum dos ministros discorda?

Os oficiais presentes para celebrar o Ano-Novo não esperavam assistir a um espetáculo daqueles. Primeiro olharam todos para Lu Linyuan. Quando ele assentiu discretamente, responderam em coro:

— A princesa mais velha está coberta de razão!

Huyan Zhu: — Você...!

Vendo que os dois mal haviam se sentado e já pareciam prestes a brigar, Lu Linyuan inclinou-se para sussurrar ao ouvido de Ning Xiaoxiao: — Não pedi que você a convencesse a não vir?

Ning arregalou seus olhos inocentes e piscou: — Eu tentei convencê-la! Mas, se ela não me escutou, o que eu podia fazer...?

— ...

Lu Linyuan levou a mão à testa, impotente.

【Desde que você entrou, estou ouvindo seus pensamentos sobre como vai se divertir assistindo à confusão!】

【O que foi que você tentou convencê-la a fazer?】

【Vir correndo para cá?】

O tumulto no salão prosseguia. Sentado bem ao lado de Qingyang, Huyan Zhu ergueu sua taça e bateu-a com força contra a dela.

— Faz muito tempo que não vejo a rainha secundária. Desde que voltou a Qi, parece tão cheia de vida! Nem lembra a mulher submissa que vivia se humilhando em Zhuyin.

Nos tempos em que estivera em Zhuyin, Qingyang tramara continuamente uma maneira de acabar com o rei. Por isso precisara esconder a própria força e aguardar a ocasião certa.

Agora, ao ouvir a provocação, não se perturbou. Ergueu a taça com toda a dignidade e retribuiu o brinde.

Mas, depois que Huyan Zhu bebeu seu vinho com ar de triunfo, ela arqueou ligeiramente uma sobrancelha e, sorrindo diante dos olhos dele, derramou sua bebida no chão.

Huyan Zhu: — !!!

Tanto em Qi quanto em Zhuyin, derramar vinho na terra era um gesto de homenagem aos mortos.

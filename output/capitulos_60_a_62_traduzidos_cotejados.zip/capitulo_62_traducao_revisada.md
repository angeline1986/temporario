# Capítulo 62 — Não posso simplesmente ir embora

Ning Xiaoxiao sentou-se na cama de um salto.

【Como assim, vai morrer? Explique isso direito!】

Xiao Qi explicou: 【É que você colocou perila na sopa de fritilária e nêspera que levou ao tirano.】

【Perila?】

Ning Xiaoxiao realmente acrescentara perila. Era uma erva medicinal usada para tratar tosse e resfriados e ela acreditara que ajudaria Lu Linyuan a se recuperar mais depressa.

Mas por que ele morreria se a comesse? Aquilo não era uma planta medicinal sem veneno?

Ning Xiaoxiao: 【O que a perila tem a ver com isso?】

Xiao Qi: 【Porque o tirano tem uma alergia gravíssima a perila!】

Ning Xiaoxiao: 【?? Mas isso nunca foi mencionado na história original!】

Xiao Qi: 【Exatamente! Por isso você ativou uma linha narrativa secreta!】

Ning Xiaoxiao: 【Então, se Lu Linyuan morrer agora, é como se eu mesma o tivesse matado? Mas você disse que existiam restrições na minha entrada neste livro, que eu não podia fazer nenhum personagem importante morrer antes da hora! Como é que ele...】

Xiao Qi: 【É assim: em princípio, você não pode provocar deliberadamente a morte prematura de nenhum personagem importante. Mas, como isto aconteceu por acidente, sem que soubesse das consequências, não conta como uma ação intencional sua. Portanto, o caso é considerado uma linha narrativa secreta.】

Ning Xiaoxiao não conseguia aceitar aquilo e achou que Xiao Qi só podia estar brincando.

Fechou os olhos, abriu o documento da trama e percorreu rapidamente os acontecimentos futuros. Então puxou o ar, horrorizada:

Lu Linyuan realmente era alérgico a perila.

E, como naquela época não havia bons tratamentos para alergias, seu estado pioraria nos três dias seguintes. Ele morreria no dia oito do nono mês...

Era... assim que tudo terminaria?

Desde o momento em que entrara naquele mundo, Ning Xiaoxiao sonhava, dia e noite, com a possibilidade de voltar para casa.

Mas agora, quando esse momento enfim chegava, ela experimentava um sentimento impossível de descrever.

Ela havia causado a morte de Lu Linyuan. Seria certo simplesmente ir embora?

Xiao Qi percebeu sua hesitação e tentou convencê-la:

【Você não precisa se preocupar com o processo! Afinal, todos os personagens do livro são apenas figuras de papel para você. Por que se importar com o que acontece no caminho? O importante é que o resultado é bom! É uma oportunidade que aparece uma vez a cada mil anos! Já acompanhei tantas hospedeiras e você é a única a conseguir se formar antes do prazo!】

Havia até uma pontinha de empolgação na voz de Xiao Qi.

Mas aquele resultado podia realmente ser considerado bom?

Se Lu Linyuan não tivesse passado uma noite inteira no frio de Yanxi para comprar a pulseira, não teria adoecido. Se não tivesse adoecido, ela não teria inventado de preparar uma sopa de fritilária e nêspera. E, se não tivesse preparado a sopa, ele não teria ingerido perila... e não morreria.

Em outras palavras, Lu Linyuan percebera sua tristeza por perder a pulseira e, por bondade, comprara outra igual para ela. E ela retribuíra matando-o com uma tigela de remédio?

Não era como se o tivesse matado com as próprias mãos?

Depois de pensar muito, Ning Xiaoxiao tomou uma decisão:

Precisava salvar Lu Linyuan.

Não podia simplesmente ir embora!

Sem perder mais uma palavra com Xiao Qi, abriu o documento e começou a tentar modificar a trama.

Havia acumulado mais de cem caracteres disponíveis para alteração. Não deveria ser difícil fazer Lu Linyuan se recuperar.

O texto original dizia:

〈Lu Linyuan, gravemente enfermo e sem possibilidade de cura, agonizou por três dias até finalmente morrer.〉

Ela tentou apagar aquela passagem e substituí-la por outra.

Mas descobriu que o trecho estava bloqueado. Não tinha permissão para modificá-lo!

Foi quando Xiao Qi reapareceu:

【Você enlouqueceu? O que está fazendo? Não quer mais voltar para casa?】

Ning Xiaoxiao: 【Chega de conversa! Por que não consigo alterar a história?】

Xiao Qi: 【Eu já lhe disse: você pode modificar a trama, mas não pode mudar diretamente a vida ou a morte de um personagem. Ficou com pena dele? Não acredito! Ele não passa de um personagem fictício, uma figura de papel! Era melhor ter pena de si mesma!】

【Além disso, quanto antes você voltar, mais cedo eu cumprirei minha missão e melhorarei meus indicadores de desempenho. É uma situação em que todo mundo ganha! O que há de errado nisso?】

Só então Ning Xiaoxiao entendeu as “intenções ocultas” de Xiao Qi.

Se conseguisse mandá-la de volta para casa, o sistema cumpriria sua missão e aumentaria seus indicadores de desempenho. Portanto, mesmo que existisse uma forma de salvar Lu Linyuan, Xiao Qi tentaria impedi-la.

Diante disso, Ning Xiaoxiao simplesmente apertou o botão Pausar e congelou o tempo de todo aquele mundo.

Xiao Qi se espantou. 【O que está fazendo?!】

Ning Xiaoxiao: 【Se não puder salvá-lo, vou deixar o tempo deste mundo parado para sempre! Enquanto eu não chegar ao final, você não vai cumprir suas metas! Pode se preparar para passar o resto da vida preso neste livro comigo!】

Xiao Qi: 【Hospedeira... V-v-você... Isso é jogar sujo! Não pode me ameaçar! E está mesmo disposta a abrir mão da grande chance de voltar para casa por causa de um personagem de papel?】

A atitude de Ning Xiaoxiao era resoluta, e sua voz não vacilou:

【Não estou ameaçando você, nem dizendo que não quero voltar para casa. Mas não vou abandonar meus princípios só para conseguir o que quero! Ele está entre a vida e a morte por minha causa. Se eu cruzar os braços e for embora, qual é a diferença entre isso e matá-lo? Para você ele pode ser um personagem de papel, mas eu convivo com ele todos os dias! Como poderia agir com tanta frieza?】

Xiao Qi: 【...】

O sistema estava com tanta raiva que queria dar uma bofetada em Ning Xiaoxiao!

Tinha certeza de que aquela era a hospedeira mais idiota que já acompanhara!

E a primeira a explorar uma falha de suas habilidades especiais para ameaçar o próprio sistema!

Ao mesmo tempo, porém, comparada às demais hospedeiras, ela parecia ser a única realmente feita de carne, osso e sentimentos...

No fim, Xiao Qi cedeu.

【Você realmente me tira do sério, sua trapaceira! Se não quer mesmo que o tirano morra, existe uma maneira. Mas não posso lhe dizer qual é. Vai ter de descobrir sozinha.】

Descobrir sozinha?

Uma alergia podia ser leve ou grave. E a de Lu Linyuan era gravíssima!

Mesmo na medicina moderna, com os recursos mais avançados, não era possível garantir a cura de todos os casos.

Ela era só uma universitária, e ainda por cima estudava outra área! Aquele sistema maldito não podia esperar que ela solucionasse um problema médico tão complexo na Antiguidade!

Nesse momento, ouviu Xiao Qi cantarolando em sua mente:

【Ah, amor QQ... Quem saberá dizer se é verdadeiro ou não...?】

Aquela música antiga, típica de uma época de modinhas extravagantes, fez Ning Xiaoxiao se lembrar de um prêmio que recebera na roleta.

— A bala de goma QQ que neutralizava todos os venenos!

Xiao Qi dissera que aquela bala podia eliminar qualquer veneno e curar doenças assim que fosse ingerida.

Se desse a bala a Lu Linyuan, talvez ele se recuperasse.

Então Xiao Qi cantara aquela música justamente para lhe dar uma pista?

Num raro momento de sentimentalismo, Ning Xiaoxiao disse: 【Xiao Qi, obrigada!】

Xiao Qi: 【... Eu não disse absolutamente nada, viu!】

Ning Xiaoxiao: 【Hehe! Você é uma pestinha de língua afiada, mas tem um coração mole!】

Xiao Qi: 【Olha o respeito... Se vai salvá-lo, ande logo! Pare de enrolar!】

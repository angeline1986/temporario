# Validação — capítulo 61

- **Fonte primária:** `novel_capitulos_61_a_120(20261103-184549).docx`.
- **Limites no DOCX:** parágrafos 3–82 (índices iniciados em zero).
- **Unidades não vazias do original, título incluído:** 77.
- **Linhas de dados no CSV:** 77.
- **Unidades sem correspondência, vazias ou extras:** 0.
- **Método:** tradução diretamente do chinês tradicional, alinhada a cada parágrafo com seu índice de origem; verificação programática de cobertura e preenchimento, com revisão editorial durante a tradução.
- **Cuidados narrativos e editoriais:** Sanfu explica a origem da pulseira, Lu aceita a sopa apesar de detestar doces e Xiao Qi anuncia a linha narrativa secreta. A metáfora da doçura no coração foi conservada. Mantém-se o suspense do último parágrafo sem revelar antecipadamente a causa da morte anunciada.
- **Limite da validação:** o alinhamento 1:1 confirma cobertura estrutural, não fidelidade semântica absoluta. Não houve segunda auditoria linguística independente.

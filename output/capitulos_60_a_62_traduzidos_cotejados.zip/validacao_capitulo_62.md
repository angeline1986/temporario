# Validação — capítulo 62

- **Fonte primária:** `novel_capitulos_61_a_120(20261103-184549).docx`.
- **Limites no DOCX:** parágrafos 83–157 (índices iniciados em zero).
- **Unidades não vazias do original, título incluído:** 72.
- **Linhas de dados no CSV:** 72.
- **Unidades sem correspondência, vazias ou extras:** 0.
- **Método:** tradução diretamente do chinês tradicional, alinhada a cada parágrafo com seu índice de origem; verificação programática de cobertura e preenchimento, com revisão editorial durante a tradução.
- **Cuidados narrativos e editoriais:** Mantidos o prazo de três dias, o dia oito do nono mês, a perila, o bloqueio da alteração de mortes, os indicadores de desempenho do sistema, a pausa temporal e a goma QQ como recurso narrativo. O trecho musical é adaptado brevemente; a implicância cômica entre Ning e Xiao Qi é preservada. As descrições sobre alergia são afirmações da ficção, não aconselhamento médico.
- **Limite da validação:** o alinhamento 1:1 confirma cobertura estrutural, não fidelidade semântica absoluta. Não houve segunda auditoria linguística independente.

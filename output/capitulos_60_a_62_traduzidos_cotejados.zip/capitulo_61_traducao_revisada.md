# Capítulo 61 — Uma missão secreta foi ativada: o tirano vai bater as botas?

Como Lu Linyuan e a imperatriz-viúva conversavam lá dentro, Ning Xiaoxiao, simples criada, não tinha como entrar.

Assim, entregou a tigela de sopa de fritilária e nêspera a Sanfu e pediu que a levasse ao imperador depois que a imperatriz-viúva fosse embora.

Sanfu sorriu. — Ora, ora! Parece que você e Sua Majestade vivem pensando um no outro, hein?

Ning Xiaoxiao ficou confusa. — Como assim?

Sanfu era um servo leal e sabia interpretar os sentimentos de Lu Linyuan. Uma pessoa por quem o imperador se dispunha a passar uma noite inteira procurando uma pulseira só podia ocupar um lugar importante em seu coração.

Mas Lu Linyuan era o imperador. Não poderia simplesmente deixar de lado sua posição e confessar seus sentimentos a uma criada.

E se ele, Sanfu, desse uma ajudinha? Talvez conseguisse fazer Ning Xiaoxiao tomar a iniciativa!

Então a puxou para um canto e cochichou: — Você sabe de onde veio essa pulseira no seu braço?

Ning Xiaoxiao ergueu a manga, revelando a pulseira de jadeíta. — Esta? Sua Majestade não disse que a encontrou por aí?

Sanfu não sabia se ria ou chorava. — Encontrou por aí? Nem o tesouro imperial tem uma pulseira tão boa! Onde ele iria achar isso jogado?

— Vou contar a verdade: por sua causa, Sua Majestade mandou os artesãos trabalharem dia após dia numa pulseira, mas achou que estavam demorando demais!

— Quando soube que Yanxi era conhecida pelo comércio de pedras e joias raras, ele me arrastou pela cidade inteira na noite da visita aos túmulos imperiais. Fomos de loja em loja, perguntando e procurando!

— Só depois de passar a noite em claro conseguimos encontrar esta pulseira!

— Se não tivesse passado a noite se esforçando naquele lugar úmido e gelado, Sua Majestade nem teria pegado esse resfriado.

Depois de ouvir aquela explicação, Ning Xiaoxiao ficou paralisada, com a cabeça zumbindo e a sensação de que uma descarga elétrica lhe percorria o corpo inteiro.

— Você está dizendo que... ele procurou em um monte de lugares e comprou isto especialmente para mim?

— Claro! Então, agora você entende o que Sua Majestade sente?

Quanto a Ning Xiaoxiao... ela não tinha coragem de entender.

Estava acostumada a ser contrariada, provocada e atormentada pelo tirano todos os dias.

Era difícil se adaptar àquela súbita gentileza.

E, apesar do estranhamento, seu coração se aqueceu. Sem saber como descrever o sentimento, limitou-se a entregar a caixa de comida a Sanfu, com as bochechas vermelhas, e fugiu quase em pânico.

Vendo-a tão envergonhada, Sanfu sorriu e murmurou para si mesmo:

— Nas horas decisivas, ainda bem que podem contar comigo!

---

A imperatriz-viúva não parava de levar respostas atravessadas de Lu Linyuan. Para cada coisa que dizia, ele retrucava três. Percebendo que mãe e filho acabariam brigando de vez, ela se levantou, contrariada.

— O imperador não para de tossir. É melhor chamar um médico imperial para examiná-lo.

— Agradeço a preocupação, mãe. Estou bem.

Lu Linyuan respondeu friamente e fez um gesto indicando a saída.

A imperatriz-viúva se retirou, furiosa.

Mal ela saiu, Sanfu entrou carregando a caixa de comida, com um sorriso bajulador no rosto, para cumprimentar o imperador.

Ele sacudiu a caixa diante de Lu Linyuan. — Vida longa a Vossa Majestade! Seu servo trouxe uma coisa boa!

Lu Linyuan ergueu uma sobrancelha. — O quê?

Sanfu colocou a caixa sobre a escrivaninha imperial e abriu a tampa devagar.

Um aroma doce e delicado de sopa de fritilária e nêspera se espalhou pelo ar. Ao senti-lo, Lu Linyuan franziu discretamente a testa.

Sanfu explicou, sorridente: — Majestade, esta é uma sopa doce de fritilária e nêspera, foi...

— Tire daqui! — Lu Linyuan o repreendeu. — Você sabe que não gosto de doces. Trouxe isso justamente para me contrariar?

— Jamais ousaria! — Sanfu ficou sério e arriscou: — Mas... Majestade, foi Ning Xiaoxiao quem mandou a sopa...

Ao ouvir aquilo, Lu Linyuan sentiu algo se mover em seu peito, mas logo percebeu que havia algo estranho.

Ning Xiaoxiao era apenas uma criada e nem sequer trabalhava diretamente a seu serviço. Por que Sanfu se ofereceria para entregar alguma coisa por ela?

Será que... estava interessado nela?

Sem saber de onde vinha aquele súbito ciúme, Lu Linyuan voltou a repreendê-lo:

— Você está ficando cada vez melhor no seu serviço, hein!

— Já seria uma coisa trazer para minha presença um presente de algum senhor. Mas agora você se atreve a trazer o que uma simples criada lhe entrega? Quem foi que lhe ensinou essas regras?!

A voz dele subiu vários tons. As pernas de Sanfu fraquejaram, e ele caiu de joelhos.

— Perdoe-me, Majestade... Eu só... Eu achei que...

Mas as palavras entalaram em sua garganta.

Ele pensara que Lu Linyuan nutria certo carinho por Ning Xiaoxiao. Ela havia preparado a sopa com as próprias mãos ao saber de sua tosse; o imperador não deveria ficar feliz? Então por que o estava repreendendo?

Será que interpretara tudo errado e, tentando agradar, acabara dando um tiro no pé?

Num lampejo de inspiração, procurou uma desculpa:

— Majestade... seu servo não teve segundas intenções. Pensei apenas que a sopa de fritilária e nêspera poderia aliviar sua tosse. Foi por isso que a trouxe, eu...

— Suma daqui!

— Ah! Com todo o prazer!

Sanfu achara que não escaparia de uma surra naquele dia, mas Sua Majestade só estava mandando que fosse embora?

Ora, então precisava sair dali voando, dando uma pirueta de trezentos e sessenta graus, soltando faíscas e relâmpagos pelo caminho!

Depois que Sanfu saiu, Lu Linyuan contemplou a sopa ainda fumegante dentro da caixa. Permaneceu em silêncio por um instante e, então, pegou uma colher e mexeu o conteúdo da tigela.

Não gostava de tomar remédios nem de comer coisas excessivamente doces.

Aquela sopa conseguia reunir tudo de que ele não gostava.

Ainda assim, pegou a tigela e levou a sopa à boca, colherada por colherada.

Era muito doce. Mas a doçura não estava apenas em sua língua.

Sem que percebesse, uma parte dela também se infiltrava em seu coração.

---

De volta a seu alojamento no palácio, Ning Xiaoxiao aproveitou a tarde sem tarefas para se deitar e tentar dormir.

Mas, sempre que fechava os olhos, o rosto bonito de Lu Linyuan surgia em sua mente.

Ela se revirava na cama sem conseguir pegar no sono, pensando sem parar no que Sanfu havia lhe contado.

Ora, por favor! Ele é o imperador!

Com tantas consortes à disposição, por que se interessaria por uma criadinha como eu?

Ah, esquece! Melhor parar de inventar coisas!

Ele não passa de um personagem de papel. Mesmo que gostasse de mim, eu jamais poderia gostar dele.

É melhor terminar logo minhas missões e voltar para casa...

Foi quando a voz de Xiao Qi surgiu em sua cabeça:

【Bip, bip, bip! Parabéns, hospedeira!】

Ning Xiaoxiao: 【Eu estava pensando em você e você apareceu! Fala logo: que missão é desta vez?】

Xiao Qi: 【Você não precisa mais fazer missões! Ativou uma linha narrativa secreta, e isso fez a trama desmoronar completamente! Em três dias, você poderá voltar para casa! Vim dar os parabéns!】

Ning Xiaoxiao ficou sem entender nada. 【O quê? Desmoronou completamente?】

Xiao Qi: 【Isso mesmo! Porque o tirano está prestes a bater as botas!】

Ning Xiaoxiao: 【???】

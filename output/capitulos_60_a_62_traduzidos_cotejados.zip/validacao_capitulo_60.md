# Validação — capítulo 60

- **Fonte primária:** `novel_capitulos_1_a_60(20261103-183111).docx`.
- **Limites no DOCX:** parágrafos 4493–4562 (índices iniciados em zero).
- **Unidades não vazias do original, título incluído:** 68.
- **Linhas de dados no CSV:** 68.
- **Unidades sem correspondência, vazias ou extras:** 0.
- **Método:** tradução diretamente do chinês tradicional, alinhada a cada parágrafo com seu índice de origem; verificação programática de cobertura e preenchimento, com revisão editorial durante a tradução.
- **Cuidados narrativos e editoriais:** O humor de 'arar/semear' é metáfora sexual usada pela imperatriz-viúva para cobrar descendentes; a alusão de Sanfu a ‘brincar com a mocinha’ é preservada como insinuação. O original alterna 岩溪鎮 e 靈溪鎮 ao mencionar a cidade; adota-se Yanxi conforme a forma 岩溪 e a continuidade. O episódio da tosse termina com a entrega da sopa, sem antecipar as consequências.
- **Limite da validação:** o alinhamento 1:1 confirma cobertura estrutural, não fidelidade semântica absoluta. Não houve segunda auditoria linguística independente.

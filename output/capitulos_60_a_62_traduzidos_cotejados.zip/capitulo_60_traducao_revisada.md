# Capítulo 60 — A imperatriz-viúva veio cobrar a semeadura

Naquele dia, Lu Linyuan realmente não estava se sentindo muito bem.

Primeiro veio a tosse; depois, calafrios intermitentes e uma dor de cabeça persistente, embora discreta.

Tudo indicava que ele havia pegado um resfriado.

Yanxi era uma cidadezinha entre as montanhas, onde a temperatura variava muito entre o dia e a noite. Devia ter adoecido por lá.

Como praticava artes marciais havia muitos anos, tinha uma constituição excelente e fazia muito tempo que não ficava doente.

Ouvira os mais velhos do palácio dizerem que, quando alguém passa anos sem adoecer, a próxima doença costuma vir com mais força.

Ao vê-lo tossir sem parar, Ning Xiaoxiao, bem-intencionada, serviu-lhe um copo de água. — Majestade, que tal beber um pouco para aliviar a garganta?

— Tire isso daqui. — Lu Linyuan não apreciou o gesto nem um pouco. — E fique longe de mim. Nunca sei quando você vai tentar me atacar de novo.

Ning Xiaoxiao: “...”

【Fazer o bem para receber patada! Acha que eu queria mesmo me preocupar com você? Não quer beber? Pois fique com sede!】

— Estou cansado. Pode se retirar.

— Ah. Com licença, Majestade.

Ning Xiaoxiao saiu de lá bastante contrariada.

Mal ela cruzou a porta, Lu Linyuan teve uma violenta crise de tosse.

Ele vinha reprimindo a tosse o tempo todo, sobretudo porque temia transmitir a doença a Ning Xiaoxiao.

Como já não conseguia segurar, tratara de mandá-la embora.

Afinal, aquela criatura delicada era praticamente uma inútil. Se adoecesse, quem leria para ele aquela montanha de memoriais?

---

Ao sair da sala de estudos, Ning Xiaoxiao encontrou Sanfu enquanto ia chamar Gu Sijin para voltarem juntas ao palácio.

Assim que a viu, Sanfu abriu um sorriso de orelha a orelha. — Já terminaram?

Pensando que ele se referia à leitura dos memoriais, ela respondeu casualmente: — Sim, terminamos.

— Estranho... — Sanfu revirou os olhos, pensativo, e murmurou: — Não pode ser. Só meia hora? Normalmente, Sua Majestade leva mais tempo que isso até brincando com a própria mocinha...

— O que está resmungando, senhor Sanfu?

— Nada, nada!

— Então, se não precisa de mais nada, vou chamar a Atendente Gu e voltar.

Ning Xiaoxiao acenou em despedida, mas, quando ia partir, Sanfu a deteve: — Ei! Espere um instante!

Ele se aproximou com seus passinhos miúdos e ficou examinando longamente a pulseira de jadeíta no pulso dela.

Ora, ora! Então Lu Linyuan havia passado a noite inteira percorrendo Yanxi só para comprar aquela pulseira para ela?

O lema preferido do tirano sempre fora: “Nunca desperdiço tempo com coisas inúteis”.

E, no entanto, gastara uma noite inteira procurando aquela joia. Era fácil imaginar a importância de Ning Xiaoxiao para ele.

Nem à imperatriz nem à Consorte Nobre ele jamais dedicara tanta atenção.

De repente, Sanfu passou a olhar para Ning Xiaoxiao com um respeito inteiramente novo. — Xiaoxiao, quando subir na vida, não se esqueça deste seu humilde servo.

Até onde uma criada do palácio poderia subir na vida?

Virar chefe das criadas?

E comandar três mil empregadas numa grande operação de limpar mesas e esfregar o chão?

Ela deu a Sanfu um sorriso sem graça e, antes de ir embora, pediu: — Ouvi Sua Majestade tossindo o tempo todo hoje. Por favor, peça a um médico imperial que venha examiná-lo amanhã. Não deixem um probleminha virar uma doença séria.

Sanfu assentiu repetidas vezes. Só quando ela se afastou é que cobriu a boca para rir sozinho.

— Tosse, é? Aquilo não é tosse, é falta de ar de tanto amor!

---

Aquela “falta de ar de amor” de Lu Linyuan não melhorou no dia seguinte.

Depois da audiência matinal, Sanfu havia providenciado um médico imperial para examiná-lo. A imperatriz-viúva, porém, apareceu justamente naquela hora, e o médico precisou aguardar num salão lateral.

Ao notar a expressão abatida de Lu Linyuan, ela perguntou: — O imperador está doente?

— Só uma tosse. Nada grave.

— Mas como a Atendente Gu anda cuidando de você? Ela vem atendê-lo todas as noites e nem percebe que está doente?

Era óbvio que a imperatriz-viúva estava procurando defeitos em Gu Sijin.

Lu Linyuan estranhou.

Ele a convocava com tanta frequência precisamente porque julgara que a imperatriz-viúva a favorecia na seleção das concubinas. Assim, esperava que a mãe parasse de importuná-lo.

Que espetáculo ela pretendia encenar agora?

A imperatriz-viúva, como sempre, foi direto ao assunto: — A Atendente Gu está no palácio há quase dois meses. Já passou dezessete noites com você, recebendo sozinha todas as suas graças, e ainda assim não há sinal de gravidez. Mandei um médico examiná-la. Ele disse que a constituição dela é fria e que será necessário um tratamento cuidadoso para que possa conceber um herdeiro imperial.

Ela acariciou a proteção dourada que usava na unha do dedo mínimo e prosseguiu, falando em duas camadas de sentido: — Imperador, você passa de um extremo a outro. Antes, tinha um harém inteiro de campos sem cultivar um único. Agora, só ara o mesmo pedaço de terra sem parar. Mas esse terreno é infértil! Pode exaurir o boi que jamais colherá fruto algum. Você se dedica aos assuntos do Estado, mas a sucessão também é essencial ao reino. É preciso repartir sua chuva e seu orvalho por igual; só assim haverá prosperidade duradoura.

O que Lu Linyuan mais detestava era ver a imperatriz-viúva se intrometer em sua vida privada.

Por isso, não fez questão alguma de poupar o orgulho dela. — Como a senhora mesma disse, mãe, a sucessão diz respeito à estabilidade do Estado. Portanto, é assunto de governo. As mulheres do harém não devem interferir na política. Acaso a senhora esqueceu os preceitos dos nossos antepassados?

A imperatriz-viúva ficou lívida de raiva. — Você...! Para quem pensa que estou dizendo tudo isso? Não é para o seu bem? Agora que cresceu e virou imperador, minhas palavras já não valem nada?

---

Embora dissesse que não se importava com Lu Linyuan, Ning Xiaoxiao também passara a noite anterior sem conseguir dormir direito.

Ele era teimoso e tinha mania de evitar médicos; talvez nem obedecesse ao conselho de se deixar examinar.

Um resfriado não era grande coisa, mas, se viesse acompanhado de febre, ele poderia passar uns sete ou oito dias sofrendo.

Ela olhou para a pulseira em seu pulso.

【Mesmo que ele só tenha me dado esta pulseira porque não fazia questão dela, não posso aceitar um presente sem retribuir.】

【Ah, deixa para lá. Vou preparar para ele uma tigela de sopa doce de fritilária e nêspera. Quando eu tossia lá em casa, minha mãe sempre fazia, e até que ajudava.】

Depois de preparar a sopa e levá-la a Lu Linyuan, Ning Xiaoxiao ouviu de longe uma discussão acalorada vinda do salão principal do Palácio Chaoyang.

Com seu espírito fofoqueiro imediatamente desperto, ela puxou Sanfu para um canto e perguntou baixinho: — Com quem Sua Majestade está lá dentro?

— Com a imperatriz-viúva.

— Mas não é a hora da sesta dela? Aconteceu alguma coisa? Parece que estão discutindo.

Sanfu riu às escondidas. — Que grande coisa poderia ser? Veio cobrar a “semeadura” de sempre! Uma ou duas vezes por mês é a mesma história: manda Sua Majestade espalhar sementes pelos palácios do harém. Ele já deve estar com calos nos ouvidos de tanto escutar.

Ning Xiaoxiao: 【Hmm... Do jeito que ele fala, o imperador mais parece um... porco reprodutor?】

Então nem na Antiguidade, nem sendo imperador, um homem conseguia escapar da própria mãe cobrando casamento e filhos...

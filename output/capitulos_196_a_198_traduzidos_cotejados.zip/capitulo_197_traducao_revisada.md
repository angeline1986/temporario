# Capítulo 197 — Uma jogadora de alto nível

Um dia antes. Palácio Fengluan.

A imperatriz estava recostada junto à janela de treliça, contemplando a paisagem coberta de neve. Nas mãos, apertava um decreto imperial.

Era o decreto que a nomeara imperatriz. Naquele mesmo dia, quatro anos antes, recebera o título.

Ela sabia perfeitamente que, se sua família não tivesse se aliado à imperatriz-viúva, e se esta não tivesse desejado uma nora submissa, fácil de manipular, o posto de imperatriz jamais teria sido seu.

Mesmo assim, ao receber o decreto, ficara feliz por muito tempo.

Não porque a glória da família Zhu estivesse assegurada, mas porque finalmente se tornara esposa do homem que amava.

Antes de entrar no palácio, só encontrara Lu Linyuan três vezes. As palavras que ele lhe dirigira mal chegavam a cinco. Ainda assim, passara anos pensando nele.

O amor à primeira vista costuma começar pela atração física. E há quem confunda esse desejo com um sentimento profundo, para depois acreditar que foi traída por alguém.

Naquela manhã, ela se arrumara com todo o cuidado, esperando que Lu Linyuan viesse visitá-la, nem que fosse apenas para sentar e conversar um pouco.

Mas o meio-dia já passara e a maquiagem impecável começava a se desfazer; o homem por quem esperava não aparecera.

Apertou o decreto com tanta força que o papel ficou cheio de rugas impossíveis de alisar, tal como seu coração naquele momento.

Os pratos sobre a mesa já haviam sido reaquecidos duas vezes. Xiangling, com pena de vê-la sofrer em silêncio, tentou consolá-la:

— Majestade, disseram nos aposentos imperiais que o imperador está ocupado com assuntos de Estado. Receio que... não tenha tempo.

A imperatriz deu uma risada fria e balançou a cabeça com amargura: — Quando existe vontade, sempre se encontra tempo.

— Majestade, a senhora não come desde cedo. Se esquentarmos a comida mais uma vez, ela já não ficará boa. Coma pelo menos um pouco, para não prejudicar sua saúde.

— Pode levar e jogar fora. Estou sem apetite. — A imperatriz guardou cuidadosamente o decreto numa caixa e a colocou no lugar mais visível do aposento.

Era como se só assim pudesse lembrar aos outros — e a si mesma — a dignidade do posto que ocupava.

No dia seguinte haveria o Banquete do Lago Imperial. Todas as apresentações que as consortes planejavam fazer deveriam ser informadas à imperatriz com antecedência.

Ela pegou a relação de participantes e examinou nome por nome. Ao notar a ausência da Consorte Tong, perguntou: — E o Palácio Yaohua? Por que a Consorte Tong enviou uma folha em branco?

Xiangling respondeu: — As criadas do Palácio Yaohua nunca contam nada, e a Consorte Tong há muito se considera acima de todos. Disseram apenas que não prepararam apresentação alguma e que Vossa Majestade não precisava se preocupar...

A imperatriz talvez não recebesse amor do imperador, mas malícia e capacidade de calcular não lhe faltavam.

— O melhor talento de Tong é sua bela voz. Mas cantar simplesmente não bastaria para fazer o imperador lhe dar atenção. Aposto que pretende inventar alguma novidade.

Depois de pensar por um momento, mandou Xiangling ao Departamento de Assuntos Internos verificar se alguém requisitara os barcos do Lago Imperial. A serva foi e voltou rapidamente, trazendo uma resposta precisa:

— Vossa Majestade tem uma percepção extraordinária. O Palácio Yaohua realmente pediu um pequeno barco para amanhã.

A imperatriz compreendeu então qual era o truque que Tong pretendia aprontar.

Uma bela mulher cantando suavemente enquanto navegava pelo lago poderia atrair a atenção de Lu Linyuan. Mas o mesmo espetáculo poderia levá-la à ruína.

Por isso, a imperatriz mandou adulterar o barquinho da Consorte Tong e manteve afastados os guardas imperiais que deveriam servir no banquete. Assim que Tong entrasse no lago, seria como se já tivesse posto um pé no mundo dos mortos.

*

Naquele momento, a imperatriz soltava exclamações aflitas, parecendo mais preocupada com Tong do que qualquer outra pessoa. — Xiangling! Depressa! Isso...

Apenas a cabeça de Tong ainda aparecia acima da superfície. Justo naquela emergência, uma patrulha de guardas aquáticos que navegava pelo Lago Imperial passou perto dali.

Ao perceberem o perigo, os guardas saltaram imediatamente na água para salvá-la.

Todos estavam apreensivos com a sorte da Consorte Tong. A imperatriz não desgrudava os olhos do lago.

Seu maior desejo era que Tong se afogasse na água gelada e afundasse, para que retirassem do lago apenas um cadáver frio.

Afinal, os mortos não podiam mais se exibir diante dela.

Infelizmente para a imperatriz, Tong foi resgatada com vida. Engolira um pouco de água, sofrera um susto terrível e tremia sem parar, encharcada pelo lago congelante.

Assim que chegou à margem, as servas lhe trouxeram toalhas e se juntaram em volta dela, enxugando suas roupas e seu cabelo.

Tong começou a chorar descontroladamente. Assim que ficou um pouco mais seca, arrebatou uma toalha, colocou-a sobre os ombros e avançou na direção de Lu Linyuan entre soluços.

Mas, antes que chegasse perto dele, o imperador ergueu a mão e ordenou: — Você está completamente encharcada. Não é apropriado continuar no banquete. Volte aos seus aposentos, troque de roupa e descanse.

Tong esperava algumas palavras de consolo. Em vez disso, só viu repulsa no rosto de Lu Linyuan.

Inconformada, fez uma cena: — Majestade! Eu estava preparando esta surpresa para o senhor e acabei caindo no lago... A água estava tão fria! Fiquei apavorada, pensando que afundaria e nunca mais o veria nesta vida.

Por mais arrogante que fosse, continuava sendo uma mulher que acabara de passar por um grande susto. Misturando medo e ressentimento, começou a chorar: — Escapei da morte por um triz e o senhor ainda me trata com tanta frieza? Eu...

Lu Linyuan interrompeu-a severamente: — Só estou deixando de puni-la justamente porque caiu do barco. É proibido navegar no Lago Imperial, cantar em voz alta dentro do palácio e, com exceção da imperatriz, usar roupas vermelhas. Conte você mesma quantas regras desrespeitou.

O manto vermelho-escuro bordado com flores e pássaros que Tong usava fora encomendado por um preço altíssimo a uma bordadeira habilidosa de fora do palácio. Os desenhos pareciam vivos e os fios de ouro tornavam a peça luxuosíssima.

Ela até poderia aceitar ser repreendida pelas duas primeiras infrações. Mas como assim ninguém além da imperatriz podia vestir vermelho?

Olhou de relance para Ning Xiaoxiao. A capa de pele vermelha e vibrante que Ning trazia não chamava mais atenção do que as roupas de qualquer outra pessoa ali?

Inconformada, Tong apontou para Ning: — Majestade, o senhor diz que apenas a imperatriz pode usar vermelho. Então por que não repreende a Concubina Hua por estar de vermelho, mas me repreende?

Lu Linyuan respondeu sem precisar sequer pensar:

— Xiaoxiao é Xiaoxiao. Você é você. Como poderiam ser iguais?

Imperatriz: — ...

Consorte Tong: — ???

Demais consortes: — ￣□￣｜｜

Quando a própria Gu Sijin era humilhada, ficava quietinha, sem coragem de responder. Mas bastava alguém dizer uma palavra contra Ning Xiaoxiao para ela mostrar as garras:

— Todas as roupas de Xiaoxiao foram presentes do imperador! Se foram concedidas por Sua Majestade, é claro que ela pode vesti-las quando bem entender.

# Validação — Capítulo 198

- Fonte: `novel_capitulos_181_a_211(20261105-152737).docx`, chinês tradicional, parágrafos de índice base zero.
- Limites: do índice `1078` (inclusive) ao `1142` (exclusive); o próximo título não foi incluído.
- Unidades não vazias incluindo título: **61**.
- Primeira unidade: `1078`; última: `1140`.
- CSV: cabeçalho `indice_docx,original_chines,traducao_portugues`; **61** linhas de dados.
- Verificação estrutural: índices reais e únicos, nenhum índice ausente entre os parágrafos não vazios do capítulo, nenhum campo vazio e correspondência 1:1 entre DOCX, CSV e Markdown.
- Cuidado: a checagem 1:1 verifica alinhamento estrutural; não constitui auditoria semântica independente ou prova absoluta de ausência de omissão intraparágrafo.

## Decisões editoriais e observações

- Os versos do jogo poético foram adaptados com prioridade ao contraste cômico entre os versos e as réplicas; efeitos fonéticos chineses não são totalmente equivalentes em português.
- Ning está no cargo de Concubina Hua (華嬪), não no cargo anterior de Nobre Dama.
- A imperatriz tenta embaraçar Ning; o oferecimento de capa imperial é iniciativa de Lu Linyuan.

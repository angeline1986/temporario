# Capítulo 198 — Ning Xiaoxiao, a primeira colocada nos exames do harém

Na verdade, só com aquela língua afiada Ning Xiaoxiao já seria capaz de deixar a Consorte Tong sem resposta.

Mas, antes mesmo que pudesse abrir a boca, Lu Linyuan e Gu Sijin haviam se unido numa parceria perfeita e pego Tong completamente desprevenida. Ning se divertiu bastante por dentro.

Tong, derrotada, calou-se contrariada e, ao se virar, lançou um olhar mortal na direção de Ning Xiaoxiao.

O rosto da imperatriz também ficou alguns tons mais sombrio.

Ao repreender Tong, Lu Linyuan fora muito claro: no harém, ninguém além dela, a imperatriz, podia vestir vermelho.

Mas também dissera que Tong não podia, enquanto Ning Xiaoxiao podia — e ainda lhe presenteara especificamente com uma capa vermelha.

À primeira vista, parecia uma provocação dirigida a Tong. Na prática, era um tapa bem sonoro na cara da própria imperatriz.

Ela reprimiu a irritação e sentiu-se tão sufocada quanto se alguém estivesse apertando seu pescoço. Nada lhe parecia confortável.

Sanfu percebeu o constrangimento e tentou convencer Tong: — Consorte Tong, queira se retirar. Venta muito à beira do Lago Imperial. Não vá pegar um resfriado.

Tong estava morta de frio. As roupas ensopadas de água gelada colavam no corpo e, com o vento que soprava agora, nem a bolsa térmica nem as toalhas sobre os ombros impediam que ela se sentisse prestes a congelar.

Mas não podia ir embora. Naquele dia, pretendia conquistar uma vaga na viagem à estância de águas termais. A apresentação fora um desastre, mas, conforme o programa do banquete, ainda haveria uma competição de versos.

Lu Linyuan já dissera que ela não entendia nada de poesia e que conversar com ela era cansativo. Para fazê-lo mudar de opinião, passara muitas noites estudando à luz de velas, até os olhos doerem, só para memorizar mais alguns versos.

Depois de tanto se preparar, ir embora naquele instante seria jogar todo o esforço fora.

Por isso, retornou ao assento e disse, com os dentes batendo: — Estou bem. O Banquete do Lago Imperial ainda não chegou nem à metade. Se eu partir agora, aí sim estarei desrespeitando as regras.

Como Tong insistia em permanecer sentada, Lu Linyuan não se deu ao trabalho de discutir.

Ning Xiaoxiao, por sua vez, sabia lidar com situações delicadas. Desde que Tong mencionara sua capa vermelha, as outras consortes não paravam de lançar olhares em sua direção. Pareciam lâminas, fazendo-a sentir um calafrio nas costas.

Como sabia que o banquete seria à beira do lago, Ning já vestira várias camadas de roupa. Com a capa por cima, sentia até calor.

Então decidiu tirá-la, levantou-se e foi até Lu Linyuan, oferecendo-lhe a peça: — Majestade, não posso aceitar algo que não é apropriado à minha posição.

Depois, voltou-se para a imperatriz: — Antes eu desconhecia as regras e acabei ofendendo Vossa Majestade. Peço que não leve a mal.

A imperatriz naturalmente sorriu e respondeu que não se importava, mas Lu Linyuan ficou aflito.

Ele recebeu a capa e se ergueu para colocá-la de novo nos ombros de Ning: — Vista isto. O vento do lago é forte; pode acabar adoecendo. É um presente meu. Não precisa se preocupar com regras.

Diante de uma demonstração tão descarada de favoritismo, as outras consortes quase quebraram os dentes de tanta inveja.

Ning acabara de se livrar do suor provocado pela capa, mas Lu Linyuan já a embrulhava nela outra vez.

Ela sacudiu os ombros e inventou outra desculpa para recusar a 'gentileza': — Majestade, na verdade eu não gosto muito desta cor...

— Se não gostava da cor, deveria ter dito antes. — Lu Linyuan sorriu com carinho e tocou a ponta do nariz dela. — Ah, você... Não sei mesmo o que fazer com você.

Dito isso, tirou a capa dos ombros de Ning e a jogou de lado. Então, para espanto geral, removeu a própria capa amarela imperial, com o desenho do dragão, e colocou-a sobre ela.

As consortes estavam cansadas de pensar nas palavras 'absurdo' e 'inacreditável'... Pela primeira vez, a imperatriz e Tong trocaram um olhar de perfeito entendimento, ambas com os olhos marejados.

Até Ning Xiaoxiao ficou sem reação diante daquela ideia maluca de Lu Linyuan.

【Será que o vento do lago soprou tão forte que arrancou os miolos dele?】

Dessa vez, não ousou recusar. Temia que, num novo impulso, ele acabasse lhe dando o selo imperial para que levasse para casa e quebrasse nozes com ele...

A imperatriz achou a situação constrangedora. Para demonstrar sua dignidade e generosidade como senhora do palácio central, forçou um sorriso: — O imperador ama tanto nossa irmã mais nova, a Concubina Hua. O que haveria que não pudesse lhe dar? É a prova do carinho de Sua Majestade. Não deve recusá-la.

Assim, Ning Xiaoxiao agradeceu pela graça imperial, ainda um tanto constrangida.

Quando ela voltou ao lugar, a imperatriz anunciou: — Nos anos anteriores, sempre fizemos jogos de versos no Banquete do Lago Imperial. Algumas consortes recém-chegadas ainda não conhecem as regras. Poemas célebres atravessaram os séculos. Apenas completar seus versos originais seria sem graça. Que tal cada uma propor um verso, para que a outra crie livremente uma continuação que combine com ele?

Em seguida, olhou para Lu Linyuan: — O que Vossa Majestade acha?

Era uma atividade tradicional do banquete, e Lu Linyuan deixou que a imperatriz a organizasse.

A imperatriz lançou um olhar para Ning Xiaoxiao e sorriu: — Entre as consortes recém-chegadas, nossa irmã Hua é a de posição mais elevada. Que tal eu e a Consorte Tong propormos os primeiros versos, para você inventar os segundos?

A imperatriz estava armando uma situação embaraçosa para Ning Xiaoxiao.

Os poemas clássicos das dinastias Tang e Song que sobreviveram aos séculos eram obras-primas. Diante de versos tão brilhantes, nenhuma continuação improvisada teria como superar os originais.

E, para uma péssima aluna como Ning, até recitar os versos corretos de memória poderia ser complicado. Imagine ter de criar versos na hora!

Aquilo era praticamente uma sentença de morte...

Assim que a imperatriz apresentou a proposta, todas as consortes ficaram ansiosas para rir de Ning e começaram a incentivá-la:

— Concubina Hua, não precisa ser modesta! Já ouvimos falar de seu grande talento literário. Mostre às suas irmãs!

— Exatamente! O imperador adora conversar com a irmã Hua. Isso prova que ela é cheia de conhecimentos e sabe conquistar o coração de Sua Majestade.

A expressão 'cheia de conhecimentos' fez o próprio Lu Linyuan rir. Por acaso ele não sabia muito bem até onde iam os talentos de sua Xiaoxiao?

Ning já lhe lançava olhares desesperados, pedindo socorro. Mas ele ficou curioso para ver as respostas absurdas que aquela figurinha inventaria e declarou:

— Responda sem medo. Mesmo que não fique bom, ninguém vai rir de você.

Ning Xiaoxiao: — ...

【Ah, então querem brincar comigo? É só completar uns versos, não é? Se não consigo fazê-los bem, pelo menos posso fazê-los horrivelmente mal!】

— Então vou avisando: meu talento literário é bem limitado. Só posso prometer que os versos terão alguma correspondência, não que o resultado fará sentido.

A imperatriz, animada, respondeu: — Já será excelente se conseguir manter a correspondência. Vou começar.

— O primeiro verso é: 'No lago de águas claras, os sapos põem-se a coaxar.'

Ning Xiaoxiao: — 'E eu nem sabia que isso ia se passar.'

Imperatriz: — ...

A Consorte Li entrou logo em seguida: — 'Dois papa-figos amarelos cantam entre os salgueiros verdes.'

Ning Xiaoxiao: — 'Seu cabelo está tão oleoso que parece uma frigideira.'

Consorte Li: — ...

A Consorte Tong não quis ficar para trás: — 'A brisa da primavera torna a margem sul do rio novamente verde.'

Ning Xiaoxiao: — 'E sua cara parece uma ameixa seca e encarquilhada.'

Consorte Tong: — ...

As respostas de Ning deixaram todas as presentes completamente atônitas. Só Lu Linyuan gargalhava sem parar em seu lugar de honra, dobrando-se de tanto rir como um completo idiota.

# Validação — Capítulo 197

- Fonte: `novel_capitulos_181_a_211(20261105-152737).docx`, chinês tradicional, parágrafos de índice base zero.
- Limites: do índice `1021` (inclusive) ao `1078` (exclusive); o próximo título não foi incluído.
- Unidades não vazias incluindo título: **54**.
- Primeira unidade: `1021`; última: `1076`.
- CSV: cabeçalho `indice_docx,original_chines,traducao_portugues`; **54** linhas de dados.
- Verificação estrutural: índices reais e únicos, nenhum índice ausente entre os parágrafos não vazios do capítulo, nenhum campo vazio e correspondência 1:1 entre DOCX, CSV e Markdown.
- Cuidado: a checagem 1:1 verifica alinhamento estrutural; não constitui auditoria semântica independente ou prova absoluta de ausência de omissão intraparágrafo.

## Decisões editoriais e observações

- Capítulo inicia um dia antes do banquete; a sabotagem e o afastamento dos guardas são fatos narrados, e o suposto desespero da imperatriz é fingimento.
- Ning não ouve os pensamentos de Lu Linyuan no capítulo anterior; Lu responde diferentemente às consortes.

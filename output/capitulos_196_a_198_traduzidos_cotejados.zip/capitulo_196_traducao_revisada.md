# Capítulo 196 — Não, não, não, seu barco! O que mexe na boca é o... quê?

Ning Xiaoxiao realmente era daquelas que não temem o perigo por pura inexperiência. Mesmo depois de tantos avisos de Lu Linyuan, continuava brincando sem parar à beira do limite dele.

Só faltava Lu Linyuan prendê-la contra a mesa imperial e dizer: Mulher, foi você quem acendeu esse fogo. Agora dê um jeito de apagá-lo.

Mas a indulgência dele com Ning Xiaoxiao não parava por aí.

Bastava ela fazer um denguinho, e ele seria capaz de arrancar a lua e as estrelas do céu para lhe dar.

Além disso, o que ela dissera tinha fundamento: ele realmente não poderia acompanhá-la as vinte e quatro horas do dia.

Se a deixasse morando sozinha no Palácio Fengluan, toda vez que ela sentisse vontade de conversar com alguém teria de atravessar o palácio inteiro.

Sua Xiaoxiao era uma gatinha preguiçosa. Bastava caminhar dos aposentos até o portão do palácio para reclamar que as pernas estavam prestes a cair. Ele não suportaria vê-la fazer tanto esforço.

Por isso, acabou cedendo: — Se você realmente quer morar com Gu Sijin, não é impossível. Mas terá de me prometer uma coisa.

Ning Xiaoxiao: — O quê?

Lu Linyuan aproximou os lábios do ouvido dela e murmurou, com a voz rouca:

— Da próxima vez que eu perder o controle por desejar você, não pode me deixar inconsciente outra vez.

Ning Xiaoxiao: — ???

【Mas foi você quem bateu em si mesmo, está bem? Por que põe tudo na minha conta? Se um cachorro cagar por aí, a culpa também vai ser minha???】

— Majestade... naquela noite, juro que não fui eu que bati no senhor!

— Ah, é? — Lu Linyuan soltou uma risadinha e soprou de leve a orelha dela. — Então, naquela noite, você também estava com vontade?

Ning Xiaoxiao: — ...

Era melhor encerrar aquela conversa ali. Se continuassem, a coisa ficaria tão quente que até o Rio Amarelo transbordaria.

Felizmente, no fim Lu Linyuan concordou que Gu Sijin morasse com Ning Xiaoxiao.

Naquele mesmo dia, ao sair do Palácio Chaoyang e encontrar Gu Sijin, Ning viu que ela mantinha a expressão habitual, mas os olhos avermelhados não mentiam.

Ning Xiaoxiao segurou a mão dela, radiante: — Irmã, o imperador concordou!

Gu Sijin assentiu com um sorriso forçado. Temendo que Ning percebesse que havia algo errado, tratou de sorrir ainda mais.

— Que bom. Vamos, já está ficando tarde. É melhor arrumarmos as coisas logo.

Ela caminhou à frente de Ning Xiaoxiao, arrastando consigo uma sombra tão longa quanto sua tristeza.

Ao vê-la tão abatida, Ning sentiu um aperto no peito e reforçou silenciosamente a decisão de ajudá-la a conquistar um bom final.

Quando todos os preparativos do Palácio Fengyi ficaram prontos, logo chegou o dia do Banquete do Lago Imperial.

Para a ocasião, o Departamento de Assuntos Internos mandou pintar de vermelho os lótus brancos que o Departamento de Flores e Aves cultivara para florescer no inverno. De longe, o lago parecia coberto de flores escarlates: uma beleza impressionante na estação em que todas as outras flores haviam morrido.

A bem da verdade, o Banquete do Lago Imperial não passava de uma festividade palaciana comum, em que as consortes se reuniam para comer, beber e se divertir. Nada de extraordinário.

Mas, como a imperatriz transformara o evento numa espécie de competição para disputar vagas na viagem à estância de águas termais, todas as consortes se empenharam em exibir seus melhores talentos e chamar a atenção de Lu Linyuan.

A Consorte Li, por exemplo, era excelente dançarina e apresentou a Dança da Deusa do Rio Luo, com movimentos elegantes e graciosos. Lu Linyuan achou que ela parecia uma cobra-d'água...

A Consorte Yun, exímia tocadora de pipa, apresentou uma peça intitulada Convite ao Vinho, com notas límpidas como pérolas caindo numa bandeja de jade. Lu Linyuan não entendeu nada e só ficou com dor de cabeça...

De qualquer forma, durante todo o evento os olhos dele permaneceram grudados em Ning Xiaoxiao. Que lhe importava o espetáculo que as outras consortes resolvessem montar?

A Consorte Duan era observadora. No dia em que a imperatriz viu a lista de participantes, notara uma mudança fugaz em sua expressão. Suspeitou que qualquer esforço naquele banquete seria inútil e resolveu ficar de braços cruzados, assistindo à armadilha que a imperatriz preparava para as outras.

Gu Sijin acompanhava a agitação e cochichou com Ning Xiaoxiao: — Estranho, por que a Consorte Tong ainda não apareceu? Justamente agora, ela seria a primeira a querer roubar a cena.

Mal terminou de falar, uma voz melodiosa surgiu sobre as águas do Lago Imperial.

— Flores de mil cores desabrocham por toda parte, mas tudo se perde entre poços abandonados e muros em ruínas.

— Que fazer diante de um dia tão belo? Em que jardim se encontram os prazeres que encantam o coração?

Eram versos de O Pavilhão das Peônias, cantados no estilo da ópera Kunqu. Em todo o palácio, só a Consorte Tong sabia cantar Kunqu.

Ning já ouvira sua voz antes, mas nunca tão límpida e delicada. Pelo visto, Tong não perdera tempo durante o confinamento: ensaiara bastante.

A canção vinha do lago e atraiu imediatamente todos os olhares.

Tong trajava um vestido vermelho e navegava sozinha num barquinho, com a silhueta graciosa como uma flor de lótus emergindo das águas.

As outras consortes a odiavam e invejavam, mas até elas ficaram impressionadas com a apresentação.

Todas haviam se esforçado para atrair o olhar de Lu Linyuan. Entretanto, apenas a Consorte Tong conseguira.

Assim que a voz dela ecoou pelo lago, os olhos do imperador ficaram fixos nela.

Só que ninguém sabia o que se passava pela cabeça dele:

【Tsc... Essa mulher enlouqueceu? Ousa fazer arruaça em área proibida do palácio e ainda cantar essas músicas frívolas? Quando desembarcar, vou castigá-la severamente e acabar com esses maus costumes do harém.】

Ning Xiaoxiao, porém, não conseguia ouvir os pensamentos dele. Vendo-o encarar Tong sem parar, concluiu que era mesmo um safado fascinado por mulheres bonitas.

Ah, então você gosta de olhar, é? Está achando a música bonita, é?

Essa Consorte Tong não tem mais o que fazer no inverno e resolveu sair remando e cantando pelo lago, foi?

Pois cante! Vou deixar você cantar até não aguentar mais!

O ciúme de Ning estava prestes a transbordar. Sem hesitar, ela fechou os olhos, abriu o documento mental e reescreveu uma boa parte da trama.

Então, da garganta de Tong começou a sair um som estridente, semelhante ao de alguém esfregando um vidro. Enquanto remava com toda a força, ela cantava a plenos pulmões:

— Não, não, não, seu barco! O que mexe na boca é o... quê? Miau-li, miau-li, miau-li, miau-li! O que mexe na boca é o... quê?

Lu Linyuan: — ???

Todas as consortes: — ...

A Consorte Tong parecia possuída. Quanto mais cantava, mais depressa e entusiasmada ficava.

— Não, não, não, seu barco! O que mexe na boca é o... quê? Miau-li, miau-li, miau-li, miau-li! O que mexe na boca é o... quê? Thank you!

Ning Xiaoxiao só havia alterado a trama até esse ponto. O que aconteceu depois, porém, deixou-a boquiaberta.

Depois daquela apresentação de fazer todo mundo arregalar os olhos, Tong soltou um grito repentino. O barquinho em que estava começou a afundar visivelmente.

Parecia que um buraco surgira por algum motivo no fundo da embarcação. A água gelada do lago entrou de uma vez, e em poucos segundos mais da metade do barco havia submergido.

Alguém gritou da plataforma do banquete:

— O quê... O que aconteceu com a Consorte Tong?

— O barco está afundando!

Num instante, o pânico tomou conta de todos.

Tong estava no meio do Lago Imperial e prestes a desaparecer sob a água. Sanfu gritou: — Guardas imperiais! Entrem na água e salvem a Consorte Tong!

A imperatriz levou a mão ao peito, aparentemente aflita: — Os guardas ficaram vigiando a entrada da plataforma e não vieram conosco. Rápido, Xiangling! Vá chamar alguém!

# Validação — Capítulo 196

- Fonte: `novel_capitulos_181_a_211(20261105-152737).docx`, chinês tradicional, parágrafos de índice base zero.
- Limites: do índice `952` (inclusive) ao `1021` (exclusive); o próximo título não foi incluído.
- Unidades não vazias incluindo título: **66**.
- Primeira unidade: `952`; última: `1019`.
- CSV: cabeçalho `indice_docx,original_chines,traducao_portugues`; **66** linhas de dados.
- Verificação estrutural: índices reais e únicos, nenhum índice ausente entre os parágrafos não vazios do capítulo, nenhum campo vazio e correspondência 1:1 entre DOCX, CSV e Markdown.
- Cuidado: a checagem 1:1 verifica alinhamento estrutural; não constitui auditoria semântica independente ou prova absoluta de ausência de omissão intraparágrafo.

## Decisões editoriais e observações

- A canção nonsensical 漏漏漏油包特 / 嘴巴裏動的是居 foi adaptada foneticamente e com sentido cômico aproximado; não se afirma equivalência literal.
- Os versos do Pavilhão das Peônias receberam tradução sem reproduzir tradução publicada.
- A alteração da trama termina antes do afundamento do barco: não atribuir causalidade direta ao poder de Ning.

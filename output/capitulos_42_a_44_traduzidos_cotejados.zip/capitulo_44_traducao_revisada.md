# Capítulo 44 — Ele é só uma criança. Não tenham piedade dele!

Diante de todos os presentes, Ning Xiaoxiao venceu aquela rodada.

Mo Yesuo, que até então transbordava confiança, ficou terrivelmente constrangido.

Vendo que ele não se mexia, Ning Xiaoxiao o apressou: — O rei de Xiliang também governa um país. Um cavalheiro cumpre o que promete. Não vai querer voltar atrás, vai?

Os habitantes de Xiliang davam enorme importância à honestidade e à palavra empenhada. Preferiam perder a dignidade a dar aos outros um motivo para acusá-los de desonra.

Ignorando os protestos dos subordinados, Mo Yesuo caiu de joelhos. Inclinou o corpo para a frente, apoiou as mãos no chão e começou a engatinhar como um cachorro, rangendo os dentes.

— Rei de Xiliang, não se esqueça de latir — lembrou Ning Xiaoxiao.

Mo Yesuo ficou vermelho de raiva e soltou um latido baixinho: — Au...

Lu Linyuan já voltara ao lugar de honra. Ning Xiaoxiao perguntou: — Sua Majestade ouviu?

Lu Linyuan passou o dedo mínimo pela orelha, balançou a cabeça e soltou uma risada fria: — Não ouvi absolutamente nada.

A Consorte Nobre, sempre disposta a atiçar o espetáculo, acrescentou: — Se o rei de Xiliang vai latir, que lata alto! Ainda há pouco gritava tão forte. Por que agora ficou mudo?

Furioso, Mo Yesuo levantou a cabeça para Lu Linyuan e desatou a latir:

— Au! Au! Au! Agora ouviu?!

Lu Linyuan assentiu, satisfeito. Quando Mo Yesuo engatinhou até seu lado, apanhou um pedaço de carne com os hashis e o jogou diante dele, como quem alimenta um cachorrinho.

Mo Yesuo já havia engatinhado, latido e passado toda a vergonha possível.

Levantou-se, indignado, e exigiu passar logo à prova seguinte. Jurou a si mesmo recuperar o prestígio perdido.

— Desta vez, trouxe de Xiliang um «convidado ilustre». Ele será a próxima prova entre mim e o imperador. Quero comparar nossa coragem!

Bateu palmas três vezes. Os acompanhantes que aguardavam à porta empurraram para dentro uma enorme jaula de ferro sobre um carro de madeira.

Uma cobertura de pano preto ocultava o interior da jaula.

Todos especularam sobre o que estaria ali. Mo Yesuo se aproximou e arrancou a cobertura num puxão.

Só então viram um urso-negro gigantesco, de quase três metros de altura, olhos vermelhos e saliva escorrendo da boca.

As patas eram grossas como pilares, e as garras afiadas pareciam capazes de dilacerar qualquer ser vivo com facilidade.

A pelagem negra, longa e espessa, exalava um mau cheiro que atraía moscas e outros insetos.

Enquanto a jaula estava coberta pelo tecido, a escuridão mantivera o animal relativamente quieto.

Mas, ao perceber a multidão ao redor, o urso — fosse por nervosismo ou excitação — levantou-se, golpeou as grades com força e soltou rugidos ensurdecedores.

Gu Sijin, assustada, apertou a mão de Ning Xiaoxiao: — Nunca vi um urso tão grande... Só de olhar já dá medo.

Não era apenas Gu Sijin que via algo assim pela primeira vez. Até Lu Linyuan, que participava das caçadas de outono todos os anos, jamais vira um animal daquele porte.

Ao perceber o pavor nos rostos dos presentes, Mo Yesuo ficou ainda mais orgulhoso:

— Esse urso de Ke'er é só um filhote, nem sequer chegou à idade adulta! Em Xiliang, até ursos adultos são comuns, e nossos guerreiros conseguem dominá-los com as próprias mãos! O quê? A grandiosa Qi, com suas vastas terras e riquezas, nunca viu nem um filhote de urso como esse?

Lu Linyuan não tinha paciência para aquelas provocações veladas. — Diga logo em que consiste a prova.

— Muito bem! — respondeu Mo Yesuo. — Como estamos testando a coragem, o jeito mais simples é enfrentar o medo. O imperador deve escolher alguém para entrar na jaula e passar ali o tempo que leva para queimar um bastão de incenso. Se a pessoa sair ilesa, terá vencido.

Qi também tinha domadores de animais. Para um deles, passar aquele tempo na companhia do urso não seria algo impossível.

Lu Linyuan ia responder, mas Mo Yesuo, adivinhando sua intenção, acrescentou: — O imperador deve escolher alguém que já esteja neste salão. Se puder mandar buscar um domador, que sentido teria competir em coragem?

A imperatriz se irritou: — Você escolhe a prova e também impõe todas as regras? Se vai decidir tudo sozinho, acha que somos idiotas para cair nos seus truques?

Ao contrário dela, Lu Linyuan manteve-se perfeitamente sereno: — Rei de Xiliang, essas são mesmo as regras? Pretende fazer alguma alteração?

— Nenhuma — respondeu Mo Yesuo.

Lu Linyuan sorriu: — Então entre na jaula e participe da prova.

Mo Yesuo: ??? — Imperador, o que significa isso?

— Exatamente o que você ouviu. Não disse que eu deveria escolher qualquer pessoa presente? Ou será que se sentiu tão à vontade fazendo papel de cachorro que agora se recusa a admitir que é humano?

Ning Xiaoxiao: 【Hm... esse imperador idiota até que é esperto~】

Mo Yesuo fora enganado pela própria regra, mas não estava preocupado.

Afinal, em Xiliang, aquele urso era seu animal de estimação. Era muito apegado a ele e costumava andar livremente pelo seu palácio.

Ficar com ele por um bastão de incenso não seria problema; nem mesmo passar um dia inteiro representaria perigo.

Por isso, aceitou e propôs: — Nem precisamos complicar. Entrarei na jaula; se conseguir ficar com o urso por mais de um bastão de incenso, Xiliang vence a rodada. Caso contrário, Qi vence. O que acha, imperador?

Ao ouvir tamanha confiança, Lu Linyuan soube que Mo Yesuo tinha certeza da vitória.

Entretanto, se recusasse, temia que Ning Xiaoxiao mais uma vez se oferecesse para entrar na jaula e encarar o urso gigante.

Ela talvez tivesse sobrevivido à pedra por sorte, mas bastaria uma patada daquele animal para dilacerá-la. Ele não podia deixá-la correr outro risco.

Pensando nisso, aceitou a proposta de Mo Yesuo.

Mo Yesuo entrou na jaula, e o urso correu imediatamente até ele.

O rei acariciou a cabeça do animal e o elogiou em sua língua de Xiliang.

Ning Xiaoxiao não tinha tempo para ficar assistindo àquela demonstração de «amor de pai e filho». Queria concluir a missão o quanto antes, voltar para seu quarto e saborear seu KFC em paz.

Pausou o tempo e examinou o que viria a seguir no enredo:

Mo Yesuo deitou-se no chão. O urso gigante deitou-se ao lado dele, abraçou-o com as patas grandes e grossas e, satisfeito, adormeceu.

Após a modificação de Ning Xiaoxiao, o trecho ficou assim:

Mo Yesuo deitou-se no chão. O urso gigante deitou-se ao lado dele, abraçou-o com as patas grandes e grossas e, satisfeito, começou a lambê-lo.

Mo Yesuo estava deitado de costas quando o urso subitamente perdeu o controle. Imobilizou-o sob o próprio corpo e abriu a boca enorme.

A saliva pingou no rosto de Mo Yesuo. Antes que ele entendesse o que estava acontecendo, a língua larga e grossa do animal lhe lambeu a cara.

— Você enlouqueceu, seu bicho maldito? O que está fazendo? Ugh...

Mo Yesuo berrava, mas o urso não lhe dava a menor atenção. Como se o confundisse com um pote de mel, passou a lambê-lo freneticamente, duas vezes por segundo.

A saliva tinha um fedor tão forte que Mo Yesuo estava prestes a sufocar.

Lu Linyuan, que adorava assistir à desgraça alheia, comentou: — A que ponto chegamos! O que você anda ensinando a esse urso para ele beijar com tanta habilidade? Ele ainda é apenas um filhote! E você não é capaz de poupar nem uma criança dessas?

Mo Yesuo não tinha como prestar atenção ao que ele dizia.

Seu maior medo era que o urso descontrolado se empolgasse tanto com as lambidas que acabasse engolindo-o de uma vez.

Acertou um soco no rosto do animal e, enquanto se debatia e tentava se arrastar para a frente, gritou desesperadamente para os subordinados:

— Rápido! Rápido, tirem-me daqui!

Os guardas posicionados nas proximidades sacaram as espadas e avançaram para impedi-los. Do alto do estrado, Lu Linyuan falou com a maior tranquilidade:

— Ainda não se passou nem meio bastão de incenso. Se sair agora, terá perdido.

Mo Yesuo bateu furiosamente na porta da jaula: — Pois que eu perca! Abram logo! Tire-me daqui! Depressa!

---

## Notas editoriais

- 科爾熊 foi transliterado como urso de Ke'er; o texto o trata como espécie ou designação fictícia, sem identificação zoológica adicional.
- Uma vara/bastão de incenso funciona como unidade de tempo na prova, e a metade desse intervalo é preservada.
- O jogo verbal 熊孩子 (‘criança travessa/filhote de urso’) motiva a provocação do imperador sobre o ‘filhote’ e a ‘criança’, sem introduzir uma criança humana na cena.
- Ning transforma no texto da história o ato de dormir (睡) em lamber (舔), preservando os dois trechos lado a lado.
- A prova termina com Mo Yesuo desistindo antes de se completar o tempo exigido; não se antecipou o capítulo 45.

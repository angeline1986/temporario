# Capítulo 43 — Ning Xiaoxiao apresenta o número da pedra quebrada sobre o peito

Os habitantes de Xiliang eram todos gente rude. Numa competição dessas, levavam uma enorme vantagem.

Lu Linyuan era o soberano de um país, e sua palavra tinha o peso de mil peças de ouro. Depois de aceitar, não poderia voltar atrás.

Mo Yesuo bateu palmas três vezes. Os acompanhantes de Xiliang trouxeram duas placas de pedra azulada, cada uma com um metro de largura e altura e a espessura de um punho.

Ao vê-las, todos começaram a cochichar.

Ter uma daquelas placas sobre o corpo não seria um grande problema. Mas, se alguém a golpeasse com um martelo, ninguém sabia se a pedra se quebraria; já os órgãos da pessoa sob ela provavelmente ficariam esmagados.

Sob os murmúrios admirados, Mo Yesuo tirou o manto e exibiu o corpo coberto de músculos e carne.

— Imperador, eu começo!

Esfregando as mãos, aproximou-se de uma placa e apontou para um de seus acompanhantes: — Você, deite-se!

O rosto de Ning Xiaoxiao se encheu de pontos de interrogação. 【Você nem vai fazer a prova! Então por que tirou a roupa? Está com calor, por acaso...?】

Mas o acompanhante escolhido parecia ainda mais largo e musculoso do que o próprio rei.

Ele se deitou num banco comprido, bateu duas vezes nos próprios peitorais e mandou que colocassem a placa sobre ele.

Depois de se preparar, fez um sinal com a cabeça para o homem que segurava a marreta, autorizando-o a começar.

O homem ergueu a marreta. No instante anterior ao impacto contra a pedra, Ning Xiaoxiao apertou Pausar.

Ela examinou depressa os acontecimentos que viriam depois:

O martelo desceu com força. A placa de pedra se partiu com um estrondo e foi reduzida a pedaços. O homem que estava debaixo dela, porém, permaneceu completamente ileso.

Ning Xiaoxiao inverteu a ordem dos acontecimentos, transformando o trecho em:

O martelo desceu com força. A placa de pedra permaneceu completamente ilesa. O homem que estava debaixo dela, porém, se partiu com um estrondo e foi reduzido a pedaços.

A história voltou a correr.

Quando a marreta caiu, a placa não sofreu sequer um arranhão. Já o acompanhante que estava embaixo explodiu como se tivesse engolido uma bomba, espalhando uma nuvem de sangue.

— Aaaah!

A cena era tão sanguinolenta que as consortes perderam a cor do rosto, apavoradas.

Lu Linyuan já estava acostumado a derramamentos de sangue. Olhou para Mo Yesuo, agora boquiaberto, e bateu palmas com sarcasmo: — Que técnica impressionante de atingir o boi através da montanha! Abriu meus horizontes.

A imperatriz declarou com calma: — A prova era quebrar uma pedra sobre o peito, não despedaçar uma pessoa. Como a placa continua inteira, Xiliang perdeu esta rodada.

Mo Yesuo fingiu manter a compostura: — Qi ainda não apresentou seu participante. Como podem dizer que Xiliang perdeu? Imperador! É sua vez!

Mas onde Qi encontraria alguém com tamanha habilidade?

Nem mesmo um homem robusto de Xiliang resistira. Quem quer que deitasse debaixo da placa teria o mesmo destino: a morte.

Enquanto Lu Linyuan se via num dilema, Ning Xiaoxiao deu um salto à frente:

— Uma brincadeirinha dessas nem exige que Sua Majestade designe alguém. Uma simples criada como eu dá conta facilmente.

O salão inteiro explodiu em exclamações.

Gu Sijin se levantou às pressas e segurou seu braço: — Xiaoxiao, não faça uma loucura!

Lu Linyuan também ficou assustado com a atitude dela.

Por mais estranhos que fossem seus modos, Ning Xiaoxiao era frágil e não tinha força sequer para enfrentar uma galinha.

Uma única martelada a transformaria em carne moída!

— Ning Xiaoxiao! Quem pediu sua opinião? Retire-se!

Mo Yesuo a avaliou de cima a baixo, zombeteiro: — Você, por acaso?

Ning Xiaoxiao revirou os olhos. — Quer aumentar a aposta? Se eu ganhar, você se ajoelha e late duas vezes para o imperador. Depois dá duas voltas pelo salão engatinhando.

Mo Yesuo não se deixaria intimidar por uma moça que parecia tão indefesa. Respondeu imediatamente: — Aceito! Mas, se perder, o imperador de Qi também terá de se ajoelhar e latir duas vezes. E depois passar por baixo das minhas pernas!

*Que absurdo!*

*Quer me fazer latir como um cachorro? E passar por baixo das suas pernas?*

*Nem pensar!*

Lu Linyuan rugiu: — Eu jamais...

— Combinado! — Ning Xiaoxiao concordou antes dele, deixando Lu Linyuan atônito.

Ele se levantou, agarrou-a pelo pulso e a puxou para um canto. Perguntou em voz baixa: — Que brincadeira é essa? Está tão cansada de viver que quer morrer?

Falava com urgência, a expressão séria. Parecia genuinamente preocupado com a vida dela.

Ning Xiaoxiao não esperava tal demonstração de cuidado. Sem jeito, deu uma risadinha:

— Ora, Majestade, não se preocupe! O senhor não vive dizendo que sou uma medrosa apegada à própria vida? Eu jamais procuraria a morte! Para falar a verdade, antes de entrar no palácio eu me apresentava nas ruas. Quebrar pedras sobre o peito era um número que fazia o tempo todo. Não vai acontecer nada.

Mal terminou de falar, arrependeu-se:

【Ah... por que basta esse imperador idiota demonstrar um pouquinho de preocupação para eu perder toda a vergonha na cara?】

【Eu sei muito bem que não vou me machucar, mas preciso fingir um pouco!】

【Afinal, tenho de arrancar uns fios de cabelo dele! Meu KFC está me chamando!】

Mudou imediatamente para uma expressão triste: — Só que... sempre existe a possibilidade de um acidente. Não posso garantir que sairei ilesa. Mesmo assim, por Sua Majestade, estou disposta a tentar.

Piscou com força até os olhos ficarem vermelhos, parecendo ainda mais digna de pena: — Se algo me acontecer, se eu acabar batendo as botas por acidente, nunca mais poderei servir Vossa Majestade... Antes de morrer, tenho um pedido bem pequenininho. O senhor poderia atendê-lo?

Lu Linyuan observou em silêncio a encenação. — Diga.

— Quero arrancar alguns fios de cabelo de Vossa Majestade e enrolá-los no dedo... Assim, se eu morrer e reencarnar, poderei encontrá-lo na próxima vida e continuar a me matar de trabalhar a seu serviço!

Vejam só que discurso! Que criada dedicada!

Lu Linyuan quase ficou comovido a ponto de «chorar».

Mas, antes mesmo que ele respondesse, Ning Xiaoxiao tomou a iniciativa e arrancou-lhe uma pequena mecha com força.

O couro cabeludo dele ardeu. Ao ver os vinte ou trinta fios que ela segurava, seu rosto ficou verde de raiva.

Ainda assim, ele não queria deixá-la correr perigo.

Não admitiria que começara a se importar com a segurança dela. Convenceu-se em silêncio:

*Se ela morrer, quem vai prever o futuro para mim?*

— Já que garante que nada lhe acontecerá, explique-me o segredo do truque. Eu mesmo farei a prova!

Ning Xiaoxiao: 【Você? Uma marretada e você morre, o mundo inteiro desmorona de novo! Eu só entraria nessa se estivesse com vontade de arrumar problema para mim mesma!】

Sem dizer mais nada, soltou a mão de Lu Linyuan e se estendeu no banco. — Estou pronta! Podem começar!

Quando Lu Linyuan conseguiu alcançá-la, a placa de pedra já havia sido colocada sobre seu corpo.

— Esperem!

Ele tentou impedir a prova. Mas Mo Yesuo percebeu sua preocupação com a criada e desejou ainda mais vê-la morrer. Ordenou imediatamente: — Quebrem a pedra!

A marreta foi levantada. No instante em que ia atingir a placa, Ning Xiaoxiao apertou Pausar.

Com dificuldade, empurrou a pedra para longe do corpo. Ao cair no chão de modo desigual, ela se partiu em vários pedaços.

Ao ver isso, teve uma ideia. 【Hm... desse jeito, acho que nem preciso alterar a história, não é? Afinal, a pedra já está quebrada...】

Deitou-se novamente e dispôs um por um os fragmentos sobre o corpo.

Quando terminou, apertou Reproduzir e a história prosseguiu.

Assim que a marreta do acompanhante tocou a placa, ela se desfez em pedaços que caíram por todo o chão.

Todos ficaram de queixo caído, inclusive Lu Linyuan.

Só Ning Xiaoxiao continuou como se nada tivesse acontecido. Sentou-se de um salto no banco, apontou para Mo Yesuo e gritou:

— Engatinhe!

Lu Linyuan soltou um longo suspiro de alívio. Toda a preocupação se dissipou.

Ao vê-la provocando o adversário, não conseguiu conter um sorriso.

Mas...

Como aquela placa de pedra tinha se partido?

Lu Linyuan olhou para os fragmentos espalhados pelo chão e, em seguida, para o tamanho D no peito de Ning Xiaoxiao.

*Será que...?*

*Uma pedra daquele tamanho tinha sido despedaçada pelo impacto dos seios dela?*

---

## Notas editoriais

- A alteração decisiva do enredo troca aquilo que se quebra: a pedra permanece intacta, enquanto o homem debaixo dela se despedaça. As duas versões aparecem completas.
- Os três números da aposta secundária são dois latidos, duas voltas engatinhando e o ato de passar por baixo das pernas do adversário.
- A mecha arrancada tem aproximadamente 20 a 30 fios, e a letra D alude ao tamanho dos seios da protagonista.
- Quando Ning pausa o tempo, ela própria quebra a placa ao deixá-la cair e recoloca os pedaços sobre o peito; não foi a marretada que realmente produziu a fratura.
- O texto contém violência gráfica explícita; foi preservada sem suavização que alterasse o ocorrido.

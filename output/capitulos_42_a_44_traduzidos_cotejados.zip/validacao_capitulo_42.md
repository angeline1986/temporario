# Conferência do capítulo 42

Fonte primária: `novel_capitulos_1_a_60(20261103-131325).docx`; limites: início do capítulo 42 até antes do título do capítulo 43.

## Correspondência estrutural

- Unidades não vazias em chinês (título incluído): **69**.
- Unidades em português (título incluído): **69**.
- Correspondência ordenada: **69/69**.
- Linhas faltantes ou vazias no CSV: **0**.

## Observações terminológicas e narrativas

- 常在 é mantido como Atendente, na continuidade do capítulo 41; não equivale a imperatriz ou consorte de posto superior.
- Mo Yesuo (摩謁挲), Xiliang (西涼), dinastia Qi (啟朝), Terraço Tonghua (桐花台) e Palácio Zhongcui (鍾粹宮) foram transliterados.
- As apostas são dois anos de isenção de tributos, 30.000 shi de provisões e 20.000 cavaleiros; os 3% da missão e a penalidade de morte são explícitos.
- 肯德基 refere-se à rede KFC; o equívoco sexual do imperador explora a sonoridade de 基 (*ji*), presente no nome em chinês. A tradução inclui uma nota e sinaliza a sílaba para não inventar outro trocadilho.
- Os pensamentos de Ning são audíveis ao imperador, mas a conversa com o sistema Xiao Qi não é.

## Limites reais da revisão

O cotejo inclui todos os parágrafos, com tradução própria e revisão de acontecimentos, falas, números, negações e relações narrativas durante a elaboração. A verificação estrutural programática não comprova equivalência semântica; não houve auditoria linguística independente posterior. Tradução revisada, com revisão futura aberta para ambiguidades e fluência.

# Capítulo 42 — Espalhem a notícia: Ning Xiaoxiao quer devorar o... do tirano

A notícia de que Gu Sijin recebera o título de Atendente logo se espalhou pelos seis palácios orientais e ocidentais.

Nos últimos dois dias, o limiar do Palácio Zhongcui quase fora gasto de tanto movimento.

Consortes de todos os escalões vinham lhe oferecer presentes e cumprimentos.

Gu Sijin as recebia com um sorriso, mas, assim que fechava os portões, mandava Ning Xiaoxiao guardar tudo no depósito. Não pretendia usar sequer um presente.

Estava apavorada com a ideia de cair, por descuido, em outra armadilha de alguma concubina.

A promoção fora tão repentina que ela própria ainda não conseguia acreditar.

Todos imaginavam que Lu Linyuan a favorecia e que o título era recompensa pelas inúmeras noites que ela passara a seu serviço.

Só Gu Sijin sabia o que realmente fazia durante aquelas visitas noturnas.

Em particular, perguntou baixinho a Ning Xiaoxiao: — Xiaoxiao, por que será que Sua Majestade me chama todas as noites para fazer ginástica? Será que tem alguma segunda intenção?

— Quem sabe Sua Majestade não quer aprender com a senhora a fazer espacate? — brincou Ning Xiaoxiao.

Gu Sijin: ...

Talvez Ning Xiaoxiao fosse a única pessoa que não achava surpreendente a promoção de Gu Sijin a Atendente.

Afinal, no romance original, Gu Sijin sobreviveria a Lu Linyuan, chegaria à posição de imperatriz-viúva e acabaria controlando a corte: uma protagonista poderosa em toda a sua glória.

Mesmo que Ning Xiaoxiao desviasse a trama e impedisse o romance dos dois de avançar, a história principal ainda precisava seguir, em linhas gerais, seu caminho.

Três dias depois, Gu Sijin vestiu-se com todo o requinte e levou Ning Xiaoxiao para um banquete.

Foi só ao chegar ao Terraço Tonghua e ver o convidado de honra, já com o banquete iniciado, que Ning Xiaoxiao descobriu quem seria recebido: Mo Yesuo, o soberano de Xiliang.

Mo Yesuo usava uma barba cerrada, tinha quase dois metros de altura e era extremamente robusto. Parecia um gigante.

Vestia roupas exóticas feitas de pele de urso, e cada gesto seu exalava uma ferocidade selvagem, como a de alguém acostumado a comer carne crua e beber sangue.

— Imperador de Qi, há quanto tempo.

Falou com o peito estufado e a cabeça erguida, sem a menor intenção de se curvar. Seu tom desdenhoso deixava claro que não tinha Lu Linyuan em grande conta.

Depois de tanto sofrer com a leitura do romance original, Ning Xiaoxiao ainda se lembrava desse sujeito.

Era um adversário perigoso. Sabendo que Lu Linyuan prezava a própria reputação, trouxera três desafios para confrontar os talentos extraordinários da dinastia Qi.

Confiante de que seu reino estava repleto de pessoas capazes, Lu Linyuan não se intimidara e, provocado, aceitara a competição.

O problema era que Xiliang havia subornado o eunuco-chefe do Departamento de Assuntos Internos e descoberto em quais áreas Qi era mais fraca.

Assim, os três desafios de Xiliang atingiriam precisamente esses pontos fracos. Ninguém na corte conseguiria superá-los.

Antes de competir, os dois governantes apostariam tributos, provisões e tropas. Lu Linyuan perderia em todas as provas, causando perdas consideráveis a Qi.

Ning Xiaoxiao resmungava tudo isso em pensamento, e Lu Linyuan escutava, fascinado.

Decidiu que, assim que terminasse de lidar com Mo Yesuo, mandaria cozinhar o responsável pelo Departamento de Assuntos Internos num enorme caldeirão de cobre e serviria a carne aos cães.

Mas, justamente quando esperava ouvir os detalhes, os pensamentos de Ning Xiaoxiao tomaram outro rumo:

【Ah... estou ficando com fome. Que cheiro bom de carne!】

【Eles comem enquanto eu fico aqui olhando, sem poder provar nada! Isso é o próprio inferno na Terra!】

【Quando o banquete acabar, vou voltar ao palácio e comer alguma coisa caprichada!】

【É verdade, hoje é dia de receber o pagamento! Posso pedir à cozinha imperial um joelho de porco à Dongpo! Só que os cozinheiros daqui não chegam aos pés da minha mãe. Se ela viesse para cá, no mínimo viraria a chefe da cozinha imperial!】

【Mas aquele camarão cristal até que era bom. Na última vez que trouxeram o almoço, a pequena Gu me deu um pedacinho... Pronto, decidi! Vou comer camarão cristal e joelho de porco à Dongpo! Mas aquele prato de Buda Salta o Muro na mesa deles também parece ótimo! Quero!】

Lu Linyuan: ...

Mas quais eram os três desafios?

Fale de uma vez!

Por que você só consegue pensar em comer, comer e comer?!

Vai morrer se passar um instante sem comida?!

Irritado, quase esmagou a taça entre os dedos.

Mo Yesuo ergueu a sua taça, bebeu com ele e declarou: — A grande Qi é rica e poderosa, superior a Xiliang em tudo. É natural que Xiliang lhe preste submissão. Mas, já que vim até aqui, gostaria de testar minhas habilidades contra as do imperador de Qi. Será que Vossa Majestade tem coragem de aceitar?

Lu Linyuan fora colocado contra a parede. Qi era uma grande potência; se não ousasse responder ao desafio daquele reino considerado bárbaro, viraria motivo de chacota.

Por isso, respondeu com absoluta serenidade: — Se é esse o seu desejo, terei prazer em acompanhá-lo até o fim.

Mo Yesuo soltou uma gargalhada. — Excelente! O imperador de Qi sabe mesmo decidir sem rodeios! Mas competir por competir não tem graça. Que tal acrescentarmos algumas apostas? Tributos, grãos e tropas.

— Se Qi vencer, Xiliang pagará o dobro dos tributos, entregará trinta mil *shi* de provisões e vinte mil cavaleiros de elite.

— Se Qi perder, Xiliang ficará isenta de tributos por dois anos, e Qi nos entregará as mesmas quantidades de provisões e tropas que acabei de mencionar. O que acha, imperador?

Lu Linyuan permaneceu em silêncio. Todos pensaram que avaliava a proposta; na verdade, ouvia com toda a atenção o cardápio que Ning Xiaoxiao planejava comer...

Aquela comilona perdera o foco. Pelo visto, demoraria a prestar atenção novamente no que acontecia no salão.

Lu Linyuan não teve escolha a não ser aceitar. Se Ning Xiaoxiao fracassasse dessa vez, ao menos ele já sabia que o visitante tinha más intenções e poderia se prevenir.

— Muito bem. Aceito.

Assim que Lu Linyuan concordou com a competição, a voz de Xiao Qi ressoou na cabeça de Ning Xiaoxiao:

【Bip, bip, bip~ Anfitriã, nova missão chegando~】

【Ajude o tirano a vencer a competição contra Xiliang e garanta a vitória de Qi.】

【Recompensa pelo sucesso: o índice de desvio da trama sobe 3%. Se fracassar, sua vida chegará ao fim imediatamente~】

Ning Xiaoxiao: 【??? Desta vez vocês resolveram apostar tão alto?!】

Xiao Qi: 【O resultado desta missão está diretamente ligado ao desfecho do livro depois das alterações na trama. Use sua vantagem especial com sabedoria para ajudar o tirano a superar essa dificuldade!】

Na verdade, mesmo que Xiao Qi não tivesse aparecido, Ning Xiaoxiao já pretendia ajudar Lu Linyuan.

Mas não de graça. Ela tinha uma condição.

Queria uma pequena mecha dos cabelos do tirano para poder comprar KFC e comer frango frito...

Lu Linyuan não conseguia ouvir a conversa dela com Xiao Qi, mas, desta vez, ouviu nitidamente o que Ning Xiaoxiao murmurava para si.

*Quer uma mecha dos meus cabelos? E o «ji» de quem você pretende abocanhar?*

*Se conseguir vencer essa disputa, pode até abocanhar o meu «ji»...*

Ele baixou os olhos até a própria virilha, e seu belo rosto corou. *É... melhor não...*

*Enfim, eu lhe dou os cabelos!*

Mo Yesuo continuou: — Qi é um reino enorme, ao passo que Xiliang não passa de um território minúsculo. Sendo assim, Vossa Majestade se opõe a que eu escolha as provas?

Com Ning Xiaoxiao como sua profetisa, Lu Linyuan não tinha motivo para temer. Respondeu com um tom zombeteiro: — Como quiser.

Mas a primeira prova anunciada por Mo Yesuo já deixou todos de boca aberta:

— A primeira disputa será... quebrar uma enorme pedra sobre o peito!

---

## Notas editoriais

- 常在 é mantido como Atendente, na continuidade do capítulo 41; não equivale a imperatriz ou consorte de posto superior.
- Mo Yesuo (摩謁挲), Xiliang (西涼), dinastia Qi (啟朝), Terraço Tonghua (桐花台) e Palácio Zhongcui (鍾粹宮) foram transliterados.
- As apostas são dois anos de isenção de tributos, 30.000 shi de provisões e 20.000 cavaleiros; os 3% da missão e a penalidade de morte são explícitos.
- 肯德基 refere-se à rede KFC; o equívoco sexual do imperador explora a sonoridade de 基 (*ji*), presente no nome em chinês. A tradução inclui uma nota e sinaliza a sílaba para não inventar outro trocadilho.
- Os pensamentos de Ning são audíveis ao imperador, mas a conversa com o sistema Xiao Qi não é.

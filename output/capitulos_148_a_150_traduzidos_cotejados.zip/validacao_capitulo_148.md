# Validação — Capítulo 148

## Fonte e limites

- Fonte primária: `novel_capitulos_121_a_180(20261103-233558).docx` (chinês tradicional).
- Parágrafos: índices base zero **1891–1962**; título no índice **1891**.
- Parágrafos não vazios presentes: **69**.

## Verificação estrutural

- Linhas de cotejo: **69**.
- Parágrafos omitidos do alinhamento: **0**.
- Índices duplicados: **0**.
- Campos chineses vazios: **0**.
- Campos portugueses vazios: **0**.
- Cabeçalho: `indice_docx,original_chines,traducao_portugues`.
- Cada parágrafo não vazio, inclusive título, conserva o índice real do DOCX.

## Decisões editoriais e continuidade

A conversão de doze shichen foi mantida como 24 horas. O barbeador funciona, na hipótese do imperador, como chave do espaço; não confirmar que ele tenha acesso. 肚兜 vertido como faixa de peito (roupa íntima tradicional), não sutiã moderno. Mantida a natureza cômica do roubo acidental.

## Limitações

O alinhamento 1:1 por parágrafo e a revisão editorial durante a tradução **não constituem segunda auditoria linguística independente**. Um parágrafo presente pode, mesmo assim, conter nuances discutíveis. As falas vulgares, referências de humor e alusões sexuais foram preservadas sem suavização automática; expressões culturais receberam adaptação contextual.

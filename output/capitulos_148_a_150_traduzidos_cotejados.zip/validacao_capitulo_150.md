# Validação — Capítulo 150

## Fonte e limites

- Fonte primária: `novel_capitulos_121_a_180(20261103-233558).docx` (chinês tradicional).
- Parágrafos: índices base zero **2038–2106**; título no índice **2038**.
- Parágrafos não vazios presentes: **66**.

## Verificação estrutural

- Linhas de cotejo: **66**.
- Parágrafos omitidos do alinhamento: **0**.
- Índices duplicados: **0**.
- Campos chineses vazios: **0**.
- Campos portugueses vazios: **0**.
- Cabeçalho: `indice_docx,original_chines,traducao_portugues`.
- Cada parágrafo não vazio, inclusive título, conserva o índice real do DOCX.

## Decisões editoriais e continuidade

O enredo mantém a gravidez de Ning como aparente/falsa, embora outras personagens creiam nela. Shen planeja causar aborto e incriminar Gu Sijin; Ning não ingere o cártamo no capítulo. A alegação sobre o efeito do cártamo pertence ao universo narrativo, não a recomendação clínica. Os nomes dos quatro criados foram transliterados provisoriamente. A ameaça final é da perspectiva de Ning, não um assassinato consumado.

## Limitações

O alinhamento 1:1 por parágrafo e a revisão editorial durante a tradução **não constituem segunda auditoria linguística independente**. Um parágrafo presente pode, mesmo assim, conter nuances discutíveis. As falas vulgares, referências de humor e alusões sexuais foram preservadas sem suavização automática; expressões culturais receberam adaptação contextual.

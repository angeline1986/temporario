# Capítulo 149 — Ela está tentando me agradar?

— Vou roubar, sim! Passa para cá!

Depois de dizer isso, Lu Linyuan fugiu quase em pânico sob o olhar chocado e constrangido de Ning Xiaoxiao.

Palácio Chaoyang.

Sanfu havia procurado Lu Linyuan por todos os cantos do palácio, sem encontrar nem sombra dele. Estava à beira de um ataque de nervos.

Preparava-se para chamar os criados e organizar uma busca quando finalmente o viu voltar, furioso, com uma expressão péssima.

— Ai, Majestade! Onde esteve? Nem avisou este servo! Quase morri de susto...

Quando Lu Linyuan se aproximou e Sanfu conseguiu enxergar o objeto que ele carregava, as palavras morreram em sua garganta.

Lu Linyuan ainda estava irritado por ter ido buscar lã e voltado tosquiado. Sem a menor disposição para conversar, entrou nos aposentos e fechou a porta com um estrondo.

Sanfu, deixado do lado de fora, mergulhou em pensamentos.

Aquilo na mão dele... era uma faixa de peito?

Onde foi arranjar uma coisa dessas?

Perguntou aos guardas e eunucos pelo caminho e descobriu que o imperador havia ido naquela noite aos aposentos de Ning Xiaoxiao.

Pronto. Todas as dúvidas estavam esclarecidas.

Sanfu abriu um sorriso de quem estava completamente entregue à torcida pelo casal. Xiao Yinzi, sem entender a graça, perguntou: — Mestre, do que está rindo?

— Como você é lerdo! — Sanfu deu-lhe uma batidinha na cabeça com o espanador. — Desde que a Nobre Dama Hua engravidou, Sua Majestade não convocou mais ninguém para passar a noite com ele. Pelas contas, a gravidez já deve estar no terceiro mês. A essa altura, o bebê deve estar firme, e eles já podem voltar a fazer aquelas coisas prazerosas~

Com uma expressão maliciosa, baixou a voz de propósito. — Quando o imperador sai, não costuma levar uma multidão atrás de si? Hoje foi sozinho, às escondidas, procurar a Nobre Dama Hua. Um homem e uma mulher, sozinhos num quarto no meio da noite... O que acha que foram fazer?

Xiao Yinzi corou. — M-mas... Sua Majestade deveria ter voltado feliz, não? Eu o vi de testa franzida. Parecia até zangado.

Sanfu abafou uma risadinha e lançou um olhar de lado para os aposentos escuros. — Deve ter levado um fora da Nobre Dama Hua~ Senão, por que voltaria com a faixa de peito dela para se virar sozinho no palácio?~

O rosto de Xiao Yinzi ficou vermelho como um tomate. — Mestre... O senhor entende mesmo de muita coisa...

Sanfu piscou maliciosamente e cantarolou, arrastando as palavras: — Se quer saber a minha opinião~ Nosso imperador caiu de amores~

Os dois, mestre e aprendiz, riram no pátio. E entenderam ainda melhor quem realmente mandava no harém.

Naquele palácio profundo, posição e linhagem não eram o mais importante. O essencial era quem conseguia conquistar e conservar o coração do imperador.

E estava claro que Ning Xiaoxiao não só conquistara o coração de Lu Linyuan como também o tinha na palma da mão, podendo apertá-lo e brincar com ele quando bem entendesse.

Como não tratar com todo cuidado uma favorita dessas?

— Para nós, servos, o mais importante é perceber as vontades dos senhores — ensinou Sanfu. — Já que Sua Majestade e a Nobre Dama Hua descobriram uma «brincadeira nova», temos que ajudar a tornar tudo perfeito. É assim que se demonstra iniciativa, entendeu?

Xiao Yinzi, ainda confuso, sacudiu a cabeça com sinceridade. — Não muito...

Sanfu revirou os olhos. — Mas você é burro mesmo! Vou preparar uns presentes. Amanhã, bem cedo, leve-os à Nobre Dama Hua.

Assim, na manhã seguinte, quando Ning Xiaoxiao retornou da visita de cortesia à imperatriz, encontrou servos do Departamento de Assuntos Internos entregando objetos ao palácio.

Xiao Yinzi estava encarregado da entrega. Ela lhe perguntou: — Por que estão trazendo todos esses presentes assim, do nada?

Ele respondeu com um sorriso misterioso: — A Nobre Dama vai entender assim que vir~

Depois que ele saiu, Ning Xiaoxiao retirou o pano vermelho que cobria os presentes. Sobre a bandeja de madeira escura repousavam, pacificamente, cinco... faixas de peito de modelos diferentes?!

Ela pegou uma das peças para examinar. Descobriu que a seda trazia bordadas cenas picantes de *Jin Ping Mei* (*A Flor de Ameixeira no Vaso Dourado*).

Seu rosto se contraiu numa expressão de puro desgosto.

【Que problema esse imperador idiota tem na cabeça? Roubou uma peça minha e mandou outras cinco? Está com medo de eu ficar sem estoque para ele roubar nas próximas visitas?】

*

Lu Linyuan era obstinado. Um fracasso podia desanimá-lo por algum tempo, mas nunca o fazia desistir facilmente.

Aquele barbeador misterioso era um ótimo exemplo. Não conseguira roubá-lo na primeira tentativa? Pois tentaria uma segunda!

Dessa vez, para roubar o barbeador com sucesso, decidiu arranjar primeiro uma maneira de tirar Ning Xiaoxiao do caminho.

Desde o início do inverno, a imperatriz suspendera as apresentações teatrais para reduzir gastos e cultivar uma reputação de virtude e frugalidade.

Por isso, havia muito tempo que não se montava um palco no Jardim Changchun, especialmente reservado aos espetáculos.

Naquele dia, Lu Linyuan organizou pessoalmente uma apresentação, convidando artistas da companhia de ópera para o palácio. Como Ning Xiaoxiao adorava uma agitação, ele tinha certeza de que iria assistir.

Mas, justamente dessa vez, calculou mal.

Ning Xiaoxiao já conhecera tantas formas de entretenimento na vida moderna! Como se interessaria por ópera tradicional?

Além disso, admitia não ter qualquer refinamento artístico. Não compreendia nada daquela herança deixada pelos antepassados, e as cantorias ainda lhe pareciam barulhentas.

Só que Gu Sijin estava entusiasmada e insistiu tanto para que a acompanhasse que Ning Xiaoxiao não resistiu aos seus pedidos carinhosos e aceitou.

Ao chegar ao Jardim Changchun, bastou ouvir uma única peça para ficar entediada. Aproveitou que ninguém prestava atenção e escapuliu às escondidas.

Depois de tantos dias de neve, finalmente fazia sol. Não seria muito melhor tirar um cochilo confortável no palácio?

Enquanto ela voltava, Lu Linyuan já havia chegado ao Palácio Zhongcui antes dela e começara a revirar gavetas e armários.

Procurou primeiro por toda a cama. Sem encontrar nada, abriu as gavetas da penteadeira e examinou-as cuidadosamente.

Depois de vasculhar quase todos os lugares possíveis, finalmente abriu o guarda-roupa.

E o que surgiu diante de seus olhos foi uma fileira inteira, cuidadosamente pendurada, de... faixas de peito!

Não era a primeira vez que Lu Linyuan abria o guarda-roupa de Ning Xiaoxiao. Antes, só havia roupas comuns penduradas ali. Aquelas faixas pareciam novinhas, como se tivessem acabado de ser confeccionadas.

Pegou uma pela ponta e a virou para examiná-la. Ao ver os bordados impróprios para descrição, capazes de fazer o sangue correr mais depressa, seus lábios se curvaram num sorriso insinuante.

【Será que ela realmente acreditou que naquela noite eu fora lá só para roubar sua faixa de peito e mandou o Departamento de Assuntos Internos confeccionar todas essas peças?】

【E todas têm desenhos tão indecentes... Pelo visto, ela está inventando maneiras diferentes de me agradar!】

【Ah, mulheres...】

A ideia o deixou secretamente encantado.

BAM!

A porta se abriu. Ning Xiaoxiao entrou cantarolando uma musiquinha. Quando os olhares dos dois se cruzaram, ambos viraram estátuas mais uma vez.

Lu Linyuan não sabia se largava a faixa de peito ou a apertava ainda mais. Ning Xiaoxiao foi a primeira a se recompor e lhe ofereceu um sorriso constrangido. — Majestade... Foi o senhor quem acabou de me dar todas essas peças. Nem tive tempo de vesti-las e já veio roubá-las...

— !!!

Lu Linyuan arregalou os olhos e protestou indignado: — Que conversa é essa?! Quando foi que eu lhe dei uma coisa dessas?

— Mas não foi Sua Majestade quem mandou Sanfu trazê-las para mim?

Ao ouvir isso, Lu Linyuan lembrou que, alguns dias antes, no caminho para a audiência da manhã, Sanfu mencionara que fazia frio e seria bom mandar roupas novas a Ning Xiaoxiao. Na ocasião, ele concordara e até recomendara que enviasse algumas peças extras.

Mas que diabos!

Era dessas «roupas» que aquele sujeito estava falando?!

O que essas faixas de peito têm a ver com o frio?!

Por acaso ela vai pendurá-las por cima da capa e sair usando roupa íntima do lado de fora?!

...

Seu maldito servo!!

Eu vou matar você!!

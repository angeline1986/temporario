# Validação — Capítulo 149

## Fonte e limites

- Fonte primária: `novel_capitulos_121_a_180(20261103-233558).docx` (chinês tradicional).
- Parágrafos: índices base zero **1963–2037**; título no índice **1963**.
- Parágrafos não vazios presentes: **72**.

## Verificação estrutural

- Linhas de cotejo: **72**.
- Parágrafos omitidos do alinhamento: **0**.
- Índices duplicados: **0**.
- Campos chineses vazios: **0**.
- Campos portugueses vazios: **0**.
- Cabeçalho: `indice_docx,original_chines,traducao_portugues`.
- Cada parágrafo não vazio, inclusive título, conserva o índice real do DOCX.

## Decisões editoriais e continuidade

華貴人 padronizado como Nobre Dama Hua, conforme o novo posto atribuído à protagonista. A interpretação sexual de Sanfu e Xiao Yinzi é especulação dos eunucos, não confirmação de relação íntima. 金瓶梅 identificado como Jin Ping Mei com tradução editorial do título. A entrega das faixas foi iniciativa equivocada de Sanfu, não ordem explícita do imperador.

## Limitações

O alinhamento 1:1 por parágrafo e a revisão editorial durante a tradução **não constituem segunda auditoria linguística independente**. Um parágrafo presente pode, mesmo assim, conter nuances discutíveis. As falas vulgares, referências de humor e alusões sexuais foram preservadas sem suavização automática; expressões culturais receberam adaptação contextual.

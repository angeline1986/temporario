# Capítulo 150 — Se uma desgraçada faz maldades, basta matá-la

Aqueles dois corvos tão dedicados, sabe-se lá de onde, reapareceram e começaram a grasnar sem parar.

Antes, eu só queria levar vantagem sobre aquela mulher tola, experimentar coisas diferentes e satisfazer meu sentimento de superioridade como alguém acima de todos.

Agora decidi me corrigir, abandonar os velhos hábitos e começar uma vida nova. De hoje em diante, vou lavar minhas mãos e me tornar uma pessoa melhor:

— Nunca mais vou roubar nada!!

Bem, enquanto o constrangimento não nos matar, só resta continuar vivendo com coragem...

— Cof, cof~

Lu Linyuan limpou a garganta estrategicamente e, com a maior seriedade do mundo, começou a inventar desculpas:

— Se fui eu quem lhe deu, por que não está usando?

Apanhou de uma vez todas as faixas do armário, atirou-as nos braços de Ning Xiaoxiao e a obrigou a segurá-las.

— Comece a usar amanhã! Uma diferente por dia, sem repetir. Vou fazer inspeções surpresa!

Ning Xiaoxiao ￣□￣｜｜: — ????

【Inspecionar a sua cara! Minha vontade é enfiar todas essas faixas de peito nessa sua cabeça nada inteligente!】

Por mais que reclamasse em pensamento, diante da «tirania» do imperador precisava responder com respeito: — Sim. Esta concubina obedecerá ao decreto de Sua Majestade...

Depois de exibir sua autoridade sem motivo algum, Lu Linyuan saiu de cabeça erguida, peito estufado, feito um galinho orgulhoso marchando para a batalha.

Ninguém soube que, depois de fugir do Palácio Zhongcui, seu belo rosto ficou tão vermelho que poderia passar pelo traseiro de um macaco pendurado num galho...

Pouco depois que ele partiu, Ning Xiaoxiao arrumava o armário revirado quando teve a impressão de ouvir uma porta se abrir.

Pensou que Gu Sijin houvesse notado sua ausência e voltado para procurá-la. Mas, ao entreabrir a janela treliçada e olhar para fora, viu a Concubina Shen andando sorrateiramente.

Naquele dia, quase todo o harém tinha ido ao Jardim Changchun assistir à ópera. Para dar mais animação à ocasião, os palácios haviam levado consigo muitos criados.

O Palácio Zhongcui já contava com poucos servos. Os quatro encarregados de Ning Xiaoxiao e Gu Sijin — Qiqi, Qia Qia, Bengbeng e Lala — tinham ido juntos.

Quanto à Consorte Duan, sempre gostara de ostentar. Depois da queda da Consorte Nobre, tornara-se a concubina de maior posição abaixo apenas da imperatriz.

Adorava fazer cena diante de multidões, por isso levara todos os dezesseis servos de seu palácio para a apresentação.

Assim, naquele momento, não havia ninguém no Palácio Zhongcui além de Ning Xiaoxiao.

Não. Para ser exato, seu retorno fora um imprevisto.

Se ela não tivesse achado a ópera entediante e voltado mais cedo, o Palácio Zhongcui deveria estar completamente vazio.

A Concubina Shen escolhera justamente a hora em que não haveria ninguém. O que pretendia fazer?

Ning Xiaoxiao fechou a janela sem fazer ruído, dando a impressão de que o palácio estava deserto. Pela fresta, continuou observando cada movimento de Shen.

A visitante tinha um destino muito claro: entrou diretamente na cozinha particular.

Ning Xiaoxiao apertou sem hesitar o botão Pausar e foi à cozinha descobrir o que ela queria fazer.

Ao entrar, encontrou a Concubina Shen congelada junto ao fogão, segurando um pequeno embrulho de papel encerado.

Ning Xiaoxiao examinou o pacote e descobriu que continha uma quantidade considerável de cártamo.

Ao lado do fogão, havia ingredientes como tâmaras-vermelhas, açúcar mascavo e farinha.

Durante a apresentação de ópera, a Concubina Shen estivera sentada não muito longe de Gu Sijin e Ning Xiaoxiao.

Na ocasião, Gu Sijin dissera a Ning Xiaoxiao: — Você parece andar com vontade de comer coisas gostosas. Quando voltarmos da ópera, vou preparar uns bolinhos de tâmaras-vermelhas para você, bem recheados e com bastante açúcar mascavo. Desde que engravidou, só quer comer essas coisas bem doces e meladas~

Muito provavelmente a Concubina Shen ouvira a conversa.

Segundo a compreensão dos personagens naquele contexto, o cártamo fazia o sangue circular e dispersava estagnações; ingerido, seria especialmente perigoso para uma gravidez.

Além disso, o pó de cártamo era visualmente muito semelhante ao açúcar mascavo em pó. Misturados, seriam difíceis de distinguir.

Ning Xiaoxiao juntou as peças rapidamente.

【Essa tapada da Concubina Shen quer misturar o cártamo ao açúcar mascavo sem ninguém perceber. Quando Gu preparar os bolinhos, eu vou comê-los e sofrer um aborto espontâneo?】

No harém, nenhuma mulher era simples e inocente. Todas tinham seus próprios planos.

Mas, se fosse preciso apontar a mais burra de toda a história original, seria sem dúvida a Concubina Shen.

Era o exemplo perfeito de alguém que trocara o cérebro por um rostinho bonito: uma bela embalagem sem conteúdo.

Ter pensado numa armadilha para usar outras mãos como arma já devia ter consumido toda a inteligência que ela teria na próxima encarnação.

Ning Xiaoxiao observou a mulher congelada com interesse, deu duas batidinhas leves em seu rosto e zombou:

— E eu aqui preocupada, tentando descobrir como explicar a todos que essa gravidez logo não poderá mais ser escondida... Você apareceu por conta própria para me salvar!

— Tsc, tsc. Pelo visto, entre todas as mulheres do harém, você é a única que me ama de verdade.

Era isso mesmo. Pelas contas, sua «gravidez» já deveria estar no terceiro mês.

No inverno, as roupas eram usadas em várias camadas, com capas e mantos largos para proteger do frio. Era possível esconder a barriga.

Mas dentro dos aposentos, aquecidos por braseiros, sempre chegaria um momento em que ela tiraria as camadas externas e ficaria com roupas mais finas. Se a barriga continuasse lisa, acabariam desconfiando.

A Concubina Shen aparecera sem pensar, como alguém que, ao ver Ning Xiaoxiao com sono, gentilmente lhe oferecesse um travesseiro.

Era claro que Ning Xiaoxiao aceitaria de bom grado tanta «gentileza».

Ela reembrulhou o pó de cártamo, devolveu o pacote à palma da mão de Shen, voltou aos seus aposentos e estalou os dedos, retomando a trama.

Depois de realizar seus pequenos truques na cozinha, a Concubina Shen se esgueirou, sob os olhos de Ning Xiaoxiao, para dentro do quarto de Gu Sijin...

Ning Xiaoxiao repetiu o procedimento: pausou, seguiu a intrusa e descobriu que Shen pretendia esconder o restante do pó de cártamo num compartimento falso do guarda-roupa de Gu Sijin.

Deixou o tempo correr até que Shen terminasse e saísse apressada. Então retirou o pó escondido no armário de Gu Sijin, pausou o tempo mais uma vez e foi ao palácio da própria Concubina Shen, onde escondeu o pacote intacto no compartimento falso do guarda-roupa dela.

Ao sair, olhou para a expressão presunçosa da Concubina Shen, congelada no tempo, e murmurou:

— Já que você quer tanto provocar um aborto, só me resta ser generosa e realizar seu desejo~

Ning Xiaoxiao tinha um jeito despreocupado de viver e, em geral, mantinha a tranquilidade.

Não queria disputar poder nem se envolver em intrigas; achava aquilo entediante e sem sentido.

Mesmo tendo se tornado concubina imperial, só desejava levar uma vida preguiçosa no harém, como um peixe salgado que não faz nada.

Mas ser preguiçosa não significava estar morta e enterrada.

Se alguém ousasse conspirar contra ela ou tentar prejudicá-la em segredo, Ning devolveria todas aquelas maldades multiplicadas por dez.

A antiga Consorte Nobre, Cailian e a Atendente Xiao eram os melhores exemplos disso.

Para alguém que detestava problemas tanto quanto Ning Xiaoxiao, quando uma pessoa desprezível começava a fazer maldades, não havia motivo para gastar palavras tentando convencê-la a ser boa.

Ela preferia acabar com os conflitos da maneira mais direta e imediata possível. Por exemplo:

Se alguém insistia em agir como uma desgraçada, bastava matá-la.

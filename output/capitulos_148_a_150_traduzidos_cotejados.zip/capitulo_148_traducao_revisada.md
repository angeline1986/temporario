# Capítulo 148 — Até a minha faixa de peito você rouba? Como você é rancoroso!

Lu Linyuan não perdia a hora de vista.

Pelos pensamentos de Ning Xiaoxiao, sabia que ela só permaneceria transformada em gata por doze *shichen* — vinte e quatro horas.

Na noite anterior, ela caíra em sua banheira pouco antes da meia-noite. Portanto, deveria recuperar a forma humana naquela noite, também perto da meia-noite.

Curioso para descobrir como seria a transformação, ele percebeu que já estava quase na hora e saiu sorrateiramente, sozinho, sem sequer mandar preparar o cortejo imperial, rumo ao Palácio Zhongcui.

As visitas «discretas» de Sua Majestade a Ning Xiaoxiao já não surpreendiam os criados do palácio.

Assim, mesmo quando o viram espiar pela fresta da porta como um ladrão, ninguém ousou interromper aquele seu «passatempo refinado».

Infelizmente, chegara tarde demais.

Pela fresta, viu que Ning Xiaoxiao já havia voltado à forma humana.

Ela acariciou a barriga vazia e estalou os lábios. — Estou morrendo de fome! De fome!

Naquela hora, já não havia nada para comer no quarto. Se mandasse acender o fogão da cozinha particular no meio da noite, acabaria ouvindo sermões da Consorte Duan.

Muito melhor entrar diretamente no espaço e pegar os petiscos que seus pais haviam preparado para ela. Assim poderia comer até se fartar!

Tateando sob o travesseiro, ela retirou o barbeador, apertou-o na mão e o contemplou com olhos «gananciosos».

Lu Linyuan ficou completamente perdido.

【O que ela pretende fazer agora?】

【Eu não acabei de proibi-la de raspar os pelos? Minhas palavras entraram por um ouvido e saíram pelo outro?】

Estava prestes a empurrar a porta e repreendê-la quando um clarão azul-claro brilhou diante de seus olhos. Ning Xiaoxiao simplesmente desapareceu!

Lu Linyuan ficou boquiaberto. Mas uma surpresa ainda maior o aguardava.

Nos poucos segundos em que tentou compreender o que vira, outro clarão azul iluminou o quarto, e Ning Xiaoxiao reapareceu.

Dessa vez, além do barbeador, trazia uma caixa de frango frito e um copo de chá com leite ainda fumegante.

【Esse espaço é muito mais útil do que arrancar os cabelos do tirano! Basta entrar e pegar o que quiser comer. Nunca mais vou precisar me humilhar diante de ninguém!】

Toda satisfeita, pôs a comida na mesa e começou a devorar tudo.

Seus dentes brancos romperam a casquinha crocante do frango, liberando sucos e um aroma irresistível que encheu o aposento, escapou pela fresta e despertou imediatamente o apetite de Lu Linyuan.

Ele observou a cena e estalou os lábios sem perceber.

Que vontade de comer! Eu também quero!

Espere. Ela não acabou de dizer que tirou tudo isso de um «espaço»?

Lu Linyuan pôs sua cabecinha esperta para trabalhar e organizou os fatos.

【Ela segurou o barbeador e desapareceu de repente. Será que esse barbeador é a chave para entrar naquele «espaço» misterioso?】

【Se ela consegue entrar segurando aquilo, talvez eu também consiga!】

Ora... Uma coisa tão boa assim, eu também quero!

Mas ela certamente não vai me dar. Melhor roubá-la, então~

Cof, cof... Só vou pegar emprestado às escondidas uma vez, ver que diabos é aquilo e depois devolver!

Depois de comer e beber até ficar satisfeita, Ning Xiaoxiao, que passara o dia inteiro sendo atormentada por Lu Linyuan, sentiu o peso do cansaço. Fez uma rápida higiene e foi dormir.

Somente quando ela adormeceu profundamente é que Lu Linyuan entrou na ponta dos pés.

Antes, ele a vira tirar o barbeador debaixo do travesseiro. Mas ela dormia sobre uma almofada macia de penas de ganso; qualquer objeto escondido ali atrapalharia seu sono.

Então, provavelmente o havia guardado em outro lugar.

Se aquele «espaço» realmente continha tantas raridades, Ning Xiaoxiao jamais deixaria a chave jogada em qualquer canto. Com certeza a manteria ao alcance dos olhos para não perdê-la.

À luz fria da lua, Lu Linyuan examinou tudo ao redor da jovem adormecida.

Por fim, seu olhar parou nas roupas cuidadosamente dobradas em um quadrado perfeito aos pés da cama.

Na dinastia Qi, as pessoas costumavam pendurar no cabideiro as roupas que vestiriam no dia seguinte. Aquelas peças que Ning Xiaoxiao deixara dobradas aos pés da cama eram, portanto, bastante suspeitas.

Se não escondessem algo, para que tanto mistério e trabalho desnecessário?

Para Lu Linyuan, um objeto importante deveria ser mantido bem junto ao corpo. Concluiu, sem sombra de dúvida, que ela escondera o barbeador naquele monte de roupas.

Levantou as peças com delicadeza e as sacudiu. Em vez do barbeador, porém, foi a faixa de peito que Ning Xiaoxiao dobrara por dentro que caiu ao chão.

— ...

Lu Linyuan olhou de relance para a peça, delicadamente rosada. Pelo corte e pelas costuras, estava claro que fora ajustada para acompanhar as curvas de Ning Xiaoxiao e acomodar seu busto de tamanho D.

Pensamentos nada apropriados começaram a surgir em sua cabeça, avermelhando-lhe o rosto bonito.

De repente, percebeu que ficar estudando a roupa íntima de uma moça no meio da noite era um tanto pervertido. Abaixou-se para recolhê-la e devolvê-la ao lugar.

Mas, justo quando a segurava na palma da mão, Ning Xiaoxiao acordou. Que azar!

Ao avistar Lu Linyuan parado de costas diante da cama, ela levou um susto. — M-Majestade? O que está fazendo aqui a uma hora dessas?

Lu Linyuan apertou a faixa de peito na mão. Ao ouvir a voz dela, teve vontade de morrer ali mesmo.

Felizmente, estava de costas, e ela não via o que ele segurava.

Num movimento rápido, enfiou a faixa no cós das calças e a cobriu com o amplo traje da corte. Então respondeu com aparente tranquilidade:

— Nada demais. Passei o dia inteiro sem vê-la ontem. Achei que tivesse morrido, então vim conferir.

Ning Xiaoxiao: — ???

Lu Linyuan: — Já que ainda está viva, volte a dormir. Estou indo.

Para Ning Xiaoxiao, Lu Linyuan sempre parecera ter algum problema na cabeça. Não queria sequer tentar adivinhar por que ele entrara em seu quarto no meio da noite. Ainda assim, como concubina imperial, precisava observar as formalidades mais básicas.

Ela se levantou respeitosamente. — Então permita que esta concubina acompanhe Sua Majestade até a saída.

Lu Linyuan nada respondeu. Só queria fugir dali antes que ela notasse o desaparecimento da faixa de peito.

Mas, por dar passos largos demais, a peça escorregou do cós, entrou pela perna de sua calça e empreendeu uma longa «viagem». Justo quando ele estava prestes a cruzar a porta do quarto, deslizou suavemente pela barra e caiu no chão.

O constrangimento congelou os dois. Ning Xiaoxiao se abaixou, rígida, recolheu a peça e o encarou, incrédula.

— Você... enfiou a minha faixa de peito dentro das suas calças?

Lu Linyuan: — ...

— Majestade, ainda está ressentido porque roubei sua cueca? Veio aqui no meio da noite roubar a minha faixa de peito para se vingar?

Lu Linyuan: — ...

Já que passara vergonha até a alma, melhor ir até o fim!

No instante anterior, Lu Linyuan estava paralisado, sem saber como se explicar. De repente, endireitou-se e passou ao ataque, invertendo a culpa:

— Exatamente! Você pode roubar minhas cuecas, mas eu não posso roubar sua faixa de peito?

Estendeu a mão de supetão, arrancou a peça das mãos de Ning Xiaoxiao e declarou, com a arrogância de uma criança mimada:

— Vou roubar, sim! Passa para cá!

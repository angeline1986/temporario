Capítulo 314 — O tirano tem enjoos de gravidez em plena corte

A náusea repentina deixou Lu Linyuan um tanto perplexo.

Ele nunca havia apresentado esses sintomas antes...

Quando sua náusea diminuiu um pouco, ele olhou para trás, para Ning Xiaoxiao, e percebeu que o rosto dela havia escurecido e que ela o encarava com os olhos semicerrados.

......

Será que ela poderia pensar... que eu vomitei porque senti o cheiro do corpo dela?

Seu instinto de sobrevivência entrou em ação e ele entrou em pânico imediatamente.

Lu Linyuan tratou de explicar: — Tive ânsias porque comi demais. Não tem absolutamente nada a ver com você! Não pense bobagens! Minha Xiaoxiao é a mais cheirosa de todas!

Ning Xiaoxiao forçou um sorriso e olhou para as tigelas e os pauzinhos que ainda estavam sobre a mesa.

Há pouco, Lu Linyuan estivera tão ocupado servindo comida a ela que praticamente não tocara no próprio prato.

Você comeu menos do que uma galinha bicou o arroz, e está me dizendo que está satisfeito?

Vou te dar um sorriso; você que descubra o resto!

Ao ver o sorriso um tanto sinistro no rosto de sua esposa, Lu Linyuan não pôde evitar um arrepio.

Ele estava prestes a continuar explicando quando viu a expressão séria de Ning Xiaoxiao se desfazer repentinamente, e ela caiu na gargalhada:

Por que você está levando isso tão a sério? Você realmente acha que eu sou o tipo de pessoa que está sendo irracional?

Lu Linyuan finalmente se sentiu aliviado e deu um longo suspiro de alívio, dizendo:

— Claro que não! Como eu poderia não conhecer a mulher que amo?

"Pare de ser bobo. Mas você mal comeu alguma coisa, então por que está se sentindo enjoado de repente? Deveríamos chamar o médico imperial para dar uma olhada?"

"Não é tão frágil assim", Lu Linyuan acenou com a mão, com um sorriso travesso no rosto. "Não é nada, provavelmente só algumas sequelas de ter usado muita força em você nos últimos dias. Não é nada sério~"

Ning Xiaoxiao olhou para ele e disse: "Então, para o bem da sua saúde, acho que devemos evitar esse tipo de coisa no futuro."

"Isso não vai funcionar!" Lu Linyuan aproximou-se dela novamente e agarrou seu antebraço antes que ela pudesse fugir. "Não importa se você engasgar ou qualquer coisa do tipo, você ainda precisa comer."

Ning Xiaoxiao estendeu a mão para trás e pegou a tigela de arroz dele da mesa. No momento em que seus lábios estavam prestes a tocar os dela, ela colocou a tigela na frente de ambos. "Então você deve comer direito!"

Depois de dizer isso, ela o empurrou no peito. "Ainda preciso contar as boas notícias para Qiqi e Bengbeng. Não tenho tempo para brincadeiras com você hoje."

"E à noite?"

"Vamos falar sobre hoje à noite!"

Ning Xiaoxiao gritou com ele e, ao se virar para sair, um leve sorriso surgiu inconscientemente em seu rosto.

*

De volta ao Palácio Fengluan, Ning Xiaoxiao chamou Qiqi e Bengbeng e lhes contou a boa notícia.

Qiqi ainda estava em choque ao ouvir isso, mas Bengbeng imediatamente se emocionou e se ajoelhou diante de Ning Xiaoxiao com um baque, fazendo uma reverência.

"Este servo agradece a Vossa Majestade por atender ao meu pedido!"

Qiqi então percebeu o que estava acontecendo e também se ajoelhou.

Ning Xiaoxiao se apressou em ajudar Qiqi a se levantar e ordenou firmemente a Bengbeng que também se erguesse. — Faz tanto tempo que nos conhecemos! Desde quando precisamos de tanta cerimônia?

“Eu nunca os tratei como escravos; sempre os considerei meus amigos.”

Declarações tão vanguardistas como a igualdade para todos teriam sido consideradas pura fantasia pelos antigos.

Ao ouvir isso, Bengbeng não ousou mais se levantar. Em vez disso, baixou a cabeça profundamente, desejando poder se tornar um com os ladrilhos do chão.

"Como poderia um mero servo como eu ser digno de ser amigo de Sua Majestade a Imperatriz?"

Ning Xiaoxiao agarrou seu braço com força e o puxou do chão.

Ela ignorou a diferença entre senhor e servo e estendeu a mão para tirar o pó de suas roupas:

"Que distinção existe entre nobres e plebeus? Eu já fui como você, um servo do palácio. Alguma vez você já me viu me menosprezar?"

Qiqi e Bengbeng se entreolharam e balançaram a cabeça repetidamente.

Eles nunca tinham visto nada parecido com aquilo em Ning Xiaoxiao...

Que corajosa é a imperatriz deles!

Quando ainda era uma criada do palácio, ela ousara esbofetear uma consorte nobre. Onde estava a suposta falta de amor-próprio?

Ning Xiaoxiao também queria que Gu Sijin pudesse celebrar o casamento dos dois antes de deixar o palácio.

Por isso decidiu organizar uma cerimônia simples para Qiqi e Bengbeng no Palácio Fengyi, como presente de despedida de Gu Sijin.

Na manhã seguinte, Gu Sijin foi ao Palácio Fengluan e tomou café da manhã com Ning Xiaoxiao.

"Fiz alguns arranjos simples no palácio. Afinal, são criados do palácio, então é melhor não ser muito ostentoso, para que não deem aos outros motivo para fofocar."

"Minha irmã pode dar um jeito nisso."

Ning Xiaoxiao deu uma enorme mordida no pãozinho recheado e, falando de boca cheia, estendeu a mão para pegar outro.

Gu Sijin deu um tapinha no dorso da mão dela.

"Foram servidos seis pães cozidos no vapor hoje, e você comeu três sozinho. Não é o suficiente? Você quer um quarto?"

Ela não deixava Ning Xiaoxiao comer, então Ning Xiaoxiao começou a choramingar e a agir de forma fofa.

Quem consegue resistir ao charme sedutor de uma mulher bonita?

No fim, Gu Sijin cedeu. — Não estou proibindo você de comer, mas tantos pãezinhos logo no café da manhã não vão deixá-la empanturrada?

Ning Xiaoxiao não se sentia empanturrada de modo algum.

Ultimamente, seu apetite tem estado excepcionalmente bom. Às vezes, ela sente fome novamente pouco tempo depois de comer.

Como sempre fora gulosa, não deu importância à mudança.

*

Palácio de Chaoyang.

Quando Ning Xiaoxiao estava prestes a receber o título de Consorte Nobre Imperial, Lu Linyuan instruiu os servos do Pavilhão Fenxiang a prepararem um incenso especial para ela.

Após muitos dias de pesquisa e desenvolvimento, o Pavilhão Fenxiang selecionou dezenas de especiarias preciosas e as misturou cuidadosamente em proporções adequadas para criar um incenso exclusivo para Ning Xiaoxiao.

Nesse momento, o chefe do Pavilhão do Incenso apresentou o objeto a Lu Linyuan, que então ordenou a Sanfu que o pegasse e o abrisse.

Assim que foi aberto, um aroma refrescante se espalhou.

A fragrância se espalhou por quilômetros, rica, mas não pungente, como se a pessoa estivesse imersa em um mar de flores, e todos os funcionários da corte ficaram maravilhados com ela.

O mestre de incensos perguntou com um sorriso: "O que Vossa Majestade acha? Há algo que precise ser melhorado?"

Lu Linyuan respirou fundo e assentiu com grande satisfação:

— Acho que... uéééc!

Antes de terminar a frase, ele começou a ter fortes ânsias de vômito.

O mestre dos incensos ficou desconcertado. — O que Vossa Majestade quer dizer? Acha que há algum problema com este incenso?

Lu Linyuan deu um tapinha no peito para se acalmar, esperando que a náusea diminuísse antes de se preparar para responder.

Mas, para sua surpresa, assim que abriu a boca, não conseguiu evitar engasgar novamente...

Essa ação repentina assustou bastante Sanfu. Ninguém conseguia acreditar que Lu Linyuan pudesse ter vomitado por causa do aroma daquele incenso de primeira qualidade.

Além disso, as ânsias não haviam começado naquele dia: Sanfu já notara o mesmo sintoma na noite anterior, ao ajudá-lo a se lavar.

Considerando isso, parece mais que ele está doente.

Sanfu imediatamente disse: "Alguém! Chamem logo o médico imperial!"

(PS: Surgiu um imprevisto hoje, então esta é apenas uma atualização por enquanto. Compensarei a atualização perdida amanhã à noite, totalizando três atualizações. Amo vocês, boa noite!)

Capítulo 313 — Xiaoxiao é tão cheirosa... que me dá vontade de vomitar

Palácio de Chaoyang.

"Você está trapaceando!"

Ning Xiaoxiao contemplava o tabuleiro, onde só lhe restava a peça do general, mergulhada em profunda reflexão...

Ela nunca deveria ter aceitado jogar xadrez chinês com Lu Linyuan!

Se nem no cinco-em-linha conseguia vencer, como haveria de ganhar no xadrez chinês?

Tendo sido completamente aniquilada por Lu Linyuan, ela perdeu todo o prazer no jogo e começou a desistir.

— Por que não captura logo meu general também? Pode muito bem jogar sozinho!

Lu Linyuan lançou-lhe um olhar. — Já ficou zangada? Venha, vou facilitar. Capture à vontade qualquer peça do tabuleiro.

Sem respeitar regra alguma, Ning Xiaoxiao pegou seu general, atravessou a fronteira entre Chu e Han e foi colocá-lo bem na cara do comandante adversário.

No momento em que a peça de xadrez estava prestes a ser colocada em cima, Lu Linyuan agarrou seu pulso.

"Isso não vai funcionar."

"Por que?"

Lu Linyuan abriu um sorriso convencido. — Porque eu sou realmente bonito. — Ele brincava com a homofonia entre o nome da peça “comandante” (shuai) e “bonito” (shuài).

Ning Xiaoxiao: “...”

【Pelo amor de Deus, você é que é meloso demais!】

Após o término da partida, os criados do palácio trouxeram o almoço.

O almoço de hoje foi muito farto, com vinte e um pratos de sabores variados.

Parece que os gostos de Ning Xiaoxiao mudaram recentemente.

Ela adorava doces, até mesmo na hora de comer.

Ela nunca se interessara muito por pratos apimentados e não suportava nada azedo; parecia até alérgica a vinagre.

Naquele dia, porém, Lu Linyuan a viu avançar sem parar nas costelinhas agridoces e no peixe apimentado diante dele, e perguntou, intrigado:

"Você não disse que não gostava de comer isso? Foi preparado para mim pela cozinha imperial..."

Ning Xiaoxiao engoliu a comida que tinha na boca e bufou para Lu Linyuan.

"Qual é o problema? Não posso nem dar uma mordidinha na sua comida agora?!"

"Está tudo bem... mas olhe para os pratos nesta mesa!" Lu Linyuan apontou para cada prato à sua frente, dizendo, impotente:

— São só vinte e um pratos: dezenove são dos seus favoritos. Os únicos dois que prepararam para mim, você também tomou...

"Ah..." Ning Xiaoxiao inflou as bochechas e devolveu a fatia de peixe que já havia colocado em sua tigela para Lu Linyuan. "Aqui está!"

Lu Linyuan sorriu levemente, pegou pessoalmente uma fatia de peixe e a levou até os lábios de Ning Xiaoxiao.

"O que eu quero dizer é que você deve me dizer se quer comer, e eu mesmo lhe darei comida, para que você não precise se esforçar para se levantar e pegar a comida porque tem braços curtos."

Ning Xiaoxiao não se mostrou nada tímida. Ela deu uma risadinha maliciosa e abriu a boca para que Lu Linyuan a alimentasse.

Este gato glutão esquece todas as suas preocupações quando tem algo delicioso para comer, e pode ficar bobo e feliz por um longo tempo enquanto come.

Depois de comer metade da refeição e satisfazer o apetite, Ning se lembrou de que tinha vindo falar com Lu Linyuan sobre um assunto sério: intermediar casamentos.

Ela pousou a tigela e os pauzinhos, tomou um gole de água e limpou a garganta.

"Ah Yuan, posso falar com você sobre uma coisa?"

"Hum... Qiqi e Bengbeng sempre serviram a mim e a Sijin, e têm um ótimo relacionamento conosco."

— Os dois gostam um do outro e Sijin logo vai deixar o palácio. Pensei em lhes conceder uma graça antes disso: permitir que se tornem um casal de companheiros do palácio (*duishi*).

Lu Linyuan continuou comendo, ignorando completamente o que ela disse.

— Está com amnésia? Você agora é a imperatriz. Tem autoridade sobre o harém e pode autorizar as uniões de companheiros do palácio que quiser, sem me consultar.

“Eu sei disso, mas… há uma pessoa sobre a qual preciso pedir sua opinião primeiro.”

Ning Xiaoxiao murmurou: — Sanfu e Ahuan também se amam. Mas Sanfu é o eunuco-chefe, e não cabe a mim decidir sobre ele. Por isso queria pedir essa graça a você.

A expressão de Lu Linyuan tornou-se séria. Ele largou os pauzinhos, virou-se e lançou um olhar fulminante para Ning Xiaoxiao.

"O que você disse? Repita."

Ajuda!

Por que ele está agindo com tanta ferocidade de repente?

Ning Xiaoxiao batucava os dedos silenciosamente debaixo da mesa.

"Eu sei que isso é contra as regras, mas mesmo assim quero perguntar... ai?"

Antes que ela pudesse terminar de falar, Lu Linyuan deu um tapinha na cabeça dela com a ponta dos hashis.

"Se eu ouvir você pronunciar a palavra 'implorar' na minha frente de novo, eu..."

De repente, ele estendeu a mão e beliscou a cintura dela de forma atrevida, dizendo: "Vou te fazer chorar."

Ning Xiaoxiao: “...”

Por que o foco dele é sempre tão estranho?

"Então, o que A-Yuan quer dizer é que você concorda com isso?"

Lu Linyuan não respondeu diretamente; apenas ergueu a mão e apontou para fora da porta.

Era meio-dia e a luz do sol estava intensa.

O papel colado nas portas e janelas permite que as silhuetas do exterior se reflitam no interior.

Ning Xiaoxiao conseguia ver claramente que alguém estava com o ouvido encostado na porta, escutando os sons que vinham de dentro do salão.

Sem dúvida alguma, a única pessoa que podia ouvir conversas escondida no Palácio de Chaoyang sem ser pega era Sanfu.

Lu Linyuan ergueu a voz: — Continue bisbilhotando e farei com que passe o resto da vida solteiro!

"Oh, céus! Majestade, por favor, perdoe-me! Este servo reconhece seu erro!"

Sanfu empurrou a porta e entrou, com o rosto contorcido de tristeza enquanto se curvava e se humilhava diante de Lu Linyuan.

— Este servo não quer ficar sozinho, coaxando feito um sapo! Este servo...

Ele estava tão envergonhado que não conseguiu dizer o que ia dizer em seguida, então Lu Linyuan o repreendeu com uma expressão severa.

"Como tem desempenhado suas funções como chefe dos eunucos? Há quanto tempo não visita o Departamento da Casa Imperial?"

"Ah... esse empregado vai lá todos os dias..."

— Ainda ousa retrucar? — Lu Linyuan soltou um riso frio. — Xiao Yinzi, traga o documento!

Após dizer isso, Xiao Yinzi curvou-se e entrou na sala, carregando um pergaminho com nomes, e o entregou a Lu Linyuan.

Lu Linyuan pegou a lista e a atirou na cara de Sanfu. "Veja você mesmo!"

Sanfu abriu o registro com cautela, apenas para descobrir que, na verdade, era o arquivo de A-Huan no Departamento da Casa Imperial.

No alto do registro, estava escrito com toda a clareza: 【Marido: Sanfu.】

Ele então percebeu que, embora Lu Linyuan não tivesse dito nada, ele havia secretamente concedido seu desejo.

Transbordando de gratidão, Sanfu ajoelhou-se no chão e prostrou-se repetidamente diante de Lu Linyuan.

"Vossa Majestade, sou profundamente grato por sua misericórdia! Não tenho como retribuir a sua bondade! Se houver uma vida após a morte, estou disposto a servir a Vossa Majestade como um boi ou um cavalo!"

Lu Linyuan olhou para ele com certo desdém: "Não se atreva. Meu palácio não aceita gado nem cavalos."

— Em vez de usar a cabeça para soltar fogos de artifício diante de mim, por que não corre para contar a boa notícia à mulher que ama?

Sanfu concordou prontamente, enxugou as lágrimas e saiu correndo, feliz.

Ao sair correndo, Sanfu ainda tropeçou no batente da porta.

Lu Linyuan balançou a cabeça e o chamou novamente:

— Depois da audiência de amanhã, concedo a vocês três dias de folga. Leve sua amada para passear fora do palácio.

Ning Xiaoxiao não interrompeu sua conversa com Sanfu em nenhum momento.

Ela apoiou o queixo na mão e o observou em silêncio.

Atordoada, ela sentiu como se seu Ayuan estivesse brilhando.

A obra original o descreve como sedento de sangue, brutal e implacável. Mas o A-Yuan que conheci era claramente uma pessoa dura por fora, mas gentil por dentro, que aquecia profundamente todos ao seu redor...

Ela estava olhando fixamente quando, de repente, seu olhar encontrou o de Lu Linyuan, que se virou.

Ele ergueu uma sobrancelha.

O que você está olhando?

"Ah Yuan está bonito~"

"oh?"

Lu Linyuan aproximou-se dela, apoiando o queixo em seu ombro perfumado, com a voz baixa e rouca:

"Onde é que é bonito?"

Ning Xiaoxiao sentiu uma fileira de linhas negras surgir em sua testa. Pronto, lá vinha ele de novo!

O homem roçou delicadamente o nariz no pescoço dela, dizendo: "Minha Xiaoxiao tem um cheiro tão doce que dá vontade de comê-la."

Os dedos dos pés dela quase começaram a cavar, de tanta vergonha, um castelo mágico debaixo do chão.

Ajuda!

Ela estava prestes a empurrar Lu Linyuan para longe e dizer-lhe mais algumas palavras.

Mas antes que pudesse fazer algo, ele tomou a iniciativa de se afastar dela.

— Uéééc...

Ele se virou e começou a ter ânsias de vômito, sem aviso algum...

Ning Xiaoxiao parecia completamente perplexa:

Será que essa coisa acabou de me elogiar por cheirar bem?

Então por que raios ele estava tendo ânsias agora???

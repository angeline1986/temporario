# Validação do capítulo 314

- **Original:** `novel_capitulos_301_a_360(20261107-181903).docx` (chinês).
- **Tradução-base:** `novel capitulos 301 a 360 - ch.epub` (`index_split_013.html`).
- **Índices absolutos do DOCX:** 1079–1156 (base zero; parágrafos vazios preservados como lacunas).
- **Unidades textuais não vazias:** 76 no original e 76 no cotejo, incluindo título, marcações e notas.
- **Unidades com intervenção textual:** 18 (inclui normalizações superficiais).

## Decisões e problemas detectados

O título se refere aos enjoos de gravidez do imperador durante a audiência, e não a tontura. Corrigidos agentes de ações, confusão entre os palácios Fengluan e Fengyi e a representação das ânsias (yue).

## Método e limites

Comparação estrutural de todas as unidades na ordem do DOCX, com correção semântica dirigida de passagens identificadas como problemáticas e normalizações pontuais. Os demais trechos preservam substancialmente a tradução-base do EPUB. **Não foi realizada auditoria semântica independente e exaustiva frase a frase de cada unidade mantida**; podem subsistir erros sutis, omissões internas ou construções pouco naturais. A correspondência estrutural não equivale a certificação integral da qualidade.

# Validação do capítulo 315

- **Original:** `novel_capitulos_301_a_360(20261107-181903).docx` (chinês).
- **Tradução-base:** `novel capitulos 301 a 360 - ch.epub` (`index_split_014.html`).
- **Índices absolutos do DOCX:** 1158–1241 (base zero; parágrafos vazios preservados como lacunas).
- **Unidades textuais não vazias:** 82 no original e 82 no cotejo, incluindo título, marcações e notas.
- **Unidades com intervenção textual:** 22 (inclui normalizações superficiais).

## Decisões e problemas detectados

O pulso de gravidez é atribuído ao imperador em uma situação cômica, sem significar que ele esteja biologicamente grávido. Corrigidos médicos Zhao/Sun, salto usando ombro de Bengbeng e sujeito de falas; confirmação real da gravidez é de Ning Xiaoxiao no desfecho.

## Método e limites

Comparação estrutural de todas as unidades na ordem do DOCX, com correção semântica dirigida de passagens identificadas como problemáticas e normalizações pontuais. Os demais trechos preservam substancialmente a tradução-base do EPUB. **Não foi realizada auditoria semântica independente e exaustiva frase a frase de cada unidade mantida**; podem subsistir erros sutis, omissões internas ou construções pouco naturais. A correspondência estrutural não equivale a certificação integral da qualidade.

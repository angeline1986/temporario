# Validação do capítulo 313

- **Original:** `novel_capitulos_301_a_360(20261107-181903).docx` (chinês).
- **Tradução-base:** `novel capitulos 301 a 360 - ch.epub` (`index_split_012.html`).
- **Índices absolutos do DOCX:** 975–1077 (base zero; parágrafos vazios preservados como lacunas).
- **Unidades textuais não vazias:** 101 no original e 101 no cotejo, incluindo título, marcações e notas.
- **Unidades com intervenção textual:** 30 (inclui normalizações superficiais).

## Decisões e problemas detectados

Xadrez chinês: general/comandante e trocadilho 帥 (comandante/bonito); 對食 é uma união entre servidores do palácio, não uma refeição; corrigidas trocas de sujeito, voz narrativa e pensamentos 【】.

## Método e limites

Comparação estrutural de todas as unidades na ordem do DOCX, com correção semântica dirigida de passagens identificadas como problemáticas e normalizações pontuais. Os demais trechos preservam substancialmente a tradução-base do EPUB. **Não foi realizada auditoria semântica independente e exaustiva frase a frase de cada unidade mantida**; podem subsistir erros sutis, omissões internas ou construções pouco naturais. A correspondência estrutural não equivale a certificação integral da qualidade.

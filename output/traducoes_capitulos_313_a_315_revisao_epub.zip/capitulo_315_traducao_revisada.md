Capítulo 315 — Xiaoxiao está grávida!

Durante as audiências matinais, médicos imperiais ficavam de prontidão no salão anexo ao Salão do Trono Dourado.

Assim, caso surgisse alguma emergência durante a audiência, poderiam prestar socorro imediatamente.

Portanto, assim que Sanfu chamou, o médico imperial chegou rapidamente.

Lu Linyuan vomitou por um tempo antes de seu estado finalmente se estabilizar, mas quando olhou para cima e viu de quem era o médico imperial, ficou estupefato...

As pessoas abaixo dele que lhe prestaram suas homenagens foram o Médico Zhao e o Médico Sun.

Eram justamente os dois infelizes que haviam diagnosticado um pulso de gravidez no imperador e, por isso, tinham sido mandados alimentar cavalos nos estábulos imperiais!

Hoje foi o primeiro dia de volta ao trabalho deles e, inesperadamente, o tirano vomitou no tribunal, obrigando-os a verificar seu pulso...

Os dois homens avançaram cautelosamente e verificaram cuidadosamente o pulso de Lu Linyuan.

Mas esse pulso... é simplesmente absurdo!

Após verificar o pulso, o médico Zhao tornou-se mais sábio e não disse nada explicitamente:

"Vossa Majestade, meu conhecimento é limitado e não posso diagnosticar nada de anormal no momento. Talvez eu devesse pedir ao Dr. Sun que o examinasse?"

Lu Linyuan assentiu em silêncio, e o Médico Sun assumiu o lugar do Médico Zhao e começou a examinar o pulso de Lu Linyuan.

Assim que pousou os dedos no pulso de Lu Linyuan, o médico Sun percebeu: aquele era, mais uma vez, um pulso de gravidez!

O médico Sun olhou para Lu Linyuan com uma expressão preocupada, perguntando-se se o imperador estaria com alguma doença grave.

Será que o imperador não tinha mais nada para fazer além de ficar “engravidando” por diversão?

O olhar penetrante de Lu Linyuan encontrou o dele. "Fale o que pensa, não hesite!"

Surpreendido por suas palavras, o Dr. Sun ficou sem palavras e deixou escapar:

— Ma-Majestade! Seu pulso é de gravi... aaah!

Antes que ele pudesse terminar de falar, Lu Linyuan o chutou para longe.

De pé ao lado, o Médico Zhao franziu a testa e olhou para o Médico Sun, que havia sido chutado e caía no chão. Ele estava completamente sem palavras.

Se você tivesse um mínimo de inteligência, não teria feito uma coisa tão estúpida!

Antes mesmo que pudesse se congratular por ter escapado ileso fingindo ignorância, ouviu Lu Linyuan repreendê-lo furiosamente:

"Mandem esses dois para os estábulos imperiais para alimentar os cavalos!"

— E vão alimentá-los por dez anos!

Sanfu acenou com seu batedor de arame, e imediatamente os guardas se aproximaram para levar os dois embora.

"Majestade, poupe minha vida! Este humilde súdito deixou os estábulos imperiais apenas ontem..."

Os ministros não entendiam em que os dois médicos haviam ofendido Lu Linyuan para sofrer tamanho castigo.

Enquanto expressavam compaixão pela situação dos dois homens, ouviram repentinamente a risada de Lu Linyuan vinda do trono do dragão.

E não era sua risada fria de sempre, mas sim uma risada incontrolável e extasiante que irrompeu em um grito alto.

Os ministros: "???"

Majestade, por favor, pare de rir, estamos com medo...

*

Palácio Fengyi.

"Majestade, por favor, desça! Isto é inaceitável!"

"Xiaoxiao! Pare de brincar! É perigoso!"

Gu Sijin, Qiqi, Qiaqia, Bengbeng e Lala estavam reunidos sob a grande árvore no pátio do Palácio Fengyi, gritando para os galhos lá em cima.

Ning Xiaoxiao abraçou o tronco da árvore e escalou até o topo do galho.

Ela segurava um nó da sorte na mão e sorriu enquanto o acenava para a multidão abaixo:

"Quanto mais alto este nó auspicioso for pendurado, mais sorte ele trará. Não se preocupe comigo, eu não vou cair!"

Ela tinha o costume de subir em árvores no quintal de casa quando era criança, então essa altura não era nada para ela.

Enquanto se divertia subindo e descendo, Lu Linyuan chegou ao Palácio Fengyi.

Mal entrou, viu sua esposa balançando no alto da árvore como um macaquinho — não num balanço de verdade.

Ele estava tão assustado que suas palmas suavam. Não ousou gritar, com medo de que ela se assustasse e caísse da árvore.

Usando sua técnica de leveza, Lu Linyuan tomou impulso sobre o ombro de Bengbeng, saltou até o galho, segurou Ning pela cintura e desceu com ela, como se voasse.

O gesto suave e sem esforço com que ele abriu a tampa do caixão de Newton deixou todos atônitos.

Ning Xiaoxiao, que estava aninhada em seus braços naquele momento, ficou especialmente surpresa e sem palavras.

"Então, A-Yuan, assim como o General Ren, também pode decolar do local?"

"Mas por que eu nunca te vi voar antes?"

A irritação de Lu Linyuan desapareceu assim que ouviu a pergunta ingênua, feita com tanta admiração pela esposa.

"Eu sou o imperador! Deixem que meus subordinados cuidem dos voos!"

"Eu não sou um pássaro, por que eu ficaria voando por aí o dia todo?"

Ning Xiaoxiao previu que Lu Linyuan a repreenderia, então atacou preventivamente, com palavras doces como mel:

Uau! Ah Yuan é incrível!

Depois disso, Ning Xiaoxiao ainda convocou todos a aplaudirem Lu Linyuan.

Infelizmente, essa tática se mostrou completamente ineficaz.

Lu Linyuan passou o braço pelo ombro dela, puxou-a com força para um abraço e disse severamente:

"Você não tem permissão para fazer essas coisas perigosas novamente, e definitivamente não tem permissão para subir tão alto! Você é uma macaca? Subindo em árvores para construir um ninho?"

Gu Sijin interrompeu: "Exatamente! E se você caísse de uma altura dessas? Me daria um susto enorme..."

Ning Xiaoxiao sentiu que estavam fazendo tempestade em copo d'água.

Afinal, ela foi criada em casa com total liberdade desde criança. Quando tinha quatro anos, seu pai, que não era confiável, a levou pessoalmente para subir em uma árvore.

Ela é sagitariana, ama a liberdade e detesta ser controlada e restringida em tudo o que faz.

Então ela se desvencilhou dos braços de Lu Linyuan e disse casualmente:

"Ah, estou realmente bem, estou leve como uma pluma, então não se preocupe comigo!"

Vendo que a expressão de Lu Linyuan ainda não era boa, e temendo que ele continuasse a criticá-la, ela rapidamente mudou de assunto:

— Já que Vossa Majestade chegou, vamos almoçar juntos? Estou morrendo de fome...

Depois, ela deu dois tapinhas bem fortes na própria barriga, produzindo dois estalos audíveis.

Lu Linyuan ficou apavorado novamente e agarrou seu pulso, dizendo, infeliz:

Por que você se bateria sem motivo?

Ning Xiaoxiao olhou para ele sem expressão, depois estendeu a mão e usou o dorso da mão para sentir a temperatura da testa dele:

"Você está bem? Por que você se assusta tão facilmente hoje?"

Hum... como você pode dizer que não é nada?

Ele tinha, sim, uma novidade — e era uma alegria enorme!

Enquanto conversavam, o diretor Song também chegou ao Palácio Fengyi.

Lu Linyuan contou secretamente a Ning Xiaoxiao e Gu Sijin que o Médico Imperial Song tinha vindo examinar o pulso de Gu Sijin, preparando-a para fingir a própria morte e deixar o palácio em alguns dias.

De volta aos seus aposentos, o Médico Imperial Song examinou o pulso de Gu Sijin e disse que estava tudo bem.

Lu Linyuan então disse: "Já que você está aqui, pode aproveitar para dar uma olhada na Imperatriz também. Desde que ela tomou o remédio caseiro do Hospital Imperial no mês passado, sua menstruação está atrasada há alguns dias este mês. Dê uma olhada e veja o que está acontecendo."

De fato, o ciclo menstrual de Ning Xiaoxiao já estava atrasado havia mais de quinze dias.

Ning Xiaoxiao não disse nada e, obedientemente, estendeu a mão para que o Dr. Song verificasse seu pulso.

Mal o diretor Song encostou os dedos no pulso de Ning Xiaoxiao, seus olhos brilharam. Ele retirou a mão, ajoelhou-se diante de Lu Linyuan e anunciou, radiante:

"Parabéns, Vossa Majestade! Parabéns, Vossa Majestade a Imperatriz!"

— Majestade... é um pulso de gravidez!

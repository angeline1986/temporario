# Validação — capítulo 147

- **Fonte primária:** `novel_capitulos_121_a_180(20261103-233558).docx`, chinês tradicional.
- **Limites do capítulo no DOCX:** parágrafos 1841–1890 (índices de base zero).
- **Unidades de texto não vazias (incluindo título):** 47.
- **Linhas de cotejo:** 47.
- **Índices ausentes:** 0; **índices duplicados:** 0; **traduções vazias:** 0.
- **Critério de cotejo:** uma linha por parágrafo não vazio do original, preservando o índice real e a sequência original.
- **Limitações:** cotejo 1:1 e revisão editorial durante a tradução, sem segunda auditoria independente integral. A validação automatizada não certifica perfeição semântica nem ausência de omissões internas a cada parágrafo.

## Observações editoriais e de continuidade

- Imperatriz, Concubina Shen, Nobre Dama Gu e Nobre Dama Hua são pessoas/cargos diferentes e não foram fundidos.
- O relatório de corrupção sobre o pai de Shen é apresentado pela imperatriz; a narrativa posterior demonstra manipulação, sem comprovar de forma independente a acusação inicial.
- A bofetada em Xiangling e a ordem de vinte golpes são uma encenação: depois se revela que ela não compareceu ao departamento de punição.
- A imperatriz interceptou a carta enviada pelo pai de Shen e a queimou, o que sustenta o caráter manipulador do encontro.
- A ameaça ao herdeiro imperial é plano/intriga das personagens; não é notícia de um dano já ocorrido.

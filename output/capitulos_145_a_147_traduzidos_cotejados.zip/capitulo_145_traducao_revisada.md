# Capítulo 145 — Eu gosto muito de Xiaoxiao

Entrar debaixo das cobertas? Nem pensar!

Por quem ele me toma?

Sou uma gata de respeito!

Ning Xiaoxiao afiava as garras na beirada da cama, toda constrangida, recusando-se terminantemente a entrar debaixo do edredom.

Lu Linyuan levantou uma ponta da coberta e lhe deu um ultimato: — Ou aquece minha cama, ou come ratos. Escolha.

Assim que ouviu aquilo, Ning Xiaoxiao, que um instante antes ainda mantinha a cabecinha felina erguida com altivez, reagiu como se lhe tivessem pisado no rabo. Com um miado, mergulhou de imediato na cama de Lu Linyuan.

O olfato dos gatos era muitas vezes mais apurado que o dos humanos.

Mal se enfiou debaixo das cobertas, uma fragrância intensa e amadeirada veio de todas as direções, inundando-lhe o nariz.

Era o cheiro característico de Lu Linyuan: âmbar-gris, notas frescas de madeira e o aroma natural de sua pele, misturados numa combinação extraordinária.

Como erva-dos-gatos, era viciante.

Enquanto se perdia naquela fragrância, sentiu de repente a cama imperial estremecer. Quando se deu conta, Lu Linyuan já havia levantado a coberta e se deitado.

Ele a puxou para fora das profundezas do edredom, deixando a maior parte de seu corpinho coberta e só a cabecinha à mostra. Acomodou-a sobre o próprio travesseiro, ficando cara a cara com ela.

Se aquele rosto do tirano aparecesse no mundo moderno, seu dono poderia dançar sem coordenação e cantar completamente desafinado; ainda assim, tamanha era sua beleza que conseguiria estrear como artista solo só com a aparência.

Por mais que Ning Xiaoxiao olhasse para ele, continuava impressionada. E suspirava intimamente: personagens de ficção são mesmo irresistíveis!

Agora que era uma gata, podia ficar com o rosto colado ao do tirano sem corar nem desviar o olhar, envergonhada. Podia contemplá-lo à vontade.

Lu Linyuan segurou uma de suas patinhas e apertou as almofadinhas rosadas e fofinhas. — Pequenina, você tem olhos lindos.

Ning Xiaoxiao: — Miau~~

Lu Linyuan: — Dá até vontade de arrancá-los.

Ning Xiaoxiao: — Miau??

Ele passou um dedo pelo narizinho curto e carnudo dela e soltou uma risada. — Estou brincando. Já está tarde. Vamos dormir.

Virou-se para apagar a vela da mesinha. Quando retornou à posição anterior, pousou a mão com toda a naturalidade sobre Ning Xiaoxiao, desenhando círculos com o indicador em seu peito peludo.

Ning Xiaoxiao: 【??? Isso conta como se aproveitar de mim?】

Lu Linyuan: 【Quem está se aproveitando de quem? Você me espiou no banho, pulou dentro da minha banheira e ainda apalpou meu... Se tivesse um pingo de vergonha, não diria uma coisa tão descarada!】

Quanto mais pensava nisso, mais se sentia prejudicado. Num gesto quase emburrado, beliscou o peitinho da gatinha.

— MIAU!!!

【Sai daqui, sem-vergonha!】

Toc, toc, toc!

Algumas batidas na porta interromperam os movimentos um tanto pervertidos de Lu Linyuan.

— O que foi? — perguntou ele em tom grave, voltado para a porta.

Do outro lado, Sanfu respondeu: — Majestade, capturamos os ratos que o senhor pediu!

Ao ouvir a palavra «ratos», Ning Xiaoxiao eriçou todo o pelo. Miando sem parar, enterrou-se no peito de Lu Linyuan.

A roupa de dormir do imperador era de seda, lisa e bastante folgada.

Ao se enfiar ali, ela enterrou metade da cabeça contra o peito dele, parecendo um avestruz idiota que escondesse a cabeça na areia para fugir da realidade.

【Buááá! Não vou comer, não vou comer, não vou comer! Se esse imperador cachorro me obrigar a comer rato, quando eu voltar a ser humana vou pôr cocô de rato na comida dele todos os dias!】

Em vez de se irritar com aquela ameaça, Lu Linyuan achou que ela estava bem mais agradável assim do que em sua forma humana.

Como humana, só sabia bancar a durona. Como gata, já sabia se esconder nos meus braços?

Hum. Que mulher cheia de artimanhas.

Afagou com carinho a cabecinha de Ning Xiaoxiao e respondeu à porta: — Pode comê-los você mesmo.

Sanfu: — ???

*

Depois de dispensar Sanfu, o aposento ficou extraordinariamente silencioso.

Ning Xiaoxiao saiu do peito de Lu Linyuan, encontrou uma posição confortável e se deitou quietinha.

Mas ele achou que ela estava longe demais, puxou-a novamente para junto de si, roçou a ponta do nariz na cabecinha peluda dela e disse com ternura:

— Boa noite, pequenina.

— Miau, miau...

Era a primeira vez que Ning Xiaoxiao dividia a cama com o tirano, e era inevitável sentir certo nervosismo.

Pretendia fugir assim que ele adormecesse, mas pensou melhor: lá fora, o frio era de congelar. Mesmo que saísse, para onde iria?

Além daquele tirano azarado, quem mais recolheria uma gata no meio da noite e a enfiaria debaixo das cobertas para dormir abraçado a ela, bem quentinho?

Em vez de fugir e morrer congelada, era melhor passar uma noite improvisada nos braços do tirano.

Nunca havia sido gata antes; sem experiência, tinha preocupações de sobra:

【Hum... Será que devo ficar mais longe? E se ele se mexer dormindo, rolar por cima de mim e me esmagar até a morte...?】

Vendo que o tirano fechara suavemente os olhos e respirava cada vez mais devagar, tentou se remexer na palma de sua mão para se soltar.

Mas, bem quando estava prestes a escapar daquelas garras demoníacas, a mão de Lu Linyuan se deslocou um pouco para cima e a prendeu firmemente outra vez.

— Quietinha. Não apronte.

Esqueça. Enquanto ele não dormisse de verdade, não conseguiria fugir. Restava aceitar o destino.

O homem e a gata adormeceram assim. Não se sabia quanto tempo havia passado quando Ning Xiaoxiao sentiu uma pressão crescente atrás do traseiro.

Abriu os olhos num sobressalto e descobriu que aquele tirano azarado havia virado de lado e estava pressionando seu rabo com o braço!

— Miau, miau, miau!!!

【Acorda! Você está esmagando meu rabo!】

Empurrou Lu Linyuan com força usando as patinhas, mas, comparado a ela naquele corpo, ele parecia uma montanha. Como poderia movê-lo?

Se não podia vencer pela força, teria de usar a inteligência.

Esticou a patinha e passou delicadamente a almofadinha na ponta do nariz do tirano.

O truque funcionou. Quando ele levantou a mão para coçar o nariz, Ning Xiaoxiao escapou num instante.

【Ah, é assim? Esmagou meu rabo? Pois vou pisotear você!】

Saltou sobre o corpo de Lu Linyuan e mal dera duas pisadas quando ouviu um murmúrio vindo debaixo dela:

— Ning Xiaoxiao... Será que você não pode parar de me atormentar...?

Ning Xiaoxiao: — ???

Interrompeu imediatamente sua dança frenética e desvairada sobre ele e ficou imóvel, observando-o.

As pálpebras estavam fechadas. Continuava dormindo. Devia estar falando durante o sono.

— Eu... não gosto de fazer espacate, nem de cantar...

Ning Xiaoxiao ficou atônita, sem entender muito bem.

Só o fizera abrir as pernas num espacate! Ele guardava tamanho rancor que até sonhava com aquilo?

Mas as palavras seguintes de Lu Linyuan lhe prenderam a respiração, entorpeceram todo o corpo e a deixaram petrificada.

Ele estalou baixinho a língua e murmurou, ainda como se sonhasse:

— Eu não gosto nem um pouco...

— Mas eu... gosto muito de Xiaoxiao...

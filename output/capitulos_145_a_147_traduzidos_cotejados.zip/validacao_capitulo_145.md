# Validação — capítulo 145

- **Fonte primária:** `novel_capitulos_121_a_180(20261103-233558).docx`, chinês tradicional.
- **Limites do capítulo no DOCX:** parágrafos 1688–1767 (índices de base zero).
- **Unidades de texto não vazias (incluindo título):** 77.
- **Linhas de cotejo:** 77.
- **Índices ausentes:** 0; **índices duplicados:** 0; **traduções vazias:** 0.
- **Critério de cotejo:** uma linha por parágrafo não vazio do original, preservando o índice real e a sequência original.
- **Limitações:** cotejo 1:1 e revisão editorial durante a tradução, sem segunda auditoria independente integral. A validação automatizada não certifica perfeição semântica nem ausência de omissões internas a cada parágrafo.

## Observações editoriais e de continuidade

- A narração e os pensamentos imperiais marcados por 【 】 foram mantidos separados das falas audíveis.
- A referência nene foi interpretada como peitinho da gata, preservando a brincadeira corporal de registro atrevido.
- O que Lu Linyuan murmura ao final é inicialmente percebido por Ning como fala de alguém adormecido; não antecipar a revelação seguinte.
- A ameaça de comer ratos é usada para provocá-la; Sanfu é dispensado com a ordem absurda de comer ele próprio os ratos.

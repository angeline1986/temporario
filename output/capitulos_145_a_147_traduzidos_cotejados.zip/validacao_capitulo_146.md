# Validação — capítulo 146

- **Fonte primária:** `novel_capitulos_121_a_180(20261103-233558).docx`, chinês tradicional.
- **Limites do capítulo no DOCX:** parágrafos 1768–1840 (índices de base zero).
- **Unidades de texto não vazias (incluindo título):** 70.
- **Linhas de cotejo:** 70.
- **Índices ausentes:** 0; **índices duplicados:** 0; **traduções vazias:** 0.
- **Critério de cotejo:** uma linha por parágrafo não vazio do original, preservando o índice real e a sequência original.
- **Limitações:** cotejo 1:1 e revisão editorial durante a tradução, sem segunda auditoria independente integral. A validação automatizada não certifica perfeição semântica nem ausência de omissões internas a cada parágrafo.

## Observações editoriais e de continuidade

- O imperador não estava realmente dormindo ao expressar o afeto: o narrador confirma depois que disse aquilo de propósito.
- A recusa de Lu Linyuan em forçar sentimentos pelo poder imperial é central ao capítulo.
- O pedido de folga na quarta vigília e a sopa de painço com camarões foram preservados.
- A pistola de Qi é apresentada como superior à arma ocidental, mas não foram inventados detalhes de fabricação.
- Meio shichen (半個時辰) corresponde a aproximadamente uma hora.
- O insulto 朕羞你先人 e a réplica de Sanfu envolvem humor com os antepassados; o diálogo foi adaptado sem mudar o sentido.

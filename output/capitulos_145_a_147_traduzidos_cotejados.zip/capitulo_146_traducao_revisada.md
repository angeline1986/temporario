# Capítulo 146 — Quando o coração sabe o que quer, não há pressa nem inquietação

Ning Xiaoxiao ainda estava em pé sobre Lu Linyuan. As últimas palavras dele lhe chegaram aos ouvidos e a deixaram completamente desnorteada.

【Ele... gosta de mim?】

Uma mistura complicada de sentimentos tomou conta dela: alegria, mas também apreensão.

Alegria porque ouvira de fato uma declaração de amor do tirano. Isso significava que toda a sua timidez e seus constrangimentos talvez não fossem sentimentos sem correspondência.

Apreensão porque, em sua opinião, naquele mundo antigo ela era o exemplo perfeito de alguém sem talento nem virtude. Nunca acreditara que alguém pudesse ignorar todas as vantagens externas e gostar dela simplesmente por ela ser quem era.

É assim com as pessoas: por mais extrovertidas e otimistas que sejam, quando a pessoa de quem gostam parece uma estrela inalcançável, a sensação de merecer esse amor despenca para perto de zero.

Até alguém muito confiante acaba duvidando de si.

Por isso, mesmo com o coração disparado a cento e oitenta por hora, Ning Xiaoxiao encontrou uma maneira de se acalmar:

Ele era um personagem de papel. Pior: era o par romântico destinado a Gu Sijin, a protagonista da história original. Mesmo gostando dele, ela não tinha coragem de admitir o que sentia.

E Lu Linyuan parecia estar na mesma situação: só ousava dizer tais coisas em sonhos.

Ning Xiaoxiao começou a discutir consigo mesma:

【De qualquer modo, ele não disse isso acordado, olhando para mim. Vou fingir que não ouvi.】

【E tem mais... os sonhos são o contrário da realidade! Se, sonhando, ele diz que gosta de mim, então, acordado, na vida real, não significa que me odeia com todas as forças?】

Consolou-se com aquela lógica absurda. Talvez fosse o único jeito de escapar por algum tempo da prisão daqueles sentimentos e voltar a se sentir livre e despreocupada.

Depois de convencer a si mesma de que Lu Linyuan jamais se apaixonaria por alguém tão comum quanto ela, conseguiu dormir de consciência tranquila.

Despreocupada como sempre, caiu num sono profundo cerca de um quarto de hora depois.

Só quando ela fechou de vez os olhos e a respiração se tornou regular, saindo pelo narizinho curto e carnudo da gata, Lu Linyuan abriu os próprios olhos e ficou observando-a sem piscar.

Com infinita delicadeza, puxou a coberta sobre o corpo peludo da gatinha, acariciou-lhe as costas duas vezes e sussurrou:

— Heh.

— Bobinha.

— Você realmente acha que eu estava falando durante o sono?

Enquanto contemplava a gata preguiçosa à sua frente, recordou, por alguma razão, uma sucessão de cenas dos momentos vividos ao lado de Ning Xiaoxiao.

Sem saber quando isso acontecera, aquela mulher criara raízes em seu coração, sorrateiramente.

Mas ele não tinha pressa de possuí-la por completo.

O melhor amor é aquele em que os dois corações se voltam um para o outro, sem pressa nem aflição, aproximando-se naturalmente.

Não lhe interessava um amor arrancado à força pelo poder imperial.

Um dia, talvez numa tarde de céu tomado pelo crepúsculo,

ele e sua Xiaoxiao ficariam sentados juntos no assento aquecido, sem fazer nada, apenas contemplando as nuvens púrpuras e avermelhadas do lado de fora e ouvindo a respiração um do outro.

Quando as últimas cores do poente desaparecessem e a noite estendesse seu manto azul-escuro, sua Xiaoxiao também lhe diria:

— Ela também gostava muito dele.

Não tinha pressa alguma. Havia tempo de sobra para lidar pacientemente com aquela mulher estranha, maluca e imprevisível.

Até o dia em que ela já não conseguisse guardar tudo para si e tivesse coragem de encarar o próprio coração.

No dia seguinte, Lu Linyuan acordou muito cedo.

A gatinha preguiçosa continuava profundamente adormecida, aninhada na dobra de seu braço.

O braço estava um pouco dormente. Provavelmente, depois de adormecerem, ela havia pousado a cabeça ali sem perceber e passado a noite inteira naquela posição.

Ele tocou de leve seus bigodes compridos. Não moveu sequer um pouco o braço sob ela, temendo interromper um sonho agradável.

Perto da quarta vigília, Sanfu bateu suavemente à porta. — Majestade, está na hora de levantar, fazer a higiene e comparecer à audiência matinal.

Lu Linyuan respondeu num murmúrio quase tão baixo quanto o zumbido de um mosquito: — Hoje vou tirar folga. Dispense os ministros.

Sanfu: — Majestade vai tirar o quê?

Aquele eunuco sempre parecia testar os limites da paciência de Lu Linyuan. O imperador franziu a testa e rosnou baixinho:

— Vou envergonhar seus antepassados!

Sanfu, contrariado, respondeu com a maior reverência: — Sim, Majestade! Vou buscar imediatamente as tabuletas memoriais dos meus veneráveis antepassados para o senhor!

Lu Linyuan: — ...

Sanfu, sem o menor tato, não soubera controlar o volume da voz e acordara a gatinha nos braços do tirano.

Ela se ergueu preguiçosamente, arqueou o corpo num longo espreguiçamento e soltou dois miados. Estava adorável.

Como ele já decidira tirar o dia de folga, não haveria audiência matinal.

Na hora do café da manhã, Lu Linyuan mandou Xiao Yinzi preparar uma sopa cremosa de painço com camarões frescos. Não gostava daquele prato, mas havia perguntado discretamente à cozinha imperial sobre os hábitos alimentares de Ning Xiaoxiao e sabia que ela adorava.

Empurrou a tigela para a gatinha e comentou, fingindo casualidade: — Não consigo tomar. Beba você, para não desperdiçar.

Ning Xiaoxiao: — Miau, miau~~

【Ontem virei gata antes de jantar e agora estou morrendo de fome! Comida de graça? É claro que vou comer!】

Ela pôs para fora a linguinha rosada, coberta de minúsculas papilas ásperas, e lambeu o desjejum que lhe fora «oferecido por caridade».

Depois de comer, Lu Linyuan passou a maior parte do dia no próprio palácio brincando com a gata.

Só perto do anoitecer ordenou que trouxessem da prisão imperial o príncipe ocidental para uma audiência.

Quando o príncipe chegou, Lu Linyuan estava sentado no lugar de honra, com Ning Xiaoxiao tranquilamente acomodada em seu colo.

A princípio, o visitante imaginou que, agora que o imperador melhorara, não ousaria desafiar o «poderio» ocidental e tentaria convencê-lo cordialmente antes de libertá-lo.

Mas Lu Linyuan tirou uma pistola ainda mais refinada que a arma ocidental e disparou na direção de um ponto atrás do príncipe.

BANG!

O estampido fez Ning Xiaoxiao mergulhar nos braços de Lu Linyuan e deixou o príncipe ocidental lívido.

Ele conhecia muito bem a construção das armas de fogo. Por isso, compreendeu perfeitamente que a pistola nas mãos de Lu Linyuan era de uma categoria de potência superior à arma mais recente de seu país.

A única vantagem com que o Ocidente acreditava poder pressionar a dinastia Qi era sua superioridade em armamentos.

Agora que Qi desenvolvera uma arma mais poderosa que as pistolas ocidentais, aquela vantagem — e a confiança que dela vinha — desaparecera por completo.

O príncipe, sabendo reconhecer a situação, murchou imediatamente; há pouco, ainda mantinha a cabeça erguida com arrogância.

Lu Linyuan declarou: — Posso libertá-lo. Mas, quando voltar, diga ao rei do seu país que, de agora em diante, Qi não precisa mais de suas armas. Se continuarem precisando dos nossos cereais e provisões, o preço das importações terá de ser renegociado.

Ciente de que não tinha mais um trunfo para coagir Qi, o príncipe aceitou provisoriamente os termos. Ao retornar ao próprio país, discutiria uma contramedida.

Enquanto os dois conversavam, Ning Xiaoxiao olhou para o relógio mecânico sobre a mesa. Faltava apenas uma hora para recuperar a forma original; assim, escapuliu discretamente do colo de Lu Linyuan.

Mais exatamente, Lu Linyuan permitiu que ela partisse.

Afinal, já brincara o bastante com aquela gata.

Se continuasse, acabaria arrancando todo o pelo dela de tanto acariciá-la.

Depois que voltasse a ser humana, poderia continuar brincando com ela. Não seria tarde demais.

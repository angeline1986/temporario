# Capítulo 147 — Reunião das víboras

Como Ning Xiaoxiao havia se transformado em gata, naturalmente perdera a visita de cumprimentos à imperatriz naquela manhã.

Dias antes, a Consorte Yun, a Consorte Li e a Concubina Shen haviam sido punidas por Lu Linyuan com oitenta tapas na boca por se aproveitarem da desgraça alheia, espalharem rumores e acusarem Ning Xiaoxiao injustamente.

Passados alguns dias, as lesões da Consorte Yun e da Consorte Li estavam quase curadas. Apenas a Concubina Shen, de pele naturalmente muito clara, ainda exibia marcas evidentes de vermelhidão e inchaço.

Já tarde da noite, a imperatriz mandou chamá-la ao próprio palácio e demonstrou uma preocupação quase afetuosa: — Essas feridas no seu rosto nunca cicatrizam completamente. Fico preocupada com você.

Fez um sinal a uma criada, que entregou à Concubina Shen um pequeno pote redondo de cerâmica marrom. — Este é um unguento Zijin para ativar a circulação e dissipar hematomas. É o mais eficaz que existe. Leve-o.

A Concubina Shen ficou profundamente agradecida. — Agradeço os cuidados de Vossa Majestade. A esta altura, só a imperatriz ainda se dispõe a se preocupar comigo...

A imperatriz sorriu serenamente. — Como concubinas do harém, todas servimos ao mesmo imperador e somos irmãs. Como poderia eu permitir que tamanha beleza acabasse marcada por cicatrizes?

Enquanto trocavam gentilezas, Xiangling entrou inclinando-se em reverência e informou: — Majestade, todas as cartas enviadas neste mês pelas famílias das senhoras dos diversos palácios já foram distribuídas.

A imperatriz assentiu. A Concubina Shen, porém, perguntou: — Todas foram entregues? Então por que não recebi nenhuma?

A imperatriz respondeu: — Seu pai está sob investigação incessante do Tribunal de Censores. Eles estão examinando minuciosamente as acusações de corrupção e recebimento de subornos contra ele. Como poderiam permitir que continuasse trocando notícias com você aqui no palácio?

Ao ouvir que sua família passava por dificuldades, Shen ficou desesperada. — Como isso é possível? A indicação daqueles funcionários nem sequer foi ideia do meu pai! Só o escolheram para levar a culpa! Na carta do mês passado ele disse claramente que o caso estava esclarecido, que ele não tinha qualquer envolvimento e que os censores já o haviam libertado. Por que agora...?

— Se os censores vão deixar seu pai em paz, isso depende de uma única palavra do censor imperial — interrompeu-a a imperatriz, elevando a voz.

— Seu pai precisa pensar no seu futuro, assim como o pai da Nobre Dama Gu precisa pensar no futuro da filha. Sua beleza desperta a inveja de todas as mulheres. Se Gu Yanchuan derrubar seu pai, terá acabado de vez com suas perspectivas. A corte e o harém sempre estiveram ligados. Não me diga que só hoje compreendeu isso.

Com algumas frases, a imperatriz transformou a Concubina Shen num pássaro assustado por qualquer ruído.

De origem modesta, Shen tivera enorme dificuldade para alcançar a posição atual de senhora de um palácio. Tanto por sua família quanto por si mesma, não podia permitir que Gu Yanchuan derrubasse seu pai na corte.

Levantou-se de repente e caiu de joelhos diante da imperatriz com um baque. — Majestade, meu pai é inocente! Imploro que me ajude a encontrar uma solução! Ou... ou devo procurar o imperador? Pedir que ele intervenha pessoalmente?

— O que está fazendo? Levante-se, depressa. — A imperatriz tentou erguê-la e balançou a cabeça, impotente. — Procurar o imperador agora não seria praticamente confessar que há algo a esconder? Como uma mulher do harém saberia dos assuntos da corte? Se não procurá-lo, ainda há esperança. Se procurar, só tornará tudo mais complicado.

A Concubina Shen a fitou, com lágrimas nos olhos. — Mas não posso simplesmente ficar de braços cruzados!

A imperatriz respondeu: — Primeiro, pare de chorar e se acalme. A rigor, talvez exista uma saída. Se a Nobre Dama Gu fizesse alguma coisa que enfurecesse profundamente o imperador, o incêndio provocado no harém poderia acabar se espalhando para a corte. Nesse caso, Gu Yanchuan estaria ocupado demais tentando salvar a própria pele para continuar tramando contra seu pai.

Os olhos negros da Concubina Shen giraram enquanto pensamentos maliciosos fervilhavam em sua cabeça. — Algo que enfurecesse profundamente o imperador... Mas, ultimamente, ele só pensa naquela vadia da Ning Xiaoxiao! Faz mais de um mês que a Nobre Dama Gu não põe os pés no Palácio Chaoyang. Se nem consegue vê-lo, como poderia enfurecê-lo?

— Então só podemos pedir que os Céus enxerguem a verdade e não permitam que gente mal-intencionada consiga sempre o que deseja. — A imperatriz assumiu uma expressão de piedade e chamou Xiangling para ajudar Shen a se levantar.

Ao erguê-la do chão, Xiangling murmurou: — Na verdade... não seria tão difícil fazer a Nobre Dama Gu cometer um erro...

Os olhos da Concubina Shen brilharam. — Você conhece algum jeito?

Xiangling falou timidamente: — Hoje em dia, o que mais importa ao imperador é o herdeiro que a Nobre Dama Hua carrega no ventre. A Nobre Dama Gu mora no mesmo palácio que ela. Se alguma coisa acontecesse à criança e uma investigação minuciosa revelasse inúmeros vínculos entre a tragédia e a Nobre Dama Gu, naturalmente o imperador descontaria sua ira nela...

PÁ!

Antes que Xiangling terminasse, a imperatriz explodiu e lhe deu uma bofetada violenta. Assustada, a criada cobriu o rosto e se ajoelhou imediatamente. — Majestade, perdoe-me! Eu...

— Que insolência! Uma simples serva se atreve a especular sobre a descendência imperial? E ainda lança palavras de mau agouro! Está cansada de viver?

Xiangling bateu a testa repetidas vezes no chão. — Buááá! Majestade, tenha misericórdia! Falei sem pensar! Não foi de propósito!

A imperatriz sacudiu as mangas furiosamente e ordenou: — Vá por conta própria ao Departamento de Punições receber vinte golpes de bastão! Se voltar a falar tais absurdos, não a perdoarei!

Xiangling saiu correndo do Palácio Fengluan, cobrindo o rosto e chorando.

Era uma criada que servia à família da imperatriz desde o nascimento, e a senhora jamais se enfurecera de verdade com ela.

Mas, naquele dia, já a condenara a vinte golpes de bastão de uma só vez. Parecia realmente furiosa.

Depois de mandá-la embora, a imperatriz advertiu a Concubina Shen de propósito: — Tudo o que Xiangling disse é absurdo. Finja que não ouviu nada. E lembre-se: aconteça o que acontecer, você não deve tocar no herdeiro imperial. Entendeu?

A Concubina Shen respondeu respeitosamente: — Sim. Guardarei os ensinamentos de Vossa Majestade.

Era o que dizia da boca para fora. No entanto, pelo brilho sombrio de seus olhos, a imperatriz já havia compreendido o que ela estava planejando.

Pouco depois da partida de Shen, Xiangling retornou.

Não fora ao Departamento de Punições, muito menos recebera os golpes. Ao ver a imperatriz, sorriu e lhe entregou uma carta de família.

— Majestade, aqui está a carta que o pai da Concubina Shen enviou para ela.

A imperatriz abriu um sorriso cruel. Pegou a carta e a atirou casualmente no braseiro à sua frente.

As chamas iluminaram seu rosto delicado, sereno e bondoso, produzindo um contraste indescritivelmente sinistro.

Parecia ter absoluta certeza de que a Concubina Shen cairia na armadilha que preparara.

Xiangling, porém, não estava tão otimista. — Majestade... e se a Concubina Shen estragar tudo? Isso não acabará nos envolvendo?

Brincando com um rosário de contas de âmbar e oito tesouros, a imperatriz respondeu, com voz perfeitamente controlada:

— Se Shen executar o plano como deve, aquelas duas «promessas em ascensão» do Palácio Zhongcui e o maldito feto não escaparão vivos. Se fracassar, tudo terá sido ideia dela desde o princípio. O que isso teria a ver comigo?

Deixou cair o rosário sobre a mesa e seu tom tornou-se subitamente muito mais frio:

— Eu a adverti repetidas vezes para não tramar contra o herdeiro imperial. Se ela realmente ousar agir, como senhora do harém, serei a primeira a exigir que confesse seus crimes e receba a pena de morte!

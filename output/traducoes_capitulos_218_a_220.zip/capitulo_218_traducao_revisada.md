# Capítulo 218 — O que você achava ser um pequeno truque era, na verdade, algo que eu havia planejado cuidadosamente

Aquilo lá era alguém com raiva?

Ele estava era fazendo charme!

Quem fica apertando os lábios desse jeito quando está zangado? Aquilo já tinha passado de indireta. Era um pedido escancarado!

Ning Xiaoxiao segurou o riso e entrou na brincadeira: — Então... que tal eu dar um beijo em Vossa Majestade?

Lu Linyuan manteve sua pose orgulhosa e não disse uma palavra, nem aceitando nem recusando.

Ning Xiaoxiao sorriu, resignada, aproximou-se e depositou um beijinho na bochecha dele.

Mas o beijo não melhorou em nada a expressão daquele rosto de gelo.

Ele continuou sério, tocou de leve o arco do próprio lábio com o indicador e disse, cheio de pose:

— Errou o lugar.

Certos presidentes mandões parecem ter nascido mergulhados num barril de óleo de tão melosos e cafonas. Lu Linyuan, aquele “imperador mandão”, não ficava atrás.

Só que, de tanto ele agir assim, Ning Xiaoxiao começou a se perguntar: por que raios estava gostando daquilo?

Pensando bem, depois de tanto tempo, fora os acidentes e as missões, ela nunca o havia beijado por iniciativa própria.

E, agora que refletia, receber dele uma medalha de imunidade à morte e logo passá-la para Gu Sijin realmente tinha sido um pouco insensível. Ela não levara em conta o que ele sentiria.

Se fez besteira, assuma as consequências; se for beijar, tome a iniciativa!

Assim, ela fechou suavemente os olhos e encostou os lábios nos de Lu Linyuan.

Foi como acionar algum interruptor: depois disso, não houve como parar.

Lu Linyuan envolveu-lhe a cintura fina com a mão grande e correspondeu ao beijo com ardor.

*

Ning Xiaoxiao jamais imaginou que havia caído direitinho num “plano” de Lu Linyuan.

Quando ele propôs levá-la à residência das fontes termais, ela insistira em levar Gu Sijin junto.

Lu Linyuan sabia que Ning não conseguia deixar a amiga para trás, receosa de que Gu Sijin fosse maltratada naquele harém capaz de devorar pessoas vivas.

Mas ele não pretendia levar Gu Sijin.

Finalmente havia surgido uma oportunidade de passar um tempo a sós com sua amada, e ele não permitiria que ninguém a estragasse.

Por outro lado, se simplesmente arrastasse Ning Xiaoxiao para longe, ela, tão ligada a Gu Sijin, não conseguiria ficar tranquila. Passaria os dias e as noites preocupada, sem aproveitar a viagem nem conseguir comer direito. Lu Linyuan não suportaria vê-la sofrer assim.

Por isso, naquele dia, depois de declarar expressamente que Gu Sijin não poderia acompanhá-los, ele entregara a Ning Xiaoxiao a medalha de imunidade à morte.

Desde o começo, sua intenção era que ela emprestasse a medalha a Gu Sijin. Assim, Ning não precisaria insistir em levá-la e tampouco temeria pela segurança da amiga enquanto estivesse nas fontes termais.

Todos os truquezinhos que Ning considerava tão espertos eram, na verdade, frutos do cuidado e da preferência que ele lhe dedicava deliberadamente.

E Lu Linyuan não tinha a menor intenção de lhe revelar que tudo aquilo fora pensado para conquistá-la ainda mais.

Para quê contar?

Gostar verdadeiramente de alguém é pensar no que essa pessoa pensa e preocupar-se com o que a preocupa.

Quem precisa anunciar imediatamente cada boa ação, com medo de que ninguém perceba, parece querer se exibir e exigir: “Olhe tudo o que faço por você; agora faça o mesmo por mim”.

Isso não se parece com amor, e sim com uma transação em que cada favor exige uma contrapartida.

E Lu Linyuan não se rebaixaria a isso.

*

Na manhã seguinte, bem cedo, Lu Linyuan levou Ning Xiaoxiao de volta ao Palácio Chaoyang.

Ele foi à audiência matinal da corte; Ning tomou um caminho discreto até o Palácio Fengyi, tentando evitar que qualquer pessoa descobrisse o ocorrido na véspera.

Gu Sijin já estava habituada a que ela passasse a noite fora.

Ao vê-la de manhã, brincou: — Para que se dar ao trabalho de voltar? Não seria mais perto ir dos aposentos do imperador diretamente prestar cumprimentos à imperatriz?

Ning Xiaoxiao se lembrou das instruções de Lu Linyuan e tinha uma ideia de como ele moveria aquela peça. Quanto menos gente soubesse, melhor. Por isso, não contou a verdade a Gu Sijin.

— Irmã, não zombe de mim... Você ainda não soube de uma coisa tão importante?

Gu Sijin franziu a testa, intrigada. — Do quê?

— Ai... — Ning Xiaoxiao suspirou e balançou a cabeça, desanimada. — Ontem à noite, o imperador escolheu a placa da Consorte Nobre e foi ao Palácio Zhaochun.

— Isso...

Gu Sijin não gostava de bisbilhotar os assuntos do palácio. Dormira cedo na noite anterior e não soubera de nenhuma movimentação.

Depois de ouvir a notícia, permaneceu calada por alguns instantes antes de consolá-la: — Não fique tão abatida. Quem se casa com um imperador precisa saber que ele jamais pertencerá por inteiro a uma só mulher. A família da Consorte Nobre é poderosa; Sua Majestade precisa tratar Tong Guowei com deferência. A corte e o harém são inseparáveis, então não é surpreendente que ela receba favores.

Segurou a mão de Ning Xiaoxiao, com os olhos cheios de ternura. — Mas tente ver o lado bom. As outras recebem atenção por causa de suas famílias. O imperador precisa pesar os interesses da corte e do harém e, muitas vezes, encenar uma relação. Com você é diferente. Você veio de uma posição de criada; se ele a trata bem, é simplesmente porque gosta de quem você é. Comparando uma coisa com a outra, fica evidente o que tem mais valor.

Era estranho.

Lu Linyuan a tratava muitíssimo bem. Ela sabia que não acontecera absolutamente nada entre ele e a Consorte Nobre. E sabia que a tristeza exibida diante de Gu Sijin era fingimento...

Mesmo assim, aquelas palavras a comoveram profundamente. Sentiu um aperto no peito e os olhos voltaram a se encher de lágrimas.

Sem saber o motivo verdadeiro, Gu Sijin achou que ela estava magoada e a abraçou com força. — Pronto, não chore. Nossa Xiaoxiao é muito mais bonita que a Consorte Nobre. Além disso, não foi você quem disse que quanto mais alto alguém sobe, maior é a queda? O esplendor dela não vai durar.

Mais tarde, quando foram juntas prestar cumprimentos à imperatriz, encontraram a comitiva da Consorte Nobre numa esquina do lado de fora do Palácio Fengyi.

Ela saíra com suas melhores roupas e estava coberta de joias, brilhando tanto que mal se conseguia olhar diretamente para ela.

Depois que Ning Xiaoxiao e Gu Sijin a saudaram, a Consorte Nobre se dirigiu a Gu Sijin: — Entre primeiro. Tenho algo a dizer à Concubina Hua.

— Mas...

A Consorte Nobre a fulminou com os olhos e a interrompeu: — Tenho autoridade para auxiliar na administração dos seis palácios. Quer apanhar?

Ao perceber que Gu Sijin ainda pretendia defendê-la, Ning puxou-a de lado e murmurou: — Irmã, espere por mim aqui. Ela não terá coragem de me fazer nada.

Gu Sijin apertou-lhe a mão, preocupadíssima. — Concorde com o que ela disser. Agora que está no auge do prestígio, não a confronte. Entendeu?

Que bobinha.

Aconselhava Ning a não desafiar a Consorte Nobre, mas ela mesma acabara de enfrentá-la para proteger a amiga.

Ning voltou para junto da Consorte Nobre, sorrindo: — Quais são as ordens de Vossa Alteza?

A Consorte Nobre examinou-a com os olhos semicerrados. — Escute bem: o que aconteceu ontem à noite não pode sair dessa sua boca imunda. Se disser uma única palavra, tenho meios de fazer você morrer sem deixar um cadáver inteiro!

Ning levou a mão ao peito, fingindo um susto. — Nossa, que medo de Vossa Alteza! Está bem, entendi: ontem o imperador ficou sozinho em seus aposentos e os dois se divertiram a noite inteira. Assim está bom?

A Consorte Nobre soltou um resmungo. — Do que está tão satisfeita? Hoje o imperador pode favorecê-la; amanhã pode mandá-la ao Palácio Frio.

— Quanto tempo acha que dura um favoritismo sem o apoio de uma família importante? Se daqui para a frente me tratar com reverência e se submeter, talvez eu deixe você viver. Do contrário, estará enfrentando a mim e a toda a minha família!

Ning Xiaoxiao não tinha paciência, logo cedo, para prolongar a conversa com aquela idiota. Respondeu sem grande interesse e se virou para ir embora.

De repente, a Consorte Nobre a segurou e deu dois tapinhas no rosto dela.

— Tsc, tsc. Eu sabia que não estava enganada a seu respeito. Desde os tempos em que você servia à Nobre Dama Gu, percebi que não era flor que se cheirasse.

— Com esse rosto, você parece uma verdadeira sedutora demoníaca!

A pouca paciência que Ning Xiaoxiao ainda tinha acabara de se esgotar.

Ela sacudiu a mão da Consorte Nobre, arregaçou as mangas e lhe acertou um soco bem no nariz.

— Demônio é você! Sua família inteira é um bando de peças de mahjong!

— Seu pai é um Dois de Círculos, sua mãe é um Cinco de Caracteres e seu avô é um Dragão Vermelho!

*

PS: Amanhã vamos passar férias na residência das fontes termais! A princesa mais velha e Huanü, Ren Duanli e o príncipe Jing também estarão lá~

Três casais vão se afastar das intrigas e fazer um passeio em grupo~

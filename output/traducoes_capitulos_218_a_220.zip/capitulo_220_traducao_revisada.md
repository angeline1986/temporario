# Capítulo 220 — Especial de Qixi: o ingênuo adorável × o grande general (1)

A residência das fontes termais ficava a certa distância da capital. Como a comitiva avançava lentamente, a viagem levaria cerca de três dias.

Ren Duanli, comandante do Acampamento da Cavalaria de Elite, era responsável pela segurança de Lu Linyuan naquela ocasião.

Durante todo o percurso, não entrou numa carruagem: montou Pixiu e seguiu à frente com a vanguarda da Guarda dos Tigres.

Era um homem frio. Tão frio que, embora Lu Linyuan e Chu Xingran fossem seus melhores amigos de infância, quase não conversava nem quando estavam juntos.

Preferia a tranquilidade de ficar sozinho ao tumulto das reuniões.

Mas, com aquele desastre ambulante e tagarela chamado Lu Yiqiu, o príncipe Jing, por perto, seus ouvidos jamais conheciam sossego.

Em vez de entrar numa carruagem, Lu Yiqiu insistia em cavalgar lado a lado com Ren Duanli.

— Meu Duanlizinho, que dia lindo hoje~

— Meu Duanlizinho, faz três dias que não vejo você.

— O que andou fazendo? Nem apareceu para brincar comigo!

— Estava ocupado — respondeu Ren Duanli.

— Ocupado com o quê?

— Com coisas.

— ...Eu sei! Estou perguntando que coisas eram essas!

— Treinar soldados.

— ...Por que você fala só duas palavrinhas de cada vez? Vai morrer se disser uma a mais?

— Não vou.

Lu Yiqiu: — ...

Embora todo aquele entusiasmo tivesse recebido apenas respostas geladas, Lu Yiqiu não parecia se importar se Ren Duanli lhe dava atenção ou não.

Contanto que pudesse estar sempre ao lado dele, “importunando-o”, já estava satisfeito.

*

Depois de um dia inteiro de viagem, a comitiva chegou ao riacho Qishui quando o céu começava a escurecer.

O riacho ficava no Vale dos Vagalumes. As águas termais que nutriam as profundezas daquele desfiladeiro permitiam que grandes grupos de vagalumes aparecessem entre os arbustos mesmo no inverno rigoroso. Daí o nome do vale.

Lu Yiqiu adorava essas coisas mágicas e esquisitas. Virou o cavalo e correu até a carruagem imperial para gritar a Lu Linyuan:

— Irmão! Vamos passar a noite aqui? Lá no fundo do Vale dos Vagalumes aparecem lanterninhas noturnas. Quero ver!

Lu Linyuan afastou a cortina da carruagem e lhe lançou um olhar. — Quantos anos você tem? Por que continua tão infantil?

Ning Xiaoxiao, que crescera no mundo moderno, nunca havia visto um vagalume de perto. Curiosa, perguntou: — Existem mesmo essas lanterninhas no inverno? Que interessante!

Ao ouvir que sua amada também queria ver, a atitude de Lu Linyuan mudou imediatamente, numa reviravolta de cento e oitenta graus.

— Não é? Eu também acho interessante. Então acamparemos aqui esta noite.

Lu Yiqiu: — ??? Irmão! Quando eu digo, é infantil; quando ela diz, é interessante! Mas você... Hein?!

Lu Linyuan lançou uma almofada macia para fora da carruagem imperial, acertando a cabeça de Lu Yiqiu.

— Que história é essa de “ela”? Tenha modos! Chame-a de cunhada imperial!

“Cunhada imperial” era a forma como um príncipe normalmente se dirigia à imperatriz. Lu Yiqiu costumava chamar a imperatriz apenas de “imperatriz”. O fato de Lu Linyuan exigir que assim chamasse Ning Xiaoxiao mostrava o peso que ela tinha em seu coração.

Lu Yiqiu sabia ser encantador e agradar quando queria. Já que o irmão dera a ordem, faria questão de prestigiá-lo. Chamou Ning Xiaoxiao de “cunhada imperial” várias vezes e depois saiu correndo, todo animado, para contar aquela “fofoca bombástica” a Ren Duanli.

Naquela noite, a comitiva acampou na entrada do Vale dos Vagalumes.

Dali também se podiam ver as lanterninhas noturnas, mas em número reduzido.

Lu Yiqiu insistiu para que Lu Linyuan e Ning Xiaoxiao o acompanhassem até o fundo do vale. Lu Linyuan, porém, recusou, alegando que Ning estava cansada depois de um dia inteiro de viagem.

Como os dois não iriam, Lu Yiqiu também não ousou convidar a princesa mais velha, com medo de apanhar dela. Só lhe restou importunar Ren Duanli com súplicas e insistências.

Ren Duanli já estava deitado. Por mais que Lu Yiqiu implorasse, nem que virasse o mundo de cabeça para baixo ele se levantaria.

Por fim, Lu Yiqiu se irritou e declarou, bufando: — Se não quer ir, esqueça! Eu vou sozinho!

E saiu correndo da tenda sem olhar para trás.

O caminho que avançava pelo Vale dos Vagalumes não era muito acidentado. O problema eram as árvores densas, que bloqueavam o luar e deixavam tudo mergulhado na escuridão.

Aquele bobinho ingênuo estava tão contrariado que se esquecera de pegar uma lanterna antes de entrar na montanha.

Depois de se afastar bastante, a noite escureceu até não dar para enxergar a própria mão diante do rosto. Apavorado, só lhe restou cantar para criar coragem.

Enquanto caminhava, de repente ouviu um movimento estranho no mato.

Olhou na direção do som e viu dois pontos verde-fosforescentes brilhando entre os arbustos escuros.

As luzinhas piscavam. A princípio, achou que fossem lanterninhas noturnas e caminhou em direção a elas.

Só quando ouviu um uivo de lobo Lu Yiqiu soltou um grito e saiu correndo o mais rápido que pôde.

Os lobos selvagens da montanha eram muito velozes. Sem conseguir enxergar o caminho, Lu Yiqiu tropeçou num buraco e caiu.

O lobo abriu ligeiramente a boca, expondo presas afiadas e a língua vermelha. Fios de saliva escorriam pelo pelo e pingavam no chão.

Não lhe deu chance de fugir outra vez. Rosnou baixo e saltou direto sobre ele.

No instante em que estava prestes a cravar os dentes na garganta de Lu Yiqiu, uma sombra negra se chocou contra o lobo, derrubou-o e imobilizou-o firmemente com as patas dianteiras poderosas.

Uma luz morna e amarelada se aproximou por trás. Ainda apavorado, Lu Yiqiu enfim conseguiu enxergar:

Quem prendia o lobo sob as patas e brincava com ele era Pixiu. Ren Duanli vinha atrás, tranquilamente, com uma lanterna numa mão e uma espada na outra.

Assim que viu Ren Duanli, Lu Yiqiu sentiu toda a mágoa subir de uma vez. Seus olhos se encheram de lágrimas e ele começou a chorar aos berros.

Levantou-se do chão e passou a esmurrar o peito de Ren Duanli com os punhinhos, com a voz carregada de ressentimento.

— Buaaa! Você não tinha dito que não vinha?

— Então não viesse! Me deixasse ser devorado por aquele lobão! Queria ver como ia se explicar para o meu irmão!

Ren Duanli permaneceu em silêncio, deixando que ele batesse.

Quando Lu Yiqiu ficou praticamente sem forças, o general lhe entregou a lanterna e soltou uma frase gelada:

— Você dá mais trabalho que uma mulher.

Então desembainhou a espada e, com um movimento rápido demais para ser visto, cortou a garganta do lobo.

Pixiu virou a cabeça para Ren Duanli e soltou um ganido baixinho, como se reclamasse que ainda não havia terminado de brincar.

Ren Duanli lhe fez um gesto. A pantera obedeceu, aproximou-se e se deitou ao seu lado.

Ele olhou por cima do ombro para Lu Yiqiu, arqueou uma sobrancelha e perguntou: — Ainda vai?

— Humph! Não é da sua conta!

Lu Yiqiu o empurrou e continuou caminhando rumo ao fundo do vale.

Ren Duanli observou suas costas orgulhosas, com a expressão cada vez mais fria.

Girou o pescoço, pressionou a língua contra a parte interna da bochecha direita e, visivelmente impaciente, agarrou Lu Yiqiu pela cintura fina e o jogou sobre as costas de Pixiu.

— Veja logo o que quer ver e vamos embora. Odeio insetos.

Ele seguiu à frente, enquanto Pixiu carregava Lu Yiqiu logo atrás.

Lu Yiqiu era do tipo que respondia melhor à firmeza do que à delicadeza. E todas aquelas provocações e manhas dirigidas especificamente a Ren Duanli pareciam ser, desde sempre, uma forma de testar alguma coisa.

Evidentemente, o teste obtivera uma resposta positiva.

Por isso, agora abraçava o pescoço de Pixiu, enterrava o rosto no pelo curto e macio da pantera e sorria feito um bobinho envergonhado.

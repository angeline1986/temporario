# Validação — capítulo 218

- **Fonte:** `novel_capitulos_212_a_270(20261105-204934).docx` (original chinês tradicional; segunda cópia conferida por SHA-256).
- **Limite:** parágrafos do DOCX com índices reais base zero de `426` até `504` (exclusivo: `505`), até antes do título do capítulo seguinte.
- **Unidades não vazias incluindo título, apartes e notas:** 76.
- **Cotejo:** 76 linhas de dados e cabeçalho exato `indice_docx,original_chines,traducao_portugues`.
- **Checagem estrutural:** nenhum índice duplicado, nenhum índice de parágrafo não vazio ausente, nenhum campo traduzido vazio. Ordem e índices preservados.
- **Coerência Markdown/CSV:** tradução gerada diretamente das mesmas unidades do cotejo, na mesma ordem.
- **Decisões editoriais:** A expressão 妖姬 (“sedutora demoníaca”) é explorada foneticamente como 幺雞 (peça/termo de mahjong) e seguida de nomes de outras peças (二餅, 五萬, 紅中). A tradução conserva a referência ao mahjong; a aproximação sonora não é integralmente reproduzível em português. A cena do soco ocorre antes de o tempo ser retrocedido no capítulo seguinte, não sendo um fato consolidado na nova linha temporal. O trecho 218 menciona Palácio Fengyi conforme original.
- **Limitação:** a cobertura estrutural 1:1 não constitui auditoria semântica independente da qualidade ou da exatidão de cada escolha tradutória.

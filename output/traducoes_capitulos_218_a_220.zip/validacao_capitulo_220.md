# Validação — capítulo 220

- **Fonte:** `novel_capitulos_212_a_270(20261105-204934).docx` (original chinês tradicional; segunda cópia conferida por SHA-256).
- **Limite:** parágrafos do DOCX com índices reais base zero de `575` até `652` (exclusivo: `653`), até antes do título do capítulo seguinte.
- **Unidades não vazias incluindo título, apartes e notas:** 75.
- **Cotejo:** 75 linhas de dados e cabeçalho exato `indice_docx,original_chines,traducao_portugues`.
- **Checagem estrutural:** nenhum índice duplicado, nenhum índice de parágrafo não vazio ausente, nenhum campo traduzido vazio. Ordem e índices preservados.
- **Coerência Markdown/CSV:** tradução gerada diretamente das mesmas unidades do cotejo, na mesma ordem.
- **Decisões editoriais:** Capítulo identificado como especial de Qixi no próprio original. 宵燭 (“lanterninhas noturnas”) refere-se aos vagalumes neste contexto. 皇嫂 (“cunhada imperial”) é uma forma de tratamento normalmente destinada à imperatriz, relevante para a relação de Ning com Lu. A alternância entre o nome 陸弈秋 e outras grafias registradas na pílula é normalizada para Lu Yiqiu segundo glossário; 任斷離 para Ren Duanli.
- **Limitação:** a cobertura estrutural 1:1 não constitui auditoria semântica independente da qualidade ou da exatidão de cada escolha tradutória.

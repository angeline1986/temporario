# Capítulo 219 — Partida para a residência das fontes termais: três casais reunidos

Na verdade, considerando a posição que Ning Xiaoxiao ocupava no coração de Lu Linyuan, se quisesse bater na Consorte Nobre, podia simplesmente bater. Precisava mesmo escolher a ocasião?

Mas satisfazer o impulso momentâneo não ajudaria em nada o plano maior.

Para arrancar de vez a úlcera apodrecida que a família Tong representava para a dinastia Qi, primeiro era preciso deixar a Consorte Nobre tão convencida que perdesse a prudência.

Depois de lhe dar uma surra e descarregar a raiva, Ning Xiaoxiao nem lhe deu chance de responder: fechou os olhos, abriu o documento e apertou o botão Retroceder.

Três minutos antes:

A Consorte Nobre resmungou: — Do que está tão satisfeita? Hoje o imperador pode favorecê-la; amanhã pode mandá-la ao Palácio Frio.

— Quanto tempo acha que dura um favoritismo sem o apoio de uma família importante? Se daqui para a frente me tratar com reverência e se submeter, talvez eu deixe você viver. Do contrário, estará enfrentando a mim e a toda a minha família!

Ning Xiaoxiao assumiu de propósito uma expressão medrosa e se curvou humildemente diante dela.

— Para ser sincera, Alteza, sei muito bem que o imperador se interessa por mim apenas por novidade. Isso me deixa bastante apreensiva.

— Não tenho família poderosa a quem recorrer, não sei agradar com palavras e já ofendi muitas mulheres do harém, tanto aberta quanto secretamente. Se Vossa Alteza não me desprezar, desejo colocar-me sob sua proteção e seguir todas as suas ordens.

Ao ver o ar cada vez mais satisfeito da Consorte Nobre, Ning aproveitou a oportunidade, aproximou-se e aconselhou em voz baixa:

— A imperatriz não tem virtudes nem competência. Há muito deveria ter cedido seu lugar a alguém mais digno. Em minha opinião, somente Vossa Alteza é capaz de representar o papel de mãe exemplar de todo o império.

Aquela enxurrada de bajulação fez a Consorte Nobre se sentir nas nuvens.

Ela ajeitou o ornamento de cabelo balançante, ergueu os olhos de fênix e sorriu com presunção.

— A imperatriz já é velha e perdeu o encanto. Como poderia se comparar comigo? Já que deseja passar para o meu lado, darei a você uma oportunidade de provar sua lealdade. Quando formos cumprimentar a imperatriz, acompanhe-me numa pequena encenação e vamos tirar do sério aquela velha desbotada.

Então se inclinou ao ouvido de Ning Xiaoxiao e começou a cochichar suas instruções.

*

Na hora de cumprimentar a imperatriz, Ning Xiaoxiao e Gu Sijin entraram primeiro no Palácio Fengluan. A Consorte Nobre já havia chegado à entrada, mas permaneceu sentada em seu palanquim durante um quarto de hora antes de entrar no salão principal.

Arrogante como sempre, mal cruzou a porta soltou um bocejo, ergueu o lenço para tocar a ponta do nariz e caminhou até seu assento sem saudar a imperatriz.

Só depois que as outras concubinas se levantaram para cumprimentá-la, ela disse em tom preguiçoso à imperatriz:

— Ontem à noite, servir ao imperador me deu um trabalhão. Nós só fomos dormir depois da metade da noite. Por isso me atrasei para cumprimentar Vossa Majestade. Não se importa, certo?

A imperatriz sorriu serenamente. — De modo algum. Mesmo tendo dormido tão poucas horas, você ainda fez questão de vir me prestar respeitos. Como poderia culpá-la por respeitar tão bem a hierarquia e a etiqueta?

Em seguida olhou para Ning Xiaoxiao e mudou de assunto: — Concubina Hua, amanhã vocês partirão para as fontes termais. Já preparou a bagagem?

Ning assentiu, mas manteve o rosto caído e a boca amuada, parecendo bastante infeliz.

A imperatriz perguntou: — Viajar amanhã com o imperador deveria ser uma alegria. Por que está tão preocupada?

— Respondendo a Vossa Majestade, eu não estou...

— Afinal, você deveria ser a mais feliz. Quantas pessoas dariam tudo por essa sorte! — A imperatriz se voltou para a Consorte Nobre. — Aliás, você que goza de tanto prestígio, como é que não foi incluída na viagem?

A Consorte Nobre já esperava que a imperatriz tentasse zombar dela por isso. E era exatamente para essa cena que, momentos antes, havia instruído Ning Xiaoxiao.

Sem perder a calma, pegou uma xícara de chá, retirou lentamente a espuma da superfície, tomou um gole e respondeu: — Não é que o imperador não tenha me convidado. Eu é que não quis ir.

— Ah, é? Ora, ora! — A imperatriz soltou uma risadinha de escárnio. — Essa é novidade para mim.

— Se não acredita, pergunte à Concubina Hua. Por que acha que ela está com esse rosto tão triste hoje?

Diante de tamanha confiança, a imperatriz fez a pergunta a Ning Xiaoxiao quase por acaso.

— Ontem... quando eu acompanhava Sua Majestade, ele escolheu a placa da Consorte Nobre. Antes de partirmos, disse que decidira levar Vossa Alteza às fontes termais e me deixar no palácio. Depois, ao perceber que eu fiquei bastante abalada, a Consorte Nobre se compadeceu e disse que não iria mais, permitindo que eu a acompanhasse como planejado. Só então o imperador concordou.

Sua voz embargou enquanto falava; a encenação era tão convincente que parecia ter sofrido uma enorme injustiça.

Ao ouvir aquilo, a imperatriz sentiu o coração apertar.

Lu Linyuan havia enfrentado até a imperatriz-viúva por causa de Ning Xiaoxiao. Será que agora dedicava aquele mesmo favoritismo à Consorte Nobre?

Com uma família poderosa e o favor imperial, bastaria a Consorte Nobre ter um filho para ameaçar de verdade a posição da imperatriz. Por quanto tempo ela ainda ocuparia o trono principal do harém?

Ao perceber o desconforto da imperatriz, a Consorte Nobre continuou com suas provocações venenosas: — É claro que não posso deixar o palácio agora. Sua Majestade acabou de me conceder autoridade para auxiliar na administração dos seis palácios. Naturalmente, devo ficar aqui e dividir os encargos com a imperatriz. Não se preocupe: enquanto eu estiver aqui, Vossa Majestade não precisará mais se envolver com os assuntos incômodos do harém.

Ning Xiaoxiao contemplou em silêncio as duas mulheres, prestes a se engalfinhar.

Briguem, briguem. Quanto mais feroz for a disputa agora, mais interessante será o espetáculo depois.

*

No dia seguinte, era hora de partir para a residência das fontes termais. As carruagens e os cavalos aguardavam no portão sul da cidade imperial.

Lu Linyuan só chegaria depois da audiência matinal. Assim, Xiao Yinzi acompanhou Ning Xiaoxiao até a carruagem no portão sul, enquanto Gu Sijin foi se despedir dela.

Ouvindo Xiao Yinzi conversar no caminho, Ning descobriu que, além dela e de Lu Linyuan, o príncipe Jing e a princesa mais velha Qingyang também fariam a viagem.

Isso começara quando Ning, tentando convencer Lu Linyuan a deixar Gu Sijin acompanhá-los, comentara indiretamente que seria meio sem graça viajarem só os dois.

Então Lu Linyuan convidara os outros em segredo para servirem de “diversão” para Ning Xiaoxiao.

Quando Ning chegou, o príncipe Jing e Qingyang já estavam esperando.

Montado em Pixiu, a pantera-negra de Ren Duanli, o príncipe Jing fazia o animal assustar de propósito os cavalos imperiais. Um deles se sobressaltou e quase lhe acertou o rosto com um coice. Apavorado, ele deu um pulo e se agarrou ao pescoço de Ren Duanli, choramingando.

Qingyang, por sua vez, sussurrava algo ao ouvido de Huanü, que sorria radiante.

Ao vê-la chegando de longe, Qingyang arqueou levemente a sobrancelha e a chamou: — Tampinha, quanto tempo!

O príncipe Jing virou a cabeça na direção dela e acenou vigorosamente. — Oiê, heroína das calcinhas! Nos encontramos de novo!

Segurando a mão de Gu Sijin, Ning Xiaoxiao se aproximou e a apresentou ao príncipe Jing e a Qingyang. Depois de algumas brincadeiras, ficaram esperando Lu Linyuan para iniciar a viagem.

Quando a comitiva começou a atravessar o portão, Ning pôs a cabeça para fora da janela da carruagem e acenou com força para Gu Sijin. — Irmã! Enquanto eu estiver fora, cuide bem de você!

Gu Sijin sorriu e ia responder, mas viu Ning ser puxada bruscamente de volta para dentro da carruagem por uma força irresistível.

Era Lu Linyuan, que enganchara um dedo no cinto de Ning Xiaoxiao para trazê-la de volta.

— Haverá quem cuide dela. Não precisa se preocupar.

Ning Xiaoxiao: — ???

Depois que Gu Sijin viu a comitiva partir, uma rajada de vento fez suas fitas esvoaçarem e seus longos cabelos negros dançarem.

Qiqi se colocou diante dela para protegê-la do vento. — Minha senhora, o vento está ficando forte. É melhor voltarmos logo para o palácio.

Gu Sijin respondeu afirmativamente e se virou.

Seu jovem amado, vestido de azul, estava parado não muito longe, em meio ao vento, observando-a em silêncio.

Os olhos de Chu Xingran brilhavam; uma luz ardente tomava suas pupilas.

Era como se estrelas tivessem caído ali dentro.

E Gu Sijin, envolvida naquele olhar, parecia a lua seguida e adorada por um céu inteiro de estrelas.

(PS: Lá vou eu pedir folga outra vez! Hoje haverá só uma atualização, tá? Amanhã serão cinco. O especial de Qixi também sai amanhã.)

(Amo vocês! Feliz Qixi~)

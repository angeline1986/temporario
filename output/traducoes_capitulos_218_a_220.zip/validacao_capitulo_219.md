# Validação — capítulo 219

- **Fonte:** `novel_capitulos_212_a_270(20261105-204934).docx` (original chinês tradicional; segunda cópia conferida por SHA-256).
- **Limite:** parágrafos do DOCX com índices reais base zero de `505` até `574` (exclusivo: `575`), até antes do título do capítulo seguinte.
- **Unidades não vazias incluindo título, apartes e notas:** 67.
- **Cotejo:** 67 linhas de dados e cabeçalho exato `indice_docx,original_chines,traducao_portugues`.
- **Checagem estrutural:** nenhum índice duplicado, nenhum índice de parágrafo não vazio ausente, nenhum campo traduzido vazio. Ordem e índices preservados.
- **Coerência Markdown/CSV:** tradução gerada diretamente das mesmas unidades do cotejo, na mesma ordem.
- **Decisões editoriais:** O retrocesso de três minutos restitui a cena anterior à agressão do capítulo 218. As alegações de ter passado a noite com o imperador e de ter sido convidada às fontes termais integram a encenação deliberada e não devem ser narradas como acontecimentos verdadeiros. O original nomeia Fengluan (鳳鸞宮) no início da audiência; a tradução preserva o nome, sem harmonizá-lo silenciosamente com Fengyi.
- **Limitação:** a cobertura estrutural 1:1 não constitui auditoria semântica independente da qualidade ou da exatidão de cada escolha tradutória.

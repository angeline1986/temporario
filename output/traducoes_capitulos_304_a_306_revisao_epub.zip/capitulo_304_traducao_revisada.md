Capítulo 304 — A cerimônia de nomeação da imperatriz (II)

Nesse instante, enquanto Ning Xiaoxiao murmurava nervosamente para si mesma com a cabeça baixa, ela não percebeu as expressões de choque nos rostos dos funcionários da corte quando Lu Linyuan caminhou em sua direção.

Desde os tempos antigos, os dragões sempre estiveram acima das fênix, e os homens sempre foram superiores às mulheres, especialmente porque Lu Linyuan é o dragão mais nobre entre os homens do mundo.

A túnica cerimonial de Ning Xiaoxiao já ostentava nove dragões de cinco garras. Como se isso não bastasse, até os passos que cabiam à imperatriz foram invertidos: agora era o imperador quem caminhava ao encontro dela!

Embora Ning Xiaoxiao tivesse feito muitas coisas que iam contra as regras no passado, Lu Linyuan optou por ignorá-las porque se importava com ela.

Desta vez, ficou claro que Ning Xiaoxiao queria seguir as regras, mas Lu Linyuan se antecipou e as quebrou antes que ela pudesse.

Os ministros sentiram aquele cheiro enjoativo de romance no ar e chegaram todos à mesma conclusão:

Melhor não falar nem perguntar nada. Era mais seguro ficar quietinho, acompanhando a fofoca. Num dia tão feliz, ninguém queria provocar o temperamento do tirano.

Todos os ministros sabiam se comportar. Só a imperatriz-viúva, aquela criatura sem noção, ficou paralisada, com uma expressão particularmente sombria.

Ela estava originalmente ao lado de Lu Linyuan, mas agora que Lu Linyuan se aproximou, ela teve que se rebaixar a cumprimentar Ning Xiaoxiao, a nova imperatriz.

A imperatriz-viúva franziu a testa, conduzindo a contragosto o Grande Ministro da Guarda Imperial e o Grande Secretário para a frente. Seus olhos penetrantes encontraram o olhar apavorado de Ning Xiaoxiao:

— Ning, conduzirei pessoalmente o rito. O comandante da Guarda Imperial e o grande secretário lhe entregarão o registro imperial em ouro e o selo da fênix.

Seguindo o protocolo, Qingzhu solenemente chamou de lado: "Por favor, Vossa Majestade a Imperatriz, ajoelhe-se para receber o livro de ouro e o selo da fênix."

De acordo com os procedimentos da cerimônia de coroação, ela primeiro teve que se ajoelhar para receber o livro de ouro e o selo da fênix, depois o eunuco-chefe leu o édito imperial de sua coroação, e então Lu Linyuan entregou pessoalmente o édito a ela antes que ela pudesse se levantar.

Com tantas pessoas assistindo, Ning Xiaoxiao temia envergonhar Lu Linyuan, então não ousou cometer o menor erro.

Ela, que estava acostumada a quebrar as regras, havia praticado o procedimento do palácio de três ajoelhamentos e nove reverências inúmeras vezes nos últimos dias.

Quando ela ergueu a barra do traje cerimonial para se ajoelhar, uma mão gentil segurou seu antebraço.

Ela olhou para Lu Linyuan com um toque de dúvida nos olhos.

Antes que ela pudesse perguntar, Lu Linyuan tomou o édito imperial que a nomeava imperatriz das mãos de Sanfu e o entregou diretamente a Ning Xiaoxiao.

Ning Xiaoxiao: “???”

Lu Linyuan: — Não vamos ler esse decreto em voz alta. Leia você mesma.

Ning Xiaoxiao desenrolou lentamente o édito imperial e viu que continha apenas uma linha de texto concisa:

【Seja bem-vinda, meu amor, à morada do meu coração. Coraçãozinho para você!】

Aquelas poucas palavras atingiram os olhos de Ning Xiaoxiao como tijolos, deixando-a atônita.

Ah, então era por isso que ele não queria que lessem o decreto!

Ora, vejam só! Aquilo era jeito de alguém falar?

Não, aquilo era jeito de marido apaixonado falar...

Embora a imperatriz-viúva não soubesse o que estava escrito no édito imperial, sua expressão era de choque.

De acordo com as regras, Ning Xiaoxiao deveria ter obtido primeiro o Livro Dourado e o Selo da Fênix antes que o Édito Imperial pudesse ser entregue a ela após ser lido em voz alta.

Ela podia não conseguir impor disciplina a Lu Linyuan, mas, agora que a nova nora chegava, estava decidida a estabelecer a própria autoridade.

Então a imperatriz-viúva ordenou: — Sem receber o registro de ouro e o selo da fênix, você ainda não é imperatriz. Há tantos ministros assistindo! Não perca a compostura e se torne motivo de chacota. Ajoelhe-se.

— Ah...

Essa foi a primeira vez que Ning Xiaoxiao se comportou de maneira tão obediente diante da imperatriz-viúva; quando a imperatriz-viúva lhe ordenou que se ajoelhasse, seus joelhos cederam.

Vendo sua esposa prestes a ceder, Lu Linyuan apertou um pouco mais o antebraço dela e ficou sério.

— Sou seu marido. Diante de você, não sou o imperador.

— Marido e mulher formam um só coração e são iguais. Você não precisa se ajoelhar.

Essas duas frases foram ditas para que todos ouvissem.

Então ele sussurrou algo no ouvido de Ning Xiaoxiao:

— Se você se ajoelhar diante de mim, quer que eu passe o resto da vida me ajoelhando diante de você quando fecharmos a porta do quarto, para compensar?

As bochechas de Ning Xiaoxiao coraram. — Ah, A-Yuan, não diga bobagens... Eu nem sou tão mandona assim...

A brincadeira do casal pareceu ter ofendido a imperatriz-viúva, que subitamente ficou irritada novamente.

"Majestade! Tantos oficiais civis e militares estão observando. Tudo deve ser feito de acordo com as regras, senhor..."

"Que regras são essas?" Lu Linyuan a interrompeu bruscamente.

— Sob o céu e sobre a terra, as minhas regras são as regras.

“......”

Ele olhou para os oficiais da corte reunidos, sua aura imperial subitamente desencadeada, emanando uma majestade inegável:

"Xiaoxiao e eu somos uma só, então fazê-la ajoelhar é o mesmo que me fazer ajoelhar."

— Quem aqui seria digno de receber uma reverência minha?

Ao ouvirem isso, todos os funcionários do tribunal responderam em uníssono: "Não nos atrevemos!"

Ele abriu as mangas, sua aura pulsando, sua voz profunda e solene:

— De hoje em diante, os decretos da imperatriz terão a mesma autoridade que os meus. Ver o selo da fênix será como ver o selo imperial. Todos deverão obedecer a essa determinação, sem exceções.

Todos ficaram surpresos quando essas palavras foram ditas.

A imperatriz-viúva elevou subitamente a voz em várias oitavas:

"Vossa Majestade, o que está fazendo...?"

"Hum?" A voz de Lu Linyuan se elevou ligeiramente no final enquanto ele se virava para encará-la com um olhar fulminante.

A força de sua presença esmagou a imperatriz-viúva; ela teve de engolir outra vez as palavras desagradáveis que estava prestes a despejar.

O Grande Secretário era um homem sensato; ele detinha o Selo da Fênix da Imperatriz, que sabia que precisava entregar a Ning Xiaoxiao.

Mas, já que Lu Linyuan já havia dito tudo isso, como ele ousaria fazer Ning Xiaoxiao se ajoelhar?

Ele, que estava de pé, ereto como uma vara, de repente ajoelhou-se diante de Ning Xiaoxiao sem aviso prévio, apresentando respeitosamente o selo da fênix com ambas as mãos acima da cabeça:

— Esta humilde autoridade solicita a Vossa Majestade que receba o selo da fênix.

Ao se ajoelhar, o secretário deixou em uma situação ainda mais difícil Zhu Zhenshan, pai da imperatriz deposta e comandante da Guarda Imperial.

Ele ficou ali parado, segurando o livro dourado, sentindo-se ressentido.

Hoje, ele havia planejado deixar cair o livro dourado no chão de propósito quando Ning Xiaoxiao se ajoelhasse para recebê-lo, fazendo-a se sentir envergonhada.

Como ele poderia se ajoelhar no chão e apresentar pessoalmente o livro de ouro da Imperatriz, que originalmente pertencia à sua filha, a Ning Xiaoxiao?

Isso não é uma afronta para ele?

"O que você está fazendo aí parado como uma estaca de madeira? Está mesmo pensando em como desobedecer ao decreto imperial?"

A voz fria de Lu Linyuan interrompeu a raiva impotente que se acumulava no peito de Zhu Zhenshan. Ele enrijeceu o pescoço, seus dentes amarelados e velhos quase se desfazendo em pó.

Ele fingiu estar pronto para lutar contra Lu Linyuan, mas depois admitiu a derrota e bateu os joelhos no chão.

O baque alto assustou Ning Xiaoxiao.

— Este humilde súdito não ousaria!

Ele, relutantemente, apresentou o livro de ouro com ambas as mãos, dizendo: "Por favor, Vossa Majestade, aceite este livro..."

Ning Xiaoxiao e Lu Linyuan trocaram um olhar. Ele sorriu e ergueu uma sobrancelha, olhando para o livro dourado e o selo da fênix, fazendo um sinal para que ela fosse buscá-los.

Ela segurava o livro dourado na mão esquerda e o selo da fênix na direita, só percebendo o quão pesados eram quando os segurou nas mãos...

Então ela os abraçou forte, dizendo: "Ai... eles são tão pesados..."

Talvez, porém, o verdadeiro peso não fosse o daqueles objetos, mas o amor puro e sincero de Lu Linyuan por ela.

(Feliz volta às aulas! Embora talvez não seja tão feliz assim... 【gritando isso bem alto】)

(Como muitos de vocês voltaram à escola e estão acumulando capítulos para ler depois, este livro voltará a ter duas atualizações por dia. Aproveito para adiantar o manuscrito do meu novo livro.)

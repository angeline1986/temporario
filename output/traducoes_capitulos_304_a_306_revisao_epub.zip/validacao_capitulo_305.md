# Validação do capítulo 305

- **Original:** `novel_capitulos_301_a_360(20261107-181903).docx` (chinês).
- **Base revista:** `novel capitulos 301 a 360 - ch.epub` (`index_split_004.html`).
- **Índices DOCX:** 302 a 385 (índices absolutos, base zero).
- **Unidades não vazias no DOCX:** 82 (título incluído).
- **Unidades em português:** 82 (título incluído).
- **Alinhamento:** uma unidade de saída para cada parágrafo não vazio do DOCX, na ordem e com índices preservados.

## Correções e pontos de atenção

- Corrigidos os agentes de fala e ação na cena de Sanfu/Ahuan e nos preparativos do casamento.
- Ajustados os utensílios do ritual nupcial, o vinho de união, falas e pensamentos de Ning Xiaoxiao.

- **Correções dirigidas:** 39 unidades da tradução-base reescritas manualmente, mais ajustes uniformes de nomenclatura e marcação.
- **Conferência estrutural:** contagem, índices absolutos, título, integridade de CSV, preservação das unidades finais e integridade do ZIP.

## Alcance e limites

**Revisão semântica focalizada e alinhamento estrutural**, não auditoria semântica independente de cada frase. Os parágrafos restantes derivados do EPUB não foram integralmente retraduzidos nem individualmente certificados contra erros sutis ou omissões internas. A correção de passagens-chave não garante a inexistência de falhas fora delas.

Capítulo 306 — A pílula da empatia compartilhada

Depois de um dia inteiro de cerimônias, só de pensar que Lu Linyuan ainda pretendia cansá-la mais, Ning Xiaoxiao sentiu vontade de desistir da vida.

Ela o interrompeu e começou a discutir o assunto com ele de forma séria:

"Depois das últimas três vezes, você me prometeu que seria mais contido e que faria isso apenas uma vez por dia daqui para frente. Embora hoje seja o nosso dia de casamento, você não pode quebrar a regra que estabeleceu para si mesmo. Afinal, você é um imperador; não pode voltar atrás na sua palavra, nem mesmo para a sua própria esposa, pode?"

— Da última vez, depois de três rodadas, você prometeu aprender a se controlar: no máximo uma vez por dia. Hoje é nosso casamento, mas não pode quebrar a regra que você mesmo estabeleceu. Você é o imperador! Não pode faltar com a palavra nem com a própria esposa, certo?

Naquele momento, o texto chinês traz literalmente «21», que parecia ansioso para começar. [Trecho possivelmente corrompido no original; o referente não está claro.]

Lu Linyuan conseguiu arrancar um pouco de ternura de seu ímpeto. Acariciou os cabelos desgrenhados dela e respondeu, com a voz rouca:

— O que Xiaoxiao disser está decidido.

O povo de Qichao não mente uns para os outros; eles dizem o que pensam sempre. Mas isso não durou muito...

Na dinastia Qi, palavra dada era palavra cumprida: uma vez seria uma vez. Mas ninguém havia dito quanto tempo essa vez duraria...

Aproveitando a brecha, Lu Linyuan controlou cuidadosamente o próprio ritmo, prolongando aquela única ocasião por uma hora inteira antes de, enfim, deixar os fogos de artifício explodirem.

"Desde que eu te contei da última vez que a Xiao Yinzi e as outras estavam com algodão nos ouvidos durante a vigília noturna, a voz da minha Xiao Xiao tem ficado cada vez mais alta."

— Desde que contei que Xiao Yinzi e os outros ficam de vigília com algodão nos ouvidos, a voz da minha Xiaoxiao anda cada vez mais alta.

Ele beijou as costas nuas da moça. — É uma delícia de ouvir.

Os dois discutiram por um tempo, e já passava da meia-noite.

Os dois trocaram provocações por algum tempo, até passar da meia-noite.

Lu Linyuan sentou-se abruptamente.

"Tsk tsk... De repente me lembrei de algo!"

"O que?"

Ele contou nos dedos em tom sério: "Amanhã começa sua menstruação, e ela sempre demora sete dias para voltar. Se continuar voltando, não vai passar de trinta vezes por mês para vinte e três? Como isso pode ser aceitável...?"

Contando nos dedos, ele anunciou solenemente: — Amanhã deve começar sua menstruação. Todo mês perdemos sete dias por causa disso. Das trinta vezes mensais, ficaremos reduzidos a vinte e três! Como pode ser?

— Sou o Filho do Céu. A palavra do soberano não pode ser desmentida! Se prometi trinta vezes, serão trinta vezes, nem uma a menos!

Ela pegou um travesseiro e atirou na cabeça não muito brilhante de Lu Linyuan.

"Você é tão bom em cálculos, deveria ser contador na sua próxima vida!"

"Contabilidade, certo?" Lu Linyuan repetiu as palavras dela, e o rio Huangpu, com seus 113 quilômetros de extensão, inundou instantaneamente sua mente. "Isso não pode ser feito às pressas. Quem tentar apressar as coisas não é homem de verdade."

— Contador, é? — Lu Linyuan repetiu, e um rio inteiro de pensamentos indecentes pareceu inundar sua cabeça. — Isso não pode ser rápido. Homem de verdade não termina depressa.

Lu Linyuan: "Não estou doente. Mas sou viciado em você."

Desta vez, ela ficou completamente sem palavras com as travessuras de Lu Linyuan!

Ele costumava ser um jovem tão bom e ambicioso, mas desde que começou a namorar comigo, sua mente está cheia de coisas confusas e fúteis.

Antes ele era um jovem tão esforçado! Como, desde que começara a namorá-la, só pensava nessas safadezas?

Será possível que meu marido tenha contraído alguma doença dela, considerando o comportamento dele hoje?

Será que seu marido tinha ficado assim... por influência dela?

O apelo da noite passada foi ineficaz, e Lu Linyuan teve pena dela, reduzindo a pena de sete para três dias, o que foi considerado como poupar a pobre criaturinha de metade da vida.

A reclamação da noite anterior não dera resultado. Lu Linyuan, em sua imensa generosidade, reduziu de sete para três — e Ning Xiaoxiao achou que pelo menos lhe restara meia vida.

Lu Linyuan agiu como se nada tivesse acontecido, preparou o café da manhã para ela com toda a atenção e depois foi ao tribunal.

Lu Linyuan, por sua vez, agia como se nada tivesse acontecido. Preparou-lhe o café da manhã com carinho e depois foi à audiência matinal da corte.

【Personagens de papel são mesmo incríveis... Têm energia de sobra a qualquer hora...】

Era o primeiro dia de Ning Xiaoxiao como imperatriz, e as consortes dos seis palácios deveriam ir ao Palácio Fengluan saudá-la ao meio-dia.

Ela planejava tirar um cochilo antes de se arrumar e, depois de cerca de uma hora, ouviu vagamente Xiao Qi chamando-a em sua mente:

Ela queria dormir mais um pouco antes de se arrumar. Cerca de uma hora depois, ouviu vagamente Xiao Qi chamá-la dentro da mente:

【Parabéns, anfitriã! Você concluiu a missão de se tornar imperatriz em menos de um mês!】

Ela ergueu as pálpebras pesadas. 【Da próxima vez, pode não aparecer de repente enquanto eu durmo?】

Xiao Qi: 【Está bem, anfitriã! Então vou embora~】

Ning Xiaoxiao: 【Esquece, você já me acordou mesmo!】

Xiao Qi sorriu: 【Bip, bip, bip! Missão concluída: índice de desvio da trama aumentado em 10 pontos percentuais; total acumulado de 65%. Como ultrapassou 60%, a anfitriã ganha uma chance de girar a grande roleta de recompensas!】

Ela já conhecia o procedimento.

Fechar os olhos, esperar a roleta aparecer e girá-la com toda a força.

Ning Xiaoxiao olhou para a recompensa: [Pílula da Empatia? Que diabos é isso?]

Ning Xiaoxiao espiou a recompensa. 【Pílula da Empatia Compartilhada? Que troço é esse?】

Xiao Qi: 【Hehe! Vou enviar a recompensa e as instruções para a anfitriã agora mesmo!】

Ela perguntou: "Por que tem um manual de instruções desta vez? É complicado?"

Ela perguntou: 【Por que desta vez veio com manual de instruções? É tão complicado assim?】

Xiao Qi: 【Antes eu explicava os efeitos das recompensas em voz alta, mas tinha receio de que você esquecesse depois de passar muito tempo sem usá-las. Por isso, daqui em diante enviarei também as instruções, para poder consultá-las quando quiser.】

【A "pílula da empatia" só é eficaz quando dada a alguém que se importa profundamente com você?】

【Pílula da Empatia Compartilhada: só funciona se for ingerida por alguém que se importe profundamente com quem a possui?】

【Se quem ingerir a pílula for sincero com seu portador, passará a sentir, no lugar dele, todos os desconfortos e dores que o portador experimentar pelo resto da vida.】

【Em contrapartida, se a pessoa que tomar a pílula não for sincera com o portador, será ele quem sentirá todos os desconfortos e dores que ela experimentar durante o resto da vida.】

【O efeito é permanente. Depois de ingerida, não há como desfazê-lo.】

【...】

【Mas que troço é esse?!】

【Aqui na dinastia Qi, quem realmente se importa comigo talvez sejam só Xiao Gu e A-Yuan. Eu daria isso a eles para carregarem minhas dores e desconfortos?】

【De jeito nenhum! Xiao Gu é uma chorona, e A-Yuan é o homem que eu amo. Não seria justo com nenhum dos dois...】

【E se alguém que não se importa comigo encontrar a pílula e tomá-la, vou ter que suportar todas as dores dessa pessoa até o fim da vida? Se Zhu ou a Consorte Duan a tomassem, seria como morrer junto com elas!】

Depois de reclamar consigo mesma por um bom tempo, concluiu que aquela coisa não parecia trazer nada de bom.

Também não se atrevia a jogá-la fora; se um rato ou um corvo a engolisse, estaria perdida.

Talvez fosse melhor deixá-la no depósito, juntando poeira...

Ela não percebeu, porém, que Lu Linyuan estivera parado do lado de fora da porta durante todo aquele tempo.

Ele achava que havia sido um pouco bruto demais na noite anterior e não sabia se machucara a esposa. Por isso, assim que terminou a audiência matinal, correu para confortá-la.

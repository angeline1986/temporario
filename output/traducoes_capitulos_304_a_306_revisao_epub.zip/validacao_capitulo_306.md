# Validação do capítulo 306

- **Original:** `novel_capitulos_301_a_360(20261107-181903).docx` (chinês).
- **Base revista:** `novel capitulos 301 a 360 - ch.epub` (`index_split_005.html`).
- **Índices DOCX:** 387 a 456 (índices absolutos, base zero).
- **Unidades não vazias no DOCX:** 68 (título incluído).
- **Unidades em português:** 68 (título incluído).
- **Alinhamento:** uma unidade de saída para cada parágrafo não vazio do DOCX, na ordem e com índices preservados.

## Correções e pontos de atenção

- Corrigidos o total de 65% de desvio da trama (+10 pontos), os gêneros, as condições da pílula e o uso de 【 】 para pensamentos/sistema.
- Há um provável trecho corrompido no original («21»), mantido e explicitamente sinalizado, sem adivinhar o referente.

- **Correções dirigidas:** 45 unidades da tradução-base reescritas manualmente, mais ajustes uniformes de nomenclatura e marcação.
- **Conferência estrutural:** contagem, índices absolutos, título, integridade de CSV, preservação das unidades finais e integridade do ZIP.

## Alcance e limites

**Revisão semântica focalizada e alinhamento estrutural**, não auditoria semântica independente de cada frase. Os parágrafos restantes derivados do EPUB não foram integralmente retraduzidos nem individualmente certificados contra erros sutis ou omissões internas. A correção de passagens-chave não garante a inexistência de falhas fora delas.

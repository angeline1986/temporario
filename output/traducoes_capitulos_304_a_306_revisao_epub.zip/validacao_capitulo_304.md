# Validação do capítulo 304

- **Original:** `novel_capitulos_301_a_360(20261107-181903).docx` (chinês).
- **Base revista:** `novel capitulos 301 a 360 - ch.epub` (`index_split_003.html`).
- **Índices DOCX:** 222 a 300 (índices absolutos, base zero).
- **Unidades não vazias no DOCX:** 77 (título incluído).
- **Unidades em português:** 77 (título incluído).
- **Alinhamento:** uma unidade de saída para cada parágrafo não vazio do DOCX, na ordem e com índices preservados.

## Correções e pontos de atenção

- Corrigido o texto de um decreto amoroso, os agentes da entrega dos emblemas imperiais, os tratamentos e a referência ao ritual de ajoelhar-se.
- Nota da autora preservada como parágrafo próprio.

- **Correções dirigidas:** 31 unidades da tradução-base reescritas manualmente, mais ajustes uniformes de nomenclatura e marcação.
- **Conferência estrutural:** contagem, índices absolutos, título, integridade de CSV, preservação das unidades finais e integridade do ZIP.

## Alcance e limites

**Revisão semântica focalizada e alinhamento estrutural**, não auditoria semântica independente de cada frase. Os parágrafos restantes derivados do EPUB não foram integralmente retraduzidos nem individualmente certificados contra erros sutis ou omissões internas. A correção de passagens-chave não garante a inexistência de falhas fora delas.

Capítulo 305 — A noite de núpcias

A música festiva continuava. Ning Xiaoxiao entregou a Qiqi o registro de ouro e o selo da fênix para que fossem guardados em uma caixa de brocado com motivos de fênix. Depois, de mãos dadas com Lu Linyuan, caminhou de cabeça erguida sobre o tapete dourado.

Diante do Palácio Chaoyang ficava o Salão do Trono; o tapete dourado seguia até o alto da plataforma cerimonial adornada com dragões e nuvens.

À luz do sol, os fios de ouro brilhavam em pequenas ondas, como se os dois caminhassem sobre um mar dourado.

O vestido de corte da imperatriz era adornado com muitas joias, o que o tornava pesado e desconfortável de usar.

Ning Xiaoxiao estava claramente com dificuldades para subir na plataforma de nuvens. Lu Linyuan parou e olhou para ela. "Quer que eu te carregue?"

"Não." Ela balançou a cabeça vigorosamente, como um chocalho, mas seu tom era incrivelmente sério:

"Quero caminhar passo a passo até estar ao seu lado."

Mais tarde, o imperador e a imperatriz chegaram de mãos dadas ao alto da plataforma, acima da multidão.

Dali era possível contemplar boa parte da cidade imperial.

Ao observar os inúmeros ministros e servos do palácio ajoelhados no pátio interno, no pátio externo, na longa rua e nos corredores, Ning Xiaoxiao sentiu-se como se estivesse flutuando em uma nuvem, e até mesmo as lajes de pedra azul sob seus pés se transformaram em nuvens macias.

— Prestamos nossas reverências a Sua Majestade, o imperador, e a Sua Majestade, a imperatriz!

— Que o imperador e a imperatriz vivam em harmonia e permaneçam unidos por cem anos!

As felicitações dos cortesãos caíram sobre ela como uma onda gigante, tão altas que assustaram Ning Xiaoxiao.

Felizmente, o homem ao lado dela segurou sua mão com firmeza o tempo todo, dando-lhe exatamente a segurança necessária.

Uma névoa densa cobria sua visão. Lu Linyuan se virou para olhá-la, seus dedos quentes enxugando as lágrimas que brotavam como pérolas. Incontáveis ternuras emanavam de seus olhos claros.

"Essa bênção não tem nada de especial, deixe-me acrescentar algo."

Ele curvou os lábios num sorriso travesso, inclinou-se e sussurrou no ouvido de Ning Xiaoxiao:

— Que venha logo um herdeiro! E que, em três anos, vocês já tenham dois!

— Vai abraçar a sua irmã...

"Ah?"

"Não é nada, não é nada..."

Assim, concluiu-se a cerimônia de nomeação da imperatriz.

Mas para Lu Linyuan, essas formalidades tediosas eram para o mundo todo ver.

Mas ele não pretendia tratar o próprio casamento com tamanha superficialidade.

Ning Xiaoxiao retornou ao Palácio Fengluan e tirou seu magnífico vestido de corte. Gu Sijin, Qiqi e os outros vieram alegremente recebê-la.

"Você acha que isso é tudo? Está longe de terminar!"

Ning Xiaoxiao viu Qiqi e as outras trazendo trajes nupciais de um vermelho intenso, como os usados em casamentos tradicionais chineses modernos, com coroa de fênix e manto bordado.

De repente, ela se lembrou de que, quando fez uma excursão de um dia ao mundo moderno com Lu Linyuan, ele viu um casal realizando um casamento tradicional chinês.

Na ocasião, ela comentara sem pensar muito: — Se um dia eu me casar, quero uma cerimônia assim. Acho o branco de mau agouro. Vestir um traje de noiva branco pode ser o sonho de outras meninas, mas não é o meu.

Ele se lembrava.

Ele se lembrara daquilo o tempo todo.

Por isso, mesmo depois de lhe dar o traje mais magnífico de uma imperatriz, quis realizar também aquele casamento que ela mencionara apenas de passagem.

Ela usava um manto vermelho, uma coroa de fênix e um véu de noiva.

Quando terminou de se arrumar, ouviu a agitação festiva do lado de fora.

"O noivo veio buscar a noiva!"

Sob o vermelho vivo do véu que cobria seu rosto, Ning Xiaoxiao deixou-se conduzir por Gu Sijin para fora do Palácio Fengluan. A amiga colocou sua mão em outra palma, tão familiar.

Seu rosto estava coberto por um véu, e apenas um vislumbre podia ser visto olhando para baixo.

Ao olhar para baixo, viu que as barras das calças de Lu Linyuan também eram vermelhas: ele havia vestido trajes nupciais vermelhos.

O ambiente era incrivelmente animado, e essa animação era genuína, repleta de alegria.

Ouviu a princesa mais velha e Huanu brincarem com a aparência de Lu Linyuan. Também ouviu Lu Yiqiu falar demais e ser prontamente ameaçado pelo tom frio de Ren Duanli.

Uma voz feminina soou ao lado de Sanfu; parecia ser Ahuan. Era Sanfu quem, com evidente orgulho, dizia que os trajes nupciais daquele dia tinham sido confeccionados por ela.

Qiqi e Bengbeng não conseguiram evitar dar as mãos quando ela não podia vê-los, ambos corando.

além do mais......

E havia Chu Xingran, que aproveitou a confusão para sussurrar ao ouvido de Gu Sijin: — No dia em que eu me casar com você, vai ser ainda mais animado.

A multidão aplaudiu e acompanhou o casal até a liteira nupcial. Após retornarem ao Palácio Chaoyang, os presentes os incentivaram a prestar suas homenagens ao céu e à terra.

Lu Linyuan estava excepcionalmente bem-humorado hoje, permitindo que fizessem alarde do começo ao fim sem proferir uma única palavra de recusa.

Só quando Lu Yiqiu, aquele pestinha sem noção, anunciou que pretendia fazer algazarra no quarto nupcial é que Lu Linyuan lhe deu um baita tapa.

"Se você ousar perturbar meu descanso e o da Imperatriz hoje, demolirei seu palácio amanhã e o enviarei para viver com Ren Duanli."

Lu Yiqiu acenou rapidamente com a mão: "Não vou causar problemas, não vou causar problemas!"

Após dizer isso, deu dois passos para trás e encostou-se à parede para cobrir as nádegas.

Mais tarde, eles beberam e jogaram jogos de bebida e de adivinhação com lanternas no salão principal, enquanto Lu Linyuan conduzia Ning Xiaoxiao, cujo rosto ainda estava coberto por um véu de noiva, de volta para os aposentos internos.

Depois que se sentaram na cama, entraram duas senhoras experientes, designadas pelo Ministério dos Ritos para conduzir os costumes nupciais.

Uma das senhoras segurou a haste dourada usada para erguer o véu e sorriu para Lu Linyuan:

— Majestade, por favor, erga o véu da imperatriz. Ao levantar-se o véu, que tudo transcorra com felicidade e boa sorte.

A mão de Lu Linyuan tremeu ligeiramente ao receber a haste. Uma apreensão inteiramente nova o tomou e o fez hesitar.

Com o véu de noiva levantado, sua Xiaoxiao tornou-se sua única esposa.

Ele estava com medo.

Mesmo sendo ele já o imperador, estando acima de todos os outros e sendo o homem no mundo mais capaz de protegê-la.

Ele ainda temia que sua filhinha sofresse até mesmo a menor mágoa se o seguisse.

Ele não estava com pressa, mas Ning Xiaoxiao estava extremamente ansiosa.

Após ter celebrado dois casamentos no mesmo dia, sua emoção inicial se transformou em uma avalanche de reclamações:

【Ei, meu caro, o que está esperando? Que eu engravide sozinha, por geração espontânea?】

【Levanta logo esse véu! Não comi nada o dia inteiro! Você quer me matar de fome e acabar assassinando a própria esposa?!】

Ela disse que sentia fome e sono, e bocejou sem ousar fazer nenhum barulho.

Nesse instante, Lu Linyuan ouviu-a reclamar e, preocupado que sua esposa estivesse com fome, rapidamente levantou o véu da noiva.

Então ele viu sua linda esposa, que parecia uma deusa, fazendo caretas e abrindo bem a boca como se quisesse engoli-lo inteiro.

“......”

Ao perceber que Lu Linyuan a vira naquela situação ridícula, Ning Xiaoxiao fechou a boca de supetão, interrompendo o bocejo. Engoliu o ar de uma vez e soltou um pequeno arroto.

— Hic~

"Pfft~"

Lu Linyuan não conseguiu conter o riso, achando sua esposa particularmente adorável hoje.

Uma das senhoras trouxe uma bandeja de prata com taças de vinho ornamentadas com dragões e fênix:

— Que Sua Majestade e a imperatriz bebam o vinho de união nupcial.

Os dois beberam o vinho juntos, de um só gole. Lu Linyuan queria dizer algo sentimental, mas Ning Xiaoxiao viu a casamenteira trazer uma tigela de sopa com muitos ingredientes.

Ela estava tão faminta que nem deu a Lu Linyuan a oportunidade de fazer declarações sentimentais. Agarrou a tigela e tomou a sopa de uma vez.

Depois, ainda estalou os lábios, satisfeita.

Lu Linyuan sorriu resignado e limpou os resíduos de sopa no canto da boca dela.

A senhora explicou, sorrindo: — Este é o Caldo das Bênçãos, preparado com tâmaras vermelhas, amendoim, longan e sementes de lótus triturados. Esses ingredientes simbolizam o desejo de ter filhos em breve! A imperatriz tomou tudo de um só gole; parece que deseja muito dar herdeiros ao imperador!

Aquelas palavras agradaram em cheio a Lu Linyuan. Ele lançou à senhora um olhar sorridente. — Já que sabe disso, por que ainda não saiu? Pretende assistir também?

Ning Xiaoxiao: “???”

A senhora recolheu rapidamente os utensílios e se retirou. Lu Linyuan então puxou Ning Xiaoxiao para a cama, disposto a começar o plano de ter filhos daquela noite.

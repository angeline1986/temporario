# Validação do capítulo 324

- **Original chinês:** `novel_capitulos_301_a_360(20261107-181903).docx`.
- **Tradução-base:** `novel capitulos 301 a 360 - ch.epub` (`index_split_023.html`).
- **Faixa de parágrafos DOCX (base zero):** 1818–1897, incluindo vazios; unidades efetivas: 1818–1896.
- **Unidades não vazias:** 77 no DOCX e 77 no EPUB; 77 no CSV, incluindo título, notas e divisórias.
- **Unidades com alterações textuais:** 31, incluindo normalização de nomes e correções dirigidas.

## Revisão e decisões editoriais

Lu mantém o verdadeiro destino (Chonghai) em segredo; Sanfu acompanha a comitiva-isca. Distância em li, e não milhas. A emboscada envolve bandidos montados, não criaturas com cabeças de cavalo; Ren atinge o cavalo do chefe e Lu protege a carruagem de Ning.

As correções relevantes foram cotejadas diretamente contra os trechos chineses correspondentes. Expressões de cultura e ironia foram adaptadas com cautela. O capítulo 324 foi conservado integralmente na ordem da fonte, inclusive as unidades sem alteração.

## Alcance e limitações

**Cotejo estrutural completo, revisão semântica focalizada.** As demais unidades foram herdadas do EPUB, às vezes com normalização terminológica. Não foi feita uma segunda tradução independente nem auditoria semântica exaustiva frase a frase; alinhamento 1:1 não demonstra inexistência de omissões internas nem de erros de nuance.

## Verificações

- Arquivos UTF-8, CSV com cabeçalho exato e índices absolutos do DOCX, sem duplicação e sem renumeração.
- Contagem e ordem das unidades mantidas; notas e divisórias não descartadas.
- Correspondência textual entre CSV e Markdown para cada capítulo.

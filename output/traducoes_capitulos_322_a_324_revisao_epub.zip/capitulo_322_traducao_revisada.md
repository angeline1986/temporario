# Capítulo 322 — Reunião geral dos casais

Originalmente, a morte da Consorte Duan deveria ter sido considerada um evento de grande repercussão.

Mas a morte da Consorte Nobre Viúva aconteceu no mesmo dia, e ninguém deu a menor atenção à Consorte Duan.

Lu Linyuan mandou enrolar o cadáver da Consorte Duan numa esteira de palha e devolvê-lo à família de origem. Ao saber que a filha cometera uma grave transgressão no palácio e acabara provocando a própria morte, o pai dela correu para a corte, ansioso por se isentar de qualquer responsabilidade.

Ele chorou copiosamente diante do imperador, protagonizando um espetáculo bastante dramático.

Ele afirmou francamente que sua família Liu era composta por homens leais e justos, e que se soubessem que a Consorte Duan tinha um coração tão perverso, certamente não a teriam deixado se desviar do caminho certo.

Ele fez questão de desvincular toda a família Liu dos atos da Consorte Duan, como se ela nem fosse sua filha biológica.

Na corte, o clã Liu levava uma existência medíocre: não tinha grandes feitos a ostentar, tampouco havia cometido erros particularmente graves.

A Consorte Duan já estava morta, e Lu Linyuan não pretendia perder tempo com aquele bando de inúteis.

Mas o próprio chefe da família Liu, sem um pingo de bom senso, insistiu em procurar Ning Xiaoxiao para se desculpar pessoalmente.

Teria sido melhor se eles não tivessem pedido desculpas; o pedido de desculpas só trouxe o problema à tona.

Diante de Ning Xiaoxiao, ele xingou a Consorte Duan até não poder mais e chegou a dizer que, se soubesse que a filha planejava prejudicar o herdeiro imperial no ventre dela, teria ele mesmo a espancado até a morte.

Ning Xiaoxiao não aguentou ouvir o restante. Disse que não guardava rancor pelo ocorrido e permitiu que Liu voltasse para casa.

Mal o homem havia saído, Ning Xiaoxiao já não conseguia disfarçar a repulsa no rosto.

Lu Linyuan sentiu imediatamente uma forte vontade de vomitar. Ele tomou um gole de chá para suprimir a sensação e perguntou:

"O que foi? Você está assim. Acha que fui muito leniente com a Consorte Duan?"

Ning Xiaoxiao balançou a cabeça, com um tom de voz carregado de desamparo:

"Será que esses funcionários da corte estão enviando suas filhas para o palácio com tanta pressa para usá-las como ferramentas em suas lutas políticas?"

“Tanto a Concubina Tong quanto a Consorte Duan cometeram incontáveis erros. Mas quantas das coisas que fizeram não foram pensando no bem da própria família?”

"Se nada der errado, você é um herói na família; se algo der errado, sua família materna vai te descartar como lixo."

“O quê? As filhas já nascem devendo alguma coisa à família? Vieram ao mundo só para pagar uma dívida?”

Como imperatriz, Ning Xiaoxiao não conseguia entender nem tolerar suas inúmeras maldades.

Mas, como mulher, também lamentava sinceramente o destino dessas vidas controladas por outros.

Quanto mais falava, mais furiosa ficava. Os médicos imperiais já haviam alertado que, durante o tratamento para proteger a gestação, ela não deveria se exaltar.

Bastava ficar irritada para a barriga começar a doer.

Só que quem sentia dor não era ela: era seu pobre e querido marido.

Lu Linyuan pressionou levemente a própria barriga e fixou os olhos no ventre de Ning Xiaoxiao, inspirando bruscamente de dor...

Se a esposa continuasse naquele estado, a vida dele e a do filho poderiam estar em perigo!

Então, imediatamente, ele convocou Sanfu e disse: "Vá encontrar Liu Zhi e diga-lhe que quero demiti-lo do cargo e investigá-lo. Além disso, seu filho, que recebe salário sem trabalhar, deve ser imediatamente preso e interrogado para averiguar se cometeu alguma irregularidade durante seu mandato."

Ning Xiaoxiao olhou para Lu Linyuan com uma expressão confusa, enquanto Lu Linyuan disse algo que pareceu bastante razoável:

"Se atrever a mexer com a minha mulher? Ele quer morrer!"

Ning Xiaoxiao achou graça do discurso sério e autoritário dele, típico de um CEO.

Após se acalmar, a dor abdominal de Lu Linyuan desapareceu imediatamente.

Ele se aproximou de Ning Xiaoxiao, sua grande mão acariciando suavemente a parte inferior do abdômen dela:

"Você também. Agora que você é mãe, está mais pesada, então não se irrite tão facilmente. Não é bom para você nem para o bebê."

Cof, cof... Também não faz muito bem para mim. Tome cuidado!

Ning Xiaoxiao colocou a mão sobre o dorso da mão dele e sorriu encantadoramente: "Meu filho não é tão delicado assim."

Ao pensar em como todas as dores, incômodos e calafrios que costumava sentir haviam desaparecido desde que engravidou, ela se sentiu cada vez mais feliz.

"É estranho, mas desde que tive esse filho, todos os pequenos problemas de saúde que costumavam me incomodar de vez em quando desapareceram sozinhos."

Ela fez uma pausa, olhou para a parte inferior do abdômen e disse em tom brincalhão, como se estivesse acalmando uma criança:

"Ter você é a minha bênção."

Lu Linyuan: “...”

Sua sorte é ter a mim, isso sim!

É claro que você não sente nada! Fui eu que assumi todos os sintomas que deveriam ser seus!

Onde no mundo você pode encontrar um homem como eu, disposto a suportar a dor do parto por sua mulher?

Devia era comemorar em segredo!

Embora continuasse murmurando esses pensamentos para si mesmo, seu olhar carinhoso nunca se desviou de sua pequena esposa.

“Estive pensando: os assuntos de Estado andam tranquilos e sua gravidez é motivo de alegria. Agora que a primavera chegou e as flores estão desabrochando, quero levá-la para passear e espairecer.”

"Você não gosta do mar? Que tal ir passar um tempo na praia?"

"Ótimo!" Ning Xiaoxiao nunca tinha visto o mar antes, então ficou naturalmente encantada. "Meu maior desejo é..."

Ao ver o olhar cheio de expectativa de Lu Linyuan, Ning Xiaoxiao ficou intrigada.

【Hum? Espere um minuto...】

【Ué? Acho que nunca contei a ele que gosto do mar... Como é que ele sabe?】

“Cof, cof.”

Lu Linyuan tossiu duas vezes, estrategicamente. Antes mesmo que Ning Xiaoxiao perguntasse, apressou-se a improvisar uma justificativa:

"Mas isso é só um palpite. Ouvi você murmurando algumas palavras sobre isso enquanto dormia, então mencionei casualmente. Se não gostar, pode ir para um lugar que preferir."

"Para onde quer que você vá, eu estarei com você."

Ning Xiaoxiao não era chamada de “bela cabeça-oca” à toa. Parecia ter trocado parte do cérebro por beleza: seu QI normalmente era 180, mas diante de Lu Linyuan virava 250 — número que, na gíria chinesa, também quer dizer “idiota”.

"Adorei! Mas vai ser um tédio na viagem se formos só nós dois..."

Ela olhou para baixo e bateu os dedos. "Então, acho que poderíamos... talvez pudéssemos..."

A hesitação e a gagueira dela deixaram Lu Linyuan ansioso.

"Se você quiser trazer Gu Sijin junto, basta dizer. Não finja ser gago na minha frente para tentar ganhar minha simpatia."

Ning Xiaoxiao riu e mostrou a língua, "Hehe, A-Yuan me entende melhor! Mua~"

Ela deu um beijo estalado na bochecha de Lu Linyuan, e ele, sorrindo, retribuiu com um peteleco carinhoso na testa dela.

"Vi que Gu Sijin optou por não deixar o palácio por enquanto para cuidar da sua gravidez."

"Desta vez, quando sairmos do palácio, Chu Xingran nos acompanhará como guarda-costas. O jovem casal sempre se sente desconfortável com as muitas restrições do palácio, então é uma espécie de realização para eles saírem do palácio conosco."

“E Yiqiu também. Ele anda abatido por causa da morte da Consorte Nobre Viúva, então vamos levá-lo. Só que é impossível controlar aquele pestinha. Melhor deixar Ren Duanli atrás dele para mantê-lo na linha.”

Ao imaginar aquela reunião geral de casais, Ning Xiaoxiao ficou radiante. “E a princesa mais velha e Huanu?”

“As duas?” Lu Linyuan sorriu, cheio de segundas intenções. “Elas têm outras coisas a resolver. Desta vez não vão se juntar à nossa diversão.”

(É feriado, compensarei o capítulo perdido amanhã~ Três capítulos amanhã~)

(Boas festas~~ amo vocês~)

# Capítulo 323 — Deixe a imperatriz-viúva “aproveitar a vida”

O dia da partida do palácio foi marcado para dois dias depois. Antes de partir, para evitar que o harém voltasse a mergulhar no caos, Ning Xiaoxiao precisava primeiro estabelecer regras para aquelas concubinas ingratas.

Quando as consortes se reuniram no Palácio Fengluan, todas recomendaram repetidas vezes que Ning Xiaoxiao se cuidasse durante a viagem e não deixasse acontecer nada ao herdeiro imperial.

Se tivessem ficado caladas, seria melhor. Do jeito que falavam, parecia até que estavam rogando uma praga.

Era como se desejassem que Ning Xiaoxiao sofresse um acidente fora do palácio, morrendo junto com o bebê que carregava.

Ning Xiaoxiao aceitou toda essa preocupação insincera.

“Recebi todos os bons votos de vocês. Antes de sair do palácio, também tenho algumas orientações a dar.”

"Depois que eu partir, a Consorte Li será a concubina de mais alta patente no harém, e todos os assuntos triviais deverão ser tratados por ela."

“Mas a Consorte Li está com a saúde frágil e os médicos imperiais recomendaram repouso. Não quero sobrecarregá-la.”

Dizendo isso, Ning Xiaoxiao empurrou Qiqi um passo à frente, atraindo todos os olhares.

“Por isso decidi que Qiqi, a servidora-chefe do Palácio Fengluan, cuidará dos assuntos grandes e pequenos do harém em meu lugar. Se precisarem de algo, falem com ela.”

As concubinas trocaram olhares e, após um breve silêncio, começaram a cochichar entre si:

“Sua Majestade quer colocar uma simples servidora do palácio como nossa superiora? Isso é contrário às regras!”

"Sim, as criadas do palácio são todas de nascimento humilde, enquanto nós somos descendentes de príncipes e nobres. Se essa inversão de classes se tornar pública, não nos tornaremos motivo de chacota?"

“Enquanto a imperatriz estiver fora, a imperatriz-viúva ainda poderá administrar o harém. Desde quando uma servidora pode assumir um papel que não lhe cabe?”

Ning Xiaoxiao já esperava as objeções delas e havia preparado sua resposta:

“O que eu disse foi que vocês podem encaminhar seus pedidos à Qiqi. Se precisarem de algo para os palácios ou quiserem se reunir para assistir a uma apresentação, ela fará os arranjos. Assim, não terão de perturbar o retiro da imperatriz-viúva.”

“Quanto à ideia de que Qiqi assumirá autoridade sobre vocês, isso simplesmente não existe.”

“Ela apenas registrará como vocês se comportam no palácio enquanto eu estiver fora.”

Enquanto falava, seu sorriso se alargou, e seu dedo mindinho, adornado com protetores de unha dourados, deslizou levemente sobre a mesa, produzindo um som sibilante arrepiante.

"Se vocês não forem obedientes, quando eu voltar ao palácio, castigarei os rebeldes com uma surra, e haverá muitas."

Ela disse essas palavras em tom de brincadeira, mas as concubinas que haviam testemunhado seus métodos implacáveis sabiam que ela era uma mulher de palavra.

Se alguém causar problemas enquanto ela estiver fora do palácio, ela provavelmente vai garantir que essa pessoa leve uma surra, literalmente.

Por exemplo, uma tábua de madeira de três polegadas de espessura, feita para ser engolida crua pela pessoa que cometeu o erro na frente de todos...

Ninguém ousou desobedecer, e todos concordaram em uníssono:

“Nós acataremos os ensinamentos de Sua Majestade, a imperatriz. Cumpriremos as regras e nossos deveres, sem causar problemas no harém.”

Ning Xiaoxiao assentiu, satisfeita. Em seguida, seus olhos pousaram sobre Zhu Xihua, quase despercebida no meio das demais.

“Dama Zhu, ontem passei perto do Palácio Yingquan e achei que o caminho de pedras estava muito gasto. As pedras ficaram lisas e alguém pode escorregar.”

"Temia que você caísse e morresse, por isso ordenei especialmente ao Departamento da Casa Imperial que renovasse as estradas ao redor do Palácio de Yingquan."

"A partir de amanhã, as estradas ao redor do Palácio Yingquan serão escavadas, o que pode dificultar suas viagens. Portanto, prepare mais comida em seu palácio e tome cuidado para não morrer de fome."

Ning Xiaoxiao planeja mandar escavar todas as ruas ao redor do Palácio Yingquan, transformando-o em uma ilha isolada dentro do palácio, onde as pessoas não poderão entrar nem sair.

Ela sabia que era improvável que Zhu Xihua se comportasse bem, então usou esse método para confiná-la em seu próprio território, impedindo-a assim de causar mais problemas.

Agora Zhu Xihua não passava de uma humilde Dama. Como ousaria contrariar uma ordem da imperatriz?

Então, ela só pôde cerrar os dentes e concordar: "Esta concubina agradece a Vossa Majestade pela sua preocupação."

Ning Xiaoxiao sorriu: "De nada. Você cuidou bem de mim no passado, então é justo que eu cuide de você agora."

*

Entretanto, no Gabinete Imperial.

Qingyang estava sentada diante de Lu Linyuan. Segurando delicadamente uma taça de vinho entre os dedos, tomou um gole e sorriu:

“Então quer que eu aproveite sua ausência para expulsar todas aquelas mulheres do harém?”

Lu Linyuan ergueu seu copo para brindar com ela: "Só você, irmã mais velha, pode fazer isso para que Xiaoxiao não se sinta culpada."

"Como você pôde sequer pensar nisso?" Qingyang zombou.

“Assim que saírem do palácio, você espalhará o boato de que, em Chonghai, a imperatriz apresentou sinais preocupantes na gravidez e de que o herdeiro corre perigo. Depois pedirá ao Observatório Imperial que invoque os astros, alegando que os presságios das outras consortes entram em conflito com os da imperatriz. Aí entro eu e disperso o harém por você.”

“O plano é absurdo, mas funcionará. Afinal, ao usar o herdeiro imperial como justificativa, qualquer pessoa que se opuser parecerá ameaçar a continuidade da dinastia — um crime gravíssimo. Ninguém vai querer carregar essa culpa por causa de um título que nem tem substância.”

Lu Linyuan sorriu: "A irmã mais velha é perspicaz."

Qingyang se recostou na cadeira. “Qualquer mulher ficaria comovida até as lágrimas se o marido fizesse uma coisa dessas por ela. Mas você é diferente: faz tudo isso e ainda pretende esconder da imperatriz? Não consigo entender.”

Lu Linyuan respondeu: “Se eu intervier pessoalmente, haverá turbulência na corte, e Xiaoxiao certamente se culpará. Não se deixe enganar pelo jeito despreocupado dela, irmã mais velha: por dentro, ela carrega mais preocupações que qualquer um. Não quero que meu amor se transforme em correntes nem que ela sinta que me deve alguma coisa.”

"Entendo. Você não quer que sua esposa se sinta culpada, nem quer que ela se torne alvo de críticas públicas. Então você quer me jogar, sua irmã mais velha, no meio da confusão, é isso?"

Qingyang pegou um memorial e o atirou, brincando, na direção de Lu Linyuan. “Seu moleque, que belo tratamento dá à irmã mais velha! Mas Xiaoxiao é esperta e adorável, e eu também gosto dela. Se preciso virar alvo das críticas por ela, viro com prazer.”

Gosta dela?

Da minha esposa você não pode gostar!

Ele estava prestes a dizer algo para interromper o discurso desconexo de Qingyang quando ela se antecipou e continuou:

“Mas vou avisando: se eu fizer isso por você, sua mãe certamente tentará me impedir. Sabe muito bem que nós duas não nos suportamos. Se eu deixar sua mãe tão furiosa que ela fique doente, não venha me cobrar explicações.”

Para lhe causar problemas?

Se Qingyang conseguisse irritar a imperatriz-viúva até deixá-la doente, Lu Linyuan provavelmente soltaria fogos e bateria tambores para comemorar...

Mas ele ainda lhe deu um conselho:

“Minha mãe e eu discordamos em muitas coisas, mas ela ainda é minha mãe. Tome um pouco de cuidado, irmã mais velha. Se ela adoecer, os médicos imperiais podem tratá-la; mas, se morrer de raiva, aí não será bom.”

Afinal, ele ainda precisava manter a imperatriz-viúva viva para que ela pudesse “aproveitar a vida” como ele planejava.

Se Qingyang a matasse de raiva, onde estaria a diversão dele?

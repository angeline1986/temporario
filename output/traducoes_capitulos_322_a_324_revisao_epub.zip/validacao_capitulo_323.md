# Validação do capítulo 323

- **Original chinês:** `novel_capitulos_301_a_360(20261107-181903).docx`.
- **Tradução-base:** `novel capitulos 301 a 360 - ch.epub` (`index_split_022.html`).
- **Faixa de parágrafos DOCX (base zero):** 1757–1817, incluindo vazios; unidades efetivas: 1757–1816.
- **Unidades não vazias:** 58 no DOCX e 58 no EPUB; 58 no CSV, incluindo título, notas e divisórias.
- **Unidades com alterações textuais:** 32, incluindo normalização de nomes e correções dirigidas.

## Revisão e decisões editoriais

A Consorte Li continua com o posto de consorte; Zhu Xihua é Dama Zhu (答應). Ning nomeia Qiqi para registrar a conduta das consortes, enquanto Lu planeja com Qingyang a dispersão do harém. Corrigidos o agente do plano, o elogio à irmã e a ironia sobre a imperatriz-viúva.

As correções relevantes foram cotejadas diretamente contra os trechos chineses correspondentes. Expressões de cultura e ironia foram adaptadas com cautela. O capítulo 323 foi conservado integralmente na ordem da fonte, inclusive as unidades sem alteração.

## Alcance e limitações

**Cotejo estrutural completo, revisão semântica focalizada.** As demais unidades foram herdadas do EPUB, às vezes com normalização terminológica. Não foi feita uma segunda tradução independente nem auditoria semântica exaustiva frase a frase; alinhamento 1:1 não demonstra inexistência de omissões internas nem de erros de nuance.

## Verificações

- Arquivos UTF-8, CSV com cabeçalho exato e índices absolutos do DOCX, sem duplicação e sem renumeração.
- Contagem e ordem das unidades mantidas; notas e divisórias não descartadas.
- Correspondência textual entre CSV e Markdown para cada capítulo.

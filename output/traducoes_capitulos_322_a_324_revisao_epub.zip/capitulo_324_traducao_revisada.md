# Capítulo 324 — Bandidos ferozes bloqueiam a estrada

Essa viagem tinha como objetivo principal levar Ning Xiaoxiao para ver o mar, mas Lu Linyuan também tinha seus próprios motivos egoístas.

Chonghai está sob a jurisdição de Zhu Zhenshan.

Desde que Lu Linyuan ascendeu ao trono, Chonghai tem relatado consistentemente que o povo vive em paz e prosperidade, deixando suas portas destrancadas à noite, e que a prosperidade da cidade rivaliza com a de uma pequena capital.

Além disso, Chonghai era a região que mais recolhia tributos locais todos os anos. À primeira vista, tudo parecia estar em ordem.

Mas se algo é perfeito demais, deve haver algo de suspeito.

Nos últimos cinco anos, Chonghai nunca registrou nenhuma notícia ruim. Todos os anos foram de colheitas abundantes e, mesmo em anos de desastre, a região permaneceu completamente ilesa.

Com o tempo, Lu Linyuan começou a duvidar da autenticidade do memorial que lhe foi apresentado.

Ele já havia enviado discretamente outros ministros para investigar a região, mas os relatos recebidos confirmavam o cenário de prosperidade descrito nos memoriais.

Então ele decidiu ir ver com os próprios olhos.

Mas a premissa é que o destino desta viagem deve ser mantido em segredo de todos.

Por isso, anunciou aos ministros na corte:

“Nesta viagem, a imperatriz e eu pretendemos apreciar as paisagens ao longo do sul do rio. Ficaremos fora por cerca de um mês. Durante esse período, a princesa mais velha ficará responsável pelos assuntos de Estado.”

Os funcionários do tribunal tinham muitas reservas quanto à possibilidade de mulheres deterem o poder.

Mas como Lu Linyuan já havia emitido o decreto imperial, eles não podiam dizer mais nada na cara dele.

Quando a comitiva imperial partiu, Sanfu conduziu o grosso do séquito para a região ao sul do rio. Na liteira imperial viajavam um jovem eunuco e uma jovem servidora disfarçados de imperador e imperatriz, numa encenação destinada a despistar os observadores.

Lu Linyuan e seu grupo viajaram com pouca bagagem para Chonghai, sem levar muitas pessoas para servi-los.

*

A cidade de Chonghai está localizada na costa do Mar da China Oriental e é a maior cidade costeira da Dinastia Qi.

A cidade ficava a cerca de mil li da capital, e a jornada levaria aproximadamente quatro ou cinco dias.

No entanto, agora é início de verão, a época perfeita para apreciar a paisagem. A paisagem ao longo do caminho também é muito agradável, então você não se sentirá entediado durante a viagem.

No caminho para cá, Lu Linyuan e Ning Xiaoxiao estavam na mesma carruagem. Entediados, começaram a jogar Gomoku (Cinco em Linha).

No entanto, desta vez, o progresso de Ning Xiaoxiao foi muito evidente, e ela já conseguiu empatar com Lu Linyuan.

Em segredo, ela havia encontrado em seu espaço de armazenamento um manual de estratégias de cinco-em-linha. Passara a noite anterior à partida estudando-o para finalmente vencer Lu Linyuan e recuperar o orgulho.

Mas como é que esse tolinho poderia ganhar?

Lu Linyuan conseguia ouvir claramente os pensamentos dela a cada passo que dava e onde ela iria pousar em seguida.

Teoricamente falando, mesmo que Ning Xiaoxiao treinasse para se tornar uma campeã nacional, ela ainda não seria páreo para Lu Linyuan.

Mas você precisa mimar sua própria esposa e admitir a derrota quando chegar a hora de fazê-lo.

Se perder uma partida fizesse a esposa pular de alegria, abraçá-lo e beijá-lo, por que não perder?

"Um golpe decisivo!"

Ning Xiaoxiao fez um movimento decisivo, batendo palmas animadamente: "Desta vez eu não trapaceei! A-Yuan, você perdeu!"

Lu Linyuan fingiu frustração, deixou os ombros caírem e suspirou: "Tudo bem... Eu perdi. Castigue-me como quiser!"

Depois de dizer isso, ele se esparramou no assento macio, com um toque de expectativa nos olhos, esperando que sua esposa o 'castigasse'.

Ning Xiaoxiao se virou e deitou-se sobre ele, tocando levemente a ponta do nariz dele com o dedo indicador, e sorriu:

“Acha que sou boba? Isso é castigo ou recompensa?”

Mas agora era tarde demais para escapar, pois ela já estava presa a ele.

Lu Linyuan enlaçou delicadamente a cintura dela, roçou o nariz em seu pescoço e começou a fazer manha, apesar do jeitão de machão:

"Não me importo, estou de mau humor porque perdi o jogo, preciso de um beijo da minha esposa~"

“yue...”

Ning Xiaoxiao soltou uma ânsia de vômito sem a menor cerimônia. Lu Linyuan franziu a testa: “Está com nojo de mim?”

Ning Xiaoxiao: "Não, não, como eu poderia não gostar de você? Estou grávida, sabia? É só enjoo matinal normal..."

Lu Linyuan: “???”

Você sofre de enjoos matinais?

Está achando que sou algum trouxa para cair nessa mentira?!

Ele acariciou suavemente a testa de Ning Xiaoxiao e disse com um sorriso travesso:

"Xiaoxiao não está se sentindo bem, então, como marido dela, naturalmente tenho que confortá-la."

Após dizer isso, seus lábios quentes e úmidos pressionaram os dela.

De qualquer forma, ela não vai escapar desse beijo hoje!

Enquanto os dois trocavam carinhos, a carruagem sofreu um solavanco repentino e sacudiu violentamente.

Se Lu Linyuan não tivesse reagido rapidamente e segurado Ning Xiaoxiao, ela teria sido jogada ao chão.

Lu Linyuan ficou furioso. Depois de ajudar Ning Xiaoxiao a se acomodar, já ia repreender os responsáveis quando ouviu cascos de cavalos e gritos ameaçadores vindo de todos os lados.

Ao erguer a cortina da carruagem, viu um grande grupo de bandidos montados convergindo em sua direção.

Havia uns trinta ou quarenta homens, de barbas cerradas e rostos cobertos, todos com aparência feroz e armados até os dentes.

Como viajavam incógnitos, não eram acompanhados por um grande número de Guardas Tigre. O grupo de seis mestres estava acompanhado apenas por seis servos do palácio.

Nenhum dos servidores sabia lutar. Os únicos com habilidades marciais eram Lu Linyuan, Ren Duanli e Chu Xingran, os três homens que lutavam lado a lado.

Os bandidos rapidamente os cercaram, rodeando o grupo de cerca de dez pessoas.

Ren Duanli e Chu Xingran já haviam descido de suas liteiras e estavam de guarda ao lado da carruagem de Lu Linyuan, com suas espadas desembainhadas.

O chefe dos bandidos montados ergueu o facão e ameaçou, com voz grave:

“Deixem o dinheiro e pouparemos suas vidas!”

Ren Duanli o encarou com frieza: “Vocês tiveram a ousadia de tentar me assaltar?”

Mal terminou de falar, Ren Duanli golpeou com a espada e cortou o pescoço do cavalo montado pelo chefe dos bandidos.

O cavalo disparou, assustado. O bandido saltou da sela, deu uma cambalhota para trás e aterrissou firme no chão.

Embora fossem um tanto habilidosos, não eram páreo para Lu Linyuan e seus dois irmãos.

Já Ning Xiaoxiao, Gu Sijin e Lu Yiqiu eram três completos desastres em combate.

Além de não saberem lutar, ainda precisavam de proteção, distraindo os companheiros.

Durante o confronto, quando percebeu que seus homens não conseguiam superar os três lutadores, o líder dos bandidos gritou:

“Tem mulheres nas carruagens! Peguem-nas primeiro!”

A emboscada aqui não consistia apenas de espadachins montados, mas também de arqueiros no topo da colina não muito distante.

Os arqueiros estavam prontos para atirar, e eram muitos.

Chu Xingran percebeu imediatamente que algo estava errado e gritou:

"Cuidado! Há emboscadas na floresta!"

Mal ele terminou de falar, uma chuva de flechas despencou sobre o grupo.

Os três homens brandiam suas espadas, desferindo golpes e aparando-os da esquerda e da direita, mas, embora fossem mestres incomparáveis, não conseguiram resistir a um ataque de pinça como aquele.

A carruagem de Lu Linyuan e Ning Xiaoxiao era a mais luxuosa. Pelas roupas dele, também se percebia que não era um homem qualquer.

Ao perceberem a situação, os bandidos mudaram imediatamente de estratégia e toda a sua cavalaria e arqueiros atacaram Lu Linyuan.

Uma flecha estava prestes a atingir o interior da carruagem, e já não havia tempo de desviá-la com a espada.

Sem hesitar, Lu Linyuan avançou instintivamente, usando as costas para proteger a liteira, tudo para resguardar sua amada de qualquer mal.

# Validação do capítulo 322

- **Original chinês:** `novel_capitulos_301_a_360(20261107-181903).docx`.
- **Tradução-base:** `novel capitulos 301 a 360 - ch.epub` (`index_split_021.html`).
- **Faixa de parágrafos DOCX (base zero):** 1683–1756, incluindo vazios; unidades efetivas: 1683–1755.
- **Unidades não vazias:** 71 no DOCX e 71 no EPUB; 71 no CSV, incluindo título, notas e divisórias.
- **Unidades com alterações textuais:** 34, incluindo normalização de nomes e correções dirigidas.

## Revisão e decisões editoriais

A morte da Consorte Nobre Viúva eclipsa a morte da Consorte Duan; o corpo devolvido à família é o de Duan, não o do imperador. Lu Linyuan assume as dores de Ning, inclusive durante a gestação. Nome e gênero da princesa mais velha e Huanu preservados. Mantidas as duas notas da autora.

As correções relevantes foram cotejadas diretamente contra os trechos chineses correspondentes. Expressões de cultura e ironia foram adaptadas com cautela. O capítulo 322 foi conservado integralmente na ordem da fonte, inclusive as unidades sem alteração.

## Alcance e limitações

**Cotejo estrutural completo, revisão semântica focalizada.** As demais unidades foram herdadas do EPUB, às vezes com normalização terminológica. Não foi feita uma segunda tradução independente nem auditoria semântica exaustiva frase a frase; alinhamento 1:1 não demonstra inexistência de omissões internas nem de erros de nuance.

## Verificações

- Arquivos UTF-8, CSV com cabeçalho exato e índices absolutos do DOCX, sem duplicação e sem renumeração.
- Contagem e ordem das unidades mantidas; notas e divisórias não descartadas.
- Correspondência textual entre CSV e Markdown para cada capítulo.

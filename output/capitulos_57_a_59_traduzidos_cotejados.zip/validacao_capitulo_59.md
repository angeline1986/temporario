# Validação — capítulo 59

- **Original principal:** `novel_capitulos_1_a_60(20261103-183111).docx` (chinês tradicional).
- **Trecho do DOCX:** parágrafos 4418–4492, finalizado antes do capítulo 60.
- **Unidades originais não vazias (título incluído):** 72.
- **Linhas de cotejo CSV:** 72.
- **Traduções vazias / unidades omitidas no cotejo / unidades extras:** 0.
- **Método:** transcrição e tradução associadas ao índice de cada parágrafo do documento original; checagem programática de cobertura 1:1 e presença de tradução.
- **Pontos de continuidade e escolhas editoriais:** As suspeitas sexuais sarcásticas de Ning e o contraste com os gestos carinhosos de Lu são preservados. Sanfu encontra Ning sentada no trono lendo memoriais. O título mantém a alusão ao “bastão de ferro” presente no chinês. A água de rios na metáfora é mantida sem tentar racionalizá-la.
- **Ressalva:** a correspondência 1:1 só comprova a cobertura estrutural. Não prova fidelidade semântica absoluta. Houve revisão durante a redação, mas não segunda auditoria linguística independente.

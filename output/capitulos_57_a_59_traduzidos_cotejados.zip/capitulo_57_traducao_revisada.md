# Capítulo 57 — Ela é a imperatriz da dinastia Qi, não a minha

De volta ao palácio, Ning Xiaoxiao despejou uma quantidade absurda de pó cicatrizante no ferimento do dedo. Enquanto espalhava o remédio, resmungava:

— Ah, não quer que eu use, é? Pois vou usar, sim! Vou gastar tudinho! Quero ver você morrer de raiva, seu azarado!

Quando terminou, ouviu a voz de Gu Sijin vindo do pátio.

— Qiqi, vá até o Portão Yuxiu dar uma olhada. Cailian já deveria ter cumprido o tempo de castigo ajoelhada. Por que ainda não voltou?

Depois, ordenou a Qiaqia: — Prepare um chá de gengibre com tâmaras-vermelhas. Quando Cailian voltar, faça-a beber para se aquecer.

No fundo, Gu Sijin se preocupava com Cailian. Afinal, era uma criada que crescera ao lado dela desde pequena; se a moça adoecesse ou se machucasse, Gu Sijin também sofreria.

Qiqi mal chegou à porta quando viu Cailian voltar, de cabeça baixa e ensopada feito um pinto molhado.

Tirou o próprio lenço e, enquanto enxugava o rosto de Cailian, conduziu-a para dentro. — Minha senhora, Cailian voltou!

Ao vê-la molhada dos pés à cabeça, Gu Sijin deixou escapar um lampejo de pena no olhar.

— Levem-na primeiro ao meu quarto. E tragam roupas secas para ela trocar.

Assim que entrou no quarto com Gu Sijin, Cailian caiu de joelhos diante dela. — Senhorita, eu sei que errei! Buááá!

Chorava tão desconsoladamente que, mesmo quando Gu Sijin tentou ajudá-la a se levantar, ela se recusou.

— A senhorita fez muito bem em me castigar! Eu não devia ter roubado as coisas da Xiaoxiao, muito menos respondido à senhorita. Se me castigou, foi pensando no meu bem. Já é tão difícil para nós duas sobreviver neste palácio, com tantos olhos nos vigiando! Em vez de ajudar a senhorita, só causo problemas. Eu... eu nem tenho coragem de olhar na sua cara!

Cada palavra parecia vir do fundo do coração; Cailian demonstrava arrependimento sincero diante de Gu Sijin.

O coração de Gu Sijin se enterneceu imediatamente. Ela abraçou a criada e começou a chorar junto com ela.

— O importante é que você entendeu onde errou. Eu também não queria castigá-la. Mas, se não fosse eu a puni-la hoje, amanhã seria outra pessoa. Neste palácio, ofender alguém pode acabar muito mal. Espero que não me culpe. Ver você sofrer me dói mais do que a qualquer outra pessoa.

Senhora e criada se abraçaram apertado e choraram copiosamente.

Cailian também prometeu a Gu Sijin que, dali em diante, seguiria as regras à risca e nunca mais agiria de maneira imprudente.

Só depois que ela trocou de roupa e tomou o chá de gengibre Gu Sijin disse: — A pulseira da Xiaoxiao foi um presente da mãe dela. Tem um significado especial. E foi por sua culpa que acabou quebrada. Você precisa ir até ela e lhe pedir desculpas como se deve.

— Eu sei, senhorita. Já estava pensando em pedir desculpas à Xiaoxiao. Se ela me culpar, não vou reclamar. Só posso tratá-la bem em tudo daqui para a frente, até que, aos poucos, deixe de guardar rancor de mim.

Quando Cailian foi procurar Ning Xiaoxiao, encontrou-a no pátio podando os galhos das flores.

— Xiaoxiao, me desculpe. Eu não devia ter roubado sua pulseira.

— No começo, achei bonita e só queria usá-la um pouquinho. Ia devolver assim que voltasse. Não imaginei que a Consorte Nobre fosse tomá-la à força...

Enquanto falava, Cailian mordia o lábio e parecia prestes a chorar, numa imagem de dar pena.

Ning Xiaoxiao lançou-lhe um olhar de lado. — Você é uma sacola plástica boiando no lago Dongting? Porque, além de falsa que nem chá-verde, é cheia de pose e fingimento.

— Como você sabe que minha cidade natal fica às margens do lago Dongting? — perguntou Cailian.

Ning Xiaoxiao: Gente, eu simplesmente não tenho palavras...

— Não me importa se você nasceu perto do lago Dongting ou do rio Huangpu. Só vou dizer uma coisa: quem faz maldades acaba pagando. Se quer continuar seguindo por esse caminho sem volta, fique à vontade.

— Xiaoxiao, do que você está falando? Não estou entendendo... Eu me arrependi de verdade...

— Você se arrependeu mesmo? — Ning Xiaoxiao interrompeu-a e avançou passo a passo, até erguer a tesoura que segurava e encostar a ponta no peito dela.

Assustada, Cailian recuou repetidas vezes. — Xiaoxiao... V-você não faça nenhuma loucura! Eu...

Ning Xiaoxiao soltou uma risada fria. — Sei perfeitamente o que você está pensando. Pode enganar sua senhora com esses truques, mas não engana os céus. E, mesmo que engane os céus, não me engana. Aconselho que se comporte e pare de cavar a própria sepultura.

Em seguida, colocou a tesoura nas mãos de Cailian e voltou para seu quarto.

Cailian acompanhou-a com o olhar. A expressão digna de pena desapareceu num instante, dando lugar a um rosto contorcido de ódio.

Apertou a tesoura com toda a força e murmurou entre os dentes: — Sua desgraçada! Quero ver por quanto tempo ainda vai poder se achar tão importante!

Ning Xiaoxiao sabia que Cailian já havia passado para o lado sombrio.

Na história original, a transformação de Cailian acontecia justamente porque Gu Sijin a obrigara a se ajoelhar debaixo de chuva, e a Consorte Nobre mandara alguém protegê-la com um guarda-chuva.

Cailian ficara grata e passara a achar que a Consorte Nobre a tratava melhor do que a própria Gu Sijin.

A Consorte Nobre aproveitara para conquistá-la: — Você é bonita, afinal. Só lhe falta uma família influente. Sua senhora está no auge da popularidade; mas o que você vai ganhar seguindo-a? Na melhor das hipóteses, um dia vão casá-la com um criado qualquer, e será isso o resto da sua vida. Se, porém, vier para o meu lado, garanto que também poderá receber o título de concubina imperial, quem sabe até de consorte.

Bastara essa promessa da Consorte Nobre para fazer florescer a semente demoníaca que Cailian guardava no coração havia tantos anos.

Ela nunca se conformara em ser apenas uma criada. Se Gu Sijin não tinha consideração por ela, que não a culpasse por retribuir na mesma moeda.

A partir de então, Cailian se aliara à Consorte Nobre e começara a conspirar com ela, agindo por dentro e por fora para prejudicar Gu Sijin.

Esse trecho era um dos pontos altos da história original: graças a ele, Gu Sijin descobria a crueldade do mundo e, aos poucos, deixava de ser uma coelhinha inocente para se tornar uma temível senhora do harém, capaz de matar sem hesitação.

Por isso, mesmo sabendo o que aconteceria no futuro, Ning Xiaoxiao não advertiu Gu Sijin.

Afinal, não era uma parte do enredo que o sistema lhe tivesse mandado desviar.

---

No dia seguinte, depois da audiência matinal, Lu Linyuan foi apresentar seus respeitos à imperatriz-viúva.

Ela lhe perguntou: — Imperador, está tudo pronto para a visita aos túmulos imperiais e o culto aos ancestrais amanhã?

Todos os anos, no primeiro dia do nono mês, Lu Linyuan saía do palácio com a imperatriz-viúva para prestar homenagens nos mausoléus dos antepassados e rogar por paz, prosperidade e boas colheitas para o reino.

— Está tudo preparado. Podemos partir amanhã cedo — respondeu ele.

A imperatriz-viúva assentiu. — A viagem de ida e volta leva dois dias. Convém que o imperador leve alguém de sua preferência para servi-lo. Que tal levar a imperatriz?

Sem pensar duas vezes, Lu Linyuan recusou: — Ultimamente, ela vem sofrendo crises frequentes de dor de cabeça. Não é aconselhável viajar tão longe.

— Ah, é? Pensei que o imperador nem soubesse dessas crises — retrucou a imperatriz-viúva, com ironia. — Se sabe, por que nunca foi visitá-la?

Lu Linyuan respondeu com frieza: — Se ela está doente, que procure um médico imperial. Minha visita vai curar a dor de cabeça dela? Se curar, é porque estava fingindo. Se não curar, para que tanto drama sobre eu ir ou não vê-la?

A imperatriz-viúva se irritou. — Seja como for, ela é a imperatriz! Sua esposa legítima! Não deveria demonstrar um pouco de consideração?

— Ela é a imperatriz da dinastia Qi escolhida pela senhora, minha mãe. Não é *minha* imperatriz. Em vez de gastar seu tempo discutindo comigo, seria melhor chamar um bom médico imperial para tratar da doença dela.

Dito isso, Lu Linyuan foi embora a passos largos, deixando a imperatriz-viúva para trás, quase morta de raiva.

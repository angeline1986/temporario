# Capítulo 58 — Aquilo que você mais preza, eu protegerei por você

Na manhã seguinte, o cortejo imperial deixou o palácio, levando o imperador e a imperatriz-viúva para prestar homenagens aos ancestrais nos mausoléus.

Quando chegaram, já era tarde. Ao término das cerimônias, o céu começava a escurecer.

Como de costume, Lu Linyuan e a imperatriz-viúva passariam a noite no Templo do Buda de Jade, perto dos mausoléus, e partiriam de volta ao palácio na manhã seguinte.

Ao lado do templo havia uma cidadezinha chamada Yanxi, famosa por suas pedras de jade. Comerciantes de joias de toda a região iam até lá abastecer seus estoques. Mesmo à noite, as lojas ficavam iluminadas, cheias de clientes, e as ruas fervilhavam de animação.

Sanfu estava prestes a ajudar Lu Linyuan a se lavar e a se preparar para dormir quando o imperador teve uma ideia repentina: — Estou sem sono. Venha comigo dar uma volta por Yanxi.

— Mas... Majestade, de onde surgiu essa vontade? Já está tarde, e amanhã cedo teremos de pegar a estrada. Não seria melhor...

Antes que Sanfu terminasse, Lu Linyuan já havia saído pela porta.

O eunuco suspirou, resignado, e correu atrás dele.

Yanxi não ficava longe do Templo do Buda de Jade: eram cerca de quinze minutos a pé.

Era a primeira visita de Lu Linyuan àquele lugar. À noite, a cidadezinha era tão movimentada quanto a capital durante o dia. Os comerciantes anunciavam suas mercadorias com entusiasmo, ansiosos para mostrar aos clientes seus jades e joias.

Lu Linyuan entrou numa loja qualquer e pediu ao proprietário que trouxesse todas as joias de jadeíta que tivesse.

O homem apresentou as peças sem parar de falar, mas, depois de examiná-las uma a uma, Lu Linyuan não gostou de nenhuma.

Sanfu se aproximou de seu ouvido e murmurou: — Majestade, como as coisas vendidas fora do palácio poderiam se comparar às do tesouro imperial? O senhor está acostumado a peças magníficas. Como haveria de gostar dessas bugigangas?

Lu Linyuan não respondeu. Tirou do peito uma folha de papel de arroz dobrada e a entregou ao comerciante. — Tem algo assim à venda?

O proprietário desdobrou o papel. Sanfu espiou e reconheceu imediatamente o desenho da pulseira que Lu Linyuan lhe mandara levar aos artesãos da Oficina Imperial para ser reproduzida às pressas.

Só que os artesãos já haviam informado que fabricar uma pulseira de jadeíta daquele tipo levaria pelo menos dois ou três meses.

Sanfu achava tudo muito estranho. Lu Linyuan nunca demonstrara interesse por jades ou joias. Por que, de repente, estava tão empenhado em encontrar aquela pulseira?

Depois de ver o desenho, o comerciante fez um gesto negativo. — Não temos uma peça dessas. Por que o senhor não pergunta em outra loja?

Sanfu acompanhou Lu Linyuan a mais três ou quatro estabelecimentos, mas todos disseram que não tinham jadeíta daquela aparência e qualidade.

Sanfu imaginou que, depois de tantas negativas, alguém tão impaciente quanto o imperador logo desistiria.

Mas, naquela noite, parecia que Lu Linyuan havia tomado algum remédio errado: estava determinado a encontrar aquela bendita pulseira de jadeíta!

Sanfu pediu que voltasse para descansar. Lu Linyuan, porém, deu meia-volta e entrou em mais uma loja.

Assim, amo e servo percorreram Yanxi de um lado para o outro, passando de comércio em comércio.

As pálpebras de Sanfu já brigavam para não fechar, enquanto Lu Linyuan parecia ficar cada vez mais desperto.

Por fim, encontraram uma pista numa lojinha discreta.

Depois de ver o desenho, o comerciante assumiu um ar misterioso. — O que o senhor procura é justamente o maior tesouro da minha loja. E não custa pouco.

Sanfu despertou de uma vez ao ouvir aquilo: finalmente chegara sua hora de bancar o ricaço!

— Cof, cof! — Ele engrossou a voz. — Diga o preço! Não existe quantia que meu senhor não possa pagar!

O comerciante elogiou tamanha generosidade e foi buscar, nos fundos, uma caixa de brocado preta com detalhes dourados. Dentro dela repousava uma pulseira de jadeíta.

Lu Linyuan pegou a joia e examinou-a com cuidado. Era quase noventa por cento idêntica à pulseira que a mãe de Ning Xiaoxiao lhe dera. Um sorriso discreto enfim surgiu em seu rosto cansado.

Sanfu, especialista em ler expressões, perguntou: — Meu senhor, é esta?

Lu Linyuan assentiu. Sanfu suspirou, aliviado, e perguntou ao comerciante: — Quantos taéis?

— Quinhentos taéis de prata. Não aceito nem uma moeda a menos.

Era óbvio que o lojista estava tentando arrancar uma fortuna deles: quinhentos taéis por uma pulseira de jadeíta!

Mas não se põe preço naquilo que se deseja de verdade. Lu Linyuan passara a noite inteira procurando; diante de todo esse esforço, a quantia já nem parecia tão importante.

Por isso, sem pensar duas vezes, Sanfu fez um gesto grandioso e pagou.

Quando saíram da loja, o horizonte já começava a clarear.

Sanfu bocejou. — Majestade, tamanha perseverança... O senhor praticamente vasculhou todas as joalherias de Yanxi. Deve mesmo gostar muito dessa pulseira. Quinhentos taéis foi caro, mas valeu a pena.

Lu Linyuan sorriu. — Valeu mesmo. Afinal, não fui eu que paguei.

— Exatamente, e além disso... Hein? O quê?! — Sanfu despertou num sobressalto. — Majestade, não vai me dizer que pretende deixar a despesa da pulseira por minha conta!

Lu Linyuan olhou de esguelha para ele. — Foi você quem se gabou de ter dinheiro, e foi você quem pagou. Vou lançar a dívida na sua conta e descontá-la mensalmente do seu soldo.

Sanfu seguiu atrás do imperador com uma expressão de choro, reclamando sem parar:

— Aaaah, Majestade! Assim o senhor acaba com a minha vida!

— E se eu pagar só a metade? Podemos dividir, duzentos e cinquenta para cada um!

— Ei! Majestade, vá mais devagar! Não saia correndo!

A aurora alaranjada se espalhava pelo céu azul-claro como tinta derramada sobre seda. Entre brincadeiras e reclamações, as silhuetas de amo e servo foram desaparecendo ao longe.

Ao voltar ao Templo do Buda de Jade, Lu Linyuan não descansou nem um instante: ordenou que o cortejo partisse imediatamente para o palácio.

Na viagem de volta, Sanfu estava tão exausto que mal se mantinha vivo. Já Lu Linyuan continuava sem sono e chegou até a ler um tratado militar dentro da carruagem.

Sanfu perguntou, curioso: — Majestade, o senhor não está cansado?

De fato, ele não estava. Só não sabia por quê.

Muito tempo depois, compreenderia uma verdade:

Quando se carrega alguém no coração, o cansaço parece não ter vez.

---

Naquela noite, já de volta ao palácio, Lu Linyuan mandou trazer, como de costume, a plaquinha com o nome de Gu Sijin.

Assim que entrou nos aposentos, Gu Sijin tirou a roupa com a familiaridade de quem já conhecia a rotina. Por baixo, usava uma veste de dormir de seda justa ao corpo, ideal para absorver o suor.

Depois de um breve aquecimento, nem precisou que Lu Linyuan marcasse o ritmo: começou por conta própria.

— Um, dois, três, quatro! Dois, dois, três, quatro! Movimento errado, mais uma vez!

— Barriguinha definida, cinturinha marcada, é isso que eu quero!

Enquanto isso, Lu Linyuan apanhou Ning Xiaoxiao como quem segura um pintinho e a levou outra vez ao escritório do salão lateral para ler memoriais para ele.

Ning Xiaoxiao parecia já ter se acostumado com aquele ritual. Nem se deu ao trabalho de reclamar mentalmente.

Mal se sentou e se preparou para abrir o memorial, Lu Linyuan segurou-lhe o pulso direito de repente.

— Dois dias sem nos vermos, e o ferimento no seu dedo já sarou?

— Eu... eu tenho uma constituição especial, Majestade. Desde pequena minhas feridas cicatrizam depressa... E eu não peguei escondido aquele remédio que o senhor deu para o Caonima, não...

Dizia que não, mas ainda havia uma camada fina de pó medicinal sobre a ferida já cicatrizada.

Lu Linyuan não era cego. Se visse aquilo, com certeza voltaria a acertar contas com ela.

Ning Xiaoxiao tentou puxar a mão, mas ele apertou ainda mais e ordenou, num tom autoritário:

— Não se mexa.

Os calos ásperos que os treinos de artes marciais haviam deixado na palma dele roçaram a pele delicada dela, provocando cócegas...

No instante seguinte, Lu Linyuan tirou uma pulseira de dentro da manga e, com movimentos delicados, colocou-a no pulso da moça.

Ning Xiaoxiao ficou paralisada ao ver aquela pulseira de jadeíta, igualzinha à que sua mãe lhe dera.

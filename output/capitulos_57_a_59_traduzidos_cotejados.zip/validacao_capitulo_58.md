# Validação — capítulo 58

- **Original principal:** `novel_capitulos_1_a_60(20261103-183111).docx` (chinês tradicional).
- **Trecho do DOCX:** parágrafos 4344–4417, finalizado antes do capítulo 59.
- **Unidades originais não vazias (título incluído):** 71.
- **Linhas de cotejo CSV:** 71.
- **Traduções vazias / unidades omitidas no cotejo / unidades extras:** 0.
- **Método:** transcrição e tradução associadas ao índice de cada parágrafo do documento original; checagem programática de cobertura 1:1 e presença de tradução.
- **Pontos de continuidade e escolhas editoriais:** Viagem ao mausoléu e busca de uma pulseira semelhante à da mãe de Ning. Sanfu paga 500 taéis e o imperador lhe atribui a conta. A fala sobre dividir 250/250 no chinês também admite uma piada com “二百五” (tolo); a tradução mantém a proposta de divisão, mas não reproduz integralmente esse duplo sentido. O imperador presenteia Ning com a pulseira.
- **Ressalva:** a correspondência 1:1 só comprova a cobertura estrutural. Não prova fidelidade semântica absoluta. Houve revisão durante a redação, mas não segunda auditoria linguística independente.

# Validação — capítulo 57

- **Original principal:** `novel_capitulos_1_a_60(20261103-183111).docx` (chinês tradicional).
- **Trecho do DOCX:** parágrafos 4283–4343, finalizado antes do capítulo 58.
- **Unidades originais não vazias (título incluído):** 58.
- **Linhas de cotejo CSV:** 58.
- **Traduções vazias / unidades omitidas no cotejo / unidades extras:** 0.
- **Método:** transcrição e tradução associadas ao índice de cada parágrafo do documento original; checagem programática de cobertura 1:1 e presença de tradução.
- **Pontos de continuidade e escolhas editoriais:** Cailian pede desculpas a Gu Sijin e a Ning Xiaoxiao; os eventos espelham sua transformação antagonista no texto original. Lu Linyuan se recusa a levar a imperatriz à visita ancestral. A expressão chinesa “綠茶” é insulto para alguém dissimulado, e a fala de Dongting contém um trocadilho; a versão conserva o lago e explica a dissimulação.
- **Ressalva:** a correspondência 1:1 só comprova a cobertura estrutural. Não prova fidelidade semântica absoluta. Houve revisão durante a redação, mas não segunda auditoria linguística independente.

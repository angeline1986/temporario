# Capítulo 59 — Para que serve esse bastão de ferro?

A jadeíta estava fria ao toque, como se gelasse até o ar ao redor.

O salão estava estranhamente silencioso. Ning Xiaoxiao só conseguia ouvir o próprio coração batendo acelerado.

Ela apertou os lábios e desviou os olhos de corça, constrangida. Um leve rubor subiu-lhe às faces.

Talvez para aliviar o embaraço dela — ou o seu próprio —, Lu Linyuan soltou sua mão e disse com a habitual frieza:

— Hoje, enquanto conferia o tesouro imperial, encontrei essa coisa empoeirada num canto. Achei tão feia que me lembrei de você: combina perfeitamente.

Ele alisou com aparente indiferença uma dobra da manga. — Se não quiser, pode quebrá-la e jogar fora.

Aquela fala de sujeito sem o menor tato estourou, uma a uma, todas as bolhinhas cor-de-rosa que surgiam sobre a cabeça de Ning Xiaoxiao.

Ela recuperou a lucidez imediatamente. Sem corar nem hesitar, ainda ralhou consigo mesma em pensamento:

【Que bobagem estou imaginando? Ele tem um harém inteiro de mulheres lindas à disposição e nem liga para elas. Por que haveria de se interessar por mim?】

Lu Linyuan soltou um muxoxo por dentro: *Humpf. Ao menos você tem um pingo de consciência de si mesma.*

Mas logo os pensamentos dela tomaram um rumo bastante estranho:

【Hmm... Espera aí, tem alguma coisa errada! A essa altura, ele já deveria ter feito *aquilo* com a Gu. Por que até agora não aconteceu nada?】

【Será que chamar a Gu para fazer ginástica todas as noites, enquanto me obriga a ler memoriais aqui, é só uma cortina de fumaça?】

【Será que, por ele já ter ficado grávido uma vez, o corpo passou a produzir estrogênio demais e agora... o equipamento não funciona direito?】

Enquanto pensava nisso, seus olhos desceram involuntariamente para... as calças de Lu Linyuan.

Lembrando-se de que Sanfu tinha certos “desejos mundanos”, ela não resistiu a zombar mentalmente do imperador:

【Se tem uma coisa boa que não usa, podia doar para quem sabe aproveitar~】

Lu Linyuan entendeu mais ou menos a insinuação. Franziu a testa e a fulminou com o olhar. — Por que está encarando a minha virilha?

— Ah? N-não... Não é nada! — Ning Xiaoxiao balançou a cabeça com força, tentando expulsar as imagens indecentes da mente.

— Agradeço o presente de Vossa Majestade. Gostei muito da pulseira.

Ela ergueu o pulso e o exibiu diante dele. O sorriso fez surgir pequenas covinhas no rosto, dando-lhe um ar puro e inocente, como o de uma moça que nada sabia da vida.

Lu Linyuan: 【Inocente, ela? Ah, me poupe! Com tanta sujeira que passa pela cabeça dessa mulher todos os dias, começo a suspeitar que a água dos rios Amarelo, Huangchuan e Huangpu veio toda espremida do cérebro dela!】

— Cof, cof, cof... — Lu Linyuan tossiu de repente, sentindo uma dor de cabeça incômoda.

Ning Xiaoxiao perguntou, preocupada: — Majestade, o que houve? Não está se sentindo bem?

— Cof, cof... Eu passo mal só de olhar para você!

— Ah... — Ning Xiaoxiao pensou depressa, fechou o memorial e se preparou para escapar. — Nesse caso, vou me retirar primeiro, para não prejudicar a preciosa saúde de Vossa Majestade~

Mal terminou de falar, saiu correndo. Lu Linyuan pegou um memorial e o arremessou contra a panturrilha dela.

Controlou muito bem a força: o golpe não machucaria, mas bastaria para fazê-la perder o equilíbrio enquanto corria.

Ning Xiaoxiao soltou um grito esquisito, escorregou de joelhos e foi parar bem nos braços de Lu Linyuan.

Para manter aquela pose de homem frio e indiferente, ele não estendeu as mãos para ampará-la.

Com o impulso da queda, Ning Xiaoxiao deslizou mais um pouco, até... enterrar a cabeça nas coxas de Lu Linyuan...

Lu Linyuan: “???”

Ning Xiaoxiao: “...”

O problema nem era ter acabado naquela posição. Mas por que diabos ela não se levantava?

Tinha gostado daquilo?

— Levante-se!

— Ai, Majestade, não se mexa... Eu dei um mau jeito na cinturaaa...

Ning Xiaoxiao segurava a cintura com a testa franzida. Não parecia estar fingindo.

Lu Linyuan sentiu outra pontada de dor de cabeça. — Cof, cof, cof... Que transtorno!

Reclamava com irritação e fazia cara de desgosto, mas ajudou-a a se erguer do chão com movimentos muito suaves e cuidadosos.

— E então? Como está?

Ning Xiaoxiao se mexeu um pouco. Na queda, torcera a cintura e sentira uma dor forte; agora restava apenas um incômodo leve, e já estava bem melhor.

— Não foi nada, Majestade.

— Se não foi nada, continue lendo os memoriais.

Lu Linyuan voltou a se sentar na poltrona de madeira. Observou Ning Xiaoxiao retornar, contrariada, à mesa imperial: com uma mão na cintura, ela abria um memorial com a outra.

Por causa da dor, não conseguia ficar reta e balançava o corpo o tempo todo.

Lu Linyuan então ordenou: — Leia sentada.

— Hein? — Ning Xiaoxiao olhou para o trono imperial, constrangida. — Majestade... esse é o seu assento. Como uma simples criada poderia...

Lu Linyuan interrompeu-a, ríspido: — Se estou mandando sentar, sente-se! Você fica balançando de um lado para o outro e me dá tontura!

— Ah... Tá bom...

Era a primeira vez que Ning Xiaoxiao se sentava no trono. Não sabia de que material era feita a almofada, mas era tão macia que parecia um colchão de molas.

【Tsc, tsc, tinha esquecido que ele sofre de hemorroidas. Passa o dia inteiro sentado em audiências e lendo memoriais. Claro que precisa de uma almofada bem fofinha!】

Lu Linyuan: “...”

— Mandei você ler os memoriais! Cof, cof, cof... Por que ficou aí parada?

A tosse dele não parecia seca; lembrava mais a tosse de quem pegou um resfriado.

Ning Xiaoxiao não resistiu a demonstrar preocupação: — Majestade, será que não pegou um resfriado por causa do frio? A tosse costuma ser um dos primeiros sinais. É melhor tomar remédio logo, antes que piore. Se a doença avançar e vier uma febre, vai sofrer bastante.

Dessa vez, surpreendentemente, Lu Linyuan não retrucou.

Parecia um leão de juba eriçada que enfim havia perdido a vontade de brigar. Limitou-se a murmurar um “hum” sem entusiasmo.

Ning Xiaoxiao voltou a se concentrar na leitura. Em certo momento, Sanfu pediu licença do lado de fora, e Lu Linyuan mandou que entrasse.

Assim que o eunuco pôs os pés no salão, ficou boquiaberto com a cena.

Ning Xiaoxiao estava confortavelmente instalada no trono imperial, de pernas cruzadas, segurando um memorial e lendo-o em voz alta, toda tagarela.

Lu Linyuan, por sua vez, ocupava uma poltrona secundária, com a cabeça levemente inclinada na direção dela.

Que cena dos deuses era aquela?

Lu Linyuan era tão possessivo com tudo o que dizia respeito à própria autoridade! Como poderia permitir que alguém se sentasse em seu trono? E, mais ainda, que lesse seus memoriais?

Sanfu primeiro ficou pasmo; depois, abriu um sorriso de quem já estava torcendo loucamente pelo casal. — Majestade, a imperatriz enviou o programa das comemorações do seu Festival da Longevidade, seu aniversário, para que o senhor examine.

Lu Linyuan não tinha disposição para olhar. Respondeu displicentemente: — Façam como nos anos anteriores. Cof, cof... Não precisa me mostrar.

Sanfu respondeu, todo alegre: — Certinho! Este servo entendeu!

Ao ouvi-lo rir sem parar, Lu Linyuan finalmente o encarou. — Do que você está rindo?

Sanfu cobriu a boca, com um ar de quem tramava alguma coisa. — Este servo está rindo porque o luar desta noite está encantador, as cigarras quase não cantam... É uma noite maravilhosa e rara!

Ele olhou para Ning Xiaoxiao, depois para Lu Linyuan, cerrou o punho num gesto de incentivo e murmurou:

— Majestade! Vai com tudo!

# Validação — capítulo 112

- **Fonte primária:** `novel_capitulos_61_a_120(20261103-205857).docx`, chinês tradicional.
- **Limites (índices de parágrafo DOCX base zero):** 3730 a 3799; próximo capítulo inicia em 3800.
- **Unidades não vazias, título incluído:** 67.
- **Linhas no cotejo:** 67.
- **Traduções vazias:** 0.
- **Índices ausentes ou excedentes:** 0.
- **Alinhamento estrutural:** uma tradução para cada parágrafo não vazio, mantendo a ordem.

## Observações editoriais

Índice acumulado atinge exatamente 20% após acréscimo de 5% pelo bug. 任斷離 aparece nesta fonte com grafia distinta de 任端禮 na pílula; optou-se pela forma editorial Ren Duanli, com divergência registrada. 陸弈秋 difere de 陸奕秋 da pílula; foi mantido Lu Yiqiu. A piada 急支糖漿 é alusão a anúncio cultural chinês de perseguição por leopardo, aqui vertida literalmente com contexto humorístico. 阿拉燈神釘 é o percevejo mágico, não a lâmpada.

## Limitações verificáveis

A tradução foi preparada e revisada durante a redação; houve verificação de cobertura estrutural 1:1, mas **não uma segunda auditoria linguística independente**. A igualdade na contagem não comprova, por si só, inexistência de omissões dentro de um parágrafo ou erros de sentido.

# Capítulo 113 — Majestade... eu estava morrendo de saudade de você!

Ning Xiaoxiao limpou a garganta e falou com Ren Duanli, do lado de fora:

— General Ren, sei que está cumprindo ordens e não deveria impedi-lo. Mas estou grávida e sou muito medrosa. Sua pantera é imponente demais; só de olhar, fico apavorada.

Ren Duanli: — Fique tranquila, senhora. Minha pantera entende as pessoas. Comigo aqui, é mais obediente do que um cachorro. Não vai assustá-la.

Ning Xiaoxiao: — Mesmo assim, continuo com medo. Que tal o general ir primeiro prestar contas a Sua Majestade? Daqui a pouco eu mesma levarei o Príncipe Jing ao Palácio Chaoyang.

Lá fora, fez-se silêncio.

Quando Ning Xiaoxiao pensou que finalmente o despachara, ouviu um movimento acima de sua cabeça.

Ao erguer os olhos, viu que Ren Duanli, em algum momento, subira até o alto do muro vermelho e agora os observava de cima.

Ele vestia roupas negras e empunhava uma espada longa de cabo dourado. Uma faixa azul-escura marcava sua cintura, e botas marrons bordadas de nuvens cobriam suas pernas, acentuando ainda mais sua silhueta alta e esguia.

O vento soprava naquela altura, fazendo as abas de suas vestes esvoaçarem. A presença dele era tão ameaçadora quanto a de um demônio guerreiro.

No instante seguinte, saltou do muro e aterrissou com firmeza diante de todos.

Ning Xiaoxiao ficou chocada. 【Caralho! Esse muro deve ter uns sete ou oito metros! Newton está se revirando no caixão! O sujeito simplesmente saiu voando?!】

Só então ela pôde ver seu rosto direito.

Sob sobrancelhas retas como espadas, os olhos negros eram profundos e perigosos, como tinta impossível de dissolver. Tinha nariz alto, lábios finos e uma discreta covinha vertical no centro do queixo — um traço associado a uma virilidade marcante. Mas, naquele rosto belo e ligeiramente perverso, a força dos traços se equilibrava num encanto ainda mais perturbador.

Em seus lábios havia um sorriso quase imperceptível, despreocupado e insolente. Seus olhos continuavam presos ao Príncipe Jing.

Era como se ninguém mais existisse à sua volta, como se só enxergasse o príncipe.

Ao ver aquele homem tão bonito, porém, o Príncipe Jing reagiu como se tivesse visto um fantasma: soltou um grito e saiu correndo.

Como a pantera rosnava sem parar do lado de fora do portão, só lhe restava fugir na direção do salão principal do Palácio Zhongcui.

Ren Duanli lançou-lhe um olhar, saltou e executou um elegante mortal para trás, aterrissando bem à frente dele.

Era meia cabeça mais alto que o príncipe. Pousou sua mão larga sobre a cabeça dele, como se brincasse com uma bola, e o manteve inteiramente sob controle.

— Corre de novo. Mas cuidado com esse traseiro.

— Uaaaaa! — O Príncipe Jing segurou o pulso dele com uma mão e protegeu o próprio traseiro com a outra. — Seu pervertido! Você sabe que eu tenho medo de dor! Faz isso de propósito para me maltratar!

Ning Xiaoxiao: — ???

Tem alguma coisa errada comigo!

Se vocês continuarem assim, vou começar a fazer casalzinho na minha cabeça!

O Príncipe Jing, escorregadio como uma enguia, aproveitou um instante de distração de Ren Duanli para se esgueirar de volta para trás de Ning Xiaoxiao, usando-a como escudo.

— N-não chega perto! Esta é a Dama Ning, a nova favorita do meu irmão! Está grávida! Se avançar sem olhar e bater nela, meu irmão vai mandar cortar sua cabeça!

Empurrada para a frente, Ning Xiaoxiao ficou cara a cara com Ren Duanli, numa situação bastante constrangedora.

Esse moleque está me usando como refém?!

Ren Duanli não era alguém que se deixasse enganar facilmente. Por mais que o Príncipe Jing tagarelasse, ele o ignorou e foi direto até Ning Xiaoxiao, estendeu a mão, agarrou o príncipe pelo colarinho e o puxou de volta para seu lado.

— Seu irmão quer ver você. Venha comigo.

Ele começou a arrastar o Príncipe Jing para a saída. Ao passarem por Ning Xiaoxiao, o príncipe agarrou o braço dela e tentou arrastá-la também.

Com o rosto choroso, implorou: — Por favor, por favor! Heroína, venha comigo! Senão, ele e meu irmão vão acabar me matando!

— Venha comigo! Eu ajudo você a roubar as cuecas do meu irmão! Que tal?!

Ning Xiaoxiao: Muito obrigada, viu?!

Esse homem nunca vai superar a história das cuecas roubadas?

Ning Xiaoxiao não queria se meter naquela confusão. Afinal, agora quanto mais longe conseguisse ficar de Lu Linyuan, melhor.

Mas o Príncipe Jing estava tão comoventemente perto das lágrimas que ela acabou cedendo. Sussurrou: — Não precisa roubar cuecas. Arranque um punhado de cabelos do seu irmão para mim, e eu vou com você e falo em seu favor.

O príncipe concordou imediatamente: — Combinado! Palavra dada!

Por estar grávida, Ning Xiaoxiao podia usar uma liteira quando saía.

Já o Príncipe Jing e Ren Duanli precisariam ir a pé.

A liteira de Ning seguia atrás. Vendo os dois homens e a pantera caminharem numa harmonia razoável, ela não conseguiu impedir que a imaginação disparasse:

Um príncipe ingênuo, adorável e todo dengoso no papel de uke × um general frio, calculista e irresistível... Declaro esse casal oficialmente meu!

O Príncipe Jing adorava fazer birra. Antes mesmo de andar muito, começou a reclamar de cansaço e quis entrar na liteira de Ning Xiaoxiao.

Ren Duanli não permitiu. — Você é um homem adulto. Que história é essa de entrar na liteira de uma consorte imperial?

O príncipe olhou para ele com os olhos marejados. — Mas eu não aguento mais andar!

Ren Duanli franziu o cenho e levou a mão à testa. — Que trabalho...

Sem dizer mais nada, segurou o príncipe pela cintura, ergueu-o e o colocou diretamente sobre o dorso da pantera.

O Príncipe Jing começou a gritar de pavor. Ren Duanli ordenou: — Grite de novo, e mandarei Pixiu arrancar seu pescoço com os dentes!

Ao ouvir isso, a pantera chamada Pixiu soltou um “auu”, colaborando com a ameaça de Ren Duanli.

Apavorado, o Príncipe Jing tapou a boca e não ousou emitir mais um som.

Quando chegaram ao Palácio Chaoyang, Lu Linyuan viu Ning Xiaoxiao acompanhando os outros para assistir à confusão. Lançou-lhe um olhar atravessado e a repreendeu de propósito: — Por que você aparece em todo lugar onde há alguma agitação?

Ning Xiaoxiao já estava acostumada com as broncas dele e ia responder: “Esta serva vai se retirar imediatamente”.

Mas pensou melhor. 【Espera aí, porra! Eu já não sou mais uma criada! Agora sou consorte imperial. Tenho que começar a me impor!】

Então limpou a garganta e lançou mão de sua voz mais afetada e melosa: — Majestaaade... é que eu estava morreeendo de saudade de vocêêê!

Aquela exclamação fez Lu Linyuan estremecer e atraiu olhares carregados de insinuação do Príncipe Jing e de Ren Duanli.

Lu Linyuan pigarreou. — Engoliu uma espinha de peixe? Fale direito!

O objetivo de Ning Xiaoxiao era fazê-lo morrer de vergonha na frente do irmão e do súdito favorito. Quem mandou obrigá-la a entrar no harém, como quem força alguém a comprar algo que não quer?

Já que ele escolhera se casar com aquela peste ambulante, teria de aguentar as consequências!

— Majestaaade... estou falando com a minha vozinha manhosa, tááá?

— Majestade, não mude de assuuunto... Você sentiu saudade de mim ou nããão?

Lu Linyuan: — ...

Senti. Senti demais. Principalmente vontade de lhe dar uma paulada!

Diante da súbita crise de afetação de Ning Xiaoxiao, Lu Linyuan decidiu adotar a estratégia de, se não podia vencê-la, juntar-se a ela.

Sem se irritar, respondeu com toda a ternura do mundo, numa única palavra: — Senti.

E fez um gesto chamando Ning Xiaoxiao. — Venha. Sente-se aqui ao meu lado.

Ning Xiaoxiao veio rebolando, com passinhos de gata, sinuosa como uma cobra-d'água, até se acomodar junto dele.

Mal se sentou, a mão grande de Lu Linyuan pousou em sua coxa.

Mas não foi um carinho afetuoso: foi um beliscão ameaçador!

— Aaaai! Majestade! Majestade! Dói! Dói!

Lu Linyuan ergueu uma sobrancelha e perguntou: — Vai continuar com essa vozinha?

— Não! Não vou mais! Eu errei!

Ele soltou um resmungo satisfeito e finalmente retirou a mão.

(PS: Contando um segredinho: podem torcer à vontade por todos os casais deste livro. Nenhum deles é um casal de mentira, viu?)

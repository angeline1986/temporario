# Validação — capítulo 111

- **Fonte primária:** `novel_capitulos_61_a_120(20261103-205857).docx`, chinês tradicional.
- **Limites (índices de parágrafo DOCX base zero):** 3671 a 3729; próximo capítulo inicia em 3730.
- **Unidades não vazias, título incluído:** 56.
- **Linhas no cotejo:** 56.
- **Traduções vazias:** 0.
- **Índices ausentes ou excedentes:** 0.
- **Alinhamento estrutural:** uma tradução para cada parágrafo não vazio, mantendo a ordem.

## Observações editoriais

O posto 答應 é traduzido como Dama, conforme o lote anterior (capítulo 110); 常在 permanece Atendente. Xiao Qi esclarece que se trata de gravidez aparente, não real. A expressão 宿便 é tratada como fezes acumuladas, elemento absurdo da ficção.

## Limitações verificáveis

A tradução foi preparada e revisada durante a redação; houve verificação de cobertura estrutural 1:1, mas **não uma segunda auditoria linguística independente**. A igualdade na contagem não comprova, por si só, inexistência de omissões dentro de um parágrafo ou erros de sentido.

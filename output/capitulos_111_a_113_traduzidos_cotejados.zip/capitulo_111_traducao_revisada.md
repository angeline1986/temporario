# Capítulo 111 — Você está com fezes acumuladas, anfitriã!

Gu Sijin ergueu um lenço de seda para enxugar as lágrimas que escorriam dos olhos de Ning Xiaoxiao. — Não chore mais. Agora que está grávida, precisa se cuidar. Quando eu era pequena, minha mãe dizia que, se uma mulher chorar durante a gestação, o bebê nascerá com uma pinta de lágrima no rosto. E isso não fica bonito.

Ao ouvir falar em pintas de lágrima, Ning Xiaoxiao logo se lembrou da pequena marca vermelho-cinábrio no canto do olho de Lu Linyuan.

Ela brincou: — A do imperador é até vermelha! Pelo visto, a imperatriz-viúva deve ter chorado bastante quando estava grávida dele.

— O imperador tem uma pinta dessas? — Gu Sijin apoiou o queixo na mão, pensou um pouco e sorriu, balançando a cabeça. — Nunca reparei.

Gu Sijin nem sequer havia notado uma característica tão evidente. Isso mostrava o quanto Lu Linyuan ocupava pouco espaço em seus pensamentos.

E fazia sentido. Afinal, na obra original ele não passava do eterno segundo colocado no coração dela.

Chu Xingran é que era seu eterno amor idealizado.

Enquanto Chu Xingran não aparecia, Lu Linyuan ainda conseguia conquistar um cantinho em seu coração.

Mas, assim que ele voltava, Gu Sijin só tinha olhos para ele, sem espaço para mais ninguém.

Enquanto Ning Xiaoxiao estava distraída, Gu Sijin tirou um par de brincos e começou a colocá-los em suas orelhas.

Ning olhou: eram brincos de jadeíta.

A pedra era translúcida, de excelente qualidade, e bastava uma olhada para perceber que custava uma fortuna.

O acabamento também era delicado, com fios de ouro formando a moldura e detalhes em pedra azul-esverdeada, o que os fazia brilhar ainda mais.

— Irmã, isso é...?

— Fique quietinha, deixe eu ver. — Depois de colocar os brincos, Gu Sijin examinou-a de um lado e do outro, satisfeita. Pegou um espelho de bronze para que ela se visse. — Esse verde vivo realça sua pele clara e deixa você ainda mais bonita. E combina perfeitamente com sua pulseira. Achei lindo.

Gu Sijin acabara de perder dois meses de soldo como punição e já andava com as finanças apertadas.

Um par de brincos assim custaria pelo menos cem taéis, o equivalente a um mês de remuneração que ela recebera quando ocupava o posto de Atendente.

Ning Xiaoxiao se sentiu constrangida por aceitar algo tão caro. — Irmã, esse presente vale demais. Não posso ficar com ele.

Ela começou a tirar os brincos, mas Gu Sijin franziu a testa, aborrecida. — Se tirar, vou entender que continua fazendo cerimônia comigo. O valor não está no preço, mas no carinho! Hoje eu lhe dou um presente; amanhã você me dá outro. Por que ficar fazendo contas?

— Além disso, nem custaram tanto assim. Comprei a jadeíta bruta no Departamento de Assuntos Internos por apenas trinta taéis de prata. Minha mãe começou a vida negociando joias e pedras preciosas; aprendi um pouco do ofício com ela quando ainda morava em casa.

— Eu mesma cortei e poli a pedra, sem imaginar que encontraria um material tão bonito. Os detalhes azul-esverdeados e o entrelaçado dourado eu fiz ontem à noite, trabalhando até tarde. Cada fio, cada pedra e cada pedaço de jade levam meu carinho. Como você pode rejeitar tudo isso?

Só então Ning Xiaoxiao entendeu o motivo dos ruídos metálicos que ouvira na noite anterior, quando Gu Sijin se trancara no quarto: ela havia passado a noite confeccionando aqueles brincos.

Contemplando o sorriso luminoso de Gu Sijin, Ning sentiu que, naquela cidade imperial cada vez mais fria, ela era como um pequeno sol inesgotável, irradiando luz e calor para aquecer todas as pessoas que mereciam aquele afeto.

Embora a chamasse de irmã mais velha, em seu íntimo Ning Xiaoxiao sempre a tratara como sua própria “filhota”.

E, quando alguém a tratava com sinceridade, ela retribuía da mesma forma.

Mais tarde naquele dia, Gu Sijin a acompanhou aos palácios da imperatriz e da imperatriz-viúva para agradecer a graça recebida. Quando regressaram, os criados recém-designados pelo Departamento de Assuntos Internos para servir Ning Xiaoxiao já haviam chegado.

Como Ning fora promovida excepcionalmente, saltando níveis da hierarquia, por enquanto só poderiam destinar-lhe duas criadas.

As duas pareciam simpáticas, e Ning estava prestes a aceitá-las quando Gu Sijin sussurrou em seu ouvido: — Aquela da esquerda, de olhos alongados e rosto oval... Acho que já a vi no palácio da Consorte Yun.

Ning Xiaoxiao não era tão observadora quanto Gu Sijin. Somente depois do aviso percebeu que aquela criada realmente lhe parecia familiar.

Agora ela estava “grávida” e, aos olhos dos outros, era a nova favorita imperial. Não faltariam consortes dispostas a conspirar contra ela.

Se admitisse uma criada de antecedentes duvidosos, seria preferível cuidar de tudo sozinha a repetir a desgraça de Cailian, que traíra a confiança de quem a acolhera.

Ela disse: — Peço que leve as duas de volta, eunuco. Não vim de família nobre e sempre fiz minhas próprias tarefas. Passei anos trabalhando como criada e me acostumei. Ter gente me servindo é que me deixaria desconfortável.

O eunuco hesitou. — Mas... agora a senhora está esperando um filho imperial, e sua posição não é mais a mesma. Como permitir que se canse? Se essas duas não lhe agradam, posso escolher outras.

Gu Sijin interveio: — Não será necessário. Qiqi e Qiaqia, do meu palácio, trabalharam com a Dama Ning e são muito próximas dela. Eu gosto de sossego e não faço questão de tantos criados. Afinal, continuaremos todas no Palácio Zhongcui. Basta transferi-las para atender a Dama Ning e registrar a mudança no Departamento de Assuntos Internos.

Só assim conseguiram dispensar o eunuco.

Qiqi e Qiaqia eram muito próximas de Ning Xiaoxiao. Como as alas leste e oeste do Palácio Zhongcui ficavam separadas apenas por uma galeria, não faria grande diferença onde trabalhassem.

Com isso, os acontecimentos relativos à nomeação de Ning Xiaoxiao como Dama chegaram, por ora, ao fim.

Daí em diante, ela era oficialmente uma integrante do harém imperial.

Só que a maneira como se tornara uma consorte era surreal demais.

Quando foi descansar depois do almoço, Ning Xiaoxiao perguntou a Xiao Qi:

【E agora? Eu, que estava tão bem, fiquei grávida do filho de um personagem de papel! Quando chegar a hora, será que vou dar à luz uma carta SSR?】

Xiao Qi andava matando serviço nos últimos dias e ainda não ouvira a “boa notícia” de Ning.

Ao saber da gravidez, acionou imediatamente seu sistema de varredura e fez um exame completo do corpo dela:

【Mas, anfitriã... você não está grávida!】

Ning Xiaoxiao: 【Como assim? Os médicos imperiais examinaram meu pulso várias vezes! Todos podem estar errados? E aquele maldito imperador ainda admitiu, com a própria boca, que fez... aquilo comigo...】

Xiao Qi: 【Não, não! O tirano está mentindo! Naquela noite em que você ficou inconsciente no Palácio Chaoyang, ele não fez nada indecente! A Administração do Espaço-Tempo tem uma regra: nós, sistemas, não podemos presenciar essas coisas picantes.】

【Se a anfitriã e o tirano começassem a fazer algo íntimo, eu seria imediatamente trancada numa salinha escura pela Administração do Espaço-Tempo e só sairia quando vocês terminassem.】

【Além do mais, segundo a minha varredura corporal, você continua virgem. De onde teria vindo esse bebê?】

Ning Xiaoxiao retrucou, irritada: 【Você pergunta para mim? Eu vou perguntar para quem?!】

Xiao Qi consultou o manual de transmigração e examinou novamente o corpo de Ning Xiaoxiao. Por fim, chegou a uma conclusão:

【Calma, anfitriã. Talvez tenha ocorrido um bug na Administração do Espaço-Tempo. Como você escreveu aquela ceninha em que o tirano ficava grávido, pode ter sofrido uma reação de retorno. Sua situação é igualzinha à dele naquele dia: seu pulso apresenta sinais de gravidez, mas o que você carrega na barriga não é um bebê. É... cocô velho acumulado no intestino...】

Ao ouvir aquilo, Ning Xiaoxiao quase desmaiou de raiva.

Era melhor você ter dito que eu estava grávida de verdade!

Agora vem me dizer que estou carregando uma montanha de merda na barriga?!

Eu sei que isso normalmente fica na barriga, mas, dito assim, por que parece tão nojento?!

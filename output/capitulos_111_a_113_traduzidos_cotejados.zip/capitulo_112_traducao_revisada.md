# Capítulo 112 — Você tem xarope para bronquite?

Xiao Qi não sabia que Lu Linyuan podia ouvir os pensamentos de Ning Xiaoxiao, muito menos que, por uma série de coincidências, ele usara o percevejo mágico de Aladim para fazer um desejo que ninguém em sã consciência teria imaginado.

Por isso, a única explicação razoável que encontrou para aquela situação inesperada foi jogar a culpa na Administração do Espaço-Tempo e afirmar que havia ocorrido um bug.

Ning Xiaoxiao já era brava com o sistema mesmo quando ele não fazia nada de errado. Agora que uma confusão desse tamanho tinha acontecido, será que não iria acabar com Xiao Qi?

O sistema se apressou em tranquilizá-la: 【Mas não se preocupe, anfitriã. Essas fezes acumuladas desaparecerão em dois meses. Ou seja, basta aguentar dois meses e os sintomas de gravidez desaparecerão naturalmente...】

【Dois meses?! Por que não diz logo dois anos?! O sistema de vocês dá defeito e eu é que pago o pato?! Tem ideia de como a história está agora? Eu estava muito bem, agarrada às pernas de Gu Sijin, levando uma vidinha tranquila sem fazer esforço! Agora o maldito imperador me transformou numa concubina, e vou acabar envolvida à força nas brigas daquelas mulheres!】

Xiao Qi: 【Calma, anfitriã! Foi justamente porque você seguiu um caminho completamente inesperado que o desvio da trama ficou tão anormal. Fiz as contas: esse bug pode lhe render mais 5% de índice de desvio. Pense bem, não é um mau negócio! Sem cumprir missão nenhuma, você ganha 5% só por fingir estar grávida durante dois meses. Uma bênção disfarçada, não acha?】

Discutir com Xiao Qi não adiantaria nada.

O sistema também não tinha como fazê-la deixar de apresentar aquela falsa gravidez imediatamente.

O estrago estava feito. Ela teria de sobreviver por dois meses com aquela carga intestinal e seus inconvenientes. Pelo menos receberia 5% de desvio da trama. Restava aceitar o destino.

Somados esses 5%, o índice de desvio da trama chegava agora a 20%. Ela já havia conseguido alterar um quinto do enredo.

Pensar que o dia de voltar para casa estava cada vez mais próximo lhe trouxe algum consolo.

*

Nos últimos dois dias, Lu Linyuan parecia especialmente ocupado com assuntos de Estado. Ren Duanli, comandante do Acampamento de Cavalaria de Elite, derrotara as tribos bárbaras do sul e regressava naquele dia à capital. Os soldados que se haviam distinguido na batalha receberiam grandes recompensas, de modo que o imperador não tinha tempo de assistir Gu Sijin dançar “Compêndio de Matéria Médica” ou Ning Xiaoxiao dançar “Ai Ni”.

Sem ele por perto, Ning Xiaoxiao e Gu Sijin estavam felizes da vida.

Passavam os dias comendo, bebendo e passeando, numa tranquilidade digna dos imortais.

Depois do almoço, a imperatriz-viúva foi queimar incenso e orar no Salão Fahua, convidando as mulheres do harém para acompanhá-la.

Como Ning Xiaoxiao estava “grávida”, seria melhor evitar a fumaça de incenso; por isso, ficou sozinha no Palácio Zhongcui.

Ela acordara tarde e não conseguia dormir depois do almoço, então decidiu passear no jardim imperial.

Mas mal cruzou os portões do palácio e quase foi atropelada por um jovem eunuco.

Qiqi colocou-se à sua frente e o repreendeu com severidade: — Para que toda essa correria?! E se esbarrasse na senhora e machucasse o herdeiro imperial?

Ning Xiaoxiao olhou melhor. Aquilo que disparava pelo corredor em plena hora do almoço não era eunuco coisa nenhuma!

Era o adorável e desmiolado Príncipe Jing!

— Alteza, Príncipe Jing? Por que... por que está vestido assim de novo?

Com o rosto coberto de suor, o príncipe agarrou o braço de Ning Xiaoxiao e começou a implorar com voz manhosa:

— Heroína das Cuecas, socorro! Tem um leopardo me perseguindo!

Lu Linyuan sempre dizia que seu irmão vivia inventando moda. O que seria aquele cosplay de hoje?

— De onde apareceria um leopardo dentro do palácio? E você escondeu algum xarope de bronquite aí na roupa? Por que um leopardo iria correr atrás de você?

O Príncipe Jing resmungou, sacudindo os braços e batendo os pés. — Como vou saber por que está me perseguindo? Acho que quer me comer...

— ...

Ning Xiaoxiao, naturalmente, achou que ele estava contando lorotas. Como não tinha nada melhor para fazer, pensou que não custaria entrar na brincadeira.

Só que, no instante seguinte, ouviu um rugido baixo de leopardo vindo de não muito longe.

O Príncipe Jing saltou para trás dela e espiou por cima de seu ombro a fera que se aproximava:

— Uaaaa! Está vindo! Está vindo! Está vindo!

Ning Xiaoxiao também ficou boquiaberta.

Caramba!

Era um leopardo de verdade, porra?!

Tratava-se de uma pantera de pelagem castanho-escura quase negra, com cerca de um metro e meio de comprimento e corpo musculoso. Seus dois olhos castanhos brilhavam de modo ameaçador, fixos na direção deles, enquanto as patas dianteiras arranhavam o chão, prontas para atacar.

— Corram!

Ning Xiaoxiao agarrou o Príncipe Jing e correu para dentro do Palácio Zhongcui, trancando os portões às pressas.

Com um estrondo, a pantera bateu contra a porta de madeira vermelha, soltou um rosnado e começou a raspar suas garras afiadas nas frestas.

O Príncipe Jing continuava escondido atrás de Ning, agarrado a seus ombros com as duas mãos. Aquele homem de mais de um metro e oitenta fora reduzido, pelo medo, a um cachorrinho indefeso.

Entre a irritação e a vontade de rir, Ning Xiaoxiao perguntou: — Alteza, o que foi que fez para essa pantera não sair do seu encalço?

O príncipe respondeu com a maior cara de injustiçado: — Eu... O que eu poderia ter feito?! A culpa é do meu irmão! Ele disse que estava doente, e corri para o palácio para visitá-lo. Só que, quando cheguei, dei de cara com o meu querido Li! Aí descobri que meu irmão estava mentindo! Ele queria que o Li me desse uma lição!

— Você acha que sou burro? Claro que não sou! Saí correndo na mesma hora. Já tinha conseguido escapar, mas aquele Li trapaceiro mandou o leopardo farejar meu cheiro e me perseguir pelo caminho inteiro!

Quando percebeu que os portões eram resistentes e a pantera não conseguia atravessá-los, sua coragem começou a voltar.

Saiu de trás de Ning Xiaoxiao, sem sinal dos tremores de antes, e ainda gritou para a fera pela fresta da porta: — Vem me pegar, sua idiota! Se é corajosa, fica aí sem se mexer! Vou mandar os guardas prenderem você e, à noite, a gente faz um churrasco!

Ning Xiaoxiao: — Seu querido Li? Quem é? Sua esposa?

— Credo! Credo! — O Príncipe Jing cuspiu duas vezes, com expressão de nojo. — É aquele cabeça de porco do Ren Duanli!

Do lado de fora, a pantera parou de atacar e ficou quieta.

Em seguida, uma voz masculina grave, envolvente e perigosamente sedutora ecoou do outro lado: — Quem você chamou de porco?

O Príncipe Jing, que até então se fazia de valentão, murchou no segundo em que ouviu aquela voz.

Escondeu-se de novo atrás de Ning Xiaoxiao e gritou para o outro lado: — E-eu estava falando de você!

— Hã. — O homem soltou uma risada fria, provocadora. — Lu Yiqiu, ficou três dias sem apanhar, as feridas no seu traseiro já cicatrizaram e você esqueceu a dor?

Que voz absurda!

Era sedutora e maliciosa; o final de cada frase parecia um gancho. Nos dias de hoje, no mínimo serviria para dublar um vilão perigosamente obcecado.

【Ele é um oficial de fora do palácio e ousa chamar o Príncipe Jing pelo nome?】

【Nossa... Como é que eu não sabia que havia um personagem tão atrevido assim na história original?】

【E ele... já bateu na bunda do Príncipe Jing?!】

A voz ficou mais moderada e prosseguiu: — Não sei qual senhora do harém está aí dentro. Sou Ren Duanli e apresento meus respeitos. Por ordem de Sua Majestade, vim conduzir o Príncipe Jing ao Palácio Chaoyang para uma conversa. Peço que abra o portão.

O Príncipe Jing agarrou o braço de Ning Xiaoxiao, fez um biquinho e implorou: — Heroína! Heroína! Não abra! Se abrir essa porta, vou morrer jovem!

Era difícil para as mulheres resistirem a coisas adoráveis — e não se tratava apenas de objetos ou animais. Pessoas também podiam ser adoráveis.

Ning Xiaoxiao ergueu uma sobrancelha para o príncipe e lhe sussurrou: — Fique tranquilo. Nós dois juramos irmandade no Palácio Chaoyang. É claro que vou proteger você.

— Aaaah, obrigada, heroína!

Dizendo isso, o Príncipe Jing deu-lhe um abraço enorme. Era magro, mas muito alto e musculoso; aquele abraço de urso quase deixou Ning Xiaoxiao sem ar...

— Pare de me abraçar! Se não soltar, eu abro o portão!

Assim que ouviu a ameaça, o príncipe a soltou, ergueu as mãos acima da cabeça em rendição e mostrou a língua de modo travesso.

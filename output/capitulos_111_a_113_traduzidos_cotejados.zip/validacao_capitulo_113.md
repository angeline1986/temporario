# Validação — capítulo 113

- **Fonte primária:** `novel_capitulos_61_a_120(20261103-205857).docx`, chinês tradicional.
- **Limites (índices de parágrafo DOCX base zero):** 3800 a 3876; próximo capítulo inicia em 3877.
- **Unidades não vazias, título incluído:** 74.
- **Linhas no cotejo:** 74.
- **Traduções vazias:** 0.
- **Índices ausentes ou excedentes:** 0.
- **Alinhamento estrutural:** uma tradução para cada parágrafo não vazio, mantendo a ordem.

## Observações editoriais

O título 答應 foi vertido como Dama. 夾子音, voz aguda/manhosa, foi adaptado para português natural. A expressão 耽美 傻白甜誘受 X 高冷腹黑大將軍 é uma fantasia de ship/casal feita por Ning, não prova de relação estabelecida na cena. O nome 貔貅 foi transliterado Pixiu. Nota da autora ao fim preservada.

## Limitações verificáveis

A tradução foi preparada e revisada durante a redação; houve verificação de cobertura estrutural 1:1, mas **não uma segunda auditoria linguística independente**. A igualdade na contagem não comprova, por si só, inexistência de omissões dentro de um parágrafo ou erros de sentido.

# Capítulo 240 — A morte de Qiqi

(A história segue seu curso normal. Há uma cena dolorosa; quem tem coração sensível, melhor não ler. Se ler, por favor, não brigue comigo.)

(Por favooor o(╥﹏╥)o)

Bilian imediatamente trouxe vários eunucos e imobilizou Qiqi.

A Consorte Yun aproximou-se e pisou com força nos dedos dela.

— Aaaah!!!

— Sua escrava desprezível! Acha que, só porque aquela Ning foi promovida a Consorte Nobre, você também subiu de posição por ser a criada encarregada do Palácio Fengyi?

A Consorte Yun apertou ainda mais o pé. De tanta dor, Qiqi mordeu os próprios lábios até sangrar.

— Vou lhe dizer como funcionam as regras deste palácio: escrava é escrava, senhora é senhora! Nem Xiangling, que serve a própria imperatriz, ousaria me barrar. E você pensa que é quem?

A Consorte Yun recebeu de Bilian um lenço e limpou delicadamente o arranhão na palma da mão.

— Ai...

Uma pontada a fez franzir o cenho. Cada vez mais irritada, ordenou:

— Arrastem essa escrava para longe e deem-lhe uma surra daquelas!

Obedecendo, Bilian e os demais puxaram Qiqi para um canto e começaram a golpeá-la com socos e pontapés.

Qiqi não ousou reagir em momento algum. Chorava e implorava à Consorte Yun que poupasse sua vida.

A Consorte Yun fingiu não ouvir e ficou assistindo a tudo.

Por fim, incapaz de suportar mais golpes, Qiqi empurrou Bilian.

Enfurecida, Bilian apanhou uma pedra de um canteiro e a desferiu contra a testa de Qiqi.

*PÁ!*

A testa de Qiqi se abriu, e o sangue jorrou. Ela caiu no chão com o impacto.

O enfeite de cabelo que guardara cuidadosamente junto ao peito também caiu.

Com as poucas forças que lhe restavam, estendeu lentamente a mão e conseguiu recolhê-lo na palma.

Mas, antes de conseguir apertá-lo contra si, fechou os olhos para sempre.

Ao vê-la imóvel, Bilian pensou que estivesse fingindo de morta. Deu-lhe dois chutes e, quando ela não reagiu, abaixou-se para verificar sua respiração. Só então percebeu que realmente a haviam matado.

Um dos eunucos entrou em pânico ao perceber que alguém morrera:

— S-senhora Consorte Yun... ela morreu de tanto apanhar... O-o-o que vamos fazer?

*PÁ!*

Bilian deu um tapa no rosto do eunuco e o repreendeu em voz alta:

— Por que esse escândalo? Morreu uma criada, só isso! Gente morre neste palácio todos os dias. Ela não pode morrer também? Foi ela quem afrontou a senhora primeiro. Recebeu o que merecia!

A Consorte Yun lançou um olhar frio ao corpo de Qiqi e disse sem emoção:

— Avisem ao Departamento de Assuntos Internos que ela tropeçou por descuido e bateu a cabeça numa pedra, morrendo em consequência da queda.

Ergueu o lenço para cobrir o nariz, com uma expressão de repulsa. — O Ano-Novo está chegando, e é de péssimo agouro que ela morra dentro do palácio. Mandem os servos enrolá-la numa esteira de palha e enterrá-la no cemitério dos indigentes.

Era assim que as coisas sempre funcionavam no palácio. A vida de criadas e eunucos valia tanto quanto capim; seus senhores detinham por completo o poder de decidir quem vivia e quem morria.

*

Mais tarde, a Consorte Yun não foi ao Palácio Fengyi. Dirigiu-se diretamente à imperatriz.

Fora reivindicar o mérito pelo que fizera.

— Majestade, aquela escrava já está morta.

A imperatriz fechou os olhos e recitou uma invocação budista. — Eu só disse que ela se comportara mal e me ofendera. Pedi que lhe desse uma lição. Por que teve de matá-la?

Naquela manhã, quando convocara a Consorte Yun, deixara implícito em suas palavras que não queria mais ver Qiqi no palácio.

Mas já estava habituada a falar como uma santa e agir como uma víbora. A Consorte Yun, que dependia dela, também conhecia muito bem aquela falsidade.

— Ning foi promovida de repente a Consorte Nobre e ficou com toda a atenção. Era preciso fazê-la sofrer um pouco. Na verdade, mesmo sem o lembrete de Vossa Majestade, eu teria feito isso.

A imperatriz lançou-lhe um olhar de lado:

— O que você decidiu fazer é responsabilidade sua. Eu nunca lhe mandei tirar a vida de ninguém.

— Enfim, a pessoa já está morta. Não adianta mais falar. Mandem o Departamento de Assuntos Internos anunciar que foi um acidente e retirem o corpo do palácio para um enterro apropriado.

Enquanto isso, no Palácio Fengyi, Qiaqia, Lala e Bengbeng haviam enfeitado o pátio de maneira alegre e bonita.

Com recortes de papel cor-de-rosa, cobriram os galhos nus das árvores com flores de pessegueiro, as favoritas de Qiqi.

Bengbeng preparara pessoalmente uma mesa inteira de pratos deliciosos. Só esperava Qiqi voltar para que comemorassem seu aniversário com toda a alegria.

Mas ninguém imaginava que aquele aniversário se tornaria o dia de sua morte...

# Validação — capítulo 239

- **Fonte:** `novel_capitulos_212_a_270(20261105-204934).docx` (chinês tradicional).
- **Limites:** parágrafos reais do DOCX [1906, 1975), índice base zero.
- **Unidades não vazias incluindo título e notas:** 66.
- **Linhas de cotejo:** 66.
- **Índices ausentes entre as unidades não vazias:** 0.
- **Índices duplicados:** 0.
- **Campos chineses ou portugueses vazios:** 0.
- **Coerência formal CSV/Markdown:** cada tradução na ordem exata dos parágrafos.

## Decisões tradutórias

O título 血壓預警 foi adaptado como “Alerta de pressão alta”. A forma 佟嬪 foi mantida como Concubina Tong, distinguindo sua antiga posição de Consorte Nobre. A cena do palanquim não atribui à Qiqi intenção de ferir a Consorte Yun. A nota final “還有一章” foi preservada. O original alterna 琪琪 e 洽洽, mantidos como Qiqi e Qiaqia.

## Limitações

A conferência 1:1 demonstra correspondência estrutural, não constitui auditoria semântica independente integral. As escolhas literárias ainda podem ser refinadas em revisão especializada.

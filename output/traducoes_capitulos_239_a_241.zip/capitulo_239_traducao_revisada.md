# Capítulo 239 — Alerta de pressão alta

Naquela noite.

Com a aproximação do Ano-Novo, o clima começava a esquentar e a neve acumulada derretia aos poucos.

Desde que Gu Sijin saíra do palácio às escondidas, o Palácio Fengyi permanecia fechado. Havia a ordem de confinamento anteriormente imposta pela Concubina Tong e, além disso, Gu Sijin alegara estar doente. Ninguém queria se meter com aquele azar.

Qiqi, Qiaqia, Bengbeng e Lala até aproveitavam a liberdade. Sem as senhoras por perto, passavam os dias inventando pratos deliciosos e, nas horas vagas, reuniam-se para jogar cartas. Levavam uma vida bastante tranquila.

Entre eles, Qiqi era a mais parecida com Ning Xiaoxiao em temperamento: esperta, cheia de vivacidade, era naturalmente a alegria do grupo.

Tinham acabado de jogar cartas e, encantados com o luar, sentaram-se sob a varanda para tomar chá, contemplar a lua e sonhar com o futuro.

Qiqi apoiou o queixo nas mãos e fitou a lua com ar sonhador. — Amanhã, depois do meu aniversário, faço vinte e quatro anos. As criadas podem deixar o palácio aos vinte e cinco. Quando entrei aqui, aos quinze, achei que dez anos seriam uma eternidade. Agora vejo que passaram num piscar de olhos.

Qiaqia a invejou. — Eu ainda zombava de você por ser mais velha. No fim, a palhaça sou eu... Só fiz vinte e um no começo do ano. Ainda tenho uma longa espera pela frente~

Lala discordou: — Não é bem assim. Com senhoras tão boas, como podemos dizer que estamos penando? Nem os servos que atendem ao imperador têm uma vida tão confortável quanto a nossa~

Bengbeng entrou na conversa: — É verdade. A Nobre Dama Gu pensa em nós em tudo, e Xiaoxiao brincava conosco de igual para igual todos os dias, sem nunca nos tratar como escravos. Agora que Xiaoxiao se tornou Consorte Nobre e tem o favor do imperador, ninguém mais vai ousar humilhar ou maltratar o nosso Palácio Fengyi.

Enquanto falava, sua voz foi diminuindo, como se sondasse alguma coisa:

— Na verdade... de todos os anos que passei no palácio, os dias mais felizes foram os que passei trabalhando com vocês. Antes, achava que o coração de todo mundo aqui era gelado. Mas, depois de tanto tempo juntos, descobri que também é possível encontrar pessoas que retribuem a sinceridade com sinceridade.

— Há muito tempo considero vocês a minha família.

Enquanto dizia aquelas palavras melosas, seus olhos não paravam de procurar Qiqi às escondidas.

Ele gostava dela havia muito tempo. Até o burrinho azarado que lhe dera de presente acabara confiscado por Ning Xiaoxiao.

Mas, embora a amasse, não se atrevia a confessar. Afinal, ele não era um homem inteiro. Como poderia oferecer um lar completo à mulher que amava?

Eunucos não tinham direito a sentimentos nem desejos.

Pensando nisso, soltou um longo suspiro e forçou um sorriso:

— Que tal comemorarmos o aniversário de Qiqi amanhã? Vai ser o último aniversário que ela passará no palácio antes de sair.

Havia certa tristeza nessas palavras. Qiqi olhou discretamente para ele e percebeu seus olhos avermelhados.

Então se espreguiçou e disse, com preguiça: — Ah, mas eu não pretendo sair do palácio. Não tenho parentes. Lá fora ficaria sozinha, sem ninguém. Sair para quê? Prefiro continuar com vocês e servir às nossas senhoras para sempre.

Os outros a chamaram de boba. Só Bengbeng escondia um sorriso.

Mais tarde, quando todos se recolhiam para dormir, Qiqi chamou Bengbeng de repente: — Ei!

Ele se virou e coçou a nuca, meio sem jeito. — O que foi?

— Capriche no presente de aniversário que vai me dar amanhã! Está ouvindo?!

Bengbeng assentiu repetidas vezes, sorrindo todo abobalhado. — Uhum!

Ele já preparara o presente havia muito tempo: um requintado enfeite de cabelo com contas, incrustações de penas azul-esverdeadas e detalhes dourados.

Pedira a Xiao Yinzi que o comprasse na loja Caidiexuan, fora do palácio, gastando quatro meses inteiros de seu soldo.

De volta ao alojamento, tirou o enfeite e o limpou com todo o cuidado usando um papel fino. O sorriso não saiu de seu rosto um instante sequer.

*

No dia seguinte, Bengbeng levantou-se cedinho e chamou Qiaqia e Lala às escondidas para decorar o pátio e fazer uma surpresa de aniversário para Qiqi.

Quando ela terminou de se lavar e se arrumar, os três agiam de maneira misteriosa e não lhe contavam o que estavam fazendo.

Depois, alguém do Departamento de Assuntos Internos bateu à porta, anunciando que a imperatriz mandara distribuir os presentes de Ano-Novo e que alguém deveria ir buscá-los.

Qiqi comemorou: — Não poderia haver presente de aniversário melhor~ Quem vai comigo?

Os três queriam que ela saísse logo para começar a decoração. Por que iriam acompanhá-la?

Todos a apressaram: — Ah, vá logo! É só ouro, prata e coisinhas assim. Uma pessoa consegue trazer tudo. Para que ajuda?

Qiqi mostrou a língua e fez uma careta. — Humpf~ Quando nossas senhoras voltarem, vou contar direitinho como vocês vivem fazendo corpo mole~

Antes que saísse, Bengbeng a segurou e colocou o enfeite de cabelo em sua mão.

Qiqi ficou encantada. — Ah, que lindo~

Com o rosto vermelho, Bengbeng perguntou: — Então coloque para eu ver como fica.

Ela abriu um sorriso travesso. — Nem pensar~ — Aproximando-se do ouvido dele, murmurou, envergonhada: — Que tal você mesmo colocá-lo em mim hoje à noite, na festa do meu aniversário?

Bengbeng ficou sem palavras. Seu coração disparou.

Qiqi agitou o enfeite diante dele e deixou o palácio com um sorriso radiante.

No Departamento de Assuntos Internos, a distribuição dos presentes era generosa: folhas de ouro, pequenas peças de ouro e lingotes de prata, tudo na quantidade devida.

Como Ning Xiaoxiao acabara de ser promovida a Consorte Nobre, os funcionários foram especialmente solícitos. Disseram que entregariam pessoalmente os presentes destinados a ela quando voltasse ao palácio.

Qiqi seguia alegremente de volta com os presentes. Pouco depois de deixar o departamento, encontrou de frente o palanquim da Consorte Yun.

Correu para junto do muro e fez uma reverência respeitosa.

A cortina do palanquim estava aberta. Ao passar por Qiqi, a Consorte Yun lançou-lhe um olhar e ordenou subitamente que parassem:

— Que coincidência encontrá-la. Ouvi dizer que a Nobre Dama Gu está doente. Já melhorou?

— Respondendo à senhora Consorte Yun: a saúde de minha senhora se estabilizou um pouco. Obrigada pela preocupação.

— Ah, é? Como estou livre hoje, vou fazer-lhe uma visita.

Qiqi entrou em pânico.

Se a Consorte Yun fosse naquele momento ao Palácio Fengyi e descobrisse que Gu Sijin não estava lá, certamente usaria o fato contra ela.

Se o escândalo crescesse, Gu Sijin pagaria caro. Uma consorte deixar o palácio sem autorização não era uma infração pequena!

Por isso, Qiqi se apressou em argumentar:

— Senhora Consorte Yun, a Consorte Nobre... quer dizer, a Concubina Tong impôs há alguns dias uma ordem de confinamento ao Palácio Fengyi. As consortes não podem fazer visitas.

— Ora! — A Consorte Yun soltou um riso de desprezo. — Você mesma disse que Tong agora é apenas concubina. Como alguém dessa posição poderia dar ordens a mim? Vamos.

Ao ver que os carregadores estavam prestes a seguir para o Palácio Fengyi, Qiqi, desesperada, colocou-se diante do palanquim para barrá-lo.

Ela surgiu tão de repente que os carregadores se assustaram. Suas mãos vacilaram, o palanquim caiu e a Consorte Yun foi arremessada ao chão por acidente.

Os servos correram em massa para ajudá-la a se levantar. Na queda, ela arranhara a palma da mão, que começou a sangrar.

Percebendo que causara um desastre, Qiqi ajoelhou-se e bateu a testa no chão. — Perdoe-me, senhora Consorte Yun! Não foi de propósito...

Furiosa, a Consorte Yun apontou para ela e esbravejou:

— Sua escrava imunda! Quem você pensa que é para ousar impedir minha passagem?

— Bilian! Prenda-a!

(Tem mais um capítulo.)

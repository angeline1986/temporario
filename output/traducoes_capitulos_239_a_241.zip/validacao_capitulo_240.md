# Validação — capítulo 240

- **Fonte:** `novel_capitulos_212_a_270(20261105-204934).docx` (chinês tradicional).
- **Limites:** parágrafos reais do DOCX [1975, 2026), índice base zero.
- **Unidades não vazias incluindo título e notas:** 48.
- **Linhas de cotejo:** 48.
- **Índices ausentes entre as unidades não vazias:** 0.
- **Índices duplicados:** 0.
- **Campos chineses ou portugueses vazios:** 0.
- **Coerência formal CSV/Markdown:** cada tradução na ordem exata dos parágrafos.

## Decisões tradutórias

A nota inicial da autora foi integralmente mantida, inclusive o emoticon. A morte de Qiqi não foi suavizada nem transformada em acidente: a versão do acidente é uma mentira deliberada da Consorte Yun. As declarações da imperatriz foram mantidas com sua contradição intencional.

## Limitações

A conferência 1:1 demonstra correspondência estrutural, não constitui auditoria semântica independente integral. As escolhas literárias ainda podem ser refinadas em revisão especializada.

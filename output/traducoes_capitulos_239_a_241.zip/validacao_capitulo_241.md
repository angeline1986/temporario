# Validação — capítulo 241

- **Fonte:** `novel_capitulos_212_a_270(20261105-204934).docx` (chinês tradicional).
- **Limites:** parágrafos reais do DOCX [2026, 2085), índice base zero.
- **Unidades não vazias incluindo título e notas:** 56.
- **Linhas de cotejo:** 56.
- **Índices ausentes entre as unidades não vazias:** 0.
- **Índices duplicados:** 0.
- **Campos chineses ou portugueses vazios:** 0.
- **Coerência formal CSV/Markdown:** cada tradução na ordem exata dos parágrafos.

## Decisões tradutórias

A nota autoral sobre a montanha-russa foi preservada. O texto distingue a versão falsa recebida pelos criados da revelação obtida por Bengbeng. O conhecimento da imperatriz sobre a aliança política foi preservado como informação da narrativa, e não como confissão a Gu Sijin.

## Limitações

A conferência 1:1 demonstra correspondência estrutural, não constitui auditoria semântica independente integral. As escolhas literárias ainda podem ser refinadas em revisão especializada.

# Capítulo 241 — A morte de Qiqi (2)

(Hoje vou levar vocês numa montanha-russa.)

Gu Sijin foi trazida de volta ao palácio pela imperatriz no dia seguinte.

A primeira coisa que fez foi ir apresentar seus respeitos à imperatriz.

Vendo que os dias passados em casa com a família lhe haviam devolvido a boa aparência, a imperatriz sorriu: — Rever os familiares lhe fez bem. Você está radiante. Pelo menos valeu a pena eu correr tamanho risco para permitir que saísse do palácio.

Gu Sijin fez uma reverência respeitosa. — Agradeço a Vossa Majestade pelo cuidado. Só que... quanto aos assuntos da corte, falei com meu pai, mas ele teme que essa medida cause instabilidade política e não quis aceitar...

Curvou-se ainda mais, em atitude humilde e submissa. — Não fui capaz de cumprir sua vontade. Peço que Vossa Majestade me castigue.

A imperatriz a observou com olhos límpidos e um sorriso doce, como a água na primavera. Não demonstrava a menor intenção de censurá-la.

Na carta que Zhu Yunshan enviara à família, ele escrevera que Gu Yanchuan já tomara a iniciativa de formar uma aliança com ele, decidido a unir forças para derrubar Tong Guowei.

Como sabia disso, a imperatriz sorriu com benevolência. — O que está fazendo? Levante-se logo.

Xiangling ajudou Gu Sijin a se erguer. Então a imperatriz acrescentou: — Eu realmente me preocupo com você, por isso permiti que voltasse à casa de sua família. Falando assim, parece até que eu estava tramando alguma coisa contra você.

— Jamais ousaria pensar isso...

— Chega de formalidades. Sente-se. — A imperatriz pegou a xícara e tomou um gole de chá. — Já mandei entregar os presentes de Ano-Novo ao seu palácio. Faltam apenas dez dias para a festa, e será seu primeiro Ano-Novo aqui. Tudo o que as outras receberem, você também receberá. Ah, e tenho uma boa notícia para lhe contar.

Ela pousou a xícara e seu sorriso se alargou: — A Consorte Nobre insistiu em ir à estância de águas termais atrás do imperador. Não sei como o desagradou, mas, depois de apenas um dia lá, foi rebaixada à posição de concubina.

Gu Sijin não tinha interesse em saber o que a Concubina Tong fizera. Limitou-se a responder de maneira indiferente.

A imperatriz mudou de assunto: — Mas essa não é a boa notícia de que eu falava. A boa notícia é que a Concubina Hua recebeu uma promoção extraordinária do imperador e se tornou Consorte Nobre.

— Isso... — A alegria era impossível de esconder no rosto de Gu Sijin. — Nesse caso... tenho mesmo de parabenizar a senhora Consorte Nobre!

Se não se preocupasse com o constrangimento que uma promoção tão excepcional poderia causar à imperatriz, Gu Sijin teria dado uma gargalhada ali mesmo.

A imperatriz lhe contara aquilo de propósito para deixá-la feliz.

Quanto maior fosse a alegria dela naquele instante, maior seria o desespero ao retornar ao palácio e receber a notícia da morte de Qiqi.

— Muito bem. Você deve estar cansada da viagem e ainda veio conversar comigo assim que chegou. Volte logo para seu palácio e descanse.

*

No caminho de volta, Gu Sijin tirou da pequena bagagem uma pulseira.

Era feita de turmalinas engastadas em metal dourado, escolhida especialmente para Qiqi durante sua saída do palácio. Bastara vê-la para pensar em como combinaria com a moça.

Gu Sijin sempre se lembrava dos aniversários de todos os servos que a atendiam.

Além disso, sempre que alguma desgraça lhe acontecia, Qiqi era a primeira a se colocar à sua frente para protegê-la. Gu Sijin a tratava com o mesmo carinho que tivera por Ning Xiaoxiao quando esta ainda era uma criada.

Pensou que, agora que Xiaoxiao fora promovida a Consorte Nobre e os presentes de Ano-Novo anteriormente retidos haviam finalmente sido distribuídos, o Palácio Fengyi deveria estar em festa.

Mas, assim que abriu a porta, ouviu um choro baixinho e contínuo.

Qiaqia e Lala estavam sentadas diante do alojamento de Qiqi, no canto sudoeste do pátio. Abraçavam algumas roupas que a amiga costumava usar e choravam tanto que nem ouviram Gu Sijin entrar.

Sem saber o que acontecera, Gu Sijin se aproximou depressa e perguntou: — Por que estão chorando desse jeito? O que aconteceu?

Ao notar de relance as roupas que as duas abraçavam, sentiu um mau pressentimento crescer no peito.

Qiaqia ergueu o rosto banhado em lágrimas e soluçou: — Minha senhora... Qiqi não está mais aqui...

— Não está mais aqui? Como assim? — Gu Sijin não compreendeu de imediato. Seus olhos se encheram de espanto e dúvida. — Ela cometeu alguma falta e foi mandada como castigo para o Departamento de Trabalhos Forçados?

Lala chorou ainda mais. — Minha senhora... Qiqi morreu!

???

Aquelas palavras atingiram os ouvidos de Gu Sijin como um trovão abafado. Seus pés ficaram dormentes, ela cambaleou para trás e arregalou os olhos.

Lala explicou: — Ontem foi o aniversário dela. Como a imperatriz também distribuiu os presentes de Ano-Novo, Qiqi foi buscá-los no Departamento de Assuntos Internos. Só que se passaram duas horas e ela não voltou.

— Quando saímos para procurá-la, disseram no departamento que ela tropeçou por descuido, bateu a testa numa pedra e morreu na mesma hora...

Lutando contra a angústia que lhe subia pelo peito, Gu Sijin perguntou: — Chamaram um médico imperial? Se aconteceu alguma coisa, onde ela está? Onde está o corpo agora?

Qiaqia engoliu o choro antes de conseguir dizer: — Já a levaram para fora e enterraram...

Gu Sijin ficou paralisada. Depois de um breve silêncio, uma onda esmagadora de dor tomou conta dela.

Apertou os dentes, e lágrimas enormes transbordaram de seus olhos, ensopando a gola de suas roupas.

Como se a notícia impossível de aceitar lhe tivesse roubado todas as forças, recuou dois passos e se apoiou no tronco de uma árvore. A pequena bagagem com o presente de aniversário caiu de sua mão.

Desde que entrara no palácio, sempre que era espancada ou castigada, Qiqi era a primeira a correr para defendê-la.

Quando Gu Sijin não conseguia dormir, Qiqi lhe fazia companhia e conversava com ela. Também se esforçava para aprender a preparar os petiscos de sua terra natal, tentando de novo e de novo, até uma centena de vezes se fosse preciso, apenas para reproduzir um sabor parecido com o da comida de sua família e aliviar sua saudade.

Qiqi adorava sorrir. Passava os dias com um sorriso luminoso no rosto e tinha tantas esperanças para a vida. Nunca se entregava à amargura só por ser uma criada.

Como uma pessoa tão boa, alguém que Gu Sijin tratava como uma irmã mais nova, poderia simplesmente desaparecer? Antes de sua saída do palácio, Qiqi estava tão bem! Como podiam lhe dizer que ela se fora assim?

Qiaqia e Lala ficaram ao lado dela, pedindo que não se deixasse consumir pela tristeza a ponto de prejudicar a própria saúde.

Gu Sijin olhou em volta e não viu Bengbeng. Sempre soubera que ele gostava de Qiqi e temeu que, por causa da tragédia, fizesse alguma loucura. Perguntou depressa: — Onde está Bengbeng?

Mal terminou de falar, Bengbeng entrou no pátio, com o rosto desfeito e passos cambaleantes.

Em apenas uma noite, envelhecera de tanto sofrimento. Parecia exausto, com o olhar distante e confuso.

Ele perguntara aos servos que trabalhavam ao longo dos corredores entre o Departamento de Assuntos Internos e o Palácio Fengyi e conseguira descobrir o que realmente acontecera.

— Minha senhora... Qiqi não tropeçou nem bateu a cabeça por acidente. A Consorte Yun mandou espancá-la até a morte!

— Ontem, a Consorte Yun insistiu em vir ao Palácio Fengyi visitar a senhora. Qiqi teve medo de que descobrissem sua ausência e aquilo causasse problemas; por isso tentou impedi-la de vir. Só que os carregadores do palanquim perderam o controle e a Consorte Yun caiu. Ela descontou a raiva em Qiqi e mandou Bilian e os outros espancá-la até morrer...

Depois de dizer tudo, Bengbeng desabou emocionalmente e começou a chorar de maneira desesperada.

Seu pranto parecia vir do próprio inferno. Cada soluço penetrava no coração de Gu Sijin, como as garras de um demônio que o rasgassem repetidas vezes.

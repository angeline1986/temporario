# Capítulo 16 — O primeiro presente que o tirano lhe deu

Absurdo!

O maior absurdo debaixo do céu!

Ele, o soberano supremo de um império, acabara de ser usado como montaria?!

E por uma criada completamente maluca, ainda por cima...

Ning Xiaoxiao também se assustou ao perceber que o tirano acordara. Saiu depressa de cima dele e ficou ao lado da cama sem saber o que fazer. — Majestade, não se irrite! Esta serva... estava espantando os mosquitos para Vossa Majestade...

Até ela se sentia culpada de contar uma desculpa dessas.

O tirano se sentou e lançou-lhe um olhar enviesado, os olhos transbordando intenção assassina.

— Quem sabe da história vai dizer que estava espantando mosquitos. Quem não sabe vai achar que estava cavalgando em cima de mim!

Ao notar que ela escondia as mãos atrás das costas, repreendeu-a: — O que está escondendo aí? Mostre!

Ning Xiaoxiao reagiu depressa e abriu a palma da mão. Três fios negros de Lu Linyuan flutuaram até o chão. Ela então mostrou as mãos vazias diante dele. — Nada, nada! Veja, Majestade, não tenho coisa alguma!

【Os imperadores da Antiguidade só cortam os cabelos em ocasiões excepcionais, como o luto nacional. Se esse maldito imperador me vir segurando três fios do cabelo dele, vai mandar cortar minha cabeça!】

Hein?

Por que ela estava pegando meus cabelos sem motivo?

Será que pretende usá-los para algum feitiço ou maldição?

Muito bem. Quero ver o que essa feiticeira está tramando.

Lu Linyuan lançou-lhe um olhar cortante. — Pegue seu leque e vigie direito esta noite! Se ousar subir em cima de mim de novo, mando cortá-la ao meio pela cintura!

Dito isso, deitou-se outra vez, fechou os olhos e fingiu dormir.

No início, Ning Xiaoxiao ainda abanou o leque, fazendo de conta que espantava os mosquitos. Cerca de um quarto de hora depois, Lu Linyuan começou deliberadamente a respirar mais fundo e mais pesado para parecer adormecido.

Ning Xiaoxiao chamou bem baixinho, testando-o: — Majestade? Majestade?

Como ele não reagiu, ela jogou o leque de lado e resmungou em pensamento:

【Ser criada é mesmo não ter direito nenhum! E servir a um tirano que vive ameaçando matar os outros é azar para umas oito encarnações!】

【Melhor achar logo aqueles cabelos que caíram no chão e trocá-los pelo repelente. Senão, amanhã cedo, se um mosquito picar o imperador, minha cabeça estará em jogo de novo...】

Acendeu um acendedor tradicional de pavio e, ajoelhada no chão, procurou os três fios de cabelo caídos à luz fraca da chama.

Durante todo esse tempo, Lu Linyuan a observou discretamente, por entre as pálpebras semicerradas.

Quando encontrou os três fios, Ning Xiaoxiao juntou as mãos, acomodou-os na palma e as ergueu acima da cabeça com a maior solenidade, murmurando: — Três fios de cabelo por um espiral repelente!

Assim que terminou de falar, um clarão azul brilhou entre suas mãos e um espiral repelente surgiu em sua palma.

Lu Linyuan se considerava um homem de vasta experiência, mas nunca tinha visto nada parecido!

Então ela usara meus cabelos para pedir aos céus aquele objeto chamado “repelente”?

Lu Linyuan alisou os próprios cabelos, mergulhado em pensamentos...

Meus cabelos têm mesmo esse poder?

Ele continuou fingindo dormir. Ning Xiaoxiao acendeu o repelente, colocou-o ao lado da cama imperial e foi dormir confortavelmente no assento aquecido.

No começo, Lu Linyuan não fazia ideia da utilidade do tal repelente. Parecia apenas mais um incenso aromático, embora tivesse um cheiro esquisito.

Mas não demorou a descobrir suas vantagens.

Normalmente, quando tentava dormir, mosquitos voavam em torno dele, deixavam-lhe o corpo cheio de picadas e ainda zumbiam sem parar, impedindo-o de descansar.

Assim que acenderam aquele “repelente”, porém, os mosquitos daquela noite pareceram entrar em acordo: nenhum sequer chegou perto dele.

Lu Linyuan não pôde deixar de se maravilhar:

Seria aquele um tesouro concedido pelos imortais do céu?

Quero um desses para mim também!

Depois que Ning Xiaoxiao adormeceu, Lu Linyuan se sentou cuidadosamente na cama. Após uma breve luta consigo mesmo, tomou coragem e arrancou três fios do próprio cabelo.

Imitando os gestos dela, depositou-os na palma da mão e ergueu as mãos acima da cabeça, com toda a devoção:

— Três fios de cabelo por um espiral repelente!

Repetiu conscienciosamente aquilo que Ning Xiaoxiao havia pronunciado, como se decorasse um encantamento.

E não aconteceu absolutamente nada.

Ele franziu a testa. Será que não fui suficientemente devoto?

Mais uma vez!

— Três fios de cabelo por um espiral repelente!

Repetiu as palavras. Desta vez, além de o repelente não aparecer, uma rajada de vento entrou pela janela de treliça e levou embora os fios que segurava na palma, sem deixar vestígios.

Lu Linyuan caiu em si de repente e sentiu que devia estar ficando maluco.

Aquele truque de fazer objetos surgirem do nada provavelmente não passava de uma ilusão armada por Ning Xiaoxiao!

Foi então que ouviu Ning Xiaoxiao, adormecida no assento aquecido, murmurar:

— Mamãe...

Sua voz era muito baixinha e frágil, completamente diferente do jeito espalhafatoso e barulhento de sempre.

Lu Linyuan lançou-lhe um olhar distraído. Sob a luz suave e prateada da lua, sua pele parecia ainda mais clara e luminosa. Era, sem dúvida, uma jovem de beleza notável.

Sobrancelhas delicadamente arqueadas, olhos amendoados, nariz pequeno e arrebitado, lábios rosados e bochechas um pouco cheias: uma aparência tão adorável que ninguém suspeitaria dela.

Sem saber por quê, Lu Linyuan ficou admirando-a por algum tempo e viu uma lágrima cristalina, como uma pérola, escorrer pelo canto de seus olhos.

Ela parecia sonhar com alguma coisa muito triste.

— Mãe, estou com tanta saudade de você...

— Mãe, estou com saudade da sua comida...

Cavalo?

O que há de tão especial num cavalo para sentir saudade?

Ela ainda quer disputar a comida com um cavalo?

Que gosto estranho...

Lu Linyuan soltou um risinho de desdém e a deixou dormir, sem perturbá-la.

*

Na audiência da manhã seguinte, Lu Linyuan organizou os preparativos para enviar suprimentos de socorro às vítimas das enchentes no sul.

Ainda encarregou Wei Yan, comandante das tropas de infantaria, de escoltar a remessa. Mas, depois de ouvir os pensamentos de Ning Xiaoxiao na noite anterior, resolveu tomar precauções.

Após a audiência, convocou seus guardas de ferro mais leais, ordenou que se infiltrassem no grupo que transportaria os suprimentos e lhes deu instruções:

— Vigiem Wei Yan durante todo o trajeto. Se ele tentar alguma coisa ilícita no transporte dos suprimentos, matem-no ali mesmo, sem precisar consultar-me novamente.

Os guardas juntaram os punhos em saudação e responderam a uma só voz: — Cumpriremos as ordens de Vossa Majestade!

Resolvido o assunto, Lu Linyuan estava prestes a examinar os memoriais quando se lembrou de outra coisa e ordenou a Sanfu:

— Vá aos estábulos imperiais, escolha um bom cavalo e leve-o ao Palácio Zhongcui para a Dama Gu. Diga que é uma recompensa especial pelo serviço prestado a mim durante a noite passada.

— Ah, mas... — Sanfu mostrou-se constrangido. — Majestade, que gosto peculiar! Já ouvi falar em presentear uma consorte com ouro e joias depois de passar a noite com ela, mas é a primeira vez que vejo alguém mandar um cavalo...

Lu Linyuan lançou-lhe um olhar autoritário. — Chega de conversa! Faça o que mandei!

Sanfu assentiu freneticamente e ia sair quando Lu Linyuan o chamou de volta. — Ao entregar o cavalo, deixe claro que só Ning Xiaoxiao poderá cuidar dele. Mais ninguém. E quanto ao nome...

Um sorriso divertido apareceu em seu rosto. — Deixe que ela escolha também.

---

## Notas de tradução

- **Mamãe / cavalo:** em mandarim, 媽 (mā, mãe) e 馬 (mǎ, cavalo) têm pronúncia parecida, com tons diferentes. Lu Linyuan interpreta equivocadamente o que Ning Xiaoxiao murmura dormindo. A versão portuguesa conserva a troca de sentido na reação dele, mas não reproduz a semelhança sonora.

- **Dama Gu (顧答應):** 答應 é uma categoria de concubina de baixo escalão. A tradução emprega “Dama Gu”, sem confundi-la com consortes de posição superior.

- **Wei Yan:** a vigilância do comandante decorre do que Lu Linyuan ouviu dos pensamentos de Ning no capítulo anterior.

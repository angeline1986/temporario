# Capítulo 15 — Arrancar os cabelos do tirano até deixá-lo careca

Justamente quando Ning Xiaoxiao se felicitava por ter cumprido a missão do sistema, a voz de alerta de Xiao Qi soou de repente em sua cabeça:

【Bip, bip, bip! A missão foi considerada malsucedida.】

【Como a anfitriã acionou o botão Retroceder, o tempo inteiro voltou atrás. Portanto, a missão de enfiar o dedo na narina do tirano não foi concluída.】

【A anfitriã deverá concluir a missão em cinco minutos. Caso contrário, ela será considerada fracassada.】

Ning Xiaoxiao: 【??? Eu já enfiei o dedo lá, e você só me avisa agora?!】

Xiao Qi: 【Nossa, como a anfitriã é espertinha!~ É melhor não ficar explorando as falhas do sistema. Além de ter a missão invalidada e o prazo reduzido, você ainda pode ser punida!~】

Ou seja, tinha comemorado à toa.

Enquanto lia os memoriais sem prestar a menor atenção, lançou olhares furtivos às narinas do tirano e mergulhou em pensamentos.

Os mosquitos do verão eram um tormento; não paravam de zumbir junto aos ouvidos dela.

Ela fez um movimento distraído com a mão e esmagou um mosquito na palma.

Ao contemplar o cadáver do inseto, quietinho em sua mão, teve um estalo.

Aproveitando que o tirano descansava de olhos fechados e não lhe prestava atenção, colocou o mosquito morto na ponta do dedo e chamou, toda alarmada: — Majestade!

Lu Linyuan abriu os olhos, impaciente. — O que foi?

— Majestade, não se mexa!

Ning Xiaoxiao foi até ele na ponta dos pés, examinou cuidadosamente seu rosto e, sem qualquer aviso, enfiou o dedo em sua narina.

Vendo o rosto de Lu Linyuan escurecer de imediato, retirou depressa o dedo e exibiu diante dele o mosquito morto que trazia na ponta:

— Que mosquito atrevido! Ousou sugar o sangue imperial de Vossa Majestade! Felizmente, esta serva foi rápida e impediu que seu augusto corpo fosse importunado!

【Por que esse maldito imperador está me olhando assim? Ele não acredita? Minha atuação foi perfeita... Afinal, que pessoa normal sairia enfiando o dedo no nariz dos outros à toa?】

Acha mesmo que eu acredito?

Se eu acreditar nessa história, sou um perfeito idiota!

Lu Linyuan engoliu a raiva e espremeu um sorriso gelado. — Ah, é? Sua rapidez é realmente de abrir os olhos.

Ning Xiaoxiao: — Majestade, é muita gentileza sua!~

Lu Linyuan: — Seria um desperdício não aproveitar tamanho talento. No verão, esses insetos vivem me tirando o sono. A partir de hoje, quando eu me deitar, você virá caçar mosquitos para mim.

Ning Xiaoxiao: — ??? Mas, Majestade, eu...

— Psiu. — Lu Linyuan pousou o longo indicador nos lábios dela e arqueou a sobrancelha. — Se um mosquito me picar, você perderá a cabeça.

Ning Xiaoxiao: 【Desgraçado! Você acha que eu sou um sapo?!】

Quando Lu Linyuan retornou à câmara de dormir, Gu Sijin acabara de terminar uma série de corridas com os joelhos elevados.

Ela estava coberta de suor. Só então ele disse: — Suar ajuda a expulsar a doença mais depressa. Pronto, volte ao seu palácio e durma.

Gu Sijin respondeu entre arfadas: — Sim... Esta concubina agradece a Vossa Majestade...

Ao saberem que Gu Sijin passaria aquela noite com o imperador, as consortes dos diversos palácios praticamente todas enviaram gente para vigiar os movimentos do Palácio Chaoyang.

Quando os servos escondidos a viram sair com o rosto vermelho, os cabelos molhados de suor e completamente exausta, imaginaram uma noite de paixão arrebatadora.

Depois de anos no palácio, os criados se tornavam fofoqueiros de primeira. Ao contarem a história às senhoras, pareciam ter assistido a tudo debaixo da cama imperial: descreviam até os mínimos detalhes daquele suposto encontro, deixando as consortes furiosas de ciúme.

Depois que Gu Sijin partiu, quem sofreu foi Ning Xiaoxiao.

O tirano dormia tranquilamente, enquanto ela abanava os mosquitos ao lado da cama, obediente.

【Bip, bip, bip! Parabéns à anfitriã por concluir a missão “Enfiar o dedo na narina do tirano”! O índice de desvio da trama aumentou 1%, alcançando agora 5%. O sistema foi atualizado.】

【A função Loja de Conveniência foi desbloqueada! A anfitriã poderá comprar produtos para ajudá-la nas missões ou simplesmente aproveitar melhor a vida.】

Ning Xiaoxiao fechou os olhos e constatou que um botão de Loja de Conveniência realmente aparecera na parte inferior do documento.

Apertou-o e, com uma mudança de cenário em sua mente, surgiu uma loja repleta das mais variadas mercadorias.

Havia de tudo ali; praticamente qualquer coisa que quisesse podia ser comprada.

Para Ning Xiaoxiao, aquilo era uma verdadeira salvação!

Passar a noite inteira caçando mosquitos para o tirano acabaria com ela!

Mas, se comprasse um espiral repelente e o acendesse, resolveria o problema de uma vez!

Procurou rapidamente pela loja e, como esperava, encontrou um repelente em espiral.

No lugar do preço, apareciam duas palavras enormes: 【Três fios】.

Ning Xiaoxiao perguntou: 【Xiao Qi, o que significa esse “três fios”?】

Xiao Qi: 【Bem, anfitriã, para comprar mercadorias aqui também é preciso pagar. Mas nossa moeda não é ouro nem prata... São os cabelos do protagonista masculino.】

Ning Xiaoxiao: 【??? Então três fios de cabelo daquele imperador miserável compram um repelente? É isso?】

Xiao Qi: 【Isso mesmo!~】

Ning Xiaoxiao observou a cabeleira escura, espessa e lustrosa do tirano. Seus olhos brilharam de cobiça.

Aquilo ainda podia ser chamado de cabelo?

Era dinheiro vivo esvoaçando ao vento!

Hehehe. Pois hoje ela faria uma bela sessão de compras por vingança!

Começou a encher o carrinho da loja sem a menor moderação:

Comidinhas eram essenciais, não? A comida servida aos criados era péssima. Batatinhas, tiras apimentadas, biscoitos crocantes de arroz e sementes para beliscar: um saco cheio de cada!

Bebidas também! Com aquele calor, refrigerante geladinho era tudo de bom! Duas caixas para guardar!

E produtos para a pele? Creme facial, creme para os olhos, sérum, tônico e loção hidratante: um conjunto completo!

Absorventes da marca Sete Graus de Espaço também eram indispensáveis! As mulheres antigas usavam panos menstruais, abafados, quentes e nada higiênicos. Melhor levar dois pacotes!

...

Só quando os produtos que comprara quase formavam uma montanha ela se lembrou de que, a princípio, entrara na loja para comprar repelente para o tirano.

Com muita má vontade, pôs um único espiral repelente em cima da pilha.

Xiao Qi: 【Anfitriã, o valor total da compra é de 18.769 fios de cabelo do protagonista masculino.】

Ning Xiaoxiao respondeu com a maior generosidade: 【Eu te entrego um punhado! Se sobrar, fica de gorjeta! Se faltar, arranco mais!】

Dizendo isso, estendeu suas mãozinhas criminosas na direção de Lu Linyuan.

Hehehe. Dizem que ficar careca é a verdadeira prova de beleza masculina. Você é tão bonito... não deve se importar em perder os cabelos, certo?

Ela já tinha um plano: apertaria Pausar e arrancaria os cabelos do tirano sem qualquer preocupação.

Mas, quando tudo estava pronto e ela ia começar, Xiao Qi a interrompeu:

【Cof, cof. Anfitriã, cabelos arrancados enquanto o tempo estiver pausado não podem ser usados como pagamento. Por favor, empregue sua inteligência em algo útil e pare de procurar atalhos para levar vantagem...】

*Crac.*

Ouviu? Era o som de seus sonhos se estilhaçando.

Se não podia pausar o tempo, arrancar tantos cabelos acordaria Lu Linyuan, mesmo que ele estivesse dormindo, não?

De cabeça baixa, Ning Xiaoxiao devolveu as mercadorias às prateleiras e ficou apenas com o espiral repelente de três fios de cabelo.

Olhou para Lu Linyuan, que dormia profundamente, e de repente teve outra ideia:

Bastava serem cabelos do tirano! Não precisava arrancá-los!

Que adulto não perde uns fios de cabelo?

Ela começou a examinar minuciosamente o travesseiro do tirano e, depois de muito procurar, encontrou finalmente um fio.

Só que havia partes do travesseiro que não conseguia alcançar.

Então subiu sorrateiramente na cama do tirano, montou sobre ele e começou a vasculhar o travesseiro e a roupa de cama.

Lu Linyuan tinha o sono leve; qualquer movimento bastava para despertá-lo.

Ainda sonolento, sentiu algo se mexendo sobre seu corpo e abriu os olhos devagar.

Mal abriu os olhos e viu Ning Xiaoxiao montada sobre ele...

— O que está fazendo?!

---

## Notas de tradução

- **Loja de Conveniência:** o preço das mercadorias é cobrado em fios de cabelo de Lu Linyuan; não foi convertido em dinheiro convencional.

- **Sete Graus de Espaço (七度空間):** marca de absorventes mencionada no texto chinês, mantida como referência comercial adaptada.

- **YYDS:** gíria chinesa de internet equivalente a “é tudo de bom / é insuperável”, adaptada no diálogo interno da protagonista.

- **18769:** número original preservado como 18.769 fios de cabelo.

# Validação do capítulo 16

## Fontes e escopo

- Original primário: `novel_capitulos_1_a_60(20261103-131325).docx`, em chinês.
- Tradução produzida diretamente das unidades originais, não do EPUB.
- Unidades chinesas não vazias (incluído o título): **76**.
- Unidades portuguesas correspondentes: **76**.
- Correspondências sem tradução: **0**.
- Unidades fora dos limites do capítulo: **0**.
- Cotejo: `capitulo_16_cotejo.csv`, com todas as unidades originais preservadas em ordem.

## Conferência de conteúdo e continuidade

O imperador observa o aparecimento do repelente, tenta imitar a troca sem sucesso, confunde a palavra “mãe” com “cavalo”, desconfia de Wei Yan e envia um cavalo a Gu Sijin sob os cuidados de Ning.

- Conferência realizada com atenção a personagens, sujeitos, sequência causal, diálogos, números, negações e humor em todas as unidades.
- Nomes e sistemas preservados: Ning Xiaoxiao, Lu Linyuan, Xiao Qi, Sanfu, Gu Sijin; índice de desvio da trama; Pausar e Retroceder.
- Adaptações culturais e trocadilhos constam nas notas editoriais externas à narrativa.

## Pendências e limites

- **Não há unidades sem correspondência nem dúvidas textuais abertas identificadas nesta revisão.**
- Não foi realizada segunda leitura linguística por um revisor independente; portanto, o cotejo não garante que nenhuma nuance estilística ou erro semântico residual possa existir.
- A divisão segue as unidades não vazias do DOCX, não uma segmentação arbitrária de orações.

## Conclusão

**Aprovado no cotejo bilíngue por unidade e na revisão editorial realizada**, com os limites explicitados acima.

# Capítulo 17 — Ning Xiaoxiao: Imperador maldito, vai se ferrar!

Assim que Sanfu levou um cavalo castanho-avermelhado ao Palácio Zhongcui, todos se reuniram para vê-lo.

O animal mantinha a cabeça erguida com orgulho, a crina longa caindo pelo pescoço. Tinha enormes olhos castanhos, cílios longos e curvados, e pupilas tão límpidas que refletiam a imagem das pessoas.

Mesmo entre os cavalos do palácio, aquele era um exemplar belíssimo.

Ao ver Sanfu chegar, Cailian abriu imediatamente um sorriso e foi recebê-lo: — Ora, eunuco Sanfu! O que o traz aqui a esta hora?

Ela era especialista em bajular os poderosos. Como Sanfu gozava de grande prestígio junto ao imperador, dispensava-lhe uma atenção ainda mais exagerada.

— Que cavalo lindo!~

Ela estendeu a mão para acariciá-lo, mas Sanfu imediatamente a afastou com seu espanador. — Tire essas mãos imundas de perto dele! Onde está sua senhora? Mande-a vir receber o decreto imperial e agradecer a graça concedida.

Cailian segurou a mão dolorida, magoada. — Nossa senhora piorou da doença depois que voltou dos aposentos imperiais ontem. O médico recomendou repouso na cama. Ela acabou de tomar o remédio e adormeceu. Eunuco Sanfu, esse cavalo é um presente de Sua Majestade para nossa senhora?

Sanfu confirmou com um aceno: — Sua Majestade enviou este cavalo especialmente para a Dama Gu, em recompensa pelo serviço prestado ao imperador na noite passada.

Cailian ficou radiante. Chamou imediatamente Qiqi, Qiaqia, Bengbeng, Lala e os outros para se ajoelharem e baterem a testa no chão. — Nós, servos, agradecemos a imensa graça de Sua Majestade em nome de nossa senhora!

Sanfu ergueu o queixo e soltou um “hum” satisfeito. Quando todos se levantaram, acrescentou: — Já que sua senhora está doente, chamem Ning Xiaoxiao.

Naquele momento, Ning Xiaoxiao estava dentro dos aposentos, cuidando de Gu Sijin. Ao ouvir alguém chamá-la no pátio, respondeu prontamente e saiu.

Ao ver Sanfu com um cavalo, também achou a situação muito estranha.

Cailian falou com sua habitual maldade disfarçada: — Esse é um presente de Sua Majestade para nossa senhora! Uma recompensa imperial é a maior das honras. Ficar escondida lá dentro e não vir agradecer é uma falta de respeito. O que está esperando? Ajoelhe-se e agradeça!

Ning Xiaoxiao não suportava aquela pose arrogante de Cailian, que se escorava na posição alheia para intimidar os outros.

Queria avançar e rasgar a boca da mulher ali mesmo, mas, como o imperador de fato presenteara sua senhora, devia se ajoelhar e agradecer a graça imperial.

Por isso, ignorou a provocação e começou a dobrar os joelhos.

Para sua surpresa, Sanfu a segurou pelo braço e lhe disse, sorrindo: — Você não precisa se ajoelhar. Sua Majestade me encarregou de transmitir mais algumas palavras a você.

Sanfu servia Lu Linyuan desde a época em que ele ainda era príncipe; praticamente crescera ao lado dele.

A pessoa que melhor conhecia Lu Linyuan no mundo não era a imperatriz-viúva: era Sanfu.

Bastava um olhar de seu senhor para que Sanfu compreendesse o que ele queria dizer.

Em todos aqueles anos, nunca vira alguém ofender Lu Linyuan e continuar vivo e inteiro.

Ning Xiaoxiao fora a primeira. E não o ofendera apenas uma vez: testava os limites do imperador repetidas vezes.

Sanfu especulava que só havia uma explicação razoável para aquele comportamento tão fora do comum de Lu Linyuan: ele estava interessado em Ning Xiaoxiao.

Por isso, já a tratava como uma futura senhora, mostrando-se naturalmente humilde e respeitoso.

— Sua Majestade determinou que, embora o cavalo seja um presente para a Dama Gu, somente Ning Xiaoxiao poderá cuidar dele. Ninguém mais poderá tocar nem acariciar o animal. E, se acontecer alguma coisa com ele, suas cabeças estarão em risco!

— Eu? — Ning Xiaoxiao apontou para si mesma, sem acreditar.

【Esse imperador desgraçado levou um coice de burro na cabeça? Por que diabos me mandou um cavalo do nada? E ainda quer que eu cuide de tudo que ele come, bebe e faz de sujeira? Socorro, esse bichão fede demais!】

Ela não gostava do cavalo, mas o cavalo não tinha nada contra ela.

Pelo contrário: pareceu gostar dela logo de cara e se mostrou muito afetuoso.

A cabeça que antes mantinha tão erguida abaixou-se de repente quando Ning Xiaoxiao se aproximou, e o cavalo lhe deu uma lambida no rosto sem qualquer aviso.

Ao sentir aquela língua úmida se esfregando em sua face, Ning Xiaoxiao ficou horrorizada e enojada!

Ela tirou um lenço e esfregou as bochechas com força:

【Aaaaaah! Esse imperador fez isso de propósito! Será que matei a família inteira dele na vida passada para ele me torturar desse jeito?!】

Sanfu brincou: — Ora, parece que o cavalo gostou mesmo de você. Sua Majestade também ordenou que você lhe dê um nome. Escolha logo um, pois preciso avisar o imperador e depois registrar o nome nos estábulos imperiais.

Ainda precisava batizar o cavalo?

E depois contar o nome ao imperador maldito?

As engrenagens na cabeça de Ning Xiaoxiao giraram, e ela logo encontrou um “ótimo nome”.

Acariciou a crina do cavalo e fingiu pensar por um longo tempo antes de dizer: — Não consigo imaginar um nome muito bom. Mas ele come capim e vive correndo pela terra, com os cascos cheios de lama. Que tal chamá-lo de...

— Cao Ni Ma!

Sanfu: — ...

Todos os criados: — ...

Embora ninguém soubesse o que “Cao Ni Ma” significava, havia algo estranho naquelas palavras. Não soavam nada respeitosas.

Ning Xiaoxiao abafou uma risadinha e fez questão de acrescentar: — Eunuco Sanfu, ao contar o nome ao imperador, transmita também uma mensagem minha: diga que foi Sua Majestade quem me inspirou a escolher “Cao Ni Ma”.

Sanfu: — Muito bem. Se não há mais nada, vou me retirar!~

Cailian se curvou toda para acompanhar Sanfu até a saída, com um sorriso falso estampado no rosto. — Faça uma boa viagem, eunuco Sanfu!~

Mas Sanfu não lhe deu a menor atenção, do começo ao fim.

Qiqi, Qiaqia, Bengbeng, Lala e os outros rodearam Cao Ni Ma, admirando-o sem parar. Diziam que o cavalo era lindo e tinha uma presença imponente.

Cailian acabara de se humilhar bajulando Sanfu em vão. Ver os outros tão felizes juntos a deixou ainda mais furiosa, e ela começou a gritar:

— Saiam! Saiam daqui! O que estão fazendo todos em volta do cavalo? Nossa senhora está doente e vocês ainda têm vontade de rir? Dispersem!

Mal terminou de falar, ao passar por Cao Ni Ma, o cavalo deu um coice inesperado e a lançou direto num buraco ao redor de uma árvore.

Todos tentaram segurar o riso. Cailian soltava gemidos de dor: — Ainda estão rindo? Venham me ajudar a sair daqui!

Ning Xiaoxiao disse: — Nossa senhora precisará tomar remédio quando acordar. Vão prepará-lo para que esteja quentinho quando ela se levantar. Vou amarrar o cavalo no quintal dos fundos e já encontro vocês.

Os outros se dispersaram de uma vez. Assobiando, Ning Xiaoxiao conduziu seu querido Cao Ni Ma e passou tranquilamente diante de Cailian sem sequer olhar para ela.

*

Enquanto isso, no Palácio Chaoyang.

Sanfu compareceu diante do imperador para prestar contas: — Majestade, cumpri suas ordens.

Lu Linyuan estava ocupado examinando os memoriais e nem ergueu a cabeça. — Que nome ela deu ao cavalo?

Sanfu respondeu: — Ela disse “Cao Ni Ma”. E acrescentou que se inspirou em Vossa Majestade.

— E o que esse nome horroroso tem a ver comigo?... Cao Ni Ma? — Lu Linyuan repetiu algumas vezes aquele nome esquisito, balançando a cabeça.

— Deixa para lá. O que se poderia esperar de uma simples criada? Cao Ni Ma, então, será Cao Ni Ma.

---

## Notas de tradução

- **Cao Ni Ma / 草泥馬:** escrito como “capim, lama, cavalo”, remete ao meme chinês que soa como um insulto obsceno (肏你媽, “foda-se sua mãe”). Ning escolhe o nome deliberadamente para insultar o imperador sem que os outros compreendam. A transliteração mantém o nome e esta nota preserva o trocadilho.

- **Cailian:** o coice e a recusa dos demais em socorrê-la pertencem ao texto original; nenhuma punição extra foi acrescentada.

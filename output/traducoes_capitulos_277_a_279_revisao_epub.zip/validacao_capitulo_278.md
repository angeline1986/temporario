# Validação — capítulo 278

**Original chinês:** `novel_capitulos_271_a_300(20261106-202946).docx`

**Tradução-base em português:** `novel capitulos 271 a 300 - ch.epub` (EPUB, capítulo 278)

**Limites do capítulo no DOCX (base zero):** parágrafos 467–544.

**Unidades não vazias:** 75 no original; 75 no EPUB; 75 no cotejo; 75 no Markdown.

**Integridade estrutural:** correspondência posicional 1:1, incluindo título, marcadores e notas, sem índices repetidos. A distribuição no EPUB foi verificada antes da revisão.

**Intervenções explícitas:** 41 unidades com substituição editorial registrada pelo processo de revisão; outras unidades conservam o texto-base, com normalização limitada de termos e pensamentos quando aplicável.

## Pontos de atenção

- Os pensamentos internos entre 【 】 foram preservados, inclusive o contraste entre preocupação política de Ning e decisão de Lu.
- A sequência descreve Ying Shuang soltando a víbora; a picada e a reação de Qingzhu são fatos narrados, não boatos.
- O original retrata Qingzhu sugando a ferida; não constitui recomendação de primeiros socorros.

## Escopo e limites

A revisão confrontou as unidades com o original e corrigiu problemas identificados, especialmente divergências evidentes de sentido, pronomes e terminologia. A equivalência de contagem não é prova de equivalência semântica; não se afirma segunda auditoria semântica independente integral ou verificação literária exaustiva de cada oração. O EPUB é tradução-base, não prevalece sobre o chinês.

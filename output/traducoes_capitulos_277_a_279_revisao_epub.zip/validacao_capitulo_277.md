# Validação — capítulo 277

**Original chinês:** `novel_capitulos_271_a_300(20261106-202946).docx`

**Tradução-base em português:** `novel capitulos 271 a 300 - ch.epub` (EPUB, capítulo 277)

**Limites do capítulo no DOCX (base zero):** parágrafos 392–466.

**Unidades não vazias:** 72 no original; 72 no EPUB; 72 no cotejo; 72 no Markdown.

**Integridade estrutural:** correspondência posicional 1:1, incluindo título, marcadores e notas, sem índices repetidos. A distribuição no EPUB foi verificada antes da revisão.

**Intervenções explícitas:** 48 unidades com substituição editorial registrada pelo processo de revisão; outras unidades conservam o texto-base, com normalização limitada de termos e pensamentos quando aplicável.

## Pontos de atenção

- Revisão de gênero de Gu Sijin e Ning; fala de Gu sobre “flores” contém duplo sentido.
- O índice acumulado chega a 55% apenas depois da missão já concluída. A missão seguinte vale +10 pontos percentuais, com penalidade de -50% de vitalidade e hibernação.
- A expressão “mulher de 21” alude à idade do homem (Lu Linyuan), e não à de Ning; trocadilho preservado de modo interpretativo.
- O último parágrafo traz explicação autoral dos divisores * e ❤; mantida como paratexto.

## Escopo e limites

A revisão confrontou as unidades com o original e corrigiu problemas identificados, especialmente divergências evidentes de sentido, pronomes e terminologia. A equivalência de contagem não é prova de equivalência semântica; não se afirma segunda auditoria semântica independente integral ou verificação literária exaustiva de cada oração. O EPUB é tradução-base, não prevalece sobre o chinês.

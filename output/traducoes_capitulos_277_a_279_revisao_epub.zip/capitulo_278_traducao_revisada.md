# Capítulo 278 — Ying Shuang solta uma serpente contra a imperatriz-viúva

Ning Xiaoxiao praticamente tinha um ponto de interrogação gravado na testa:

【Não... ser imperatriz é algo que eu possa simplesmente decidir e pronto?】

【Só me dão um mês? E se eu não virar imperatriz, vão me pôr para hibernar?】

【Daqui a um mês já vai estar quase no verão! Hibernar uma ova!】

Xiao Qi: 【Hospedeira, por favor, reclame menos e se esforce mais. Tenho certeza de que cumprirá a missão no prazo. Já é tarde. Descanse bem, tchauzinho~】

O sistema viera e fora embora num instante, deixando Ning Xiaoxiao se revirando na cama, fazendo contas:

【A-Yuan pode até me conceder o posto de imperatriz um dia, mas em menos de um mês? Impossível, não é?】

【A corte está concentrando todas as forças contra Tong Guowei. Se irritarmos agora a família da imperatriz e a empurrarmos para o lado dele, só vamos piorar a situação.】

【Esse sistema maldito não consegue passar um dia sem implicar comigo!】

【Ah, que se dane. Não vou pensar nisso. Vou dormir!】

Ela sempre fora despreocupada e não costumava guardar preocupações.

Ela puxou o cobertor para se enrolar, virou-se para abraçar Lu Linyuan, fechou os olhos e adormeceu quase imediatamente.

Ao ouvir sua respiração se tornar gradualmente mais regular e seus murmúrios ocasionais durante o sono, Lu Linyuan abriu os olhos de repente.

Lu Linyuan, na verdade, não dormira.

Com sua doce e adorável esposa deitada ao seu lado, como ele poderia adormecer facilmente?

Mas, se ele não dormisse, Ning Xiaoxiao também não dormiria. E, enquanto ela estivesse acordada, ele queria continuar com ela sem parar.

Ele podia aguentar qualquer coisa; já sua esposa corria o risco de não suportar tantas investidas...

Por isso, para uma relação duradoura, era preciso moderação. Melhor fingir que dormia.

Nesse instante, as pontas dos dedos dele subiram pelo pescoço delicado de Xiaoxiao, centímetro por centímetro, até acariciar suavemente sua clavícula.

Ao ver a menina dormindo profundamente em seus braços, um sorriso foi se espalhando gradualmente pelo seu rosto:

Será que sua pequena tirana queria se tornar imperatriz dentro de um mês?

Hum... Nada muito difícil.

Bastava acelerar a queda da família Tong.

*

Na manhã seguinte, no Palácio Xianshou.

Ajoelhar-se diante da imagem de Buda, recitar sutras e queimar incenso todas as manhãs tornara-se um hábito arraigado da imperatriz-viúva.

Se ela não fizer isso por um dia, sente que algo está faltando.

Outra coisa tem estado um pouco estranha ultimamente.

Ou seja, ela frequentemente tem pesadelos, sonhando que seu filho, que morreu jovem, cresceu na vida após a morte.

Seu rosto, coberto de sangue e irreconhecível, aparecia diante dela, chorando.

Ele implorava que ela parasse de bater nele e poupasse sua vida.

Sempre que acordava desses sonhos, encontrava as roupas de dormir encharcadas de suor.

Ela sentia que o motivo pelo qual era atormentada por pesadelos todos os dias estava definitivamente relacionado a Ying Shuang.

No terceiro dia do Ano Novo Lunar, Ying Shuang quebrou acidentalmente um ruyi de jade enquanto limpava o salão lateral.

O *ruyi* de jade fora obtido pela imperatriz-viúva com um monge eminente do templo Liuyun, fora do palácio; supostamente atraía a boa sorte e afastava desgraças.

Se qualquer outro servo do Palácio Xianshou tivesse quebrado isso, a Imperatriz Viúva teria cortado sua cabeça na hora.

Infelizmente, Ying Shuang foi enviado pessoalmente a ela por Lu Linyuan, então ela não pôde matá-lo. Portanto, ela fez com que Qingzhu tentasse de todas as maneiras atormentar Ying Shuang todos os dias, não o deixando morrer, mas espancando-o até que ele estivesse coberto de feridas, piores que a morte.

"Ah! Ah! Não me bata..."

Nesse instante, os gritos lamentáveis de Ying Shuang chegaram aos ouvidos da Imperatriz Viúva. Ela sorriu calmamente, não achando o som nada incômodo, e até mesmo o considerou um tanto agradável.

'Rangido'

— Imperatriz-viúva, aquele sujeito não suportou o castigo e desmaiou — informou Qingzhu.

— Por hoje, chega de espancá-lo. Deixem-no vivo, ou não teremos o que dizer ao imperador.

Qingzhu: "Sim. Majestade, o tempo está ensolarado hoje. Depois da chuva, muitos botões de flores desabrocharam no Jardim Imperial. A senhora não saiu do palácio nos últimos três dias. Que tal eu acompanhá-la em um passeio pelo Jardim Imperial?"

A Imperatriz Viúva respirou fundo. Depois da chuva, o ar estava impregnado com o aroma de grama fresca, refrescante e agradável, que transmitia uma sensação de relaxamento.

Depois de tanto tempo enclausurada, talvez lhe fizesse bem caminhar um pouco.

Ela aceitou a sugestão de Qingzhu, trocou de roupa e saiu com ela.

Ying Shuang se escondeu em seu quarto lateral, espiando pela fresta da janela em forma de diamante.

Ying Shuang estava coberto de feridas; a imperatriz-viúva mandara arrancar suas cascas e jogar água salgada sobre elas, torturando-o até ele desejar a morte.

O sofrimento que ele suportou no Palácio da Fênix não foi menor do que o sofrimento que suportou enquanto estava aprisionado por Lu Linyuan na masmorra.

Às escondidas, amaldiçoara Lu Linyuan e a imperatriz-viúva incontáveis vezes. Chamava-os de mãe e filho venenosos e desejava que um raio fulminasse os dois.

Ele mancava ao lado da cama e tirou um saco de estopa debaixo da cama de madeira.

De tempos em tempos, era possível ouvir sons sibilantes vindos de dentro da sacola, o que era assustador.

Há alguns dias, a Imperatriz Viúva o castigou, obrigando-o a varrer o Jardim Imperial. O inverno passou e a primavera chegou, época em que as serpentes abundam no palácio.

Como os senhores dos palácios só costumavam ir admirar as flores por volta do segundo mês, o Departamento de Flores e Pássaros normalmente começava a retirar as serpentes do jardim no fim do primeiro mês lunar.

Quando Ying Shuang foi ao Jardim Imperial, por acaso capturou uma víbora.

Sabendo que era venenosa, Ying Shuang a capturara para soltá-la no quarto da imperatriz-viúva e matá-la com uma picada.

Para isso, ao buscar as roupas da imperatriz-viúva na lavanderia, untara-as com o sumo de uma erva que atrai serpentes.

Infelizmente, ele nunca teve permissão para entrar no palácio da Imperatriz Viúva, razão pela qual não conseguiu encontrar uma oportunidade para fazer sua investida.

Agora que a imperatriz-viúva saíra, talvez surgisse a oportunidade perfeita.

Enviado ao Departamento de Assuntos Internos para buscar sachês repelentes de insetos, ele seguiu a imperatriz-viúva até o Jardim Imperial.

Enquanto ela se distraía admirando a paisagem, Ying Shuang libertou a víbora da sacola de estopa.

Ao sentir o cheiro da grama que atrai cobras, a víbora ficou imediatamente enfeitiçada e atacou diretamente a Imperatriz Viúva.

Ninguém notou a 'coisinha' aos seus pés até que ela mordeu com força o tornozelo da Imperatriz Viúva, fazendo-a gritar de dor, momento em que todos entraram em pânico.

"Cobra! Tem uma cobra ali!"

"A Imperatriz Viúva foi mordida por uma cobra! Depressa, chamem o médico imperial!"

Após morder a Imperatriz Viúva, a víbora ficou tão assustada com as exclamações da multidão que se escondeu nos arbustos e desapareceu.

Qingzhu se agachou e reconheceu de imediato uma picada de serpente venenosa.

Leal à imperatriz-viúva, Qingzhu se abaixou sem hesitar e sugou o sangue da ferida com a boca.

A imperatriz-viúva tinha aparência feroz, mas pouca coragem. Apavorada, soltou um som estranho e desmaiou ali mesmo.

Depois que Qingzhu sugou o que pôde da ferida, mandou levar a imperatriz-viúva de volta ao Palácio Xianshou.

Ying Shuang, que vinha observando a cena em silêncio à margem, exibiu um sorriso sinistro.

Ele não poderia estar mais feliz com a ideia de a Imperatriz Viúva ser envenenada até a morte; quanto mais horrível a morte, melhor!

Se ela morresse, Lu Linyuan certamente ficaria arrasado — era nisso que Ying Shuang acreditava.

Só de imaginar Lu Linyuan chorando a morte dela, Ying Shuang se enchia de satisfação.

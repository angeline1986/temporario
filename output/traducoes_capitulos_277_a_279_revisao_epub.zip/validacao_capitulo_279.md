# Validação — capítulo 279

**Original chinês:** `novel_capitulos_271_a_300(20261106-202946).docx`

**Tradução-base em português:** `novel capitulos 271 a 300 - ch.epub` (EPUB, capítulo 279)

**Limites do capítulo no DOCX (base zero):** parágrafos 545–606.

**Unidades não vazias:** 59 no original; 59 no EPUB; 59 no cotejo; 59 no Markdown.

**Integridade estrutural:** correspondência posicional 1:1, incluindo título, marcadores e notas, sem índices repetidos. A distribuição no EPUB foi verificada antes da revisão.

**Intervenções explícitas:** 36 unidades com substituição editorial registrada pelo processo de revisão; outras unidades conservam o texto-base, com normalização limitada de termos e pensamentos quando aplicável.

## Pontos de atenção

- 宋院判 indica o diretor/chefe da Academia Médica Imperial; não significa “juiz” nem “canção”.
- A proposta de remédio com sangue consanguíneo faz a imperatriz-viúva recusar o sangue de Lu: ela sabe que não há parentesco biológico.
- Ao fim, o diretor Song admite obedecer às ordens de Lu; não apresentar a lesão permanente como simples efeito não intencional do veneno.
- A ironia de “devoção filial” na cena final foi mantida.

## Escopo e limites

A revisão confrontou as unidades com o original e corrigiu problemas identificados, especialmente divergências evidentes de sentido, pronomes e terminologia. A equivalência de contagem não é prova de equivalência semântica; não se afirma segunda auditoria semântica independente integral ou verificação literária exaustiva de cada oração. O EPUB é tradução-base, não prevalece sobre o chinês.

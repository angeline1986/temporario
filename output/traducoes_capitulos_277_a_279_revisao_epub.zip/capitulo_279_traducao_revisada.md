# Capítulo 279 — Mas que filho exemplar você é, hein, mãe?

Com a imperatriz-viúva ferida, os médicos mais experientes da Academia Médica Imperial foram convocados às pressas.

O diretor Song, acompanhado de vários médicos imperiais veteranos, correu ao Palácio Xianshou.

Quando chegaram, a Imperatriz e as outras já estavam lá. Cercaram a Imperatriz Viúva, consolando-a enquanto ela continuava a lamentar-se.

A Imperatriz segurou firmemente a mão da Imperatriz Viúva, seus olhos de fênix cheios de lágrimas. "Majestade, fique tranquila, a senhora tem se dedicado ao budismo por muitos anos e sempre foi bondosa. Buda certamente a protegerá e a manterá sã e salva."

— Diretor Song! Depressa, venha examinar a imperatriz-viúva!

O diretor Song pediu que as consortes se afastassem do leito: — Majestade, por favor, peça às senhoras dos outros palácios que recuem. Todas reunidas ao redor da cama impedem a circulação do ar e prejudicam a imperatriz-viúva.

Só depois que todos saíram, ele começou a verificar o pulso da Imperatriz Viúva.

Qingzhu explicou o ocorrido. Depois de examinar a paciente, o diretor Song pareceu um pouco mais tranquilo:

— Felizmente, Qingzhu sugou o sangue da ferida imediatamente. Além disso, no início da primavera, as serpentes acabaram de sair da hibernação e, após a primeira caçada, têm pouco veneno armazenado. Por isso, a quantidade de veneno que entrou no corpo da imperatriz-viúva não é tão grave.

Ao ouvir isso, a Imperatriz Viúva, que momentos antes estava gemendo, sentiu-se instantaneamente muito melhor, e seus olhos, antes sem brilho, recuperaram o viço. "É verdade? Então estou bem?"

— Não significa que esteja completamente livre de problemas, mas sua vida não corre perigo. Ainda assim, a desintoxicação pode deixar sequelas. É melhor que Vossa Majestade se prepare...

A imperatriz-viúva apertou o cobertor. — Fale!

— O tratamento habitual consiste em expulsar o veneno com medicamentos e aplicar suco de ervas sobre a ferida. Mas a picada foi no tornozelo, região de circulação intensa, e o veneno começou a se espalhar. Mesmo eliminando todo o resíduo, receio que Vossa Majestade tenha dificuldade para caminhar daqui para a frente.

A Imperatriz Viúva, cujo estado de saúde havia acabado de melhorar, imediatamente começou a gemer novamente...

A Consorte Duan perguntou: — Diretor Song, quer dizer que a imperatriz-viúva poderá ficar com dificuldades de locomoção? Mas...

A imperatriz interveio: — Tenho a impressão de que o diretor Song ainda não nos contou tudo. Existe algum outro tratamento?

O diretor Song hesitou. — Existe, mas... está registrado no *Registro de Shennong* como a “Fórmula de Sangue Condutor”. É preciso usar sangue de um parente consanguíneo como ingrediente principal. E... a quantidade necessária é considerável.

A Consorte Duan exclamou: — Um parente de sangue? Mas o único parente consanguíneo da imperatriz-viúva não é Sua Majestade? Isso exigiria retirar sangue do imperador para...

Durante esse período, embora o relacionamento entre Lu Linyuan e a Imperatriz Viúva tenha melhorado um pouco, mãe e filho não conseguiram esquecer completamente seus conflitos passados.

A Imperatriz, sempre hábil em lidar com situações sociais, mesmo depois de o Médico Imperial Song ter afirmado claramente que apenas o sangue de um parente consanguíneo poderia curar a doença, ainda assim se esforçou ao máximo, perguntando:

"Tem que ser o sangue do Imperador? Não pode ser o meu?"

O diretor Song balançou a cabeça, constrangido. — Majestade, precisa ser sangue de um parente consanguíneo. Caso contrário, o remédio não só deixará de funcionar como poderá agravar o envenenamento e até pôr a vida da imperatriz-viúva em risco!

— Mas... como pode ser?

'Clang'

A porta do quarto imperial foi aberta com violência, e Lu Linyuan correu para lá, com o rosto tomado pela preocupação com a Imperatriz Viúva.

Ele caminhou rapidamente até o leito, tomou a mão da imperatriz-viúva e compôs uma bela cena de afeto entre mãe e filho:

— Como está se sentindo, mãe?

A Imperatriz Viúva não conseguiu conter as lágrimas ao pensar que poderia ficar inválida no futuro.

Lu Linyuan, “incapaz” de suportar o sofrimento dela, ordenou imediatamente ao diretor Song:

— Tirem meu sangue! Agora mesmo! Quanto for necessário para tratar minha mãe!

Ele arregaçou a manga e praticamente enfiou o braço diante do médico.

As consortes louvaram a “devoção filial que comovia os céus” de Lu Linyuan.

Apenas a Imperatriz Viúva entrou em pânico...

Como o diretor Song acabou de afirmar, o ingrediente medicinal deve ser sangue de um parente consanguíneo do próprio paciente. Caso contrário, o uso do medicamento pode resultar em morte.

Ela sabia perfeitamente que Lu Linyuan não era seu filho biológico. Como poderia aceitar sangue dele para preparar o remédio?

Então ela se sentou abruptamente na cama e disse emocionada:

— Não! O imperador é o Filho do Céu! Como poderiam ferir seu corpo? Mesmo que minha perna fique inutilizada, não permitirei que retire sangue do imperador para me curar!

Lu Linyuan afagou-lhe as costas. — Mãe, não se preocupe. Sou jovem e saudável. Perder um pouco de sangue não me fará mal. Sua saúde é tudo o que desejo.

— Não! O imperador está sendo imprudente! Seu corpo representa a prosperidade da dinastia Qi. Ferir o soberano é ferir o destino do reino. Como poderia sacrificar o destino de Qi para me tratar? Se isso acontecer, eu me tornarei uma pecadora perante toda a dinastia!

A Imperatriz Viúva estava extremamente agitada, e a Imperatriz e outras concubinas tentaram confortá-la, dizendo que ela estava pensando demais.

No entanto, ela foi categórica, afirmando que mesmo se ficasse aleijada, jamais permitiria que Lu Linyuan usasse seu sangue para tratar sua doença.

Lu Linyuan, “sem conseguir dissuadi-la”, acabou cedendo a contragosto e deixou que ela ficasse manca.

Mais tarde naquele dia, o médico Song tratou a Imperatriz Viúva usando métodos médicos comuns.

Antes do tratamento, a Imperatriz Viúva ainda tinha sensibilidade na perna esquerda. No entanto, após ingerir o remédio para remover o veneno da cobra e receber acupuntura, sua perna esquerda ficou anormalmente rígida, e ela só conseguia mancar ao sair da cama, sem forças para se levantar.

Ela realmente ficou manca.

A noite cai. Palácio de Chaoyang.

Enquanto Ning Xiaoxiao se banhava, Sanfu avisou que o diretor Song fora ao palácio informar o imperador sobre o estado da imperatriz-viúva.

Lu Linyuan foi até o corredor lateral para vê-lo.

Ao vê-lo, o diretor Song prestou uma reverência respeitosa: — Majestade, fizemos tudo conforme suas ordens. A perna da imperatriz-viúva... nunca mais terá os movimentos normais.

Lu Linyuan permaneceu em silêncio, brincando com um terço de turmalina que a Imperatriz Viúva lhe dera certa vez.

— Você comanda toda a Academia Médica Imperial. Confio que, se alguém voltar a examinar a imperatriz-viúva, todos darão a mesma versão dos fatos.

Uma camada fina de suor surgiu na testa do diretor Song. — Naturalmente, Majestade. Minha posição se deve inteiramente ao seu apoio. Jamais esquecerei essa dívida.

"Está bem, pode ir agora."

Após a saída do diretor Song, Lu Linyuan apertou o rosário budista com mais força e o atirou displicentemente pela janela, na lama.

Por enquanto, ela apenas perdera o movimento normal de uma perna. Não havia pressa.

Nos próximos dias, ele iria visitá-la com frequência, conversar e aliviar sua tristeza.

Não podia permitir que ela se desesperasse a ponto de fazer alguma loucura. Precisava continuar viva para que ele tivesse muitas outras oportunidades de “cuidar” dela com toda a devoção filial.

Ela precisava continuar viva para que ele ainda tivesse a oportunidade de “honrá-la” como uma mãe merece — com toda a sua ironia cruel.

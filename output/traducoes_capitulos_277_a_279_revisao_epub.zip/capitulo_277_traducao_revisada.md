# Capítulo 277 — Nova missão: tornar-se imperatriz

O comportamento um tanto ambíguo do casal foi testemunhado por Gu Sijin, que tinha vindo procurar Ning Xiaoxiao.

As duas tinham combinado de admirar as flores naquele dia. Ao prestar cumprimentos à imperatriz pela manhã, Gu Sijin não vira Ning Xiaoxiao. Soubera também que Lu Linyuan faltara à audiência da corte e, preocupada com a possibilidade de algo ter acontecido, fora procurá-la.

Mas o casal não tinha problema algum. Estavam apenas como recém-casados, grudados um no outro além da conta.

Gu Sijin, percebendo a situação, fez uma reverência e se virou para escapar.

Ning Xiaoxiao a via como uma salvadora, então por que a deixaria ir tão facilmente?

Ela correu apressadamente para o lado dela, pegou em seu braço e se escondeu atrás dela, espiando Lu Linyuan com metade da cabeça:

— Ah, é verdade! Eu e minha irmã combinamos de admirar as flores hoje cedo. Já que Sua Majestade não vai à audiência da corte, encontre alguma coisa para fazer. Nós vamos indo, tchauzinho~

Ela achou que assim conseguiria escapar, mas Gu Sijin, aquela “assassina do harém”, empurrou-a de volta, direto para os braços de Lu Linyuan.

"Irmã mais velha?"

Gu Sijin fez uma expressão de desgosto deliberadamente e provocou:

— Não venha comigo. Se você for embora, como Sua Majestade vai poder “admirar as flores”?

Ning Xiaoxiao: “...”

Lu Linyuan: “???”

Ao ouvir isso, o rosto de Ning Xiaoxiao ficou vermelho como um tomate.

Lu Linyuan também ficou surpreso. Afinal, quanto Ning Xiaoxiao teria “corrompido” uma dama de boa família como Gu Sijin para ela soltar uma insinuação daquelas?

"Irmã! Você está zombando de mim..."

Gu Sijin sorriu, mas a ignorou, erguendo uma sobrancelha para Lu Linyuan e sussurrando:

— Força, Majestade! Daqui para a frente, é com o senhor!

Dito isso, ela se virou e foi embora, fechando atenciosamente a porta do palácio atrás de si.

Essa foi a primeira vez que ela deixou de se referir a si mesma como concubina na frente de Lu Linyuan e passou a usar o termo "eu".

Quanto melhor Lu Linyuan tratava Ning Xiaoxiao, mais feliz ela se sentia.

Ela ficou feliz por nunca ter se apaixonado pelo mesmo homem que sua melhor amiga e, depois, como as outras mulheres do harém, terem se voltado umas contra as outras e incriminado umas às outras por causa do amor.

Ela também se alegrava porque a pessoa que amava continuava à sua espera.

Lu Linyuan atraiu o olhar de Ning Xiaoxiao de volta para si e riu baixinho, com uma voz rouca e baixa: "Os reforços já foram embora, para onde você pensa que vai fugir?"

Ele agarrou a cintura de Ning Xiaoxiao, e a coelhinha se debateu e se contorceu em vão, então não teve escolha a não ser admitir a derrota.

Mas ela não ia deixar que ele levasse toda a vantagem de graça!

Ning pensou: 【De qualquer forma, ele e a pequena Gu nunca mais vão ter nada. Por que não aproveitar para pedir que ele liberte Gu Sijin e a entregue em casamento a Chu Xingran? Assim não preciso vê-la todos os dias, deprimida como uma esposa abandonada...】

Os olhos de Ning Xiaoxiao brilharam de expectativa quando ela o encarou: — Eu até posso fazer o que A-Yuan quer, mas primeiro você precisa me prometer uma coisa.

"Hum." Lu Linyuan assentiu levemente. "Diga-me, e eu concordarei com qualquer coisa que você pedir."

— É mesmo? E se eu pedir que dê uma das suas mulheres a outro homem?

*Pá!*

Antes que ela acabasse a frase, Lu Linyuan deu um tapinha de leve em seus lábios, fingindo severidade:

— A única mulher que tenho é você. Não vou entregá-la a ninguém!

— E não é só que eu não vá entregá-la: se alguém ousar pôr a mão em você, mando picá-lo e dá-lo aos cães!

Ning Xiaoxiao estava ao mesmo tempo divertida e exasperada. "Que bobagem você está falando? Eu quis dizer..."

— Nem precisa terminar. Se você me pedir para mandar a imperatriz para a África, eu concordo.

Ning Xiaoxiao: “!!!”

【Será que esse homem está mesmo me ouvindo?!】

Quando ela estava prestes a reconduzir a conversa ao assunto principal, o sorriso de Lu Linyuan desapareceu e ele disse em tom sério:

— Chu Xingran e Ren Duanli são como irmãos para mim, mais próximos até do que irmãos de sangue. Ren Duanli ficou com meu irmão mais novo, e eu permiti.

— Então, Xiaoxiao, você acha que eu negaria a Chu Xingran a pessoa que ele ama?

Ning Xiaoxiao foi pega desprevenida. — Então A-Yuan... sabia desde o começo?

"Você quer saber?" Lu Linyuan exibiu um sorriso malicioso, baixando deliberadamente a voz: "Venha comigo para a cama, e eu lhe contarei devagar."

Após dizer isso, ele a pegou no colo e a levou em direção ao salão interno.

Ela mal terminara o mingau de frutos do mar, e os pãezinhos de camarão ainda estavam intocados na mesa. Debatendo-se nos braços de Lu Linyuan, gritou:

— Os pãezinhos!

— Meus pãezinhos de camarão!

Lu Linyuan deixou-a se remexer em seus braços, carregou-a de volta para o quarto e, em seguida, fechou a porta com os dedos dos pés.

— Comporte-se. Daqui a pouco vou lhe dar algo ainda mais gostoso.

*

Um vezes um é um, dois vezes dois são quatro, três vezes três são nove.

E nove vezes nove? É hora de voltar ao um. Portanto, foram nove vezes.

Ser gente é difícil. Ser mulher é difícil. Ser mulher de um homem de 21 anos é mais difícil ainda!

Depois que Lu Linyuan adormeceu, Ning Xiaoxiao ficou estirada na cama como um peixe fora d’água, repassando os acontecimentos surreais dos últimos dois dias.

Pensando bem, tirando o desconforto do começo, a noite anterior não fora tão insuportável quanto ela imaginara.

Lu Linyuan prestara bastante atenção ao que ela sentia, parando constantemente para perguntar se estava tudo bem.

Os dois haviam aprendido às apalpadelas, como quem atravessa o Rio Amarelo sondando as pedras: erravam, tentavam de novo e, aos poucos, ganhavam confiança, até descobrirem novas maneiras de ficar juntos.

Ning se lembrava de Xiao Qi dizer que, quando ela fizesse algo “impróprio”, a Agência de Administração do Espaço-Tempo o desligaria automaticamente para impedir que o sistema aprendesse maus hábitos.

Agora que tudo terminara, a julgar pelas experiências anteriores, Xiao Qi já devia aparecer para anunciar a conclusão da missão.

Como esperado, pouco depois aquela voz familiar ecoou em sua mente:

【Bip, bip, bip~ Parabéns, hospedeira, por cumprir a missão “Comemorar o aniversário da Concubina Tong e fazê-la passar a maior vergonha da vida”. Recompensa: +5 pontos percentuais no índice de desvio da trama. Total acumulado: 55%.】

Ning Xiaoxiao: 【Hoje você foi bem pontual~】

Xiao Qi resmungou baixinho: 【Claro! Se eu não fosse pontual, sua mãe acabaria me cozinhando...】

Ning Xiaoxiao: 【Hã? O que você disse?】

【Nada, nada...】 Xiao Qi desconversou: 【Consegui uma nova missão para a hospedeira. Deseja aceitá-la?】

Ora, quando não aparecia uma missão, não vinha nenhuma; quando aparecia, vinha uma atrás da outra sem parar!

Ning Xiaoxiao: 【Que missão?】

Xiao Qi: 【Bip, bip, bip~ Parabéns, hospedeira! Você recebeu uma missão de dificuldade infernal: “Tornar-se imperatriz dentro de um mês”.】

【Recompensa em caso de sucesso: +10 pontos percentuais no índice de desvio da trama. Em caso de fracasso: perda de 50% da vitalidade e entrada imediata em hibernação~】

Ning Xiaoxiao: 【??? Você está bem da cabeça?!】

(Deixe-me explicar: daqui em diante, os asteriscos indicam que vou seguir a história principal e os corações indicam que vou acompanhar o romance do casal principal ou secundário.)

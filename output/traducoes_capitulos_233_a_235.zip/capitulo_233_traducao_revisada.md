# Capítulo 233 — Quando vai bagunçar a minha cama?

Palácio Fengluan.

Dias antes, a imperatriz havia adotado uma arara, que usava para se distrair nas horas vagas.

Já passavam seis quartos de hora da meia-noite, mas ela não tinha ido dormir. Estava alimentando a ave com sementes de girassol cruas.

Cantarolava baixinho, aparentemente de excelente humor.

Xiangling voltou de sua incumbência para prestar contas: — Vossa Majestade, a Nobre Dama Gu já foi levada para fora do palácio.

— Muito bem. — A imperatriz respondeu com serenidade; seu olhar irradiava a alegria de quem tinha certeza da vitória.

Xiangling, porém, estava intrigada e arriscou perguntar: — Vossa Majestade, há uma coisa que não entendo... Mandar a Nobre Dama Gu para fora do palácio já representa um risco enorme. E nem sabemos se ela vai mencionar o “grande assunto” a Gu Yanchuan. Para conseguir sair e passar algum tempo com a família, ela pode muito bem ter concordado só da boca para fora e enganado Vossa Majestade.

A imperatriz brincou um pouco com a arara, que imediatamente imitou uma voz dirigida a Xiangling: — Burra! Burra!

Xiangling: — ...

A imperatriz riu. — Até a minha arara sabe como sua pergunta foi idiota. O quê? Acha que não percebi que Gu Sijin apenas entrou no meu jogo para garantir que eu a mandasse para casa?

Mais confusa ainda, Xiangling perguntou: — Então por que Vossa Majestade...?

— Sabe que remédio passei nas feridas dela?

Xiangling negou com a cabeça, e a imperatriz prosseguiu: — O remédio não ajuda a cicatrizar. Ao contrário: faz as feridas infeccionarem e piora os machucados.

Fez uma pausa e soltou um riso de escárnio. — Faz alguma diferença se ela conta ou não conta a Gu Yanchuan?

— Não. O que importa é que Gu Yanchuan só tem essa filha. Ao vê-la voltar coberta de ferimentos, depois de ser tratada daquela maneira no palácio, você acha que um pai conseguiria suportar?

A imperatriz atirou as cascas de girassol no braseiro, de onde saltaram fagulhas. — Gu Yanchuan pode até engolir as humilhações que Tong Guowei lhe impõe. Mas nunca vai aceitar que a própria filha tenha sido usada como saco de pancadas pela filha de Tong.

— Mesmo que Gu Sijin peça ao pai que não se envolva, ele vai correr por conta própria atrás do meu pai. Portanto, desde o instante em que ela saiu do palácio para voltar para casa, o plano já estava concretizado.

Xiangling servia à imperatriz havia tanto tempo e, ainda assim, não conseguia decifrá-la.

Sempre que julgava ter encontrado uma falha nos planos da imperatriz, acabava descobrindo, surpresa, que até o aparente erro havia sido calculado desde o princípio.

Era como se a imperatriz estivesse jogando uma partida de xadrez, sem jamais voltar atrás depois de mover uma peça.

Desde o primeiro movimento, já conseguia enxergar a derrota do adversário.

— Vossa Majestade é tão perspicaz e previdente... Sou eu que enxergo pouco e ainda tive a audácia de tentar aconselhá-la. Eu realmente...

A imperatriz a interrompeu: — Quando alguém tem um filho, ganha ao mesmo tempo uma armadura e um ponto fraco. Por ele, é capaz de enfrentar qualquer obstáculo; por ele, também pode abrir mão de todos os princípios.

— Aprendi a lição. Vossa Majestade compreende tão profundamente o coração humano que cada movimento seu é brilhante!

A imperatriz deu um sorriso frio e balançou a cabeça. — Errado. O que eu compreendo não é o coração de cada pessoa, mas a natureza humana.

Levantou-se, retirou o adorno de fênix dos cabelos e o entregou a Xiangling. — Se sou capaz de ocupar o trono de imperatriz e usar esta fênix, também sou capaz de mantê-los. A Consorte Nobre, a Concubina Hua e até Gu Sijin são peças incômodas neste tabuleiro. Vou eliminá-las todas.

Ergueu a cabeça para a lua, com um sorriso assustador:

— Nesta partida, só eu posso vencer.

*

Na manhã seguinte, na estância termal.

Naquele dia, Ning Xiaoxiao — o verdadeiro terceiro elemento que sobra no encontro dos outros — tinha ido passear pelas montanhas com a princesa mais velha e Huanü.

Lu Linyuan terminara de examinar os memoriais enviados do palácio e pretendia procurar Ning, quando ouviu Sanfu comentar em tom de brincadeira:

— A ideia era acomodar Sua Alteza, o príncipe Jing, no Pavilhão Xiaoyao para que pudesse entrar e sair à vontade. Quem diria que ele ficaria tão quieto nos últimos dois dias, sem sair nem para dar uma voltinha, enquanto a princesa mais velha passeia diariamente?

Pensando bem, já fazia dois dias que Lu Yiqiu não aparecia diante dele.

Com aquele temperamento irrequieto, seria impossível que tivesse sossegado de verdade.

— Vá chamá-lo. Quero saber o que anda aprontando.

Normalmente, bastava chamá-lo uma vez para que o irmão caçula surgisse correndo todo animado. Naquele dia, porém, Sanfu precisou de quase o tempo de queimar um incenso para arrastá-lo até ali.

Lu Yiqiu chegou segurando um livro e lendo com a maior dedicação. Até seu cumprimento ao imperador foi displicente.

— Mano, estava me chamando?

Nem ergueu os olhos ao perguntar.

Lu Linyuan achou graça. — Caiu um raio na sua cabeça? Pensei que morreria sem ver você agarrado a um livro desse jeito!

Fez um gesto para que o irmão se aproximasse, mas Lu Yiqiu desconversou: — Ah, mano, espera um pouquinho! Estou na melhor parte!

A paciência de Lu Linyuan se esgotou. O sorriso desapareceu e ele arrancou o livro das mãos do irmão.

— Ah, mano! O que está fazendo?!

Com um olhar de relance para a capa, Lu Linyuan encontrou sete caracteres enormes que formavam o título:

— “O Príncipe Dominador se Apaixonou por Mim”.

???

— Que porcaria você anda lendo?

— É bom demais! — Lu Yiqiu estendeu a mão para recuperar o livro, mas Lu Linyuan lhe deu um tapa na cabeça com o volume.

Esperto, Lu Yiqiu aproveitou o movimento para retomar o livro e abri-lo diante do irmão. — Olha só, mano, como é bem escrito! Tem um monte de declarações românticas de derreter o coração. Vou ler uma!

— Essa aqui, essa aqui: “Eu sou nove, você é três...”

— Você é um imbecil — cortou Lu Linyuan.

— Não entendeu, né? Quer dizer: “Tirando você de mim, só sobra você!”

Lu Linyuan: — ...

— Tem outra, tem outra! Olha esta!

Limpou a garganta e fez de propósito uma voz grave e rouca, cheia de pose:

— “Mulher, tenho nove certezas em dez... Só me falta um beijo seu para ter certeza absoluta.”

Terminou a leitura e começou a berrar feito um maluco: — Aaaaaah! Não é doce demais?!

Lu Linyuan franziu a testa. Enquanto Lu Yiqiu flutuava em sua nuvem de romance, arrancou-lhe o livro mais uma vez e o jogou de lado.

— Você passa os dias sem fazer nada de útil, só se ocupando dessas bobagens! Quantos anos acha que tem?

Repreendido sem entender por quê, Lu Yiqiu fez um biquinho magoado. — Quando saio para me divertir, você reclama que gasto dinheiro. Quando fico lendo, também não deixa... Humpf! Não falo mais com você!

Bateu o pé com força, virou as costas e saiu, indignado.

Assim que se certificou de que o irmão estava longe, Lu Linyuan pegou sorrateiramente “O Príncipe Dominador se Apaixonou por Mim” e começou a estudá-lo com seriedade...

Quanto mais lia, mais se empolgava. O sorriso bobo de quem torce por um casal não saía de seu rosto.

À noite, Ning Xiaoxiao voltou tagarelando feito um passarinho, contando animadamente tudo o que tinha visto no passeio com a princesa mais velha e Huanü.

Lu Linyuan fingiu uma expressão impaciente. — Dá para parar de ficar passeando diante de mim? Você está bagunçando todos os meus pensamentos.

Ning Xiaoxiao parou, perplexa:

【Ah, é assim agora? Criou coragem, foi? Faz quantos dias que estamos juntos e já está de saco cheio de mim?】

Lançou-lhe um olhar atravessado e se virou para sair.

Lu Linyuan agarrou seu braço e a puxou para junto do peito. Ergueu-lhe o queixo delicado e abriu um sorriso tão arrogante quanto sedutor:

— Já que você bagunçou o meu coração...

— Quando pretende bagunçar a minha cama?

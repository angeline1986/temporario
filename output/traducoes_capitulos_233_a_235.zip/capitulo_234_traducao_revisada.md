# Capítulo 234 — Nova missão: deixar a boca da Consorte Nobre torta

Ning Xiaoxiao: — ???

Você está bem da cabeça?

Se estiver sem ter o que fazer, vá treinar espacate!

Pela pose de Lu Linyuan, ela suspeitou que ele ainda guardava um arsenal de cantadas cafonas. Antes que ele abrisse a boca de novo, encostou o indicador nos lábios dele.

— Majestade, os leitores estão dizendo que o senhor está meloso demais. É melhor fechar a boca agora, imediatamente, ou vou me jogar de cabeça contra os seus peitorais e morrer aqui mesmo, para que todos vejam nosso romance acabar em tragédia!

Lu Linyuan lhe ergueu um polegar. — ... Você é superior mesmo, não há quem se compare!

Então tomou Ning Xiaoxiao nos braços e, ao chegar à cama, apagou de passagem as velas do quarto.

— Chega dessa palhaçada! Vamos dormir!

*

Ao meio-dia seguinte, Ning Xiaoxiao calculou que Lu Linyuan já devia ter terminado de tratar dos assuntos de governo e foi procurá-lo para almoçarem juntos.

Mal chegou ao Pavilhão de Estudos Bitong, viu Sanfu entrar apressado no salão principal, andando com passinhos miúdos.

A expressão dele anunciava problemas. Ning Xiaoxiao foi se esgueirando até a janela e ficou escutando.

— Majestade... O senhor Tong disse que Vossa Majestade veio à estância termal sem trazer a Consorte Nobre. Ela sente tanta saudade que passa noites sem dormir, anda abatida... Então ele... ele... desrespeitou as normas do palácio e trouxe a Consorte Nobre para fora, por conta própria. Estão a caminho da estância termal.

O rosto de Lu Linyuan escureceu. A haste do pincel se partiu em duas com um estalo dentro de sua mão.

Tong Guowei enlouquecera?

Ele vinha testando os limites do imperador pouco a pouco, estendendo as garras da corte para dentro do harém. Desta vez, Lu Linyuan teria de lhe ensinar uma lição. Caso contrário, que autoridade imperial lhe restaria?

Sanfu acrescentou: — Há mais uma coisa... A notícia foi passada por alguém a pedido da imperatriz. A Consorte Nobre mandou espancar a Nobre Dama Gu até deixá-la coberta de feridas e ainda a colocou em confinamento.

A imperatriz fizera questão de espalhar a notícia. Sabia que, mesmo que Lu Linyuan nada fizesse, Ning Xiaoxiao iria defender Gu Sijin.

Se provocasse Ning Xiaoxiao, a Consorte Nobre não teria um único dia de paz na estância termal, mesmo que lhe permitissem ficar.

Lu Linyuan apenas soltou um “ah” indiferente ao ouvir aquilo. Evidentemente, não se importou.

Sabia que Gu Sijin tinha a medalha de imunidade à morte que Ning Xiaoxiao lhe deixara; nada de realmente grave deveria acontecer.

E, falando francamente, se uma mulher apanhasse em qualquer canto do mundo e não fosse Ning Xiaoxiao, ele não daria a mínima.

Talvez houvesse uma exceção: a princesa mais velha Qingyang. Mas, conhecendo o gênio dela, o mais provável era que ela batesse nos outros, não que alguém ousasse encostar um dedo nela.

Ele não se importava. Ning Xiaoxiao, porém, que escutara a notícia escondida sob a janela, ficou furiosa.

Ao trazer a Consorte Nobre para lá, Tong Guowei só conseguiria obrigá-la a assistir às demonstrações de carinho entre Ning e Lu Linyuan, passando vergonha. O que mais ela poderia fazer na estância?

Ning Xiaoxiao jamais a considerara digna de atenção; a mulher nem sequer qualificava como rival de verdade.

A princípio, pretendia ignorar tudo. Mas, quando ouviu que a Consorte Nobre havia mandado bater em Gu Sijin, sua raiva explodiu.

Talvez estivesse contaminada pelas cantadas cafonas de Lu Linyuan, pois uma frase dramática imediatamente lhe veio à cabeça:

“Se você quebrar as asas da minha irmã de coração, eu destruirei o seu paraíso inteiro!”

Ning Xiaoxiao ficou tão furiosa que quase teve um infarto. Desistiu até do almoço e voltou ao quarto para pensar numa estratégia.

E não era só a Consorte Nobre: Tong Guowei também era um desgraçado.

Com certeza viera importunar Lu Linyuan outra vez. A estratégia de suportar provocações enquanto preparava os próximos movimentos era digna de um cavalheiro; um grande homem sabia a hora de ceder e a hora de agir.

Mas Ning Xiaoxiao não queria saber de nada disso. Ninguém podia maltratar o homem dela, nem de mentirinha!

Ela pretendia usar tudo junto: reescrever a trama de ponta-cabeça, Pausar, Retroceder... Um verdadeiro combo contra Tong e sua filha.

Só que, ao abrir o documento, descobriu encantada que o botão de Possessão, apagado havia tanto tempo, estava de novo aceso!

Fazendo as contas: podia possuir alguém uma vez por mês. E não tinha passado exatamente um mês desde a última vez, quando se transformara em uma gatinha?

Uma alegria impossível de conter tomou conta dela. Com aquele poder especial, quem disse que não conseguiria dar uma lição naqueles dois miseráveis?

Foi então que Xiao Qi, desaparecido havia um bom tempo, reapareceu de repente:

【Bip, bip, bip! Olá, anfitriã! O sistema tem uma nova missão para você! Não se esqueça de conferir!】

【Bip, bip, bip! Nova missão: “Deixar a boca da Consorte Nobre torta”. Recompensa ao completar: +5 pontos percentuais no Índice de Desvio da Trama. Penalidade por fracasso: −15% da vitalidade da anfitriã. Conclua a missão o quanto antes!】

???

Desde quando aquele sistema maldito começara a se comportar como gente?

Além disso, cinco pontos percentuais de desvio da trama era uma recompensa enorme! Só por isso?

Era como se alguém tivesse lhe oferecido um travesseiro justamente quando estava morrendo de sono!

Ning Xiaoxiao declarou mentalmente: mesmo que não tivesse me dado essa missão, eu já ia deixar a boca dela torta de qualquer maneira!

No dia seguinte, Tong Guowei chegaria à estância termal acompanhado da Consorte Nobre.

Lu Linyuan convocou os funcionários das regiões vizinhas, pretendendo usar a pressão implícita da presença deles para obrigar Tong Guowei a se conter.

Ele não contou o plano a Ning Xiaoxiao, pois temia que ela fosse envolvida. Mandou-a acampar com a princesa mais velha e Huanü.

Quando usava a possessão, seu corpo original desaparecia. Aquela combinação não poderia ser mais conveniente para Ning Xiaoxiao.

Assim que saíram, ela disse que sua menstruação ainda não havia terminado e que de repente sentira dores abdominais. A princesa mais velha, então, levou-a de volta.

Na entrada da estância termal, Ning Xiaoxiao insistiu para que a princesa e Huanü aproveitassem o passeio a sós e não se preocupassem com ela. Depois de dispensar as duas, abriu rapidamente o documento, apertou Possessão e procurou cuidadosamente o nome Tong Guowei entre inúmeras opções.

Só teria aquela oportunidade. Não podia cometer outro engano como o da última vez.

*

Àquela altura, Tong Guowei já havia chegado com a Consorte Nobre ao Pavilhão de Estudos Bitong.

O pavilhão estava repleto de ministros. Tong Guowei, contudo, continuava relaxado e insolente. Cumprimentou o imperador de qualquer jeito e foi direto ao assunto:

— Majestade, desde que Vossa Majestade deixou o palácio sem levar a Consorte Nobre, ela chora todos os dias de saudade, a ponto de os olhos ficarem inchados. Como pai, sinto muita pena da minha filha e também não consigo comer nem dormir em paz.

— Por isso a trouxe hoje. Peço a Vossa Majestade que compreenda o coração de um pai e permita que a Consorte Nobre fique na estância termal para servi-lo.

A Consorte Nobre deu dois passos à frente e fez uma reverência. Em seguida, começou a choramingar. — Majestaaade! Senti tanta saudade! Fui eu que obriguei papai a me trazer até aqui. Se for punir alguém, puna a mim, mas não desconte nele!

— Majestaaaaade!

Enquanto falava, saiu rebolando em direção a Lu Linyuan.

Lu Linyuan já se preparava para afastá-la com um chute quando Tong Guowei estremeceu de repente. Então avançou em passos rápidos e deu um chute violento no traseiro da filha, derrubando-a de cara no chão.

Os ministros: — !!!

Lu Linyuan: — ???

A Consorte Nobre ficou tão aturdida com o chute do próprio pai que perdeu a fala.

Apoiou-se no chão para se levantar e perguntou entre lágrimas: — Papai, por que me bateu?

— Chora, chora, chora! Chora uma ova! — Tong Guowei começou a xingar. — Sou seu pai! Se eu quiser bater em você, bato! Preciso escolher um dia especial, por acaso?

— Tenho mil coisas para resolver, e você, sua idiota, só sabe arranjar confusão para mim o dia inteiro!

Arregaçou as mangas, avançou, agarrou a gola da Consorte Nobre e a encarou furiosamente. — Se eu não acabar hoje com você, sua filha ingrata, vou bater a cabeça até morrer diante do imperador!

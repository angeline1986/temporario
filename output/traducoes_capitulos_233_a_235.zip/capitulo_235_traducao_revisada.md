# Capítulo 235 — [Leitura obrigatória] Nomeie Xiaoxiao Consorte Nobre imediatamente!

O salão inteiro ficou paralisado de espanto, mergulhado em silêncio.

Aquele velho Tong Guowei era mesmo um sujeito de ação: quando tinha uma filha, não hesitava em descer a mão nela.

Reuniu todas as forças e deu um tapa estrondoso na Consorte Nobre.

Praticava artes marciais havia anos e tinha uma força considerável nos braços.

A bofetada veio acompanhada de um “crec”: a mandíbula da Consorte Nobre saiu do lugar e ficou torta para a esquerda. Incapaz de fechar a boca ou conter a saliva, ela parecia um daqueles “deuses da guerra de boca torta” dos vídeos de internet, balbuciando sem parar.

Mesmo assim, Tong Guowei ainda não achou suficiente.

Num espetáculo absurdo, recolocou a mandíbula dela no lugar e em seguida lhe acertou outro tapa, deslocando-a mais uma vez...

Repetiu isso sete ou oito vezes. O rosto da Consorte Nobre ficou tão inchado, lustroso e deformado que parecia uma cabeça de porco.

Lu Linyuan ficou tão chocado com aquela cena que até sua respiração hesitou. Tong Guowei havia enlouquecido de vez?

Até que ouviu uma voz bem conhecida.

【Então você teve coragem de bater na minha Gu, foi? Criou asas, foi? Vou acabar com você, sua desgraçada!】

Lu Linyuan finalmente entendeu tudo!

Tal como quando Ning Xiaoxiao se transformara numa gatinha, ela agora tinha entrado no corpo de Tong Guowei...

Da outra vez, ao escutar os pensamentos da gatinha Xiaoxiao, ele descobrira que ela podia possuir alguém uma vez por mês, e que cada possessão durava um dia inteiro.

Portanto, o Tong Guowei diante dele era, na verdade, sua esposa — só que em versão masculina...

Depois de organizar os fatos na cabeça, Lu Linyuan imediatamente interveio:

— Chega de bater! Senhor Tong, pare!

— Você... cuidado para não machucar a mão!

A Consorte Nobre com cara de porco: — ???

Ning Xiaoxiao, ocupando o corpo de Tong Guowei, já havia batido o bastante. Se continuasse, a Consorte Nobre poderia morrer, e o sistema não permitia que ela simplesmente eliminasse os vilões da história.

Por isso, se conteve. Então lhe ocorreu outro pensamento:

【Esse brutamontes vive desafiando o meu Lu! Só porque tem algum poder nas mãos, esqueceu que não passa de um monte de lama imprestável!】

【De todo modo, não sinto dor quando possuo alguém. Vou só dar uma pequena rachadinha na cabeça dele para começar!】

Tong Guowei de repente pareceu sofrer um ataque de loucura. Abraçou uma coluna com dragões no centro do salão e começou a bater a própria cabeça contra ela, uma pancada atrás da outra.

Lu Linyuan quase caiu na gargalhada: que maravilha era ter uma esposa disposta a defendê-lo!

Todos os presentes guardavam alguma desavença com Tong Guowei. Ao vê-lo se torturar, sentiram uma satisfação secreta. Limitaram-se a rir às escondidas; ninguém tentou impedi-lo.

Apenas a Consorte Nobre de rosto inchado se lançou cambaleante sobre ele, abraçou-o e gritou em prantos: — Papai! Papai, não faça isso! Estou com medo!

Tong Guowei a empurrou bruscamente para longe e, com o rosto coberto de sangue, ajoelhou-se diante de Lu Linyuan, cheio de aparente remorso:

— Majestade! Este ministro é culpado! Este ministro não merece ser chamado de gente!

— Criei uma filha tão desavergonhada: primeiro crime! Eu mesmo não tenho vergonha na cara: segundo crime! No mês passado, sequestrei uma senhora de setenta e cinco anos que morava na zona oeste da cidade para obrigá-la a ser minha concubina: terceiro crime...

— Sou pior que um animal! Vivo, desperdiço ar; morto, desperdiçarei terra! Por que Vossa Majestade não manda me esquartejar de uma vez?

— Se me picarem bem miudinho, ainda podem me dar de comer aos cães. Pelo menos assim lavarei alguns dos meus pecados!

Os ministros ficaram boquiabertos: essa era nova! Nunca tinham ouvido um pedido tão absurdo.

A Consorte Nobre avançou chorando para ajudá-lo a se levantar, mas ele lhe acertou outra bofetada e a jogou para o lado.

Lu Linyuan, naturalmente, não podia simplesmente satisfazer aquele “desejo” e mandar executá-lo. Assim, fingiu compaixão. — Levante-se, senhor Tong. Embora não mereça ser chamado de gente, não precisa ofender os cães oferecendo-lhes sua carne... Reconhecer os próprios erros já é muito bom. Pode se levantar.

Tong Guowei continuou ajoelhado. — Agradeço a Vossa Majestade por poupar minha vida! Mas... este ministro tem um pedido um tanto impertinente. Imploro que Vossa Majestade o conceda!

— Diga.

— Peço a Vossa Majestade que mande me castrar!

???

— Majestade! Para falar a verdade, faz muito tempo que este ministro deseja ser mulher.

Estufou o peito, forçou uma pose curvilínea em formato de S e, com a delicadeza afetada de um brutamontes, declarou: — Ser mulher é tão bom!

???

Depois de um breve silêncio, alguém entre os ministros comentou alguma coisa e os demais começaram a pedir, um após outro:

— Majestade, já que o senhor Tong tem ambição tão grandiosa, seria justo satisfazê-la.

— Exato! Como diz o ditado, quem disse que as mulheres são inferiores aos homens? Tenho certeza de que, caso se torne mulher, o senhor Tong será um exemplo entre elas! Um modelo de virtude feminina!

A Consorte Nobre quase desmaiou de tanto chorar. Prostrada no chão, desesperada, perguntou: — Pai... o que está acontecendo com o senhor? Que absurdos está dizendo?!

Lu Linyuan estava quase explodindo por segurar o riso.

Sua Xiaoxiao era sempre tão criativa.

Mas, evidentemente, não mandaria castrar Tong Guowei:

Primeiro, porque sabia que a possessão de Ning Xiaoxiao durava apenas doze períodos de duas horas, isto é, um dia. Se castrasse Tong Guowei de verdade, acabaria provocando uma rebelião imediata.

Segundo, porque para castrá-lo seria necessário tirar-lhe as calças, e Xiaoxiao acabaria vendo as partes íntimas de um velho de mais de cinquenta anos. Que horror para os olhos dela!

Sua Xiaoxiao já havia conhecido “grandes emoções” com ele. Como permitir que uma ave velha viesse ferir aqueles olhos inocentes?

— Esse pedido eu não posso conceder. Faça outro.

Tong Guowei pensou por um instante e puxou a Consorte Nobre para diante de si:

— Majestade, minha filha é uma mulher desprezível que só sabe cometer maldades! Tem intenções perversas e não possui virtude à altura do posto. Com que direito ocupa a posição de Consorte Nobre? Peço que Vossa Majestade lhe retire a autoridade de auxiliar na administração dos Seis Palácios e a destitua do título de Consorte Nobre, para que aprenda uma lição!

A Consorte Nobre: — ??? Papai! Eu não fiz nada contra o senhor!

Lu Linyuan sorriu. — Seria indelicado recusar repetidamente os pedidos do senhor Tong. Os censores estão registrando tudo, e os ministros são testemunhas: foi você quem me implorou para destituí-la. Concedo-lhe esse desejo. A partir de hoje, retirarei dela o título de Consorte Nobre. Mas isso deixará uma vaga no posto, que precisará ser preenchida.

Ergueu as sobrancelhas para Tong Guowei, divertido. — Acredito que a Concubina Hua seja uma excelente candidata, capaz de assumir a posição de Consorte Nobre e a autoridade de auxiliar na administração dos Seis Palácios. Assim, farei da Concubina Hua a nova Consorte Nobre e rebaixarei a atual Consorte Nobre a Concubina Tong. O que acha, senhor Tong?

Ning Xiaoxiao ficou pasma. Nunca pensara em aproveitar a situação para elevar o próprio status e, por um momento, não soube como responder.

Lu Linyuan continuou: — Como não diz nada, tomarei seu silêncio por consentimento. Guardas! Transmitam minha ordem verbal: rebaixem a Consorte Nobre ao posto de Concubina e promovam a Concubina Hua a Consorte Nobre, concedendo-lhe autoridade para auxiliar na administração dos Seis Palácios. Assim que o decreto for redigido, enviem-no ao palácio a toda velocidade, para tornar a decisão efetiva!

Os ministros levantaram-se e fizeram reverências respeitosas. — Vossa Majestade é sábio!

Tong Guowei, possuído por Xiaoxiao, ainda tentava entender o que acabara de acontecer. Sem alternativa, repetiu a saudação com os outros.

E assim se concretizou um mundo em que a única prejudicada foi a Consorte Nobre...

Tendo aprendido direitinho com a imperatriz-viúva, a Consorte Nobre ouviu a notícia, perdeu o fôlego e desmaiou com um gemido esquisito...

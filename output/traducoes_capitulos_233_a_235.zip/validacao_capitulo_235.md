# Validação — capítulo 235

- **Fonte:** `novel_capitulos_212_a_270(20261105-204934).docx`, original chinês tradicional.
- **Parágrafos DOCX:** 1632 a 1699 (índices base zero).
- **Unidades não vazias (incluindo título):** 65.
- **Correspondência estrutural:** 65 linhas de cotejo 1:1, todas com índice real do DOCX, chinês e tradução portuguesa preenchidos.
- **Título:** preservado como primeira unidade, com adaptação literária.
- **Notas e escolhas editoriais:** A condição de Tong Guowei é possessão por Ning, não ato voluntário. “Deus da guerra de boca torta” é meme audiovisual chinês. O rebaixamento e a promoção foram ordenados verbalmente; o decreto escrito será enviado depois. A interpretação jocosa da frase sobre o dia inteiro mantém doze períodos tradicionais de duas horas. A agressão é explícita e não foi suavizada.
- **Limitação:** verificação estrutural automatizada não substitui uma segunda auditoria semântica integral independente. Tradução preparada por leitura contextual do original; não alegar certificação independente.

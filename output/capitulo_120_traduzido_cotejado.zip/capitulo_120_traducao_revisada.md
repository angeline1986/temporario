# Capítulo 120 — Trocando experiências sobre como preparar frango

No caminho para o Palácio Chaoyang, Ning Xiaoxiao seguia sentada no palanquim, de olhos fechados, descansando. Aproveitou para abrir o documento e conferir o que aconteceria a seguir na trama.

Quem diria que uma imensidão de mosaicos voltaria a inundá-la?

Xiao Qi já lhe explicara que, por ela ter entrado à força na história como uma personagem adicional, sempre que grandes trechos da trama a envolvessem, as palavras do documento se transformariam em mosaicos.

Mas Ning Xiaoxiao se lembrava perfeitamente: no romance original, não havia nenhuma história de estrangeiros ocidentais entrando no palácio...

Ela chamou Xiao Qi: 【Xiao Qi? Está aí?】

Só alguns minutos depois recebeu uma resposta.

【Anfitriã... cof, cof, cof... O que foi?~】 Sua voz soava fraca, como se estivesse doente.

Ning Xiaoxiao: 【O que aconteceu com você? Está falando sem força nenhuma.】

Xiao Qi: 【Está tendo um surto de gripe aqui do nosso lado. Dei azar e peguei também... Agora estou no hospital, prestes a tomar uma injeção.】

Ele tossia sem parar, como se fosse pôr os pulmões para fora.

Só depois que a tosse diminuiu um pouco Ning Xiaoxiao perguntou de onde surgira aquele trecho da história de que ela não tinha lembrança alguma.

Xiao Qi: 【Talvez a anfitriã tenha esquecido. Ou talvez sua entrada no livro tenha alterado o rumo da trama, fazendo surgir uma nova história paralela. De qualquer forma, não é nada grave... cof, cof, cof~~】

Ning Xiaoxiao: 【Você está tossindo desse jeito e diz que não é grave? Que tipo de regime de trabalho vocês têm aí? Mesmo nesse estado, não pode tirar uns dias para descansar?】

Comovido pela preocupação dela, Xiao Qi aproveitou para se lamentar: 【Não é que eu não queira pedir licença... É que, se eu me afastar e o sistema ficar temporariamente fora do ar, seus poderes especiais também desaparecerão por um tempo. Por isso, além de comunicar minha licença à Administração do Espaço-Tempo, preciso da autorização da anfitriã...】

Quanto mais falava, mais culpado parecia; no fim, sua voz mal se ouvia.

E não era para menos. Desde que ficara vinculado a Ning Xiaoxiao, aquele sistema de personalidade insuportável não parava de lhe passar missões praticamente suicidas. De vez em quando, ainda aproveitava para provocá-la e debochar dela. Era a própria encarnação da falta de escrúpulos.

Agora que precisava de um favor de Ning Xiaoxiao, por que ela não aproveitaria a fraqueza dele para acabar de vez com sua alegria? Como poderia concordar com a licença?

Ning Xiaoxiao percebeu o que ele pensava pelo tom de voz e riu: 【Você está imaginando coisas. Nem gente você é; por que eu ficaria guardando rancor de você? Licença concedida. Descanse uns dias e melhore. Se continuar tossindo sem parar, até eu vou acabar com dor de cabeça.】

Xiao Qi: 【Buááá~ Anfitriã, você é tão boazinha! Estou emocionado!】

Depois de trocar mais algumas palavras melosas com Ning Xiaoxiao, ele se desconectou às pressas para ir tomar sua injeção.

Ao mesmo tempo, o documento na mente de Ning Xiaoxiao ficou cinza-escuro, inteiramente bloqueado.

Quando o palanquim parou diante do Palácio Chaoyang, ela avistou de longe, assim que desceu, o Grande Erudito e um velho de barba branca, vestido com uma túnica comprida, saindo juntos e conversando animadamente. Ao distinguir o rosto do velho, Ning Xiaoxiao ficou boquiaberta.

Caralho?

Esse sujeito é o quê, o antepassado do velhinho do KFC? Dizer que os dois se parecem é pouco: são idênticos!

Ao passar por Ning Xiaoxiao, o homem percebeu que ela o encarava sem piscar e lhe dirigiu um cumprimento muito cordial: — Hello~

Embora parecesse idoso, tinha uma voz potente. O cumprimento inesperado mais parecia o canto de um galo ao amanhecer.

Hum... É, quem tem uma família que enriqueceu preparando frango realmente é diferente...

Ning Xiaoxiao respondeu com um sorriso educado. Em seguida, perguntou baixinho ao Grande Erudito: — Erudito Yao, esse homem é o enviado ocidental?

O Grande Erudito assentiu: — Sim, minha senhora. É ele mesmo.

Ele carregava duas sacolas de papel encerado, das quais vinha um aroma apetitoso.

Ning Xiaoxiao: — O que é isso?

O Grande Erudito abriu uma das sacolas. Lá dentro havia um frango frito colocado de cabeça para baixo, exibindo para Ning Xiaoxiao seu traseirinho dourado.

— Minha senhora, é um presente de boas-vindas que o enviado ocidental me deu.

Ning Xiaoxiao olhou para o velho de barba branca, depois para o frango frito, e não economizou no elogio: — O cheiro é muito bom.

O velho compreendeu o elogio. Contente por ver sua habilidade culinária reconhecida, desatou a falar uma porção de coisas numa língua que Ning Xiaoxiao não entendia.

O Grande Erudito traduziu: — Ele disse que a capital é vasta e rica em recursos, com uma variedade impressionante de iguarias. Ontem, quando estava hospedado na estação de recepção dos enviados, viu alguém vendendo roujiamo na cidade. Provou e gostou tanto que não parou de elogiar. Isso lhe deu uma ideia: criar um prato com características ocidentais.

— Entre os nobres de sua terra, o pão é um alimento básico. Ele pretende combiná-lo com frango frito, alface e um molho secreto. Inspirado no nosso roujiamo, quer colocar tudo dentro do pão. Já pensou até num nome estrangeiro para a receita: “Hamburger”.

Ning Xiaoxiao ficou estarrecida. 【Olha só! Então o hambúrguer nasceu de uma cópia do nosso roujiamo chinês? Ah, mas eu não vou deixar você sair copiando assim, não!】

Ela franziu de leve as sobrancelhas e balançou a cabeça. — Não acho essa ideia muito boa. Por que você não sugere a ele substituir o pão por panquecas finas de primavera? Para o recheio, frango e pepino. Mande também dois pacotes de molho doce de farinha fermentada, para ele espalhar por dentro. O sabor agridoce ajudará a equilibrar a gordura do frango frito. Além disso, o pão é caro, enquanto essas panquecas podem ser feitas em qualquer casa. Assim, mais gente poderá comer o prato, que ficará conhecido com muito mais facilidade.

O Grande Erudito transmitiu as sugestões ao enviado ocidental. Ao ouvi-las, ele teve uma verdadeira revelação: ergueu o polegar para Ning Xiaoxiao, repetiu “very good” várias vezes e pediu que ela desse um nome ao prato.

Ning Xiaoxiao respondeu casualmente: — Pode chamar de wrap de frango à moda da Velha Pequim.

Os dois tiveram uma conversa bastante agradável, trocando cordialmente experiências sobre como preparar um frango ainda mais gostoso.

Mas Lu Linyuan, que esperava no salão principal, já começava a perder a paciência. Chamou Sanfu e perguntou: — Por que Ning Xiaoxiao ainda não chegou?

Sanfu respondeu: — Ela encontrou o enviado ocidental lá fora, Majestade. Então a Atendente Ning começou a conversar com ele.

— Começou a conversar? — Lu Linyuan ergueu uma sobrancelha. — Então ele é mesmo o pai dela?

— Bem... — Sanfu hesitou e balançou a cabeça. — Não parece. Os dois estão se tratando com muita formalidade.

Lu Linyuan: — Então o que ela tem para conversar com um velho que nunca viu na vida?

Sanfu: — Este servo ouviu um pouquinho. Parece que... estavam trocando experiências sobre fazer frango?

— ...

O rosto de Lu Linyuan escureceu imediatamente. Percebendo que sua escolha de palavras soara imprópria, Sanfu deu dois tapinhas na própria boca e se apressou a corrigir:

— Majestade, não estou falando daquele tipo de “fazer frango”! — Ele se curvou, abriu os braços e os agitou como asas. — É deste frango aqui! O que faz cocoricó!

— ...

Lu Linyuan lançou-lhe um olhar que se reserva a alguém completamente sem noção. — Vá chamá-la. Diga a ela para parar de fazer frango.

Sanfu concordou repetidas vezes e correu para fora do salão principal a fim de buscar Ning Xiaoxiao.

Quando chegou, o enviado ocidental e o Grande Erudito já haviam ido embora. Sanfu deu alguns passos na direção de Ning Xiaoxiao para recebê-la. — Atendente Ning, Sua Majestade está esperando pela senhora lá dentro~

Em seguida, movido pela curiosidade de quem adora uma fofoca, aproximou-se de seu ouvido e cochichou: — Atendente Ning, a senhora conseguiu olhar direito? Aquele homem é seu pai?

Ning Xiaoxiao se virou e lançou-lhe um olhar fulminante. — Seu pai!

Sanfu: — ...

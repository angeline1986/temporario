# Validação — capítulo 120

- Fonte primária: `novel_capitulos_61_a_120(20261103-205857).docx` (chinês tradicional).
- Limites: parágrafo DOCX 4323 (título) a 4383 (última unidade); fim do documento.
- Unidades não vazias do original (incluindo título): **59**.
- Linhas de cotejo: **59**; cada linha preserva o índice real do DOCX.
- Campos vazios: **0**. Índices duplicados: **0**. Unidades não alinhadas: **0**.

## Conferência editorial

- Preservada a distinção entre pensamentos delimitados por `【】` e falas pronunciadas.
- Mantido o estado do sistema: Xiao Qi obtém licença e o documento fica bloqueado.
- Preservados *KFC*, *Hello*, *Hamburger*, *very good* e as referências ao `roujiamo` e ao prato à moda da Velha Pequim.
- `做雞` tem ambiguidade cômica no chinês (preparar frango / expressão potencialmente sexual). A tradução mantém «fazer frango» e a reação desproporcional dos personagens; o duplo sentido pode não ficar plenamente recuperável em português sem nota.
- `寧答應` foi traduzido como «Atendente Ning», seguindo a convenção editorial vigente; o termo é um posto do harém, não apenas uma forma de tratamento comum.
- `白胡子老頭` e semelhança com o mascote do KFC são parte de uma sátira deliberadamente anacrônica; não tratar como história real da origem do hambúrguer.
- A referência «seu pai!» na última fala é uma réplica sarcástica; não estabelece parentesco.
- O capítulo 120 é o último do arquivo fornecido, **não há confirmação de que seja o fim da novel**.

## Escopo e limitações

Tradução conferida contra as 59 unidades chinesas durante a elaboração, e conferência estrutural 1:1 concluída. Não foi realizada segunda auditoria linguística independente; correspondência de linhas não prova, isoladamente, ausência de desvios de sentido em cada frase. Nenhum acontecimento de capítulos posteriores foi acrescentado.

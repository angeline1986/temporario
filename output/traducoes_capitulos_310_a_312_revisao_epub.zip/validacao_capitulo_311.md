# Validação do capítulo 311

- **Original:** `novel_capitulos_301_a_360(20261107-181903).docx` (chinês).
- **Tradução-base:** `novel capitulos 301 a 360 - ch.epub` (`index_split_010.html`).
- **Índices absolutos do DOCX:** 799–888 (base zero, lacunas de parágrafos vazios preservadas).
- **Unidades não vazias no original e na saída:** 88 e 88, inclusive títulos e marcadores.
- **Unidades corrigidas diretamente:** 37; outras receberam normalização pontual de nomes e pensamentos.

## Problemas de tradução e decisões editoriais

- O atraso menstrual é de Ning; ela finge estar menstruada para recusar Lu Linyuan.
- Gu Sijin é quem deixará o palácio; Ning permanece imperatriz. Gu Sijin e Chu Xingran são o casal cuja união precisa ser protegida.
- O original contém “21” em uma alusão sexual, sem expansão inequívoca; preservada a expressão e registrada a incerteza.
- O sistema impõe missão contrária à libertação de Gu Sijin: recompensa de 3 pontos percentuais no índice e penalidade de 10% de vitalidade.

## Método e limites

Cotejo estrutural de todas as unidades e revisão semântica dirigida a erros evidentes após comparação dos textos. A numeração do cotejo é o índice absoluto do parágrafo no DOCX. Todas as unidades foram mantidas na ordem original. **Não houve auditoria independente e exaustiva frase a frase de cada trecho preservado do EPUB**; outras imprecisões e problemas de estilo podem subsistir. A tradução de trechos não alterados reproduz substancialmente a base portuguesa.

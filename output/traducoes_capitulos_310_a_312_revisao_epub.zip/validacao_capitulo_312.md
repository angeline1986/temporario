# Validação do capítulo 312

- **Original:** `novel_capitulos_301_a_360(20261107-181903).docx` (chinês).
- **Tradução-base:** `novel capitulos 301 a 360 - ch.epub` (`index_split_011.html`).
- **Índices absolutos do DOCX:** 890–973 (base zero, lacunas de parágrafos vazios preservadas).
- **Unidades não vazias no original e na saída:** 82 e 82, inclusive títulos e marcadores.
- **Unidades corrigidas diretamente:** 35; outras receberam normalização pontual de nomes e pensamentos.

## Problemas de tradução e decisões editoriais

- O original afirma que o prazo é de uma semana, mas a punição é condicionada à permanência de Gu Sijin no palácio após o festival, embora a missão seja impedir sua saída; registrada possível incoerência interna, sem normalização.
- Corrigidas reversões de interlocutores e gênero referentes à imperatriz-viúva, Zhu Xihua, Qiqi e Bengbeng.
- A expressão 磕到了 indica entusiasmo por um casal, não agressão física.
- Ameaça ligada a desvio de fundos de auxílio a desastres e risco para os clãs Zhu e Guo.

## Método e limites

Cotejo estrutural de todas as unidades e revisão semântica dirigida a erros evidentes após comparação dos textos. A numeração do cotejo é o índice absoluto do parágrafo no DOCX. Todas as unidades foram mantidas na ordem original. **Não houve auditoria independente e exaustiva frase a frase de cada trecho preservado do EPUB**; outras imprecisões e problemas de estilo podem subsistir. A tradução de trechos não alterados reproduz substancialmente a base portuguesa.

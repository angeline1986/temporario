Capítulo 312 — A imperatriz-viúva ameaça Zhu Xihua

Xiao Qi: 【Mas, hospedeira... Ai...】

Parecia haver algo que o sistema não podia dizer. Hesitava, bastante constrangido:

【Está bem... Se não quiser cumprir a missão, não cumpra.】

【Mas há um prazo de uma semana. Daqui a uma semana será o Festival das Lanternas. Se, depois do festival, Gu Sijin ainda estiver no palácio, terei de aplicar a punição: retirar 10% da sua vitalidade e fazer você dormir por um dia.】

Acrescentou então, timidamente:

【Mas foi você quem decidiu não cumprir a missão, viu? Não tem nada a ver comigo...】

Ning Xiaoxiao respondeu com voz fria:

【Não vou aceitar nenhuma missão que possa machucar A-Yuan ou Xiao Gu. Nem precisa mais me apresentar missões assim.】

Xiao Qi: [Mas anfitrião...]

Ning Xiaoxiao: 【Cale a boca! Some daqui!】

Xiao Qi: 【Ah, certo, já estou indo! Não fique brava, hospedeira...】

Após se livrar daquele pequeno bastardo, a raiva de Ning Xiaoxiao inconscientemente se espalhou pelo seu rosto.

Ao ver isso, Gu Sijin presumiu que ela estava emburrada porque não sabia como fazer bolo de açúcar de osmanthus, então explicou-lhe pacientemente novamente.

— Pare com isso! Vai ser constrangedor se alguém nos vir!

Enquanto conversavam, de repente ouviram risadas e barulhos de brincadeira vindos do pátio.

As duas abriram uma fresta na janela da pequena cozinha e viram Qiqi e Bengbeng brincando.

Os dois corriam em volta da árvore diante da porta. Bengbeng, com passadas mais largas, logo alcançou Qiqi.

Ele segurava uma peônia vermelha em plena floração, colocou-a nos cabelos de Qiqi e disse timidamente, com o rosto corado:

"É tão lindo..."

Qiqi riu: "As flores do Jardim Imperial foram todas cuidadosamente selecionadas pelo Departamento de Flores e Pássaros. Como poderiam não ser belas? Deixando isso de lado, é um crime grave para os servos do palácio colherem flores casualmente no Jardim Imperial. Você não quer perder a cabeça?"

Bengbeng ergueu o olhar, seu olhar endurecendo subitamente:

— Quero dizer que você é mais bonita do que as flores.

Uma frase fez Qiqi corar.

Duas pessoas tímidas permaneciam em silêncio, frente a frente. O vento agitava as folhas, e a luz do sol, filtrada pelas folhas, iluminava-as, criando uma bela imagem repleta de terno amor.

Ning Xiaoxiao assistia à cena com um sorriso de tia coruja.

"Antes que minha irmã deixe o palácio, vamos nos divertir um pouco?"

"Qiqi e Bengbeng já expressaram seus sentimentos um pelo outro. Como são pessoas afetuosas e nos serviram por tanto tempo, devem receber o que merecem."

Gu Sijin também abriu um sorriso de quem estava adorando aquele casal. — E não vamos esquecer o eunuco Sanfu e Ahuan. Os dois ajudaram muito a derrubar a antiga imperatriz.

— Claro. Amanhã vou falar com o imperador. Desde que me tornei imperatriz, ainda não pedi nenhum favor a ele; deve atender a esse pedido tão pequeno.

"Ele se atreve a te recusar?"

Gu Sijin a examinou com um sorriso travesso: "Afinal, ouvi o Imperador chamando você de 'Pequena Ancestral' em particular~"

Ning Xiaoxiao não ficou atrás. Fingiu ter ânsias de vômito e provocou: — Pois ontem eu ouvi o comandante Chu chamá-la de “meu bem”! Também vi você se aninhar no peito dele, dizendo que falava demais!

"Você! Você está pedindo por isso! Bem feito para você por falar besteira!"

*

Palácio Yingquan.

À tarde, Zhu Xihua voltou depois de lavar os pés de Li Fei.

Ela mergulhou as mãos em suco de rosas.

Depois de ficar de molho por um tempo, ela tirou as mãos e as cheirou novamente. O cheiro de repolho em conserva parecia ter impregnado sua pele e se impregnado em sua carne e ossos, e ela não conseguia tirá-lo, por mais que lavasse.

"A Imperatriz Viúva chegou!"

Ao ouvir o anúncio, Zhu Xihua tirou as mãos da bacia, enxugou-as rapidamente na roupa e correu até a porta para receber a visitante.

Ela fez uma reverência e uma mesura:

"Esta concubina saúda a Imperatriz Viúva. Que a Imperatriz Viúva desfrute de bênçãos infinitas."

Ajoelhe-se!

A Imperatriz Viúva lançou-lhe um olhar com seus olhos de fênix, a voz carregada de raiva.

Zhu Xihua tremeu de medo e imediatamente se ajoelhou diante da Imperatriz Viúva:

— Imperatriz-viúva, acalme sua ira! Não sei o que fiz de errado para deixá-la...

"Estou te mantendo no palácio, mas você sabe o que está acontecendo na corte?"

— Eu... Não recebi nenhuma carta de meu pai ultimamente, então não sei o que aconteceu.

— Hmph!

A Imperatriz Viúva zombou friamente e sentou-se à mesa, deixando a mulher ajoelhada na porta continuar ajoelhada.

"Como seu pai lidou com as coisas?"

— Quando seu pai tentou atrair Gu Yanchuan para investigar Tong Guowei, como acabou deixando provas comprometedoras nas mãos dele?

Os olhos de Zhu Xihua tremeram: "Esta... esta concubina não sabia de nada disso..."

"Você não sabe?"

A Imperatriz Viúva ergueu sua bengala com cabeça de fênix e a bateu com força no chão.

"Você não sabe quanto dinheiro destinado ao auxílio em desastres seu pai e seus associados do Departamento de Transportes do Norte desviaram ao longo dos anos?"

— Se não fosse isso, como seu pai, com aquele salário, teria conseguido comprar uma mansão tão enorme em Jiangnan?

Zhu Xihua realmente desconhecia esse assunto, mas sabia que a Imperatriz Viúva não inventaria algo do nada.

Além disso, seu pai de fato possuía muito dinheiro de fontes duvidosas, sobre o qual ela nunca havia questionado antes.

Depois da queda de Tong Guowei, os clãs Zhu e Guo eram os mais poderosos da corte.

Se for comprovado que Zhu Zhenshan desviou fundos públicos e se apropriou indevidamente de verbas destinadas ao auxílio em desastres, sua família provavelmente sofrerá o mesmo destino da família Tong.

É claro que a família Guo, a família materna da Imperatriz Viúva, e a família Zhu estavam em conluio, então a família Guo não tinha como limpar seu nome nessa questão.

Zhu Xihua era uma mulher inteligente e compreendeu imediatamente o propósito da visita da Imperatriz Viúva naquele dia.

"Vossa Majestade, realmente não sei nada sobre este assunto. Mas, por favor, fique tranquilo, enviarei uma carta ao meu pai assim que possível, para que ele..."

— Você é inteligente; não pretendo ficar dando voltas com você.

A imperatriz-viúva levantou-se de súbito, aproximou-se de Zhu Xihua e lhe ergueu o queixo com os dedos.

"Peça ao seu pai para resolver essa questão para mim o mais rápido possível e não envolva minha família materna."

Ao apertá-lo, as longas proteções de unha feitas de ouro cortaram o rosto de Zhu Xihua.

O sangue pingava da armadura no chão; o rosto da Imperatriz Viúva estava sombrio.

"Saiba que a família Guo é a minha prioridade máxima. Se alguém prejudicar os interesses da família Guo, eu jamais deixarei essa pessoa impune."

Zhu Xihua tremia de medo e apreensão:

— Acalme-se, imperatriz-viúva! Farei meu pai resolver essa questão e não permitirei que Gu Yanchuan tenha a menor oportunidade de implicar o clã Guo.

A imperatriz-viúva prosseguiu: — Gu Yanchuan está reunindo provas. Quando os censores querem investigar, praticamente nada lhes escapa.

— Dou a você, no máximo, um mês. Se o clã Zhu não resolver isso nesse prazo, não garanto que o clã Guo não se volte contra vocês para se proteger e mande toda a sua família para a morte!

Zhu Xihua respirou fundo, tentando ao máximo se acalmar.

— Não se preocupe, imperatriz-viúva. O clã Zhu não vai decepcioná-la!

— Hmph! Assim espero. — A imperatriz-viúva soltou com desprezo o rosto dela. — Se resolver isso, usarei minha influência na corte para pressionar o imperador a conceder-lhe novamente um posto de Consorte.

— Eu lhe prometo: enquanto eu viver, mais cedo ou mais tarde o posto de imperatriz será seu.

"Mas a condição é que você seja obediente e capaz de resolver meus problemas, não de criar problemas. Entendeu?"

Ao ouvir isso, Zhu Xihua fez uma profunda reverência.

— Esta humilde concubina agradece à imperatriz-viúva por planejar tudo por mim. Não decepcionarei sua confiança!

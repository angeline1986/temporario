# Validação do capítulo 310

- **Original:** `novel_capitulos_301_a_360(20261107-181903).docx` (chinês).
- **Tradução-base:** `novel capitulos 301 a 360 - ch.epub` (`index_split_009.html`).
- **Índices absolutos do DOCX:** 709–797 (base zero, lacunas de parágrafos vazios preservadas).
- **Unidades não vazias no original e na saída:** 87 e 87, inclusive títulos e marcadores.
- **Unidades corrigidas diretamente:** 30; outras receberam normalização pontual de nomes e pensamentos.

## Problemas de tradução e decisões editoriais

- O apelido 淵淵 refere-se a Lu Linyuan, um homem; o EPUB atribuiu gênero feminino no título e no desfecho.
- 答應 corresponde a Dama, não ao posto genérico de Consorte.
- O imperador sente as cólicas de Ning por causa da pílula; humor e ponto de vista foram recuperados.

## Método e limites

Cotejo estrutural de todas as unidades e revisão semântica dirigida a erros evidentes após comparação dos textos. A numeração do cotejo é o índice absoluto do parágrafo no DOCX. Todas as unidades foram mantidas na ordem original. **Não houve auditoria independente e exaustiva frase a frase de cada trecho preservado do EPUB**; outras imprecisões e problemas de estilo podem subsistir. A tradução de trechos não alterados reproduz substancialmente a base portuguesa.

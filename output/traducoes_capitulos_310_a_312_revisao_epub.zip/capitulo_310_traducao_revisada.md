Capítulo 310 — Linyuan está sofrendo, mas não diz nada

Hahaha~

Abaixo do salão, Gu Sijin assumiu a liderança, fazendo com que as concubinas caíssem na gargalhada.

O rosto de Zhu Xihua alternava entre o lívido e o rubro. Ela apertou os lábios, contendo as lágrimas.

Ning Xiaoxiao não suportava o jeito pretensioso dela.

— Foi você mesma quem disse que queria servir aos outros. Não fique aqui se fazendo de vítima, ou vão pensar que estou maltratando você.

— N-não... — Zhu Xihua balançou a cabeça e enxugou os olhos avermelhados com a manga. — Esta humilde concubina não se sente injustiçada.

— Se não se sente injustiçada, então beba logo essa água e termine de lavar os pés da Consorte Li! Quem você pensa que é, uma simples Dama, para deixar tantas senhoras esperando?

Zhu Xihua se recompôs, pegou a bacia de banho de pés novamente, tomou um grande gole e, reprimindo a náusea, disse a Ning Xiaoxiao:

"Majestade, a temperatura da água está adequada."

"Certo, então vamos começar."

Zhu Xihua agachou-se diante da Consorte Li e mergulhou na bacia aqueles pés que cheiravam a repolho azedo fermentado.

Ela massageou delicadamente os pés da Consorte Li com ambas as mãos, o cheiro de repolho em conserva fazendo seus olhos arderem e lágrimas caírem incontrolavelmente.

Ning Xiaoxiao olhou para ela.

Por que você está chorando? Você não quer?

— Não... Agradeço à imperatriz por conceder a esta humilde concubina a honra de segurar os delicados pés da Consorte Li. Estou radiante de felicidade.

Ning Xiaoxiao sorriu: "Contanto que você esteja feliz. A coisa mais importante na vida é ser feliz."

"Já que você gostou, posso garantir que haverá coisas como hoje que te farão feliz todos os dias, e cada uma será diferente."

"Garanto que sua vida no palácio será rica, colorida e repleta de alegria daqui para frente."

Ning Xiaoxiao sabia perfeitamente que, por maior que fosse o poder da Imperatriz Viúva, jamais poderia superar o de seu A Yuan.

Mesmo que a imperatriz-viúva concedesse a Zhu Xihua o posto de Dama, Lu Linyuan poderia trancar as portas do Palácio Yingquan e mantê-la presa ali até morrer.

Portanto, Lu Linyuan permitira deliberadamente que Zhu Xihua retornasse ao harém, para que ela viesse apresentar seus respeitos a Ning Xiaoxiao.

Como marido e mulher, ela sabia muito bem o que seu A-Yuan queria fazer.

Ele só queria que Ning usasse todos os meios possíveis para atormentar Zhu Xihua e cobrasse as injustiças que sofrera nas mãos dela.

Ning Xiaoxiao nunca foi uma santa, nem acredita que admitir erros e corrigi-los seja uma grande virtude.

Alguns erros podem ser corrigidos.

Mas alguns erros, a menos que a pessoa morra, jamais poderão ser corrigidos durante sua vida.

Caso contrário, por que existiria uma expressão idiomática como "expiar os pecados com a morte"?

Ning Xiaoxiao estava se divertindo ao ver Zhu Xihua lavar os pés da Consorte Li quando ouviu um eunuco anunciar à porta:

"O Imperador chegou!"

O anúncio do eunuco veio um pouco tarde; quase assim que o som agudo e prolongado se dissipou, Lu Linyuan já havia entrado no salão principal.

As concubinas levantaram-se rapidamente e ajoelharam-se para prestar-lhe homenagem. Zhu Xihua também tirou as mãos da bacia, enxugou-as no corpo e depois ajoelhou-se diante de Lu Linyuan.

Ning Xiaoxiao não se curvou.

Ela se levantou, saltitou alegremente como uma coelhinha até Lu Linyuan, tomou sua mão e se aninhou nele:

"Por que A-Yuan está aqui neste momento?"

A dor abdominal de Lu Linyuan havia diminuído um pouco, mas os pulos e saltos de Ning Xiaoxiao faziam com que sua barriga parecesse estar sendo golpeada por um homem forte com uma marreta novamente...

Ele realmente estava lascado. Obrigado por nada!

Por isso, tomou sua pequena preciosidade nos braços e, com todo o cuidado, levou-a de volta ao trono da fênix.

— Hoje é melhor você se movimentar o mínimo possível.

"Por que?"

"Usei força demais ontem à noite... receio que suas pernas estejam fracas hoje."

As concubinas olharam para os dois com inveja: Será que isso é algo que se pode dizer?

O rosto bonito de Ning Xiaoxiao corou levemente com um rubor de quem bebeu demais. "Não fale bobagens..."

"O que há para ter vergonha?"

A súbita dor de estômago havia temporariamente anestesiado o olfato de Lu Linyuan, mas agora que o pequeno ancestral havia se sentado, sua dor de estômago havia diminuído um pouco.

Foi então que ele sentiu imediatamente aquele cheiro de repolho azedo.

Ele levantou a manga para cobrir a ponta do nariz. "Vocês estão conservando chucrute no palácio?"

Ning Xiaoxiao ergueu uma sobrancelha para a Consorte Li, cujos pés ainda estavam imersos na bacia abaixo do salão.

— A Dama Zhu está lavando os pés da Consorte Li. Ultimamente, os pés da Consorte Li andam suando muito, então pedi à Dama Zhu que cuidasse deles.

Lu Linyuan olhou na direção do olhar dela e viu que Zhu Xihua estava sendo extremamente cuidadosa ao lavar os pés da Consorte Li, a fim de ganhar sua simpatia.

Ela então assumiu uma aparência lamentável e encantadora, na esperança de despertar um momento de piedade em Lu Linyuan.

Ela continua sendo uma leoparda que não muda suas manchas; mesmo agora, ela não consegue enxergar a realidade e se recusa a desistir.

No entanto, seu "pequeno truque" parece ter surtido efeito.

Lu Linyuan perguntou-lhe, aparentemente com preocupação:

— Por que está lavando pés aqui?

Zhu Xihua sentiu uma onda de emoção e adotou de propósito uma voz embargada:

"Vossa Majestade... esta concubina..."

"Por que você não esfrega um pouco?", disse Lu Linyuan impacientemente.

"Os pés de Li Fei estão todos marinados; como você pode limpá-los apenas deixando-os de molho?"

“......”

— Esta humilde concubina reconhece seu erro... Vou esfregar agora mesmo...

"Muito bem, muito bem, você não precisa mais esfregar aqui. Volte ao palácio da Consorte Li e esfregue devagar."

Lu Linyuan expulsou impacientemente todas as concubinas e olhou para Ning Xiaoxiao com um toque de desdém nos olhos:

— Não é por nada, mas não podia mandar que ela lavasse os pés da Consorte Li lá fora, junto ao portão?

"Veja o que isto fez ao seu palácio!"

Ele sentiu náuseas depois de dizer apenas algumas palavras, então pegou Ning Xiaoxiao novamente no colo e a levou de volta para seu quarto.

Quando chegaram aos aposentos, Ning Xiaoxiao viu o diretor Song e vários médicos imperiais reunidos diante de sua cama.

Ela ficou atônita. "Isto é..."

Lu Linyuan aproximou-se do ouvido dela e sussurrou:

"Eu me informei sobre isso; se houver algum problema com o fluxo menstrual, é difícil engravidar. É por isso que pedi ao diretor Song para trazer pessoas aqui hoje para tratar completamente esse sintoma."

"Hã? Talvez não precisemos...?"

Ning Xiaoxiao detesta tomar remédios. "Hoje eu estava menstruada, mas a dor durou pouco. Será que já me recuperei completamente?"

Ela até se levantou e deu alguns pulinhos, com medo de que Lu Linyuan não acreditasse nela.

Lu Linyuan: o(╥﹏╥)o

Linyuan estava sofrendo, mas Linyuan não ia reclamar...

Ele pressionou sua grande mão sobre Ning Xiaoxiao, com as sobrancelhas franzidas de dor, parecendo estar torcidas como um pretzel.

— Minha pequena ancestral, pare com essas acrobacias! Mesmo que não doa, pulando desse jeito, não tem medo de manchar a roupa?

Ning Xiaoxiao: “???”

【Socorro! Ele entende disso demais! Será que já passou por isso?!】

......

Mais ou menos! Embora eu nunca tenha menstruado, hoje pude sentir na própria pele!

Ele a persuadiu por um longo tempo antes que ela finalmente concordasse em deixar o médico imperial tratá-la.

O diretor Song trouxera os melhores especialistas em saúde feminina da Academia Imperial de Medicina. Depois de examinar o pulso de Ning Xiaoxiao, eles pesquisaram durante várias noites até encontrar uma prescrição apropriada.

Lu Linyuan convenceu sua pequena ancestral a tomar o remédio diariamente. Após mais de um mês de tratamento, sua saúde melhorou, enfim, em abril.

Lu Linyuan não precisou perguntar se ela estava melhor: quando chegou a época da menstruação naquele mês e ele não sentiu dor alguma, presumiu que estava curada.

Mas ele mal sabia...

Na verdade, quando chegou a data esperada, Ning Xiaoxiao simplesmente não menstruou naquele mês.

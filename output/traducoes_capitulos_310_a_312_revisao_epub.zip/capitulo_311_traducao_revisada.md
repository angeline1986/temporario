Capítulo 311 — Gu Sijin se prepara para fingir a própria morte e deixar o palácio

A própria Ning Xiaoxiao também estava confusa.

Gu Sijin já havia menstruado. Por que a menstruação dela ainda não tinha vindo?

Não diziam que, quando uma menstruava, as outras acabavam menstruando também?

Já se passaram cinco ou seis dias e ainda não há sinal dele...

Será que os remédios estranhos que tomara no mês anterior tinham feito os médicos imperiais provocar uma menopausa precoce?

Mas, se a menstruação não viesse, também não haveria cólicas. Ela se preocupou por pouco tempo e logo deixou o assunto de lado.

*

Naquele dia, enquanto almoçava com Lu Linyuan, ele lhe disse algo:

"Aquilo que você sempre me pede insistentemente já foi providenciado."

"O Festival das Lanternas é no meio deste mês, então podemos combinar para que Gu Sijin 'se afogue' nessa época."

Ning Xiaoxiao pousou os pauzinhos. — Então vai usar essa ocasião para ajudar minha irmã a sair do palácio?

Lu Linyuan assentiu. — Com o clã Tong arruinado e Zhu deposta, ninguém mais ficará vigiando o harém. Oficialmente, Gu Sijin ainda é uma mulher do harém; precisamos planejar sua saída com cuidado para evitar que, no futuro, alguém descubra a verdade sobre ela e Chu Xingran e os condene.

Ning Xiaoxiao sorriu feliz, e o peso que vinha pressionando seu coração finalmente desapareceu.

"Ótimo... finalmente poderei realizar o desejo da minha irmã."

Lu Linyuan ergueu uma sobrancelha e a examinou de cima a baixo. "Então, quando você pretende realizar meu desejo?"

Ao observar o sorriso malicioso em seus lábios, ela soube que ele estava pensando naquelas coisas indecentes novamente.

— Ai, não dá! Estou menstruada... — apressou-se a dizer Ning.

Enquanto falava, ela agarrou a parte inferior do abdômen, fingindo sentir dor.

Lu Linyuan estava perplexo. Ele claramente havia tomado a pílula da empatia, então deveria ser ele quem estava sentindo dor.

Será que... parou de funcionar?

Ele ia perguntar se ela estava bem quando ouviu seus pensamentos:

【Mesmo que a menstruação não tenha vindo, também mereço uma folga!】

【Você não sabe o quão assustador você é quando enlouquece? Quem aguentaria seus rins?!】

Lu Linyuan: “...”

Então ela nem estava menstruada?

Ah, então estava encenando tudo para enganá-lo!

Ele largou os pauzinhos, moveu a cadeira e sentou-se ao lado de Ning Xiaoxiao.

Ao se aproximar, sua respiração quente roçou as têmporas de Ning Xiaoxiao.

O homem roçou delicadamente os finos pelos da orelha da menina com a ponta dos lábios, num tom sedutor e provocante:

— Só vou me esfregar em você, não vou entrar.

"???"

【Esfregar é o cacete!】

Ela empurrou Lu Linyuan violentamente, gritando: "Saia daqui!!"

Ela o empurrara com força demais; como a cadeira de Lu Linyuan não tinha encosto, ele perdeu o equilíbrio e caiu no chão.

'baque'

Com um baque surdo, Ning Xiaoxiao viu a nuca dele bater no chão e ele desmaiar.

Foi então que ela percebeu que estava entrando em pânico.

Ela se abaixou depressa para verificar o que acontecera.

Sacudiu os ombros dele e procurou sentir sua respiração. Ué... nada? Ele tinha batido as botas?

Acreditando ter causado uma tragédia e se tornado uma fabricante de viúvas, ela fechou os olhos para retroceder três minutos e recomeçar.

Assim que ela fechou os olhos, sua mão, que repousava na ponta do belo nariz do homem, foi agarrada pelo pulso.

Lu Linyuan puxou-a com força para os seus braços, com a voz baixa e rouca:

“Matar o próprio marido é um crime grave.”

"Você estava fingindo? Você..."

Antes que ela pudesse terminar de falar sem parar, seu marido selou seus lábios com um beijo.

Entre beijos, ele conseguiu dizer algumas palavras:

"Era falso, mas doeu muito."

"Então você tem que compensar-me."

Ning Xiaoxiao usou seu período menstrual como desculpa para evitar a situação por quatro ou cinco dias, mas os dois ainda compartilhavam a cama todas as noites.

Ambos estavam muito atentos a quaisquer mudanças sutis nos corpos um do outro.

Às vezes, aquele “21” ficava de pé a noite inteira, mas A-Yuan ainda se continha, sem ultrapassar os limites combinados.

Pensando nisso, ela sentiu pena dele e fechou o documento do sistema que já havia aberto, sem apertar o botão de retroceder.

*

A brincadeira durou de depois do almoço até quase a hora do jantar. Só quando Ren Duanli apareceu para tratar de assuntos das tropas da fronteira Lu Linyuan finalmente “liberou” sua delicada esposa.

Depois de escapar daquela situação, a primeira coisa que Ning Xiaoxiao fez foi contar a Gu Sijin a boa notícia: dentro de dois dias, a amiga poderia deixar o palácio.

Ao ouvir isso, Gu Sijin a abraçou e chorou de alegria.

Na verdade, nos últimos dias, a vida de Gu Sijin pouco diferia da que teria fora do palácio.

Depois que Ning Xiaoxiao se tornou imperatriz e se mudou para o Palácio Fengluan, Gu Sijin ficou morando sozinha no Palácio Fengyi.

Chu Xingran ia visitá-la a cada poucos dias.

Ning Xiaoxiao, sendo a Imperatriz, na maior parte do tempo os ajudava a se protegerem.

O imperador Lu Linyuan fez vista grossa e os protegeu.

Os dois só não tinham atravessado a última fronteira da intimidade; de resto, já haviam experimentado quase tudo o que os casais costumam fazer.

Embora os amantes pudessem se ver todos os dias no palácio, a sensação era diferente de realmente se casar.

A partir de agora, ela terá um status legal e poderá estar com seu marido abertamente e honestamente.

Ning Xiaoxiao ficou genuinamente feliz por ela. Depois de transmigrar para dentro do livro por tanto tempo, ela finalmente havia mudado o final trágico de Xiao Gu.

No entanto, apesar da alegria, havia também um toque de decepção.

Afinal, depois que Gu Sijin saísse do palácio, Ning não conseguiria vê-la com tanta facilidade.

Acompanhar Gu Sijin até seu casamento foi como uma mãe se despedindo da filha para casar, ou como elevar um card SSR ao nível máximo em um jogo de criação de personagens.

Ao ver que seus olhos também estavam vermelhos, Gu Sijin rapidamente enxugou as próprias lágrimas e perguntou-lhe em voz suave:

Por que você também está chorando? A culpa é minha por te deixar triste.

"Estou muito feliz pela minha irmã."

"Como eu poderia não te conhecer? Nossa amizade é mais forte que a de irmãs juradas, e nossos corações estão naturalmente conectados."

Ela pegou a mão de Ning Xiaoxiao, seus olhos brilhantes, cintilando como água de nascente, olhando diretamente para ela:

— É claro que também me dói deixá-la. Mas sairei do palácio fingindo que morri, e depois será difícil voltar aqui. Estarei na residência do comandante; sempre que sentir saudade, venha me visitar. Prepararei seus bolinhos de osmanthus favoritos.

Ning Xiaoxiao assentiu com firmeza, reprimindo as lágrimas, e sorriu docemente.

Mais tarde, Gu Sijin a levou para a pequena cozinha e a ensinou a fazer doces passo a passo.

Mas Ning Xiaoxiao estava distraída durante a aula, com a cabeça em outro lugar.

Gu Sijin presumiu que ela estava triste demais para estudar por causa da separação, então não a forçou.

Ela mal sabia que estava travando uma batalha mental com Xiao Qi:

【Você ficou maluco, porra?! Se não tem nada para fazer, tire seu próprio plugue da tomada e se autodestrua!】

Xiao Qi: 【Cof, cof! Hospedeira, não brigue comigo! A decisão de cumprir ou não a missão é sua, mas preciso comunicá-la até o fim.】

【Bip, bip, bip! Nova missão para a hospedeira: “Impedir Gu Sijin de deixar o palácio”. Recompensa pelo sucesso: acréscimo de 3 pontos percentuais ao índice de desvio da trama. Falha: perda de 10% da vitalidade...】

Ning Xiaoxiao: 【Não precisa continuar. Não vou cumprir essa missão. Pode descontar a vitalidade. Ainda tenho 90%; tirando 10%, no máximo dormirei por um dia. Não me importo.】

Xiao Qi: 【Hospedeira, não vai mesmo reconsiderar...?】

Ning Xiaoxiao olhou para Gu Sijin, que a estava ensinando cuidadosamente a fazer doces, e respondeu a Xiao Qi em um tom extremamente firme:

【Você não é humano, mas eu sou. Pode me chamar de santinha ou de Mary Sue. Xiao Gu e A-Yuan não são personagens de papel: ambos são pessoas muito importantes para mim!】

【Se quer que eu os machuque para favorecer a mim mesma, vou deixar uma coisa bem clara: nem pensar!】

# Capítulo 81 — Acho que você daria uma ótima esposa

Depois que Lu Linyuan vestiu os trajes da corte, as criadas entraram em fila para ajudá-lo a se lavar e se arrumar.

Ning Xiaoxiao observava tudo em silêncio, refletindo sobre o luxo extravagante da vida dos imperadores de antigamente.

【Ele lava o rosto com leite fresco, escova os dentes com gel de menta e até a água para lavar as mãos leva essência de flores. E ainda tem todas essas beldades para servi-lo. Não é à toa que todo mundo quer ser imperador.】

【Tsc, tsc. Ele pode ser um desgraçado, mas isso não muda o fato de que é bonito de verdade! Até as gotas d'água no rosto dele depois de se lavar parecem sedutoras...】

【A autora original só podia escrever romances voltados para mulheres! Não pensa em outra coisa além de safadeza!】

Lu Linyuan não entendeu as últimas frases, mas percebeu que Ning Xiaoxiao o estava elogiando.

Seu humor melhorou um pouco, e ele deixou de falar com tanta aspereza.

— Quando voltar ao seu palácio, se sua senhora perguntar onde você passou a noite, invente qualquer desculpa. Mas não conte a ninguém que dormiu nos meus aposentos ontem. Entendeu?

Ning Xiaoxiao respondeu sem pensar: — Entendi. Não vou deixar suas esposas com ciúmes~

— Esposas? Que coisa é essa? — perguntou Lu Linyuan.

Devia ter dormido tanto que acordara desnorteada: as expressões modernas saíam de sua boca sem que percebesse.

— N-nada... Não é nada que preste. Só me enrolei nas palavras.

Lu Linyuan soltou um riso abafado e provocou: — Pois eu acho que você daria uma ótima esposa!

— ??? — Ning Xiaoxiao ficou sem reação.

Sentiu as bochechas pegarem fogo. Até o som da própria saliva descendo pela garganta pareceu ensurdecedor. Apressou-se a mudar de assunto.

— Pode ficar tranquilo, Majestade. Não vou contar a ninguém o que aconteceu ontem à noite. Se as consortes entenderem errado e começarem a fofocar, isso também prejudicaria sua reputação~

Lu Linyuan ficou em silêncio.

*Idiota! Estou tentando proteger você. O que minha reputação tem a ver com isso?*

*Por acaso acha que existe mais alguém neste palácio inteiro, além de você, que se atreva a agir com tamanha insolência diante de mim?*

Depois que ele terminou de se arrumar, Xiao Yinzi trouxe o desjejum.

Naquela manhã havia mingau de arroz com camarões grandes e abalone, além de dois pãezinhos recheados de sopa e ovas de caranguejo. O aroma bastou para Ning Xiaoxiao começar a salivar.

【Uau! Esse mingau parece uma delícia! Nhac...】

*Grrrr...*

A barriga dela voltou a protestar, sem a menor consideração.

Lu Linyuan sentou-se à mesa, apanhou uma colherada de mingau e a levou à boca.

Mal engoliu, franziu as sobrancelhas e fez uma careta de repulsa. — O que deu na cozinha imperial hoje?

Irritado, atirou a colher dentro da tigela, espalhando gotas de mingau sobre a mesa. Xiao Yinzi se assustou. — Majestade... Há algum problema com o mingau?

— Está horrível! Parece lavagem de porco! — respondeu Lu Linyuan, impaciente.

Xiao Yinzi não entendia nada.

Como eunuco encarregado de provar as refeições imperiais, precisava experimentar tudo antes de servir ao soberano. E não havia encontrado defeito algum naquele mingau...

Mas a palavra do imperador era lei. Se ele dizia que estava ruim, era preciso retirar a comida imediatamente.

Xiao Yinzi pediu desculpas repetidas vezes e ia levar a tigela embora para descartá-la e buscar outra refeição.

Lu Linyuan, porém, o deteve. — Mesmo comida de porco continua sendo alimento. Jogar fora seria um desperdício. Eu não posso comer, mas certamente há quem seja muito adequado para isso.

Enquanto falava, voltou o olhar vagarosamente para Ning Xiaoxiao.

Ela apontou para si mesma, atônita. — Vossa Majestade está querendo que eu coma?

Lu Linyuan assentiu de leve e empurrou a bandeja na direção dela. — Coma. E, se deixar sobrar alguma coisa, será punida.

Aquilo cheirava tão bem... Se Lu Linyuan não queria comer, com certeza era porque o gosto devia ser péssimo. Se fosse bom, ele jamais a deixaria ficar com aquilo.

Talvez aquele mingau fosse o contrário do tofu fedorento?

Um fedia, mas era delicioso; o outro tinha um cheiro maravilhoso, porém um gosto... horrível?

Não havia jeito. O tirano a estava obrigando a comer, e ela não podia recusar.

Depois de xingar mentalmente dezoito gerações dos antepassados dele, Ning Xiaoxiao pegou a colher com a determinação de quem se encaminhava para o sacrifício e levou, trêmula, um pouco de mingau à boca.

Bastou uma colherada para que seus olhos, apagados pela fome, começassem a brilhar!

Onde é que aquele mingau era ruim?

Era simplesmente delicioso num nível absurdo!

Ning Xiaoxiao jurava nunca ter provado um mingau tão gostoso em toda a vida!

Começou a comer colherada após colherada, cada vez mais feliz. Por fim, abandonou a colher e levou a tigela diretamente à boca, como um fantasminha esfomeado e adorável.

Depois de acabar com o mingau, devorou os pãezinhos de sopa, um por mordida, e soltou um arroto satisfeito.

Quando Xiao Yinzi saiu levando a louça vazia, encontrou Sanfu.

Sanfu espiou a caixa de comida e sorriu. — Ora, o imperador está com um apetite e tanto hoje! Ele sempre come só até ficar setenta por cento satisfeito, mas hoje limpou os pratos!

— Que nada, mestre, o senhor nem imagina... — Xiao Yinzi respondeu, com uma expressão de quem ia chorar. — O imperador não comeu nem uma mordida. Disse que aquilo era lavagem de porco, horrível, e obrigou Ning Xiaoxiao a comer tudo.

— Lavagem de porco? Mas o mingau de camarão com abalone é o favorito de Sua Majestade! E os pãezinhos com ovas de caranguejo? Ele os mencionou outro dia, então pedi especialmente que a cozinha os preparasse. Como isso poderia ser lavagem de porco?

Mestre e discípulo apoiaram o queixo nas mãos ao mesmo tempo, mergulhados em pensamentos.

É claro que aquele desjejum não tinha nada de lavagem de porco. Enquanto assistia Ning Xiaoxiao comer, Lu Linyuan sentira a própria barriga prestes a roncar...

Se não tivesse ouvido aquela mulher maluca pensar que estava quase desmaiando de fome, jamais teria cedido suas comidas preferidas.

A quinta vigília da noite estava chegando, e era hora de Lu Linyuan comparecer à audiência matinal.

Ning Xiaoxiao passara a noite no Palácio Chaoyang dormindo bem e comendo até se fartar. Uma maravilha de vida.

Já Lu Linyuan não dormira direito nem conseguira tomar café da manhã. Um verdadeiro coitado.

Lembrando que não voltara ao Palácio Zhongcui a noite inteira e que Gu Sijin devia estar morrendo de preocupação, Ning Xiaoxiao disse: — Vossa Majestade precisa ir à audiência. Eu também tenho de voltar e avisar minha senhora. Ela não me vê desde ontem; deve estar muito preocupada.

— Espere um instante. — Lu Linyuan se levantou e entrou no aposento interno. Depois de algum tempo fazendo sabe-se lá o quê, reapareceu com um livro enrolado nas mãos.

Atirou o volume para Ning Xiaoxiao. Ela olhou a capa e viu dois caracteres enormes: **Virtudes Femininas**.

— Você passa os dias se comportando como uma lunática, sem o menor cuidado com suas ações. Continuando a servir no harém dessa maneira, mais cedo ou mais tarde vai causar um escândalo. Leve este *Virtudes Femininas*, leia com atenção e copie três vezes. Se ousar fazer corpo mole, quebro suas mãos!

O que Ning Xiaoxiao mais odiava eram castigos de copiar textos!

Quando estudava, preferia que chamassem seus pais à escola a ter de copiar qualquer coisa como punição!

Quem diria? Agora era adulta, havia até atravessado para dentro de um romance... e continuava sem escapar de copiar textos de castigo.

Fraca como era, não ousava perder a cabeça na frente de Lu Linyuan. Restava-lhe reclamar mentalmente.

【Eu entendo tudo, mas... por que você tem um exemplar de *Virtudes Femininas* nos seus aposentos? Olha só a capa! Está tão manuseada que quase criou uma pátina! Quantas vezes você já leu isso? O quê? Ser homem não está te fazendo feliz e agora resolveu estudar como ser uma mulher virtuosa?】

Lu Linyuan: — ...

*Não estou feliz sendo homem? Muito bem! Então vou tratar de fazer você aproveitar bastante a experiência de ser mulher!*

Ele mudou de ideia na mesma hora. — Pensando melhor, copie dez vezes. Você é um tanto lerda para aprender. Três cópias não bastariam para entender o conteúdo; dez devem servir.

Ning Xiaoxiao: 【Sabe por que o alfabeto passou de 26 letras para 25 depois que eu apareci? Porque eu levei o Q comigo! Obrigada por nada!】

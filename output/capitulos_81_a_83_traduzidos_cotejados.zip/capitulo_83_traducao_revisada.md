# Capítulo 83 — Modo de Extermínio Ativado no Harém

Ning Xiaoxiao retirou cuidadosamente todos os fios escondidos entre as páginas do *Virtudes Femininas*. Eram trinta ao todo.

Não era uma fortuna, mas também não era pouco. Economizando, daria para muita coisa.

Mal guardara os cabelos, ouviu a voz de Gu Sijin no pátio: — Se não encontraram, continuem procurando! Não há notícias do imperador. Se for preciso, vou implorar novamente à imperatriz que nos ajude.

Ning Xiaoxiao saiu do quarto e chamou de longe: — Minha senhora~ Voltei~!

Todos olharam ao mesmo tempo. Com exceção de Cailian, praticamente todos correram na direção dela.

Alguns lhe pegaram as mãos e rodopiaram de alegria; outros levaram a mão ao peito e agradeceram aos deuses. Gu Sijin, depois de um instante de alívio, assumiu uma expressão severa. — Onde você se meteu? Faz ideia de como todos ficaram preocupados?

Ning Xiaoxiao mostrou a língua, travessa. — Minha senhora... Pensei que o verão já está acabando e quis colher flores do Jardim Imperial antes que murchassem, para preparar essências florais para a senhora. Mas de repente me deu um sono... Encostei numa árvore para descansar um pouquinho e, quando abri os olhos, já era dia...

Gu Sijin suspirou, resignada. — Ah, Xiaoxiao... Da próxima vez, avise alguém do palácio aonde vai. Não faça mais uma coisa dessas, entendeu?

Cailian se aproximou com ar desdenhoso e uma voz carregada de ironia. — Você disse que foi colher flores. E onde estão elas?

Ning Xiaoxiao revirou os olhos. — Acordei e fiquei tão preocupada com o susto que minha senhora devia estar levando que vim correndo. Como ia me lembrar de trazer flores?

— Ah, claro. A boca é sua, então pode dizer o que bem entender. Quem sabe onde foi ontem à noite ou que coisas vergonhosas andou fazendo!

— Cailian! Chega! — Gu Sijin a repreendeu. Depois acrescentou: — Xiaoxiao passou a noite fora. Provavelmente ainda não comeu. Vá buscar alguns bolinhos na cozinha para ela, antes que fique com fome.

— Senhorita! Aqueles bolinhos são para os senhores! Ning Xiaoxiao não passa de uma criada. Ela merece comê-los?

Gu Sijin não disse nada. Apenas ergueu a sobrancelha e lançou-lhe um olhar.

Cailian percebeu que, se insistisse, só acabaria levando outra reprimenda. Saiu furiosa, sacudindo as mangas.

Todos ainda conversavam no pátio quando uma voz suave soou às suas costas: — Ora, que animação por aqui hoje!

Ao se virarem, reconheceram a Consorte Duan. Todos, liderados por Gu Sijin, prestaram-lhe reverência.

A Consorte Duan ajudou Gu Sijin a se levantar. — Nós nos vemos todos os dias. Aqui no seu palácio, não precisa de tantas formalidades comigo.

Gu Sijin notou que Xiuer carregava vários embrulhos e que a Consorte Duan vestia roupas comuns. Perguntou, curiosa: — Vossa Alteza vai a algum lugar?

A Consorte Duan sorriu. — Meu pai prestou um grande serviço à corte. O imperador perguntou o que ele desejava como recompensa, e meu pai respondeu que sentia saudades de mim. Assim, Sua Majestade permitiu que eu voltasse à casa de minha família por dois dias.

A inveja era evidente nos olhos de Gu Sijin. — Parabéns, Vossa Alteza.

— Estou no palácio há três anos e esta é a primeira oportunidade que tenho. Você conta com o favor do imperador; espero que em breve tenha boas notícias na barriga. — A Consorte Duan acariciou o ventre de Gu Sijin e sorriu com serenidade. — Quando tiver um filho, as mulheres de sua família poderão vir ao palácio fazer-lhe companhia por dois ou três meses. Aí serei eu quem terá motivos para invejá-la.

*Engravidar?*

Gu Sijin lançou involuntariamente um olhar para o bracelete que a Consorte Duan lhe dera e que ainda usava no pulso. Sorriu, dizendo apenas que sua sorte não era tão boa quanto a da consorte.

Depois que a Consorte Duan partiu, Gu Sijin foi tirar uma soneca. Ning Xiaoxiao voltou a copiar o *Virtudes Femininas*.

Não fazia nem quinze minutos que escrevia quando, com um estrondo, alguém escancarou a porta com um chute.

Cailian entrou carregando um prato de bolinhos estragados, que largou sobre a mesa de Ning Xiaoxiao. — Coma — disse, impaciente.

O prato bateu no tinteiro e espalhou tinta sobre a folha que Ning Xiaoxiao acabara de copiar.

Ela mal sabia usar o pincel de caligrafia e precisara escrever até a mão doer para terminar aquela página. Agora Cailian a destruíra! Era de perder a cabeça.

Quando Cailian virou as costas para sair, Ning Xiaoxiao largou o pincel, avançou e a agarrou pelos cabelos, arrastando-a de volta ao quarto.

— Ai! Ning Xiaoxiao, o que está fazendo? Me solta!

Ning Xiaoxiao nem lhe deu atenção. Arrastou-a pelos cabelos até a mesa e enfiou todos os bolinhos podres em sua boca, impedindo-a de gritar.

— Você não consegue passar um único dia sem ser uma cretina, não é?

Cailian se debateu, aterrorizada. A mão com que Ning Xiaoxiao a segurava trazia a pulseira dada por Lu Linyuan.

Mas aquela pulseira não era a mesma. Por mais parecida que fosse, não era o presente de sua mãe.

Se Cailian não tivesse roubado a pulseira naquele dia, nada do que veio depois teria acontecido.

Quanto mais pensava nisso, mais furiosa Ning Xiaoxiao ficava. Pegou o tinteiro e despejou a tinta na boca de Cailian.

Cailian conseguiu empurrá-la para longe e caiu de joelhos, engasgando e tentando vomitar. — Ning Xiaoxiao! Você enlouqueceu?!

— Hoje vou lhe mostrar o que é uma louca de verdade!

Ning Xiaoxiao ergueu o tinteiro, pronta para acertar a testa de Cailian, mas se conteve no último instante.

Xiao Qi avisara claramente que ela não podia causar diretamente a morte de personagens da trama original. Isso poderia desencadear acontecimentos desconhecidos e deixá-la presa naquele mundo para sempre.

Seu objetivo final ainda era voltar para casa. Uma pequena impaciência podia arruinar um grande plano.

Ela atirou o tinteiro diante de Cailian, pisou sobre seu peito e rosnou: — Eu não sou Gu Sijin e muito menos sua mãe! Não tenho paciência para continuar tolerando suas provocações! Escute bem: não mexa mais comigo. Ou, da próxima vez, esse tinteiro vai parar bem na sua testa!

Cailian era do tipo que oprimia os fracos e tremia diante dos fortes. Pediu desculpas depressa, dizendo que Ning Xiaoxiao a havia entendido mal.

Ning Xiaoxiao a encarou ferozmente. — Levante-se!

Cailian se levantou obediente como um cachorrinho. Ning Xiaoxiao lhe deu um chute no traseiro, fazendo-a cambalear até a mesa.

— Você anda tão sem virtude que precisa de umas aulas. Está vendo o *Virtudes Femininas* sobre a mesa? Copie dez vezes. Não pergunte por quê. Se questionar, arrebento sua boca!

Cailian ficou paralisada de medo. Nem ousou soltar um pio e obedeceu.

Enquanto Ning Xiaoxiao a vigiava copiando o livro, Xiao Qi apareceu.

【Hospedeira, hospedeira~ Você recebeu uma missão nova.】

【Ative o modo de extermínio no harém e faça com que qualquer personagem antagonista da trama original seja eliminado antes da hora.】

【Recompensa pelo sucesso: 3% no índice de desvio da trama. Penalidade pelo fracasso: menos 20% de vida da hospedeira.】

Um brilho surgiu nos olhos de Ning Xiaoxiao, e os cantos de seus lábios se ergueram sem que percebesse.

*Dessa missão ela gostava!*

Observou Cailian copiar o *Virtudes Femininas* entre lágrimas, e seu olhar tornou-se cortante.

Parecia ter chegado a hora de acertar todas as contas, novas e antigas, com aquela idiota insuportável.

Sua primeira ideia foi simplesmente alterar a trama para fazer Cailian “morrer”, mas Xiao Qi a advertiu:

【Hospedeira, é preciso haver uma razão plausível para que ela saia da história. Se simplesmente cair morta do nada, a missão não será considerada concluída.】

Em outras palavras, precisava esperar uma oportunidade: o momento em que Cailian não resistisse à vontade de provocar alguém de novo.

Isso não seria particularmente difícil.

Afinal, aquela falsa sonsa não parecia saber fazer outra coisa além de provocar os outros o dia inteiro.

*(Nota da autora no original: a plataforma Fanqie ajustou recentemente seu sistema de avaliações. Se as notas estiverem estranhas, não significa que alguém esteja dando avaliações baixas de propósito; talvez voltem a subir em breve. Não se preocupem. Amo vocês!)*

# Capítulo 82 — Oi~ Heroína das Cuecas!

Segurando de má vontade o *Virtudes Femininas*, Ning Xiaoxiao saiu do quarto atrás de Lu Linyuan, de cabeça baixa.

— Irmãããão~~~!

O chamado do príncipe Jing, Lu Yiqiu, era tão meloso que nem aquelas duas ondinhas conseguiam transmitir um décimo do efeito.

Ele acenou animadamente para Lu Linyuan e correu até ele, ofegante como um cachorrinho abanando o rabo.

— Irmããão~ Feliz aniversááário~!

...

O príncipe Jing já tinha dezenove anos, mas, de qualquer ângulo, parecia uma criança grande que nunca amadurecera direito.

Só que era mais bonito e tinha uma personalidade mais fofa do que a média dos bobões.

Escondida atrás de Lu Linyuan, Ning Xiaoxiao o observava. Aquele rosto branco e macio, com bochechas que pareciam elásticas como uma goma QQ... Que vontade de apertar!

Naquele exato instante, os olhares de Lu Yiqiu e dela se cruzaram.

Ele abriu um sorriso impecável, mostrando os oito dentes da frente, e acenou. — Olha só quem está aqui de novo! Heroína das Cuecas~~!

Ning Xiaoxiao: (ΩДΩ)

Lu Linyuan: ￣□￣｜｜

Os criados ao redor: *modo fofoca ativado.jpg*

A expressão “Heroína das Cuecas” saiu de sua boca num volume tão alto que parecia querer garantir que ninguém perdesse uma sílaba.

Depois de atrair todos os olhares, ele completou: — Irmã heroína, você trabalha duro mesmo! Veio tão cedinho roubar qual cueca do meu irmão desta vez?

Os olhares dos criados, afiados como flechas de fofoca, se voltaram para Ning Xiaoxiao. Ela ficou vermelha e engasgada, incapaz de pronunciar uma palavra.

Só conseguiu abaixar a cabeça e lançar uma maldição silenciosa:

【Deus do céu, abre os olhos! Leva logo esses dois irmãos! Prometo passar o resto da vida sem comer carne se os dois morrerem cedo!】

Lu Linyuan lançou-lhe um olhar de lado.

*Droga! Foi meu irmão idiota quem falou besteira! Amaldiçoe ele, então! O que eu tenho a ver com isso? Não estou sendo injustiçado à toa?*

Seu rosto se fechou. Lu Yiqiu imediatamente parou de sorrir e fazer gracinhas, enquanto os criados desviaram o olhar e voltaram às próprias tarefas.

— Irmão! Não consegui voltar a tempo do seu aniversário ontem, então vim pedir desculpas logo cedo! Também preparei um presentão para você~!

— Você? — Lu Linyuan o examinou de cima a baixo, desdenhoso. — Ficar longe de mim já seria o melhor presente que poderia me dar.

— Ah, irmão! — Lu Yiqiu fez um gesto manhoso. — Fique paradinho e deixe eu entregar seu presente!

Apesar das reclamações, Lu Linyuan tinha um enorme carinho pelo irmão caçula.

Quando Lu Yiqiu pediu que ficasse parado, ele obedeceu, curioso para ver que palhaçada viria a seguir.

Para sua surpresa, Lu Yiqiu pulou sobre ele como um coala e o abraçou com toda a força.

Um pouco mais baixo que Lu Linyuan, envolveu-lhe o pescoço com os braços, enterrou o rosto em seu ombro e esfregou o queixo de leve...

Aos olhos de Ning Xiaoxiao, uma fã inveterada de romances entre homens, aquela cena praticamente transbordava bolhas cor-de-arco-íris!

【Eu sabia! Casal de irmãos é imbatível!】

*(Nota do original: “casal ortopédico” é uma gíria chinesa para pares de personagens com parentesco, remetendo ao clichê de novelas antigas em que apaixonados acabam descobrindo que são irmãos.)*

Sua cabeça começou a fabricar cenas escandalosas e impróprias. Lu Linyuan estremeceu e tentou afastar Lu Yiqiu à força.

Mas o irmão estava grudado nele como um emplastro e, além de não se soltar, perguntou: — Irmão! Tem tanta gente querendo ganhar um abraço meu~ Você não gostou desse presentão? Se não gostou, que tal eu te dar um beijinho também?

Ning Xiaoxiao entrou em êxtase de fã; Lu Linyuan ficou todo arrepiado de horror.

Ele apertou o pescoço do irmão com o cotovelo e ameaçou: — Se ousar me dar um beijo, mando costurar sua boca!

Só então Lu Yiqiu o soltou, mostrou a língua, travesso, e disse: — Estou brincando~ O presente verdadeiro é este!

Tirou de dentro das roupas um pingente de jade branco, com um dragão esculpido na frente e nuvens em relevo atrás. O trabalho era delicado, a pedra excelente e o preço certamente exorbitante.

Para alguém como ele, uma criatura que só sabia gastar e nunca economizava, dar um presente daqueles era um sacrifício enorme.

— Irmão, gastei uma fortuna! Ficou emocionado?

*Emocionado?*

*Mal ouso me mexer!*

— Não pense que, só porque me deu uma coisa cara, vou deixar de repreendê-lo. Diga: há quanto tempo não cuida dos assuntos oficiais sob sua responsabilidade?

Lu Yiqiu pareceu uma criança cujas artimanhas acabassem de ser descobertas. Murchou como um balão e voltou a fazer manha.

— Ah, irmão! Não tem acontecido nada de importante ultimamente. Me deixa descansar um pouquinho, vai?

Ele era encarregado dos registros militares — em termos simples, da administração logística para os generais na linha de frente.

Era um serviço tranquilo. Fora ele mesmo quem o pedira, para não parecer que recebia o salário da corte sem fazer absolutamente nada.

Vendo que estava quase atrasado para a audiência, Lu Linyuan desistiu de discutir. — Faça como quiser. De qualquer modo, Ren Duanli voltará à capital em dez dias. Depois você mesmo dará explicações a ele!

— O quê? Ele está voltando? — Num segundo Lu Yiqiu estava fazendo manha diante do irmão; no seguinte já corria até o portão do Palácio Chaoyang e se agarrava ao pinheiro ornamental. — Vou fugir primeiro, irmão! Se ele perguntar por mim, diga que... que morri jovem! Que não precisa me procurar!

Dito isso, desapareceu como uma rajada de vento.

*Ren Duanli?*

Ning Xiaoxiao nunca encontrara esse nome no livro.

Talvez fosse... um personagem secundário sem importância?

Ela perguntou: — Majestade, quem é Ren Duanli? Por que o príncipe Jing não tem medo nem do senhor, mas parece apavorado com ele?

Lu Linyuan deu um sorriso frio. — Hmph. É o comandante mais jovem do acampamento da cavalaria de elite. E o pior pesadelo do príncipe Jing.

Ao perceber o sorriso sugestivo no rosto de Lu Linyuan, Ning Xiaoxiao sentiu que acabara de descobrir outro casal perfeito!

【General de cara fechada × príncipe jovem e ardiloso? Já estou torcendo pelos dois!】

Lu Linyuan revirou os olhos para ela.

*Essa mulher maluca arranja casal para qualquer coisa o dia inteiro?*

*Se gosta tanto de ficar “shippando”, vou lhe dar dois quilos de sementes de girassol para ficar quebrando e comendo até cansar!*

*

Quando retornou ao Palácio Zhongcui, encontrou uma quietude estranha.

Além de Cao Nima, não havia uma única pessoa em todo o palácio.

Ning Xiaoxiao nunca se achara tão importante para os demais criados. Portanto, nem lhe ocorreu que todos tivessem saído à sua procura.

Como Gu Sijin costumava prestar respeitos à imperatriz àquela hora e demoraria a retornar, resolveu ir para seu quarto e começar a copiar o *Virtudes Femininas*.

Mal folheou duas páginas, alguns fios de cabelo caíram do livro.

Ela os recolheu e viu o saldo da lojinha do sistema mudar para **1**!

Isso significava que aqueles fios eram de Lu Linyuan!

— Aposto que caíram quando ele coçava a cabeça lendo! Vou procurar mais!

Folheou rapidamente o volume e, a cada duas páginas, encontrava mais alguns fios. Ficou tão contente que mal conseguia fechar a boca. — Hahahaha! Agora fiquei rica!

Enquanto isso, Lu Linyuan, que estava na audiência da manhã...

...sentia fome, sono e uma dorzinha persistente no couro cabeludo.

*Devo ter algum problema na cabeça! Já dei meu café da manhã a ela. Por que ainda fui arrancar meus cabelos para presenteá-la?*

*Cansei. Pode acabar o mundo!*

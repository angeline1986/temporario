# Validação do capítulo 83

- Fonte primária: `novel_capitulos_61_a_120(20261103-184549).docx`.
- Unidades chinesas não vazias (incluindo título): **63**.
- Linhas de cotejo preenchidas: **63**.
- Correspondências vazias: **0**.
- Limites: início no parágrafo DOCX 1687; próximo capítulo no parágrafo 1753.
- Método: tradução literária com associação manual sequencial das unidades, revisão durante a redação e conferência de cobertura.
- Ressalva: a contagem 1:1 e esta revisão não equivalem a auditoria linguística independente.

## Observações

女德 é Virtudes Femininas; o jogo com falta de virtude foi mantido. Nota extraliterária da autora sobre avaliações da plataforma preservada. O termo 下線 pode significar saída da trama, não necessariamente um método específico de morte.

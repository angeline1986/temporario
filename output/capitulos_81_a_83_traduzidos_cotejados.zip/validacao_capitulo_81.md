# Validação do capítulo 81

- Fonte primária: `novel_capitulos_61_a_120(20261103-184549).docx`.
- Unidades chinesas não vazias (incluindo título): **71**.
- Linhas de cotejo preenchidas: **71**.
- Correspondências vazias: **0**.
- Limites: início no parágrafo DOCX 1535; próximo capítulo no parágrafo 1609.
- Método: tradução literária com associação manual sequencial das unidades, revisão durante a redação e conferência de cobertura.
- Ressalva: a contagem 1:1 e esta revisão não equivalem a auditoria linguística independente.

## Observações

A expressão 老婆 foi traduzida como esposa. A piada 栓Q usa uma aproximação da brincadeira sonora em inglês; convém revisão editorial para maximizar o efeito humorístico.

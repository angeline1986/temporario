# Capítulo 100 — Que uma boa pessoa tenha oito bebês de uma vez!

Sanfu apressou-se a explicar: — Majestade, este servo...

— Cale-se! — Lu Linyuan pegou um travesseiro e o atirou nele.

Sanfu fez uma carinha de injustiçado: Ծ‸Ծ

Exatamente como havia previsto.

Quando a confusão veio à tona, Ning Xiaoxiao ainda tinha chance de se explicar. Quanto a ele, até respirar era um erro.

Tantos anos de lealdade entre senhor e servo... Tudo em vão.

Lu Linyuan era o imperador, e nada era mais importante para um imperador do que a própria dignidade.

Para piorar, aqueles guardas sem noção tinham presenciado uma cena tão constrangedora e nem se lembraram de desviar os olhos.

Lu Linyuan ordenou com severidade: — Todos que entraram sem autorização em meus aposentos esta noite receberão cinquenta golpes de vara!

O pobre Sanfu perguntou: — E este servo...?

— Você? Cinquenta golpes de vara e mais cinquenta tapas na boca! Suma daqui!

A farsa terminou, e todos se retiraram.

O quarto voltou a mergulhar na penumbra; apenas a luz difusa da lua entrava pelas janelas.

Ning Xiaoxiao tentou fugir às escondidas, deslizando junto à parede, na ponta dos pés, como uma ladra que acabara de roubar um coração:

【Você não está me vendo, você não está me vendo, você não está me vendo!】

Já estava quase na porta quando um travesseiro macio de plumas de ganso voou na direção dela e acertou em cheio sua cabecinha.

— Aii!

— Você me acha cego, por acaso?

— Majestade, esta serva...

— Venha aqui. Agora!

— Está bem...

Com a cabeça baixa, ela se aproximou da cama em passinhos miúdos.

Lu Linyuan agarrou-lhe o pulso e a puxou para cima da cama imperial.

Ela perdeu o equilíbrio, e seu rosto acabou encostando na coxa dele.

Que posição constrangedora! Ao erguer os olhos e encontrar o olhar do tirano, pensou a toda velocidade e tomou uma decisão:

Das trinta e seis estratégias, a melhor é chorar!

Antes que Lu Linyuan pudesse repreendê-la, ela começou a berrar: — Buaaa! Majestade, tenha piedade! Não fiz por querer!

Mas o tirano não se deixaria enganar outra vez por lágrimas de crocodilo. Chorasse ou não, ele continuou ameaçador:

— Se continuar chorando, arranco seus olhos.

A torneira das lágrimas de Ning Xiaoxiao fechou na hora. O pranto escandaloso virou um soluço baixinho.

E assim ela ficou ainda mais digna de pena.

Lu Linyuan ergueu-lhe o queixo, obrigando-a a encará-lo. — Você vem aqui no meio da noite se aproveitar de mim e, depois de conseguir o que queria, ainda chora? Por quê?

— Majestade, entendeu tudo errado. Não vim me aproveitar de você. Só vim ver se você estava morto ou não...

— Como é? — A ira dele aumentou; os dedos apertaram cada vez mais o queixo dela. — O que disse?

Ning Xiaoxiao fez uma careta de dor. — Sonhei que Sua Majestade não estava bem de saúde. Por isso corri ao Palácio Chaoyang para verificar. E aí tropecei de novo em alguma coisa que estava jogada nos seus aposentos...

Fez um biquinho e resmungou: — Também não foi culpa minha... Por que deixam tanta coisa espalhada pelo chão? Toda vez piso em alguma coisa, tropeço e caio...

— Então, pelo visto, eu ainda deveria agradecer a você?

— Ah? Não, não precisa! Foi tudo culpa desta serva. Vou receber meu castigo agora mesmo.

Quando ele afrouxou um pouco a mão, Ning Xiaoxiao escapou. — Cinquenta varadas, não é? Já estou indo!

【Acha que sou idiota? Assim que sair, vou enfiar duas camadas grossas de algodão na calça e subornar o rapaz do Departamento de Punições para fingir que me dá umas pancadinhas!】

Lu Linyuan a observou com um sorriso carregado de ironia. — Se eu mandar o Departamento de Punições bater em você, tenho medo de sujar a vara.

Dito isso, abriu a mão e deu-lhe uma palmada inesperada no traseiro.

*Pá!* O estalo foi ainda mais alto que o de um belo tapa na cara.

Ning Xiaoxiao cobriu o traseiro, corando. — Majestade, você...!

— Se ousar atrapalhar meu sono de novo, eu corto você em pedaços! — Lu Linyuan deitou-se outra vez, virando-se de lado. — Fora daqui.

Ning Xiaoxiao sentiu que alguém acabara de se aproveitar dela, mas não tinha provas.

De costas para ela, o tirano passou a ponta avermelhada da língua pelos lábios.

Hum...

Apesar de tudo, os lábios dela são bem macios.

Bons de beijar.

Então ele ouviu os pensamentos indignados de Ning Xiaoxiao:

【Eu devia ter deixado você morrer!】

【Espere só! Quando encontrar o Prego Mágico de Aladim, vou fazer um desejo na mesma hora!】

【Vou fazer você engravidar de novo! E desta vez vai ter que dar à luz!】

— ...

Lu Linyuan sentiu um aperto no baixo-ventre.

De novo?!

Se você ousar me fazer engravidar mais uma vez, eu amarro um casco nas suas costas e chuto você no lago imperial para virar uma tartaruga!

Ning Xiaoxiao disse com a voz mais doce do mundo: — Durma bem, Majestade. Esta serva se retira.

【Droga... Onde será que aquele prego caiu?】

【Já procurei o corredor inteiro com cuidado e não achei nada.】

【Eu nem fiz desejo nenhum! Por que disseram que meu desejo foi realizado?】

【Não dá. Vou procurar de novo!】

Os passos de Ning Xiaoxiao se afastaram, e a voz de seus pensamentos foi desaparecendo.

Mas Lu Linyuan conseguiu captar o ponto principal.

Ela tinha algum tipo de tesouro chamado... Prego Mágico?

Aquela coisa realizava desejos. Apostava que, da última vez, fora com aquilo que ela o fizera engravidar!

Agora ela o perdera? No corredor?

Agora que eu sei que existe algo tão bom, você acha mesmo que vai encontrá-lo primeiro?

He-he. Passe para cá!

*

Naquele momento, Ning Xiaoxiao vasculhava o corredor com cuidado quando uma multidão de guardas surgiu dos dois lados, cercando-a.

Com lanternas nas mãos, eles bloquearam toda a passagem entre o Palácio Chaoyang e o Palácio Zhongcui.

O comandante perguntou: — De que palácio você é? O que faz aqui a esta hora?

— Sou uma criada do Palácio Zhongcui e sirvo à Atendente Gu. Minha senhora perdeu um brinco ao voltar dos aposentos imperiais esta noite e me mandou procurá-lo.

O comandante fez sinal para que saísse. — Ande, vá embora! Sua Majestade também perdeu uma coisa aqui e ordenou que isolássemos o corredor até encontrá-la. Se virmos o brinco de sua senhora, guardaremos e mandaremos ao Palácio Zhongcui.

Sem lhe dar oportunidade de contestar, mandou-a embora.

De volta ao palácio, Ning Xiaoxiao obrigou Xiao Qi a aparecer. 【Você me deve uma explicação! Perdi o Prego Mágico e nem fiz desejo algum. Por que ele disse que meu desejo foi realizado?】

Ainda meio adormecido, Xiao Qi respondeu confusamente: 【Qualquer pessoa pode usar o Prego Mágico para fazer um desejo. Talvez alguém o tenha encontrado... Depois de realizar um pedido, ele desaparece. Não adianta procurar; mesmo que o ache, não vai servir para nada.】

Furiosa por perder a oportunidade de fazer um desejo, Ning Xiaoxiao se jogou na cama e bateu no peito, inconsolável.

Enquanto isso, obedecendo à ordem imperial, os guardas recolheram todos os objetos em forma de prego espalhados pelo corredor entre Chaoyang e Zhongcui.

Diante de Lu Linyuan havia agora uma fileira de pregos: compridos, curtos, em espiral, de ferradura... Tinha de tudo.

Primeiro ele ordenou: — Prendam os criados responsáveis pela limpeza desse corredor, deem uma surra neles e mandem-nos trabalhar no Xinzheku. Como conseguem deixar tantos pregos espalhados se limpam o local todos os dias? E se um cavalo se assustar ou alguém se machucar?

Depois que os guardas saíram para cumprir a ordem, ele começou a apanhar os pregos um a um e examiná-los entre os dedos.

Será que essa coisa realmente realiza desejos?

Então eu quero que Ning Xiaoxiao engravide!

De oito bebês de uma só vez!

Ela vai inaugurar uma nova modalidade de maternidade por atacado!

Vou fazê-la parir até não aguentar mais!

Quando ela estiver farta de dar à luz, vai parar de inventar histórias sobre eu ter filhos!

Hum! ╭(╯^╰)╮

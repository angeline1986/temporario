# Validação — capítulo 100

## Fonte e recorte

- Fonte primária: `novel_capitulos_61_a_120(20261103-205857).docx` (chinês tradicional).
- Início: índice de parágrafo DOCX 2926; último índice do capítulo: 3020; próximo capítulo começa em 3021.
- Índices do DOCX são **base zero**, obtidos por `python-docx`.
- Título original: `第100章 好人一生生八胎`.

## Conferência estrutural

- Unidades não vazias do DOCX, incluindo título: **92**.
- Linhas de cotejo (sem cabeçalho): **92**.
- Índices únicos, em ordem crescente: **sim**.
- Unidades de origem sem tradução associada: **0**.
- Traduções vazias: **0**.
- Unidade externa ao recorte: **0**.

## Opções e ambiguidades editoriais

- O desejo de Lu Linyuan por **一胎八寶** refere-se especificamente a **oito bebês em uma única gestação**; não a oito gestações.
- **母豬流鼻祖** brinca com “matriarca/fundadora da corrente das porcas reprodutoras”; “maternidade por atacado” transmite o absurdo, com perda da associação literal à porca.
- A ameaça de transformar Ning em tartaruga (**王八**) conserva seu tom cômico; não introduz realização do desejo.
- **阿拉燈神釘** é mantido como “Prego Mágico de Aladim”. O capítulo não confirma que Lu Linyuan encontrou o objeto mágico; ele recolhe vários pregos comuns.
- A punição à equipe de limpeza (3011) faz parte da ação de Lu Linyuan e não deve ser omitida; **Xinzheku** é o destino referido.

## Limites da validação

O alinhamento 1:1, a conferência de índices e a tradução direta do chinês foram executados. As escolhas de sentido foram verificadas durante a redação, mas **não houve uma segunda auditoria linguística independente integral**, nem comparação com uma edição externa do original. Uma linha preenchida não comprova, por si só, ausência de erros semânticos internos.

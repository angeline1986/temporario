# Capítulo 101 — Boca de Buda, coração de serpente

Depois de outubro, a capital entrou no inverno, e o clima foi ficando cada vez mais frio.

Dizem que o verão dá sono e o inverno abre o apetite. Mas, nos últimos dias, Ning Xiaoxiao não tinha vontade alguma de comer e frequentemente sentia ânsias de vômito sem motivo.

Na época em que vivia no mundo moderno, ela sofria de problemas estomacais e passava por isso com frequência. Imaginou, portanto, que o corpo da personagem original fosse frágil, comeu algumas coisas para aliviar o estômago e não deu maior importância ao assunto.

Com a chegada do frio, os aposentos dos senhores e senhoras de cada palácio passaram a contar com braseiros.

Bondosa como era, Gu Sijin tirou dinheiro do próprio bolso para fornecer carvão de prata de excelente qualidade também aos quartos dos criados. Nem mesmo os servos da imperatriz recebiam carvão tão bom.

O inverno rigoroso se aproximava, mas todos se sentiam acolhidos; por isso, passaram a servi-la com ainda mais dedicação.

Nos outros palácios, a hierarquia entre senhores e servos era rígida, e raramente se ouviam risadas.

Já no palácio de Gu Sijin havia animação do amanhecer ao anoitecer. Senhora e criados conviviam com uma intimidade quase familiar.

As criadas da Consorte Duan, que morava ao lado, observavam com inveja. — Vejam como o pavilhão lateral leste da Atendente Gu é animado todos os dias. Ouvi dizer que ela paga do próprio bolso o carvão de prata dos criados. O nosso carvão comum solta tanta fumaça que quase sufoca a gente no meio da noite! Temos de abrir as janelas para ventilar. Mais vale nem acender.

— Embora ela seja apenas uma atendente, tem o favor do imperador e é chamada com frequência para servi-lo à noite. Nossa senhora tem posição de consorte, mas o Departamento de Assuntos Internos vive observando o humor do imperador. Até os tecidos que mandaram para nossa senhora passar o inverno são piores que os da Atendente Gu.

— Mas a Atendente Gu sabe se comportar. Mesmo quando recebe coisas melhores, não as usa. Respeita os limites do próprio posto, vive contente... Quem não teria inveja?

Xiu'er ouviu a conversa e imediatamente repreendeu as criadas, de cara fechada: — Que coragem a de vocês! Agora se atrevem a falar da senhora pelas costas?

— Não ousaríamos...

— Não ousariam? Ouvi tudo muito bem! Estão com inveja do carvão de prata que a Atendente Gu dá aos criados? Servas insignificantes como vocês já se acham boas demais para usar carvão comum? Muito bem! A partir de hoje, ficarão sem carvão. Se forem capazes, vão ao pavilhão leste pedir à Atendente Gu! Quero ver se ela lhes dá atenção!

— Senhora Xiu'er, acalme-se! Nunca mais faremos isso...

A discussão chamou a atenção da Consorte Duan. Ela se aproximou e perguntou em voz baixa: — O que aconteceu?

Xiu'er relatou os comentários das criadas. Mas, em vez de se irritar, a Consorte Duan sorriu e ajudou as duas a se levantarem. — Fui eu que deixei de pensar no conforto de vocês. Amanhã vou mandar trocar o carvão pelo de prata, para que possam dormir bem.

As criadas ficaram apavoradas. — Não ousamos pedir tanto, senhora. A senhora já nos trata muito bem. Fomos ingratas e dissemos bobagens...

A Consorte Duan sorriu. — Por que seriam bobagens? Fiquem tranquilas. Vocês me servem, e é natural que eu queira que vivam com conforto. Pronto, não tenham medo. Voltem ao trabalho.

Xiu'er acompanhou a consorte até os aposentos e lhe serviu uma xícara de chá quente. — Senhora, por que falou com tanta gentileza? Elas trabalham mal, mas têm uma língua afiada para fofocas!

A Consorte Duan afastou calmamente a espuma da superfície do chá com a tampa da xícara. — Arranje qualquer pretexto para mandá-las ao Departamento de Punições. Já que gostam tanto de carvão de prata, faça a ama Jingqi despejar carvão em brasa pela garganta delas. Se é algo de que gostam, naturalmente devo presenteá-las.

Xiu'er deu uma risadinha sem graça. — Sim, senhora. Entendi. Hoje não pensei direito. Se elas fossem pedir ajuda a Gu Sijin, pareceria que a senhora as maltrata.

— Guarde isto: nunca desperdice energia com gente sem importância. Se alguém a incomodar, basta matar e acabar com o problema.

A Consorte Duan pousou o chá e acariciou o enfeite dourado da proteção de unha do dedo mínimo, lançando um olhar distraído para o pavilhão leste. — A Imperatriz Viúva é devota do budismo e despreza o luxo. Além disso, o carvão de prata é destinado às consortes. Ao usá-lo para os criados, a Atendente Gu afronta a autoridade dela.

Xiu'er perguntou: — A senhora pretende contar isso à Imperatriz Viúva?

A Consorte Duan recostou-se preguiçosamente na cadeira. — Sou uma consorte; ela não passa de uma atendente. Seria indigno de minha posição discutir com ela. Mas... se bem me lembro, não entrou no palácio junto com ela uma tal Atendente Xiao?

— Sim. A Atendente Xiao nunca suportou Gu Sijin e já teve vários atritos com ela.

Ao perceber o leve sorriso no rosto da consorte, Xiu'er entendeu de imediato. — Vou providenciar para que a notícia chegue aos ouvidos da Atendente Xiao.

*

No dia seguinte, quando Ning Xiaoxiao acompanhou Gu Sijin para apresentar cumprimentos à imperatriz, a Imperatriz Viúva apareceu assim que todas as consortes se reuniram.

A imperatriz conduziu as demais no cumprimento respeitoso à Imperatriz Viúva e, em seguida, cedeu-lhe espontaneamente o assento de honra.

Era raro a Imperatriz Viúva comparecer às saudações matinais no palácio da imperatriz. Naquele dia, sua expressão estava péssima: era evidente que tinha algo a dizer.

Depois que todas se sentaram, ela declarou: — A primeira neve está próxima, e o fim do ano também. As despesas do harém aumentaram muito. No mês passado, ordenei à imperatriz que reduzisse esses gastos em vinte por cento, para economizarmos e abrirmos, com o dinheiro poupado, uma cozinha de distribuição de mingau aos pobres fora do palácio. Imperatriz, como estão os preparativos?

— Tudo foi feito de acordo com suas orientações, mãe. As despesas do harém foram reduzidas em vinte por cento e o restante está guardado no Departamento de Assuntos Internos. Depois do período solar da Grande Neve, no próximo mês, poderemos abrir a cozinha comunitária.

— Ah, é? Receio que algumas sejam econômicas enquanto outras esbanjam. Ouvi dizer que, em certo palácio, até o carvão dos servos foi trocado por carvão de prata. — A Imperatriz Viúva olhou de relance para Gu Sijin. — Atendente Gu, ouviu falar disso?

Gu Sijin, surpreendida por ser chamada, levantou-se depressa e fez uma reverência. — Em resposta à Imperatriz Viúva: de fato, troquei o carvão comum dos criados por carvão de prata. É que, com exceção de um jovem eunuco, todos os que me servem são mulheres. As mulheres sentem mais frio; o carvão comum produz muita fumaça e aquece menos. Queria que elas passassem o inverno aquecidas.

— Além disso, paguei pelo carvão com minhas economias pessoais. Não tirei nada do orçamento do harém.

Aquele seria um inverno severo. O excesso de fumaça do carvão comum podia provocar intoxicação fatal; por isso, muitos criados preferiam passar frio sob cobertores extras a acender os braseiros.

Mesmo assim, três ou quatro criados já haviam morrido congelados.

Mas, aos olhos de quem detinha o poder, a vida dos servos nunca valia grande coisa.

Preferiam usar o dinheiro economizado para socorrer pobres do lado de fora e exibir publicamente sua benevolência a enxergar o sofrimento que estava bem diante deles.

A Imperatriz Viúva nem quis ouvir a explicação de Gu Sijin. — Suas economias? De onde vêm? Do estipêndio mensal ou da ajuda da família, evidentemente. Seja qual for a origem, esse dinheiro foi concedido pela corte a você ou à sua família. Além disso, carvão de prata é artigo reservado às consortes. Distribuí-lo aos servos não é inverter a hierarquia entre superiores e inferiores?

Gu Sijin ficou sem resposta e não soube como reagir.

A Consorte Li comentou, com sarcasmo: — A Imperatriz Viúva está falando com você. Mesmo tendo cometido uma falta, ainda ousa responder de pé? Ajoelhe-se!

Ning Xiaoxiao sentiu uma tremenda dor de cabeça ao assistir à cena.

Mal tinham passado alguns dias de paz. Já estavam criando outra confusão?

E, sempre que se irritava, sentia vontade de vomitar.

Mas, com a Imperatriz Viúva presente, se ousasse fazer um "urgh" ali, não acabaria esfolada viva?

Inspirou profundamente e conseguiu engolir à força a ânsia de vômito.

# Validação — capítulo 99

## Fonte e recorte

- Fonte primária: `novel_capitulos_61_a_120(20261103-205857).docx` (chinês tradicional).
- Início: índice de parágrafo DOCX 2853; último índice do capítulo: 2925; próximo capítulo começa em 2926.
- Índices do DOCX são **base zero**, obtidos por `python-docx`.
- Título original: `第99章 你讓人圍觀她輕薄朕？`.

## Conferência estrutural

- Unidades não vazias do DOCX, incluindo título: **70**.
- Linhas de cotejo (sem cabeçalho): **70**.
- Índices únicos, em ordem crescente: **sim**.
- Unidades de origem sem tradução associada: **0**.
- Traduções vazias: **0**.
- Unidade externa ao recorte: **0**.

## Opções e ambiguidades editoriais

- O título **輕薄朕** designa o contato amoroso impróprio dirigido ao próprio imperador; “se aproveitar de mim” preserva o constrangimento cômico.
- **阿拉燈神釘** é o **Prego Mágico de Aladim**, paródia deliberada da lâmpada de Aladim; foi mantido como prego, não lâmpada nem percevejo.
- **三妃娘娘** é um trocadilho de Ning com o nome Sanfu, insinuando posição de consorte; “Consorte Sanfu” é adaptação de sentido, não equivalência fonética literal.
- O original no parágrafo DOCX 2889 traz **陸臨淵要朕被自己給咒死了**, frase com provável erro de pronome/estrutura. A solução “Se Lu Linyuan morrer por causa da minha maldição” é contextual e não uma transcrição literal; verificar contra outra edição se disponível.
- **biaji** (2911) representa som onomatopaico, adaptado como *plaft*.
- A menção ao sonho em que Lu Linyuan tenta fazer Ning engravidar é **sonho**, não acontecimento efetivo.

## Limites da validação

O alinhamento 1:1, a conferência de índices e a tradução direta do chinês foram executados. As escolhas de sentido foram verificadas durante a redação, mas **não houve uma segunda auditoria linguística independente integral**, nem comparação com uma edição externa do original. Uma linha preenchida não comprova, por si só, ausência de erros semânticos internos.

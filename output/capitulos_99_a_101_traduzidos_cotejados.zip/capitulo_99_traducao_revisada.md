# Capítulo 99 — Você chamou todo mundo para assistir a ela se aproveitar de mim?

Ning Xiaoxiao passou um minuto inteiro tendo ânsias de vômito antes que o mal-estar começasse a diminuir.

Como todo mundo sabe, exercícios intensos podem provocar vômitos.

Na faculdade, certa vez, depois de correr os 1.500 metros, ela foi ao banheiro meia hora mais tarde e vomitou até não poder mais.

Por isso tinha absoluta certeza de que aquela náusea só podia ser consequência dos movimentos exagerados da ginástica que acabara de fazer.

Quanto mais pensava, mais irritada ficava, até não conseguir segurar o comentário:

— Esse imperador desgraçado só sabe atormentar os outros quando está sem nada para fazer!

— Morre tanta gente todo dia! Por que ele não morre também?!

Mas, antes mesmo que terminasse a frase, a voz de Xiao Qi surgiu de repente:

【Bip, bip, bip! O desejo do anfitrião foi realizado! O Prego Mágico de Aladim perdeu seu poder!】

【O quê?! Você disse o quê?! Que desejo eu fiz?!】

【Boocejo...】 Xiao Qi bocejou e respondeu com preguiça: 【Como é que eu vou saber o que você desejou? Eu estava dormindo quando o sistema me avisou que seu pedido tinha sido realizado. Só vim cumprir o protocolo. Pronto, falei. Vou voltar a dormir. Tchauzinho, anfitriã!】

Ning Xiaoxiao ficou paralisada por dois segundos, questionando todas as suas escolhas de vida.

Não pode ser... Não pode ser!

Eu disse, da boca para fora, que aquele maldito imperador devia morrer logo... Será que esse prego idiota interpretou aquilo como meu desejo?!

Não! Ele não pode morrer!

Se ele morrer, a trama inteira vai desmoronar!

Em pânico, ela abandonou a lanterna onde estava e saiu correndo em direção ao Palácio Chaoyang.

*

Já passava da meia-noite, e os portões do Palácio Chaoyang estavam trancados.

O guarda de serviço conhecia Ning Xiaoxiao de vista. Ao vê-la chegar esbaforida, perguntou: — Senhorita Xiaoxiao, por que tanta pressa? Aconteceu alguma coisa com sua senhora?

Ela negou com a cabeça e, depois de recuperar o fôlego, respondeu: — Eu... preciso ver o imperador.

— Bem... — O guarda hesitou. — Sua Majestade já se recolheu. Perturbar o descanso imperial é crime punível com a morte. Se não for nada muito grave, volte amanhã, depois da audiência matinal.

— E por que eu viria até aqui no meio da noite se não fosse algo grave...?

— Quem está fazendo essa algazarra lá fora? — A voz de Sanfu veio de dentro dos portões. Ning Xiaoxiao gritou: — Eunuco Sanfu, sou eu!

Assim que reconheceu a voz dela, Sanfu mandou abrir os portões sem fazer perguntas.

— Minha nossa! O que você está aprontando a esta hora, em vez de dormir?

— Não dá tempo de explicar! Primeiro preciso ver como está Sua Majestade.

Ela disparou para dentro, deixando Sanfu apavorado.

Ele conhecia muito bem o péssimo humor do imperador ao acordar. Se Ning Xiaoxiao o despertasse, não sabia se ela seria castigada, mas tinha certeza de que ele próprio levaria uma bronca daquelas.

Agarrou com força o pulso dela. — Sua Majestade está dormindo. Se eu deixar você entrar e ele se irritar, quem vai pagar com o próprio traseiro sou eu!

Ning Xiaoxiao olhou para o traseiro de Sanfu, depois para a porta dos aposentos e imaginou o pior. — Ah... Mas isso não seria meio inadequado? Então vou ter que chamá-lo de Consorte Sanfu quando estivermos a sós?

— ... — Sanfu agitou o espanador e cuspiu duas vezes, para espantar o absurdo. — De onde você tirou isso?! Estou falando de levar umas boas varadas!

Agora você está com medo de umas varadas?

Se Lu Linyuan morrer por causa da minha maldição, você nem vai precisar apanhar. Vão mandar você direto para o túmulo com ele!

Sem conseguir explicar a verdade, inventou uma história: — Antes de ir embora, vi que Sua Majestade estava com o peito apertado, ofegante e pálido. Depois sonhei que ele estava muito mal. Vim correndo conferir.

Sanfu sabia que ela estava tentando enrolá-lo. Mas, pensando melhor, se a impedisse de entrar e ela reclamasse com Lu Linyuan no dia seguinte, quem acabaria se dando mal seria ele mesmo.

Todo mundo trabalhava como criado, mas por que a vida do chefe dos eunucos era tão miserável? Ou levava bofetada ou apanhava de vara. Dava vontade de chorar.

Por fim, depois de muita insistência, ele cedeu. — Está bem. Eu vou com você. Só daremos uma olhada e sairemos. E faça silêncio! Não podemos acordar Sua Majestade.

Os dois entraram na ponta dos pés, como ladrões, tateando no escuro até a cama imperial.

O luar prateava o rosto incomparavelmente belo de Lu Linyuan. Ele respirava regularmente, com a aparência de sempre, sem qualquer sinal de doença.

Naquele momento, ele ainda sonhava que obrigava Ning Xiaoxiao a engravidar. Quando os dois chegaram perto da cama, ouviram-no murmurar:

— Ning Xiaoxiao... Xiaoxiao...

Ela congelou.

Ele está bem mesmo?

Por que está chamando meu nome enquanto dorme?

Sanfu cobriu a boca para esconder uma risadinha. — Está vendo? Até dormindo Sua Majestade chama por você. Que doença que nada! Se ele tem algum problema, deve ser a falta de uma bela mulher nos braços, que o impede de dormir em paz.

A boca de Sanfu sempre fora assim. Ning Xiaoxiao nem se deu ao trabalho de responder. Depois de confirmar que Lu Linyuan estava bem, preparou-se para sair com ele.

Mas, quando já estavam quase chegando à porta, ouviram o imperador berrar:

— Insolente! Como ousa armar contra mim?!

Os dois se entreolharam, alarmados.

— Será um assassino? — Sanfu gritou para fora: — Guardas! Um assassino! Protejam Sua Majestade!

Mal sabia ele que Lu Linyuan também dirigia aquelas palavras à Ning Xiaoxiao de seu sonho.

Ning Xiaoxiao foi a primeira a correr de volta.

Entrou nos aposentos tão depressa que não prestou atenção onde pisava.

As botas imperiais que o Prego Mágico havia derrubado continuavam no chão. Ela pisou em uma delas, perdeu o equilíbrio, soltou um "ai, meu Deus!" e voou direto para a cama do tirano.

*Plaft!* Os dois acabaram num contato íntimo e inesperado.

Os lábios macios dela pousaram exatamente sobre os dele — e o beijo acordou Lu Linyuan!

Antes que qualquer um dos dois pudesse reagir, um batalhão de guardas entrou no quarto com lanternas, liderado por Sanfu.

Ao verem Ning Xiaoxiao estendida sobre Lu Linyuan, como se estivessem trocando carícias apaixonadas, os guardas arregalaram os olhos, com medo de perder um segundo daquele espetáculo.

Sanfu também ficou petrificado.

Assassino nenhum apareceu. Em compensação, ele se deparou com aquela cena indecente.

Essa Ning Xiaoxiao também não tinha um pingo de recato! Uma moça tão jovem... Não conseguia se controlar nem por alguns instantes?

Lu Linyuan empurrou Ning Xiaoxiao de uma vez e sentou-se bruscamente na cama.

Morrendo de vergonha, a ponto de querer cavar um buraco com os dedos dos pés, ela gaguejou: — M-Majestade, não foi de propósito...

Enquanto se explicava, ainda passou a língua pelos lábios, como se estivesse saboreando a lembrança.

Lu Linyuan lançou-lhe um olhar feroz. Quando percebeu a multidão ao redor da cama, liderada por Sanfu, ficou ainda mais furioso e apontou para o eunuco:

— Insolente! Como ousa, no meio da noite, trazê-la às escondidas para meus aposentos... e ainda chamar tanta gente para assistir...?

Seu rosto ficou vermelho como fogo, e a voz foi diminuindo conforme terminava a frase:

— Assistir a ela... se aproveitar de mim!

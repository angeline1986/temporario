# Validação — capítulo 101

## Fonte e recorte

- Fonte primária: `novel_capitulos_61_a_120(20261103-205857).docx` (chinês tradicional).
- Início: índice de parágrafo DOCX 3021; último índice do capítulo: 3073; próximo capítulo começa em 3074.
- Índices do DOCX são **base zero**, obtidos por `python-docx`.
- Título original: `第101章 佛口蛇心`.

## Conferência estrutural

- Unidades não vazias do DOCX, incluindo título: **50**.
- Linhas de cotejo (sem cabeçalho): **50**.
- Índices únicos, em ordem crescente: **sim**.
- Unidades de origem sem tradução associada: **0**.
- Traduções vazias: **0**.
- Unidade externa ao recorte: **0**.

## Opções e ambiguidades editoriais

- **佛口蛇心** (“boca de Buda, coração de serpente”) contrasta a gentileza aparente da Consorte Duan com a violência que ordena em particular.
- **銀炭**, aqui “carvão de prata”, designa carvão de qualidade superior; não é carvão feito de prata. A distinção do carvão comum é essencial à intriga.
- **端妃** é Consorte Duan, **麗妃** é Consorte Li, **蕭常在** é Atendente Xiao e **顧常在** é Atendente Gu. Não se deve trocar os títulos.
- **大雪節氣** é o período solar da Grande Neve, não uma nevasca específica.
- O vômito de Ning permanece **sintoma sem causa confirmada neste capítulo**. Não antecipar diagnóstico.
- A violência pretendida pela Consorte Duan contra as servas foi preservada sem suavização.

## Limites da validação

O alinhamento 1:1, a conferência de índices e a tradução direta do chinês foram executados. As escolhas de sentido foram verificadas durante a redação, mas **não houve uma segunda auditoria linguística independente integral**, nem comparação com uma edição externa do original. Uma linha preenchida não comprova, por si só, ausência de erros semânticos internos.

# Capítulo 79 — Porque Xiaoxiao é uma mulher extraordinária

O Cavalo de Lama disparou de volta ao Palácio Zhongcui, onde a essa altura reinava o caos.

Depois de regressar, Gu Sijin não encontrara Ning Xiaoxiao. Já passava da meia-noite, e a criada ainda não voltara.

Lembrando-se do perigo que haviam enfrentado à beira do lago imperial, tarde da noite, Gu Sijin ficou angustiada e mandou todos os criados procurá-la.

Cailian viu como sua senhora estava fora de si e pensou que, se fosse ela a desaparecer, Gu Sijin provavelmente não se preocuparia tanto. Sua voz se encheu de ressentimento:

— Por que a senhorita está tão aflita? Ela já é bem grandinha! Como poderia se perder? Aposto que foi se divertir em algum canto com gente de má índole!

— Cale a boca! — repreendeu Gu Sijin. — Pedi que ajudasse a procurá-la. Se não quer ir, tudo bem, mas não precisa fazer comentários maldosos!

Cailian se queixou: — Está tudo escuro! E se eu sair para procurá-la e também desaparecer? A senhorita só se preocupa com ela? Não se importa nem um pouco comigo?

Gu Sijin não tinha disposição para discutir e simplesmente a ignorou.

Ning Xiaoxiao sempre se dera bem com Qiqi, Qiaqia, Bengbeng e Lala. Agora que estava desaparecida, todos em Zhongcui, com exceção de Cailian, estavam preocupados.

Foram e voltaram muitas vezes, vasculhando todos os lugares a que tinham acesso. Ainda assim, nenhum sinal de Ning Xiaoxiao.

Qiqi estava quase chorando: — Minha senhora, continuar procurando assim não resolve. Há toque de recolher no palácio durante a noite, e muitas áreas são proibidas para nós.

Qiaqia acrescentou: — Xiaoxiao sempre avisa aonde vai. Jamais desapareceria por tanto tempo sem dar notícias! Tenho medo de que alguma coisa tenha acontecido com ela, minha senhora...

Bengbeng se culpou: — A culpa é minha! Ela disse que sairia no começo da noite e eu nem perguntei para onde. Se tivesse prestado mais atenção, não...

Até Lala, que quase nunca falava, deu sua opinião: — Minha senhora, por que não pede ajuda ao imperador? Se ele permitir, podemos enviar guardas para procurá-la. Assim vamos encontrá-la mais depressa!

Ao ver todos tão preocupados com Ning Xiaoxiao, Cailian ficou ainda mais irritada e soltou um resmungo:

— Vocês perderam o juízo? Uma criada desapareceu, e daí? Vão fazer nossa senhora procurar o imperador a esta hora por causa disso? De tanto alimentarem aquele Cavalo de Lama com Ning Xiaoxiao, será que ele deu um coice na cabeça de vocês?

Cailian servia à família Gu desde o nascimento; as outras criadas não ousavam responder às suas ofensas.

Gu Sijin, porém, não ia tolerá-las. — Se não tem nada decente para dizer, fique calada! Qiqi, venha comigo ao Palácio Chaoyang pedir uma audiência ao imperador!

Ela partiu com Qiqi sem olhar para trás, apesar dos insistentes chamados de Cailian.

Ao vê-la sair tão decidida e deixá-la para trás, Cailian cerrou os punhos e rangeu os dentes de ódio.

*

Ao chegar diante do Palácio Chaoyang, Gu Sijin logo chamou a atenção de Sanfu por sua pressa.

Ele correu a recebê-la, fez uma reverência e perguntou: — Atendente Gu, o que aconteceu? Por que tanta urgência?

Gu Sijin mal conseguia recuperar o fôlego: — Avise... avise Sua Majestade de que preciso vê-lo urgentemente...

— Calma, calma! — disse Sanfu. — Conte primeiro a este servo o que aconteceu, para que eu possa anunciar sua visita.

— Xiaoxiao... Xiaoxiao saiu no começo da noite e ainda não voltou. Mandei procurar por todos os lugares permitidos, mas ninguém a encontrou. Por favor, anuncie-me depressa ao imperador! Xiaoxiao pode ser apenas uma criada, mas a vida dela também tem valor!

Sanfu ficou paralisado por um instante, temendo deixar transparecer alguma coisa. Logo recuperou a expressão habitual e concordou.

Entrou nos aposentos e contou tudo a Lu Linyuan. Depois de refletir por um momento, o imperador disse: — Mande-a esperar no salão principal.

Gu Sijin andava de um lado para o outro, aflita. Passado aproximadamente o tempo de queima de um bastão de incenso, Lu Linyuan finalmente apareceu.

Assim que o viu, ela fez a reverência apropriada e ajoelhou-se, angustiada: — Peço perdão por perturbar o descanso de Vossa Majestade a esta hora. Mas é uma emergência! A chefe das criadas de meu palácio, Ning Xiaoxiao, desapareceu. Já se passaram quase quatro ou cinco *shichen*, e tenho medo de que algo lhe tenha acontecido. Imploro que envie homens para procurá-la!

Aquilo era curioso.

Ning Xiaoxiao só fora designada para servir Gu Sijin depois que a Atendente entrara no palácio. Não fazia sequer três meses. Como haviam desenvolvido um vínculo tão profundo?

Curioso, Lu Linyuan perguntou: — Não passa de uma criada. Por que se importa tanto com ela?

— Porque Xiaoxiao foi a primeira pessoa a me oferecer carinho desde que entrei no palácio. Ela trata os outros com sinceridade, e todos em Zhongcui gostam dela. Por isso... ela jamais sairia sem dar notícias e desapareceria por tanto tempo. Sei que não é apropriado pedir que Vossa Majestade envie pessoas para procurar uma criada no meio da noite. Mas Xiaoxiao é, de verdade, uma pessoa muito boa, e tenho muito medo de que tenha sofrido algum acidente...

Enquanto falava, os olhos de Gu Sijin se enchiam de lágrimas.

Foi também a primeira vez que Lu Linyuan a observou com atenção e ouviu tudo o que ela tinha a dizer, sem interrompê-la.

Mas, naquele momento, a bondade de Gu Sijin não o comoveu particularmente.

Ele apenas ficou ainda mais intrigado: como aquela mulher que lhe dava dor de cabeça todos os dias conseguia ser tão querida por todos longe dele?

Isso só podia significar que todas as insolências que ela cometia diante dele eram deliberadas!

Naquela noite, Lu Linyuan não dispensou Gu Sijin com desculpas.

Ordenou que os guardas procurassem pelo palácio inteiro e mandou Gu Sijin descansar, assegurando-lhe que Ning Xiaoxiao ficaria bem.

Não podia contar a ninguém que Ning Xiaoxiao dormia profundamente em seus próprios aposentos.

No palácio, boatos eram lâminas que matavam sem derramar sangue. Como homem no centro das disputas entre as consortes, uma única frase descuidada poderia condená-la à morte.

*

Ning Xiaoxiao acordou na madrugada do dia seguinte, durante a quarta vigília.

Não sentia nenhum desconforto. Achava apenas que dormira maravilhosamente bem e recuperara todas as energias.

Bocejou e se espreguiçou sem qualquer cerimônia.

Só quando abriu os olhos percebeu que o cenário à sua volta era ao mesmo tempo familiar e estranho:

【Mas que diabos? Onde é que eu dormi? Não são os aposentos de Lu Linyuan?】

【Eu... estou deitada na cama dele?!】

As lembranças dos momentos anteriores ao desmaio voltaram de uma vez. Ao mesmo tempo, ela percebeu Lu Linyuan bem ao seu lado.

Ele estava sentado numa cadeirinha, com a cabeça apoiada na madeira de pereira entalhada da cama, dormitando.

O rosto estava voltado de perfil para ela. Os olhos profundos, de olhar habitualmente penetrante, estavam fechados, e as sobrancelhas retas relaxadas. Sem a agressividade costumeira, o nariz altivo com uma discreta curvatura e a linha bem desenhada do maxilar formavam um perfil impecável.

Sua respiração era tão leve que qualquer ruído parecia capaz de acordá-lo.

Ning Xiaoxiao ficou observando-o por um bom tempo, enquanto algumas lembranças vagas surgiam em sua mente:

【Foi ele quem me carregou até a cama? E ainda limpou todo aquele bolo do meu rosto?】

【Então... ele passou a noite inteira aqui, cuidando de mim?】

Seu coração acelerou involuntariamente. Quando percebeu as pálpebras dele se moverem, anunciando que estava prestes a acordar, fechou os olhos depressa e fingiu continuar dormindo, para evitar o constrangimento.

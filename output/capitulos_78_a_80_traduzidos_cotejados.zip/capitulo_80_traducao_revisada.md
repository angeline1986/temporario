# Capítulo 80 — Vou bater em você até fazê-la cacarejar!

Ao ouvir o farfalhar das roupas masculinas ao seu lado, Ning Xiaoxiao imaginou que ele já tivesse acordado.

A primeira coisa que Lu Linyuan fez ao despertar foi estender a mão para verificar se Ning Xiaoxiao ainda respirava. Precisava ter certeza de que aquela louca continuava viva.

Por sorte, havia respiração.

Ning Xiaoxiao tentou fazer sua expressão adormecida parecer tão natural quanto possível. Até o ritmo da respiração fora cuidadosamente calculado.

Pensou:

【Já deve estar perto da quarta vigília. Na quinta, ele precisa ir à audiência matinal. Daqui a pouco deve sair para se lavar e tomar café.】

【Quando ele for à corte, eu escapo de fininho!】

*Grrrr...*

Seu estômago traiçoeiro roncou.

E não era para menos. No dia anterior, passara o dia inteiro preparando o bolo para Lu Linyuan e nem tivera tempo de comer.

Planejara beliscar um pouco do bolo de chocolate enquanto comemoravam o aniversário à noite. Acabou sem colocar nada na boca e ainda ganhou uma cobertura de bolo no rosto.

Depois, a missão fracassara, e ela desmaiara durante a noite. Fazendo as contas, estava quase um dia inteiro sem comer. Como não estaria faminta?

【Que fome... Queria tanto uma pizza! Um hambúrguer também serviria...】

【E se pudesse tomar uma garrafa de refrigerante geladinho depois, melhor ainda!】

【Ai... que pena, acabaram os cabelos... Melhor voltar e fazer manha para a pequena Gu, ver se consigo alguma comida gostosa. Não aguento mais aqueles pães grosseiros de milho...】

【Buááá! Socorro! Por que minha vida é tão sofrida?】

Lu Linyuan ficou sentado em silêncio, observando Ning Xiaoxiao, que supostamente dormia profundamente, enquanto analisava o drama que ela encenava dentro da cabeça:

Pizza? Que diabos seria isso? Alguma espécie nova de peixe marinho? [Nota: o imperador confunde a pronúncia da palavra moderna chinesa para “pizza”.]

Hambúrguer? Que tipo de tesouro seria esse? Para mim, a única coisa meio tapada aqui é você! [Nota: ele interpreta equivocadamente os sons do empréstimo linguístico moderno.]

Três batidas soaram na porta. Lu Linyuan disse: — Entre.

Sanfu entrou respeitosamente carregando as vestes de audiência. Ao observar o cansaço incomum no rosto do imperador, percebeu também a sombra de barba recém-nascida no queixo, que o fazia parecer ainda mais viril do que de costume.

Raramente via seu senhor daquele jeito, e sentiu pena. — Majestade, o senhor ficou a noite inteira ao lado de Ning Xiaoxiao?

Lu Linyuan: — !!!

Que absurdo!

Se Ning Xiaoxiao descobrisse que ele havia passado a noite velando seu sono, quem a aguentaria?

Ela já abusava demais de sua boa vontade. Se soubesse daquilo, pisaria na cabeça dele e subiria aos céus, apoiando um pé no outro!

— Eu, velando o sono dela? Ora... — Ele soltou uma risada curta, como se Sanfu tivesse contado a piada mais ridícula do mundo. — Apenas acordei cedo e aproveitei para verificar como ela estava.

Sanfu ficou perplexo. Olhou para Ning Xiaoxiao na cama, depois para Lu Linyuan, e perguntou num tom constrangido: — Mas há apenas uma cama nestes aposentos... Isso quer dizer que Sua Majestade dormiu com ela ontem à noite?

Lu Linyuan: — ???

Será que você fica mudo se passar um instante de boca fechada?!

Ning Xiaoxiao: 【Ah, então é por isso! Por isso acordei com o corpo todo dolorido! Será que esse imperador cachorro fez alguma coisa comigo ontem à noite? Humm... Mas não faz sentido. Se aquele 21 tivesse me espetado, eu teria acordado de dor e dado uma bofetada nele enquanto fazia uma dança frenética! Então para que ele dormiria comigo na mesma cama? Estava procurando amor de mãe?】

A enxurrada de pensamentos fez Lu Linyuan ficar vermelho até as orelhas.

De vergonha — e de raiva!

O olhar dele tornou-se cortante como a lâmina de uma faca ao atingir Sanfu. O eunuco compreendeu de imediato e deu dois tapinhas na própria boca, mudando de assunto: — Ning Xiaoxiao já dormiu seis ou sete *shichen*. Ainda não acordou?

Lu Linyuan baixou os olhos para ela e decidiu se vingar: — Não acordou a noite inteira. Deve ter virado um caso perdido.

Fez uma pausa e soltou um riso frio: — Levem-na para fora e enterrem-na.

Não havia o menor traço de brincadeira em sua voz. Sanfu ficou paralisado, sem saber o que fazer, até ouvir outra reprimenda: — Por que ainda está aí parado?

— Hã? Majestade... É para enterrá-la mesmo?

— Ou enterra ela ou enterro você. Escolha quem vai para debaixo da terra!

Sanfu respondeu imediatamente: — Vou escolher agora mesmo um lugar de excelente *feng shui* para ela!

Ning Xiaoxiao: 【Tal senhor, tal servo! Dois cachorros da mesma laia!】

Se continuasse fingindo, daqui a pouco talvez pudesse dizer adeus a este mundo para sempre.

Por isso, mostrou todo o seu talento de atriz: murmurou algumas palavras indistintas, estendeu devagar os braços num espreguiçamento, soltou um longo bocejo preguiçoso e abriu as pálpebras aos poucos.

Sanfu: — Ah, Majestade, veja só! Acordou!

Ning Xiaoxiao olhou para os dois e se sentou na cama, fingindo tranquilidade e gaguejando: — M-Majestade? O que faz nos aposentos desta criada?

Lu Linyuan: — Abra bem esses olhos e veja onde está, sua idiota!

Ning Xiaoxiao olhou ao redor e, como uma codorna assustada, despencou da cama. Num só movimento, ajoelhou-se diante de Lu Linyuan e ainda bateu a testa no chão:

— M-Majestade, não se irrite! Esta criada... esta criada não faz ideia de como foi parar na cama imperial...

— Lembro que ontem parecia que eu estava... Ah, sim! Estava comemorando o aniversário de Vossa Majestade, e Vossa Majestade me acertou com um bolo e me fez desmaiar...

Sanfu, que acompanhava a cena como quem assistia a um espetáculo, não conseguiu evitar um sorriso. Estava quase rindo alto.

Lu Linyuan deu-lhe outro tapa com as costas da mão. — Você não tem mais nada a fazer aqui. Suma!

— Pois não~ Majestade, não se esqueça de trocar de roupa~ Este servo já está indo!

Depois que ele saiu, Ning Xiaoxiao, sozinha com Lu Linyuan, sentiu uma onda de frio percorrer o corpo.

Precisava fugir! Se não saísse logo, o próximo tapa do imperador certamente seria para ela!

— Majestade vai comparecer à audiência matinal, então esta criada também vai se retirar!

Já ia disparar porta afora quando Lu Linyuan agarrou-lhe a faixa da cintura e a puxou de volta sem esforço.

— Quem lhe deu permissão para sair?

— Mas, se eu ficar aqui, não tenho nada para fazer...

— Se não tem o que fazer, arranjo uma tarefa. — Ele atirou as vestes de audiência para Ning Xiaoxiao. — Vista-me!

Ning Xiaoxiao xingou mentalmente: 【Você tem algum problema? Um homem desse tamanho precisa de ajuda para vestir a roupa?!】

Por fora, sorria toda prestativa: — Claro, Majestade~ Adoro ajudar as pessoas a se vestirem~

As vestes imperiais de audiência exigiam procedimentos rigorosos: havia uma maneira correta de abotoar cada peça e de amarrar a faixa amarela.

Ning Xiaoxiao só sabia enfiar os braços dele nas mangas e as pernas nas calças. Quanto ao resto, não fazia a menor ideia.

Começou a examinar o traje sobre o corpo dele, apalpando aqui e puxando ali, até deixar o “21” de Lu Linyuan perigosamente animado.

Ele se irritou e arrancou de suas mãos a faixa amarela com a qual ela brincava. — Que mãos desajeitadas! Se eu jogasse um punhado de arroz em cima de mim, até uma galinha conseguiria me vestir mais depressa!

Ning Xiaoxiao assentiu com um sorriso sem graça: — Sim, sim, Vossa Majestade tem toda a razão. Esta criada não chega nem aos pés de uma galinha.

Assim que ele se distraiu, revirou os olhos às suas costas:

【Se as galinhas são tão boas, por que não vai dormir num galinheiro? Melhor ainda: case com duas galinhas! Uma o ajuda a se vestir, e a outra canta de manhã para acordá-lo. Assim você vira o imperador do galinheiro! Um casal perfeito!】

Lu Linyuan: ... Agora eu é que estou com vontade de bater em você até fazê-la cacarejar!

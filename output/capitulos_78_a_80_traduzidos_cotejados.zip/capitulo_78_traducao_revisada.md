# Capítulo 78 — Ela adoeceu de tanto se esforçar por minha causa?

Enquanto esperavam o médico imperial, Lu Linyuan usou um lenço umedecido para limpar cuidadosamente os restos de bolo do rosto de Ning Xiaoxiao.

Ao observar a jovem imóvel sobre a cama, uma pontada de culpa surgiu de repente em seu peito.

Ainda assim, ele não conseguiu dizer nada de bom:

— O presente de aniversário que você me deu não era um tijolo! Era uma coisa macia como um pãozinho de farinha branca. Como isso pôde fazê-la desmaiar de uma vez?

— Tal senhora, tal criada. Sua senhora é fraca, e você não fica muito atrás.

— Quando melhorar, vai fazer ginástica com ela sempre que vier ao Palácio Chaoyang.

Fez uma pausa. Como ela continuava sem reagir, beliscou-lhe a bochecha clara e macia:

— Ei, pare de dormir! Não disse que ia comemorar meu aniversário?

— Acorde! — Ele corou e murmurou baixinho:

— No pior dos casos... eu deixo você esfregar bolo na minha cara...

Ning Xiaoxiao estava profundamente inconsciente. Nem que Lu Linyuan aceitasse levar bolo na cara — ou raspasse a cabeça ali mesmo e lhe entregasse todos os cabelos — ela acordaria.

Sanfu entrou acompanhado do médico-chefe adjunto Song. Ao ver Ning Xiaoxiao deitada na cama imperial, os olhos do médico se arregalaram visivelmente.

Sanfu, por outro lado, parecia achar aquilo perfeitamente normal. Até apressou o médico para que parasse de olhar e examinasse logo o pulso dela.

Enquanto Song examinava Ning Xiaoxiao, Sanfu cochichou para Lu Linyuan: — Majestade, também precisa pegar mais leve. Toda vez que o senhor e Xiaoxiao fazem... aquilo, tenho de chamar um médico. Ou é o senhor que se machuca, ou é ela que desmaia... Este servo...

*Pá!*

Lu Linyuan lhe deu mais um sonoro tapa com as costas da mão.

— Que bobagens está dizendo?

Antes que Sanfu pudesse se explicar, o médico Song concluiu o exame:

— Majestade, o pulso desta criada está normal. Ao que parece, ficou exausta e adormeceu.

Lu Linyuan confiava na competência do médico Song.

Mas como alguém perfeitamente saudável poderia cair no sono assim, sem mais nem menos?

Exausta?

Em Zhongcui, ela não fazia muito além de varrer o chão e limpar as mesas. E, como criada responsável pelo serviço, podia delegar as tarefas menores aos demais. De onde viria tamanho cansaço?

Lu Linyuan ordenou que Song não comentasse o ocorrido e, depois de dispensá-lo, instruiu Sanfu:

— Mande Xiaoyin investigar discretamente em Zhongcui o que ela fez hoje para acabar nesse estado.

Sanfu sempre agia depressa. Antes que um bastão de incenso terminasse de queimar, já trouxera notícias:

— Majestade, Xiaoyin perguntou aos criados da ala leste de Zhongcui. Disseram que Xiaoxiao passou a tarde inteira enfurnada na cozinha pequena, trabalhando sem parar por quase três *shichen*.

— Ela disse aos outros que estava fazendo um tal de... ovo alguma coisa? — Sanfu apoiou o queixo na mão, pensou um instante e exclamou: — Ah, isso! Bolo!

Lu Linyuan ficou em silêncio.

Fazendo bolo?

Aquela massa que parecia... bem, aquilo, embora tivesse um sabor tão peculiar?

Preparar aquela coisa dava tanto trabalho assim?

Ao pensar nisso, Lu Linyuan finalmente compreendeu.

Ela havia se esgotado de tanto trabalhar para preparar uma surpresa para ele.

Entre todas as consortes do harém e todos os oficiais da corte, quem não procurava exibir seus tesouros no aniversário do imperador? Quanto mais caro o presente, mais pareciam querer provar sua dedicação.

Mas, no fim, a única pessoa disposta a dedicar-lhe seu próprio tempo fora Ning Xiaoxiao.

Para um homem como Lu Linyuan, que tinha o mundo nas mãos, objetos valiosos nunca foram o que importava. Por mais precioso que fosse algo, ele podia obtê-lo facilmente.

Talvez o que realmente valorizasse fosse um gesto puro e sincero.

Embora Song tivesse garantido que Ning Xiaoxiao estava bem, Lu Linyuan continuava preocupado.

Afinal, aquela peste era sua preciosa fonte de previsões. Se lhe acontecesse alguma coisa, quem o ajudaria a enxergar o futuro?

Por isso, naquela noite, cedeu a ela sua cama dourada e os travesseiros macios. Ele próprio ficou sentado numa poltrona acolchoada, lendo um tratado de estratégia militar.

A noite avançou em silêncio absoluto. Desde a chegada do outono, o canto das cigarras diminuíra; de vez em quando, só se ouvia o sussurro das folhas agitadas pela brisa.

Foi nesse silêncio que Lu Linyuan ouviu Ning Xiaoxiao murmurar alguma coisa.

Ele deixou o tratado de lado e foi até a cama, olhando-a de cima.

A jovem dormia de lado sobre o travesseiro, os cabelos negros espalhados como nuvens. As sobrancelhas delicadas estavam franzidas, e suas mãozinhas agarravam com força a ponta da coberta.

Parecia uma corça assustada, de dar pena.

A voz com que murmurava durante o sono era tão baixa que ele precisou se inclinar até perto dos lábios dela para entender.

As palavras lhe soaram familiares. Com a voz embargada, ela disse:

— Mãe, estou com tanta saudade de você...

Confuso, Lu Linyuan inclinou a cabeça e observou-a de muito perto.

Quando se comportava assim, pedindo carinho, aquela pequena despertava muito mais ternura do que quando passava os dias fazendo loucuras e causando confusão.

Mas... por que ela sempre sonhava com cavalos? [Nota: em chinês, “mãe” (*mā*) e “cavalo” (*mǎ*) têm sons próximos.]

Será que, antes de entrar no palácio, tinha trabalhado cuidando dos cavalos, como o célebre Guardião dos Cavalos?

Ning Xiaoxiao continuou repetindo as mesmas palavras, cada vez mais perto do choro.

Lu Linyuan detestava ver gente chorando. Se outra pessoa chorasse à sua frente, teria vontade de arrancar-lhe os olhos.

Mas, quando aquela sua pequena peste chorava, toda a sua irritação desaparecia:

— Pare de choramingar. Vou mandar trazer seu cavalo.

— Sanfu, vá buscar o Cavalo de Lama e Três Ervas em Zhongcui.

Sanfu foi e voltou depressa. — Majestade, trouxemos o Cavalo de Lama e Três Ervas ao Palácio Chaoyang. Está amarrado no pátio.

— Traga-o para dentro.

— Mas... — Sanfu hesitou. Seu senhor era obcecado por limpeza e mal suportava pessoas no quarto. Como permitiria a entrada de um cavalo imundo?

— Majestade, esse animal está há três dias sem banho. Não está nada limpo...

— Eu mandei trazê-lo! Por que tanta conversa?

— ...

Mas assim que Sanfu conduziu o Cavalo de Lama para dentro, Lu Linyuan se arrependeu.

Tapou o nariz, horrorizado. Como aquele bicho podia cheirar tão mal?

Mesmo assim, levou pessoalmente o animal até Ning Xiaoxiao.

Cavalos reconhecem seus donos. Ao vê-la, o bicho ficou todo carinhoso e lambeu-lhe o rosto duas vezes com a língua grossa.

Lu Linyuan estremeceu...

Que tipo de coisa estranha aqueles dois faziam normalmente? Mal se reencontravam e já começavam aos beijos?

Enquanto sua imaginação corria solta, Ning Xiaoxiao murmurou outra vez, dormindo:

— Mãe, estou com saudade da sua comida...

Os olhos de Lu Linyuan quase saltaram das órbitas!

Isso... não era cruel demais?

Afinal, aquele era o animal de estimação dela! E agora queria comer pratos preparados com a carne dele?

Como Ning Xiaoxiao não parava de repetir aquilo, Lu Linyuan acariciou a cabeça do Cavalo de Lama e falou num tom que parecia de negociação, mas era claramente uma ordem:

— Que tal fazer esse sacrifício? Daqui a dezoito meses, você será um belo cavalo outra vez. [Nota: alusão à expressão chinesa “dezoito anos depois serei novamente um valente”, usada após uma morte.]

Ao ouvir isso, o Cavalo de Lama soltou um relincho súbito, disparou aos coices e fugiu em desabalada carreira...

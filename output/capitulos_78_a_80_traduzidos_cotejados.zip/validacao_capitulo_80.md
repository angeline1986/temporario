# Validação do capítulo 80

- Fonte primária: `novel_capitulos_61_a_120(20261103-184549).docx`, capítulo 80.
- Original: **70** unidades não vazias, incluindo o título.
- Tradução: **70** unidades correspondentes.
- Unidades ausentes no cotejo: **0**.
- Verificação automatizada: limites dos capítulos, índices, ordem, preenchimento e correspondência 1:1.
- Revisão: leitura e adaptação durante a tradução. **Não houve segunda auditoria linguística independente**, e a cobertura estrutural não comprova fidelidade semântica absoluta.

## Observações editoriais

Os pensamentos interiores foram preservados entre 【】; adaptações pontuais sinalizam o estranhamento do imperador diante de pizza e hambúrguer. A referência recorrente “21” foi mantida. O título reflete o trocadilho com o canto da galinha.

## Ressalvas

Não se adicionaram cenas de capítulos seguintes. As notas entre colchetes são explicações editoriais de referências intraduzíveis literalmente, e não falas ou ações inventadas dos personagens.

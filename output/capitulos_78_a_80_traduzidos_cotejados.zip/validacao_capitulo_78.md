# Validação do capítulo 78

- Fonte primária: `novel_capitulos_61_a_120(20261103-184549).docx`, capítulo 78.
- Original: **79** unidades não vazias, incluindo o título.
- Tradução: **79** unidades correspondentes.
- Unidades ausentes no cotejo: **0**.
- Verificação automatizada: limites dos capítulos, índices, ordem, preenchimento e correspondência 1:1.
- Revisão: leitura e adaptação durante a tradução. **Não houve segunda auditoria linguística independente**, e a cobertura estrutural não comprova fidelidade semântica absoluta.

## Observações editoriais

A homofonia aproximada 媽 (mãe) / 馬 (cavalo) é explicada em nota; preservado o equívoco do imperador e a alusão humorística a dezoito meses. O animal 草泥馬 foi vertido de forma descritiva como Cavalo de Lama e Três Ervas; esta escolha pede padronização no conjunto da obra.

## Ressalvas

Não se adicionaram cenas de capítulos seguintes. As notas entre colchetes são explicações editoriais de referências intraduzíveis literalmente, e não falas ou ações inventadas dos personagens.

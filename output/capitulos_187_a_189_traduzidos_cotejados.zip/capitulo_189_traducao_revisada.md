# Capítulo 189 — Se continuar bancando a desgraçada, eu a racho para fazer lenha

Na noite anterior, Lu Linyuan estava bêbado e golpeara a própria cabeça sem medir a força. Por isso, ainda havia uma leve vermelhidão em sua testa.

Ele cobriu a testa teatralmente, decidido a jogar toda a culpa em Ning Xiaoxiao.

— Eu estava bêbado e só mandei chamá-la para cuidar de mim. Como ousou me atacar de maneira tão cruel?

Ao ver a expressão séria, com um toque de mágoa, Ning acabou sendo enganada de verdade.

Pensou que ele não se lembrasse de nada por causa da bebida e explicou com toda a paciência: — Majestade, entendeu errado. Não fui eu que machuquei sua cabeça...

Lu Linyuan: — Se não foi você, quem foi? Por acaso acha que eu mesmo faria isso?

Ning revirou os olhos. — Foi um idiota, está bom?

Lu Linyuan: — ...

Vendo que ele estava cheio de energia, até para discutir, Ning concluiu que os efeitos do álcool já tinham passado.

Preocupada com Gu Sijin, apressou-se a se despedir. — Que bom que Sua Majestade acordou. A sopa de ontem ficou aquecida na cozinha a noite toda. Peça a Sanfu para esquentá-la e trazer outra tigela. Assim, não terá dor de cabeça hoje.

Ao vê-la partir, Lu Linyuan segurou-lhe o pulso. — Não vai ficar comigo?

Ning soltou os dedos dele um por um e escapou da mão. — Preciso voltar correndo para cuidar da minha irmã.

Lu Linyuan não se importava nem um pouco se Gu Sijin viveria ou morreria. Mas, ao perceber que Ning o deixaria para cuidar dela, sentiu uma pontada absurda de ciúme e perguntou, amuado: — O que ela tem?

Ning Xiaoxiao: — Nada demais. Só pegou um resfriado comum.

【O que ela tem? Ora, o que poderia ter? Só colocou um belo par de chifres em você...】

Lu Linyuan não entendeu direito o significado da expressão “colocar chifres”, mas não a deixou ir embora tão facilmente.

Esperou Sanfu trazer a sopa e obrigou Ning a dar-lhe duas tigelas na boca. Só quando a hora da audiência matinal se aproximou é que teve a magnanimidade de liberá-la.

No caminho de liteira para seus aposentos, mal atravessou o portão do palácio e já sentiu um cheiro forte e irritante de fumaça.

Viu Qiqi sentada à porta da pequena cozinha, alimentando com lenha um fogareiro em que cozinhava alguma coisa.

Aproximou-se e perguntou: — Como minha irmã passou a noite?

Qiqi: — Minha senhora ficou bem. Acordou uma vez durante a madrugada, tomou o remédio e voltou a dormir.

Ning ficou um pouco mais tranquila. Ao perceber que Qiqi preparava o remédio de Gu Sijin, estranhou: — Por que está cozinhando o remédio aqui fora?

Qiqi olhou para a pequena cozinha, com as portas e janelas fechadas, e respondeu, desanimada: — A Consorte Duan tomou a cozinha para si. Só pude preparar o remédio da senhora aqui na entrada.

Era pleno inverno, e a temperatura lá fora era baixíssima. A capital também era seca; o vento frio cortava a pele como uma faca. Preparar o remédio levava pelo menos meia hora. Ficar ali tanto tempo era pedir para adoecer.

Qiqi já parecia pálida e tossia de vez em quando.

Ning a ajudou a se levantar do chão gelado, tirou delicadamente a neve que se acumulara sobre sua roupa e disse, aflita: — Então espere até que ela termine. Se ficar aqui e adoecer também, o que vamos fazer?

Qiqi mordeu o lábio, magoada e indignada:

— Mas a Consorte Duan não dá sinal nenhum de que vá terminar. Desde a quarta vigília, as criadas dela estão preparando o café da manhã.

— Só nesse tempo já fizeram cinco pratos. Vi com meus próprios olhos: ela nem tocou na comida e mandou jogar tudo, exatamente como veio, no barril de restos.

— Está fazendo isso de propósito. De manhã soube que a senhora Gu estava doente e até foi visitá-la. Mas que visita coisa nenhuma! Foi exigir de volta os presentes que tinha dado antes. A pulseira que a senhora usava havia sido um presente dela. Hoje, aproveitou que a senhora dormia e a retirou do braço.

— Ela sabe que a senhora Gu está doente e está nos prejudicando de propósito, para eu não conseguir preparar o remédio.

Depois de ouvir o relato, Ning compreendeu as intenções de Duan.

Ela não levara a pulseira simplesmente para recuperar um presente; temia que, depois de romperem relações e algum segredo vir à tona, a pulseira se tornasse uma prova contra ela.

Desde o episódio em que Duan se comportara como um cão faminto diante da papa derramada, a Consorte Duan, Ning Xiaoxiao e Gu Sijin haviam rompido definitivamente.

Ao que parecia, dali em diante Duan pretendia atacá-las abertamente.

Ning soltou um riso gelado, virou-se e chutou a porta da pequena cozinha, escancarando-a.

Xiuer e duas criadas trabalhavam junto ao fogão. Quando ouviram o barulho e viram Ning, as três começaram a tremer de medo.

Ning avançou depressa e distribuiu bofetadas nas duas outras criadas, uma de cada lado, antes de acertar um chute na barriga de Xiuer.

Xiuer caiu contra o fogão. Ning deu um passo adiante, agarrou-a pelo pescoço e se preparou para mergulhar sua cabeça na panela de caldo de carne fervente.

Xiuer gritou, apavorada: — Nobre Dama Hua, tenha piedade!

Olhando para a enorme panela de caldo recém-preparado, Ning disse, feroz: — Você e sua senhora são porcas criadas em que chiqueiro? Conseguem comer tanta coisa assim? Que tal eu mandar trazer os dois barris de lavagem ao lado da latrina, para vocês beberem tudo de uma vez?

Da última vez, depois de comer a papa do chão, Xiuer passara três dias com diarreia. Se agora bebesse lavagem, não ia acabar com os intestinos em frangalhos até o fim dos tempos?

Estava prestes a implorar por misericórdia quando a Consorte Duan apareceu.

Assim que entrou, Duan perguntou, com voz suave: — Tão cedo e já fizeram a Nobre Dama Hua ficar zangada de novo?

Ning lançou-lhe um olhar irritado. — Suas criadas passaram a manhã ocupando a cozinha para preparar um monte de comida que nem cachorro comeria, depois jogaram tudo no barril de restos. O imperador detesta desperdício de comida. Imagino que não tenham feito isso por ordem de Vossa Senhoria, não é?

Duan sorriu. — Naturalmente que não. Também acabo de descobrir o que fizeram. Mais tarde vou puni-las como merecem. Se precisa usar a cozinha, fique à vontade. Estou indo cumprimentar a imperatriz.

Enquanto Ning se distraía, Xiuer escapou de suas mãos e correu para junto de Duan, acompanhando-a, cabisbaixa, na visita à imperatriz.

Ao ver que Ning havia vencido a disputa com a Consorte Duan, Qiqi e as outras correram até ela, batendo palmas e elogiando sua coragem.

Ning bateu as mãos uma na outra e apontou para fora com o queixo. — Tragam o remédio para cozinhar aqui dentro. Não precisam passar frio lá fora.

Pensou que o assunto estivesse resolvido. Mas quando Qiqi levou a panela de remédio para dentro e tentou acender o fogo, descobriu que a lenha recém-cortada no dia anterior havia sido inteiramente consumida naquela manhã pelas criadas da Consorte Duan.

— E agora? Se formos buscar lenha no Departamento de Assuntos Internos, a ida e volta vão atrasar a hora do remédio da senhora...

A raiva que Ning acabara de conter voltou a subir de uma vez.

Ela olhou na direção do salão principal da Consorte Duan e rosnou: — Essa mulher morre se passar um único dia sem ser uma desgraçada?

Saiu furiosa da pequena cozinha e mandou Qiqi, Qiaqia, Bengbeng e Lala acompanhá-la. Chegando à porta do salão principal, ergueu a saia e escancarou a entrada com um chute. Então se virou e ordenou em voz alta:

— Tirem de lá as mesas, as cadeiras, os banquinhos, os mantos, as roupas íntimas, os sapatos e as meias dela. E queimem tudo!

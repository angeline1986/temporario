# Capítulo 188 — Pegue isto e me bata

Mas, antes que Ning Xiaoxiao pudesse se alegrar por dois segundos, ele ficou mole como um bicho sem ossos, deixou a cabeça cair sobre o ombro esquerdo dela, apoiou ali o queixo e, virando o rosto, estalou os lábios e soprou em sua orelha:

— Ning Xiaoxiao...

— Sua safadinha desgraçada...

???

Mas que conversa era aquela?

Por que tinha que começar a insultá-la assim que ficava bêbado?

Ning lançou-lhe um olhar atravessado. — Majestade... Isso são modos?

— Modos? — O olhar brincalhão de Lu Linyuan percorreu seu corpo. De repente, agarrou-lhe o pulso e levou a mão dela até seu “vinte e um”.

Ning Xiaoxiao: — !!!

Ela tentou se soltar, mas ele apertou ainda mais.

O “vinte e um”, que já estava em plena posição de sentido, ficou ainda mais descontrolado ao contato com a mão dela.

Ning nunca ficara tão sem palavras na vida. O coração quase lhe saltava pela garganta, e ainda tinha que ouvir Lu Linyuan perguntar, em tom provocador:

— Olhe só. Você acha que isso são modos?

Ning Xiaoxiao: — Acho que os meus modos são excelentes. Você é que parece estar com algum problema sério. Parece que enlouqueceu...

Lu Linyuan soltou um riso frio. — Se eu enlouquecer de verdade, temo que você não aguente.

Ele soltou o pulso dela e percebeu que Ning continuava segurando. Só então entendeu que, no fundo, acabara de realizar um sonho secreto dela.

Ning também se deu conta do constrangimento e tentou retirar a mão às pressas, quando ouviu Lu Linyuan interrogá-la:

— Ning Xiaoxiao, só vai aceitar ficar comigo se eu me ajoelhar e implorar?

— Sou o Filho do Céu! Como poderia deixar meu orgulho de lado para lhe dizer todas aquelas declarações melosas?

A pergunta deixou Ning sem resposta. Ela também aprendera com ele a arte de ser teimosa até o fim:

— Não pedi que me dissesse declaração melosa nenhuma! Você... hum?

Ele usou o método físico mais primitivo para calar aquela boquinha de cachorrinha que nunca dizia nada de bom: um beijo.

Foi um beijo breve. Quando Ning se aquietou, ele olhou dentro dos olhos límpidos dela e, deixando de lado o orgulho imperial, pronunciou cada palavra com clareza:

— Mas eu gosto mesmo muito da minha Xiaoxiao.

Ning já estava cansada até de falar em coração acelerado.

Sentindo aquele pudor que a acompanhava, baixou a cabeça, tímida, e respondeu em voz suave:

— Quando me disser isso estando sóbrio, eu lhe darei uma resposta muito séria.

Ela trouxe a sopa para a ressaca, serviu uma tigela e entregou-a a Lu Linyuan. — Agora beba e vá dormir. Levei duas horas chinesas para preparar isto. Se não beber, vou ficar brava.

Duas horas chinesas — quatro horas.

Não havia transcorrido sequer uma hora chinesa desde o fim do banquete.

Ou seja, Ning começara a preparar aquela sopa muito antes.

O coração dele se aqueceu como a tigela fumegante de sopa à sua frente.

Aliás, ficou ainda mais quente.

Aproveitando a embriaguez, abandonou a dignidade de imperador e fez manha diante da pequena esposa: — Dê na minha boca.

Ning olhou de lado. — Sua mão não está funcionando perfeitamente?

Lu Linyuan movimentou o pulso e a ameaçou: — Se não me der, daqui a pouco ela volta a agarrar seu pulso.

Ning Xiaoxiao: — ...

Muito contrariada, pegou uma colher de sopa e a levou até a boca dele.

Mas Lu Linyuan não bebeu. — Tem que soprar primeiro.

Ning Xiaoxiao: — ???

Está bem. Eu aguento!

Ela soprou duas vezes, sem entusiasmo, e só então Lu Linyuan bebeu obedientemente.

A sopa podia aliviar a bebedeira, mas não apagar o fogo do desejo.

A força primordial que ardia dentro dele não diminuiu com a sopa. Pelo contrário, ficou ainda mais intensa.

A essa altura, porém, sua mente começava a clarear.

Ele era um tirano completo: nas campanhas militares, matava sem hesitar e, com uma única ordem, tomava pela força o que quisesse e arrasava países que não se submetessem.

Tampouco costumava jogar limpo. Como soberano, desde que seu país prosperasse, pouco importava quais artimanhas desprezíveis usasse contra outros reinos.

Também nunca fora um homem apegado à etiqueta. Em seu mundo, suas palavras eram decretos, e ele próprio era o céu acima da dinastia Qi.

Ainda assim, diante de Ning Xiaoxiao, aquele homem se tornava extraordinariamente reservado e respeitoso — um exemplo de virtude masculina.

Não queria que a primeira vez dos dois acontecesse de maneira descuidada enquanto estava bêbado. Um momento que merecia ser lembrado não deveria se perder por causa de um apagão alcoólico. Seria um desperdício não poder recordá-lo depois.

Mas Ning estava bem ali. Como aguentar aquilo?

No desespero, teve uma ideia tão absurda que parecia que seu cérebro havia dado curto. Olhou em volta e apanhou uma vara de madeira usada para erguer a cortina do leito, pesando-a na mão.

Então a ofereceu a Ning e ordenou: — Pegue. Dê uma pancada na minha cabeça.

Ning Xiaoxiao: — ...

Ela fitou a vara, mergulhada em pensamentos: 【Mas... você é completamente idiota, é?】

— Majestade, por que eu bateria no senhor assim, do nada?

— Eu mandei bater, então bata!

Ning não lhe deu ouvidos. Sem alternativa, Lu Linyuan deu ele próprio uma pancada forte na cabeça.

Ning arregalou os olhos diante daquela operação. — Majestade... O que está fazendo?

Mas já não havia ninguém capaz de responder à pergunta dela.

Aquele tirano idiota e azarado acertara a própria cabeça duas vezes com a vara e desmaiara. Agora estava estatelado na cama, parecendo um peixe salgado.

A reação de Ning Xiaoxiao foi: “Não entendi nada, mas fiquei profundamente impressionada”.

【O clima chegou a esse ponto e você me apronta uma dessas?】

Ela examinou Lu Linyuan e sentiu um certo desprezo:

【Tsc, tsc... Será que você realmente não dá conta do recado?】

Ele estava muito bêbado; até sua respiração exalava um leve cheiro de álcool.

Ning se lembrava de notícias sobre bêbados que, vomitando durante a noite, acabavam sufocados com o próprio vômito.

Por isso decidiu não ir embora naquela noite e ficar para cuidar dele.

Só depois de avançada a madrugada, sentada num assento aquecido, seus olhos começaram a pesar e ela adormeceu.

Pessoas bêbadas às vezes acordam cedo. Antes mesmo da quarta vigília terminar, Lu Linyuan despertou na manhã seguinte com uma sede insuportável.

Primeiro sentiu uma forte dor de cabeça. Esfregou as têmporas doloridas e então percebeu Ning Xiaoxiao deitada no assento aquecido.

Não lembrava de todos os mínimos detalhes da noite anterior.

Mas a maior parte dos acontecimentos permanecia bastante nítida.

Inclusive, é claro, o fato de ter se golpeado duas vezes até perder os sentidos.

Agora que se lembrava daquilo, achava que tinha agido como um completo imbecil. Como conseguira fazer algo tão idiota?

Ao se levantar para buscar água, as cenas constrangedoras da noite anterior inundaram sua mente como uma maré. Quanto mais recordava, mais queria desaparecer de vergonha.

Justo naquele momento, Ning ouviu o barulho e também despertou.

Ela esfregou os olhos, cumprimentou Lu Linyuan com preguiça e perguntou: — Majestade, sua cabeça está bem?

Lu Linyuan congelou por um instante, mas logo pareceu encontrar uma desculpa salvadora. Pousou a xícara, lançou-lhe um olhar severo e exigiu saber:

— Por que você me golpeou até me deixar inconsciente ontem à noite?

Ning Xiaoxiao: — ???

【Mas que diabos você está latindo logo cedo...?】

# Capítulo 187 — O tirano bêbado

O coração de Ning Xiaoxiao era grande o suficiente para abrigar um oceano.

Não conseguia deixar Gu Sijin de lado, mas também se preocupava com Lu Linyuan.

Felizmente, depois de perguntar repetidas vezes, os médicos imperiais garantiram que Gu Sijin estava mesmo estável e fora de perigo. Só então Ning pediu a Qiqi e às outras que cuidassem bem dela durante a noite e acompanhou Xiao Yinzi ao Palácio Chaoyang.

Sentada na liteira imperial Luanming, não conseguia aquietar os pensamentos.

Chu Xingran, na obra original, era descrito como um louco obsessivo.

Amava Gu Sijin tão ardentemente que, para ficar com ela, aceitaria até ser o amante de uma mulher casada.

Ning Xiaoxiao não sabia como julgar aquele relacionamento. Antes, como leitora distante, conseguia escrever centenas de palavras criticando os dois nos comentários entre os parágrafos.

Ainda se lembrava do que escrevera sobre Gu Sijin:

【Um burro selvagem deu um coice na cabeça dessa protagonista, foi?】

【Essa personagem que vive correndo atrás dos outros para se humilhar me faz perder a paciência!】

【Se gosta mesmo do segundo protagonista, foge com ele! Por que passa o dia inteiro nessa choradeira?】

Agora que estava dentro do livro, compreendia que aquela maneira de escrever da autora era justamente a mais realista, a que melhor correspondia à natureza humana.

Não era que Gu Sijin não quisesse fugir. Ela não podia.

Mesmo que ela e Chu Xingran saíssem ilesos, toda a família de origem dela seria condenada junto.

Felizmente, as constantes alterações de Ning na trama haviam transformado a grande protagonista feminina numa figura praticamente invisível do harém.

Nessas circunstâncias, já que Lu Linyuan não amava Gu Sijin, deixá-la sair do palácio para realizar o romance com seu grande amigo não seria uma coisa boa?

Mas isso equivalia a fazer o imperador levar um belo par de chifres. Ning não ousava falar diretamente e começou a bolar um plano.

【É isso! Posso modificar a trama para que os dois saiam do palácio!】

Mal se animou pensando que seu poder finalmente teria uma grande utilidade e, ao abrir o documento, recebeu uma advertência de Xiao Qi:

【Alerta, alerta! A hospedeira não pode modificar diretamente os grandes acontecimentos da trama principal que determinem os rumos da história. Caso contrário, o mundo do livro desmoronará e a hospedeira desaparecerá por completo.】

Ning Xiaoxiao: 【Mas quero ajudá-la. Só de rever Chu Xingran hoje ela já vomitou sangue. Se continuar sofrendo assim, tenho medo de que morra antes do desfecho!】

Xiao Qi: 【Em princípio, você não pode usar seu poder para alterar diretamente a trama principal da protagonista. Mas, se conseguir que o tirano proponha por vontade própria libertá-la do palácio, sem modificar o texto, isso pode funcionar.】

Fazer Lu Linyuan tomar a iniciativa?

Ning ficou em silêncio. Precisaria pensar cuidadosamente numa solução.

Lu Linyuan era o típico homem frio por fora e caloroso por dentro: palavras mais afiadas que facas, coração mais macio que tofu. Portanto, ainda havia esperança.

Ao chegar ao Palácio Chaoyang, encontrou Sanfu andando em círculos diante da entrada, como uma formiga sobre uma frigideira quente.

Assim que a liteira chegou, ele se apressou a ajudá-la a descer.

— Ai, minha senhora Ning, até que enfim! A senhora... por favor, entre logo e veja o imperador!

Ning achou que ele só tinha bebido demais. No máximo estaria fazendo alguma palhaçada de bêbado. O que havia de tão grave?

Mas, quando Sanfu a levou à porta dos aposentos e ela espiou pela janela entreaberta, viu Lu Linyuan de roupa de dormir fininha, suando em bicas enquanto dançava *Amo Você*!

— Se de repente você espirrar, é porque este imperador está pensando em você~

— Se...

Ao som da música hipnótica cantada pela voz bizarra de Lu Linyuan, Ning, de cara fechada, puxou Sanfu para o lado e perguntou baixinho:

— Faz quanto tempo que ele está nesse surto?

Sanfu gaguejou: — É muito raro Sua Majestade ficar bêbado. Hoje, desde que voltou do banquete, está assim. Este servo tentou aconselhá-lo, mas ele não parava de gritar o nome da senhora para mim...

Enquanto falava, Sanfu fez uma expressão de extrema timidez e, instintivamente, cobriu a bochecha. — Por isso... fui correndo chamá-la...

Ning olhou de novo para Lu Linyuan, que dançava com toda a energia, e resmungou mentalmente:

【E de que adianta me chamar? Quer que eu seja professora de dança dele?】

O tirano ouviu esse pensamento exatamente quando chegava à pose final da coreografia.

Então girou de frente para a janela, saltou e fez um coração com os dedos para Ning:

— Amo você~~

Que diabos de ataque de fofura era aquele? Como o homem conseguia ficar um pouquinho adorável quando bebia demais?

Enfim, já estava ali. Como ele estava naquele estado, melhor dar-lhe a sopa para curar a bebedeira e mandá-lo descansar.

Quando Ning entrou pela porta principal, Lu Linyuan estava de tocaia junto à entrada.

Assim que a porta se abriu, ele avançou como um cachorro fiel, abraçou Ning e esfregou o nariz no pescoço dela, como uma criança mimada.

Assustada com aquele grandalhão fazendo denguinho, Ning ergueu a marmita e sorriu sem graça:

— Majestade, pode se esfregar depois? Preparei uma sopa para sua ressaca. Beba primeiro, está bem?

— Não! — respondeu ele, cheio de manha. — Só depois de um beijinho!

Sem lhe dar meio segundo para reagir, plantou um beijo estalado na bochecha dela.

O estalo foi tão alto que alguém poderia pensar que ele havia soltado um pum na cara de Ning.

Sanfu, que a acompanhara até ali, soltou uma risadinha digna da cafetina de um bordel e, muito atencioso, fechou a porta atrás deles...

【Ah, seu traíra! Me apunhalou pelas costas!】

【Espera... Tem alguma coisa estranha aqui...】

Lembrando da expressão envergonhada de Sanfu diante da porta, sua imaginação disparou:

【Esse imperador desgraçado não deve ter confundido Sanfu comigo e dado um beijo nele, né?】

【Credo, agora esse homem está meio contaminado...】

Assim que ela pensou nisso, Lu Linyuan segurou seu rosto com as duas mãos, obrigando-a a olhar para ele. Com um tom solene e a voz embriagada, declarou:

— Eu não estou contaminado! Não beijei Sanfu. Hic!

— Ele fingiu ser você, então lhe dei duas bofetadas.

— Como ousa se fazer passar pela minha preciosa? Está cansado de viver!

Ning ficou surpresa. Parecia que o tirano a conhecia muito além do que seria normal.

Como ele conseguia adivinhar tudo o que ela pensava?

Mas se lembrou de uma frase que Qi Meijuan dissera a Ning Dazhi: “Nem precisa levantar a bunda. Se você só se mexer um pouquinho, já sei que vai peidar”. Então não achou tão estranho.

Além do mais, ele tinha acabado de chamá-la de “minha preciosa”!

Bêbado, aquele homem criava coragem. Normalmente, só sabia bancar o imperador, zombar e criticá-la. Era apenas naquele estado que lhe saíam da boca palavras doces como mel.

Entretanto, antes que Ning pudesse curtir a alegria por dois segundos, ele ficou mole como um bicho sem ossos, deixou a cabeça cair sobre o ombro esquerdo dela, apoiou ali o queixo e, virando o rosto, estalou os lábios e soprou em sua orelha:

— Ning Xiaoxiao...

— Sua safadinha desgraçada...

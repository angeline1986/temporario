# Capítulo 206 — A primeira missão de emergência de Xiao Qi

O Escravo Porco havia sido castrado.

Dois meses antes, quando a imperatriz-viúva fora transferida temporariamente para o Palácio Shoukang, Lu Linyuan mandara Sanfu buscar o especialista em castrações do Departamento de Assuntos Internos, para que removesse tudo do prisioneiro.

Fizera aquilo porque pretendia preparar uma surpresa para sua querida “mãe”.

Afastou a cortina fina de seda, aproximou-se do Escravo Porco e se abaixou. Agarrando-lhe os cabelos desgrenhados, semelhantes a capim seco, obrigou-o a erguer o rosto e encará-lo.

Sorriu. — Para alguém como você, que diferença faz ter ou não ter aquilo? Não tem um pingo de coragem. Se eu estivesse em seu lugar, preso e torturado durante tantos anos, já teria preferido morder a própria língua e acabar com a humilhação.

Ao ouvir o tom gelado e ver a expressão sinistra do imperador, o prisioneiro pensou que finalmente seria morto. Seus lábios tremiam de pavor. — Não! Não... Majestade, não me mate! Eu não quero morrer... Uuuh... Eu não quero morrer mesmo...

Seu choro era rouco, como se tivesse uma bola de catarro presa na garganta que jamais conseguiria expelir.

Lu Linyuan franziu a testa e largou brutalmente seus cabelos. Em seguida, dirigiu-se a uma bacia dourada e mergulhou as mãos em água perfumada com essência de rosas para lavá-las.

— Agora posso lhe dar uma oportunidade. Uma chance de voltar a ver a luz do dia.

— Você a quer?

Ao saber que ainda podia ter esperança de viver, o Escravo Porco começou a bater a testa no chão repetidamente. — Quero! Quero! Imploro a misericórdia de Vossa Majestade! Tenha piedade deste servo!

Lu Linyuan retirou as mãos da bacia e sacudiu sobre o rosto dele as gotículas que restavam nos dedos.

Assim que as gotas tocaram suas faces, o prisioneiro as levou com os dedos até os lábios ressecados e rachados, lambendo-as freneticamente com a ponta da língua, como um louco.

Lu Linyuan o fitou com os olhos escuros. — Você sabe que governo o reino pela benevolência e pela piedade filial. A pessoa que mais prezo é minha mãe. Preciso agora de alguém de confiança para servi-la e cuidar dela como se deve. Acha que posso confiar em você?

— Pode! Vossa Majestade pode confiar neste servo! Jamais desapontarei Vossa Majestade!

Lu Linyuan assentiu com um leve sorriso. — Espero que sim. Se servir bem à minha mãe, prometo que, quando completar vinte e cinco anos, lhe concederei o mesmo privilégio das criadas palacianas: a permissão de deixar o palácio.

O prisioneiro ficou exultante; até sua respiração se acelerou. — Este servo agradece a imensa graça de Vossa Majestade!

Era uma jogada primorosa de Lu Linyuan.

Depois de tantos anos submetido sem motivo a suas torturas, o Escravo Porco se humilhava em busca de uma chance de viver. Como poderia não guardar rancor?

Embora, em particular, Lu Linyuan não se desse bem com a imperatriz-viúva, continuara a conceder-lhe títulos honoríficos. Agora ela era, sem exceção, a mulher de maior prestígio desde a fundação da dinastia Qi.

Todos os súditos consideravam Lu Linyuan um modelo de benevolência e devoção filial. Os de fora acreditavam que ele prezava imensamente a imperatriz-viúva, e o Escravo Porco não era diferente.

A maneira mais cruel de se vingar de alguém era destruir a pessoa que esse alguém mais estimava.

Servindo tão perto da imperatriz-viúva, o Escravo Porco acabaria tendo alguma oportunidade de agir.

O problema era que Lu Linyuan já previra até mesmo o que o prisioneiro estava prestes a prever.

Ninguém conhecia melhor do que ele a mente desconfiada da imperatriz-viúva.

Havia dois meses que a mantinha no Palácio Shoukang; a ruptura entre os dois já estava escancarada.

Depois de uma briga tão feia entre “mãe” e “filho”, ele de repente a levaria de volta ao Palácio Xianshou, cercando-a de atenções e tratando-a com ainda mais intimidade. Como ela não desconfiaria?

E, se nesse momento Lu Linyuan designasse o Escravo Porco para servi-la, a imperatriz-viúva certamente pensaria que aquele eunuco desconhecido fora enviado para vigiar todos os seus movimentos.

Como poderia tratá-lo com gentileza?

Quando chegasse a hora, ela talvez o humilhasse, espancasse ou até mandasse matá-lo.

Lu Linyuan não precisaria mover um dedo. Bastaria enviar o Escravo Porco ao Palácio Xianshou para acompanhar, dia após dia, aquela mãe e aquele filho biológicos tramando um contra o outro por interesses próprios, até uma disputa mortal. Que divertimento!

Naturalmente, como imperador bondoso, ele sem dúvida lhes permitiria um dia saber quem eram e reconhecer o parentesco que os unia.

Por exemplo, depois que a imperatriz-viúva executasse o Escravo Porco... ou que o Escravo Porco envenenasse a imperatriz-viúva, Lu Linyuan revelaria o segredo colossal ao sobrevivente.

Que cada um colhesse o fruto amargo do mal que havia semeado.

Não devia existir desespero maior no mundo.

*

Naquela noite, Ning Xiaoxiao estava se divertindo à beça.

Desde que se mudara para o Palácio Fengyi e se livrara daquela vaca da Consorte Duan, não lhe faltavam passatempos: só não tinha ainda aberto um buraco no teto do palácio de tanta bagunça.

Como a neve acumulada no pátio fora removida naquele dia, depois do jantar ela brincou de esconde-esconde com Gu Sijin, Qiqi, Qia Qia, Bengbeng, Lala e os demais. Depois vieram pula-corda em grupo e jogo de saquinhos de areia.

Ao anoitecer, senhoras e criados voltaram para dentro, sentaram-se juntos em torno dos assentos aquecidos e começaram a jogar Dou Dizhu, um jogo de cartas.

O baralho fora confeccionado pela própria Ning Xiaoxiao. No começo, todos diziam nunca ter visto aquilo, que não conseguiriam aprender e que não queriam jogar. Agora que aprenderam, não passavam um único dia sem disputar algumas rodadas.

Só se dispersaram à meia-noite. Ning Xiaoxiao tomou um banho quente delicioso e se deitou, pronta para dormir, quando Xiao Qi — aquele safado que não aparecia havia um tempão — surgiu de repente, soltando um uivo que a fez estremecer.

【Mas que... Você é idiota? Por que está berrando feito um fantasma a esta hora da noite?】

Xiao Qi: 【Hospedeira, hospedeira! O tempo é curto, escute! Depois de um esforço descomunal, consegui para você uma “missão de emergência”! Se conseguir cumpri-la dentro de uma hora, o índice de desvio da trama vai aumentar oito pontos percentuais, chegando a 40% no total! Mas, se fracassar, perderá 40% de sua vitalidade e ficará com só meia vida. Hehe!】

Ning Xiaoxiao: 【Esse é o resultado de todo o seu esforço? Pelo que você lutou, afinal? Para me mandar para a cova?】

Xiao Qi: 【Ai, não dá tempo de explicar, hospedeira! Missões de emergência são obrigatórias, e a contagem regressiva começou no instante em que anunciei a missão.】

Assim que terminou de falar, surgiu na mente de Ning Xiaoxiao um cronômetro regressivo semelhante aos que aparecem nas bombas das séries de televisão.

A tensão se instalou na mesma hora. Ning Xiaoxiao deu um pulo da cama e, enquanto se vestia às pressas, cobrou Xiao Qi:

【Seu desgraçado! Então fala logo qual é a porcaria da missão!】

Xiao Qi: 【Bip, bip, bip! A hospedeira recebeu a missão de emergência: “Derrubar a estante dos aposentos do tirano”. Conclua a missão dentro de uma hora.】

Ning Xiaoxiao hesitou por um instante: 【Só isso?】

Xiao Qi: 【Isso mesmo! Eu falei que era uma missão-bônus que consegui para você. São pontos de desvio da trama de graça!】

Embora desconfiasse daquela bondade toda, até então aquela era, sem dúvida, a missão mais fácil que Ning Xiaoxiao já recebera.

Era só derrubar a estante de Lu Linyuan. O que havia de difícil nisso?

Se ela derrubasse o próprio Lu Linyuan, ele provavelmente nem reclamaria!

Assim, Ning Xiaoxiao saiu toda feliz rumo ao Palácio Chaoyang.

Era uma visitante habitual dali. Lu Linyuan decretara havia muito tempo que, sempre que ela aparecesse, ninguém poderia impedi-la de entrar, fosse a hora que fosse. Por isso, chegou sem dificuldade à porta de seus aposentos.

Naquela noite, Sanfu não estava de guarda do lado de fora. Quando ela entrou, encontrou o quarto iluminado, mas Lu Linyuan não estava em lugar nenhum.

【Hmm... Aonde foi parar esse homem, fora dos aposentos a esta hora da noite?】

【Ah, deixa pra lá! Melhor ainda se não estiver aqui. Vou cumprir a missão primeiro!】

Ela correu até a estante e, fazendo força, derrubou-a no chão.

Então seus olhos se fixaram numa pequena saliência: um mecanismo oculto na parede atrás da estante...

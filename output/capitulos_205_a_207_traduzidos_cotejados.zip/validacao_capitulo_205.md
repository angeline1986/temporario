# Validação — capítulo 205

- **Fonte:** `novel_capitulos_181_a_211(20261105-152744).docx`, texto chinês tradicional.
- **Intervalo DOCX (base zero):** `1532` a `1589` (exclusivo `1590`).
- **Unidades não vazias, título incluído:** **55**.
- **Unidades no cotejo:** **55**; índices reais do DOCX, sem omissões ou duplicações.
- **Campos CSV:** `indice_docx,original_chines,traducao_portugues`, preenchidos e legíveis em UTF-8 com BOM.
- **Correspondência:** cada parágrafo português do arquivo Markdown está representado no CSV, inclusive título e separadores narrativos.
- **Observações editoriais:** O prisioneiro chamado 彘奴 é identificado como filho biológico da imperatriz-viúva, e não deve ser confundido com Lu Linyuan. Preservada a representação explícita de tortura, castração mencionada apenas no capítulo seguinte e trauma infantil.
- **Revisão realizada:** tradução contextual e cotejo estrutural 1:1. Não foi realizada uma segunda auditoria semântica independente integral; a verificação de quantidade de parágrafos não certifica ausência de erros de sentido dentro de cada unidade.

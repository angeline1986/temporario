# Capítulo 205 — O prisioneiro

Depois de permanecer por algum tempo no Palácio Xianshou, Lu Linyuan tomou a carruagem imperial de volta e ordenou a Sanfu: — Prepare um pouco de lavagem para porcos.

— Vossa Majestade vai alimentar o Escravo Porco? [Nota: 彘 (zhì) significa “porco”.] Mas este servo o alimentou anteontem. Ele só come uma vez a cada três dias, então...

— Não importa.

Recostado preguiçosamente no assento acolchoado, Lu Linyuan passava os dedos por um rosário de âmbar, os olhos sombrios fixos à frente. — Hoje estou de bom humor. Vou conceder-lhe uma porção extra.

Sanfu não fazia ideia de quem, afinal, era aquele “Escravo Porco”, muito menos do que teria feito para ofender Lu Linyuan e merecer tamanho “tratamento especial”: quatro anos inteiros trancafiado numa câmara subterrânea, preso a correntes e torturado dia e noite.

Ao voltar ao Palácio Chaoyang, Lu Linyuan retirou os livros da segunda prateleira da estante de seus aposentos. Na parede atrás dela havia um mecanismo saliente.

Ele o girou para a direita. Ouviu-se o ruído de engrenagens em movimento e, na parede ao lado, que parecia não ter sequer uma fresta, abriu-se uma porta.

A passagem levava ao subsolo. Seguia por túneis que encurtavam o caminho e, em menos de meia vara de incenso de caminhada, chegava-se ao ponto mais profundo.

Era ali que estava aprisionado o filho biológico da imperatriz-viúva.

Lu Linyuan avançou devagar. Do fundo do corredor escuro vinha o tinido metálico de correntes roçando umas nas outras, que lhe despertava uma satisfação doentia, difícil de descrever.

Acelerou os passos até distinguir, nas profundezas da escuridão, o Escravo Porco: os quatro membros acorrentados, incapaz de ficar de pé, arrastando-se penosamente pelo chão.

Quanto mais perto chegava, mais o fedor que emanava daquele corpo fazia os olhos arderem.

Sanfu já espalhara camada após camada de pó de gardênia pelo lugar, mas nem isso conseguia disfarçar o cheiro.

Lu Linyuan levava na mão esquerda um sininho de sete aberturas e, na direita, uma bacia cheia de restos de comida.

Sacudiu o sino como quem chama um gato ou um cachorro. Ao ouvir o tilintar límpido, o Escravo Porco estremeceu e, por puro reflexo condicionado, veio rastejando debilmente na direção do som, apoiado nas mãos e nos pés.

As correntes presas aos membros limitavam seus movimentos. Só conseguiu se arrastar até os pés de Lu Linyuan, onde ergueu a cabeça e o fitou com os olhos brilhando.

Lu Linyuan ergueu bem alto a bacia e, de repente, virou-a de boca para baixo. A lavagem caiu sobre o rosto do Escravo Porco, escorreu pela pele e se espalhou pelo chão numa poça imunda, misturada à poeira.

Para alguém submetido à fome por tanto tempo, o desejo de comer beirava a loucura.

O prisioneiro recolheu os restos com as mãos e os enfiou na boca, às grandes bocadas.

Lu Linyuan observou-o sem expressão por um bom tempo. Depois se virou, caminhou até o lado oposto e acendeu com um acendedor as lamparinas de óleo de sereia fixadas na parede.

A câmara se iluminou de imediato. Só então se via que, diante do lugar onde o prisioneiro estava acorrentado, uma cortina de gaze de seda dividia o ambiente em dois. A cortina impedia que o fedor chegasse ao outro lado; atrás dela, dispostos com esmero, havia uma escrivaninha imperial e um trono reluzentes de ouro.

Sobre a mesa se amontoavam tratados militares. Ao longo dos anos, em incontáveis noites silenciosas, Lu Linyuan vinha até ali sempre que dispunha de tempo para fazer “companhia” ao Escravo Porco.

Folheava tranquilamente seus livros de estratégia e, quando os olhos se cansavam, erguia a cabeça para contemplar o prisioneiro agonizante diante dele, como quem admira uma obra-prima de sua própria autoria, sem jamais se fartar da visão.

Talvez sua mãe também tivesse sido encarcerada daquela maneira pela imperatriz-viúva, tantos anos antes.

Pagar na mesma moeda: comparado ao sofrimento que a imperatriz-viúva lhe infligira, Lu Linyuan considerava suas próprias ações muito aquém do que ela merecia.

Sabia que o Escravo Porco também era vítima da disputa pelo poder imperial e das intrigas do harém. Ele era inocente, sim. Mas que culpa tivera sua própria mãe?

Se um inocente acabara naquele estado por ter a imperatriz-viúva como mãe biológica, só restava dizer que devia ter acumulado pecados demais em outra vida e agora viera ao mundo pagar por eles.

Antes, manter o Escravo Porco ali e observá-lo de tempos em tempos proporcionava a Lu Linyuan certa satisfação.

Mas, desde que a imperatriz-viúva começara a causar problemas sem motivo e a perseguir Xiaoxiao repetidas vezes, ele passara a sentir que sua vingança ainda estava longe de ser suficiente.

Na verdade, a imperatriz-viúva não era a única a sofrer de pesadelos e passar noites em claro ao longo de todos aqueles anos.

Lu Linyuan também sofria.

Sempre que fechava os olhos, a mente reproduzia, como um desfile interminável de imagens, os incontáveis dias e noites em que fora açoitado e maltratado pela imperatriz-viúva durante a infância.

Mesmo antes de descobrir a verdade sobre sua origem, ele já se perguntava por quê. As demais consortes cuidavam dos próprios filhos com carinho extremo. Mal se via uma delas repreender uma criança, quanto mais bater nela.

Ele se tornara o mais destacado de todos os príncipes. Por que, então, a imperatriz-viúva continuava a espancá-lo e insultá-lo pelo menor motivo?

Lembrava-se para sempre de que, em criança, nada o aterrorizava tanto quanto o instante de abrir os olhos ao acordar.

Era como se o mero fato de estar desperto, de continuar respirando, bastasse para incomodar a imperatriz-viúva.

Ao menor deslize — às vezes nem sequer era um erro —, ela o trancava numa salinha escura onde não se enxergava um palmo à frente e lhe dava comida azeda, já estragada.

Amaldiçoava-o com palavras e o castigava com golpes. Naquela época, Lu Linyuan acreditava sinceramente ser um inútil completo; do contrário, por que sua própria mãe o trataria assim?

Essas lembranças se transformaram em pesadelos que o atormentaram durante mais da metade de sua vida.

Curiosamente, porém, mais tarde, sempre que Xiaoxiao dormia ao seu lado, parecia haver uma força invisível que expulsava aqueles pesadelos e lhe devolvia a paz.

Depois, ele suportou tudo em silêncio e, usando a influência da família materna da imperatriz-viúva, conquistou o trono. Mesmo assim, tratou-a com deferência e nunca a constrangeu abertamente.

Não porque tivesse deixado de odiá-la. Estava apenas se ocultando e esperando, como um leopardo de tocaia, à espreita da oportunidade de cravar os dentes na garganta da presa e não lhe deixar nenhuma chance de escapar.

Tong Guowei era a grande ameaça à corte naquele momento. Lu Linyuan ainda precisava das famílias da imperatriz-viúva e da imperatriz para contrabalançar seu poder.

Quando Tong Guowei caísse, chegaria a vez da família da imperatriz-viúva, da família da imperatriz que conspirava com ela e de todos aqueles parasitas da corte que ele tolerara por tanto tempo. Acertaria de uma vez as contas novas e antigas.

Não pretendia poupar nenhum deles.

Todos pagariam com a vida por sua infância terrível e pela morte injusta de sua mãe.

— Uuuh... uuuh...

O choro baixinho do Escravo Porco arrancou Lu Linyuan de seus pensamentos.

O prisioneiro comera até sentir náuseas e agora soluçava no meio da sujeira.

Aquele choro lhe era familiar: fazia-o lembrar de si mesmo, quando criança.

Certa vez, estivera doente, ardendo em febre. Quando a imperatriz-viúva viera vê-lo, ele correra até ela chorando, chamara-a de mamãe e pedira um abraço. Recebera em troca uma bofetada impiedosa.

A imperatriz-viúva dissera que um homem precisava se manter firme e digno; que vergonha era aquela choradeira?

Agora Lu Linyuan podia devolver a frase ao verdadeiro filho dela.

Disse, em voz grave: — Um homem deve manter-se firme e digno. É verdade que uma lâmina tirou sua masculinidade, mas você continua sendo homem. Que vergonha é essa de ficar choramingando?

# Validação — capítulo 206

- **Fonte:** `novel_capitulos_181_a_211(20261105-152744).docx`, texto chinês tradicional.
- **Intervalo DOCX (base zero):** `1590` a `1655` (exclusivo `1656`).
- **Unidades não vazias, título incluído:** **63**.
- **Unidades no cotejo:** **63**; índices reais do DOCX, sem omissões ou duplicações.
- **Campos CSV:** `indice_docx,original_chines,traducao_portugues`, preenchidos e legíveis em UTF-8 com BOM.
- **Correspondência:** cada parágrafo português do arquivo Markdown está representado no CSV, inclusive título e separadores narrativos.
- **Observações editoriais:** A castração do prisioneiro é explicitamente confirmada. A estratégia de Lu Linyuan consiste em colocar mãe e filho juntos, sem que saibam a identidade um do outro. A missão de Xiao Qi acrescenta +8 pontos percentuais ao índice, totalizando 40%; fracasso custaria 40% da vitalidade.
- **Revisão realizada:** tradução contextual e cotejo estrutural 1:1. Não foi realizada uma segunda auditoria semântica independente integral; a verificação de quantidade de parágrafos não certifica ausência de erros de sentido dentro de cada unidade.

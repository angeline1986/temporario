# Validação — capítulo 207

- **Fonte:** `novel_capitulos_181_a_211(20261105-152744).docx`, texto chinês tradicional.
- **Intervalo DOCX (base zero):** `1656` a `1725` (exclusivo `1726`).
- **Unidades não vazias, título incluído:** **67**.
- **Unidades no cotejo:** **67**; índices reais do DOCX, sem omissões ou duplicações.
- **Campos CSV:** `indice_docx,original_chines,traducao_portugues`, preenchidos e legíveis em UTF-8 com BOM.
- **Correspondência:** cada parágrafo português do arquivo Markdown está representado no CSV, inclusive título e separadores narrativos.
- **Observações editoriais:** Ning se recusa a investigar o segredo por respeito à privacidade. A estante bloqueia acidentalmente a porta da passagem; ela não sabe que Lu Linyuan está preso. A recompensa é um pó de invisibilidade por uma hora, não uma invisibilidade permanente. A crise dele é ligada ao trauma de infância. O capítulo termina sem resolução.
- **Revisão realizada:** tradução contextual e cotejo estrutural 1:1. Não foi realizada uma segunda auditoria semântica independente integral; a verificação de quantidade de parágrafos não certifica ausência de erros de sentido dentro de cada unidade.

# Capítulo 207 — Quem não conhece a dor alheia não deve aconselhar o perdão

【Bip, bip, bip! Parabéns, hospedeira! Você concluiu a missão “Derrubar a estante dos aposentos do tirano”. A missão foi cumprida e o índice de desvio da trama aumentou oito pontos percentuais. O índice acumulado agora é de 40%! Parabéns, você ganhou um prêmio da grande roleta!】

Enquanto Xiao Qi seguia os procedimentos de sempre para lhe dar os parabéns, Ning Xiaoxiao não tirava os olhos daquele mecanismo saliente.

A peça lembrava um pouco a fechadura giratória de um cofre moderno. Ning Xiaoxiao já vira mecanismos iguais em inúmeros dramas históricos: geralmente, bastava girá-los para que uma parede se movesse e revelasse uma passagem ou uma câmara secreta.

E lugares assim costumavam esconder segredos incontáveis.

Xiao Qi tratou de atiçá-la: 【Hospedeira, olha só como essa rodinha é grande e redondinha! Não quer dar uma giradinha nela?】

Ning Xiaoxiao: 【Antes de girar essa daí, prefiro girar a grande roleta.】

Xiao Qi: 【...】

Após uma breve demora, a grande roleta surgiu em sua mente, repleta, mais uma vez, de recompensas que ela não fazia a menor ideia do que significavam.

Quando pôs a roleta para girar, ela pareceu emperrar por um instante depois de algumas voltas. Em seguida, foi perdendo velocidade até parar na casa intitulada “Pó da invisibilidade”.

Xiao Qi: 【Parabéns, hospedeira! Você ganhou o pó da invisibilidade! Depois de ingeri-lo, poderá ficar invisível temporariamente por uma hora!】

Era evidente que Xiao Qi havia manipulado a recompensa desta missão.

Sabia que Ning Xiaoxiao era curiosa demais para resistir a um mecanismo daquele tipo. E, com o pó da invisibilidade à disposição, ela se sentiria ainda mais livre para explorar sem receio.

Só que, dessa vez, a reação de Ning Xiaoxiao não seguiu os “cálculos” do sistema.

Ela guardou o pó consigo e, para surpresa de Xiao Qi, se abaixou, ergueu a estante, empurrou-a cuidadosamente de volta ao lugar e arrumou uma a uma as fileiras de livros que haviam se espalhado pelo chão.

Xiao Qi não entendeu absolutamente nada: 【Ué... Hospedeira, o que você está fazendo? Por que não está seguindo o roteiro???】

Murmurou baixinho: 【Não faz sentido... Você não tinha como ver aquele mecanismo e resistir à vontade de mexer nele...】

Ning Xiaoxiao: 【E por que eu mexeria? Se Xiao Lu tiver algum segredo, vai me contar quando quiser. Se não quiser me contar, por que eu invadiria o lugar às escondidas para descobrir? Em que isso é diferente de uma mãe que lê o diário do filho pelas costas enquanto ele está na escola? Uma atitude bem escrota!】

Xiao Qi: 【...】

Ning Xiaoxiao: 【Além do mais, se não abrir o mecanismo, nunca vou precisar descobrir o que tem atrás dele. Se eu não souber, a trama não vai avançar por minha causa. Não é melhor aproveitar esse tempo para dormir mais duas horas? Por que diabos eu iria procurar sarna para me coçar?】

Ao terminar, a estante já estava arrumada. Ela bateu as mãos para tirar a poeira e se virou para sair.

*Toc!*

Um baque surdo soou às suas costas e a assustou tanto que ela saltou no lugar, quase abrindo um espacate.

*Bum! Bum!*

Os golpes se tornavam cada vez mais rápidos e fortes, como se alguém martelasse a parede com toda a força.

Ning Xiaoxiao olhou na direção do som. A estante... A barulheira parecia vir da parede atrás dela.

Ao recolocar a estante no lugar, a saliência de madeira na parte superior do móvel encaixara-se bem no trilho pelo qual a porta secreta se abria, bloqueando-o completamente.

Do lado de dentro, antes bastava girar um mecanismo para abrir a porta. Agora, mesmo com um esforço descomunal, ela não se movia um milímetro.

E quem golpeava desesperadamente a porta da passagem secreta, do outro lado, era justamente Lu Linyuan.

Ning Xiaoxiao nem cogitava que Lu Linyuan pudesse ser o responsável pela barulheira. Tampouco sabia que bloqueara a porta. Pensou que, se fosse ele, alguém capaz de entrar ali certamente também saberia como sair.

Além disso, se ela abrisse aquela passagem, quem sabia que monstro poderia saltar lá de dentro?

No enredo original, Lu Linyuan também gostava de domesticar feras. A pantera-negra chamada Pixiu, que acompanhava Ren Duanli, havia sido domada por Lu Linyuan anos antes e depois dada a ele.

*Bum! Bum! Pá!*

À medida que os estrondos atrás da porta ficavam mais altos, Ning Xiaoxiao puxou o ar entre os dentes.

A coisa lá dentro batia com tanta força que bem podia ser um lobo, um tigre ou um leopardo! E se saísse dali e a transformasse num lanchinho da madrugada?

Melhor não se meter onde não fora chamada. Era hora de dar o fora...

*

Nesse momento, atrás da porta bloqueada, Lu Linyuan ficava cada vez mais agitado.

Conhecia artes marciais e tinha muito mais força do que uma pessoa comum. Porém, não importava o que fizesse contra aquela porta secreta, ela não cedia, como se alguém a tivesse soldado.

A impaciência já se estampava em seu rosto. As veias saltavam do dorso das mãos até os antebraços enquanto esmurrava a porta com toda a força, sem parar nem quando as juntas dos dedos começaram a sangrar de tanto roçar contra o metal duro.

Sanfu reabastecia as lamparinas do túnel a cada sete dias. Aquele era justamente o sétimo, e o óleo que restava era pouco.

As chamas tremeluziam, enfraquecendo visivelmente. Quanto mais escuro ficava o corredor, mais Lu Linyuan perdia o controle das emoções.

Como uma fera enlouquecida, ele cerrava os dentes, sentia as têmporas latejarem e empregava toda a força do corpo para chutar e se atirar contra a porta da câmara.

Aquela fúria prosseguiu por muito tempo, até que as lamparinas do corredor subterrâneo se apagaram uma após outra. Por fim, a última fonte de luz desapareceu e a câmara mergulhou numa escuridão silenciosa.

Silêncio. Um silêncio de morte.

Lu Linyuan ouvia nitidamente sua própria respiração irregular e os batimentos cada vez mais acelerados do coração. Uma sensação conhecida de sufocamento o invadia sem cessar, como se uma mão invisível lhe apertasse a garganta com toda a força, esmagando-lhe o pescoço e impedindo-o de respirar.

Aquela escuridão impenetrável parecia um demônio capaz de sugar a alma e as forças de uma pessoa; drenava até o último vestígio do vigor de Lu Linyuan.

Ele arquejava, o suor escorrendo em torrentes pela testa.

Aquele espaço fechado e escuro era exatamente como o quartinho sombrio em que a imperatriz-viúva o trancava de castigo.

As janelas dos quatro lados eram cobertas com papel opaco. Não se distinguia o dia da noite, e nem um único raio de luz conseguia entrar.

A imperatriz-viúva o prendia à coluna da cabeceira da cama com grossas correntes de ferro, da espessura de pulsos. Ele se encolhia num canto, tremendo a cada instante.

Também já desejara que aquela porta fechada se abrisse. Também ansiara por ver a luz.

Mas, a cada vez que a porta se abria, o que o aguardava era mais uma sessão de espancamento pelas mãos da imperatriz-viúva.

Pouco a pouco, deixara de desejar tanto assim que ela se abrisse.

*Clinc...*

Na outra extremidade da câmara, o Escravo Porco acorrentado pareceu mover o corpo. As correntes que o prendiam rasparam no chão, produzindo um som metálico estridente.

Aquele ruído também fizera parte dos pesadelos de Lu Linyuan quando criança.

Num instante, incontáveis lembranças intoleráveis do passado lhe inundaram a mente como uma corrente de sangue revolto. Era como se tivesse voltado mais de dez anos no tempo, àquele quartinho sombrio que lhe causava um desespero gelado.

O último resquício de força foi arrancado de seu corpo. Ele escorregou pela parede e desabou sentado no chão, mole como um boneco sem sustentação.

Dobrou os joelhos, encolheu-se sobre si mesmo e tapou os ouvidos com força usando as duas mãos.

Começou a tremer, coberto de suor frio, com os dentes batendo. Parecia uma criança apavorada; toda a majestade imperial que costumava exibir havia desaparecido.

Aos poucos, começou também a ter alucinações.

Sentia pontadas nas têmporas, como se os dedos da imperatriz-viúva, protegidos por longas unhas metálicas, voltassem a cutucá-lo repetidamente, enquanto ela o insultava e o chamava de inútil.

As pontas afiadas perfuravam-lhe a pele. O sangue brotava e escorria pelo contorno definido do maxilar, pingando sobre o dorso da mão.

*Ploc.*

Quente.

Ardendo de tão quente.

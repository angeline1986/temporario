# Validação do capítulo 118

- Fonte primária: `novel_capitulos_61_a_120(20261103-205857).docx`, chinês tradicional.
- Limites no DOCX: índices de parágrafo 4177 a 4252 (zero-based, inclusivo), até antes do título do capítulo seguinte.
- Unidades não vazias (incluindo título): **73**.
- Linhas do CSV: **73**.
- Índices ausentes e traduções em branco: **0**.
- Observações editoriais: A brincadeira 屎到淋頭 / 攪便 remete a expressões idiomáticas com alteração de caracteres para aludir a fezes; o português preserva o efeito escatológico sem inventar equivalência fonética. 寧答應 é um posto hierárquico distinto de 常在 (Atendente); a tradução corrente como Atendente Ning pode exigir harmonização posterior para um equivalente específico (por exemplo, Respondente). O retrocesso de três minutos não alcança a explosão.
- Metodologia: cotejo estrutural 1:1 e revisão durante a tradução. A igualdade de linhas não é prova de ausência de omissões internas ou erros semânticos; não foi executada uma segunda auditoria independente.

# Validação do capítulo 119

- Fonte primária: `novel_capitulos_61_a_120(20261103-205857).docx`, chinês tradicional.
- Limites no DOCX: índices de parágrafo 4253 a 4322 (zero-based, inclusivo), até antes do título do capítulo seguinte.
- Unidades não vazias (incluindo título): **67**.
- Linhas do CSV: **67**.
- Índices ausentes e traduções em branco: **0**.
- Observações editoriais: A ordem 跪不足一個時辰不許起來 implica ficar de joelhos por pelo menos um shichen (aproximadamente duas horas), embora diálogos se refiram informalmente ao período. O original apresenta o mensageiro 小印子; optou-se por Xiao Yinzi. O aparente pai entre os enviados ocidentais ainda não é confirmação de parentesco, apenas anúncio de Sanfu.
- Metodologia: cotejo estrutural 1:1 e revisão durante a tradução. A igualdade de linhas não é prova de ausência de omissões internas ou erros semânticos; não foi executada uma segunda auditoria independente.

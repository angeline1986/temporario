# Capítulo 119 — Xiaoxiao, encontramos seu pai!

Depois de levar uma bronca de Lu Linyuan, a Concubina Shen ficou apavorada. Ajoelhou-se depressa e disse, tremendo: — E-eu reconheço meu erro. Peço que Vossa Majestade contenha sua ira...

Lu Linyuan respondeu: — Se reconhece seu erro, vá ajoelhar-se lá fora para esfriar a cabeça.

Lá fora, o frio era de congelar os ossos, e uma camada fofa de neve cobria o chão.

Já estava escurecendo. Se ela se ajoelhasse naquele chão, certamente acabaria machucando o corpo.

A Concubina Shen implorou perdão, aterrorizada. Gu Sijin também intercedeu: — Majestade, o frio fica intenso ao cair da noite. Parece até que começou a nevar de novo. A Concubina Shen está vestida com roupas leves. Que tal... perdoá-la desta vez? Ela não fez por mal.

A Consorte Duan aproveitou para fazer um favor sem custo: — É verdade, Majestade. Como é a primeira falta da Concubina Shen, por que não lhe conceder uma oportunidade?

Embora nem a própria Consorte Duan soubesse que falta a Concubina Shen cometera.

Talvez, considerando a posição que Ning Xiaoxiao ocupava agora no coração de Lu Linyuan, até respirar alto demais diante dela já fosse um crime.

Os pedidos de Gu Sijin e da Consorte Duan não serviram de absolutamente nada. Lu Linyuan simplesmente as ignorou e se dirigiu a Ning Xiaoxiao, como se nada tivesse acontecido: — O sabor é excelente. Passe-me o resto.

Graças a Ning Xiaoxiao, ele sempre acabava experimentando coisas novas por acaso.

E, curiosamente, todas as coisas que ela o convencia a provar acabavam lhe agradando.

Ao perceber que ele já estava querendo mais, Ning Xiaoxiao se arrependeu imediatamente do que fizera...

【Só restava aquela metade! Mal dá para eu mesma comer! Por que fui oferecer a ele?!】

【Você já provou, já sabe o gosto! Por que agora ficou viciado?!】

Olhando para o único quarto de durião que ainda estava sobre a mesa, ela sentiu o coração sangrar.

Estendeu a mãozinha e pegou um pedaço pequeno. Mas Lu Linyuan colocou a mão sobre a dela e a fez apanhar todo o durião restante, levando-o à própria boca com a ajuda da mão de Ning Xiaoxiao.

— Ah, mas... — Ning Xiaoxiao teve vontade de estrangulá-lo ali mesmo. — Majestade... comer durião demais provoca calor interno...

— Não importa. Eu não tenho medo. — Enquanto comia, ainda estalou os lábios de propósito diante dela, como se quisesse provocá-la.

Ao terminar, viu que a Concubina Shen continuava ajoelhada no salão e perguntou, impaciente: — Está esperando que eu mande alguém “convidá-la” a sair?

A Concubina Shen deixou escorrer duas lágrimas de humilhação. Diante da firmeza de Lu Linyuan, não teve escolha a não ser agradecer pela ordem recebida, sair e se ajoelhar na neve.

Na história original, a Concubina Shen também não era boa pessoa.

Era tão burra quanto cruel, a primeira do harém a envenenar alguém sem nem se dar ao trabalho de esconder a própria identidade.

Assim, embora Gu Sijin lançasse olhares insistentes para Ning Xiaoxiao, pedindo que dissesse algo em defesa da concubina, ela fingiu não perceber.

Lu Linyuan ordenou que a Concubina Shen permanecesse ajoelhada por uma hora tradicional chinesa, sem se levantar, e voltou ao Palácio Chaoyang para examinar memoriais.

Ajoelhada na neve, com a ponta do nariz vermelha de frio, a Concubina Shen parecia solitária e digna de pena.

Não parava de soluçar, e Gu Sijin sentia o coração apertar ao vê-la.

Sob a varanda, comentou em voz baixa com a Consorte Duan: — Afinal, ela não disse nada demais. Só usou um tom um pouco ríspido. Isso não merece uma punição tão severa. Ficar ajoelhada na neve por uma hora tradicional pode prejudicar seriamente a saúde de uma mulher. Senhora, e se fôssemos pedir clemência ao imperador?

A Consorte Duan não queria se envolver naquela confusão. Arranjou a desculpa de que precisava voltar aos aposentos para conferir as contas a serem entregues à imperatriz no dia seguinte e saiu às pressas.

Ning Xiaoxiao enlaçou o braço de Gu Sijin e sorriu. — Irmã, a neve e o vento estão fortes. Vamos entrar?

Gu Sijin deu alguns passos ao lado dela, mas não parava de olhar para trás, para a fina camada de neve que começava a se acumular nos ombros da Concubina Shen. Por fim, perguntou, com pena: — Podemos pedir a Qiqi que segure um guarda-chuva para ela?

Qiqi hesitou: — Senhora... é uma punição do imperador. Ele ordenou expressamente que a Concubina Shen ficasse sozinha, ajoelhada durante todo o período. Se eu segurar um guarda-chuva para ela, estarei desobedecendo a um decreto imperial...

As criadas e os servos do palácio viviam como quem caminhava sobre o fio de uma lâmina. Não fariam nada que pudesse lhes trazer problemas.

Gu Sijin também não queria colocá-los em perigo. Voltou aos aposentos internos, apanhou um guarda-chuva de papel oleado e se preparou para sair.

Ning Xiaoxiao a deteve: — Irmã, o que pretende fazer? Com todo esse gelo e neve, vai ficar segurando o guarda-chuva pessoalmente? Esqueceu que seu corpo é sensível ao frio? Como vai suportar uma nevasca dessas?

— Posso vestir uma capa grossa. Se precisar, também levo um aquecedor de mãos. Hoje, quando jantamos no palácio da imperatriz, a Concubina Shen conversou muito bem comigo. Fui eu que a convidei para visitar o Palácio Zhongcui. Agora que aconteceu tudo isso, se eu simplesmente a abandonar, não conseguirei ficar em paz com minha consciência.

Ning Xiaoxiao sabia: quando o coração de santa de Gu Sijin entrava em ação, ninguém conseguia fazê-la mudar de ideia.

Mas não queria que ela passasse frio. Por isso, deu pessoalmente uma ordem a Bengbeng:

— Vista-se bem e vá segurar um guarda-chuva para a Concubina Shen.

Bengbeng arregalou os olhos. — Hein? Senhora, mas eu...

— Vá, é só isso. Se o imperador reclamar, assumirei a responsabilidade por você. Estou grávida; ele certamente me concederá alguma consideração.

Foi assim que um guarda-chuva finalmente apareceu sobre a cabeça da Concubina Shen, protegendo-a da neve e do vento.

Gu Sijin comentou, sorrindo, que Ning Xiaoxiao tinha a língua afiada, mas um coração bondoso. Ning, porém, respondeu com seriedade: — Irmã, se continuar sendo boa com todo mundo, no fim quem vai se machucar é você. Entendeu?

Gu Sijin assentiu repetidas vezes. Ning Xiaoxiao, contudo, não sabia se ela realmente levara o conselho a sério.

*

Na manhã seguinte, Ning Xiaoxiao mal havia terminado de se levantar e se lavar quando Xiao Yinzi, servo da comitiva imperial, apareceu arrastando um saco para cumprimentá-la.

Ela encarou o saco com curiosidade. — O que é isso?

Xiao Yinzi abriu-o com um sorriso travesso: lá dentro havia cinco duriões enormes.

Explicou: — Foram guardados no gelo pela despensa de alimentos durante o verão. Só restavam esses cinco. Como Sua Majestade soube que a senhora gosta da fruta, mandou abrir a despensa durante a noite, procurá-los e entregá-los logo cedo.

Ning Xiaoxiao: — ...

Quem é que dá um saco inteiro de duriões de presente?

Além disso, depois de descongelados eles não durariam muito. Será que ele ouviu quando eu disse que durião provoca calor interno e resolveu me mandar essa quantidade toda para me fazer passar mal?

Tsc, tsc... Que perversidade!

Mesmo assim, aceitou sorrindo. — Por favor, agradeça ao imperador por mim e diga que fiquei felicíssima...

Xiao Yinzi respondeu: — Receio que agora não consiga transmitir seu recado. Hoje, enviados dos países ocidentais virão ao palácio para uma audiência. À noite haverá um banquete na Plataforma Tonghua. Sua Majestade estará muito ocupado.

Ao ouvir as palavras “enviados dos países ocidentais”, Ning Xiaoxiao estranhou.

Estrangeiros? Não havia aparecido nenhum estrangeiro na história original, havia?

De onde surgiram esses gringos agora...? Que diabo estava acontecendo...?

Ela se preparava para abrir o documento e ler atentamente os próximos acontecimentos.

Foi então que ouviu, ao longe, a voz animadíssima de Sanfu: — Senhora Ning! Senhora Ning! Ai, que notícia maravilhosa!

Ele chegou diante dela sem fôlego, mas com os olhos brilhando de alegria. — En-encontramos!

— O quê? Calma, senhor Sanfu. Pode falar devagar.

— Seu pai! Encontramos seu pai!

— Meu pai? — Ning Xiaoxiao ficou cheia de pontos de interrogação. — Do que está falando?

Sanfu tropeçava nas próprias palavras de tanta pressa: — Aquele... aquele retrato de um velho de barba branca que o imperador mandou distribuir por toda parte algum tempo atrás? Não era seu pai? Pois descobrimos que ele é justamente um dos enviados dos países ocidentais! Está em audiência com Sua Majestade neste momento. O imperador me mandou vir depressa buscá-la!

Ning Xiaoxiao: — ???

Eu realmente não tenho nem palavras...

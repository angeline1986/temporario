# Validação do capítulo 117

- Fonte primária: `novel_capitulos_61_a_120(20261103-205857).docx`, chinês tradicional.
- Limites no DOCX: índices de parágrafo 4101 a 4176 (zero-based, inclusivo), até antes do título do capítulo seguinte.
- Unidades não vazias (incluindo título): **73**.
- Linhas do CSV: **73**.
- Índices ausentes e traduções em branco: **0**.
- Observações editoriais: O texto usa a metáfora cômica 米田共戰士 (excrementos) e o ciúme do imperador. A menção jingzi na canção foi mantida como transliteração parcial, porque sua referência musical e grafia são eufemísticas no original. O nome 任斷離 aparece aqui com grafia diferente do glossário Ren Duanli (任端禮); manteve-se o nome editorial e assinala-se a divergência.
- Metodologia: cotejo estrutural 1:1 e revisão durante a tradução. A igualdade de linhas não é prova de ausência de omissões internas ou erros semânticos; não foi executada uma segunda auditoria independente.

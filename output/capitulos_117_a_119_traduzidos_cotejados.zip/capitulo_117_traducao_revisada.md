# Capítulo 117 — É proibido cozinhar cocô no palácio

Depois de deixar Ning Xiaoxiao ir embora, Lu Linyuan aos poucos recuperou a calma.

【Será que... fui duro demais com ela agora há pouco?】

【Ela já não sabe cozinhar, e ainda fui arranjar dificuldades de propósito...】

Todo protagonista masculino digno do título precisa ter alguma habilidade para se convencer sozinho de que está apaixonado.

E lá estava ele, começando a fazer seu exame de consciência:

Se perdera a cabeça há pouco, em primeiro lugar fora porque os pensamentos desconexos de Ning Xiaoxiao soavam suspeitosamente como uma ameaça de lhe pôr um par de chifres.

Em segundo, porque agora tinha certeza de que ela não carregava um filho seu na barriga. Tal como ele próprio em outros tempos, o que ela carregava era uma bela... tropa de cocô.

Mas, considerando a relação que os dois tinham naquele momento, ele não possuía motivo algum para ficar aborrecido!

【Ela nem está comigo! O que tenho a ver com quem ela gosta? Não há chifre nenhum que possa pôr na minha cabeça!】

【E é até melhor que não seja um bebê! Caso contrário, ainda teria de criar um filho que nem é meu. Por que estou me comportando como um trouxa?】

Quanto mais pensava, mais apertado sentia o peito. Ideias esquisitas insistiam em saltar-lhe à mente.

Por exemplo: de onde vinham aquela tristeza inexplicável e aquele ciúme sem razão?

Não quis aprofundar a questão.

*

Ao deixar o Palácio Chaoyang, Ning Xiaoxiao não imaginava que a dose de doçura daquele dia ainda teria continuação.

Depois de atravessar o Portão Guanghua, avistou, numa curva do caminho, a pantera de Ren Duanli agachada, balançando a cauda.

Espreitando às escondidas, viu Ren Duanli encurralar o Príncipe Jing contra a parede e acariciar-lhe a cabeça com um olhar cheio de ternura.

O príncipe fez um biquinho e revirou os olhos. Não queria lhe dar atenção e já se preparava para sair quando, sem aviso, Ren Duanli apoiou um braço na parede, bloqueando sua passagem. Dominador, envolveu-o com o corpo e se inclinou para murmurar ao seu ouvido, tão perto que os dois quase roçavam as têmporas.

Mais tarde, o Príncipe Jing fez birra e tentou afastá-lo. A pantera negra, antes quietinha no chão, ergueu-se de repente e soltou um rugido. O príncipe perdeu toda a coragem: saltou para abraçar o pescoço de Ren Duanli e ficou pendurado nele, choramingando.

Ren Duanli abriu um sorriso de pura adoração, passou o braço em torno da cintura dele e o levou embora no colo.

Ning Xiaoxiao estava prestes a surtar de tanto torcer por aquele casal!

O que ela não percebeu foi que, não muito longe atrás de si, outro par de olhos também a observava com intensidade.

Lu Linyuan fora atrás dela para lhe dizer algumas palavras gentis e consolá-la. Afinal, embora a gravidez fosse falsa, depois do desejo feito ao prego mágico ela realmente apresentaria sintomas de gestante, o que não era nada agradável.

Obrigá-la a cozinhar no meio de fumaça e calor, numa situação dessas, parecia até desumano.

Mas quem diria que, ao segui-la, presenciaria aquela cena?

【Então era por isso que saiu correndo feito uma flecha! E ainda disse que tinha pressa de voltar para cozinhar para mim! Está mais para vontade de ver Ren Duanli uma última vez antes que ele deixe o palácio!】

Desferiu um soco violento na muralha ao lado, abrindo um buraco fundo na superfície...

O estrondo acabou atraindo a atenção de Ning Xiaoxiao.

Ela se virou e encontrou Lu Linyuan logo atrás, esmurrando a parede. Ficou perplexa. — Majestade? O senhor...

Com ares orgulhosos, ele tentou interrompê-la: — Não foi nada! Não preciso da sua preocupação!

Só que Ning Xiaoxiao falou depressa demais para frear e acabou completando: — ...por que está destruindo o patrimônio público?

Lu Linyuan: — ???

Percebendo o constrangimento que tomara conta do ar, ela repuxou os lábios e pensou: 【Será que eu deveria perguntar primeiro se ele está bem?】 Então se aproximou, fingindo solicitude, tomou-lhe o braço e fez uma expressão aflita. — Majestade, machucou a mão?

— Estou bem! Cuide da sua vida!

Lu Linyuan arrancou o braço das mãos dela. — Volte ao palácio e vá fazer sua comida!

Dito isso, foi embora bufando de raiva.

Ning Xiaoxiao ficou imóvel por dois segundos e concluiu num murmúrio:

— Será que... ele teve algum ataque repentino de loucura?

*

De volta ao palácio, Ning Xiaoxiao pensou em pedir umas dicas de culinária a Gu Sijin. Ou, melhor ainda, deixar que ela mesma preparasse o jantar, só para enganar Lu Linyuan.

Mas nem Gu Sijin nem a Consorte Duan haviam voltado.

Qiqi explicou: — A Atendente Gu mandou avisar que ela e a Consorte Duan jantariam no palácio da imperatriz e voltariam mais tarde. Também convidaram a senhorita, mas a senhora ainda não tinha chegado. Eu não podia contar que tinha ido com o Príncipe Jing procurar o imperador, ou a Consorte Duan poderia criar caso. Então disse que a senhora estava dormindo e não iria.

De todas as criadas do palácio, Qiqi era a mais próxima de Ning Xiaoxiao.

Depois que Ning recebeu um posto no harém, dissera várias vezes à moça que parasse com aquela formalidade de chamá-la de senhora e referir-se a si mesma como serva. Soava distante demais.

Mas Qiqi obedecia rigorosamente à hierarquia e não se atrevia a ultrapassar os limites. Era mesmo uma moça que conhecia as regras.

Sem ninguém para ajudar, Ning Xiaoxiao precisou se virar sozinha.

Em toda a sua vida, a única coisa que cozinhara sem errar provavelmente fora pizza.

Mesmo sem forno, dava para fazê-la numa frigideira. Bastava controlar o fogo.

Lu Linyuan já provaria de tudo quanto era iguaria palaciana, mas pizza ele certamente nunca comera!

Mãos à obra!

Os ingredientes eram fáceis de conseguir, e ainda sobrara queijo ralado daquele que ela comprara com os cabelos do tirano azarado. Só não gostava muito de pizza de carne moída: se o preparo fosse malfeito, o cheiro forte da carne tomava conta.

Resolveu, então, fazer uma pizza de frutas com queijo.

Por coincidência, quando fora promovida, recebera presentes de todos os palácios.

Alguém lhe enviara dois duriões, que ela até então não tivera coragem de comer, de tanto que os valorizava.

Hoje o maldito imperador é que sairia ganhando.

Preparou os ingredientes, untou a massa com óleo, acomodou-a na frigideira e cobriu tudo com bastante polpa de durião e queijo.

O problema era o calor vindo de um único lado: a parte de baixo podia queimar antes de a parte de cima cozinhar.

Para resolver a dificuldade, aquela grande mente chamada Ning Xiaoxiao pôs outra frigideira por cima da primeira e acendeu fogo em cima e embaixo, inventando seu próprio forno improvisado.

Enquanto cozinhava, nada lhe parecia estranho. Mas, como estava assando durião, aos poucos um cheiro nada amistoso começou a escapar da pequena cozinha do Palácio Zhongcui.

Lu Linyuan chegou ao Palácio Zhongcui dois quartos de hora antes do previsto. Mal entrou, quase caiu para trás com o odor que lhe atingiu o nariz.

Tapando-o com a mão, perguntou a Qiqi, numa expressão de nojo: — A latrina de vocês explodiu? Que cheiro é esse?

Qiqi ficou constrangida. — Majestade... os baldes da latrina foram retirados logo cedo. O cheiro não vem de lá, vem... vem da cozinha...

Lu Linyuan ficou paralisado. — ??? Da cozinha? Por que a cozinha estaria cheirando a... excremento?

— Eu também não sei... Assim que voltou, minha senhora disse que ia cozinhar, entrou na cozinha e trancou a porta. Não deixou ninguém entrar...

Lu Linyuan finalmente achou que tinha entendido tudo.

Ele já ouvira Ning Xiaoxiao cantar mentalmente uma música estranha, cuja letra ainda lembrava muito bem:

【Vou te dar cocô de comer, vou te dar jingzi...】

Achara que fosse brincadeira. Quem imaginaria que ela pretendia levar aquilo a sério?

Que absurdo!

Eu só queria uma refeição feita pelas mãos dela, e agora ela quer me fazer comer merda?!

BUM!

Naquele exato momento, uma explosão violenta veio da direção da pequena cozinha...

# Capítulo 118 — O que você tem a ver com as brincadeiras entre mim e Xiaoxiao?

O “perfume” de durião que impregnava o ar ficou ainda mais intenso. No instante seguinte, Ning Xiaoxiao abriu a porta da cozinha e surgiu em meio a uma nuvem de fumaça, como uma “divindade da maluquice” descendo à terra.

Enquanto cozinhava, achara perfeito seu esquema de uma frigideira em cima da outra. Só que alguma coisa saíra errada e, sabe-se lá por quê, a pizza de durião explodira.

Metade da pizza, misturada ao queijo, fora parar no alto da sua cabecinha. A outra metade ainda estava no prato que segurava...

Tinha o rosto todo preto, como uma gatinha malhada. Ao sair e se deparar com o olhar atônito de Lu Linyuan, parou diante dele, com um ar de dar pena.

— Majestade... buááá! Que susto eu levei!

Correu em direção ao imperador, querendo lamentar a perda de todo o trabalho que tivera.

Mas Lu Linyuan recuou como quem avistasse um fantasma, apontando para ela e batendo o pé. — Para trás! Para trás! Para trás!

É que o cheiro, somado à massa de durião com queijo grudada na cabeça dela, lembrava bastante uma coisa... cocô.

Eu só mandei essa mulher cozinhar para mim! E ela pretende mesmo me fazer comer merda?!

— Por que você está cozinhando... imundícies dentro do palácio?

Ning Xiaoxiao percebeu o mal-entendido e tentou explicar, remexendo a pizza no prato com os hashis:

— Majestade, isso não é... Isso é...

— Não se mexa!

Lu Linyuan a evitava como se fugisse de uma peste. Para um homem com tamanha obsessão por limpeza, aquela mulher era uma calamidade ambulante!

Ele olhou para os fios de queijo grudados na cabeça de Ning Xiaoxiao e para a massa de durião em suas mãos. Chegou ao limite:

— Com merda até a cabeça, e você ainda tem coragem de ficar remexendo nisso?!

— Ning Xiaoxiao! Olha só a que ponto você chegou!

Ning Xiaoxiao: — ...

Estou tão cansada. Às vezes sinto que simplesmente não pertenço a este mundo...

Na verdade, ela saíra da cozinha para apertar Retroceder. A fumaça lá dentro quase a sufocara, e não conseguira se concentrar para abrir o documento em sua mente.

Quem diria que, assim que saísse, daria de cara com Lu Linyuan e ainda perderia tanto tempo discutindo com ele?

Pensou, alarmada: 【Droga! Será que passei do limite de tempo?】

Estalou os dedos imediatamente. O tempo recuou três minutos.

Lu Linyuan recuou como quem avistasse um fantasma, apontando para ela e batendo o pé. — Para trás! Para trás! Para trás!

...

Pronto. Não dava mais para voltar ao momento desejado.

Restou-lhe reunir coragem e tentar explicar. Mas como Lu Linyuan, com sua mania de limpeza no nível máximo, daria ouvidos a uma suposta guerreira do cocô?

Com uma expressão de repulsa, ele acenou para os criados e ordenou: — O que estão esperando? Levem-na para tomar banho! Esfreguem tudo, por dentro e por fora, até ficar limpa!

Qiqi e as outras a levaram para os aposentos internos, esfregando-a de um lado e de outro. Usaram uma porção de essências de flores misturadas até conseguirem tirar dela o cheiro de durião.

Quando saiu do banho, Ning Xiaoxiao esperava levar uma bronca por ter estragado tudo. Mas, assim que deixou os aposentos, foi recebida pelo aroma delicioso de comida.

Olhando melhor, viu Lu Linyuan sentado à mesa diante de oito pratos, uma sopa e um caldo espesso. Eram, além disso, comidas de que ela sempre gostara.

Ele a observou com um restinho de desagrado. — Eu sabia que você não conseguiria preparar nada próprio para consumo humano. Por isso, antes mesmo de vir, mandei a cozinha imperial providenciar o jantar. Se dependesse de você, eu morreria de fome!

Ning Xiaoxiao sorriu, toda aduladora. — Ah, Majestade! Desta vez foi um acidente de verdade! Na próxima oportunidade, preparo alguma coisa para o senhor!

Outra vez?!

Se você ousar cozinhar aquela coisa no palácio de novo, mando cortar sua cabeça!

Só de pensar naquela imundície, Lu Linyuan perdeu o apetite. Ning Xiaoxiao, por outro lado, devorava tudo como se temesse que ele lhe roubasse a comida da boca.

— Coma devagar! Vai acabar morrendo engasgada!

— Hehehe! — De bochechas estufadas, Ning Xiaoxiao sorriu feito boba. — Majestade, a irmã Gu não gosta de coentro. O senhor se esqueceu de avisar a cozinha imperial?

Dos oito pratos sobre a mesa, quase todos continham coentro para realçar o sabor ou enfeitar.

Lu Linyuan não sabia se Gu Sijin gostava de coentro. Sabia apenas que, no mês anterior, quando comera hot pot no Palácio Chaoyang, Ning Xiaoxiao ficara de olho na comida e ele permitira que se juntasse a ele.

Ela jogara no caldo um punhado enorme de coentro, passara-o no molho e engolira tudo de uma vez, deixando Lu Linyuan de queixo caído.

Os gostos dos outros não me dizem respeito. Basta que eu me lembre do que você gosta.

Com expressão fria, ele franziu o cenho. — Se tem comida, coma. Nem durante a refeição essa sua boca consegue ficar quieta?

— Ah... — Ning Xiaoxiao abaixou a cabeça, toda murchinha. A tristeza durou um segundo: logo a comida voltou a atraí-la.

Lu Linyuan observou de soslaio aquela gulosa e, sem que ela percebesse, abriu um sorriso discreto.

Depois do jantar, Ning Xiaoxiao ainda não tinha resolvido a inquietação que a incomodava:

【Não! Preciso explicar direito! O que eu preparei era pizza de durião! Não alguma coisa esquisita!】

【Senão todo mundo vai achar que andei cozinhando cocô dentro do palácio! E a minha reputação, como fica?!】

Falou com toda a seriedade: — Majestade... aquele cheiro era de durião! O senhor conhece durião, não conhece? Só o cheiro é ruim. É uma delícia!

Ele já ouvira o nome. Era uma fruta trazida por estrangeiros ao palácio. Na época, achara que parecia um ouriço e mandara Sanfu distribuí-la entre as concubinas.

Provavelmente alguma delas, depois da promoção de Ning Xiaoxiao, acabara lhe oferecendo a fruta de presente.

— Ainda resta metade! Vou trazer para o senhor experimentar!

Saltitando como uma coelhinha alegre, ela foi aos aposentos buscar a metade restante do durião.

Assim que a colocou sobre a mesa, o cheiro familiar tomou conta do lugar. Lu Linyuan franziu as sobrancelhas, perplexo. — Isso... é comestível? Tem certeza de que não está estragado?

— Claro que é! Majestade, prove só um pouquinho!

Ning Xiaoxiao pegou um pedaço de durião e tentou levá-lo à boca do imperador.

Cada poro do corpo dele parecia gritar uma recusa. Lu Linyuan empregou todas as forças para resistir ao “ataque” de Ning Xiaoxiao.

— Tire isso daqui! Afaste essa coisa! Eu não vou comer!

— Ah, Majestade, experimente! Se não for gostoso, escrevo meu nome ao contrário!

— ??? Você me acha idiota? Qual é a diferença entre escrever “Xiaoxiao” de frente para trás ou de trás para frente?

Enquanto os dois “brigavam como um casal”, Gu Sijin e a Consorte Duan chegaram de volta.

Junto delas vinha também a Concubina Shen.

As três abriram a porta do salão principal e encontraram Ning Xiaoxiao praticamente montada em cima de Lu Linyuan, tentando enfiar algo em sua boca à força.

Gu Sijin perguntou: — Xiaoxiao, o que você está fazendo?

A Consorte Duan sabia ler o ambiente: percebendo que Ning Xiaoxiao estava em alta, ficou de lado, sem dizer palavra.

Já a Concubina Shen não tinha muito juízo. Ao ver a contrariedade no rosto de Lu Linyuan, resolveu invocar sua posição no harém para repreendê-la:

— Atendente Ning! Não seja insolente! Só porque está grávida acha que pode agir sem modos? Sua Majestade é o Filho do Céu! Se ele não quer comer alguma coisa, quem pode obrigá-lo?! Saia já de cima do imperador!

Ning Xiaoxiao levou a bronca e abaixou o rosto. — Ah... Reconheço meu erro.

Ia descer de cima de Lu Linyuan quando a mão grande e firme dele segurou sua cintura e a manteve ali, sem deixá-la escapar.

No instante seguinte, ele próprio pegou o pedaço de durião, respirou fundo, reuniu toda a coragem e o colocou na boca, começando a mastigar.

Mesmo com a expressão sofrida de quem comia algo terrível, manteve a dignidade imperial e lançou um olhar de lado à Concubina Shen:

— Eu e a Atendente Ning estamos só brincando. Que merda você tem a ver com isso? Por que está gritando com ela?

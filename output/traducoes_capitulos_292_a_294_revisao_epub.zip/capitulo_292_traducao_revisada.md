# Capítulo 292 — A Consorte Nobre Imperial impõe respeito

Ning Xiaoxiao desceu rapidamente da Imperatriz, mudou sua expressão e aproximou-se de Lu Linyuan com um sorriso travesso:

"Majestade, eu não bati na Imperatriz. Sou muito gentil; jamais bateria em alguém!"

Lu Linyuan olhou para ela atentamente, sua voz baixa e carregada de raiva: "O que você disse?"

A imperatriz também pensou que Lu Linyuan estivesse furioso. Ajudada pelas criadas a se erguer, com as roupas desalinhadas e o rosto coberto de hematomas, chorou amargamente:

— Foi a Consorte Nobre quem me bateu! Todas as consortes presentes são testemunhas! Majestade, faça justiça por mim!

Ning Xiaoxiao: "Eu... eu não..."

【【Caralho! Será que esse maldito vai ficar bravo comigo por causa da imperatriz? Não pode ser! Será que cansou de dormir numa cama confortável e quer passar uns dias dormindo no chão?】】

"O que você disse?!" O tom de Lu Linyuan se elevou repentinamente, assustando Ning Xiaoxiao.

"Por que você está sendo tão feroz..." Ning Xiaoxiao fez beicinho, seus olhos felinos o encarando com pena, "Vossa Majestade, você... Ai!"

Lu Linyuan deu leves tapinhas na boca dela e depois cutucou a cabeça dela.

— Quantas vezes já lhe disse para não me chamar de Majestade? Será que sua cabeça não tem espaço para mais nada além de me amar?

Ele lhe lançou um olhar de fingido desdém e suspirou, resignado: — Sua bobinha.

As concubinas: "!!!"

Imperatriz: "???"

O gracejo atrevido de Lu Linyuan deixou Ning Xiaoxiao envergonhada. Corando, ela deu um tapinha no peito dele e disse com afetação:

"Ah Yuan, você é tão irritante~"

Após o casal ter causado repulsa descarada e pública à Imperatriz, Lu Linyuan desferiu o golpe final, com o rosto escurecendo ao se dirigir a ela:

— Fui eu quem mandou a Consorte Nobre enviar a Concubina Tong para a morte. Tem alguma objeção?

A imperatriz ficou estupefata.

M-m-mas... tinha sido ela própria quem apunhalara a Concubina Tong até a morte! Como Lu Linyuan ainda conseguia proteger Ning Xiaoxiao?

Será que ele foi enfeitiçado por Ning Xiaoxiao?

"Mas... por que eu não sabia disso?"

— Mas que presunção a sua!

Lu Linyuan ficou furioso, o que assustou tanto a Imperatriz que ela imediatamente se ajoelhou. As outras concubinas também se ajoelharam em uníssono e disseram: "Majestade, por favor, acalme-se."

Lu Linyuan ignorou todas elas e continuou a repreender a imperatriz:

— Desde quando preciso lhe prestar contas do que faço? Já que gosta tanto de se meter onde não é chamada, por que não vai pescar no Mar do Sul?

"Você sabe por que costuma ter dores de cabeça? É porque se preocupa com coisas que não lhe dizem respeito!"

— Para preservar sua saúde, a partir de hoje deixe de administrar os assuntos do harém. Tudo ficará a cargo da Consorte Nobre Imperial.

Ao ouvir aquilo, as pernas da imperatriz cederam e ela desabou, perplexa: — C-Consorte Nobre Imperial?

Lu Linyuan tomou a mão de Ning Xiaoxiao e a ergueu diante da imperatriz: — A partir de hoje, Xiaoxiao será promovida a Consorte Nobre Imperial e administrará o harém em seu lugar.

Ning Xiaoxiao espiou Lu Linyuan de soslaio. Pela enésima vez, achou aquele homem bonito pra caralho!

Ao lado dele, por mais que aprontasse, ele sempre a acolhia com uma tolerância sem limites.

Ela costumava consumir muita positividade tóxica, ouvindo apenas que os homens não são confiáveis e que as mulheres precisam se fortalecer para proporcionar uma sensação de segurança.

Tudo o que ela quer agora é derramar aquela tigela de sopa de galinha tóxica:

Por favor! Ter um namorado imperador com jeito de lobão apaixonado é bom demais!

A Consorte Duan sabia que havia ofendido Ning Xiaoxiao no passado, e agora que a Concubina Tong estava morta, somente a Imperatriz ainda podia controlá-la.

Se até a imperatriz caísse, seus próprios dias de tranquilidade provavelmente estariam contados.

Então ela se preparou e ofereceu seu conselho:

"Vossa Majestade, por favor, reconsidere! O título de Consorte Nobre Imperial é equivalente ao de uma imperatriz secundária. Normalmente, esse título só é estabelecido após a morte da imperatriz."

"Se a Imperatriz ainda estiver viva, estabelecer uma Consorte Nobre Imperial seria uma grande humilhação para ela, Vossa Majestade..."

Lu Linyuan voltou os olhos para ela e advertiu: — Diga mais uma palavra e eu a mandarei imediatamente para o Palácio Frio guardar luto pela falecida Tong!

Sua postura era firme; quem ousaria aconselhá-lo?

O salão principal estava completamente silencioso; ninguém ousava fazer barulho.

Foi Gu Sijin a primeira a se inclinar e prestar reverência a Ning Xiaoxiao:

— Esta concubina felicita Vossa Alteza pela promoção a Consorte Nobre Imperial. Sua virtude está à altura do cargo, e sua maneira de governar é exemplar. Que Vossa Alteza tenha sempre paz e prosperidade!

Assim que ela terminou de falar, as concubinas se juntaram para bajular Ning Xiaoxiao, dizendo em uníssono:

— Que a Consorte Nobre Imperial tenha paz e prosperidade!

Vendo que a situação havia se estabilizado, Lu Linyuan deu um leve peteleco no nariz de Ning Xiaoxiao, em um gesto afetuoso.

— Ainda tenho assuntos da corte a resolver. Vou voltar por enquanto. Quando terminar, posso almoçar no seu palácio?

Ning Xiaoxiao mostrou a língua para ele em tom de brincadeira: "Então, Ah Yuan, venha cedo. Eu não comi nada hoje de manhã, então com certeza estarei com fome logo ao meio-dia."

— Sua gulosa. — Lu Linyuan beliscou-lhe a bochecha e, antes de partir, acrescentou:

— Cuide do que resta como achar melhor.

Após sua partida, a imperatriz permaneceu ajoelhada no chão, sem conseguir se levantar por um longo tempo.

Então ela percebeu que estava errada, terrivelmente errada!

Ela havia imaginado que, eliminando a Concubina Tong, seria mais fácil lidar com Ning Xiaoxiao.

Mal sabia que Ning Xiaoxiao era ainda mais difícil de enfrentar do que Tong.

Xiangling olhou para a Imperatriz com uma expressão de dor e aconselhou: "Majestade, por favor, levante-se. Vou chamar o médico imperial para aplicar um remédio em seus ferimentos."

Com lágrimas nos olhos, Xiangling não suportava ver sua senhora passar por tamanha humilhação.

E daí?

Os servos fiéis àquela mulher desprezível eram também seus maiores inimigos.

Se Xiangling tivesse um mínimo de retidão, não passaria os dias arquitetando maldades para a própria senhora.

Xiangling acabara de ajudar a Imperatriz a se levantar quando Ning Xiaoxiao disse com voz fria:

— Como acabei de dizer, se alguém ousasse tocar em mim com um único dedo, eu a condenaria à morte por lingchi, o suplício dos mil cortes.

Enquanto falava, seu olhar penetrante fixou-se em Xiangling:

— Você não só me tocou como me empurrou. O imperador me confiou a administração do harém; preciso impor respeito. (Espalhem por aí que foi Ning Xiaoxiao quem inventou o WeChat!)

Ela elevou a voz e perguntou às concubinas: "Minhas palavras são lei. Alguma de vocês tem alguma objeção?"

As demais consortes responderam depressa: — Não há nada de errado com as ações de Vossa Alteza. Nós as acatamos!

— Ótimo. Se prometi uma execução por mil cortes, é isso que farei. Usar uma criada como exemplo para manter a paz no harém é até uma contribuição sua.

A chamada morte por mil cortes, em termos leigos, é "fatiar mil vezes". O carrasco cortava a carne da vítima pedaço por pedaço, evitando órgãos vitais, até que a vítima sangrasse até a morte devido aos ferimentos.

Na dinastia Qi, essa era uma forma de tortura mais cruel do que ser despedaçado por cinco cavalos.

As pernas de Xiangling fraquejaram de pavor, enquanto os guardas encarregados de detê-la já se aproximavam.

— Imperatriz, salve-me! Minha senhora, salve esta criada!

Ela era uma serva nascida na casa da família da imperatriz, a quem servia com extrema lealdade. No passado, aconselhara sua senhora em inúmeras tramas cruéis contra terceiros.

A imperatriz a protegeu, com voz feroz: "Quem se atreve! Ela é a governanta do meu palácio! Quem se atreve a executá-la?"

Ning Xiaoxiao deu uma risadinha e olhou para a Imperatriz, erguendo levemente uma sobrancelha. "Você não disse que eu era louca? O que uma louca não ousaria fazer?"

Assim que terminou de falar, Ning Xiaoxiao ergueu a voz e ordenou: — Comecem!

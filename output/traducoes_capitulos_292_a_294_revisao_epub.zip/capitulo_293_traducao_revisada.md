# Capítulo 293 — Venha morar comigo para facilitar as coisas

— Imperatriz, salve-me!

Xiangling foi arrastada para fora pelos eunucos, e ninguém deu atenção às tentativas da Imperatriz de impedi-la.

A imperatriz saiu correndo atrás deles, tropeçou e caiu ao chão, chorando até perder a voz.

Ao ver aquela figura lastimável, Ning Xiaoxiao fingiu não suportar a cena: — Esperem. Deixem-na aqui.

— Esta serva agradece à Consorte Nobre Imperial...

— Deixem-na aqui e executem-na no Palácio Fengluan. Façam a imperatriz assistir à morte dela.

— Hoje, a imperatriz desafiou um decreto imperial e a autoridade do soberano. Peço que observe atentamente como Xiangling será executada pelo suplício dos mil cortes.

— Depois escreva para mim uma redação de dois mil caracteres relatando o que viu. Quero saber se entendeu onde errou.

Ao ouvirem isso, quase todas as concubinas soltaram um suspiro de choque.

Antes, a Concubina Tong era abertamente perversa e a imperatriz, traiçoeira. Mas jamais tinham visto alguém agir com tanta severidade quanto Ning Xiaoxiao.

A imperatriz amaldiçoou Ning Xiaoxiao, desejando-lhe uma morte horrível, mas Ning não lhe deu atenção; tomou Gu Sijin pela mão e foi embora.

*

Durante a execução de Xiangling por mil cortes, a imperatriz foi obrigada a assistir.

Ela assistiu apenas por um curto período antes de desmaiar com a cena horrível.

Quando ela acordou novamente, Xiangling já havia sido arrastada para fora do palácio e enterrada.

Ela odiava Ning Xiaoxiao, mas naquele momento, sentia mais medo do que ódio.

Se as coisas continuassem assim, Ning Xiaoxiao seguiria desfrutando do favor imperial; caso viesse a gerar um herdeiro, cedo ou tarde poderia tomar seu lugar.

Ao pensar nisso, a Imperatriz não conseguiu mais ficar parada.

Naquela noite, a imperatriz foi ao Palácio Fengluan se queixar à imperatriz-viúva.

Ao ver a Imperatriz Viúva, ela caiu em prantos.

— Imperatriz-viúva, a senhora precisa fazer justiça por mim!

A Imperatriz Viúva entregou-lhe um lenço para enxugar as lágrimas, com a voz embargada pela tristeza: "Soube do que aconteceu durante o dia. O Imperador realmente foi longe demais desta vez."

— A Consorte Nobre Imperial equivale a uma segunda imperatriz. Ao conceder esse título a Ning, Sua Majestade não apenas me humilhou: tirou de mim toda a autoridade! Tenho medo de que um dia ele resolva obrigar-me a ceder meu lugar a Ning Xiaoxiao!

A Imperatriz Viúva pegou em sua mão e a confortou gentilmente:

"Estou ciente deste assunto e encontrarei uma ocasião oportuna para falar bem de você perante o Imperador."

— Não se preocupe. Enquanto eu viver, o posto de imperatriz de Da Qi não cairá nas mãos de outra mulher.

— Planejarei tudo por você. Mas, por ora, evite enfrentá-la diretamente e não entre em conflito com Ning. Entendeu?

Após receber a confirmação da Imperatriz Viúva, a Imperatriz sentiu-se muito mais tranquila.

Após sua partida, Qingzhu perguntou à Imperatriz Viúva: "Imperatriz Viúva... A Consorte Ning foi promovida ao posto de Consorte Nobre Imperial e, como é costume, veio esta tarde prestar suas homenagens e expressar sua gratidão. Notei que a Imperatriz Viúva pareceu gostar muito dela? Isso..."

A Imperatriz Viúva disse calmamente:

"Não tenho qualquer influência sobre quem o Imperador prefere, nem me importo. Sempre apoiei a Imperatriz porque a família da Imperatriz e a minha família estão unidas e podem resistir ao poder do clã Tong."

"Agora que a família Tong se foi, as famílias Guo e Zhu estão em pé de igualdade, e nenhuma consegue levar vantagem."

— O imperador pode não gostar da imperatriz, mas ela continua sendo a esposa principal. Não importa qual mulher lhe dê filhos: no futuro, ela se tornará a imperatriz-viúva, mãe legítima do soberano. Quantos anos ainda me restam? Se um dia eu morrer, quem garante que ela não fará o mesmo que faço hoje: tudo para favorecer sua família de origem?

Qingzhu compreendeu, de forma geral, o significado das palavras da Imperatriz Viúva.

Tudo o que a Imperatriz Viúva fez sempre foi em prol de sua família materna.

Se Ning Xiaoxiao derrotasse a imperatriz e a removesse do trono consorte, não seria ela quem se tornaria imperatriz-viúva no futuro.

Ning Xiaoxiao não contava com uma família de origem poderosa. Mesmo que se tornasse imperatriz ou imperatriz-viúva, não teria motivo para destruir a família Guo a fim de fortalecer parentes.

Qingzhu: "A Imperatriz Viúva é meticulosa; os planos da Imperatriz não têm onde se esconder debaixo do seu nariz."

A Imperatriz Viúva balançou a cabeça e zombou: "As mulheres deste harém se reúnem por lucro e se dispersam quando o lucro acaba. Já vi muitas delas. Ela me serve com tanta atenção hoje, mas amanhã pode se aproveitar da minha doença para me matar."

"Na verdade, quem é a imperatriz não importa. O importante é que ninguém possa afetar os verdadeiros interesses da família Guo."

"Quanto às queixas que ela sofreu? Ha, não me interessa."

❤

Ao cair da noite, Lu Linyuan, que estivera ocupado o dia todo, sentou-se com Ning Xiaoxiao na varanda, observando as estrelas.

Ning Xiaoxiao recostou a cabeça no ombro dele. O aroma de magnólia em seus cabelos negros despertou em Lu Linyuan uma vontade irresistível de se aproximar.

Ele acariciou os cabelos dela e lhe deu um leve beijo na testa.

Ning Xiaoxiao aconchegou-se em seus braços, aninhando-se contra ele como um gatinho:

"Assim que Sijin deixar o palácio, ficarei morando sozinha no Palácio Fengyi... Acho que será muito frio e solitário..."

— Você não ficará sozinha. — Lu Linyuan interrompeu-a, acariciando-lhe de leve a clavícula com a mão que pousara em seu ombro.

"Depois que ela fingir a própria morte e deixar o palácio, você se mudará para o Palácio Chaoyang e viverá comigo."

A verdadeira intenção de Ning Xiaoxiao não era ter medo da solidão.

Depois que Gu Sijin partisse, ainda teria Qiqi, Qiaqia, Bengbeng e Lala para jogar mahjong, dou dizhu ou, em último caso, algum jogo de mistério e assassinato.

Ela é o tipo de pessoa que não consegue ficar parada e adora causar alvoroço, como ela poderia se deixar ficar entediada?

Ela disse isso simplesmente porque queria sair do palácio com mais frequência, para se encontrar e conversar com Gu Sijin com mais frequência.

— Mas Ah Yuan precisa comparecer às audiências da corte e cuidar dos assuntos do governo. Só pode passar metade do dia comigo.

— Isso é fácil. Daqui para a frente, posso levá-la comigo às audiências da corte.

Ele ergueu o queixo de Ning Xiaoxiao e deu-lhe um sorriso malicioso: "Além disso, não é como se você nunca tivesse passado por isso antes."

Ele se inclinou para mais perto de Ning Xiaoxiao, esfregando o nariz no dela, com a voz baixa e sedutora:

— Acabei de me lembrar de uma coisa. Quando você se escondeu sob a mesa e ficou tão pertinho do meu precioso amiguinho... não lhe ocorreu nenhuma ideia?

Ning Xiaoxiao: “???”

Ela empurrou Lu Linyuan e disse: "Você está doente da cabeça?"

Lu Linyuan não estava envergonhado, mas sim orgulhoso, e seu sorriso malicioso tornou-se ainda mais evidente:

— Eu estava, sim. Naquela hora, já estava.

Ele tomou a mão delicada de Ning Xiaoxiao e a colocou atrás do próprio pescoço:

"Principalmente quando você se assusta com uma barata e pula para se pendurar no meu pescoço."

Antes que Ning Xiaoxiao pudesse chamá-lo de galã cafona e oleoso, como um magnata do Sudeste Asiático, ele a puxou para perto, beijou-lhe a testa e murmurou:

"Está na hora de comer."

"Não acabamos de comer? Você está com fome de novo?"

Lu Linyuan deu uma risadinha: "Eu não estava falando de comida."

Em seguida, ele pegou sua jovem esposa no colo e a carregou em seus braços, deixando-a se debater timidamente e com afetação em seu abraço.

Ao entrarem nos aposentos, ele fechou a porta com a ponta do pé e caminhou direto para a cama.

Ning Xiaoxiao deu um tapinha no peito, apontou para as velas sobre a mesa e disse docemente: "Você ainda não apagou as velas..."

Lu Linyuan olhou na direção que ela apontava e, como se não a tivesse ouvido, atirou o gatinho na cama.

— Não vou apagar.

— Quero olhar para você.

# Capítulo 294 — Majestade, por que está passando cocô no próprio corpo...?

Quando o imperador se recolhia para dormir, um criado do palácio precisava permanecer de vigília com uma lamparina acesa.

Originalmente, essa tarefa era realizada por Sanfu, mas nos últimos dois dias foi assumida por Xiao Yinzi.

Quando ele assumiu o lugar de Sanfu, Sanfu lhe deu dois pedaços de algodão.

— Para que o mestre está me dando isso?

"Seu mestre é experiente e não lhe faria mal. Aceite isto; você precisará disso em algum momento desta noite."

Xiao Yinzi não levou suas palavras a sério e casualmente enfiou a bola de algodão na manga.

Pouco depois de Sanfu ter saído, ele ouviu uma comoção vinda de dentro do salão.

......

Depois de um breve silêncio, tirou depressa os chumaços de algodão e enfiou-os nos ouvidos.

❤

Dentro do salão.

Depois de três ou quatro rodadas de intimidade, Ning Xiaoxiao sentiu fome.

Lu Linyuan já havia preparado bolinhas de arroz em vinho doce para a ceia. Estalou os dedos discretamente, sinalizando ao servo de vigia que trouxesse a comida.

Mas estalou os dedos três ou quatro vezes e Xiao Yinzi, do lado de fora, não ouviu nada.

Sem saber o que ele estava fazendo, Ning Xiaoxiao lançou-lhe um olhar como quem observa um completo idiota...

Por fim, Lu Linyuan perdeu a paciência, abriu a porta e quase matou de susto Xiao Yinzi, que permanecia ali parado, distraído.

Só então ele tirou o algodão e o cumprimentou respeitosamente: "Ó Majestade, este servo merece morrer, este servo merece morrer..."

Lu Linyuan viu o algodão na mão dele e ficou entre o riso e a irritação: — Você não aprende nada de bom com seu mestre, só essas artimanhas. Vá buscar a ceia.

A menstruação de Ning Xiaoxiao ainda demoraria alguns dias, por isso ela podia consumir um pouco de bebida alcoólica.

As bolinhas de arroz eram preparadas com vinho de ameixa, pouco alcoólico e muito perfumado, perfeito para sobremesas.

Lu Linyuan não gosta de doces, mas para atender às preferências de Ning Xiaoxiao, ele sempre come com ela.

Depois da ceia, os dois bochecharam água de hortelã, apagaram as luzes e voltaram a se deitar na cama.

Lu Linyuan não estava com sono nenhum.

As velas no salão estavam apagadas. Ele jazia de lado, seus olhos escuros e brilhantes fixos em Ning Xiaoxiao, seu sorriso como o de um tolo apaixonado.

Ning Xiaoxiao segurou sua grande mão e a repousou sob sua pequena cabeça, um leve aroma de gardênias chegando às suas narinas.

De repente, ela percebeu que o perfume de Lu Linyuan havia mudado.

Ele costumava ficar imerso no doce aroma da terra misturado com o cheiro da madeira.

O cheiro era um tanto semelhante a uma mistura de tabaco moderno e sândalo, e era um pouco pungente.

Naquela época, Ning Xiaoxiao brincou com Gu Sijin: "Eu me pergunto que tipo de cheiro o Imperador tem. Parece madeira mofada com dois cogumelos mofados brotando do topo..."

Ao ouvir isso, Gu Sijin imediatamente cobriu a boca com as mãos: "Não diga bobagens. Isso é âmbar-gris, que vem de uma besta gigante do Mar do Leste. É extremamente precioso e tem uma fragrância rara. Somente o Imperador está qualificado para usá-lo."

Os antigos o elogiavam aos céus, mas sempre que Ning Xiaoxiao imaginava que o tal âmbar-gris era, na verdade, excremento de baleia, ela inexplicavelmente sentia náuseas...

Socorro! Por que alguém se sujaria de fezes?!

Desde então, sempre que via Lu Linyuan e sentia aquele cheiro, tinha uma leve ânsia de vômito.

De tanto sentir aquela ânsia, acabou se acostumando.

No entanto, ela não conseguia se lembrar exatamente quando Lu Linyuan parou de usar as especiarias que representavam a autoridade imperial.

Então ela perguntou, curiosa: "Parece que faz muito tempo que não sinto o cheiro de âmbar-gris em Ah Yuan. Lembro que você adorava usá-lo."

O homem estendeu a mão que ela usava como travesseiro, passou o braço em volta do ombro magro dela e a puxou para um abraço.

Quanto mais se aproximava dele, mais intensa ficava a delicada fragrância floral.

Os aromas florais são geralmente usados por mulheres, mas as fragrâncias foram tão bem combinadas que não tinham a doçura enjoativa frequentemente associada ao público feminino. Em vez disso, possuíam uma qualidade refrescante que complementava perfeitamente seu comportamento frio e distante.

Sua voz estava repleta de seu carinho habitual: "Toda vez que uso esse perfume, Xiaoxiao não quer chegar perto de mim. Depois de um tempo, percebi pelas suas sobrancelhas franzidas que você não gostava, então simplesmente o troquei."

Ele enrolou uma mecha do cabelo da garota na ponta do dedo e brincou com ela: "De qualquer forma, só estou usando perfume para te agradar, então usarei o que você quiser."

O coração de Ning Xiaoxiao quase se derreteu com suas poucas palavras.

Ela se aproximou, feliz, deixando-se envolver pelo aroma suave que o calor do corpo do homem amado fazia desprender.

Ele sempre dava um jeito de fazê-la se sentir segura de diversas maneiras. Ning Xiaoxiao pensou que, se o encontrasse nos tempos modernos, ele seria o tipo de homem em quem ela poderia confiar tanto que nunca precisaria checar o celular dele.

Ela não precisava se preocupar de jeito nenhum com ele a traindo ou fazendo sexo bêbado, e depois ligando desesperadamente para ela chorando e dizendo:

Xiao Bao, Xiao Bao, Xiao Bao, eu errei, por favor, volte. Eu não consegui me controlar, falei contra a minha vontade, eu não tinha forças para me controlar...

É maravilhoso ser escolhido por alguém e amado de todo o coração.

Ela se aninhou nos braços de Lu Linyuan, a sonolência a envolvendo, e murmurou baixinho como um gatinho adormecido:

— Ah Yuan, durma logo. Amanhã ainda precisa comparecer à corte.

Lu Linyuan respondeu-lhe, e só depois que a respiração dela se tornou sonolenta é que ele suspirou, impotente.

Para ser sincero, ele sempre gostou muito do cheiro de âmbar-gris.

Ele sentia que o perfume possuía uma aura dominadora inata; o aroma chegava antes da pessoa, dando aos outros uma sensação avassaladora de opressão em termos de presença.

Mas quando ouviu os pensamentos de Ning Xiaoxiao e descobriu que a origem daquela suposta aura de imponência era, na verdade, um cheiro de cocô, quase passou mal...

Caramba!

Porra! Se aquele maldito grande erudito tivesse lhe contado que aquilo vinha de excrementos de baleia, jamais teria passado os dias se banhando naquele cheiro até ficar impregnado!

No entanto, agora que o aroma foi alterado para a fragrância de gardênia que Ning Xiaoxiao gosta, ele gradualmente descobriu os benefícios desse perfume.

Pelo menos, a fragrância de gardênia atraía a pequena esposa para seus braços todas as noites, como erva-de-gato atraindo uma gatinha.

Pensando nisso, ele sorriu presunçosamente e deu um leve beijo na testa da garota antes de adormecerem nos braços um do outro.

*

Ning Xiaoxiao fora promovida a Consorte Nobre Imperial. Sua cerimônia de investidura foi marcada para o décimo terceiro dia do segundo mês lunar, a data mais auspiciosa dos dois meses seguintes.

Como a dinastia ainda não tivera nenhuma Consorte Nobre Imperial, as vestes cerimoniais, os adornos de jade e as joias precisariam ser feitos especialmente para ela.

Com o tempo se esgotando e a tarefa árdua, os funcionários do Departamento da Casa Imperial, da Oficina Imperial e da Oficina de Bordados em Seda têm trabalhado ininterruptamente nos últimos dias, sem ousar diminuir o ritmo nem um pouco por causa da amada do imperador.

O caso entre Ah Huan, a governanta da oficina de bordados de seda, e Sanfu havia se tornado um segredo aberto em todo o palácio.

Nos últimos dias, Ah Huan trabalhava tanto para terminar as vestes que dormia no máximo dois shichen — cerca de quatro horas — por dia. Sanfu ficava preocupado com ela.

Por isso, ele frequentemente trazia sopas nutritivas para Ah Huan e a massageava para aliviar seu cansaço em seu tempo livre.

Quando Sanfu foi visitá-la naquele dia, viu Xia Guo, criada da imperatriz, saindo dos aposentos de Ah Huan...

# Validação — capítulo 293

- Fonte chinesa: `novel_capitulos_271_a_300(20261106-202946).docx`.
- Tradução-base: `novel capitulos 271 a 300 - ch.epub`, arquivo `index_split_022.html`.
- Limites do documento (índices base zero, fim exclusivo): 1485–1563.
- Unidades não vazias, incluindo título: **75**.
- Correspondência entre texto chinês e EPUB: 74 parágrafos de corpo para 74 parágrafos de corpo em chinês.
- Unidades com ajustes em relação à versão-base: **32**, contando também padronizações editoriais e alterações de delimitadores.
- Índices dos parágrafos com ajustes: 1, 3, 4, 5, 6, 7, 8, 10, 11, 13, 17, 19, 21, 23, 26, 27, 29, 33, 36, 37, 44, 48, 51, 54, 55, 58, 62, 63, 65, 70, 73, 74. Estes números identificam a ordem das unidades do corpo do capítulo (começando em 1), não o índice global do DOCX.

## Correções e decisões

- Preservados nomes, hierarquia e promoção de Ning Xiaoxiao ao posto de **Consorte Nobre Imperial**.
- Corrigidas inversões de agentes, pronomes, interpretações literais indevidas e trocas de gênero quando identificadas.
- Quando o texto chinês utiliza `【 】` para pensamentos, mantida a distinção entre pensamento e fala.
- Mantidos marcadores, cenas e conteúdo narrativo; o CSV registra cada parágrafo original por seu índice real.
- Capítulos 292–293: corrigidas passagens relativas à morte da Concubina Tong, à punição de Xiangling e às intrigas da imperatriz.
- Capítulo 294: corrigidas alusões sexuais, o humor do âmbar-gris e o sentido das cenas de vigília e da cerimônia de investidura.

## Limites e ressalvas

Realizada revisão semântica **focalizada**, confrontando trechos com o original e corrigindo erros identificados; não constitui segunda auditoria independente integral frase por frase. O cotejo 1:1 registra correspondência estrutural, não garante por si só equivalência semântica plena. O EPUB existente pode conter outras imprecisões não identificadas. A data do capítulo 294 foi expressa como dia do segundo mês lunar, para não confundir com o calendário gregoriano.

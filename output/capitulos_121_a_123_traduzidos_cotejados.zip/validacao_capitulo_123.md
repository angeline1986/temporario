# Validação — capítulo 123

- Fonte primária: `novel_capitulos_121_a_180(20261103-233558).docx`, chinês tradicional.
- Limites: parágrafos DOCX com índice base zero **142 a 208**; próximo título em 209.
- Unidades não vazias, incluindo título: **64**.
- Linhas no CSV: **64**, excluindo cabeçalho.
- Índices duplicados: **0**.
- Campos vazios: **0**.
- Índices ausentes no intervalo de parágrafos não vazios: **0**.
- O separador `*`, quando presente, foi mantido como unidade.

## Questões editoriais

A fala chinesa de Ning sobre a cabeça grande e o pescoço grosso reproduz uma referência cômica idiomática; adaptação busca manter o absurdo. C em “C哭” é eufemismo sexual usado no original, vertido sem suavização automática. Frases em inglês de estrutura propositalmente estranha foram mantidas, com glosas entre parênteses. A atribuição de motivos políticos aos atores pertence à narração ficcional.

## Escopo da verificação

Revisão linguística feita durante a tradução e comparação estrutural integral 1:1. A contagem idêntica de parágrafos não constitui auditoria semântica independente nem garante ausência de omissões dentro de cada parágrafo. O texto foi traduzido do DOCX original, sem antecipar capítulos posteriores.

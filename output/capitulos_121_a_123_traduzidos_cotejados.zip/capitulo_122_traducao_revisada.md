# Capítulo 122 — Tem coragem de xingar o meu homem?!

A sessão de lavagem de cabelo daquele dia foi o paraíso de Ning Xiaoxiao e o inferno de Lu Linyuan.

Ela esfregava sem parar o alto da cabeça dele. Só o xampu foi aplicado três vezes; parecia determinada a arrancar cada fio daquela cabeleira negra, sedosa e comprida.

Por sorte, Lu Linyuan era um personagem fictício de aparência perfeita: não importava quanto cabelo perdesse, tudo voltaria a crescer no dia seguinte.

Sem precisar se preocupar em deixar o bonitão careca, Ning Xiaoxiao se entregou alegremente à sua campanha de “depenar o dragão”.

Por fim, Lu Linyuan perdeu a paciência. — Se puxar meu cabelo mais uma vez, mando raspar sua cabeça aqui mesmo e a envio para um convento budista!

Ele só queria dar um pequeno agrado à garota. Quem diria que ela queria devorar um banquete imperial inteiro...?

Se eu deixar você encostar no meu cabelo outra vez, sou um completo idiota!

Depois de arrancar os cabelos de Lu Linyuan, Ning Xiaoxiao escapuliu plenamente satisfeita. A colheita do dia fora farta: o grande trouxa se oferecera espontaneamente, e ela conseguira sessenta fios. Dariam para se empanturrar por um bom tempo.

A caminho de seu palácio, encontrou Xiangling, uma criada da imperatriz.

Com uma caixa de comida nas mãos, Xiangling a chamou de longe: — Dama Ning, um instante.

A imperatriz tinha palavras doces e coração traiçoeiro, além de uma mente cheia de estratagemas. Suas criadas tampouco eram gente fácil de lidar.

Embora estivesse em guarda, Ning Xiaoxiao não deixou transparecer. Respondeu com um sorriso: — Tia Xiangling, aonde vai?

— Que coincidência, não é? — Xiangling ergueu a caixa de comida e sorriu. — A Consorte Yun preparou rolinhos de peônia e os enviou ao Palácio Fengluan. Sua Majestade, a imperatriz, lembrou-se de que, na última visita de cumprimentos, tanto a Atendente Gu quanto a Dama Ning gostaram deles. Por isso, mandou que eu levasse alguns ao Palácio Zhongcui.

Ning Xiaoxiao: — Agradeço à imperatriz. Fico muito feliz.

Ela recebeu a caixa e trocou algumas gentilezas com Xiangling. — Tem feito frio nestes dias, e vejo que a senhora está pouco agasalhada. Não precisa enfrentar o vento para fazer a entrega. Eu mesma levo a caixa ao palácio.

Xiangling agradeceu pela consideração, entregou a caixa e foi embora.

Passadas duas horas — quatro horas modernas —, aproximava-se a hora do banquete.

A imperatriz estava diante do espelho, sendo cuidadosamente arrumada pelas criadas, quando Xiangling entrou com ar preocupado. — Majestade, não houve nenhuma confusão no Palácio Zhongcui...

Os rolinhos de peônia enviados ao palácio não continham nada capaz de matar: apenas um pouco de pó de cróton, suficiente para provocar diarreia.

A intenção da imperatriz era impedir Ning Xiaoxiao de comparecer ao banquete daquela noite.

Mas o fato de ela não ter comido os rolinhos parecia estar dentro do esperado.

A imperatriz comentou, indiferente: — Parece tolinha e desajeitada, mas tem muito mais astúcia e recursos do que Gu Sijin. O imperador faz questão de levar uma mera Dama para receber os ocidentais. Quando ela der à luz um príncipe, inevitavelmente será promovida a concubina de patente superior, talvez até consorte. Aquele Palácio Zhongcui realmente me dá dor de cabeça.

Xiangling: — Mas as normas ancestrais estabelecem que uma mulher de origem servil, mesmo que seja promovida, só pode alcançar o posto de Nobre Dama, sem ascender além dele. O imperador...

— Normas ancestrais? — A imperatriz riu com desprezo e balançou a cabeça. — Essas regras nunca foram capazes de limitar o imperador.

*

Ao cair da noite, três mesas de banquete foram preparadas no Terraço Tonghua.

Ao longo dos anos, a dinastia Qi dera grande importância à cooperação com o Ocidente.

As armas de fogo ocidentais eram muito mais poderosas do que foguetes e bombas de trovão. Antes que Qi dominasse a fabricação de mosquetes, negociar essas armas com os ocidentais era fundamental para fortalecer o reino.

Naquela época, o Ocidente ainda era um território diminuto, com menos de quinhentos mil habitantes. A agricultura e a criação de animais eram pouco desenvolvidas, e a escassez de alimentos era frequente.

Assim, Qi e o Ocidente precisavam um do outro.

Naquele dia, os enviados ocidentais haviam chegado à capital e, segundo os rumores, traziam consigo o próprio príncipe.

Por isso, Lu Linyuan lhes dera todas as honras: o evento seguiria o protocolo de um banquete de Estado, com poucas mulheres do harém e uma presença maior de ministros da corte.

Tudo estava pronto, mas surgiu um contratempo pouco antes da abertura.

O Grande Erudito comera alguma coisa que lhe fizera mal e agora estava preso à latrina, incapaz de sair.

Lu Linyuan mandou Sanfu carregá-lo até ali, mas o eunuco respondeu, aflito: — O Grande Erudito está fazendo uma barulheira de fogos de artifício de Ano-Novo. Se o trouxermos assim, ninguém vai conseguir comer neste banquete...

Não podiam se envergonhar diante dos visitantes estrangeiros. Só que o Grande Erudito era o único na cidade imperial que dominava a língua ocidental.

Sem ele, como negociariam com o príncipe?

Ning Xiaoxiao percebeu a dificuldade, bateu no peito e declarou, confiante: — Não se preocupe, Majestade. Eu falo a língua deles~

— Você? — Lu Linyuan a examinou. — Tem certeza?

— Bem... não sou fluente, mas acho que consigo entender alguma coisa.

Na universidade, ela só havia passado no nível quatro do exame de inglês. Mas, depois de tantos anos assistindo a séries americanas, confiava na própria capacidade de manter uma conversa simples com estrangeiros.

Lu Linyuan sorriu e apertou-lhe a bochecha. — Quando se trata de algo sério, nunca sabe nada. Já essas bobagens, você conhece todas.

Do lado de fora do Terraço Tonghua, ecoou a voz aguda de um eunuco:

— O príncipe ocidental vem prestar suas homenagens~

Os ministros se levantaram para recebê-lo. Só Lu Linyuan permaneceu sentado no lugar de honra, imóvel e imponente.

O jovem branco que se aproximava usava uma coroa incrustada de ouro e trazia o desprezo estampado no rosto.

Um velho de barba branca o seguia respeitosamente. O jovem à frente devia ser o príncipe ocidental.

Tinha olhos azuis, cabelos loiros e cacheados, além de uma túnica larga. Parecia o Harry Potter prestes a sair voando numa vassoura.

Ao chegar diante do estrado, acenou sorrindo para Lu Linyuan, como forma de cumprimento, e disse: — Hello, motherfucker~

Ning Xiaoxiao ficou petrificada...

Que porra era aquela? O sujeito já começava xingando?

O problema é que Lu Linyuan não compreendia a língua ocidental. Só sabia que “hello” significava “olá”, então achou que o visitante o saudava calorosamente.

O Grande Erudito lhe ensinara uma fórmula universal para responder aos cumprimentos dos estrangeiros.

Assim, ele disse com toda a confiança: — Hi, I'm fine, think you, and you?

Ning Xiaoxiao: — ???

Fine uma ova! Você faz ideia do que esse sujeito acabou de falar?!

Aproveitando a ausência do Grande Erudito e convencido de que ninguém entendia inglês, o príncipe decidiu zombar de Lu Linyuan.

Ao ouvir aquela resposta ingênua, soltou uma risadinha desdenhosa e acrescentou: — Stupid. (Ou seja, “idiota”, num tom bastante ofensivo.)

Uma raiva repentina incendiou Ning Xiaoxiao, despertando seu espírito de luta.

【Porra! Esse desgraçado tem coragem de xingar o MEU homem?!】

Ela cutucou o braço de Lu Linyuan, balançou a cabeça para lhe lançar um olhar significativo, levantou-se e fez uma reverência sorridente ao príncipe. — Hello, your mother is boom sha ka la ka. (Sua mãe explodiu.)

O rosto do príncipe escureceu na mesma hora.

Lu Linyuan, porém, continuava absorto naquelas palavras que Ning Xiaoxiao acabara de pensar — “meu homem” —, incapaz de pensar em outra coisa.

# Validação — capítulo 121

- Fonte primária: `novel_capitulos_121_a_180(20261103-233558).docx`, chinês tradicional.
- Limites: parágrafos DOCX com índice base zero **3 a 74**; próximo título em 75.
- Unidades não vazias, incluindo título: **69**.
- Linhas no CSV: **69**, excluindo cabeçalho.
- Índices duplicados: **0**.
- Campos vazios: **0**.
- Índices ausentes no intervalo de parágrafos não vazios: **0**.
- O separador `*`, quando presente, foi mantido como unidade.

## Questões editoriais

Duplo sentido 做雞 (preparar frango / prostituir-se) mantido pela referência a “fazer frango”, mas a ambiguidade não se reproduz plenamente em português. O trocadilho 感動/敢動 (comover-se / ousar mexer-se) foi preservado pelo contexto, sem homofonia literal. 八月十五 é eufemismo para nádegas. A alusão ao quinto príncipe é cultural.

## Escopo da verificação

Revisão linguística feita durante a tradução e comparação estrutural integral 1:1. A contagem idêntica de parágrafos não constitui auditoria semântica independente nem garante ausência de omissões dentro de cada parágrafo. O texto foi traduzido do DOCX original, sem antecipar capítulos posteriores.

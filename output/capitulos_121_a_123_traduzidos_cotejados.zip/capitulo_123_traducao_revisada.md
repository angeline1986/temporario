# Capítulo 123 — Ning Xiaoxiao troca insultos ferozes com o príncipe ocidental

Ning Xiaoxiao e o príncipe ocidental tiveram um encontro bastante “amistoso”, conversando fluentemente na língua dele.

Ninguém presente entendia o que os dois diziam. Só viam o príncipe ficar cada vez mais exaltado, com o rosto e o pescoço vermelhos de fúria.

Enquanto isso, Ning Xiaoxiao mantinha um sorriso tranquilo, proferindo os palavrões mais pesados no tom mais doce do mundo.

Ao vê-la enfrentar o príncipe numa guerra de insultos, Lu Linyuan não resistiu a perguntar baixinho: — O que está dizendo a ele? Parece que o sujeito vai cair duro a qualquer instante.

Ning Xiaoxiao: — Nada demais. Fui cumprimentar respeitosamente os pais dele. Só que, quando perguntei por eles, descobri que ele não tinha nenhum.

Lu Linyuan suspirou ao ouvir aquilo. — Tão jovem e já órfão de pai e mãe... que pena.

Ao perceber que Ning Xiaoxiao entendia a língua ocidental, o príncipe deve ter concluído que já não poderia tirar vantagem com insultos naquela língua. Então falou em chinês desajeitado: — Olá, imperador de Qi. É um prazer conhecê-lo. Espero que possamos aprender um com o outro.

Ning Xiaoxiao: — ???

【Então você sabe falar chinês?! Por que estava bancando o estrangeiro metido a besta comigo?!】

Lu Linyuan comentou: — Não imaginava que o príncipe ocidental falasse a língua han, e com tamanha fluência. Estou impressionado.

O príncipe deu uma risadinha sem graça, mas, depois de se sentar, tornou-se ainda mais arrogante. — Eu falo chinês tão bem, enquanto o imperador não entende uma palavra da língua ocidental. Está claro que, nesse aspecto, Qi fica muito atrás de nós.

Lu Linyuan já ouvira falar da grosseria e arrogância dos ocidentais, que se julgavam superiores a todos por possuírem armamentos avançados.

Mas ele não pretendia tolerar aquele comportamento.

Receber os visitantes com cortesia era a postura de uma grande potência. Se os convidados fossem canalhas mal-educados que rejeitavam a boa vontade, não havia motivo para continuar tratando-os com delicadeza.

Qi importava armas ocidentais e exportava alimentos ao Ocidente.

Sem armas, a capacidade militar de um país diminuía; sem comida, porém, a fome podia matar sua população.

Por esse raciocínio, o Ocidente é que deveria se curvar diante de Qi.

Lu Linyuan sustentou o olhar desafiador do príncipe e sorriu serenamente. — Vejo que o Ocidente se dedica ao estudo do chinês. Parece que querem dominar a língua materna e voltar o quanto antes ao abraço da mãe-pátria. Fico profundamente comovido com tamanha dedicação.

A tensão entre os dois lados subiu num instante, como pólvora prestes a explodir.

O príncipe foi colocado em seu devido lugar e não ousou continuar discutindo. Escondeu o mau humor, dirigiu algumas palavras educadas ao imperador e, em seguida, murmurou mais uns xingamentos em sua própria língua.

Lu Linyuan percebeu o tom e perguntou ao ouvido de Ning Xiaoxiao: — O que ele disse?

Os insultos do príncipe eram tão imundos que mal se podiam repetir em voz alta.

Ning Xiaoxiao pensou: 【Como uma fadinha delicada como eu poderia dizer coisas tão sujas? Se eu repetir os xingamentos daquele cachorro estrangeiro, ele vai ficar furioso do mesmo jeito. Melhor dar uma incrementada artística na tradução, não?】

Então sussurrou: — Ele disse que Vossa Majestade tem a cabeça grande e o pescoço grosso: ou é um otário, ou trabalha de cozinheiro.

— ???

O rosto de Lu Linyuan se fechou, e ele lançou a Ning Xiaoxiao um olhar “ressentido”. — Foi mesmo ele quem disse isso ou você acabou de inventar?

— Foi ele! Por que esta concubina insultaria Vossa Majestade sem motivo? — Ning Xiaoxiao o encarou com absoluta sinceridade, piscando os olhos grandes e úmidos de corça, num misto de inocência e sedução.

Ao observar aquele rosto tão puro e provocante, Lu Linyuan lembrou que ela o xingava às escondidas setenta e duas vezes por dia. Uma ideia começou a se formar em sua mente:

Com essa boca tão suja, mais cedo ou mais tarde vou fazer você chorar enquanto a como.

Quando o banquete começou, as criadas encheram as taças de vinho dos convidados.

No momento do brinde, antes que Lu Linyuan pudesse falar, o príncipe ocidental despejou no chão o vinho de sua taça.

Os ministros se enfureceram, largaram as taças e gritaram:

— O que pensa que está fazendo? Derramar vinho no chão é uma oferenda aos mortos! O que pretende com isso?!

Muitos ministros estavam reunidos no Terraço Tonghua naquele dia, inclusive diversos oficiais militares.

Diante de tamanha insolência, eles cerraram os punhos, prontos para agir, e seus rostos se tornaram ameaçadores.

O príncipe explicou com um sorriso despreocupado: — No Ocidente, cremos no Senhor. Tudo o que comemos e bebemos é uma dádiva divina. Por isso, antes da refeição, oferecemos uma porção ao Senhor. Se esse costume ofendeu seu país, não foi nossa intenção.

Era evidente que ele estava procurando confusão. O Ocidente não apenas enviara diplomatas, como fizera questão de incluir aquele príncipe, claramente para exibir sua força diante de Lu Linyuan.

E havia uma razão para isso.

Três meses antes, chegara ao Ocidente a notícia de que a corte de Qi começara a desenvolver armas de fogo. Naquele mesmo mês, o preço dos alimentos exportados por Qi subira consideravelmente. Era natural que os ocidentais suspeitassem que Qi pretendia descartá-los assim que aprendesse a produzir seus próprios mosquetes e depois se voltar contra eles.

Parecia uma atitude pouco honrosa, mas Lu Linyuan era imperador: sua obrigação era buscar o bem-estar de seus súditos. Quanto a outros países, o fato de não atacá-los já era uma enorme concessão.

Os mosquetes ocidentais eram extremamente poderosos e engenhosamente fabricados. Não seria possível reproduzi-los em pouco tempo.

Portanto, ainda não era hora de romper com o Ocidente.

Foi por isso que Lu Linyuan, apesar de seu temperamento explosivo, não demonstrou grande indignação diante da provocação do príncipe.

Conseguiu até sorrir. — Cada país tem seus costumes. Não vou me ofender com isso.

Segundo o protocolo, depois do brinde coletivo, caberia à imperatriz, como mãe simbólica da nação, brindar pessoalmente ao príncipe ocidental.

A taça dela já estava cheia e ela se preparava para se levantar quando Lu Linyuan a interrompeu: — A imperatriz não precisa se incomodar com o brinde. A Dama Ning o fará em seu lugar.

A imperatriz hesitou, surpresa. A taça oscilou em sua mão, e o vinho frio respingou em seus dedos. Seu coração também gelou.

Pedir que Ning Xiaoxiao a substituísse no brinde significava entregar à jovem uma atribuição da própria imperatriz.

Ela não ousava pensar nas implicações mais profundas do gesto. Limitou-se a fingir um sorriso gentil. — Sim, será como Vossa Majestade desejar. Apenas...

Ainda tinha algo a dizer, mas percebeu que Lu Linyuan nem sequer a olhava. Estava ocupado demais cochichando ao ouvido de Ning Xiaoxiao.

Um lampejo de tristeza e ressentimento atravessou os olhos da imperatriz. Ela apertou os lábios e, percebendo que era melhor ficar calada, desistiu de falar.

O sopro quente de Lu Linyuan tocou a orelha de Ning Xiaoxiao. Com voz suave, ele pediu: — Você tem uma língua venenosa. Faça o favor de xingar alguém por mim.

Ning Xiaoxiao: — Isso foi um elogio, Majestade?

Lu Linyuan sorriu com ternura. — Se você quiser, foi. Vá brindar com aquele cachorro estrangeiro e diga umas “palavras de felicitação” na língua dele.

Ah, xingar os outros era especialidade de Ning Xiaoxiao!

Ela arregaçou as mangas, cheia de disposição. — É só mandar, Majestade! Por qual lado quer que eu comece a ofendê-lo?

Lu Linyuan: — ??? Dá para escolher o ângulo? Quanto mais certeiro e maldoso, melhor, é claro.

Ning Xiaoxiao entendeu o recado, pegou a taça e caminhou até o príncipe ocidental. Então abriu um sorriso encantador e começou:

— Your mom is big pig! (Sua mãe é uma porca enorme!)

— Your dad is puppy! (Seu pai é um cachorrinho!)

Príncipe ocidental: — ???

Ning Xiaoxiao aproveitou a vantagem para continuar:

— You're a bitch! (Você é uma vadia!)

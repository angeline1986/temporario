# Validação — capítulo 122

- Fonte primária: `novel_capitulos_121_a_180(20261103-233558).docx`, chinês tradicional.
- Limites: parágrafos DOCX com índice base zero **75 a 141**; próximo título em 142.
- Unidades não vazias, incluindo título: **64**.
- Linhas no CSV: **64**, excluindo cabeçalho.
- Índices duplicados: **0**.
- Campos vazios: **0**.
- Índices ausentes no intervalo de parágrafos não vazios: **0**.
- O separador `*`, quando presente, foi mantido como unidade.

## Questões editoriais

巴豆 é cróton, laxativo. 時辰 equivale a cerca de duas horas, portanto dois shichen são cerca de quatro horas. O inglês deliberadamente errado, “think you”, foi mantido como erro cômico do imperador. O capítulo original contém a formulação ambígua sobre o príncipe e o velho de barba branca: a descrição subsequente identifica o jovem como príncipe.

## Escopo da verificação

Revisão linguística feita durante a tradução e comparação estrutural integral 1:1. A contagem idêntica de parágrafos não constitui auditoria semântica independente nem garante ausência de omissões dentro de cada parágrafo. O texto foi traduzido do DOCX original, sem antecipar capítulos posteriores.

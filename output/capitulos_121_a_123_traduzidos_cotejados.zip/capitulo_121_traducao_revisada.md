# Capítulo 121 — Não se mexa! Cuidado para não machucar nosso filho

Quando Ning Xiaoxiao entrou no salão principal, Lu Linyuan estava de cabeça baixa, ocupado examinando memoriais.

Ela caminhou de mansinho até diante do estrado e fez uma reverência impecavelmente respeitosa:

— Esta concubina apresenta seus respeitos a Vossa Majestade. Que tenha dez mil bênçãos~

Lu Linyuan fez pose de ocupado e continuou escrevendo sem levantar a cabeça. — E então, como vão as pesquisas sobre fazer frango?

Ning Xiaoxiao: 【Tenho a impressão de que você está me xingando, mas não tenho provas...】

— Respondendo a Vossa Majestade... até que vão bem...

Ao lembrar da cozinha que ela explodira no Palácio Zhongcui, Lu Linyuan morria de medo de que voltasse a cozinhar.

Afinal, recursos não lhes faltavam; perder uma cozinha não era nada demais. O problema seria uma faísca ou respingo de óleo quente queimá-la.

Por isso, engrossou a voz e tentou soar ameaçador:

— Daqui para a frente, fica proibida de fazer frango sem minha permissão!

— ...

O silêncio se prolongou. Só então Lu Linyuan largou o pincel, ergueu a cabeça e examinou Ning Xiaoxiao com interesse.

Ele raramente a encarava daquele jeito, e Ning Xiaoxiao ficou constrangida. — Majestade... o que está olhando?

Lu Linyuan soltou uma risadinha. — Quem diria? Não sabia que você era mestiça.

— Ah, bem...

Ela estava prestes a explicar quando a frase seguinte de Lu Linyuan quase a fez morrer engasgada ali mesmo.

Seus olhos pousaram enfim no baixo-ventre dela, e ele provocou: — Nosso filho certamente será muito bonito quando nascer.

Diante disso, Ning Xiaoxiao ficou sem saída. Só conseguiu sorrir sem graça e concordar com a cabeça.

【Quando é que vou contar para ele que não tem criança nenhuma na minha barriga?】

【Isso não deve contar como crime de enganar o imperador, né? Ele não vai arranjar mais uma desculpa para cortar minha cabeça, vai?】

Havia um traço de pavor por trás do sorriso de Ning Xiaoxiao. Lu Linyuan percebeu e deixou os lábios se curvarem levemente.

Eu não vou mandar cortar sua cabeça.

É muito mais divertido provocar você do que matá-la.

— Venha cá. — Ele estendeu a mão. Assim que os dedos se tocaram, puxou-a com força para o colo.

Os lábios finos dele roçaram a orelha dela. A barba recém-nascida arranhava um pouco e provocava em Ning Xiaoxiao uma sensação de comichão.

Ele soprou de leve sobre a orelha avermelhada, sentiu-a estremecer em seus braços e murmurou, com a voz grave e sedutora: — Eu disse que ajudaria você a encontrar seu pai. Agora que o encontramos, não ficou comovida?

— Eu... eu não me atrevo a me mexer...

Ning Xiaoxiao estava dura feito uma tábua, com as mãos desajeitadamente recolhidas junto ao peito, sem ousar mover um músculo...

Os dois estavam naquele momento de “intimidade” quando Sanfu, sempre desprovido de senso de oportunidade, entrou mais uma vez.

Ao ver os dois agarradinhos no trono do dragão, cobriu instintivamente os olhos — só que deixou os dedos tão abertos que lembrava o quinto príncipe fazendo de conta que não estava vendo nada.

— Majestade... este servo merece morrer! Continue o que estava fazendo! Vou me retirar...

Ele se virou para sair, mas Lu Linyuan apanhou um memorial e o arremessou. O documento atingiu em cheio a panturrilha de Sanfu, que tropeçou e caiu de joelhos.

Comentário de fora de cena: (Sanfu: Então seus memoriais só servem para serem jogados em mim, é isso?)

— Se tem algo a dizer, diga logo.

Ning Xiaoxiao “tentou” escapar de seus braços, mas ele a prendeu ainda mais firmemente e, de repente, mordiscou a cartilagem da orelha dela. — Não se mexa. Cuidado para não machucar nosso filho.

Ning Xiaoxiao: — ...

Ao ver o rosto da jovem em seu colo corado como o céu ao entardecer, Lu Linyuan sorriu, satisfeito.

Ora... como é que eu nunca tinha percebido que mulheres... podiam ser tão divertidas?

Sanfu continuou ajoelhado, com a cabeça bem baixa. — Majestade, o diretor do Departamento de Assuntos Internos quer saber quais mulheres do harém comparecerão ao banquete desta noite para os enviados ocidentais. A imperatriz está incluída; quanto à outra vaga, a imperatriz-viúva deseja que Vossa Majestade escolha uma consorte de posição elevada.

O bom humor de Lu Linyuan desapareceu na mesma hora. — Diga ao Departamento de Assuntos Internos que a Dama Ning comparecerá comigo esta noite.

Sanfu: — Mas... Majestade... e a imperatriz-viúva...?

— Sou o imperador. Minha palavra é um decreto. Diga à imperatriz-viúva que levarei Xiaoxiao ao banquete esta noite. Se isso a desagradar, que engula a insatisfação.

A relação entre Lu Linyuan e a imperatriz-viúva era realmente péssima.

Desde pequeno, ela o submetera a manipulações psicológicas, sempre alegando que fazia tudo pelo bem dele, quando na verdade só cuidava de seus próprios interesses.

Considerando o tipo de mãe que era, permitir que passasse a velhice em paz após sua ascensão ao trono já era uma demonstração extraordinária de devoção filial.

Se nem isso a satisfazia, e ainda pretendia enfiar as garras no harém e controlar sua vida privada, Lu Linyuan não tinha motivo algum para tratá-la com gentileza.

Quanto a Ning Xiaoxiao, ela tampouco era uma vítima sacrificial da disputa, velada e aberta, entre mãe e filho.

Mesmo que Sanfu não tivesse levantado aquela questão, Lu Linyuan já decidira levá-la ao banquete.

O motivo era simples: sabia como ela era gulosa e queria vê-la satisfeita com as delícias servidas na festa.

Mas, quando Ning Xiaoxiao lhe perguntou por que a levaria, aquele teimoso incapaz de admitir o que sentia respondeu de outro jeito.

— O enviado ocidental se parece com seu pai. Isso significa que existe uma afinidade entre vocês. Naturalmente, devo ajudá-los a estreitar ainda mais esses laços de família.

Ning Xiaoxiao: 【Ele deve ter alguma doença muito séria... O Ocidente é os Estados Unidos, não é? Posso dizer que os americanos são uns filhos da puta, certo? Por que eu iria querer ficar ainda mais próxima de uns filhos da puta?】

Ela se desvencilhou do colo dele e ajeitou os fios desalinhados junto às têmporas. — Como teremos um banquete à noite, se Vossa Majestade não precisar de mais nada, vou voltar para me arrumar.

Lu Linyuan assentiu. Ning Xiaoxiao já ia escapar quando viu um fio de cabelo cair da cabeça dele durante o movimento.

Algo tão fino quanto um fio de cabelo era, aos olhos dela, mais precioso do que ouro!

【Tsc... Já caiu mesmo. Se eu não pegar, vou desperdiçar a oportunidade!】

Fingindo surpresa, soltou o cordão do pingente de jade que trazia à cintura e o jogou embaixo da mesa imperial. — Ai! Majestade... meu pingente caiu!

Então se encolheu como uma marmota e mergulhou num instante sob a mesa de Lu Linyuan.

Ao ver as duas bandas do traseiro dela balançando diante de seus olhos, Lu Linyuan achou a cena tão absurda quanto engraçada.

Tudo isso por causa de um fio de cabelo... precisava mesmo?

Ning Xiaoxiao tateou um bom tempo sob a mesa. Quando encontrou o fio, enrolou-o no mindinho e se levantou devagar, abrindo um sorriso bobo para Lu Linyuan. — Hehe~ Achei, Majestade~ Pode continuar trabalhando. Já vou, tá?~

— Pare aí.

— Ah? Mais alguma ordem, Majestade?

Lu Linyuan comentou com a maior naturalidade: — Meu couro cabeludo anda coçando. Peça aos criados que preparem água e venha lavar meu cabelo.

Ning Xiaoxiao levou dois segundos para processar a oferta. Então abriu um sorriso de quem acabara de ganhar na loteria. — Claro, claro! O que eu mais adoro é lavar o cabelo de Vossa Majestade!

Lu Linyuan viu aquele sorriso radiante, como um pequeno sol: tão adorável que parecia nem ter cérebro.

Por isso, estendeu a mão, afagou-lhe a cabecinha e riu, sem conseguir se conter:

— Bobinha.

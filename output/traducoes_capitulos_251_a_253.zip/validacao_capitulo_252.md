# Validação — Capítulo 252

- **Fonte:** `novel_capitulos_212_a_270(20261105-204934).docx`, chinês tradicional.
- **Limites reais do DOCX (base zero):** início 2864; fim exclusivo 2911.
- **Parágrafos não vazios:** 44 (incluindo título e eventuais notas autorais).
- **Linhas do cotejo:** 44; cabeçalho `indice_docx,original_chines,traducao_portugues`.
- **Índices ausentes:** nenhum. **Duplicados:** nenhum. **Traduções vazias:** nenhuma.
- **Correspondência com o Markdown:** uma unidade de tradução para cada linha do cotejo, na ordem original.

## Decisões editoriais

“掉馬” significa ter a identidade revelada. Mantida a diferença entre viagem temporal e entrada num universo literário, entre diretor-geral e diretora-adjunta, e entre Lao Liu (modelo) e Xiao Qi (derivado). As referências a fralda e jargão digital foram vertidas naturalmente.

## Limitações da verificação

O cotejo 1:1 foi verificado por programa contra os índices do DOCX. A tradução foi produzida diretamente a partir do chinês, mas não houve segunda auditoria semântica independente. O alinhamento estrutural não demonstra, por si só, ausência de escolhas tradutórias discutíveis.

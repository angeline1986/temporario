# Capítulo 253 — A família sempre será o seu apoio mais firme

Quem conheceria melhor a filha dela do que a própria mãe?

Desde pequena, Ning Xiaoxiao era exigente. Enquanto outras garotas viviam e morriam por seus ídolos, defendendo seus artistas favoritos com unhas e dentes, bastava ela olhar os astros mais populares do entretenimento para emitir, com absoluta sinceridade, um único veredicto: “Feio”.

No ensino fundamental, os meninos disputavam o lugar ao lado dela. Mas, sempre que se sentava com alguém, sua primeira providência era desenhar uma linha divisória na carteira, como uma fronteira entre reinos rivais: quem a atravessasse seria um canalha.

Na adolescência, como se desenvolveu cedo e passou rapidamente do tamanho B para o C de sutiã, os garotos que eram rejeitados começaram a zombar do corpo dela. Ning Xiaoxiao respondeu aos babacas com socos tão certeiros que os meninos da série inteira fugiam quando a viam.

No ensino médio e na universidade, os pretendentes se multiplicaram. Bilhetinhos e cartas de amor enchiam uma gaveta inteira da casa, sem que ela sequer os abrisse.

Qi Meijuan sempre imaginara que, com padrões tão altos, a filha acabaria solteira para sempre.

Jamais pensara que o romance que não surgira na vida real acabaria florescendo no mundo de um livro.

De certa maneira... a história se parecia um pouco com a própria experiência dela.

— Nas próximas missões, não mande mais minha filha arriscar a vida provocando Xiao Lu. Faça com que ela dê uma lição naquelas mulheres insuportáveis do harém, ou use suas habilidades para ajudar Xiao Lu a resolver os problemas políticos da corte. Minha filha puxou a mim: nós adoramos desmascarar falsas santinhas e colocar manipuladoras em seu devido lugar.

— E não se meta no relacionamento dela com Xiao Lu. Se eu fui capaz de trazer o pai de Xiaoxiao do mundo de um livro para o mundo moderno, também serei capaz de trazer meu genro!

Depois dessas palavras, voltou os olhos penetrantes para Xiao Qi e fez um gesto com o dedo. — Você. Venha cá.

Xiao Qi: — Diretora-adjunta, não vai me bater, vai...?

Qi Meijuan: — Já descontei minha raiva. Pode ficar tranquilo, não vou bater.

Só então Xiao Qi voou hesitante até ela. Mas Qi Meijuan, assim como Ning Xiaoxiao, não tinha o menor compromisso com o jogo limpo.

Assim que se aproximou, ela agarrou-lhe o chifre outra vez e o girou várias vezes no ar, deixando-o tão tonto que até os pedidos de socorro saíram enrolados.

— Estou lhe dando uma última oportunidade. Se tentar me enganar outra vez, seja qual for o motivo, vou apagar você definitivamente. Entendeu?

Qi Meijuan copiara dados de Lao Liu e, a partir deles, criara Xiao Qi.

Mesmo que não fosse exatamente pai nem mãe dele, era, no mínimo, sua criadora e dona.

E Xiao Qi, embora tivesse uma língua atrevida, não era mal-intencionado.

No começo, mandara Ning Xiaoxiao cumprir aquelas missões suicidas diante do tirano simplesmente porque fora manipulado pelo diretor-geral da Agência de Administração do Espaço-Tempo.

Agora estava morrendo de remorso. Como ousaria continuar cometendo os mesmos erros?

Por isso, pediu desculpas a Qi Meijuan com toda a sinceridade, num tom que parecia à beira das lágrimas.

Só então ela soltou seu chifre e beliscou-lhe a bochecha gordinha. — Pronto, não vou bater mais. Proteja Xiaoxiao. Quando ela voltar ao mundo moderno, vou recomendar você para um sistema de nível superior, para trabalhar com verdadeiros viajantes temporais.

Até no universo das viagens entre mundos existia uma hierarquia de prestígio.

Todos os sistemas trabalhavam juntos, mas os demais acompanhavam viajantes no tempo; Xiao Qi era a única exceção.

No expediente, ouvia com frequência os outros sistemas falando dele pelas costas...

Virar sistema de um viajante temporal significava conseguir um cargo efetivo: enfim seria um sistema de respeito.

Ao ouvir a promessa, Xiao Qi ficou radiante, agarrou Qi Meijuan e lhe deu um beijo estalado.

— Muito obrigado, diretora-adjunta! Eu sabia que a senhora era a melhor pessoa do mundo para mim!

— Aaaah!

Antes que Qi Meijuan pudesse afastá-lo, um grito surgiu ali perto.

Quando olhou, viu uma jovem criada que provavelmente viera buscar água da fonte e, por acaso, presenciara aquela cena.

A aparência de Xiao Qi podia ser encantadora, mas como alguém que desconhecesse sua existência não ficaria aterrorizado?

A criada deixou cair o balde, que virou no chão, e gritou: — Aaaaaah! Um fantasma!

Saiu correndo enquanto gritava.

Qi Meijuan lançou a Xiao Qi um olhar irritado. — Viu o que você fez?

Balançou a cabeça e tirou de dentro da roupa um pequeno controle remoto, apontando-o para a criada e apertando o botão.

A moça ficou imóvel por dois segundos, e sua lembrança do episódio foi apagada instantaneamente.

Qi Meijuan aproveitou para transformar Xiao Qi novamente em luz azul e guardá-lo na mão. A criada, confusa com a água recém-buscada que se derramara, avistou-a pelo canto do olho e a cumprimentou animadamente.

— Alteza, príncipe Jing, ainda está aqui? O banquete vai começar logo! É melhor ir se preparar no Terraço Biyun!

Qi Meijuan respondeu sorrindo. A criada resmungou um pouco, pegou o balde vazio e foi buscar mais água.

Pouco depois, Ning Xiaoxiao voltou para procurar a mãe.

Com um sorriso radiante, tomou-lhe a mão: — Mãe, hoje é Ano-Novo! Prepararam um banquete cheio de delícias aqui na estância. Você vai adorar!

Ela ia conduzir Qi Meijuan ao Terraço Biyun, mas a mãe a puxou suavemente de volta e sorriu. — Acho que mamãe não vai poder aproveitar. Só posso ficar um dia neste mundo do livro; preciso ir embora agora.

— O quê? Assim, de repente? — Ning Xiaoxiao ficou desanimada. — Mas você não chegou ontem à noite? Não deveria ter até esta noite para completar um dia inteiro? Não pode sair um pouco mais tarde?

Ela segurou a mão da mãe e começou a fazer manha. Qi Meijuan riu e lhe deu um leve toque no nariz. — De jeito nenhum posso ficar até a noite. Esqueceu o que falei hoje àquele bonitão musculoso?

Ning Xiaoxiao: — Está falando do general Ren?

Qi Meijuan: — Exatamente. Depois de tudo que eu disse, vai saber quanta “força” ele pretende usar com o príncipe Jing esta noite! Se sua mãe ainda estivesse no corpo dele, consegue imaginar a cena?

Ning Xiaoxiao imaginou por um instante e ficou muda.

Nossa... seria mesmo exageradamente picante!

Mas ainda nem passara um dia desde o reencontro. Como Ning Xiaoxiao conseguiria se despedir da mãe tão depressa?

Naquele momento, já não importava que Qi Meijuan estivesse ocupando o corpo de Lu Yiqiu, nem que aquele corpo fosse masculino.

Ela só queria abraçar a mãe. Sabia o quanto os pais haviam se preocupado com sua viagem ao mundo do livro; se ela sentia tanta saudade deles, eles certamente sentiam ainda mais da filha.

Abraçou Qi Meijuan como uma criancinha, reprimindo o aperto no peito para não chorar na frente dela.

— Mãe, aconteça o que acontecer, eu vou voltar para você e para o papai.

— Minha bobinha... — Qi Meijuan acariciou os cabelos longos e sedosos da filha. Seus olhos também ficaram vermelhos, mas ela sorriu.

— Tudo que mamãe deseja é que você seja feliz. Lembre-se: o que quer que decida fazer, seu pai e eu estaremos do seu lado. Enquanto tiver essa família, nunca ficará sem apoio.

Ela recolocou Xiao Qi, que guardava na palma da mão, dentro do corpo da filha. Depois a embalou nos braços enquanto Ning Xiaoxiao se aninhava em seu peito como uma gatinha, e riu dizendo que continuava igual à época em que era pequena, uma criança que nunca crescia.

Mas, na verdade, ela nunca precisaria crescer por completo.

Diante dos pais, não importa quantos anos tenhamos: sempre seremos os filhos que eles mais amam.

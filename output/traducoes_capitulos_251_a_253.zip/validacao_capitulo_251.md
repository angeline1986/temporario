# Validação — Capítulo 251

- **Fonte:** `novel_capitulos_212_a_270(20261105-204934).docx`, chinês tradicional.
- **Limites reais do DOCX (base zero):** início 2786; fim exclusivo 2864.
- **Parágrafos não vazios:** 75 (incluindo título e eventuais notas autorais).
- **Linhas do cotejo:** 75; cabeçalho `indice_docx,original_chines,traducao_portugues`.
- **Índices ausentes:** nenhum. **Duplicados:** nenhum. **Traduções vazias:** nenhuma.
- **Correspondência com o Markdown:** uma unidade de tradução para cada linha do cotejo, na ordem original.

## Decisões editoriais

A fala exageradamente infantilizada de Qi Meijuan e o tratamento “maninho” preservam a comicidade constrangedora. A nota da autora aparece em duas unidades separadas. O comentário sobre “bater algodão” mantém o absurdo da imagem original.

## Limitações da verificação

O cotejo 1:1 foi verificado por programa contra os índices do DOCX. A tradução foi produzida diretamente a partir do chinês, mas não houve segunda auditoria semântica independente. O alinhamento estrutural não demonstra, por si só, ausência de escolhas tradutórias discutíveis.

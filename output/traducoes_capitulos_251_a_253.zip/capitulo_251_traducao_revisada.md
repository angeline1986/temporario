# Capítulo 251 — A mãe de Xiaoxiao flerta com Ren Duanli

Na manhã seguinte, véspera do Ano-Novo, a estância de águas termais estava especialmente movimentada.

Lanternas e enfeites festivos decoravam tudo, por dentro e por fora. Em toda parte reinava o caloroso burburinho da celebração.

Quando Qi Meijuan acordou, Qiqi estava justamente batendo à porta:

— Alteza, príncipe Jing, já acordou?

— O que foi?

Qiqi entrou, seguida por sete ou oito criados.

Eles traziam toda sorte de petiscos típicos da dinastia Qi.

Lu Linyuan mandara Sanfu providenciá-los na noite anterior, com ordens expressas de entregá-los ao príncipe Jing no pavilhão Tingyu logo cedo.

Sua intenção de bajular discretamente a sogra não poderia ser mais evidente.

Mas, ao ver a mesa repleta de petiscos delicados e apetitosos, a primeira preocupação de Qi Meijuan foi saber se a filha recebia tratamento semelhante:

— Sua senhora recebe refeições assim todos os dias?

Qiqi sorriu. — Alteza, está esquecendo? A Consorte Nobre costuma comer à mesa do imperador. Como poderiam servir algo ruim a Sua Majestade?

Só então Qi Meijuan assentiu, tranquila, e começou a experimentar as delícias da dinastia Qi.

Era inegável que os cozinheiros imperiais preparavam pratos de aparência, aroma e sabor impecáveis. Sua filha adorava comer; naquele lugar, certamente não passaria vontade.

Depois do café da manhã, Qi Meijuan decidiu procurar Ning Xiaoxiao, levá-la para passear e, de quebra, cumprir a “missão principal” daquela viagem ao mundo do livro.

Mal saiu dos aposentos, porém, Pixiu se lançou em sua direção e começou a lamber-lhe a palma da mão.

— De onde saiu esse gatão?

Ela não teve medo. Achou Pixiu bonito e estendeu a mão para coçar-lhe o queixo.

— Onde você esteve ontem à noite?

Uma voz fria soou à sua frente. Quando ergueu a cabeça, deparou com o bonitão seminu que, na noite anterior, estava deitado ao lado do príncipe Jing!

Qi Meijuan respondeu casualmente: — Vim conversar com a cunhada imperial.

A expressão de Ren Duanli era gelada. Não dava para saber se estava com ciúme ou interrogando: — E isso significa que pode passar a noite fora?

Ele já tinha feições frias por natureza; quando franzia a testa e elevava a voz, parecia estar dando uma bronca.

— Não voltei, e daí? Precisa ser tão grosso? Um homem desse tamanho e ainda não foi desmamado?

— Você... — Ren Duanli franziu as sobrancelhas. — Lu Yiqiu! Já sarou dos ferimentos no traseiro e está querendo sentir dor de novo?

Era uma provocação íntima entre amantes, mas Qi Meijuan não tinha como entender.

Pensou que Lu Linyuan havia encarregado Ren Duanli de disciplinar o irmão mais novo, inclusive com palmadas.

Ela estava prestes a responder quando Ning Xiaoxiao chegou às pressas.

Bem que sabia! Se deixasse aquela mãe impossível sozinha, alguma confusão iria acontecer!

Ao ver Ren Duanli branco de raiva, puxou Qi Meijuan de lado e sussurrou: — Mãe! Não provoque esse homem. Os dois formam um casal. Se você o irritar, quem vai sofrer depois que você partir é o príncipe Jing...

Os olhos de Qi Meijuan brilharam. Ela examinou Ren Duanli com um sorriso malicioso, daqueles de tia que torce por um casal, e cochichou à filha:

— Ora, ora! Esses jovens andam bem ousados, hein!

— ...

— Deixe comigo. Mamãe vai garantir que tenham uma vida “feliz”!

Ning Xiaoxiao não conseguiu detê-la: Qi Meijuan avançou, tomou a mão de Ren Duanli e começou a balançá-la de um lado para outro.

— Ai, maninho, não fica bravo, vai! Eu errei, tá bom?

Encheu as bochechas, fez biquinho e começou a se derreter: — Não fica zangado comigo, maninho. Não briga comigo, por favorzinho?

— O que deu em você? — Ren Duanli ficou todo arrepiado e soltou a mão. — Comporte-se normalmente!

— Buaaa! O maninho está brigando comigo! Antes ele nunca soltava minha mão! Será que não sou mais seu docinho, seu amorzinho? Buá, buá!

As palavras deixaram Ren Duanli vermelho até as orelhas.

Era verdade que gostava de Lu Yiqiu, mas os dois jamais haviam rompido aquela barreira invisível nem confessado abertamente seus sentimentos.

Agora Lu Yiqiu parecia ter colocado tudo às claras de repente; o coração dele ficou em completo tumulto.

— Você... está chorando mesmo?

Qi Meijuan fazia um escândalo sem derramar uma lágrima sequer. De lábios caídos, repetiu: — O maninho brigou comigo...

Lu Yiqiu também costumava bancar o coitadinho, mas nunca de um jeito tão irresistivelmente adorável.

E, além de tudo, ele me chamou de “maninho”!

Quem seria capaz de resistir?

Ren Duanli se rendeu imediatamente. Com jeito resignado, mas o coração em festa, acariciou a cabeça de Lu Yiqiu. — Não chore. Está bem, a culpa foi minha.

— Então o maninho não pode mais brigar comigo.

— Está bem.

A cada “maninho”, Ren Duanli corava mais. Por fim, alegou ter assuntos a resolver e fugiu todo sem jeito, levando Pixiu consigo.

Observando-o bater em retirada, Qi Meijuan bateu as mãos, satisfeita. — Hã! E eu achando que era algum conquistador irresistível. Garoto é garoto mesmo: basta uma cantada para perder o rumo.

Ela lançou um olhar a Ning Xiaoxiao, que estava atônita diante daquela atuação desavergonhada, e continuou:

— Quando seu pai e eu começamos a namorar, era bem mais exagerado. Mas nós dois estávamos à altura um do outro. Você nem imagina como seu pai sabia jogar esse jogo!

Os olhos de Ning Xiaoxiao se iluminaram. Juntou as mãos, ansiosa: — Conta tudo! Quero ouvir!

Depois disso, mãe e filha passearam pela estância, relembrando muitas histórias divertidas do passado.

Ning Xiaoxiao havia dormido com Lu Linyuan na noite anterior. Era impossível continuar escondendo de Qi Meijuan a relação dos dois.

Assim, depois de ensaiar bastante, reuniu coragem para confessar:

— Mãe, preciso te contar uma coisa, mas não fica brava... Acho que... estou gostando do Xiao Lu...

Qi Meijuan soltou uma risadinha e a examinou como se visse uma criatura rara. — E daí se gosta dele? Se não namorar nessa idade, vai fazer o quê? Ficar batendo algodão?

Ning Xiaoxiao não tinha o otimismo da mãe. — Ah, mãe! Mas... mais cedo ou mais tarde vou voltar ao mundo moderno, para junto de vocês. O que farei quando chegar a hora?

Qi Meijuan ficou em silêncio por um instante e depois acariciou, carinhosamente, a cabeça da filha.

— Quando chegar a hora, a gente dá um jeito. Uma mulher jovem tem mais é que se permitir viver um romance. Senão acaba como eu, presa a vida inteira naquele seu pai de pescoço torto. Quando vê, a vida passou, e dá até uma sensação de desperdício.

Ning Xiaoxiao ia dizer mais alguma coisa, mas Xiao Yinzi apareceu para avisar que Lu Linyuan a chamava para conferir os pratos do banquete de Ano-Novo. Ela disse à mãe: — Vou lá rapidinho. Não saia por aí sozinha; volto já.

Qi Meijuan sorriu, assentiu e tirou a mão da cabeça da filha.

Ao afastá-la, pareceu puxar de dentro do corpo de Ning Xiaoxiao uma coisinha azul-clara, que fechou na palma e escondeu atrás das costas.

— Pode ir tranquila. Acha que vou me perder? Vou passear aqui perto e esperar você.

Depois que Ning Xiaoxiao se afastou, Qi Meijuan caminhou lentamente até um canto deserto e lançou ao ar o objeto azul-claro que apertava na mão.

A luz azul se transformou num pequeno espírito azul com chifres, flutuando no ar. Assim que o viu, o ser tentou fugir, mas Qi Meijuan foi mais rápida e o agarrou por um chifre.

Ela o fitou com um olhar frio e fez uma provocação:

— Xiao Qi, agora que eu cheguei, para onde pensa que vai fugir?

Xiao Qi começou a choramingar: — Aaaaaah! Diretora-adjunta, tenha piedade! Eu... eu nunca mais faço isso!

**Nota da autora:** (Hoje teremos duas atualizações. Estou lapidando o começo do meu novo livro; amanhã serão quatro!)

**Nota da autora:** (Escrever começos dá uma dor de cabeça de arrancar os cabelos! o(╥﹏╥)o)

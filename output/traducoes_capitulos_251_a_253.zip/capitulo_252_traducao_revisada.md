# Capítulo 252 — A verdadeira identidade da mãe de Xiaoxiao vem à tona

A forma física de Xiao Qi no mundo do livro parecia a de um pequeno duende azul com chifres.

Era rechonchudo, vestia uma espécie de cuequinha que parecia em noventa por cento uma fralda, e a barriga balançava feito gelatina quando voava. Até que era bonitinho.

Embora fosse sempre insolente quando conversava com Ning Xiaoxiao, agora, pendurado pelo chifre na mão de Qi Meijuan, estava tão apavorado que seus dentinhos pontudos batiam uns nos outros. Mal ousava abrir os olhos diante daquele olhar cortante.

— Diretora-adjunta, não entorte meu chifre! Vai quebrar! Eu juro, juro, juro que nunca mais faço isso!

— Nunca mais faz o quê? — Qi Meijuan soltou uma risada fria, tirou do peito um maço de folhas A4 e as atirou no rosto dele. — Mandei você cuidar bem da minha filha! Olhe essas missões idiotas que anda distribuindo!

Sua voz tornou-se feroz e ela apertou ainda mais o chifre. — Está cansado de viver?

Xiao Qi arreganhou os dentes de dor. — Aaaaaah! Não é culpa minha! Foi o diretor-geral que mandou passar todas essas missões! Eu... sou apenas um sistema assalariado! Não tive escolha!

— O diretor-geral só chegou ao cargo que ocupa graças às minhas pesquisas. Sem mim, aquele desgraçado não seria coisa nenhuma!

Qi Meijuan soltou Xiao Qi, olhou as folhas A4 espalhadas pelo chão e ordenou: — Recolha.

Cheio de pena de si mesmo, Xiao Qi desceu voando e, com as mãozinhas do tamanho de bolinhas de pingue-pongue, recolheu desajeitadamente uma folha após outra.

Qi Meijuan cruzou os braços e se recostou com displicência no tronco de uma árvore.

— A Agência de Administração do Espaço-Tempo pesquisa sistemas de viagem temporal. A tecnologia só agora está chegando à maturidade. É um projeto nacional altamente sigiloso, destinado exclusivamente ao Estado.

— É preciso selecionar os viajantes temporais com extremo cuidado. Se um deles voltar ao passado e tomar uma decisão equivocada, uma alteração histórica mínima pode fazer desmoronar o mundo em que vivemos.

— Por isso, essa tecnologia não pode ser disponibilizada à população comum. Consequentemente, a Agência não terá lucros expressivos com ela.

— Há vinte e três anos, o diretor-geral me incumbiu de pesquisar a entrada em mundos de livros. Dizia que, diferentemente da viagem temporal, a pessoa apenas experimentaria outra vida dentro de uma história, sem modificar a história real. Caso a tecnologia funcionasse, poderia ser oferecida ao público e render muito dinheiro.

— Como fui a primeira a realizar o avanço técnico, introduzindo ondas cerebrais humanas num supercomputador e transmitindo-as por supercondução até um mundo literário, naturalmente tive de dar o exemplo e ser a primeira a experimentar o processo.

— Só que, depois de entrar no livro, descobri que tudo ali pertence a um universo próprio. Os riscos são incontroláveis. Se alguém morrer naquele mundo, suas ondas cerebrais também serão destruídas; no mundo real, a pessoa ficará em estado vegetativo, sem jamais despertar.

— Havia tantas incertezas e tanto perigo que, quando voltei, recusei continuar a pesquisa e destruí todos os documentos confidenciais.

— Desde então, o diretor-geral vem tentando me obrigar, com ameaças e promessas, a entregar a tecnologia principal e retomar seu desenvolvimento e aperfeiçoamento. Nunca cedi.

Ao chegar a esse ponto, ela cerrou os punhos e golpeou o tronco. Um ovo de pássaro caiu de um galho e se espatifou bem na cabeça de Xiao Qi.

Xiao Qi: — Buaaa...

Qi Meijuan rangeu os dentes. — Jamais imaginei que ele adulteraria meus dados experimentais para mandar minha filha ao mundo do livro, usando-a para me forçar a obedecer!

Enquanto limpava a clara de ovo da cabeça, Xiao Qi tentou consolá-la: — Diretora-adjunta, não fique tão zangada. Xiaoxiao não está até que vivendo bem na dinastia Qi?

— Bem uma ova! — Qi Meijuan lhe deu um tabefe tão forte que o lançou contra uma forquilha na árvore, onde ficou entalado.

— Não me importa que vantagens o diretor-geral tenha lhe prometido para você dar à minha filha essas missões suicidas. Escute com muita atenção!

— Você é um derivado de Lao Liu. Fui eu quem criou você! Sua função é ajudar minha filha a viver bem no mundo do livro, sem ser maltratada por ninguém, e não fazê-la passar o tempo todo aterrorizada com essas missões que desafiam a morte!

Ela fulminou Xiao Qi com o olhar, mas havia lágrimas brilhando no fundo dos olhos.

— Passei vinte e um anos protegendo minha filha como um tesouro, sem suportar vê-la sofrer nem um pouquinho. Quem ousar maltratá-la vai ter que se entender comigo!

Tão assustado ficou Xiao Qi que seu corpo estremeceu... e ele fez xixi de medo.

Por sorte, usava uma fralda. Senão, preso logo acima da cabeça de Qi Meijuan, teria feito xixi nela e acabado torrado ali mesmo!

Puxando as próprias orelhas, choramingou: — Buaaa! Diretora-adjunta, não grite comigo. Sei que errei!

Qi Meijuan o advertiu: — Se tentar explorar minha filha de novo para cumprir suas metas de trabalho, atrapalhar o romance dela ou deixar alguém maltratá-la, vou jogar você diretamente na lixeira de dados e apagá-lo para sempre!

— Não, não, não! Nunca mais! Diretora-adjunta, por favor, não me apague!

Depois de muito se debater, Xiao Qi conseguiu sair da forquilha e voou choramingando até Qi Meijuan, esfregando a cabecinha em seu braço.

— Mas eu também queria o bem de Xiaoxiao... O diretor me disse que, como ela entrara no livro e o protagonista masculino original era um bonitão, seria terrível se ela se apaixonasse por ele. Por isso me mandou propor missões cada vez mais absurdas, para diminuir a simpatia do imperador tirano por Xiaoxiao e impedir que os dois se apaixonassem.

— Além disso, mesmo que o tirano se irritasse, Xiaoxiao tinha habilidades especiais para se proteger; nada de ruim aconteceria.

— Só que eu também não esperava... que eles fossem brincar tanto um com o outro até... até... até o clima esquentar de verdade...

Qi Meijuan o encarou e espetou com o indicador aquela cabeça de textura gelatinosa.

— Será que me esqueci de programar um cérebro quando criei você? Não percebe que aquele idiota do diretor-geral provocou tudo de propósito?

Xiao Qi fez biquinho e baixou a cabeça, como uma criança que acabara de aprontar. — Mas... e agora? Pelo plano original, Xiaoxiao só precisava desviar a trama e ficar discretamente ao lado de Gu Sijin até o final da história. Só que agora ela está com o tirano, então...

Ficou calado por um instante e teve uma ideia súbita. — Já sei! E se eu lançar uma missão para separar os dois?

Qi Meijuan lançou-lhe um olhar glacial, fechou os punhos e estalou as articulações. — Quer apostar que eu desmonto você agora mesmo?

— Aaaaaah! Não, não! Eu errei, eu errei!

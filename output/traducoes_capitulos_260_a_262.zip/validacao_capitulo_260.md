# Validação do capítulo 260

- **Fonte:** `novel_capitulos_212_a_270(20261105-204934).docx` (texto chinês tradicional).
- **Limites no DOCX:** parágrafos de índice 3420 até 3490; cabeçalho do capítulo seguinte excluído.
- **Unidades não vazias:** 68, incluindo o título e eventuais marcadores/notas.
- **Cotejo:** uma linha para cada parágrafo não vazio, com índice real de base zero, sem índice repetido e com os dois campos textuais preenchidos.
- **Integridade estrutural:** 68 unidades em chinês e 68 correspondentes em português; nenhuma omitida no alinhamento.
- **Critério editorial:** tradução integral, conservando os pensamentos, diálogos, hierarquia do harém e diferenças entre intenções, impressões e atos narrados.
- **Limitação:** o teste de estrutura não constitui revisão semântica independente, nem exclui erros de interpretação que exijam outra leitura do original.
- **Decisões:** a metáfora sexual da floresta e da fera foi mantida; a piada com vestuário íntimo preserva o duplo sentido. A imperatriz e a imperatriz-viúva sabem que certas acusações contra Tong Guowei são inventadas.

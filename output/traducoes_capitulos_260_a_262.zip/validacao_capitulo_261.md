# Validação do capítulo 261

- **Fonte:** `novel_capitulos_212_a_270(20261105-204934).docx` (texto chinês tradicional).
- **Limites no DOCX:** parágrafos de índice 3491 até 3567; cabeçalho do capítulo seguinte excluído.
- **Unidades não vazias:** 74, incluindo o título e eventuais marcadores/notas.
- **Cotejo:** uma linha para cada parágrafo não vazio, com índice real de base zero, sem índice repetido e com os dois campos textuais preenchidos.
- **Integridade estrutural:** 74 unidades em chinês e 74 correspondentes em português; nenhuma omitida no alinhamento.
- **Critério editorial:** tradução integral, conservando os pensamentos, diálogos, hierarquia do harém e diferenças entre intenções, impressões e atos narrados.
- **Limitação:** o teste de estrutura não constitui revisão semântica independente, nem exclui erros de interpretação que exijam outra leitura do original.
- **Decisões:** Consorte Nobre é o posto 貴妃 recém-concedido a Ning. A metáfora do espacate contrapõe duas posturas físicas e preserva o exagero cômico do original.

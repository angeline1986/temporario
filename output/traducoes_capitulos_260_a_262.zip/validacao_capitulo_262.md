# Validação do capítulo 262

- **Fonte:** `novel_capitulos_212_a_270(20261105-204934).docx` (texto chinês tradicional).
- **Limites no DOCX:** parágrafos de índice 3568 até 3628; cabeçalho do capítulo seguinte excluído.
- **Unidades não vazias:** 58, incluindo o título e eventuais marcadores/notas.
- **Cotejo:** uma linha para cada parágrafo não vazio, com índice real de base zero, sem índice repetido e com os dois campos textuais preenchidos.
- **Integridade estrutural:** 58 unidades em chinês e 58 correspondentes em português; nenhuma omitida no alinhamento.
- **Critério editorial:** tradução integral, conservando os pensamentos, diálogos, hierarquia do harém e diferenças entre intenções, impressões e atos narrados.
- **Limitação:** o teste de estrutura não constitui revisão semântica independente, nem exclui erros de interpretação que exijam outra leitura do original.
- **Decisões:** o plano da imperatriz é descrito como manipulação anterior; sua omissão e a resposta de Ning não foram confundidas. O termo 聖母 é traduzido como “bancar a santa” no título, referindo-se ao comportamento misericordioso de Gu Sijin, sem conotação religiosa literal.

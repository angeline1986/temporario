# Capítulo 261 — Se eu mandar abrir um espacate, você abre!

Um posto superior bastava para esmagar alguém. No harém, essa regra era igualmente verdadeira.

Embora Gu Sijin estivesse de posse da medalha de imunidade à morte, a Consorte Li apenas a obrigava a se ajoelhar. Além disso, a medalha tinha sido dada por Lu Linyuan a Ning Xiaoxiao; Ning só a deixara provisoriamente sob seus cuidados.

Se a exibisse a qualquer provocação, acabaria criando problemas para Ning Xiaoxiao.

Por isso, ajoelhou-se sem dizer palavra e fixou na Consorte Li um olhar frio e cortante.

A Consorte Li apontou para o nariz dela e começou a insultá-la:

— Sua vadia! É igualzinha à sua mãe vulgar!

— Antes, sua mãe não passava de uma criada que lavava os pés do seu pai. De tanto servi-lo, não sei como conseguiu subir na cama dele. Que mulher sem vergonha!

— Sua mãe adorava roubar o que pertencia aos outros, e você também! Nasceu com essa índole desprezível! Achou que, por ter um rostinho de sedutora, entraria no palácio e ficaria rica e poderosa?

A Consorte Li soltava risadinhas enquanto a humilhava sem piedade. — A antiga criada que a servia não tinha nem sua origem nem sua posição e só usou você como degrau. Agora ela virou Consorte Nobre, e você continua uma simples Nobre Dama. Como pode?

— Se eu fosse você, teria vergonha até de continuar viva. Procuraria uma árvore e bateria a cabeça nela até morrer!

Diante daquela enxurrada de insultos, Gu Sijin não se abalou minimamente.

Antes, se alguém insultasse sua mãe, ela com certeza responderia indignada, chorando enquanto defendia a honra materna.

Mas agora entendia que a forma mais inútil de revidar era tentar se justificar apenas com palavras.

Contemplando a expressão arrogante e autoritária da Consorte Li, uma ideia surgiu de repente em sua mente:

Aquele rosto ficaria lindo se fosse queimado por fogo escaldante e a pele arrancada junto com a carne viva.

*

No terceiro dia do primeiro mês lunar, a comitiva imperial iniciou a viagem de volta.

O grupo partiu da residência das fontes termais ao amanhecer e, após dois dias de viagem, chegou enfim à capital no quinto dia do mês.

A imperatriz reuniu as consortes logo cedo em frente ao Portão Shenwu para recebê-los.

Ao verem a carruagem imperial entrar lentamente no palácio, todas se curvaram em saudação.

— Damos as boas-vindas a Vossa Majestade por seu retorno. Que o imperador desfrute de saúde e bênçãos!

Lu Linyuan desceu da carruagem e assentiu, autorizando-as a se levantar. Então se virou, estendeu a mão e ajudou Ning Xiaoxiao, que havia viajado com ele, a descer.

Ao voltar ao palácio, Ning Xiaoxiao parecia completamente diferente de antes.

Ela vestia os trajes de Consorte Nobre. Os cabelos negros, como uma cascata, estavam presos num penteado elevado e ornamentados com grampos de fênix de ouro puro, de onde pendiam enfeites que cintilavam sob o sol, quase cegando quem os olhava.

Aquilo contrariava as regras.

Nenhuma consorte podia viajar na mesma carruagem do imperador; nem mesmo uma Consorte Nobre tinha permissão de usar grampos de fênix. Mas Lu Linyuan havia concedido a Ning Xiaoxiao precisamente todos esses privilégios proibidos.

E o que as outras consortes poderiam dizer?

Só lhes restava assistir à cena e ranger os dentes de raiva.

Agora que ela era Consorte Nobre, todas as mulheres do harém, exceto a imperatriz, deviam saudá-la com uma reverência.

Assim, mal Lu Linyuan permitiu que elas se levantassem, todas, à exceção da imperatriz, dobraram novamente os joelhos.

— Saudamos a Consorte Nobre! Que Vossa Alteza tenha mil anos de saúde e felicidade!

Lu Linyuan não retirou a mão da cintura de Ning. Ao contrário, apertou-a um pouco mais e a puxou para os braços.

— Vou primeiro ao Palácio Chaoyang encontrar os ministros. Mais tarde, venho buscá-la para jantarmos juntos.

Em seguida, inclinou-se e roçou a ponta de seu nariz na dela, num gesto escandalosamente íntimo.

Ning Xiaoxiao assentiu, corando de timidez. — Então, A-Yuan, venha cedo. Vou esperar por você.

Lu Linyuan concordou e, relutante em deixá-la, entrou no palanquim e partiu.

As consortes ficaram com expressões terríveis. Sobretudo a imperatriz.

Lu Linyuan acabara de usar o simples “eu” ao falar com Ning Xiaoxiao?

E Ning Xiaoxiao nem o chamava de imperador: usava o nome íntimo que antes apenas o imperador falecido ousava pronunciar?

Pela primeira vez, a imperatriz percebeu que aquela Ning Xiaoxiao talvez fosse incomparavelmente mais perigosa que a Concubina Tong.

Entre os olhares repletos de inveja e ódio, somente Gu Sijin contemplava Ning Xiaoxiao com olhos límpidos e emocionados.

Ning Xiaoxiao sorriu, aproximou-se dela e ajudou-a a se erguer da reverência que ainda mantinha.

— Irmã, não nos vemos há um mês. Tem passado bem?

Gu Sijin segurou a mão dela com força, lágrimas nos olhos, e assentiu com os lábios apertados, emocionada demais para dizer qualquer coisa.

Sentira muitas saudades de Xiaoxiao. Vivia pensando se ela comia bem na residência das fontes termais e se estava aquecida. Sabia que Lu Linyuan a tratava como um tesouro e jamais permitiria que lhe faltasse algo.

Mesmo assim, não conseguia deixar de se preocupar. Só ao vê-la com os próprios olhos, sã e salva, pôde finalmente sossegar.

As duas amigas se reencontraram, com a alegria estampada no rosto.

Enquanto isso, as outras consortes continuavam curvadas, e suas pernas já começavam a formigar.

A imperatriz sorriu. — Consorte Nobre, as demais irmãs ainda estão fazendo reverência. Não seria melhor permitir que se levantassem?

Só então Ning Xiaoxiao desviou os olhos de Gu Sijin e examinou friamente as belas mulheres ajoelhadas diante de si. Falou com indolência: — Podem se levantar.

— Agradecemos à Consorte Nobre.

Ning Xiaoxiao manteve o semblante severo, assumiu a postura de sua nova posição e declarou em tom solene:

— Antigamente, eu fazia vista grossa às muitas imundícies deste palácio. Mas agora as coisas mudaram.

— Como o imperador me concedeu autoridade para auxiliar na administração dos seis palácios, não posso negligenciar minhas responsabilidades. Os maus costumes do harém já duram tempo demais. Está na hora de pôr ordem na casa.

Ela caminhou lentamente, lançando um olhar penetrante às mulheres. — Onde está a Consorte Li?

Chamada de surpresa, a Consorte Li sentiu um aperto no peito e deu alguns passos trêmulos para fazer uma reverência diante dela.

— Estou aqui... Quais são as ordens de Vossa Alteza?

— Ajoelhe-se.

A Consorte Li ficou petrificada. — O que quer dizer, Consorte Nobre? Que falta cometi? Peço que Vossa Alteza esclareça.

Ning Xiaoxiao soltou uma risada fria. — Esclareça? Não foi você quem disse à Nobre Dama Gu que, por ser Consorte enquanto ela é Nobre Dama, bastava mandar que ela se ajoelhasse, sem direito a ficar de pé? O quê? Achou que, porque eu estava fora, não saberia das confusões que vocês andavam aprontando no palácio?

— Isso...

Plaft!

Antes que conseguisse se defender, Ning Xiaoxiao lhe deu um tapa violento.

O golpe foi forte o bastante para fazer sangrar o canto da boca da Consorte Li.

Ning Xiaoxiao a repreendeu em voz alta:

— “Isso” o quê? Que falta de modos!

— Eu sou Consorte Nobre, e você é Consorte. Se eu mandar você se ajoelhar, você não fica de pé. Se eu mandar abrir um espacate, não é para fazer uma ponte! Entendeu o que eu disse?

Afinal, a Consorte Li era uma veterana do harém. Antigamente, Ning Xiaoxiao sempre estivera abaixo dela na hierarquia, e Li costumava lhe dar ordens com arrogância.

Agora, com as posições invertidas e Ning Xiaoxiao acima dela, como poderia se adaptar tão depressa?

A Consorte Li apertou a face ardente e encarou Ning Xiaoxiao, com os olhos cheios de revolta.

— A Consorte Nobre age arbitrariamente e me pune sem provas ou justificativa! Não aceito!

— Não aceita? — Ning Xiaoxiao bufou e imediatamente ordenou:

— Guardas! Batam nela! Até aprender a aceitar!

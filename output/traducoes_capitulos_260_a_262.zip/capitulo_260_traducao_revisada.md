# Capítulo 260 — Gu Sijin voltou a ser maltratada

Ela avançou centímetro por centímetro em direção à parte mais perigosa daquela floresta.

Quando estava prestes a enfrentar a fera de frente, a mão grande de Lu Linyuan desceu e segurou seu pulso de uma vez.

— O que você está fazendo?

— Não foi Vossa Majestade quem disse que queria tirar as medidas?

— ...

Lu Linyuan soltou uma risada resignada, com uma expressão que não dava para saber se era de exasperação ou de êxtase.

— Pedi que, quando tivesse tempo, costurasse uma roupa de dormir para mim e medisse com as mãos a largura dos meus ombros e a minha cintura. Onde é que você está pondo a mão?

Hã?

Então tinha sido ela quem entendera tudo errado?

Pois muito bem... Que ele morresse sozinho de velhice!!

Ning Xiaoxiao ficou tão envergonhada que seu rosto corou.

— Mas, se vou fazer uma roupa para dormir, não tenho de fazer também as calças? Você não pode sair por aí com a bunda de fora!

— Ah, é? — Lu Linyuan sorriu maliciosamente, estalou a língua duas vezes e balançou a cabeça.

— Eu estava errado, você tem razão. Pensando bem, a roupa de dormir nem é o que fica mais rente ao corpo. Xiaoxiao é tão inteligente que me faz parecer um idiota.

Ele se aproximou de seu ouvido, roçando com os lábios quentes o lóbulo delicado.

— Achei sua sugestão excelente. Não quero mais a roupa de dormir. Vamos trocar por outra coisa.

Dito isso, agarrou repentinamente o pulso de Ning Xiaoxiao e começou a movê-lo devagar...

❤

Ao amanhecer do dia seguinte.

Cidade Imperial, Palácio Xianshou.

A imperatriz-viúva queimava incenso e orava diante do altar budista quando Qingzhu entrou discretamente e permaneceu ao seu lado.

Ao ouvir o movimento, a imperatriz-viúva pousou as contas de oração e estendeu a mão. Qingzhu ajudou-a a se levantar da almofada macia de penas de ganso e disse baixinho:

— Imperatriz-viúva, aquele sujeito adoeceu de novo.

Ao ouvir isso, o rosto da imperatriz-viúva se contraiu de repulsa. Ela levou a mão ao nariz. — O imperador mandou um enfermiço para me servir? Está esperando que ele me transmita sua doença e me faça morrer logo, para finalmente ficar satisfeito?

— Vossa Majestade exagera. Embora o imperador esteja na residência das fontes termais, preocupa-se muito com a senhora e manda especialidades da região a cada poucos dias. Como sabe que gosta dos doces folhados de leite, até transferiu para o palácio o cozinheiro responsável por prepará-los. Isso mostra sua devoção filial.

— Devoção filial? Humpf! — A imperatriz-viúva soltou uma risada desdenhosa. — Ele faz tudo isso para proteger aquela Ning. Mal saiu do palácio e já a elevou a Consorte Nobre. Agora teme voltar e ouvir minhas reclamações, por isso tenta me agradar de todas as maneiras. Acha que não percebo?

— Ai... Ai...

Do lado de fora, os gemidos de Ying Shuang ecoavam intermitentemente.

Ainda nem tinha cantado o galo, e aquele homem já estava deixando todos irritados.

A imperatriz-viúva disse, impaciente: — Ele grita como um fantasma dia e noite! Ficou louco? Vá! Mande calar a boca dele! Não quero ouvir mais nenhum som!

Qingzhu recebeu a ordem e se retirou. Ao sair do salão, encontrou a imperatriz, que chegava coberta de orvalho e frio da manhã.

A imperatriz entrou e prestou respeitosamente seus cumprimentos. — Que a imperatriz-viúva tenha mil bênçãos.

— Levante-se. Veio tão cedo porque tem boas notícias?

— Meu pai reuniu dezesseis acusações de usurpação de prerrogativas contra Tong Guowei, onze de conluio com ministros estrangeiros, seis de concentração abusiva de poder e interferência no governo, quatro de insubordinação e muitas outras, grandes e pequenas: noventa e três acusações ao todo. Todas configuram crimes gravíssimos, até capitais.

A imperatriz-viúva assentiu satisfeita. — Seu pai trabalha depressa. E você sabe perfeitamente quantas dessas coisas Tong Guowei realmente fez e quantas seu pai inventou do nada. Quando alguém quer condenar outra pessoa, sempre encontra uma acusação.

A imperatriz não negou. — Na verdade, só queremos dar ao imperador uma oportunidade legítima de eliminar Tong Guowei. Não importa quais provas são verdadeiras. Importa que, assim que Tong Guowei der um passo em falso, será desprezado por todos e condenado à morte.

— Faça tudo com cuidado e sem deixar rastros. Não acabem queimados pelo próprio fogo.

— Não se preocupe. Meu pai só ficará encarregado de reunir as provas. Quem as entregará ao imperador será um censor do Tribunal de Fiscalização. Assim que ele retornar ao palácio, daqui a dois dias, Tong Guowei poderá ser denunciado publicamente na corte.

A imperatriz fez uma breve pausa e sorriu de leve. — Se conseguirmos exterminar o clã Tong, o mérito caberá à senhora e à família da minha mãe. Se algo der errado e o resultado for outro, tudo terá sido obra exclusiva de Gu Yanchuan, sem qualquer ligação conosco.

A imperatriz-viúva não acrescentou nada. Limitou-se a assentir discretamente.

*

Quando a imperatriz voltou do palácio da imperatriz-viúva ao Palácio Fengluan, chegou a hora da audiência matinal das consortes.

Depois que todas se sentaram, a Consorte Li mostrou-se visivelmente contrariada.

Na véspera, primeiro dia do primeiro mês lunar, o palácio deveria ter distribuído aos serviçais de cada residência a refeição festiva de Ano-Novo.

Era a melhor refeição que aqueles empregados recebiam durante o ano inteiro, com peixe, carne e todo tipo de iguaria.

Contudo, a distribuição seguia a ordem de precedência dos postos.

As residências das Consortes e Concubinas recebiam a refeição no primeiro dia; as das Nobres Damas, no segundo; as das Atendentes e Damas, apenas no terceiro.

Como a Consorte Li era uma das consortes, sua residência deveria ter recebido a refeição na véspera, mas nada chegara.

Ela então não resistiu a perguntar à imperatriz: — Majestade, por que não distribuíram ontem a refeição festiva dos serviçais?

A imperatriz sorriu. — Espere até hoje. A refeição de ontem foi enviada primeiro ao Palácio Fengyi.

O semblante da Consorte Li piorou. Ela lançou um olhar furioso a Gu Sijin, sentada num canto, e protestou:

— Mas as regras determinam que a refeição do primeiro dia seja entregue às residências das Consortes e Concubinas. Por que o Palácio Fengyi teve prioridade?

— A Concubina Hua agora é Consorte Nobre — respondeu a imperatriz. — Naturalmente, os presentes precisam chegar primeiro ao Palácio Fengyi. Como a promoção dela foi repentina e as refeições já estavam distribuídas conforme a lista, tivemos de transferir a sua. Não leve a mal.

A Concubina Tong, que observava a cena, divertia-se com a confusão. Nem se deu ao trabalho de disfarçar: ria incessantemente da Consorte Li.

Sem conseguir preservar as aparências, a Consorte Li disse: — Mas ela nem está no palácio agora. Isso...

— Ora, os empregados da sua residência vão morrer de fome por perder uma refeição? — A Concubina Tong revirou os olhos e falou com sarcasmo. — Ning não está no Palácio Fengyi, mas a Nobre Dama Gu continua morando lá, não é?

Ela fazia aquilo deliberadamente para direcionar a raiva da Consorte Li contra Gu Sijin. E era exatamente o que a imperatriz desejava.

Afinal, aquela recompensa não passava de uma refeição. Embora houvesse regras para a distribuição, não seria difícil para a imperatriz enviar outra à residência da Consorte Li.

Mas ela não queria ser a vilã que maltratava Gu Sijin pessoalmente. Alguém teria de fazer o serviço sujo.

A Consorte Li caiu direitinho na armadilha.

Mal saíra do Palácio Fengluan quando se colocou no caminho de Gu Sijin.

Gu Sijin fez uma discreta reverência. — A Consorte Li deseja alguma coisa?

A Consorte Li cuspiu: — Ajoelhe-se!

— Não cometi nenhuma falta. Por que devo me ajoelhar?

— Sua vadia, ainda ousa retrucar?!

Sem dar qualquer explicação, a Consorte Li ergueu a mão e desferiu um tapa no rosto de Gu Sijin.

— Eu sou Consorte, e você é apenas Nobre Dama! Se mando se ajoelhar, você se ajoelha! Ainda ousa pedir um motivo?

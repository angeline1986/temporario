# Capítulo 262 — Gu Sijin voltou a bancar a santa?

Bengbeng, acompanhado de dois eunucos, avançou para cercar a Consorte Li. Ela recuou passo a passo e, de repente, começou a gritar desesperadamente:

— Ah! Não se aproximem! Sirvo ao imperador desde que ele subiu ao trono! Sou uma das quatro consortes, de posição nobilíssima! Vocês... Ah!

Antes que terminasse, Bengbeng passou por trás dela e chutou-lhe a panturrilha, obrigando-a a cair de joelhos no chão.

Os outros dois eunucos prenderam seus braços, um de cada lado, impedindo-a de se debater.

Ainda insolente, a Consorte Li gritou para a imperatriz: — Majestade! A Consorte Nobre está se vingando sob o pretexto de cumprir suas funções! Está oprimindo uma consorte sem motivo! A senhora vai ver tudo isso e não fazer nada?

No início da primavera, o clima da dinastia Qi mudava num instante. O céu, até então ensolarado, escureceu assim que nuvens cobriram o sol.

Uma rajada de vento anunciou uma mudança no tempo. A imperatriz fingiu massagear as têmporas, e Xiangling prontamente disse: — A imperatriz sofre de antigas crises de dor de cabeça. Não pode permanecer exposta ao vento.

Ela ajudou a imperatriz a entrar no palanquim de fênix, isolando os gritos e os soluços da Consorte Li do lado de fora. E, diante dos olhos de todos, a imperatriz partiu sem dizer uma palavra.

Não tinha a menor intenção de interferir.

Ou melhor: tudo aquilo fazia parte de um plano que ela preparara antecipadamente.

Conhecia muito bem o temperamento das consortes com quem convivia havia tanto tempo. Na audiência do dia anterior, atribuíra deliberadamente ao Palácio Fengyi a falta da refeição festiva destinada aos serviçais da Consorte Li.

A Consorte Li era ciumenta e agressiva. Como Ning Xiaoxiao estava ausente, era óbvio que ela criaria problemas para Gu Sijin, que morava no Palácio Fengyi e recebera diretamente os benefícios.

Ning Xiaoxiao gostava muito de Gu Sijin. Como não iria confrontar a Consorte Li ao saber do ocorrido?

Além disso, Ning acabara de se tornar Consorte Nobre. Bastava que a imperatriz a levasse a castigar outra consorte para que todos a vissem como uma favorita arrogante, tornando-a alvo de ainda mais hostilidade.

Quando todas as mulheres do harém considerassem Ning Xiaoxiao uma inimiga, a imperatriz nem precisaria agir. Mais cedo ou mais tarde, alguma delas acabaria tendo a ideia de prejudicá-la.

Ela calculava tudo com perfeição, mas não esperava que Ning Xiaoxiao a chamasse.

— Imperatriz, aguarde um momento.

Ning Xiaoxiao deu dois passos rápidos, colocou-se diante do palanquim e fez uma leve reverência. — Embora eu tenha autoridade para auxiliar na administração dos seis palácios, Vossa Majestade continua sendo a senhora do harém. Castiguei a Consorte Li porque, confiando em seu posto elevado, ela frequentemente maltratou mulheres de posição inferior. Vossa Majestade aprova minha decisão?

Após um breve silêncio, a imperatriz respondeu: — Consorte Nobre, decida por si mesma.

— Então Vossa Majestade quer dizer que a Consorte Li errou e que, se estivesse em meu lugar, também a puniria. Certo?

A pergunta encurralou a imperatriz. Mesmo que sua cabeça girasse depressa o bastante para soltar faíscas, não encontraria uma resposta que a favorecesse dos dois lados.

Se ordenasse que Ning não castigasse Li, admitiria que governava o harém com frouxidão e tolerava seus maus costumes. Bastaria Ning sussurrar alguma coisa ao ouvido de Lu Linyuan, e a imperatriz seria acusada de negligência, com consequências desagradáveis.

Mas, se permitisse que Ning punisse a Consorte Li, o incidente deixaria de ser responsabilidade de Ning: Li guardaria rancor apenas da própria imperatriz.

Como a imperatriz permaneceu calada por um bom tempo, Ning Xiaoxiao sorriu. — Vossa Majestade não está se sentindo bem por causa da dor de cabeça. É melhor voltar logo ao palácio. Quanto à Consorte Li, pode deixar que eu a disciplinarei como deve ser, em seu nome.

Dito isso, lançou imediatamente um olhar para Bengbeng. — Batam com força! Só quando aquela boca ordinária estiver toda inchada é que ela aprenderá a medir as palavras!

A Consorte Li continuou berrando e até ameaçou Bengbeng: — Se ousar me bater, eu com certeza... Ah!

Bengbeng não se intimidou. Ergueu a mão e desferiu-lhe um tapa tão forte que os grampos de ouro e pingentes de jade se espalharam pelo chão.

Como a punição já havia começado, a imperatriz não podia se indispor com ambos os lados. Limitou-se a ordenar que voltassem depressa ao palácio.

Depois de receber dois tapas de Bengbeng, a Consorte Li chorava como se toda a sua família, até os ancestrais, tivesse morrido.

As outras consortes observavam a cena apavoradas. A Concubina Tong, por sua vez, não suportava ver Ning Xiaoxiao se exibindo daquela forma. Soltou uma risada fria e voltou sozinha ao palácio.

A Consorte Li vinha de uma família ilustre e nunca tratava os serviçais com respeito. Sua boca despejava insultos cruéis sem parar, e Bengbeng já ouvira muitas coisas que feriram seu orgulho.

Agora que tinha a oportunidade de revidar, cada tapa carregava todo o ressentimento acumulado. Enquanto Ning Xiaoxiao não mandasse parar, ele batia com todas as forças.

O rosto da Consorte Li já estava tão castigado que parecia deformado. A Consorte Duan deu um passo à frente, querendo interceder por ela.

Ao perceber o movimento, Ning Xiaoxiao apenas ergueu os olhos e arqueou uma sobrancelha. Duan perdeu imediatamente a coragem.

Afinal, já tinha sido obrigada a comer aquele mingau de frutos do mar misturado com terra. Sabia do que Ning Xiaoxiao era capaz.

Depois de um número incerto de tapas, o rosto da Consorte Li estava inchado e vermelho, lustroso. Entre um golpe e outro, ela chorava e confessava sua culpa:

— Consorte Nobre... Eu errei! Reconheço meu erro!!

Ela gritava aquelas palavras em meio a soluços sofridos. Ning Xiaoxiao, porém, aproximou-se sorrindo, inclinou o corpo e levou a mão direita ao ouvido. — Mais alto! Não estou ouvindo!

Naquele dia, Ning queria transformar a Consorte Li num exemplo para todas as consortes que gostavam de causar intrigas. Se voltassem a ofender Ning ou Gu Sijin, sofreriam as mesmas consequências.

Estava defendendo Gu Sijin, mas, sabe-se lá por quê, a amiga voltou a sentir uma compaixão quase santa.

Gu Sijin puxou o braço de Ning Xiaoxiao, franziu levemente as sobrancelhas e pediu em voz baixa:

— Xiaoxiao, chega... A Consorte Li também não fez por mal, ela...

— Irmã, não diga mais nada. Se você tolerá-la hoje, amanhã ela irá ainda mais longe. Alguém em posição elevada deveria cuidar dos outros, mas ela usa o próprio título para oprimi-los e mostrar poder. O que está sofrendo agora é consequência de suas escolhas. Não tem a quem culpar.

Vendo que Ning não lhe dava ouvidos, Gu Sijin se lançou à frente, abrindo os braços como uma ave de asas estendidas para proteger a Consorte Li.

— Bengbeng, pare de bater! Se continuar, algo grave vai acontecer!

Com Gu Sijin no caminho, Bengbeng naturalmente não ousou desferir outro golpe.

Ning Xiaoxiao contemplou o rosto cheio de compaixão da amiga e soltou um suspiro resignado.

— Irmã...

— Xiaoxiao, poupe-a desta vez. Se voltar a cometer a mesma falta, ainda haverá tempo para puni-la.

A Consorte Li agarrou-se a Gu Sijin como quem encontra uma tábua de salvação. Com a boca ensanguentada, disse, mal conseguindo articular as palavras: — Nunca mais vou fazer isso... Consorte Nobre, tenha piedade...

Ning Xiaoxiao ajudou Gu Sijin a se levantar e, em seguida, agarrou com força os cabelos já despenteados da Consorte Li. Sua voz ficou ameaçadora.

— Escute bem: se eu flagrar você fazendo outra dessas, arranco sua língua!

Dito isso, entrelaçou o braço no de Gu Sijin e foi embora sem olhar para trás.

Gu Sijin, porém, voltava a cabeça a cada poucos passos e, quando seus olhos encontravam os de Li, revelavam preocupação e ansiedade.

Depois de percorrer cerca de dez metros, viu que a Consorte Li ainda estava ajoelhada e que ninguém ousava ajudá-la. Então falou: — Chuntao, ajude sua senhora a se levantar e chame um médico imperial para examiná-la em seus aposentos.

Ning Xiaoxiao puxou Gu Sijin pelo braço. — Irmã, se você tem tanta bondade sobrando, que tal aproveitar um tempo livre para carregar tijolos e construir um templo fora do palácio?

Então virou a cabeça da amiga para a frente e a puxou consigo para dentro do palanquim.

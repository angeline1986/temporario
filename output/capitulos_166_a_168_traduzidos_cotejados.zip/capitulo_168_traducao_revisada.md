# Capítulo 168 — Preparando o presente de aniversário

No dia seguinte, Qingyang não compareceu ao encontro combinado.

Ela prometera a Huanü levá-la a um lugar onde flores cobrissem as montanhas, para admirarem as flores, a lua e, sobretudo, a pessoa amada diante dos próprios olhos.

Era pleno inverno; a capital estava coberta por neve e frio rigoroso. Mas o Vale das Cem Flores, em Jiangnan, era primaveril o ano inteiro, ideal para passeios em qualquer estação.

Antes de partir, Qingyang levou Huanü para se despedir de Lu Linyuan. — Majestade, voltarei à capital apenas na primavera do próximo ano. Faz tantos anos que estive fora e ainda não revi muitos conhecidos do palácio. Se perguntarem por mim...

— Minha irmã sofreu demais em Zhuyin. Agora deve fazer aquilo que a deixa feliz. Não precisa se preocupar com os assuntos do palácio; cuidarei de tudo — garantiu Lu Linyuan.

Qingyang assentiu com um sorriso, e Huanü fez uma reverência para agradecer a bondade do imperador.

As duas saíram de mãos dadas, com os dedos entrelaçados. As criadas e os eunucos que encontravam pelo caminho as espiavam com olhares estranhos, como lâminas que tentavam atravessá-las e pregá-las ao pelourinho das convenções morais.

Elas, porém, não se importavam. Era como se só conseguissem enxergar uma à outra, e todas as contrariedades do mundo perdessem importância.

Somente quando se afastaram Sanfu se aproximou de Lu Linyuan e falou baixinho:

— Majestade... O falecido imperador mandou a Grã-Princesa para o casamento diplomático justamente porque descobriu que ela e Huanü... Ele pretendia executar Huanü, mas a Grã-Princesa concordou com o casamento para salvar a vida dela.

— Agora que voltou, parece que a relação das duas está ainda mais intensa. Qingyang foi a primeira princesa de Qi a contrair um casamento diplomático e é a única princesa desta dinastia com título e território próprios. É uma posição tão elevada... Com tanta gente observando, se isso chegar aos ministros veteranos da corte, temo que...

A preocupação de Sanfu não era infundada, mas Lu Linyuan não deu importância:

— Vão discutir o quê? Eles próprios têm várias esposas e concubinas e nem conseguem resolver as confusões dos próprios quintais. Com que cara pretendem se intrometer na vida alheia? Além disso, Qingyang é uma Grã-Princesa da família imperial. Desde quando ministros de fora da família têm direito de julgá-la?

— E, mesmo que queiram falar, o que há para discutir? Ela apenas seguiu o coração e escolheu a pessoa que ama. Que mal fez aos outros?

— Se, sob meu governo, Qi se tornar um país onde amar alguém seja crime, isso não significaria que sou tão covarde e incapaz quanto o falecido imperador?

Depois dessa sequência de perguntas, Lu Linyuan lançou um olhar para Sanfu, que não conseguia responder, e acrescentou: — Amor é amor. De onde vem essa história de certo ou errado? O palácio ainda proíbe uniões afetivas entre eunucos e criadas, sob pena de decapitação. Mas você mantém há muito tempo uma relação com a encarregada da oficina de bordados, e nem por isso mandei cortar sua cabeça.

Sanfu empalideceu como se tivesse recebido uma sentença de morte. As pernas cederam, e ele caiu de joelhos diante do imperador. — Majestade, perdoe-me! Esta serva... este servo...

— Levante-se.

— Majestade?!

— Mandei levantar — repetiu Lu Linyuan, impaciente, puxando Sanfu pelo braço. — Se a moça não se incomoda com sua condição e quer ficar com você de coração, deveria ter me contado antes.

Sanfu jamais esperara ouvir isso dele.

Até então, conhecia seu senhor como um homem violento, irascível e rigoroso na aplicação das leis. Ocultara cuidadosamente seu relacionamento com a criada, pois temia não apenas perder a própria vida, mas também arrastar a amada para a desgraça.

No entanto, as palavras aparentemente casuais que Lu Linyuan disse em seguida acabaram com suas defesas emocionais:

— Quando tiverem certeza da relação, avise-me. Descontarei um mês de seu soldo como punição e concederei autorização para que vivam abertamente essa união.

Talvez Sanfu já tivesse apanhado tanto que um pequeno gesto de carinho do tirano bastasse para comovê-lo às lágrimas, com direito a ranho escorrendo.

— Majestade... buááá! Vossa Majestade é tão bom para este servo! Nunca poderei retribuir! Só me resta servi-lo como um boi ou um cavalo para pagar tamanha bondade!

Chorava copiosamente ao lado de Lu Linyuan, que logo ficou enojado e lhe deu um belo tapa:

— Vá chorar bem longe! Não suje minhas roupas com lágrimas e meleca!

Depois de levar o tapa, Sanfu pareceu voltar ao normal. Sorriu entre lágrimas: — Certinho! Este servo já vai sumir!

— Espere. Que dia é hoje?

— Majestade, vinte e sete de novembro. Não há nenhuma data importante.

Vinte e sete de novembro.

Lu Linyuan dobrou os dedos e bateu de leve os nós sobre a mesa imperial, produzindo repetidos toc-tocs.

No registro do Departamento de Assuntos Internos, o aniversário de Ning Xiaoxiao constava como dezesseis de maio. Mas ele nunca se esquecera daquela noite em que contemplaram a lua e ela disse que era de Sagitário e ele, de Virgem.

Bastara ouvi-la uma única vez para memorizar que seu verdadeiro aniversário era vinte e oito de novembro.

Lembrava-se também de como ela ficara empolgada ao ver uma estrela cadente, quase abanando um rabinho imaginário de alegria.

Hehe. Era mesmo uma bobinha.

Quanto mais pensava, mais um sorriso ternurento lhe aparecia no rosto.

Não podia dar a Ning Xiaoxiao uma estrela cadente, mas podia substituí-la por fogos de artifício.

Ordenou imediatamente a Sanfu: — Retire os fogos de artifício do tesouro imperial. Esta noite, quando tudo estiver silencioso, enterre-os discretamente do lado de fora das muralhas do Palácio Zhongcui.

Lu Linyuan não poupou esforços para preparar aquela surpresa para Ning Xiaoxiao.

No Palácio Zhongcui moravam três consortes: Consorte Duan, Gu Sijin e Ning Xiaoxiao. Nos últimos dias, Consorte Duan passava muito tempo jogando cartas na residência de Consorte Yun e, quando anoitecia, às vezes até dormia por lá. Assim, só Ning Xiaoxiao e Gu Sijin permaneciam no Zhongcui.

Usando um convite para jantar como pretexto, chamou as duas ao Palácio Chaoyang, dando a Sanfu tempo para realizar os preparativos do lado de fora do Zhongcui.

Mais tarde, depois do jantar, Ning Xiaoxiao e Gu Sijin voltaram juntas. Pelo caminho, Ning contou piadas para fazê-la rir.

As piadas sem graça fizeram Gu Sijin gargalhar tanto que, já perto do portão, ela não percebeu onde pisava, escorregou e caiu no canteiro junto à muralha.

Qiqi, Qiaqia e as demais correram para ajudá-la a se levantar. Ning Xiaoxiao também se aproximou às pressas para ver se ela estava bem.

Felizmente, as roupas grossas de inverno e a terra fofa do canteiro impediram que Gu Sijin se machucasse.

— Estou bem! É que suas piadas me fizeram rir até a barriga doer!

O grupo já ia entrar, ainda entre risos, quando Bengbeng chamou de repente: — Senhoritas! Venham ver isto!

Ning Xiaoxiao e Gu Sijin se aproximaram e viram Bengbeng tirar da terra um tubo de papel amarelado e arredondado.

Ele rasgou o tubo e despejou o pó de dentro. Um cheiro fortíssimo de pólvora se espalhou, fazendo todos franzirem a testa e taparem o nariz.

Gu Sijin perguntou: — Por que alguém enterraria uma coisa dessas do lado de fora do nosso palácio?

Bengbeng, Qiqi e as demais vasculharam cuidadosamente o local. Descobriram que havia um desses tubos com pólvora a cada metro, formando um círculo completo ao redor do Palácio Zhongcui.

Gu Sijin ficou profundamente alarmada. — Xiaoxiao, como... como isso é possível?

Ning Xiaoxiao segurou a mão trêmula dela. Seu olhar foi escurecendo enquanto dizia, em voz grave:

— Consorte Duan não tem estado aqui nesses dias. Receio que alguém esteja tramando alguma coisa contra nós outra vez.

# Capítulo 166 — Uma irmã mais velha imponente

Fazendo as contas, Lu Linyuan não via Qingyang havia sete ou oito anos.

Qingyang se comportava com a maior naturalidade diante dele. Outros príncipes e princesas não ousariam se sentar sem permissão ao comparecer perante o imperador.

Mas ela se sentava quando queria e ainda puxava Ning Xiaoxiao para se sentar com ela. Era praticamente uma versão feminina de Lu Yiqiu.

Baixou a cabeça e ajeitou distraidamente a saia, suspirando com os lábios vermelhos entreabertos:

— Parece que nos afastamos mesmo. Durante a viagem de volta de Zhuyin, imaginei que, depois de sete anos e meio sem nos vermos, Vossa Majestade me receberia com muito carinho. Mas, desde que atravessei os portões do palácio, só encontrei frieza. Tive de vir procurá-lo por conta própria.

Lu Linyuan esboçou um sorriso: — Minha irmã mais velha não gosta de agitação. Por isso, preparei apenas aquilo de que gosta.

Bateu palmas três vezes. Sanfu conduziu uma longa fila de criados, cada qual trazendo um prato requintado, que foi disposto diante de Lu Linyuan e Qingyang.

— Minha irmã passou muitos anos longe de casa. Nas cartas, dizia sentir falta principalmente da comida do palácio. Hoje mandei preparar antecipadamente todos os seus pratos prediletos.

Fez uma pausa. Um brilho indecifrável passou por seus olhos. — E também... Huanü.

Qingyang abriu um sorriso radiante e, com certo ímpeto, ergueu a jarra para encher a taça. — Também sentia falta do vinho Imortal Embriagado deste palácio.

Aqueles irmãos pareciam falar por enigmas. Ning Xiaoxiao não entendia as indiretas trocadas entre eles.

Mas, ao ver as iguarias que cobriam a mesa dos dois e olhar para a própria mesa vazia, não conseguiu evitar a gula. Engoliu em seco.

Lu Linyuan percebeu cada movimento dela. Só depois de brindar com Qingyang voltou a atenção para aquela pequena esfomeada e perguntou, em tom de provocação: — O quê? Está com vontade de comer?

A gulosa estalou os lábios e ergueu um dedo. — Só um pouquinho... um pouquinho do tamanho de cem milhões!

Sua intenção era beliscar algo da mesa de Lu Linyuan: estava claro que ele havia planejado um banquete particular para Qingyang, e normalmente não haveria porções extras.

Para sua surpresa, Sanfu, que servia ao lado, interrompeu: — Hoje foi preparada mais uma porção, originalmente para o Príncipe Jing. Mas ele e o general Ren estão ocupados capturando um criminoso que ataca mulheres e não conseguiram vir.

Lu Linyuan aproveitou a deixa: — Então sirvam a ela. Caso contrário, a comida acabará estragando.

Ning Xiaoxiao não se importava com o que ele dizia. Desde que pudesse comer à vontade, ele podia latir o quanto quisesse.

Assim que sua mesa ficou repleta de pratos saborosos, começou a comer sem perder tempo. Se não estivesse diante do imperador e precisasse preservar alguma compostura, teria agarrado a comida com as mãos.

Lu Linyuan já estava acostumado com os modos dela à mesa. Em vez de achar desagradável, considerava-os encantadores.

Mal conseguia esconder seu sorriso bobo de quem contempla alguém querido, mas ainda assim provocou: — Coma mais devagar. Parece até um fantasma que morreu de fome e voltou à vida.

Qingyang e Lu Yiqiu eram irmãos de sangue de Lu Linyuan.

E as pessoas mais próximas são justamente as primeiras que alguém deseja apresentar à pessoa amada.

Por isso, mesmo que Qingyang não tivesse trazido Ning Xiaoxiao por acaso, ele teria inventado algum pretexto para chamá-la.

Ning Xiaoxiao não tolerava a ardência anestesiante da pimenta-de-sichuan, mas o cordeiro assado diante dela parecia irresistível. Decidiu experimentar, mesmo correndo o risco de ficar com a língua dormente.

Só depois de provar descobriu que não havia pimenta-de-sichuan no prato.

— Ah, hoje o cordeiro não tem aquela pimenta! Na última festa do palácio inteiro estava tão forte... Era delicioso, mas me fez suar toda!

Lu Linyuan conhecia perfeitamente os gostos e aversões dela. Enquanto dependesse dele, Ning Xiaoxiao não cairia duas vezes na mesma armadilha culinária.

Qingyang, porém, percebeu algo.

Remexeu o cordeiro em sua própria mesa com os hashis e sorriu: — O segredo desse prato está precisamente na pimenta aromática de Shu. Ela deixa a carne saborosa e levemente dormente, sendo considerada a melhor forma de preparar cordeiro. É necessário marinar a carne nessa pimenta por dois shichen antes de assar.

— Lembro que Yiqiu tolera bem esse tempero. Então, para quem Vossa Majestade preparou de verdade a porção extra? Não está mais do que evidente?

Lu Linyuan: — ???

Ele achava que havia disfarçado tudo perfeitamente. Uma única frase de Qingyang o desmascarara!

E sua dignidade, ficava onde?!

Limpou repetidas vezes a garganta e lançou olhares para Qingyang, implorando silenciosamente que não continuasse e preservasse sua reputação.

Mas Qingyang não caiu nessa: — Se Vossa Majestade está com a garganta ruim, chame um médico imperial. Desde o princípio pretendia que esta mocinha comesse conosco, não é?

Seus olhos pousaram em Ning Xiaoxiao, que devorava a comida sem prestar atenção ao mundo, e ela sorriu afetuosamente. — Desta vez, Vossa Majestade escolheu muito bem. Mas, se está cuidando dela, por que insiste em dizer coisas desagradáveis?

Voltando-se para Lu Linyuan, acrescentou com um sorriso debochado: — Tem medo de ficar sem graça se a moça descobrir seus sentimentos? Ora, ora... Anos sem nos vermos e Vossa Majestade ficou bem mais atrevido por dentro e reprimido por fora.

Ao ouvir aquilo, Ning Xiaoxiao quase cuspiu toda a comida.

Dizem que uma irmã mais velha é como uma mãe. No palácio, se Lu Yiqiu ocupava o segundo lugar entre aqueles capazes de deixar Lu Linyuan sem palavras, o primeiro certamente era Qingyang.

Ao ver que o rosto dele estava vermelho de vergonha, Qingyang finalmente soltou uma gargalhada. — Está bem, está bem. Finjam que bebi demais e falei bobagens. Vocês, jovens, têm tantas maneiras de flertar e implicar um com o outro... Não consigo mais acompanhar.

Ergueu a taça e bebeu com Lu Linyuan. Temendo que a irmã voltasse a zombar dele sem qualquer filtro, o imperador mudou de assunto:

— Minha irmã sofreu muito em Zhuyin. Quando o falecido imperador tomou aquela decisão, me opus repetidamente. Depois que subi ao trono, tentei trazê-la de volta diversas vezes. Por que sempre recusou?

Qingyang respondeu com indiferença: — Meu casamento diplomático serviu para evitar uma guerra entre os dois países. Quando Vossa Majestade assumiu o trono, quatro anos atrás, eu já estava casada havia três. Depois de suportar tudo o que tinha de suportar, por que provocar uma nova guerra por minha causa e fazer inocentes sofrerem?

Abriu os braços para mostrar a própria figura e sorriu: — Afinal, não voltei inteira e em perfeita saúde?

A expressão «em perfeita saúde» fez Lu Linyuan franzir discretamente as sobrancelhas.

— Ouvi dizer que, enquanto esteve em Zhuyin, minha irmã foi vítima de uma conspiração das consortes e teve a capacidade de gerar filhos comprometida...

— Ninguém tentou me matar, e ninguém teria capacidade para me fazer mal — interrompeu Qingyang, preguiçosamente.

— Foi minha própria escolha.

— Por que eu haveria de dar um filho àquele homem desprezível? Ele merecia?

— Por isso, bebi por vontade própria uma jarra de infusão de cártamo, para acabar de vez com essa possibilidade.

Ning Xiaoxiao comia enquanto acompanhava a fofoca. 【Caralho! Essa irmã é implacável!】

Lu Linyuan também ficou genuinamente chocado.

Mas Qingyang ainda guardava uma revelação capaz de surpreendê-los ainda mais.

A morte repentina do soberano de Zhuyin se devia ao fato de que, durante todos os anos de casamento, ela lhe administrara veneno de ação lenta.

A substância se acumulava gradualmente, corroendo seus órgãos internos sem que os médicos identificassem qualquer anormalidade.

Qingyang sabia que, se ele morresse e ela não tivesse filhos, certamente poderia voltar ao reino de Qi.

Assim, no dia de seu trigésimo aniversário, aumentou deliberadamente a dose. Ao observar o soberano de Zhuyin se debater diante dela, sentiu uma satisfação imensa e lhe disse, sorrindo:

— Acho melhor pararmos por aqui. Continuar vivo, a esta altura, já seria falta de educação.

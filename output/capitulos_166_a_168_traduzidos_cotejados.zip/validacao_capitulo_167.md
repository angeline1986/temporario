# Validação — capítulo 167

- Fonte primária: `novel_capitulos_121_a_180(20261103-233558).docx`, chinês tradicional.
- Intervalo dos parágrafos DOCX (base zero): 3220–3288; apenas não vazios foram cotejados.
- Total de unidades traduzidas incluindo título: **66**.
- Índices ausentes: **0**; duplicados: **0**; campos em branco: **0**.
- CSV com correspondência estrutural um a um: `indice_docx,original_chines,traducao_portugues`.

## Observações editoriais

Huanü é a criada amada por Qingyang; a cumplicidade é narrada indiretamente antes da revelação explícita no capítulo 168. A ordem violenta contra as duas criadas foi mantida. O caráter sexual das provocações foi preservado.

## Limitações

O controle estrutural não substitui auditoria linguística independente integral. Os títulos e trechos são traduzidos, com adaptações idiomáticas para português brasileiro.

# Capítulo 167 — As ameixeiras brancas floresceram na terra natal

Naquele banquete, Qingyang, feliz por voltar ao palácio depois de tantos anos, acabou bebendo algumas taças a mais.

Ao notar o rubor de vinho em suas faces, Lu Linyuan ordenou que recolhessem a jarra.

Qingyang protestou, e ele explicou: — Se minha irmã ficar bêbada, não conseguirá admirar as ameixeiras de flores brancas no Jardim das Flores Sepultadas.

Ela pareceu surpresa. — Ameixeiras brancas?

O falecido imperador não gostava dessas flores. Na verdade, detestava todas as flores brancas. Supersticioso, considerava aquela cor sóbria um mau presságio. Por isso, antes da partida de Qingyang, era proibido cultivá-las no palácio.

Para Qingyang, no entanto, o branco puro era a cor mais imaculada do mundo, livre de qualquer desejo.

Lu Linyuan conhecia seus sentimentos. — Há uma única ameixeira branca no Jardim das Flores Sepultadas. Huanü a plantou pessoalmente no dia em que minha irmã partiu para o casamento diplomático. Hoje ela cresceu e oferece uma bela copa.

O coração de Qingyang tremeu. Um calor brotou de suas profundezas e percorreu seu corpo, transformando-se em lágrimas que cintilaram sem cair.

Ergueu a taça já vazia como se fosse beber tudo de uma vez, escondendo o choro.

Depois abriu um sorriso destemido. — Não aguento mais beber; acho que estou um pouco embriagada. Amanhã, quando Vossa Majestade terminar a audiência matinal, voltarei para contar as aventuras desses anos.

Olhou para Ning Xiaoxiao e ergueu uma sobrancelha. — Você também, pequena. Venha amanhã.

Ning Xiaoxiao largou a coxa de frango, limpou a boca engordurada e assentiu com entusiasmo. — Então amanhã eu mesma cozinharei para mostrar meus dotes culinários à Grã-Princesa!

Qingyang aceitou alegremente, mas Lu Linyuan levou a mão à testa, franzindo as sobrancelhas:

— Prepare somente a sua porção e a da minha irmã. Amanhã não estarei com fome.

Ning Xiaoxiao: — ...

Qingyang riu das provocações daquele casal e se retirou.

Só depois que ela saiu Ning Xiaoxiao perguntou: — Majestade, quem é Huanü? Ela também vive no palácio? Por que nunca ouvi o senhor falar dela?

Lu Linyuan se perdeu nas lembranças e sorriu: — É alguém muito importante para minha irmã... Podemos dizer que são irmãs de coração.

O nome de Huanü nunca aparecera na obra original, portanto ela não podia ser considerada uma personagem importante daquela história.

Como Ning Xiaoxiao nunca gostara de se intrometer nos assuntos alheios, não perguntou mais nada. Satisfeita e de barriga cheia, preparou-se para ir embora.

— Majestade, já comi tudinho! Vou voltar para o meu palácio!

Lu Linyuan a deteve: — Espere aí. O que pensa que é meu Palácio Chaoyang? Uma hospedaria ou um refeitório? Vem quando está com fome e vai embora quando está satisfeita?

Ning Xiaoxiao: — ...

Ele fez um sinal com o dedo. — Venha cá.

Ning Xiaoxiao se aproximou cabisbaixa, andando devagar.

Ele segurou sua mão e desenhou círculos na palma com a ponta dos dedos. — Agora que comeu e bebeu à vontade, o que deveria fazer?

Ela balançou a cabeça, sem entender. Lu Linyuan sorriu com segundas intenções. — Vá até meus aposentos e aqueça minha cama.

Ela tentou fugir, mas não chegou a dar um passo: ele prendeu um dedo no cinto dela.

Seu manto de inverno era preso justamente pelo cinto; se fosse desatado, poderia expor muito mais do que ela desejava.

Ning Xiaoxiao congelou, sem ousar se mexer. Lu Linyuan provocou com descaramento: — Pode correr. Assim aproveito para descobrir se está usando o presente que lhe dei por baixo da roupa.

Ning Xiaoxiao: — ...

【Vai olhar a cabeça da sua mãe!】

【Ei, ei, eu nem me mexi! Por que você está desatando sozinho?!】

【Seu trapaceiro de quinta! Atacar de surpresa não vale! Você não tem competência para jogar limpo!】

Sentindo que o perigo se aproximava, segurou imediatamente a mão dele e acabou se denunciando:

— Rosa, com bordas douradas!

Lu Linyuan enganchou o indicador no cinto dela e assentiu, visivelmente satisfeito:

— Bom gosto. Também é o meu favorito.

Os dois continuaram trocando provocações indecentes, muito barulho para pouca ação.

Enquanto isso, depois de sair do Palácio Chaoyang, Qingyang caminhou pela neve recente e macia até o Jardim das Flores Sepultadas.

Era o lugar onde se enterravam flores no palácio: recolhiam as pétalas caídas do jardim imperial e as sepultavam juntas ali.

Parecia uma tarefa simples, mas o trabalho era ainda mais exaustivo do que no Xinzheku. Em geral, apenas serviçais que tivessem cometido faltas graves eram enviados para lá como punição por dois ou três meses.

Huanü fora criada pessoal de Qingyang. Depois que sua senhora partiu, pediu para trabalhar naquele lugar e lá permaneceu por sete anos inteiros.

Ao chegar, Qingyang reconheceu Huanü imediatamente entre as quatro ou cinco criadas ocupadas.

Ela não era propriamente bonita, mas tinha um rosto redondo e rechonchudo, quase infantil, no qual o tempo dificilmente deixava marcas.

Depois de sete anos, continuava igualzinha ao dia da despedida, ainda com o mesmo brilho nos olhos.

Qingyang estava prestes a cumprimentá-la quando viu duas criadas empurrá-la ao chão sem motivo. Apontaram para ela e começaram a ralhar: — Quantas vezes precisamos dizer que recolha as flores caídas perto das fontes termais do Pátio Leste? Você é surda?!

Huanü tinha um temperamento dócil e só conseguia suportar a humilhação. — Vou agora mesmo...

Apoiou as mãos no chão para se levantar, mas uma figura de vermelho apareceu ao seu lado e a ergueu pelos braços.

Quando reconheceu o rosto de Qingyang, arregalou os olhos e rompeu em lágrimas.

Qingyang não desviou os olhos dela nem por um instante; um sorriso delicado lhe curvava os lábios.

Enxugou suas lágrimas e, sem sequer olhar para as duas criadas, ordenou à comitiva: — Levem essas duas. Arranquem-lhes a pele e os ossos e joguem-nas na vala comum para servir de comida aos cães.

As criadas gritaram, implorando por misericórdia. Só quando os pedidos se perderam ao longe Qingyang falou suavemente a Huanü: — Não chore mais. Tudo passou.

Huanü soluçou: — Grã-Princesa... esta serva... esta serva saúda Vossa Alteza.

Tentou fazer uma reverência, mas Qingyang apertou sua mão e não permitiu.

— Depois dos vinte e cinco anos, você podia ter deixado o palácio. Mas insistiu em permanecer. Fiquei tantos anos longe, e você passou todos eles aqui, guardando este jardim. Se eu tivesse ficado presa em Zhuyin pelo resto da vida, teria valido a pena tamanha tolice?

A expressão de Huanü se tornou firme. Apertou os lábios e assentiu decididamente.

— Sirvo à Grã-Princesa desde criança. Não ter podido acompanhá-la a Zhuyin foi uma falha minha. Vossa Alteza sofreu tanto...

Qingyang sorriu e balançou a cabeça. — Quem sofreu foi você. Agora que voltei, ninguém mais ousará maltratá-la ou humilhá-la.

As lágrimas de Huanü diminuíram. Ela tomou Qingyang pela mão e a conduziu até a ameixeira que plantara pessoalmente, sorrindo como uma criança inocente:

— Grã-Princesa, veja! É a ameixeira branca de que tanto gosta. Implorei ao imperador durante tanto tempo até ele permitir que eu plantasse esta árvore aqui. Não é linda?

— É — concordou Qingyang, apertando involuntariamente a mão de Huanü.

Uma rajada de vento desprendeu pétalas brancas de toda a árvore, espalhando-as pelos cabelos, ombros e rostos das duas.

De mãos dadas, permaneceram lado a lado sob a árvore, contemplando os olhos límpidos uma da outra.

Não disseram nada. Apenas sorriram.

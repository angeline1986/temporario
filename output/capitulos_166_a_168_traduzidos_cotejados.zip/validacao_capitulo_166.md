# Validação — capítulo 166

- Fonte primária: `novel_capitulos_121_a_180(20261103-233558).docx`, chinês tradicional.
- Intervalo dos parágrafos DOCX (base zero): 3157–3219; apenas não vazios foram cotejados.
- Total de unidades traduzidas incluindo título: **60**.
- Índices ausentes: **0**; duplicados: **0**; campos em branco: **0**.
- CSV com correspondência estrutural um a um: `indice_docx,original_chines,traducao_portugues`.

## Observações editoriais

Qingyang conta que tomou uma infusão para impedir uma gravidez e que envenenou secretamente o soberano de Zhuyin; a exposição desse último fato está na narração, não em confissão falada aos presentes. Personagem Huanü é introduzida.

## Limitações

O controle estrutural não substitui auditoria linguística independente integral. Os títulos e trechos são traduzidos, com adaptações idiomáticas para português brasileiro.

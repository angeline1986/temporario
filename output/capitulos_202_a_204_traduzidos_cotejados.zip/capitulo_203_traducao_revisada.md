# Capítulo 203 — A verdadeira identidade do tirano (I)

A determinação com que Chu Xingran deixara a dinastia Qi para se infiltrar entre os piratas japoneses só se comparava agora ao sofrimento de sua jornada para reconquistar a esposa.

Lu Linyuan testemunhara em primeira mão o ditado “maltratar a esposa é uma delícia por um instante; reconquistá-la depois é um inferno”. Decidiu, portanto, tomar muito cuidado com tudo que dissesse ou fizesse perto de Ning Xiaoxiao. Nada de irritar a esposa e terminar ele próprio naquele inferno...

Depois que Chu Xingran partiu, Lu Linyuan chamou Sanfu e ordenou que separasse os memoriais já examinados e os devolvesse aos ministros.

Enquanto organizava os documentos, Sanfu comentou:

— Majestade, chegou um servidor do Departamento de Obras Imperiais. E também... a ama Qingzhu, que serve a imperatriz-viúva.

Falando nela, a imperatriz-viúva andava bem comportada ultimamente.

Comia e dormia na hora certa e não inventava novas confusões.

— Faça entrar primeiro o homem do Departamento de Obras.

O servidor entrou, fez uma reverência formal e disse: — Majestade, as reformas do Palácio Xianshou estão praticamente concluídas. Falta apenas repintar as paredes externas, mas o lugar já está em condições de ser habitado.

O homem estava insinuando que chegara o momento de levar a imperatriz-viúva de volta.

Afinal, com o Ano-Novo se aproximando, não poderiam deixá-la espremida no Palácio Shoukang com todas aquelas consortes viúvas, poderiam?

E era fácil adivinhar quem mandara aquele jovem eunuco trazer semelhante recado.

As mãos da imperatriz-viúva se intrometiam nos assuntos da corte e do harém havia muito tempo. Desde a mudança para o Palácio Shoukang, não faltavam ministros aconselhando Lu Linyuan, com toda a insistência, a trazê-la de volta. Ele, porém, fingia não ouvir.

Ergueu a xícara de chá e tomou um gole demorado. — Não há pressa. Continuem a reforma. Quando estiver inteiramente concluída, poderemos trazer minha mãe de volta.

Em seguida, pegou um caqui seco do prato de frutas sobre a mesa imperial e o lançou ao servidor. — Trabalhar à noite é cansativo. Pegue isto.

Receber um presente do próprio imperador era motivo de imensa alegria para um eunuco.

O rapaz saiu todo contente do Palácio Chaoyang com o caqui nas mãos. Ao cruzar com Sanfu na porta, fez-lhe uma reverência e continuou sorridente.

Antes que ele se afastasse, Sanfu lançou um olhar a Xiao Yinzi. — Viu o que ele está segurando?

Xiao Yinzi assentiu vigorosamente. Sanfu prosseguiu: — Então por que ainda não foi fazer o que precisa?

Em chinês, a palavra para caqui, *shi*, soa como a palavra para morte, *si*.

Lu Linyuan detestava gente que tentava manipulá-lo. Um personagem insignificante que falasse por quem não devia, dizendo o que não devia, naturalmente não viveria até o amanhecer.

Mais tarde, Sanfu conduziu a ama Qingzhu ao salão para prestar suas homenagens ao imperador.

Qingzhu cumprimentou-o com toda a deferência. — Majestade, vim hoje buscar a tabuleta budista e o pequeno altar que Sua Majestade, a imperatriz-viúva, mantinha no Palácio Xianshou.

— Como sabe, a imperatriz-viúva é profundamente devota. Precisa reverenciar sua tabuleta todos os dias, de manhã à noite, ou não encontra paz. Desde que se mudou para o Palácio Shoukang, sente falta desse objeto de veneração.

Para sua surpresa, Lu Linyuan não lhe criou dificuldades.

— É bom que minha mãe seja devota ao budismo. Bastava mandar alguém avisar, sem necessidade de a senhora vir pessoalmente.

Qingzhu inclinou-se ainda mais. — Agradeço, Majestade. Então esta velha serva pede licença para se retirar.

Ela já se virava para partir quando Lu Linyuan se levantou e a chamou. — Vou acompanhá-la. O homem do Departamento de Obras acabou de me dizer que a reforma está quase pronta. Quero dar uma olhada. Se estiver tudo bem, talvez minha mãe possa voltar nos próximos dias.

Dizem que entre mãe e filho não há desavença que dure a noite inteira. Ao ouvir isso, Qingzhu pensou que Lu Linyuan finalmente abandonara a disputa com a imperatriz-viúva e ficou verdadeiramente feliz por sua senhora.

O Palácio Xianshou reformado estava incomparavelmente mais luxuoso que antes.

Qingzhu imaginara que Lu Linyuan usara as reformas como desculpa para mandar a imperatriz-viúva ao Palácio Shoukang, apenas para defender Ning Xiaoxiao das perseguições dela.

Só agora, diante de toda aquela decoração dourada e prateada, percebeu que o imperador realmente reconstruíra o lugar.

Vendo-a contemplar a ornamentação, Lu Linyuan sorriu. — Diga a minha mãe que não a instalei temporariamente no Palácio Shoukang por causa da Concubina Hua, mas por minha devoção filial. Quero sinceramente que viva com mais conforto. Espero que não pense o contrário.

— O que está dizendo, Majestade? A imperatriz-viúva sempre compreendeu sua devoção e nunca suspeitou de nada — respondeu Qingzhu.

Entraram um atrás do outro no salão principal. A tabuleta estava sobre o altar, com incenso ardendo à frente. Parecia que alguém continuara a fazer oferendas todos os dias, mesmo após a mudança da imperatriz-viúva.

Lu Linyuan curvou-se com devoção diante da tabuleta. — Sei o quanto minha mãe a estima, pois a reverencia diariamente. Por isso ordenei que continuassem fazendo oferendas durante toda a reforma, sem negligenciá-la.

Qingzhu murmurou uma prece e estendeu as duas mãos para receber a tabuleta das mãos dele.

Lu Linyuan apertou-a por um instante. Uma tristeza passageira atravessou seu olhar, mas ele logo recuperou o sorriso luminoso e entregou o objeto a Qingzhu.

Quando mais jovem, a imperatriz-viúva cometera inúmeras atrocidades no harém do falecido imperador.

Envenenara consortes grávidas, conspirara contra filhos imperiais, incriminara favoritas e recorrera a toda sorte de intrigas e artifícios.

Dizem que quem tem a consciência tranquila não teme batidas à porta à meia-noite.

A imperatriz-viúva, porém, cometera tantos crimes que, quando a noite chegava, uma multidão de fantasmas parecia invadir seus sonhos, um após o outro, para cobrar-lhe a vida.

Embora ocupasse a posição mais elevada, raramente conseguia dormir em paz.

Aquela tabuleta budista fora obtida dez anos antes por Lu Linyuan, que procurara um monge eminente em nome dela.

Curiosamente, depois que passou a venerá-la todos os dias, a imperatriz-viúva nunca mais teve pesadelos. Era como se os pecados de toda uma vida tivessem sido apagados pelas preces.

Assim, ajoelhava-se três vezes ao dia diante da tabuleta, sem jamais se descuidar.

O que a imperatriz-viúva ignorava era que, escondida por trás do revestimento dourado daquela tabuleta, estava na verdade a placa memorial de uma mulher morta.

— A senhora Qin.

Qin não tinha origem nobre. Fora apenas uma criada encarregada de servir chá e água diante do trono.

Era, entretanto, extraordinariamente bela. Mesmo sem maquiagem e trajada com roupas simples, possuía uma beleza capaz de encantar um reino.

A beleza de uma mulher pode ser uma faca de dois gumes, mas, nos tempos antigos, quando tudo se submetia ao poder imperial,

ser bonita tornava-se seu pecado original.

O falecido imperador se interessou por ela e, certa vez, bêbado, forçou-a a se deitar com ele.

E bastou aquela única vez para que ela engravidasse.

Todos imaginavam que, por causa disso, ela ascenderia de uma vez só à posição de uma fênix. No entanto, após uma chuva primaveril repentina, desapareceu do palácio sem deixar vestígios.

O falecido imperador ordenou uma busca em todos os cantos da residência imperial, mas ninguém encontrou seu paradeiro.

Como Qin tinha temperamento orgulhoso, alguns especularam que se atirara num poço; outros, que escapara misturada aos trabalhadores que levavam água para o palácio.

Na época, o governo enfrentava problemas internos e externos, e o imperador já tinha muitos descendentes. Por isso, não perdeu muito tempo com uma simples criada desaparecida.

Mas Qin, naquele dia, não morrera nem saíra do palácio. Fora aprisionada pela atual imperatriz-viúva, que também estava grávida...

# Capítulo 202 — Lu Linyuan, fã número um do casal “Estrelas e Brocado”

Aquelas frases de presidente dominador talvez parecessem constrangedoras num romance, mas, na vida real, quem conseguiria ouvi-las sem ficar toda derretida?

Ning Xiaoxiao não apenas ficou derretida: ficou empolgada a ponto de querer tascar um beijo naquele rostinho bonito de Lu Linyuan e voltar com ele ao palácio para fazer coisas bem agradáveis.

O problema era que Lu Linyuan tinha um talento desesperador para matar o romantismo. Sempre que Ning Xiaoxiao se emocionava, ele arranjava um jeito de acabar com o encanto imediatamente.

— Mas não pense que vou lhe dar essa medalha de imunidade à morte de graça. Quando formos para a propriedade das fontes termais, os memoriais também serão enviados para lá. Você os lerá para mim todos os dias.

Ning Xiaoxiao: — ???

【Então você quer me levar às fontes termais para que eu seja seus olhos e lhe mostre as mudanças das estações, é isso?】

【Prefiro perder a vida a voltar a ler uma palavra sequer daqueles memoriais escritos em chinês clássico!】

Ela estendeu a medalha de volta a Lu Linyuan e disse com toda a seriedade: — Majestade, nesse caso, não quero mais isto.

— Não quer? — Um sorriso perversamente encantador se desenhou nos lábios dele. — O que eu lhe dou não é algo que você possa recusar. Se ousar rejeitar, estará desobedecendo a um decreto imperial...

As pontas dos dedos dele deslizaram pelo pescoço longo e branco de Ning Xiaoxiao. — E quem desobedece a um decreto perde a cabeça.

Diante da “tirania” de Lu Linyuan, Ning Xiaoxiao só pôde aceitar a medalha de volta, com o coração “partido”.

No fundo, ela sabia perfeitamente que Lu Linyuan jamais suportaria vê-la sofrer o menor ferimento naquele momento, quanto mais mandá-la decapitar.

Mas ele ainda era imperador. Quando fazia pose de soberano implacável, por educação ela não deveria fingir um pouquinho de medo?

Do contrário, pareceria que tinha sido criada sem modos...

O banquete no Lago Imperial tomara todo aquele dia, e a partida para as fontes termais estava próxima. Lu Linyuan ainda tinha muitos assuntos de governo a resolver.

Por isso, levou Ning Xiaoxiao de volta ao Palácio Fengyi, mandou que descansasse cedo e retornou sozinho ao Palácio Chaoyang.

No caminho, ditou a Sanfu um decreto: — Transmita minha ordem verbal: de agora em diante, todos os memoriais apresentados pelos ministros deverão ser escritos em linguagem corrente. Caso contrário, serão devolvidos intactos, sem minha aprovação em tinta vermelha.

Na verdade, os antigos também sabiam escrever de maneira coloquial; afinal, era assim que falavam no dia a dia.

Os memoriais eram redigidos em linguagem clássica porque um único caractere podia transmitir o sentido de vários. Algo que ocuparia trezentos ou quatrocentos caracteres na linguagem comum podia ser explicado em cinquenta ou sessenta no estilo clássico.

Em termos de eficiência, era naturalmente muito superior.

Sanfu não compreendeu: — Majestade... Os memoriais já se acumulam como montanhas todos os dias. Se forem escritos em linguagem comum, cada um ganhará várias páginas. Isso não lhe dará ainda mais trabalho?

Lu Linyuan lançou-lhe um olhar atravessado. — Mandei transmitir o decreto, não questioná-lo. Faz quantos dias que você não leva um tapão na cara? Está sentindo falta?

Sanfu ficou atônito. — Um tapão? Que coisa é essa?

PÁ!

Pediu, recebeu.

Lu Linyuan virou a mão e lhe deu um tapão que deixou a cabeça de Sanfu zunindo.

— Agora sabe o que é? — perguntou ele, sorrindo.

À beira das lágrimas, Sanfu só conseguiu erguer o rosto para os céus e gritar silenciosamente no coração:

EU NÃO FIZ NADA CONTRA NINGUÉM!!!

*

Gu Sijin e Ning Xiaoxiao voltaram ao palácio quase ao mesmo tempo. Assim que encontrou a amiga, Gu Sijin começou a rir, dizendo que o poema feito por ela naquele dia fora divertidíssimo. — Você e o imperador foram embora mais cedo e não viram! A imperatriz ficou com o rosto todo retorcido de raiva! Hahaha!

Ning Xiaoxiao segurou a mão dela e caminhou sob a neve que caía por toda parte. Também riu, mas disse: — Só que agora ofendi a imperatriz de vez. Você sabe que vou às fontes termais com Sua Majestade, e você ficará sozinha aqui. Não consigo deixar de me preocupar. A imperatriz é cheia de artimanhas, a Consorte Tong é arrogante, e nenhuma das outras mulheres do harém é flor que se cheire. Eu queria...

— Não se preocupe comigo.

Gu Sijin apertou a mão dela e a encarou seriamente.

— Sei o que está pensando. Você já pediu ao imperador que me deixasse morar com você no Palácio Fengyi. Pedir agora que ele também me leve às fontes termais seria passar dos limites.

— Xiaoxiao, escute. Sua Majestade a trata bem, então você também precisa pensar nele. Não pode agir como bem entende e perder a medida só porque ele a mima, entendeu?

Ning Xiaoxiao sabia desde o começo que Gu Sijin recusaria. Nem tentou convencê-la; apenas colocou nas mãos da amiga a medalha de imunidade à morte que Lu Linyuan lhe dera.

Gu Sijin vinha de família nobre. Como poderia ignorar a importância daquele objeto na dinastia Qi?

Não ousou aceitá-lo e começou a devolvê-lo. — O imperador lhe deu uma coisa tão preciosa e você quer simplesmente passá-la para mim? Se ele souber, vai morrer de raiva. Guarde-a. Pare de fazer bobagens.

— Ai, irmã! — Ning Xiaoxiao empurrou a medalha contra o peito de Gu Sijin. — Não estou dizendo que vou lhe dar. Só quero que a guarde para mim por algum tempo.

— Vou com o imperador às fontes termais. Para que levaria esta medalha? Fique com ela enquanto estiver aqui. Se alguém tentar maltratá-la, basta mostrá-la: ver esta medalha é como ver o próprio imperador. Assim poderei partir tranquila.

Como Gu Sijin insistia em recusar, Ning Xiaoxiao fingiu irritação e fez cara feia. — Está bem. Se não ficar com ela, vou passar a viagem inteira preocupada e nem conseguirei me divertir com Sua Majestade. Nesse caso, não vou mais. Deixo o imperador sozinho, de molho nas fontes termais.

Gu Sijin: — ???

Ela realmente não sabia o que fazer com aquela espertinha. E se emocionava repetidas vezes com o carinho que Ning Xiaoxiao demonstrava por ela.

Entre irmãs de coração, repetir palavras exageradas de agradecimento acabava até soando artificial.

Gu Sijin não disse mais nada. Recebeu tranquilamente a medalha e brincou: — Então vou guardá-la. Mas volte logo; se essa coisa se perder, não vou pagar outra.

Só então o sorriso voltou ao rosto de Ning Xiaoxiao.

Gu Sijin segurou a mão dela. Uma rajada de vento lhe acariciou o rosto, avermelhando seus olhos.

No íntimo, jurou que jamais soltaria a mão daquela irmã de coração, enquanto vivesse.

*

Palácio Chaoyang.

Sanfu entrou para anunciar que Chu Xingran solicitava uma audiência. Lu Linyuan interrompeu a revisão dos memoriais e mandou que o trouxesse.

Chu Xingran nunca foi de rodeios. Ao encontrar o imperador, foi direto ao assunto:

— Majestade, nesta viagem às fontes termais, prefiro não acompanhá-lo. Acabei de assumir o posto de comandante dos Nove Portões, e ainda preciso reorganizar muitos postos de guarda no palácio. Gostaria de deixar tudo pronto antes das festas de fim de ano.

Desde que descobrira a história entre Chu Xingran e Gu Sijin, Lu Linyuan fazia-se de desentendido, mas, assim como Ning Xiaoxiao, tornara-se torcedor ferrenho daquele casal e descobrira o prazer de acompanhar um romance alheio.

Mal se divulgara que ele levaria apenas Ning Xiaoxiao às fontes termais, Chu Xingran já aparecera para dizer que não iria.

Por que tanta pressa?

Não seria para conseguir encontrar Gu Sijin em particular mais algumas vezes?

Lu Linyuan observou Chu Xingran e sorriu, divertido. — Se não quer ir, não vou amarrá-lo e levá-lo à força. As três divisões orientais da Guarda Imperial também estão sob seu comando. Durante esse período, se tiver tempo, fique hospedado na ilha do Lago Imperial e cuide bem da segurança do palácio em meu lugar.

Ao ouvir aquilo, Chu Xingran imediatamente juntou as mãos num cumprimento. Incapaz de esconder a alegria, respondeu em voz alta: — Cumprirei a ordem de Vossa Majestade!

Lu Linyuan manteve a expressão impassível. — Muito bem. Se não tem mais nada, pode se retirar.

Porque, se você não sair logo, vou acabar caindo na gargalhada...

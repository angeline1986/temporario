# Capítulo 204 — A verdadeira identidade do tirano (II)

Uma mulher que conseguira vencer a edição anterior das batalhas do harém poderia ser alguém fácil de enfrentar?

A família materna da imperatriz-viúva exercia enorme influência na corte. Com suas artimanhas, ela conquistara o coração do soberano e, por algum tempo, até o falecido imperador, mulherengo como era, dedicara-lhe atenção exclusiva.

Apesar de todo o favor imperial, contudo, ela não conseguia ter filhos.

Desesperada para engravidar, conseguiu fora do palácio uma receita de tônicos supostamente milagrosa. Depois de três meses, finalmente engravidou. Mas os remédios eram agressivos demais, e o médico imperial avisou claramente: independentemente do sexo da criança, aquela seria sua única gestação.

No harém, quem não gerava um filho homem dificilmente assegurava o futuro.

Pelo amor do falecido imperador, pela própria posição, pela glória da família...

Ela precisava garantir que aquela única oportunidade resultasse no nascimento de um menino.

Nos tempos antigos, porém, determinar o sexo do bebê apenas pelo pulso da gestante era extremamente pouco confiável.

Ela passara a vida lutando no palácio e nunca acreditara no destino; acreditava apenas em si mesma.

Por isso, voltou os olhos para Qin, que engravidara quase ao mesmo tempo que ela.

Se o céu decidia quem teria menino ou menina, arranjar outra barriga para produzir mais uma criança certamente aumentaria as chances de conseguir um filho homem.

Qin era uma simples criada, sem família poderosa para protegê-la.

Se desaparecesse, a superfície das águas turvas do harém mostraria, no máximo, algumas ondulações. Nada de tempestades.

A imperatriz-viúva então recorreu a todos os meios para aprisioná-la sem que ninguém soubesse. Planejava administrar-lhe um remédio para induzir o parto quando chegasse a sua própria hora, para que as duas dessem à luz no mesmo dia.

Se ambas tivessem meninos, Qin e seu filho seriam mortos imediatamente.

Se ela tivesse uma menina e Qin um menino, mataria a mãe e tomaria o filho. Sua própria filha seria enviada para fora do palácio e criada em segurança, escapando até mesmo do risco de, no futuro, ser entregue em casamento diplomático.

Chegado o dia do parto, as duas mulheres deram à luz, uma depois da outra, dois meninos.

Infelizmente para a imperatriz-viúva, talvez devido aos remédios fortes que tomara, seu parto foi terrivelmente doloroso. Depois de sete ou oito horas de sofrimento, seu bebê nasceu sem sequer chegar a chorar: estava morto.

Ela ficou devastada. Felizmente, porém, o menino de Qin nascera forte e saudável.

A imperatriz-viúva encenou então uma troca de bebês digna de novela: mandou matar Qin, apropriou-se do filho dela e enganou todo o harém.

E aquele bebê que Qin dera à luz era o atual soberano: Lu Linyuan.

O plano da imperatriz-viúva fora engenhoso. Além disso, ambos os meninos eram filhos biológicos do falecido imperador. Nem mesmo uma prova tradicional de parentesco por gotas de sangue despertaria suspeitas.

Mas ela deixara escapar um detalhe.

Durante o cativeiro de Qin, certa criada encarregada de levar-lhe comida apareceu um dia visivelmente perturbada. Qin puxou conversa com ela.

Ao descobrir que a moça precisava urgentemente de dinheiro, Qin disse conhecer uma maneira de ajudá-la.

Explicou que, no antigo quarto onde morara, havia algumas joias escondidas sob os ladrilhos do chão; se as vendesse, poderia conseguir uma boa soma.

Em troca do favor, Qin deu-lhe o simples grampo de prata que usava no cabelo e pediu que o deixasse no lugar de onde tirasse as joias.

Disse que provavelmente não viveria muito mais e que o grampo fora um presente de sua mãe, sua única lembrança dela. Sua mãe também servira no palácio e habitara aquele mesmo quarto; queria deixar ali o objeto para que, depois da morte, seu espírito tivesse para onde voltar.

A criada era fácil de enganar e estava desesperada por dinheiro, de modo que concordou.

Naquele tempo, o médico imperial Zhao, especialista renomado em obstetrícia e saúde feminina, mantinha secretamente um relacionamento amoroso com Qin. Planejava esperar que ela completasse vinte e cinco anos, idade em que poderia deixar o palácio, para finalmente se casarem. Mas o destino não colaborou.

Quando Qin desapareceu, foi ele quem mais sofreu.

Sempre soubera que ela jamais sairia do palácio ou tiraria a própria vida sem motivo. Tinha certeza de que havia algo oculto por trás do desaparecimento.

Sabia também que Qin guardava suas pequenas economias e joias sob os ladrilhos do antigo quarto.

Depois que ela sumiu, visitava aquele cômodo de tempos em tempos, como se ainda pudesse encontrá-la ali.

Um dia, percebeu marcas mostrando que alguém havia movido um dos ladrilhos. Levantou-o e encontrou o simples grampo de prata de Qin.

Era a lembrança de amor que ele próprio lhe dera. O grampo tinha o corpo oco e, retirando a extremidade, revelava-se um pequeno compartimento secreto.

Ele colocara ali um poema de amor escrito para Qin, como maneira discreta de expressar o sentimento que compartilhavam.

Zhao retirou a ponta do grampo e descobriu que, no verso daquele poema, haviam surgido várias linhas de caracteres minúsculos escritos com sangue.

Qin os escrevera com o próprio sangue, descrevendo de forma breve e precisa a conspiração da imperatriz-viúva.

Qin sabia que provavelmente morreria. Também sabia que, mesmo se contasse a Zhao o que acontecia, ele não conseguiria resgatá-la; só alertaria a imperatriz-viúva, que descobriria tudo a tempo de eliminar as testemunhas.

Se o segredo viesse à tona, ela, Zhao e a criança em seu ventre acabariam mortos.

Por isso, resolveu apostar a própria vida numa armadilha contra a imperatriz-viúva.

Pediu que Zhao encontrasse uma forma de se aproximar da imperatriz-viúva e de assistir ao parto dela.

Depois, deveria adulterar os procedimentos para causar a morte do bebê da imperatriz-viúva e substituí-lo por seu próprio filho.

Assim, embora ela morresse, a criança poderia desfrutar uma vida inteira de riqueza e honrarias, enquanto a imperatriz-viúva terminaria a vida sem um filho verdadeiro para velar por ela.

Zhao era um médico excepcional, especializado em obstetrícia. Sob seu planejamento, tudo correu conforme o necessário.

Ele, contudo, não seguiu a instrução de Qin de matar o filho da imperatriz-viúva.

Por compaixão médica, decidiu preservar a vida do bebê e criá-lo pessoalmente.

Como a imperatriz-viúva pretendia trocar as crianças, o seu próprio suposto “natimorto” teria de ser retirado secretamente do palácio.

Na época, Zhao já se tornara um homem de confiança dela. Com a autorização implícita da senhora que confiava nele, levou a criança para fora e passou a criá-la.

Depois disso, permaneceu no serviço imperial durante mais catorze anos. Apenas quando adoeceu gravemente e percebeu que não viveria muito foi que contou tudo a Lu Linyuan.

Zhao não tinha forças para derrubar a imperatriz-viúva, mas esperava que Lu Linyuan vingasse a mãe biológica.

E, de fato, Lu Linyuan o fez.

Durante todos aqueles anos, fingiu ingenuidade e aproveitou a força da família da imperatriz-viúva para subir, passo a passo, até o trono. Além disso, fizera a mulher ajoelhar-se todos os dias, por dez anos, diante da placa memorial de sua mãe biológica, escondida sob a tabuleta budista.

Mas isso estava longe de ser o principal.

Lu Linyuan entrou nos aposentos da imperatriz-viúva, sentou-se na beirada da cama dela e bateu duas vezes com o pé no chão, com força.

Ninguém no palácio sabia que, sob o piso onde ficava a cama da imperatriz-viúva no Palácio Xianshou, havia uma câmara subterrânea secreta.

Desde que Lu Linyuan ascendera ao trono e instalara a imperatriz-viúva naquele palácio, alguém permanecia acorrentado no subterrâneo, vivendo na escuridão, numa existência pior que a de um animal.

E essa pessoa era o filho biológico que a imperatriz-viúva lutara tanto para trazer ao mundo.

Os ecos das pisadas ressoaram pela noite silenciosa. As velas tremulavam no aposento, deixando Lu Linyuan ora iluminado, ora envolto em sombras.

Ele fechou os olhos, inclinou a cabeça e escutou o som límpido dos ecos. Aos poucos, um sorriso sombrio e aterrador surgiu em seus lábios.

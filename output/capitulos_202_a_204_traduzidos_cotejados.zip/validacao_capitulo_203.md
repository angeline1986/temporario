# Validação do capítulo 203

- Fonte: `novel_capitulos_181_a_211(20261105-152744).docx` (DOCX chinês tradicional).
- Limites: parágrafos base zero 1404 a 1466, até antes do capítulo 204.
- Unidades não vazias (título incluído): 60.
- Cotejo CSV: 60 linhas, índices reais preservados; campos não vazios.
- Tradução MD: 60 unidades correspondentes em ordem.
- Notas editoriais: O trocadilho 柿 (caqui) / 死 (morte) ganhou explicação explícita. A morte do eunuco é implicada pela narração, não descrita como cena executada. A fala da serva sobre a devoção filial não comprova sinceridade de Lu.
- Limitação: correspondência estrutural 1:1 e revisão contextual; não houve uma segunda auditoria semântica independente integral.

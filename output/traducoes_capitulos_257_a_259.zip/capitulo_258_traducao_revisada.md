# Capítulo 258 — Abrace-me com seu amor até me deixar sem ar

O trio de “bel­dades letais”, Liu, Guan e Zhang, continuava empilhado sobre Huyan Zhu. Como todas eram enormes e musculosas, levaram um bom tempo para conseguir sair de cima dele.

Depois daquele tempo sob o peso das três, Huyan Zhu parecia ter ficado até mais achatado...

Furioso, ele apontou para elas e berrou: — Inúteis! Seria melhor criar um porco do que sustentar vocês!

Ning Xiaoxiao, triunfante, aproximou-se dele e disse com um sorriso: — Aposta é aposta. A partir de hoje, Zhuyin passa oficialmente a ser um condado subordinado ao Império Qi. De agora em diante, deverá se apresentar como Condado de Zhuyin.

Huyan Zhu entrou em desespero, agitando os braços: — Impossível! Absolutamente impossível! Eu...

— Hã? — Ning Xiaoxiao fechou os punhos, fazendo os nós dos dedos estalarem, e se inclinou para ouvi-lo melhor. — O que disse? Não escutei. Pode repetir?

Ele teria coragem?

Se o punho de ferro de Ning Xiaoxiao caísse sobre ele, talvez nem conseguisse sair vivo de Qi...

Acabara de aceitar a aposta com a própria boca. Agora que perdera, se voltasse atrás, Lu Linyuan certamente enviaria tropas contra Zhuyin e o destruiria sem deixar sobreviventes.

Encurralado, Huyan Zhu queria chorar, mas só lhe restou engolir a derrota e partir cabisbaixo, remoendo o ódio.

Assim que ele foi embora, Lu Yiqiu tomou a dianteira, incentivando os ministros a aplaudir Ning Xiaoxiao.

Dessa vez, ela ficou um pouco envergonhada. Baixou a cabeça, correu com passinhos miúdos até a plataforma e se escondeu ao lado de Lu Linyuan.

Parecia uma delicada passarinha buscando proteção, sem nenhum sinal da valentia de minutos atrás.

Lu Linyuan ergueu-lhe o queixo delicado e o acariciou. — Quantas surpresas suas eu ainda não conheço?

— Ah, para~ — Ning Xiaoxiao fingiu timidez e deu dois soquinhos no peito dele.

— Ugh...

Só aqueles dois socos quase mataram Lu Linyuan no mesmo lugar...

Na verdade, ele não tinha a menor ideia de que Ning Xiaoxiao venceria. Sabia apenas que ela gostava de se divertir, então a deixara brincar, para fazê-la feliz.

Afinal, Zhuyin já era praticamente um território que Qi poderia conquistar quando bem entendesse. Aos olhos de Lu Linyuan, não passava de um detalhe sem importância.

Ele nem precisava explicar suas intenções, mas receava que algum implicante aparecesse dizendo:

“Ah, tá vendo? Você sabia que Xiaoxiao tinha um poder especial e a usou de propósito para resolver a política do império! Que homem nojento!”

A isso, ele só teria uma resposta: — Minha mulher quis fazer isso! E você, seu encalhado, tem alguma coisa a ver com a nossa vida?!

*

Naquele ano, o melhor presente de Ano-Novo para o Império Qi foi Huyan Zhu atravessar mil léguas para, por conta própria, entregar seu país de bandeja: sem gastar um soldado sequer, Qi incorporara Zhuyin.

Tudo aquilo fora mérito de Ning Xiaoxiao.

Por isso, depois do banquete, ela se tornou o centro de todas as atenções.

Todos os ministros disputavam a oportunidade de brindar com ela e faziam elogios dos mais variados, sem repetir nenhum.

Na verdade, quando Lu Linyuan a promoveu inesperadamente a Consorte Nobre, as críticas na corte não cessaram, muito por instigação da família da imperatriz.

Havia montanhas de memoriais denunciando que a decisão imperial fora inadequada.

Lu Linyuan, porém, ignorara completamente todos os que se atreviam a questionar o posto dado a Ning Xiaoxiao.

Nem sequer escrevera uma resposta em tinta vermelha. Devolvera os memoriais intactos, para que os próprios autores refletissem sobre qual parte de suas palavras estava errada.

Mas, depois daquela façanha, todas as críticas a Ning Xiaoxiao caíram por terra.

Ela agora ocupava legitimamente o posto de Consorte Nobre, e ninguém ousava contestá-la.

Até porque, se alguém se atrevesse a reclamar, bastaria um soco dela para que só se reencontrassem na próxima encarnação...

❤

Quando o banquete terminou, Lu Linyuan ainda precisava discutir assuntos de Estado com os ministros. Depois de assistir aos fogos de artifício da meia-noite com Ning Xiaoxiao, pediu que ela voltasse primeiro para se preparar para dormir.

No trajeto de liteira de volta ao Pavilhão de Estudos Bitong, Ning Xiaoxiao pensava em como aquela Pílula de Força era maravilhosa.

O problema é que seus efeitos duravam vinte e quatro horas...

Ela continuava forte como um touro! Antes, só quisera dar uns soquinhos carinhosos no peito de Lu Linyuan. Quase transformara uma demonstração de carinho em viuvez...

Enquanto estivesse acordada, tudo bem: bastaria evitar o contato físico com ele.

Mas dormia de modo muito agitado. Se agarrasse Lu Linyuan durante a noite, ao amanhecer ele não estaria parecendo um boneco de Lego desmontado, com braços e pernas espalhados?

Só de imaginar, estremeceu e ordenou aos carregadores:

— Voltem ao Pavilhão Tingyu.

Quando a liteira parou, disse ainda a Xiao Yinzi, que a escoltara: — Avise Sua Majestade de que estou com sintomas de resfriado. Tenho medo de lhe transmitir a doença durante a noite, então vou dormir nos meus próprios aposentos.

Não se sabe se ela subestimava demais a importância que tinha para Lu Linyuan ou se toda aquela força extraordinária fora adquirida às custas da inteligência.

Se não tivesse dito que estava doente, talvez desse certo. Mas, agora que dissera, como Lu Linyuan poderia deixá-la dormir sozinha?

Além disso, passada a meia-noite, começara o primeiro dia do ano.

Como passar a primeira noite do Ano-Novo sem dormir abraçado à esposa?

Como era de esperar, assim que Xiao Yinzi transmitiu a mensagem, Lu Linyuan largou os ministros no salão sem pensar duas vezes e correu para o Pavilhão Tingyu.

Ning Xiaoxiao já dormia quando ele chegou. Qiqi explicou que preparara uma decocção contra o resfriado, que a senhora a bebera, suava depois do remédio e agora descansava. Por isso, Lu Linyuan não a acordou.

Depois de se lavar e tomar banho, subiu silenciosamente à cama de Ning Xiaoxiao, como um ladrão.

Deitou-se de lado, passou um braço delicadamente em volta da cintura dela e murmurou, muito baixinho:

— Meu bem, feliz Ano-Novo.

Era uma cena de ternura absoluta, até que Ning Xiaoxiao se virou e destruiu todo o clima romântico.

Ela tinha o velho costume de abraçar alguma coisa ao dormir. Antes, abraçava um travesseiro; agora, com um colchão humano ao lado, por que ficaria com o travesseiro?

Assim, enroscou braços e pernas em Lu Linyuan e o apertou com todas as forças.

Aquela posição de “abraço de urso” imediatamente o fez sentir que estava sufocando...

Tentou soltar os braços de Ning Xiaoxiao para escapar, mas descobriu que ela era mais forte que um boi. Os braços pareciam feitos de chumbo, impossíveis de mover.

O rosto dele ficou vermelho pela falta de ar, e uma premonição terrível lhe atravessou a mente:

Socorro! Será que o grande final de sua vida seria naquela noite...?

Preso no abraço de Ning Xiaoxiao, mal conseguia se mexer.

Também não tinha coragem de usar a força bruta contra a esposa. A única saída era recorrer à esperteza.

Empregando todas as forças, conseguiu liberar a mão direita por uma fresta de poucos centímetros. Então moveu os dedos com dificuldade e tocou de leve no “D”.

No instante seguinte, foi como se alguém tivesse acionado um interruptor no corpo de Ning Xiaoxiao. Ela estremeceu involuntariamente e esticou a perna direita, dando um chute que lançou Lu Linyuan da cama até embaixo de uma mesa, junto à porta do quarto...

Ela acordou sobressaltada, olhou em volta e não viu ninguém.

Achou que aquela sensação esquisita fosse uma ilusão de sonho e, como estava com muito sono, deitou-se novamente e continuou dormindo.

Pobre Lu Linyuan: depois daquele chute, bateu a cabeça e desmaiou ali mesmo, debaixo da mesa...

Na manhã seguinte, Ning Xiaoxiao acordou muito bem-disposta. Ao levantar-se para se lavar, encontrou Lu Linyuan dormindo debaixo da mesa.

Correu para acordá-lo, completamente confusa: — Majestade? Por que... por que está dormindo embaixo da mesa?

Lu Linyuan coçou a nuca, que ainda doía, e, sem saber o que dizer, tentou salvar sua dignidade:

— Eu... eu quis! E você tem alguma coisa a ver com isso?!

Então saiu debaixo da mesa com o rosto vermelho como o traseiro de um macaco e fugiu, todo envergonhado...

# Capítulo 257 — Xiaoxiao, a força da natureza, derrota todo mundo

O trio de “beldades letais”, Liu, Guan e Zhang, esfregava as mãos, ansioso para começar.

Mas diante da força absoluta, toda aquela encenação espalhafatosa não passava de palhaçada.

Ning Xiaoxiao bocejou preguiçosamente, fechou os olhos e apertou o botão Pausar.

Tirou a navalha de barbear e recitou mentalmente a “senha de acesso”, sendo transportada para o interior do espaço particular.

Sua intenção era apenas pegar uma Pílula de Força, engoli-la e sair. Mas, assim que entrou, ficou de queixo caído.

Quando recebera aquele espaço, tratava-se apenas de um cômodo enorme e completamente vazio.

Fazia muito tempo que não entrava ali e nem sabia quando tudo tinha mudado tanto.

A decoração era idêntica à de sua casa; havia televisão, computador e tudo mais. E o mais importante: eletricidade!

Ela se esticou na confortável caminha de sua própria casa, ligou a televisão para acompanhar uma série e pegou uma garrafa de Coca-Cola gelada da geladeira, bebendo-a em grandes goles.

Nem precisava perguntar: aquilo tudo certamente tinha sido preparado por seus pais.

Agora que tinha aquele espaço privativo, ainda precisaria temer o tédio dentro do palácio?

A cama estava tão gostosa que ela acabou cochilando. Quando despertou, meio grogue, lembrou-se de que tinha algo importante a fazer.

Então abriu uma gaveta, pegou a Pílula de Força e a engoliu com um gole de refrigerante.

Assim que a pílula chegou ao estômago, sentiu-se como o Popeye depois de comer espinafre: a força percorria seu corpo inteiro.

Naquele estado, arrancar um salgueiro do chão como a delicada Lin Daiyu seria fichinha. Se quisesse, talvez conseguisse desmontar o resort inteiro de águas termais.

Quando voltou do espaço e retomou a trama, Huyan Zhu a provocou:

— E então? Vamos começar?

— Qual das nossas consortes a Consorte Nobre pretende desafiar primeiro?

Ning Xiaoxiao segurou o pescoço, moveu a cabeça para os lados, estalando as articulações para se soltar. Em seguida, ergueu a mão e chamou os adversários com o indicador, desdenhosa:

— Estou com pressa. Nada de vir um por vez. Venham todas juntas.

Huyan Zhu soltou uma risada fria: — Que arrogância, Consorte Nobre! Todas juntas? Ha! Receio que não aguente! Primeiro, que a Consorte Zhang lhe mostre do que é capaz!

Alguns servos trouxeram uma mesa de madeira de huanghuali, que serviria de campo de batalha.

O huanghuali é uma madeira nobre, muito dura e caríssima.

Ning Xiaoxiao temeu que a mesa acabasse quebrando e desperdiçando material tão bom. Por isso, pediu: — Tragam uma mesa de ferro.

Ao ouvir aquilo, a Consorte Zhang soltou uma gargalhada sonora: — Hahaha! A mocinha é exigente, hein? Está com medo de que eu quebre a mesa e resolveu pedir uma que não quebre?

Ning Xiaoxiao apenas sorriu, sem responder à zombaria.

Quando trouxeram a mesa de ferro, Zhang esfregou as mãos e apoiou o cotovelo sobre ela.

Parecia um movimento leve, mas abriu uma funda depressão na superfície de ferro.

Lu Linyuan ficou alarmado. E se aquela brutamontes acabasse quebrando o braço de sua amada?

— Xiaoxiao, você...

— Não se preocupe, Majestade. Sei o que estou fazendo.

Antes mesmo que Lu Linyuan terminasse, ela já estava em posição.

Mas, em vez de estender a mão como Zhang, levantou apenas o dedo mínimo. Para levá-la ao limite da irritação, balançou o dedinho diante dela:

— Vou competir com você usando só este dedo mínimo. É melhor usar toda a sua força, ou vai fazer seu senhor Huyan passar vergonha.

Vendo como Ning Xiaoxiao estava segura de si, Lu Linyuan sabia que ela já tinha um plano, mesmo sem ouvir seus pensamentos.

Sua Xiaoxiao podia adorar fazer travessuras, mas não era nenhuma tola.

Os ministros, porém, não compreendiam aquela maluquice.

Começaram a murmurar: — Majestade! A Consorte Nobre está claramente brincando com coisa séria!

Lu Linyuan pegou um pêssego e o atirou no ministro que falara:

— E o que você tem com isso? Eu gosto!

— ...

A Consorte Zhang deu uma risadinha debochada: — Mocinha! Se está tão confiante, não vou pegar leve!

Aos olhos de Zhang, Ning Xiaoxiao parecia um pintinho frágil que jamais enfrentara uma tempestade.

Ainda assim, por respeito ao fato de ela ser a Consorte Nobre do imperador de Qi, Zhang não começou com toda a força, receando quebrar-lhe o braço e causar um incidente.

Achava que bastaria usar dez por cento da força contra um único dedo mínimo.

Mas, quando realmente começou a disputa, descobriu que nem dez por cento, nem cem por cento: mesmo usando toda a força, não conseguia mover um milímetro daquele dedo.

Ela fez cada vez mais força, apertou os dentes e suou em bicas, com a expressão de quem tentava vencer uma prisão de ventre diante de toda a corte.

Ning Xiaoxiao continuava relaxada. Chegou até a bocejar: — Irmã Zhang, se estiver difícil, pode usar as duas mãos.

Zhang obedeceu, segurando o dedo mínimo de Ning Xiaoxiao com as duas mãos e puxando com tudo.

A cena fez até o coração de Lu Linyuan disparar. Ning Xiaoxiao, porém, assobiava e cantarolava sem qualquer preocupação, como se o esforço de Zhang nem sequer bastasse para fazer cócegas.

Os ministros estavam boquiabertos. Até Huyan Zhu, que já contava com a vitória, ficou pasmo. Ao perceber que Zhang estava prestes a perder a força, ordenou que Liu Bei e Guan Yu entrassem também:

— A Consorte Nobre disse que enfrentaria as três! O que vocês estão esperando? Vão ajudá-la, já!

Naquele dia, o Terraço Biyun foi palco de uma visão completamente absurda.

Três consortes de Zhuyin, cada qual mais musculosa que um homem fortíssimo, uniram forças e mesmo assim não conseguiam dobrar o dedo mínimo de Ning Xiaoxiao.

Acabaram até começando a gritar em coro: — Um, dois, três! Força!

Ning Xiaoxiao as observava como quem assistia a macacos fazendo graça. Zombou: — É só isso?

Deu um risinho e continuou: — Já usaram toda a força? Então chegou a minha vez de reagir, viu?

Ao terminar, deu um peteleco displicente com o dedo mínimo. As três consortes de Zhuyin saíram voando e caíram empilhadas sobre Huyan Zhu, que revirou os olhos e começou a espumar pela boca sob o peso delas.

Depois de um instante de choque, os ministros começaram espontaneamente a aplaudir, produzindo um estrondo que parecia não ter fim.

— Viva a Consorte Nobre!

— Muito bem, Consorte Nobre!

Em meio àquela avalanche de elogios extravagantes à sua amada, Lu Linyuan começou a questionar a própria existência.

Até Lu Yiqiu precisou cochichar para Ren Duanli: — Meu Deus! Xiao Lili, você viu aquilo?!

Enquanto admirava a coragem heroica da cunhada, começou também a ficar um pouco preocupado com Lu Linyuan:

— Se minha cunhada é tão forte assim, será que o bastão do meu irmão não vai quebrar...?

Ren Duanli franziu as sobrancelhas e perguntou, incisivo: — Você já viu o do seu irmão?

— Hã? Não... Só tomamos banho juntos quando éramos crianças, mas isso foi há uns oitocentos anos! Já esqueci tudo...

Ao ouvir a explicação, a expressão de Ren Duanli finalmente se abrandou. — Cuide de si mesmo e pare de se meter na intimidade dos outros.

Então pegou com os próprios hashis um pedaço de carne bovina grelhada e o ofereceu a Lu Yiqiu, que continuava distraído acompanhando o espetáculo.

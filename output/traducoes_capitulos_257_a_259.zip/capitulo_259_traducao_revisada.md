# Capítulo 259 — Presentes de Ano-Novo

Diz um ditado popular que tudo o que se faz no primeiro dia do ano acaba se repetindo durante os doze meses seguintes.

Por exemplo, quem dorme até tarde nesse dia ficará sem energia o ano inteiro;

quem não comer o suficiente passará o ano sentindo fome...

Ou, por exemplo, quem levar um chute da esposa e cair da cama nesse dia passará o ano inteiro...

*

O Ano-Novo sempre foi a data mais importante para o povo.

Nesse dia, as pessoas trocam presentes para desejar que tudo corra bem no ano que se inicia.

Lu Linyuan começara a preparar o presente de Ning Xiaoxiao havia muito tempo.

Coisas que podiam ser compradas com dinheiro não demonstravam seu verdadeiro sentimento. O essencial era fazer algo que ela adorasse.

Desde que chegaram ao resort de águas termais, ele passava quase todas as manhãs, supostamente, cuidando dos assuntos de Estado, enquanto mandava Ning Xiaoxiao brincar com a princesa mais velha ou com Ren Duanli e os outros.

Só que o trabalho não era tão pesado assim. Ele usava a desculpa para afastá-la e reservar diariamente uma hora para ter aulas de culinária com os cozinheiros imperiais.

Aprenderia apenas três pratos: “Buda Salta o Muro”, camarões de jade branco e esmeralda e sopa de ovas de peixe.

Os três eram os favoritos de Ning Xiaoxiao. Talvez, em outra vida, ela tivesse sido uma sereia: bastava ver frutos do mar que não conseguia mais sair do lugar.

Mas era exigente. Adorava o sabor fresco dos frutos do mar, porém detestava qualquer cheiro forte de peixe.

Por isso, só a preparação dos ingredientes já dava um trabalho enorme.

Lu Linyuan nunca cozinhara. Sua obsessão por limpeza fazia com que rejeitasse instintivamente o cheiro de óleo e fumaça da cozinha.

A primeira vez que entrara numa pequena cozinha fora para preparar chá de gengibre com açúcar mascavo para Ning Xiaoxiao.

Depois, na primeira aula em que o cozinheiro imperial lhe ensinou a refogar, a fumaça do óleo o fez ter ânsia de vômito repetidas vezes.

Nem ele sabia de onde tirara tanta perseverança para aguentar quase um mês inteiro de aulas diárias na cozinha.

Na manhã do primeiro dia do primeiro mês lunar, Qingyang e Huanü levaram Ning Xiaoxiao para admirar as flores recém-desabrochadas do jasmim-de-inverno.

Os três pratos favoritos dela exigiam muito tempo de preparo. O “Buda Salta o Muro”, em especial, precisava de seis a oito horas de cozimento lento antes de poder ser servido.

Por isso, ele acordara cedíssimo para preparar os ingredientes e aguardara que Ning Xiaoxiao saísse para levar tudo ao Pavilhão Tingyu.

Quando ela voltou perto do meio-dia, bastou entrar pelo portão para sentir um aroma delicioso espalhado por todo o jardim.

Sua barriga de comilona roncou. Cheia de expectativa, estalou os lábios e segurou Qiqi, animada:

— Qiqi, está sentindo? Que cheiro bom!

Qiqi sorriu: — Hoje é o primeiro dia do ano. Sua Majestade certamente mandou os cozinheiros prepararem os pratos favoritos da senhora. Ele sempre pensa tanto na senhora que nem me surpreendo mais~

Senhora e criada entraram no salão principal conversando e rindo. Assim que passaram pela porta, viram Lu Linyuan usando um avental manchado de óleo, com algumas marcas de fuligem no rosto, colocando uma terrina fumegante de “Buda Salta o Muro” sobre a mesa.

Ele olhou por cima do ombro e a chamou: — Venha, venha! Coma enquanto está quente!

Ning Xiaoxiao ficou imóvel por um instante. — Foi você quem fez tudo isso?

Lu Linyuan ergueu uma sobrancelha, confiante. — Quem mais seria?

Naquele instante, Ning Xiaoxiao teve a impressão de enxergar a figura de Ning Dazhi em Lu Linyuan.

Antes, ela sempre pensara que Ning Dazhi mimava demais sua mãe. Tendo crescido num lar onde os pais viviam trocando demonstrações de carinho, e achando que homens bons como ele estavam praticamente extintos, acreditava que, não importava quem escolhesse como parceiro, acabaria tendo de se contentar com menos do que merecia.

Não imaginara que a sorte da mãe no amor pudesse se repetir com ela.

Naquele momento, o que Lu Linyuan fizera já nem importava. Se a comida estava gostosa, importava menos ainda.

O que importava era o carinho por trás do gesto.

Ning Xiaoxiao se aproximou, retirou o lenço bordado preso à cintura e limpou as manchas de fuligem no rosto dele:

— A-Yuan não detesta cozinhar mais do que tudo?

Ele assentiu sem negar, mas sorriu e acariciou a cabeça dela:

— Só que A-Yuan ama Xiaoxiao mais do que tudo.

❤

Qiqi não aguentava mais assistir àquele almoço.

Lu Linyuan tratava Ning Xiaoxiao como se ela não fosse capaz de mover um dedo, alimentando-a colherada por colherada e soprando a comida antes de cada garfada, com medo de que sua preciosidade se queimasse.

Ning Xiaoxiao também preparara um presente para ele.

Não tinha talento para bordado ou costura, mas queria fazer alguma coisa com as próprias mãos.

Qiqi dissera que um cachecol era a peça mais fácil para uma iniciante. Então a ensinara pacientemente, ponto a ponto, e Ning Xiaoxiao passara um mês inteiro tricotando até terminar.

Depois do almoço, quando se preparavam para a sesta, ela entregou o presente a Lu Linyuan e o colocou pessoalmente em volta de seu pescoço.

Os pontos eram tortos, o modelo era rudimentar e havia buracos dentro de buracos. Parecia uma relíquia deixada pelo chefe da Seita dos Mendigos.

Mesmo assim, Lu Linyuan se olhou no espelho com o cachecol e não parou de elogiá-lo.

Ning Xiaoxiao ficou vermelha com tantos elogios. — Isso só tem defeitos, mas você fala como se fosse uma maravilha. Pelo visto, todas aquelas coisas bonitas que me disse antes também não passaram de palavras da boca para fora.

— Que bobagem. Xiaoxiao tricotou isto para mim com as próprias mãos. Só pelo carinho envolvido, já é o melhor presente do mundo.

O resort de águas termais era o lugar mais quente de Qi. Enquanto no palácio a primavera mal começara, ali o clima já parecia de fim de primavera, quase verão.

As roupas de todos já eram leves. Com aquele cachecol felpudo no pescoço, Lu Linyuan começou a suar em bicas.

— Se tiver de apontar um defeito, é que o inverno já está acabando. Só poderei usar seu presente quando chegar o inverno do próximo ano.

Ele ficou pensativo por um instante. Então pareceu ter uma ideia e encarou Ning Xiaoxiao com um sorriso malandro:

— Se eu ganhasse uma peça de roupa íntima feita pelas mãos de Xiaoxiao, seria ainda melhor.

Ergueu uma sobrancelha, e a malícia em seu sorriso ficou mais evidente. — Entendeu o que quero dizer?

Roupa íntima...

Ele não usava dudou, então só podia estar falando de cueca.

Ao lembrar da missão que Xiao Qi lhe dera no passado — entrar no quarto dele para roubar uma cueca e acabar com uma delas pendurada na cabeça enquanto estava escondida no armário —, ela estremeceu.

Aquele armário cheio de cuecas fora uma revelação. Se ele não tocasse no assunto, ela quase teria esquecido a mania de colecionar roupas íntimas que ele parecia ter.

Fazer uma cueca devia ser muito mais fácil do que tricotar um cachecol, não?

Era só recortar um tecido macio e confortável e depois bordar alguma figura, como um pintinho bicando grãos de arroz, e pronto!

Como era Ano-Novo, Ning Xiaoxiao aceitou prontamente.

Não esperava, porém, que ele fosse querer mais. Com a voz baixa e insinuante, ele disse: — Mas, para fazer roupas, primeiro é preciso saber as medidas.

Ning Xiaoxiao: — ??? Hã? Mas... uma coisa não tem muito a ver com a outra, tem?

— Como não? — Lu Linyuan brincou com os fios de cabelo junto à orelha dela, deixando os dedos percorrerem sua borda.

— Se ficar pequena, vai apertar, comprimir e incomodar o corpo inteiro.

Ele se aproximou, com um sorriso atrevido e a língua encostada na parte interna do maxilar:

— Por que você não mede pessoalmente?

— Com a mão.

Ah, isso...

Ter vergonha era coisa da época em que tinham acabado de se conhecer. Depois de tanto tempo juntos sem nenhuma cerimônia, continuar se envergonhando já seria quase falta de educação.

Já que você me fez um convite tão sincero, não me resta senão aceitar com toda a consideração!

Ela respirou fundo e lentamente estendeu a mão...

# Validação — Capítulo 259

- Fonte: `novel_capitulos_212_a_270(20261105-204934).docx`, chinês tradicional.
- Intervalo de índices reais do documento: 3342–3419 (base zero; vazios excluídos).
- Unidades não vazias do original: **75** (título incluído).
- Linhas de cotejo: **75**, cabeçalho `indice_docx,original_chines,traducao_portugues`.
- Índices reais únicos, em ordem crescente: **sim**.
- Lacunas relativamente aos parágrafos não vazios da fonte: **nenhuma**.
- Campos vazios: **nenhum**.
- Tradução integral gerada em arquivo Markdown; diálogo e notas preservados na ordem documental.

## Decisões editoriais

O título é “Presentes de Ano-Novo”. 佛跳牆 foi mantido transliterado semanticamente como “Buda Salta o Muro”, prato de preparo prolongado; 三四個時辰 equivale a seis a oito horas, 半個時辰 a uma hora. O termo 內酷 é grafia jocosa de “cueca” e a referência ao dudou foi preservada. O capítulo termina em suspensão, sem completar a cena íntima. As notas culturais são comentários editoriais, não notas adicionadas ao texto da autora.

## Limitações

O alinhamento 1:1 e a comparação de contagens atestam cobertura estrutural; não equivalem a segunda auditoria semântica independente. Adaptações de trocadilhos preservam o efeito, mas não necessariamente a mesma forma fonética.

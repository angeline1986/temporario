# Validação — Capítulo 258

- Fonte: `novel_capitulos_212_a_270(20261105-204934).docx`, chinês tradicional.
- Intervalo de índices reais do documento: 3266–3341 (base zero; vazios excluídos).
- Unidades não vazias do original: **73** (título incluído).
- Linhas de cotejo: **73**, cabeçalho `indice_docx,original_chines,traducao_portugues`.
- Índices reais únicos, em ordem crescente: **sim**.
- Lacunas relativamente aos parágrafos não vazios da fonte: **nenhuma**.
- Campos vazios: **nenhum**.
- Tradução integral gerada em arquivo Markdown; diálogo e notas preservados na ordem documental.

## Decisões editoriais

O comentário sobre críticos que chamariam o imperador de manipulador é um aparte metanarrativo; manteve-se a voz jocosa sem atribuí-la ao julgamento do narrador sobre o protagonista. O termo “D” no episódio do sufocamento é uma alusão corporal não explicitada pelo chinês; foi mantido como letra, sem completar o referente. O jogo 強人鎖男 (trocadilho com 強人所難) foi adaptado como “abraço de urso”, com perda do trocadilho fonético chinês. O episódio distingue o resfriado alegado por Ning das consequências reais da Pílula de Força.

## Limitações

O alinhamento 1:1 e a comparação de contagens atestam cobertura estrutural; não equivalem a segunda auditoria semântica independente. Adaptações de trocadilhos preservam o efeito, mas não necessariamente a mesma forma fonética.

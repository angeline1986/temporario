# Validação — Capítulo 257

- Fonte: `novel_capitulos_212_a_270(20261105-204934).docx`, chinês tradicional.
- Intervalo de índices reais do documento: 3193–3265 (base zero; vazios excluídos).
- Unidades não vazias do original: **70** (título incluído).
- Linhas de cotejo: **70**, cabeçalho `indice_docx,original_chines,traducao_portugues`.
- Índices reais únicos, em ordem crescente: **sim**.
- Lacunas relativamente aos parágrafos não vazios da fonte: **nenhuma**.
- Campos vazios: **nenhum**.
- Tradução integral gerada em arquivo Markdown; diálogo e notas preservados na ordem documental.

## Decisões editoriais

O título 大力瀟瀟，亂殺 foi adaptado para expressar o registro de gíria de jogos: força desmedida e vitória esmagadora. 林黛玉倒拔垂楊柳 ironiza a fragilidade de Lin Daiyu com uma façanha tradicionalmente associada a Lu Zhishen; preferiu-se manter a referência cultural. 劉貝 e 莞羽 são grafias deliberadamente diferentes dos heróis históricos 劉備 e 關羽; mantidos os nomes consagrados em português, mas registrada a variante. A conversa final sobre o “bastão” de Lu contém uma insinuação sexual, conservada. O título de Ning é Consorte Nobre.

## Limitações

O alinhamento 1:1 e a comparação de contagens atestam cobertura estrutural; não equivalem a segunda auditoria semântica independente. Adaptações de trocadilhos preservam o efeito, mas não necessariamente a mesma forma fonética.

# Capítulo 286 — O pequeno Gu finalmente teve um final feliz

Palácio Fengyi.

Na manhã daquele dia, ao saber que Ren Duanli havia retornado ao palácio são e salvo depois de derrotar Tong Guowei, Gu Sijin se emocionou tanto que não parava de chorar.

Essa foi a única vez em que ela não foi prestar suas homenagens à Imperatriz, mas sim ao Templo de Fahua para queimar incenso e agradecer aos deuses por sua proteção.

Quando Ning Xiaoxiao foi prestar seus cumprimentos à imperatriz no Palácio Fengluan, ela perguntou: “Por que a Nobre Dama Gu não veio hoje?”

Ning Xiaoxiao lançou-lhe um olhar e respondeu com um sorriso frio: “Se ela não quis vir, não veio, ora. Ninguém recebe salário para prestar cumprimentos à senhora. Para que aparecer aqui com tanta frequência?”

“......”

A imperatriz ficou surpresa com as palavras dela e, após uma longa pausa, disse com desagrado:

“Consorte Nobre, antigamente você ao menos respeitava as regras. Por que, desde que recebeu esse título, vem se tornando cada vez mais insolente?”

Ning Xiaoxiao ergueu uma sobrancelha. “Eu também gostaria de seguir as regras na sua presença, mas ouvi esta manhã que alguém envenenou a comida da Concubina Tong. A alimentação dela sempre esteve sob a responsabilidade da imperatriz. Não vou nem investigar como o veneno foi parar ali. Só há um detalhe: o imperador não decretou a morte da Concubina Tong. A senhora não pretende passar por cima da autoridade dele e decidir por conta própria, pretende?”

A Imperatriz não esperava que Ning Xiaoxiao fosse indagar sobre esse assunto.

Na opinião da imperatriz, Ning Xiaoxiao e a Concubina Tong eram inimigas irreconciliáveis; tinha certeza de que Ning também desejava a morte dela.

Naquela manhã, ao saber da queda da família Tong, a imperatriz finalmente pôde respirar aliviada depois de tantos anos suportando as humilhações da Concubina Tong.

Por isso, mandara envenenar a comida da Concubina Tong, querendo matá-la.

Mas Ning Xiaoxiao percebera suas intenções desde cedo. Por precaução, pedira a Qiqi que vigiasse a comida enviada ao palácio de Tong, e assim o veneno fora interceptado.

Sem sequer tentar esconder o que fizera, a imperatriz sorriu: “Na audiência desta manhã, o imperador condenou as nove gerações do clã Tong ao extermínio. A Concubina Tong também merece morrer. Só estou ajudando Sua Majestade a cumprir a sentença.”

“Não tente enfeitar essa sua cara velha para parecer virtuosa.” Ning Xiaoxiao revirou os olhos. “Você sabe perfeitamente se está ajudando o imperador ou aproveitando a oportunidade para acertar contas pessoais.”

Ela se levantou de súbito, falando com firmeza: “Escute bem: ao se casar com o imperador, Tong Yuanyuan passou a pertencer à família imperial, e não mais ao clã Tong. Cabe ao imperador decidir se ela vive ou morre. Com essa mania de usurpar a autoridade alheia, quem não souber da história vai pensar que você quer imitar a imperatriz Wu Zetian e tomar o lugar do próprio soberano!”

A Imperatriz ficou furiosa: "Você..."

Ning Xiaoxiao nem lhe deu a chance de terminar. Antes que a imperatriz conseguisse completar aquele “você”, ela já havia dado meia-volta e saído.

*

Ao retornarem ao Palácio Fengyi, ela e Gu Sijin entraram quase um após o outro.

Ao ver Gu Sijin hoje, ela estava completamente diferente da melancolia que demonstrava ontem à noite.

Ning Xiaoxiao pegou em seu braço e passeou pelo pátio. "Irmã, algo te deixou feliz? Você não consegue esconder o sorriso no rosto. Por que não me conta?"

Gu Sijin riu e disse: "De jeito nenhum! Você só está me provocando."

Ning Xiaoxiao segurou a mão dela, com os olhos cheios de ternura, como se tivesse sido tocada por água de nascente.

"Você está feliz, irmã? Eu posso te fazer ainda mais feliz."

Gu Sijin olhou para ela com um toque de confusão em seus olhos sorridentes, sem entender o que estava acontecendo.

Ela não deixou Gu Sijin em suspense por mais tempo e sussurrou em seu ouvido:

"Você manteve seu caso com Chu Xingran em segredo de mim. Tem medo de que eu conte ao Imperador? Ou tem medo de que eu trame contra você como outros já fizeram?"

Gu Sijin pensou que tinha guardado segredo perfeitamente e que ninguém jamais descobriria.

Afinal, da última vez que a Consorte Yun descobrira seu segredo, Gu Sijin dera um fim nela com as próprias mãos.

Mas, agora, quem sabia era Ning Xiaoxiao. Gu Sijin jamais conseguiria fazer mal a ela, embora estivesse apavorada.

"Xiaoxiao...você já sabia de tudo?"

Ning Xiaoxiao assentiu em concordância, assumindo deliberadamente uma expressão severa para assustá-la: "Não sou só eu, o Imperador também sabia disso há muito tempo. Chu Xingran ousa cobiçar a mulher do Imperador, está cortejando a morte!"

"Vossa Majestade? O que Vossa Majestade fez com ele?" Gu Sijin agarrou o braço de Ning Xiaoxiao com força, e seus olhos imediatamente ficaram vermelhos.

Um pensamento chegou a passar pela sua cabeça: se Lu Linyuan descobrisse sobre o relacionamento deles e executasse Chu Xingran, ela não culparia Ning Xiaoxiao; simplesmente cometeria suicídio ali mesmo e iria com seu amado.

Inicialmente, Ning Xiaoxiao planejava entrar na brincadeira, mas ao ver que ela estava quase chorando, também entrou em pânico.

Ela imediatamente abraçou Gu Sijin e pediu desculpas: "Me desculpe, não chore... Eu estava apenas brincando..."

“Ai, a culpa é minha!” Ela deu um tapinha nos próprios lábios. “Não vou mais fazer suspense! A verdade é que o imperador decidiu permitir que vocês fiquem juntos.”

Ao ouvir isso, Gu Sijin sentiu um súbito entorpecimento, semelhante a um choque elétrico, por todo o corpo.

Ela ficou paralisada, incapaz de se mover, e só conseguiu perguntar com a voz trêmula: "O que... o que você disse?"

“Eu disse que o imperador permitiu que vocês fiquem juntos!”

Ning Xiaoxiao elevou deliberadamente a voz, fazendo Gu Sijin estremecer.

"Como... como isso pôde acontecer?"

Ning Xiaoxiao riu. “O imperador e Chu Xingran são amigos desde a infância. Dizem que quem cobiça a mulher do amigo acaba atingido por um raio. Como o imperador não quer levar um raio, resolveu entregar você a Chu Xingran~”

Gu Sijin mal podia acreditar no que ouvia.

Naquela época de costumes feudais, Gu Sijin ouvira falar de consortes enviadas para casamentos diplomáticos, mas nunca de um soberano que concedesse uma de suas próprias mulheres a um funcionário da corte...

Gu Sijin perguntou várias vezes a Ning Xiaoxiao antes que ela se atrevesse a confirmar que nada daquilo era uma alucinação, mas sim um evento real.

Depois de esperar por tanto tempo, ela finalmente conseguiu o que tanto desejava.

As lágrimas brotaram instantaneamente e logo ela estava em prantos.

Foi preciso Ning Xiaoxiao consolá-la durante algum tempo. Por fim, Gu Sijin deu-lhe um tapinha no ombro e reclamou entre lágrimas, com uma vozinha que tentava soar feroz:

"Você é tão cruel... O que você está fazendo... Por que fez tudo isso por mim sem dizer uma palavra? Eu sei, você deve ter implorado ao Imperador por tudo isso... Eu..."

“Se continuar falando assim, já vai ser sentimentalismo demais!” Ning Xiaoxiao beliscou sua bochecha e enxugou suas lágrimas com um lenço. “O imperador e eu nos amamos. Você é tão bonita que eu não teria sossego com você aqui dentro! Preciso despachá-la logo do palácio: uma rival a menos, uma preocupação a menos!”

Ela falou com tanta seriedade, mas Gu Sijin, é claro, não acreditou nela.

Não é segredo que Lu Linyuan só tem olhos para Ning Xiaoxiao.

Ela estava tomada pela emoção, sentindo apenas gratidão. Era grata ao destino, à sua própria perseverança e à firmeza de Chu Xingran, à benevolência de Lu Linyuan e ainda mais grata pela 'mão amiga' de Xiaoxiao.

Ela ficou momentaneamente atordoada. Nunca tivera uma amiga íntima na primeira metade da sua vida, e Ning Xiaoxiao era a primeira pessoa que podia chamar de amiga.

O que a torna tão especial a ponto de ter uma irmã que sempre a coloca em primeiro lugar?

No entanto, ela se esqueceu de que, no início, era Ning Xiaoxiao quem se mostrava hostil e desconfiada dela, chegando até mesmo a detestá-la, considerando-a uma santa flor de lótus branca.

Foi seu coração sincero que lhe rendeu uma amiga tão compreensiva.

Tudo o que ela tem hoje é o que ela merece.

(A situação na corte finalmente se resolveu! Vou deixar meu filho aproveitar a vida mais alguns dias; depois, minha filha engravida e logo se torna imperatriz!!)

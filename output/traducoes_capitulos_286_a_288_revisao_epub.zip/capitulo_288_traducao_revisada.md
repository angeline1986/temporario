# Capítulo 288 — Seus dias de sorte ainda estão por vir

A princípio, depois de Ning Xiaoxiao interceder por ela, Lu Linyuan pretendia permitir que a Concubina Tong deixasse o palácio.

Mas a decisão de Lu Linyuan não nascera de qualquer compaixão pela Concubina Tong.

Ele era frio por natureza e não costumava se colocar no lugar dos outros. Só se lembrava de que a Concubina Tong fizera sua esposa chorar.

Podia ser magnânimo diante dos assuntos do império, mas, se alguém maltratasse sua esposa, pouco importava se essa pessoa tinha suas razões ou um passado lamentável: para ele, não merecia continuar viva.

Permitir que a Concubina Tong deixasse o palácio não seria muito diferente de condená-la à morte.

Desde que entrara no palácio, cinco anos antes, ela passara quatro anos e meio ridicularizando, provocando e humilhando a imperatriz.

E a imperatriz não era conhecida pela generosidade. Se a Concubina Tong saísse do palácio, os assassinos enviados pela família da imperatriz provavelmente a matariam antes que encontrasse um lugar para morar.

É claro que Lu Linyuan percebeu essas coisas num piscar de olhos, e Ning Xiaoxiao também não era boba.

Por isso, Ning Xiaoxiao pediu a Lu Linyuan que confinasse a Concubina Tong no Palácio Frio e não permitisse que saísse.

Ao menos, se ela permanecesse no palácio, poderia salvar sua vida.

A Concubina Tong foi transferida para o Palácio Frio naquela mesma noite. Ning Xiaoxiao foi visitá-la.

Xianglan, que sempre a servira, fora espancada até a morte. Embora fosse uma criada, era a única pessoa no palácio com quem Tong podia conversar sinceramente.

Na imensidão do Palácio Frio, agora só restava ela. Teria de cuidar sozinha de sua alimentação, suas roupas e seus afazeres — um castigo considerável para uma jovem criada com tantos mimos.

Quando Ning Xiaoxiao chegou, a Concubina Tong estava sentada diante de uma mesa de pinho que começava a mofar, vestida com roupas simples. A lua projetava no rosto pálido dela as sombras entrelaçadas dos galhos.

Ela ainda estava viva, mas parecia ter definhado.

Desde que entrara no palácio, Ning Xiaoxiao nunca a vira com aparência tão despojada.

Ela retirou suas joias luxuosas e frias, o rosto descoberto e sem maquiagem, os cabelos negros e espessos presos simplesmente com um grampo de madeira.

Sem os adornos, quase toda a agressividade desaparecera de sua expressão. Parecia apenas uma jovem de dezesseis ou dezessete anos, com uma delicadeza que Ning nunca lhe notara antes.

Ao ouvir o barulho, ela ergueu os olhos e olhou em direção à porta.

Ning Xiaoxiao ficou parada em silêncio em frente à porta, observando-a.

Elas trocaram um olhar, e ela sorriu de repente: "Pensei que seria a Imperatriz que viria."

Ela falou em tom calmo, sem qualquer traço de sua antiga arrogância.

“Quando Xiao Yinzi me trouxe ao Palácio Frio, contou tudo. Eu deveria ter morrido, mas você convenceu o imperador a poupar minha vida.”

“Sei o que está pensando. Você me odeia tanto que prefere não me ver morrer; quer que eu apodreça aqui, isolada pelo resto da vida. Não é isso?”

Ning Xiaoxiao balançou a cabeça. “Você acha que eu perderia tanto tempo e esforço só por sua causa? Sim, houve uma época em que a odiei, mas, depois de conhecer sua história, consegui deixar aquilo para trás.”

“Cada dia desde que você entrou no palácio tem sido um tormento sem fim. O que você me devia foi totalmente pago com a destruição do clã Tong.”

“Eu não lhe devo nada.” Tong Yuanyuan sorriu com frieza. “As mulheres que entram no palácio estão condenadas a lutar umas contra as outras por toda a vida. Não consegui conquistar o coração do imperador e perdi para você. Aceito a derrota.”

Ela deixara de lado as amarras do status de concubina. Já não usava o solene “esta consorte” para se referir a si mesma: dizia simplesmente “eu”.

Também abandonou os modos rígidos ensinados pela família desde pequena. Recostou-se languidamente na cadeira e voltou os olhos para a lua fria além da janela.

"Sabe, quando soube que toda a família Tong tinha sido dizimada e que meu pai tinha sido espancado até a morte na corte imperial, pensei que ficaria com o coração partido e choraria muito. Mas não consegui chorar."

Banhada pelo luar comovente, ela sorriu de repente. "Naquele instante, senti-me incrivelmente relaxada e à vontade. Era como se eu pertencesse completamente a mim mesma."

"Eu nunca me pertenci antes, e só agora percebo como é maravilhoso ser eu mesma."

Um pisco-de-peito-ruivo pousou num galho, atraindo seu olhar.

O pássaro estava empoleirado num galho, alisando suas belas penas com o bico afiado, enquanto uma brisa agitava as folhas recém-brotadas no topo das árvores.

Assustado, o pássaro abriu as asas e voou. Em instantes ultrapassou o pequeno quadrado de céu delimitado pelas muralhas do palácio.

“Antes de você ganhar destaque, todos me viam como uma consorte poderosa, abaixo apenas do imperador e, às vezes, até acima da imperatriz. Achavam que eu era uma das mulheres mais felizes do mundo.”

"Sou jovem, bonita e tenho uma origem familiar que outros jamais conseguiriam alcançar, mesmo após inúmeras reencarnações. Parece que tenho tudo."

"Mas só eu sei que não passei de um fantoche da família Tong durante toda a minha vida."

“Pode rir se quiser. Tenho vinte anos e, em toda a vida, só conheci dois lugares. Quando era menina, meu pai me proibia de sair de casa. Depois que vim para o palácio, nunca mais pude atravessar estas muralhas.”

Ela fez uma pausa por um instante, balançou a cabeça tristemente e depois riu com autodepreciação:

"Viver assim é extremamente entediante."

Ning Xiaoxiao ouviu em silêncio enquanto ela relatava sua história de vida, sentindo-se profundamente comovida.

Ela não se comovia apenas com o destino de Tong Yuanyuan, mas com o de todas as mulheres que passavam a vida aprisionadas pelas normas e pelos rituais daquele sistema feudal.

Para aquelas mulheres, a liberdade muitas vezes valia mais do que a própria vida.

“Na verdade, o imperador havia permitido que você deixasse o palácio. Fui eu que pedi que a mandasse para o Palácio Frio. Você ofendeu a imperatriz; se cruzar os portões do palácio, estará seguindo para a morte.”

“Mas sua vida pertence a você. Ninguém tem o direito de escolher por você. Se quiser ir embora, posso interceder novamente junto ao imperador. Amanhã mesmo você poderá sair.”

Tong Yuanyuan ficou surpresa; ela não esperava que Ning Xiaoxiao a tratasse dessa maneira.

Ela ponderou por um instante, depois ergueu os olhos extremamente cansados e olhou para ela com um olhar travesso.

“É surpreendente ouvir isso de você. Parece que, depois de tanto tempo com Gu Sijin, até resolveu imitá-la e posar de bodisatva venerada num templo.”

"No entanto, agradeço por você ter me contado tanto. Quebrei de propósito a pulseira que sua mãe lhe deu e peço desculpas por isso."

“Quanto a sair do palácio, deixe para lá. Não sei fazer nada para ganhar a vida. Mesmo que a imperatriz não me mande assassinar, acabarei morrendo de fome na rua. Aqui, ao menos, ainda posso comer até ficar satisfeita.”

Foi uma escolha dela, então Ning Xiaoxiao não disse muito. Apenas disse para ela se cuidar antes de se virar e ir embora.

Depois que ela saiu, Tong Yuanyuan caminhou até a penteadeira coberta de teias de aranha, ergueu a mão para limpar a grossa camada de poeira do espelho de bronze e olhou semicerrando os olhos para o seu reflexo.

Ela não se olhava no espelho há muito tempo, mas a pessoa que via agora lhe era completamente desconhecida.

Ela respirou fundo, forçou um sorriso e murmurou:

“Passei a vida sem dever nada a ninguém. Não vou começar agora, aceitando a caridade de outra pessoa.”

“A gentileza que me ofereceu hoje, seja qual for o motivo, eu a retribuirei por inteiro.”

Como se de repente se lembrasse de algo, seu sorriso tornou-se sinistro:

“Ning Xiaoxiao, seus dias de sorte ainda estão por vir.”

# Validação do capítulo 288

- **Original chinês:** `novel_capitulos_271_a_300(20261106-202952).docx`.
- **Tradução-base portuguesa:** `novel capitulos 271 a 300 - ch.epub`, capítulo 288.
- **Intervalo de índices reais do DOCX:** 1158–1220 (base zero, incluindo parágrafos vazios).
- **Unidades não vazias no chinês:** 60 (inclui título).
- **Parágrafos de corpo não vazios no EPUB:** 59; título em H1.
- **Correspondência:** 60 pares no CSV; índices únicos, preservados, com título e unidades de corpo alinhados.

## Revisão editorial

Foi usada a versão portuguesa do EPUB como base, com correções focalizadas confrontadas com o original chinês. Foram revisados **32 parágrafos específicos** do capítulo, além de padronização pontual dos tratamentos Concubina Tong e Nobre Dama Gu.

**Destaques:** corrigidos os pronomes e a trajetória da Concubina Tong, o perigo de sair do palácio, o tratamento da identidade e posição de Tong Yuanyuan, a questão da escolha pessoal e o sentido da retribuição prometida.

## Escopo e limitações

**Verificação estrutural de todas as unidades:** feita. **Conferência semântica integral, frase a frase e independente:** não realizada. O texto conserva passagens do EPUB não reescritas, que podem conter erros lexicais ou nuances ainda não detectadas. O alinhamento 1:1 é estrutural e não prova exatidão semântica.

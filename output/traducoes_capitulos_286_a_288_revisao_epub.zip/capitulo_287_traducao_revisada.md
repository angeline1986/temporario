# Capítulo 287 — Perdoar quando é possível perdoar

Escapar dessa gaiola dourada e casar-se com seu amado era algo com que Gu Sijin sempre sonhou.

Agora que essa fantasia aparentemente inatingível estava prestes a se tornar realidade, ela sentiu alegria apenas por um instante antes de voltar a ficar em silêncio, com as pálpebras pesadas e os lábios finos ligeiramente franzidos, como se tivesse o coração pesado.

Ela pegou a mão de Ning Xiaoxiao e entrelaçou seus mindinhos, "Mas... depois que eu sair do palácio, será difícil te ver de novo."

Ela ergueu os olhos e encontrou o olhar de Ning Xiaoxiao. Os olhinhos da coelhinha branca estavam vermelhos, e ela parecia prestes a chorar novamente.

"Xiaoxiao, não consigo suportar me separar de você..."

Ela é uma pessoa extremamente reservada, mas naquele momento não hesitou em revelar seus verdadeiros sentimentos.

Ela abraçou Ning Xiaoxiao com força, a cena tão comovente que qualquer um que não soubesse da situação pensaria que elas estavam prestes a ser separadas pela vida e pela morte...

Como a maior inimiga do melodrama em todo o harém, Ning Xiaoxiao naturalmente não acompanharia Gu Sijin naquela onda de sentimentalismo.

Ela segurou os ombros de Gu Sijin e a afastou com delicadeza. Vendo seus cílios tremerem enquanto soluçava, não soube se ria ou se chorava:

“Você vai deixar o palácio para se casar na capital e viver feliz, não vai ser mandada para Maodu alimentar porcos! É uma coisa maravilhosa; por que está chorando?”

Apesar da língua afiada, Ning Xiaoxiao fez o contrário do que suas palavras sugeriam: enxugou com o dorso da mão as lágrimas nos olhos de Gu Sijin.

“Continuaremos as duas na capital, separadas apenas por uma muralha. Se você não puder vir ao palácio, posso visitá-la muitas vezes na residência do comandante Chu. O imperador e o comandante Chu são amigos íntimos; quando se encontrarem fora do palácio, basta eu pedir a A-Yuan que me leve junto. Acha que ele ousaria me deixar em casa?”

Gu Sijin conhecia bem quem mandava na vida doméstica de Ning Xiaoxiao. Entre a felicidade e a tristeza repentina, deixara que as emoções lhe embaralhassem o raciocínio.

Agora, após o lembrete de Ning Xiaoxiao, as lágrimas cessaram imediatamente:

"Então você terá que vir me visitar com frequência."

Ela fez um gesto para Ning Xiaoxiao com o dedo mindinho, dizendo: "Promessa de dedinho."

Ning Xiaoxiao riu dela por ser infantil, mas depois que fizeram um juramento de dedinho, ela pressionou o polegar contra o dela para selar o acordo.

Mais tarde, Gu Sijin lembrou-se de ter ouvido algumas fofocas entre os servos do palácio quando voltou do Templo Fahua mais cedo naquele dia, então perguntou a Ning Xiaoxiao:

“Hoje, quando voltei ao palácio, ouvi os criados comentarem que o imperador pretendia mandar a Concubina Tong para a morte junto com o clã Tong, mas que você intercedeu em favor dela. É verdade?”

Ning Xiaoxiao assentiu em silêncio, e Gu Sijin ficou ainda mais curiosa. “Isso é surpreendente. Depois de tudo que ela fez contra você, agora que a família Tong caiu, ainda assim você pediu clemência ao imperador por ela?”

Ning Xiaoxiao ouvira de Xiao Yinzi algumas histórias sobre a Concubina Tong.

Toda a arrogância e agressividade da Concubina Tong nasciam de uma profunda falta de segurança. Na família, o pai a usava, o irmão a desprezava e até a mãe, a única pessoa próxima dela, tinha medo do marido e não ousava defendê-la; só lhe dizia para suportar.

Entrar no palácio não foi uma escolha dela.

Ela tinha apenas quinze anos quando entrou no palácio e teve que competir ferozmente com essas mulheres pelo mesmo homem.

Se ela não tivesse revelado seus espinhos, dada a astúcia e sagacidade da Imperatriz, provavelmente teria sido alvo de inúmeras conspirações e assassinada neste palácio profundo.

Ning Xiaoxiao lembrou-se de suas disputas abertas e secretas com a Concubina Tong. Tirando a pulseira que Tong quebrara de propósito, saíra de tudo aquilo sem um arranhão.

No fim, Ning Xiaoxiao conquistara tudo, enquanto a Concubina Tong perdera de maneira esmagadora.

Pensando nisso, ela acariciou a pulseira de jade em seu pulso, deu uma risadinha suave e balançou a cabeça:

“Quando é possível perdoar, é melhor perdoar.”

“Ela também é alguém digno de pena.”

As pessoas que são próximas umas das outras, sejam amantes ou melhores amigos, sempre serão sutilmente influenciadas umas pelas outras e carregarão a sombra uma da outra, contanto que seus corações estejam próximos.

Xiao Gu finalmente se tornou alguém que não era mais covarde e ousou lutar contra todo o bullying e humilhação no mundo, enquanto o coração de Xiao Xiao também ganhou uma bondade calorosa.

(Passei a noite em claro ontem. Dormi só três horas em dois dias, estou com a cabeça zunindo. Se insistir em escrever, vou acabar enchendo linguiça, então vou tirar uma folga hoje, tá?)

(Amo vocês, ღ( ´･ᴗ･` ) Um coraçãozinho para vocês!)

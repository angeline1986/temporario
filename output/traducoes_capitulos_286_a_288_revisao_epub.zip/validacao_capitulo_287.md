# Validação do capítulo 287

- **Original chinês:** `novel_capitulos_271_a_300(20261106-202952).docx`.
- **Tradução-base portuguesa:** `novel capitulos 271 a 300 - ch.epub`, capítulo 287.
- **Intervalo de índices reais do DOCX:** 1120–1157 (base zero, incluindo parágrafos vazios).
- **Unidades não vazias no chinês:** 35 (inclui título).
- **Parágrafos de corpo não vazios no EPUB:** 34; título em H1.
- **Correspondência:** 35 pares no CSV; índices únicos, preservados, com título e unidades de corpo alinhados.

## Revisão editorial

Foi usada a versão portuguesa do EPUB como base, com correções focalizadas confrontadas com o original chinês. Foram revisados **16 parágrafos específicos** do capítulo, além de padronização pontual dos tratamentos Concubina Tong e Nobre Dama Gu.

**Destaques:** distinção entre capital e Maodu, cargo de Chu, gênero das personagens, expressão sobre a posição de Ning no relacionamento e sentido moral da máxima 得饒人處且饒人; preservadas as notas da autora.

## Escopo e limitações

**Verificação estrutural de todas as unidades:** feita. **Conferência semântica integral, frase a frase e independente:** não realizada. O texto conserva passagens do EPUB não reescritas, que podem conter erros lexicais ou nuances ainda não detectadas. O alinhamento 1:1 é estrutural e não prova exatidão semântica.

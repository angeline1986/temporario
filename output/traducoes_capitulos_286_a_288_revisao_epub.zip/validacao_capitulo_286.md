# Validação do capítulo 286

- **Original chinês:** `novel_capitulos_271_a_300(20261106-202952).docx`.
- **Tradução-base portuguesa:** `novel capitulos 271 a 300 - ch.epub`, capítulo 286.
- **Intervalo de índices reais do DOCX:** 1054–1119 (base zero, incluindo parágrafos vazios).
- **Unidades não vazias no chinês:** 63 (inclui título).
- **Parágrafos de corpo não vazios no EPUB:** 62; título em H1.
- **Correspondência:** 63 pares no CSV; índices únicos, preservados, com título e unidades de corpo alinhados.

## Revisão editorial

Foi usada a versão portuguesa do EPUB como base, com correções focalizadas confrontadas com o original chinês. Foram revisados **23 parágrafos específicos** do capítulo, além de padronização pontual dos tratamentos Concubina Tong e Nobre Dama Gu.

**Destaques:** corrigida a absurda referência a estacionamento irregular, restaurada a derrota de Tong Guowei, ajustada a identidade da consorte e a ironia da protagonista; correções nas cenas de Gu Sijin e Chu Xingran e na nota da autora.

**Ambiguidade no original:** o parágrafo de índice 1058 contém redação chinesa aparentemente corrompida (“違停…打破…”); a versão revisada interpreta o contexto como retorno vitorioso de Ren Duanli após a derrota de Tong Guowei. Essa leitura deve ser confirmada contra outra edição do original, se disponível.

## Escopo e limitações

**Verificação estrutural de todas as unidades:** feita. **Conferência semântica integral, frase a frase e independente:** não realizada. O texto conserva passagens do EPUB não reescritas, que podem conter erros lexicais ou nuances ainda não detectadas. O alinhamento 1:1 é estrutural e não prova exatidão semântica.

# Capítulo 85 — Gu Sijin e o guarda: um caso ilícito

Desde que entrara no palácio, Gu Sijin passava muitas noites sem conseguir dormir.

Seus pensamentos sempre voltavam para Chu Xingran.

Bastava fechar os olhos para se lembrar dos doces momentos que haviam vivido juntos.

Ela era atormentada pela culpa:

Se não entrasse no palácio, estaria traindo sua família.

Mas, tendo entrado, traíra o homem que amava.

Em incontáveis noites nas quais os outros a imaginavam vivendo na glória, ela atravessava a escuridão em companhia das próprias lágrimas.

Naquela noite, porém, dormiu profundamente.

Fazia muito tempo que não experimentava um sono tão tranquilo.

Em sonho, voltou à adolescência. Chu Xingran segurava sua mão enquanto caminhavam por um mar de flores.

Ele lhe disse: — Um dia, vou lhe dar um lar.

Enquanto Gu Sijin se perdia naquele sonho maravilhoso e ilusório, o céu começava a clarear.

A imperatriz e as demais chegaram meia hora antes do combinado. Ao encontrarem o pátio cheio de criados ajoelhados, mas nenhuma sinal da anfitriã, a imperatriz perguntou: — Onde está sua senhora? Ainda está dormindo?

Cailian respondeu: — A senhora não sabia que Vossas Majestades chegariam tão cedo. Deve estar dormindo. Vou acordá-la agora.

Ela se preparava para sair quando a Consorte Nobre a deteve: — Na ausência da Consorte Duan, a Atendente Gu é a responsável pelo Palácio Zhongcui. Se a dona da casa ainda não se levantou, não seria apropriado admirarmos as flores sozinhas. Imperatriz, por que não vamos todas acordá-la?

Assim, as consortes, conversando e rindo, abriram a porta dos aposentos de Gu Sijin.

Mas mal a porta se abriu, todas começaram a gritar diante da cena.

Na cama em que Gu Sijin deveria estar dormindo sozinha havia um homem vestido apenas com uma cueca larga.

Ele abraçava Gu Sijin, que tinha somente um corpete cobrindo o peito. Nenhum dos dois estava coberto, e as roupas se espalhavam desordenadas pelo chão.

O rosto de Gu Sijin, encostado no peito do homem, ainda exibia um sorrisinho, como se estivesse satisfeita com algum desempenho dele na noite anterior.

Os gritos das consortes despertaram os dois. Ao descobrir que estava semidespida nos braços de um desconhecido, Gu Sijin quase morreu de susto.

Ela empurrou o homem, puxou a colcha para se cobrir e perguntou, aterrorizada: — Você! Quem é você?

O homem também se assustou e ficou sem saber o que fazer, meio ajoelhado no chão.

A Consorte Nobre foi a primeira a se recompor. Apontou para Gu Sijin e bradou:

— Sua atrevida, Gu Sijin! Ousa manter um caso ilícito pelas costas do imperador?! Guardas! Arrastem esse casal de adúlteros para fora e espanquem os dois até a morte!

Os criados entraram para executar a ordem, mas a imperatriz ergueu a mão, detendo-os: — A Atendente Gu continua sendo uma consorte imperial, e seu pai é um importante funcionário da corte. Como podem matá-la sem mais nem menos? O assunto é grave demais para conclusões precipitadas.

Ela olhou para Gu Sijin e perguntou, com certo pesar: — Atendente Gu, o imperador a trata tão bem. Por que... faria uma coisa tão indecente?

Gu Sijin respondeu entre lágrimas: — Imperatriz, sou inocente! Não sei quem é esse homem nem por que apareceu em meus aposentos!

O homem protestou imediatamente: — Como pode dizer que não sabe quem sou, Atendente Gu? Quer abandonar este servo para salvar sua reputação?

Ele se arrastou até a imperatriz e bateu a testa no chão repetidamente: — Imperatriz! Sou um guarda do Portão Dingyuan, que fica fora do Palácio Zhongcui. Foi a Atendente Gu quem me obrigou a me deitar com ela! Disse que o imperador a chamava repetidas vezes, mas que sua barriga continuava vazia. Como sou forte, queria que eu a ajudasse a realizar o sonho de ser mãe! Se eu me recusasse, ela me mataria! Imploro que Vossa Majestade faça justiça!

Ao ouvi-lo, Gu Sijin ficou completamente atônita.

Sua cabeça zumbia e tudo diante de seus olhos parecia se duplicar.

A imperatriz ignorou o guarda e voltou a perguntar: — Atendente Gu, afirma ser inocente. Pode provar isso?

Provar sua inocência?

A primeira coisa em que Gu Sijin pensou foram os criados que a serviam no palácio.

Afinal, não era tão simples um homem adulto entrar em seu quarto.

À noite, os portões do Palácio Zhongcui eram trancados. Com os muros altos, nem mesmo um guarda conseguiria entrar pulando sem que alguém lhe abrisse a passagem.

Na noite anterior, além disso, Cailian ficara de vigia à porta. Mesmo que o guarda tivesse conseguido se infiltrar no palácio, jamais entraria no quarto sem acordá-la.

Gu Sijin se apressou a dizer: — Todos os criados do meu palácio podem testemunhar! Fui dormir cedo ontem à noite. Jamais faria uma coisa dessas!

A imperatriz olhou para os criados ajoelhados do lado de fora e perguntou com severidade: — Contem o que aconteceu ontem à noite.

Qiqi, Qiaqia, Bengbeng, Lala e os demais responderam em coro que Gu Sijin se recolhera cedo e que, depois de terminarem seus serviços, eles também haviam ido descansar.

A Consorte Nobre rebateu: — Vocês foram dormir, mas quem garante que a Atendente Gu também dormiu? Quem ficou de vigia ontem?

Bengbeng respondeu: — Deveria ter sido este servo, mas Cailian disse que meus roncos incomodavam a senhora. Mandou-me embora e afirmou que ela mesma faria a vigília.

Com o rosto tomado de pavor, Cailian negou com a cabeça repetidas vezes: — Mas eu também não fiquei de vigia ontem... A senhora... a senhora disse que o outono havia esfriado, e que a chuva do dia anterior deixara o chão do pátio úmido. Por isso, mandou-me voltar ao quarto e descansar. Disse... disse que não precisava de ninguém de vigia...

Ao ouvir aquelas palavras, Gu Sijin sentiu como se toda a força lhe fosse arrancada do corpo.

Não fora Bengbeng quem estava escalado para a vigília? Ela até pedira a Cailian que levasse outra coberta para ele!

Por quê?

Como as coisas haviam chegado àquele ponto?

Será que...?

Ela olhou para Cailian com os olhos cheios de incompreensão, como se fossem sangrar.

Não conseguia acreditar que uma criada que a acompanhava havia mais de dez anos, uma irmã a quem sempre tratara com carinho, pudesse traí-la e desejar sua morte.

Ela sempre soubera que o harém estava cheio de intrigas e disputas.

Também sempre tentara se proteger das armadilhas alheias.

Mas, por mais cuidado que tivesse, nunca imaginara que quem a trairia seria justamente a pessoa em quem mais confiava.

Ao vê-la calada, a Consorte Nobre exigiu: — Então? Ficou sem explicações?

Gu Sijin estava completamente desesperada.

Não sabia como provar sua inocência; só conseguia repetir que estava sendo injustiçada.

Mas, naquele momento, suas palavras soavam vazias e não convenciam ninguém.

A Consorte Nobre declarou: — Imperatriz, essa miserável não vai confessar enquanto não apanhar. Se continua calada, mandemos todos os criados da ala leste do Palácio Zhongcui ao Departamento de Punições para interrogatório. Com castigos severos, acredito que a verdade acabará saindo da boca deles.

Depois de pensar um pouco, a imperatriz respondeu, contrariada: — Parece ser a única solução. Levem todos os criados da ala leste do Palácio Zhongcui ao Departamento de Punições e interroguem-nos. Não descansem até descobrir o que de fato aconteceu.

A Consorte Nobre examinou os arredores e franziu as sobrancelhas: — Um momento. Onde está Ning Xiaoxiao, que vive atrás de Gu Sijin? Tragam-na e a submetam a um interrogatório rigoroso! Ela é próxima da Atendente Gu e certamente sabe de muito mais coisas!

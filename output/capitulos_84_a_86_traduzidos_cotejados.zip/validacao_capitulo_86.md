# Validação estrutural — capítulo 86

- Fonte primária: DOCX chinês, capítulos 61–120.
- Unidades originais não vazias (título incluído): **63**.
- Unidades traduzidas e cotejadas: **63**.
- Lacunas de alinhamento: **0**.
- Observação editorial: Shougongsha retratada como crença cultural ficcional, não teste médico de virgindade.
- Limite: cotejo 1:1 e revisão durante a elaboração não equivalem a auditoria semântica independente.

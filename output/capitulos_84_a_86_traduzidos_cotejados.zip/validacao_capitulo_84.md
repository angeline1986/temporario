# Validação estrutural — capítulo 84

- Fonte primária: DOCX chinês, capítulos 61–120.
- Unidades originais não vazias (título incluído): **56**.
- Unidades traduzidas e cotejadas: **56**.
- Lacunas de alinhamento: **0**.
- Observação editorial: Notas do autor mantidas e tradução de sátira das consortes adaptada de forma idiomática.
- Limite: cotejo 1:1 e revisão durante a elaboração não equivalem a auditoria semântica independente.

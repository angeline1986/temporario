# Validação estrutural — capítulo 85

- Fonte primária: DOCX chinês, capítulos 61–120.
- Unidades originais não vazias (título incluído): **62**.
- Unidades traduzidas e cotejadas: **62**.
- Lacunas de alinhamento: **0**.
- Observação editorial: Acusação de adultério apresentada como alegação; não convertida em fato.
- Limite: cotejo 1:1 e revisão durante a elaboração não equivalem a auditoria semântica independente.

# Capítulo 86 — Ning Xiaoxiao vira o jogo

— Ora, ora! O que está acontecendo aqui? Quanta animação!

A Consorte Nobre acabara de mandar procurarem Ning Xiaoxiao quando a própria apareceu.

Ela abriu caminho entre a multidão, cumprimentou a imperatriz e as demais consortes e foi diretamente até Gu Sijin, encolhida na cama e chorando sem parar.

Ao passar pelo guarda ajoelhado, ainda lhe deu um chute de brinde.

Sentou-se à beira da cama, segurou a mão de Gu Sijin e a consolou: — Não tenha medo, minha senhora. Ninguém pode acusá-la de algo que não fez.

Uma simples criada ousava bancar a valentona diante de tantas senhoras do harém! Estava pedindo para morrer!

A Consorte Nobre gritou furiosa: — Uma criadinha miserável ousa ser insolente diante de tantas consortes? Talvez eu não possa punir Gu Sijin, mas tirar sua vida não é nada difícil! Guardas! Levem-na e espanquem-na até a morte!

Ning Xiaoxiao encarou calmamente os criados que se aproximavam e bradou: — Quero ver quem se atreve!

Sua voz soou tão autoritária que os criados realmente pararam, intimidados.

A Consorte Nobre ordenou: — O que estão esperando? Mexam-se!

Ning Xiaoxiao anunciou solenemente: — Ordem verbal do imperador: levem a Atendente Gu e todos os envolvidos do Palácio Zhongcui ao Palácio Fengluan. Quando encerrar a audiência matinal, Sua Majestade os interrogará pessoalmente.

A Consorte Nobre zombou: — Só porque você disse que é ordem do imperador, devemos acreditar? Quem pensa que é para ter contato com Sua Majestade?

Ning Xiaoxiao lançou-lhe um olhar: — O que esta serva é não importa. O importante é que Vossa Alteza compreenda o valor que nossa senhora tem para o imperador. Se não acredita em minhas palavras, fique à vontade para mandar executar todos os criados do Palácio Zhongcui. Depois veremos se Sua Majestade não a condenará por desobedecer a uma ordem imperial.

— Você...!

— Basta dessa confusão — interveio a imperatriz. — Já que existe uma ordem verbal do imperador, levem todos ao Palácio Fengluan. Ele os interrogará pessoalmente depois da audiência.

No caminho até o Palácio Fengluan, Cailian manteve-se sempre distante, receando que Gu Sijin lhe perguntasse alguma coisa.

Amparada por Ning Xiaoxiao, Gu Sijin caminhava com dificuldade, os olhos fixos nas costas de Cailian. Seu coração doía.

Quando estavam quase chegando, segurou Ning Xiaoxiao e murmurou: — Xiaoxiao, se eu não conseguir escapar desta vez, não enfrente essas mulheres por minha causa. Encontre um jeito de se proteger. Não quero arrastá-la comigo...

— A senhora é minha senhora. Se a senhora não estiver bem, eu também não estarei. Não se preocupe: não vou deixar que nada lhe aconteça.

Mal todos se acomodaram no Palácio Fengluan, Lu Linyuan chegou.

As consortes o saudaram com reverências. Depois de ocupar o assento principal, ele perguntou: — Muito bem. O que aconteceu?

A imperatriz olhou para Gu Sijin e depois para o guarda ajoelhado, sem saber como começar: — Majestade... o assunto é tão indecoroso que não ouso dizê-lo em voz alta.

Ela não ousava. A Consorte Nobre, sim.

A Consorte Nobre relatou a Lu Linyuan, nos mínimos detalhes, a cena que as mulheres haviam encontrado no Palácio Zhongcui naquela manhã.

Imaginava que ele explodiria de fúria. Em vez disso, ele apenas perguntou: — Só isso?

Todas as consortes: — ???

Gu Sijin soluçou: — Majestade... fui acusada injustamente. Nem sequer conheço esse guarda!

Mas o guarda, como um cão raivoso, insistiu que passara a noite anterior com Gu Sijin e afirmou que nem sequer fora a primeira vez.

Sua intenção era evidente: estava disposto a arriscar a própria vida para incriminar Gu Sijin.

Lu Linyuan perguntou: — Atendente Gu, por que ninguém ficou de vigia ontem à noite?

Gu Sijin respondeu: — Ontem à noite, Bengbeng deveria ter ficado de vigia, mas, por algum motivo, no fim ninguém ficou.

Bengbeng se ajoelhou e explicou: — Majestade, Cailian disse que eu roncava alto demais e me mandou embora. Disse que ela mesma ficaria de vigia!

Cailian replicou: — Fiz tudo conforme as ordens da senhora. Depois, ela disse que o chão estava frio e que tinha pena de mim, então me mandou dormir no quarto. Foi por isso que ninguém ficou de vigia.

As mentiras descaradas de Cailian conseguiram enfurecer até mesmo Gu Sijin, normalmente tão dócil.

— Você está mentindo! Quando mandei você dispensar Bengbeng? Quando disse que não precisava ficar de vigia? Cailian, você me acompanha há tantos anos. Sabe muito bem como sempre a tratei. Por que está me incriminando desse jeito?

Ao ouvir isso, Cailian começou imediatamente a chorar: — Como eu poderia incriminar minha senhora? Se soubesse desde o começo que a senhora não suportava a solidão e pretendia fazer uma coisa dessas, teria escondido tudo do imperador, mesmo que me custasse a cabeça! Mas...

Ela caiu de joelhos com um baque e bateu a testa no chão diante de Lu Linyuan: — Majestade, agora que chegamos a esse ponto, há coisas que não posso mais esconder! Na verdade, esta não foi a primeira vez que a senhora encontrou esse guarda às escondidas... Fiquei apavorada e não entendo por que ela fazia isso! Nas duas primeiras vezes, presenciei coisas indecentes, mas não tive coragem de falar. Pensei que a senhora fosse parar, mas não imaginava que...

— Coisas indecentes? — Ning Xiaoxiao a interrompeu. — A que exatamente está se referindo?

Corando, Cailian gaguejou: — Coisas de homem e mulher. O que mais poderia ser?

— Tem certeza? — Ning Xiaoxiao a pressionou. — Tem certeza de que viu nossa senhora e esse guarda tendo relações sexuais?

Lu Linyuan: — ...

Ela enlouqueceu?

Como consegue fazer uma pergunta dessas tão diretamente?

Cailian assentiu com força: — Tenho certeza!

Ning Xiaoxiao abriu um sorriso: — Então fica fácil resolver isso.

Ela se aproximou de Gu Sijin e ergueu a manga de sua roupa, revelando parte do braço de pele clara.

Bem no meio do antebraço havia uma pequena marca vermelho-viva.

Era a marca *shougongsha*, considerada na época um símbolo da castidade feminina.

Segundo essa crença, sua presença indicava que a mulher ainda era virgem.

Cailian ficou tão atônita que seus olhos quase saltaram das órbitas.

Ning Xiaoxiao perguntou: — Então me explique uma coisa: se você viu nossa senhora fazer aquilo com outra pessoa, por que a marca de castidade ainda está em seu braço?

Ela se virou para o guarda igualmente apreensivo e acrescentou: — Ou será que ele tem uma agulhinha no lugar daquilo e passou a noite inteira com a senhora praticando bordado?

— Cof, cof!

Lu Linyuan quase engasgou com a observação de Ning Xiaoxiao.

As demais consortes também estavam perplexas.

Como assim?

Gu Sijin supostamente passava tantas noites servindo o imperador! Como ainda poderia ser virgem?

Cailian começou a gaguejar: — I-isso... isso...

Ning Xiaoxiao cortou: — Chega de “isso” e “aquilo”. Responda à pergunta.

Cailian murmurou: — Talvez... talvez eu tenha visto errado?

Ning Xiaoxiao riu friamente: — Não importa se você viu errado. Mas quem supostamente fez aquilo deve saber muito bem se chegou a consumar o ato, não é?

Ela lançou um olhar feroz ao guarda e exigiu: — Fale! Quem mandou você manchar a reputação da Atendente Gu com essa mentira?

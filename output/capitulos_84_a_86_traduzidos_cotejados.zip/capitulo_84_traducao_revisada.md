# Capítulo 84 — Às vésperas da tempestade

Naquela noite, caiu uma chuva de outono. O vento e a água castigaram o Jardim Imperial, derrubando muitas das flores coloridas que já mal se sustentavam.

Mas o Palácio Zhongcui acabou se beneficiando da chuva.

A Consorte Duan gostava de crisântemos, por isso havia plantado muitos deles por todo o palácio.

Isso também fazia parte de seus planos para conquistar o favor imperial.

Enquanto os outros palácios cultivavam rosas, peônias e flores de cores exuberantes, os crisântemos, embora menos vistosos, floresciam justamente quando o outono punha fim às demais flores.

Ela esperava que aquele amarelo fresco e luminoso atraísse Lu Linyuan e o fizesse visitá-la com mais frequência no outono.

Mas já fazia três anos que cultivava os crisântemos, e o favor que tanto aguardava nunca chegara.

Naquele dia, quando Ning Xiaoxiao acompanhou Gu Sijin para cumprimentar a imperatriz, as consortes que haviam enfrentado a chuva pelo caminho não puderam deixar de reclamar.

A Consorte Yun vestia um brocado de nuvens com motivos florais, cuja barra ficara salpicada de lama. Ela mandava uma criada esfregar as manchas sem parar com um lenço úmido.

— Essas chuvas de outono acabam com a paciência de qualquer uma. Todas as peônias do meu palácio murcharam de uma noite para outra. As pétalas se misturaram à água e grudaram na terra. Dá desgosto só de olhar.

A Consorte Li concordou: — Nem me fale! O palácio de Sua Majestade, a imperatriz, é que é bom. A imperatriz nunca foi de mexer com flores; seus pinheiros e ciprestes permanecem verdes o ano todo. No verão, dão uma sombra deliciosa, e no inverno, cobertos de neve, ficam inteirinhos prateados. Que coisa linda!

A Consorte Nobre apertou um lenço de seda contra o pó solto ao lado do nariz e soltou uma risadinha fria: — É verdade, pinheiros e ciprestes são ótimos. Pena que suas folhas são pontiagudas demais. O imperador nunca gostou de mulheres que exibem tanto as garras. Vai saber se ele não visita o palácio da imperatriz justamente por não gostar dessas árvores?

Aproveitando-se da influência de sua família, ela passava os dias encontrando novas maneiras de humilhar a imperatriz.

Depois de tantos anos, a imperatriz já se acostumara às provocações disfarçadas e nem se irritou. Apenas respondeu:

— Somos todas irmãs aqui. Se o imperador não vem me visitar e prefere o palácio de qualquer uma de vocês, fico igualmente feliz. Este mês, examinei os registros do Departamento de Assuntos Internos. Sua Majestade foi quatro vezes ao Palácio Zhongcui, chamou a Atendente Gu para servi-lo à noite sete vezes e passou as demais noites sozinho no Palácio Chaoyang. Pelo visto, a Atendente Gu conquistou mesmo o coração do imperador.

Com uma observação aparentemente casual, a imperatriz fez todos os olhares recaírem sobre Gu Sijin.

Apavorada com a possibilidade de virar alvo das outras, Gu Sijin se levantou depressa e fez uma reverência.

— Sua Majestade apenas considera esta concubina uma recém-chegada e está aproveitando a novidade. Na verdade, sempre que sou chamada para servi-lo, o imperador menciona a imperatriz com os maiores elogios. Está claro que Vossa Majestade e ele é que formam um casal verdadeiramente harmonioso.

Satisfeita, a imperatriz sorriu e permitiu que ela se levantasse: — Você é sensata e conhece a etiqueta. Se o imperador gosta da sua companhia, eu também gosto de ouvi-la.

A Consorte Nobre torceu o nariz com desprezo: — E daí que ela seja chamada todas as noites? Recebe mais favores do que qualquer outra, mas a barriga continua sem dar sinal de vida. Talvez seja bonita por fora e inútil por dentro. Se eu tivesse tantas noites com o imperador em um único mês e ainda assim não concebesse um herdeiro, morreria de vergonha. Procuraria uma árvore num canto deserto e me enforcaria para acabar logo com isso.

A Consorte Yun zombou: — Até parece que você não gostaria de ter essa oportunidade. Mas será que o imperador vai lhe concedê-la? Se não me engano, a última vez que a Consorte Nobre ficou sozinha com ele foi no próprio aniversário, não foi?

— Sua...!

Ao perceber que as duas estavam prestes a brigar, a imperatriz interrompeu: — Basta. As duas podem falar um pouco menos. Somos irmãs; não há necessidade de estragar nossa harmonia.

Observando a batalha verbal à margem, Ning Xiaoxiao mais uma vez se admirou com o nível das intrigas do harém.

【Essas mulheres são todas raposas velhas! Com a inteligência da Gu, como é que ela conseguiu virar imperatriz-viúva no final...?】

Depois de mais alguma conversa e alfinetadas, quando todas já se preparavam para partir, a Consorte Nobre pareceu ter uma ideia: — As flores do Jardim Imperial já murcharam, mas os crisântemos do Palácio Zhongcui estão lindos. Imperatriz, que tal dispensar os cumprimentos de amanhã para irmos todas admirar as flores e conversar por lá?

A imperatriz consultou as outras consortes. Como a proposta viera da Consorte Nobre, todas naturalmente concordaram.

A imperatriz então decidiu: — Amanhã não precisam vir me cumprimentar. Vamos juntas ao Palácio Zhongcui apreciar as flores. A Consorte Duan voltou à casa da família, então, Atendente Gu, peço que cuide dos preparativos.

Gu Sijin respondeu: — Obedeço, Vossa Majestade. Será uma honra servir às senhoras.

*

De volta ao palácio, Gu Sijin começou a distribuir ordens:

— Amanhã, todas as consortes virão ao Palácio Zhongcui. Como a Consorte Duan está ausente, não podemos faltar com a hospitalidade. Preparem os melhores doces e chás, limpem bem o pátio e as dependências, coloquem os crisântemos verdes num lugar de destaque e aparem os galhos que cresceram demais. Agradeço o esforço de todos hoje.

Ning Xiaoxiao não era propriamente trabalhadora, mas sempre cumpria com seriedade as tarefas que Gu Sijin lhe confiava, sem fazer corpo mole.

Enquanto todos corriam de um lado para o outro, Cailian agia como se nada tivesse a ver com aquilo: permanecia dentro dos aposentos bajulando Gu Sijin, massageando-lhe a cintura e os ombros.

Qiqi e as outras não suportavam aquilo: — Ela não trabalha o dia inteiro. Só sabe puxar o saco da senhora e ainda vive nos tratando com arrogância. Você é a criada responsável pela ala leste, Xiaoxiao, mas ela se comporta como se fosse metade dona do lugar.

Podando os ramos, Ning Xiaoxiao sorriu: — Não precisam se irritar por causa dela. De qualquer forma, não vai continuar se exibindo por muitos dias.

— Hein? Xiaoxiao, o que você quer dizer?

— Nada. Foi só uma brincadeira.

*

Naquela noite, era a vez de Bengbeng ficar de vigia sob a varanda.

Ele já havia estendido sua roupa de cama diante dos aposentos de Gu Sijin quando Cailian apareceu com uma tigela de leite fresco e ordenou, com arrogância: — A senhora disse que você não fará a vigília esta noite.

— Por quê? Hoje é meu turno.

— Você vem vigiar ou atormentar a senhora com esse barulho? — Cailian revirou os olhos. — Não sabe que ronca como um trovão? Sempre que você fica aqui, a senhora não consegue dormir! Agora que ela é a favorita do imperador, é justamente quando tem mais chances de engravidar. Se seus roncos prejudicarem o descanso dela e impedirem que conceba um herdeiro imperial, vai assumir a responsabilidade?

Cailian exagerou tanto a gravidade do assunto que Bengbeng se assustou, enrolou suas cobertas e foi embora.

Ela entrou com o leite nas mãos e disse, sorrindo: — Senhorita, beba um pouco de leite fresco antes de dormir. É ótimo para acalmar e descansar a mente.

Gu Sijin pegou a tigela, bebeu tudo e, depois de enxaguar a boca, perguntou: — Bengbeng já se deitou lá fora?

— Já, senhorita~

— Está fazendo frio. Quando sair, leve outra coberta para ele. Não quero que pegue um resfriado.

Cailian concordou repetidas vezes. Gu Sijin ainda a instruiu: — Embora amanhã não precisemos cumprimentar a imperatriz, acorde-me cedo. Todas as consortes virão e tenho de me preparar.

— Não se preocupe, senhorita. Sei exatamente o que fazer.

Cailian esperou Gu Sijin adormecer, apagou as velas do quarto e fechou a porta. Ao sair, porém, um sorriso sombrio e sinistro apareceu em seu rosto.

*

(Nota do autor: Antes que reclamem: houve interações demais! Deixem-me desenvolver a trama por dois dias! Primeiro, vamos tirar Cailian, essa falsa, da história! Não fujam! Continuem lendo! Juro que serão só dois dias de enredo!!!!)

(E outra coisa: vi comentários dizendo que eu odeio homens porque prego peças no protagonista masculino. Ah, pelo amor de Deus! Sou um autor homem que escreve histórias voltadas ao público feminino, não uma autora! Eu mesmo sou homem! Por que odiaria homens?)

(Para mim, mimar alguém não é justamente uma pessoa aprontar e a outra rir? Por que o protagonista masculino precisa dominar absolutamente tudo? Ele já domina todos pelo poder que tem. Fora disso, basta deixar Xiaoxiao levar a melhor sobre ele!)

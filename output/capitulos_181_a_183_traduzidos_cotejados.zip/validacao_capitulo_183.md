# Validação — capítulo 183

- Fonte: `novel_capitulos_181_a_211(20261105-152744).docx`, chinês tradicional. As duas cópias anexadas têm SHA-256 idêntico.
- Intervalo de parágrafos no DOCX (índices base zero): `119` até `175` (o próximo capítulo começa em `176`).
- Parágrafos não vazios traduzidos, incluindo título e eventuais separadores: **54**.
- Linhas do CSV (excluindo cabeçalho): **54**.
- Contagem 1:1: **OK**. Índices repetidos: **0**. Índices ausentes entre os parágrafos não vazios do intervalo: **0**. Campos vazios: **0**.
- A tradução em Markdown foi gerada das mesmas unidades portuguesas presentes no CSV.

## Observações editoriais

Separados o destino de Tong Guowei no enredo original e os eventos da linha atual. O imperador ordena a promoção da Concubina Tong a consorte, mas não concede sua reintegração como Consorte Nobre. Chu Xingran (楚星燃) reaparece; Tong Zhiyin (佟之胤) é filho mais velho de Tong Guowei.

## Limitações

Foi feita revisão contextual durante a tradução e checagem estrutural programática; **não houve segunda revisão semântica independente integral**, de modo que a validação estrutural não certifica sozinha ausência de erros de sentido dentro de cada parágrafo.

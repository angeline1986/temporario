# Capítulo 183 — O rei dos cães

De volta aos próprios aposentos, Gu Sijin mencionou algo que a preocupava:

— Ouvi dizer que Tong Guowei teve um papel importantíssimo na vitória contra os piratas japoneses. A corte e o harém estão ligados por inúmeros interesses. Depois de tanto tempo esquecida, a Concubina Tong talvez encontre uma oportunidade de voltar ao poder.

Na obra original, Tong Guowei, embriagado pelas próprias conquistas militares, tornava-se cada vez mais arrogante e insolente, até que Lu Linyuan acabava por eliminá-lo completamente.

Quanto à Concubina Tong, passava o resto da vida no palácio frio.

Ning Xiaoxiao sorriu com frieza: — Mesmo que as cinzas voltem a pegar fogo, não vão arder por muito tempo. Deixe isso para lá. Mas ouvi outra coisa: um espião enviado pelo imperador se infiltrou entre os piratas por quatro anos, conquistou a confiança do chefe deles e aproveitou a oportunidade para assassiná-lo. Foi por isso que a vitória veio com tanta facilidade. Com tamanha façanha, certamente receberá um posto elevado e um título de nobreza.

Assuntos da corte não eram coisas sobre as quais as mulheres deviam ficar comentando.

Gu Sijin não deu muita importância ao que Ning Xiaoxiao dissera. Apenas sorriu e respondeu com tranquilidade:

— É mesmo? Então devemos parabenizá-lo.

Depois de uma pausa, acrescentou: — O Departamento de Flores e Aves cultivou uma nova variedade. Dizem que agora há lótus florescendo no lago imperial, perto da ilha central, mesmo no inverno. São inteiramente brancas, mas à noite seus botões exibem tons azul-claros. Devem ser lindíssimas. Quer ir vê-las comigo esta noite, se tiver tempo?

Ning Xiaoxiao nunca fora muito interessada em flores e plantas. Além disso, queria retribuir o carinho de Lu Linyuan pelo mingau de frutos do mar com uma tigela de sopa contra ressaca. Por isso, recusou delicadamente o convite de Gu Sijin.

*

Naquela noite, Lu Linyuan ofereceu um banquete no Palácio Chaoyang exclusivamente para os dois heróis da campanha contra os piratas: Tong Guowei e Chu Xingran.

Antigamente, ele sempre convidaria Ning Xiaoxiao para ocasiões assim.

Naquela noite, Ning Xiaoxiao até pulou o jantar, contando com a oportunidade de atacar as iguarias do banquete. Mas esperou até quase escurecer e Sanfu não apareceu com convite nenhum.

Só mais tarde, quando a cozinha imperial lhe enviou dezesseis pratos idênticos aos servidos na festa, ela percebeu que Lu Linyuan não pretendia levá-la.

Restou-lhe transformar a indignação em apetite: chamou Gu Sijin e as duas comeram até não aguentar mais.

Lu Linyuan não havia convidado Ning Xiaoxiao justamente porque conhecia muito bem o tipo de homem que Tong Guowei era.

Ele acumulara feitos militares extraordinários, servira três reinados e conquistara na corte uma influência inferior apenas à do imperador.

Se nem a Lu Linyuan ele demonstrava respeito, o que faria ao encontrar Ning Xiaoxiao, a nova favorita imperial que havia derrubado a Consorte Nobre?

Ser soberano era assim: mesmo um imperador tinha suas limitações.

E quem governava o mundo inteiro precisava, mais do que ninguém, saber equilibrar as forças à sua volta.

Tong Guowei era como um tigre feroz. Tentar abatê-lo às pressas provavelmente deixaria ambos os lados feridos.

Era melhor deixá-lo engordar confortavelmente, devorando tudo pela frente, até ficar tão enorme que mal conseguisse andar. Só então seria possível matá-lo pelas costas de uma vez, sem deixar problemas para o futuro.

Naquele momento, Lu Linyuan ocupava o assento principal, no alto do trono. Seguindo a precedência cerimonial que privilegiava a esquerda, Tong Guowei sentava-se à esquerda e Chu Xingran, diante dele, à direita.

Embora estivessem frente a frente, Tong Guowei não dirigiu um único olhar a Chu Xingran durante todo o encontro.

Os ministros não podiam encarar o Filho do Céu diretamente quando não estavam lhe apresentando alguma questão, sob pena de desrespeito. Mas Tong Guowei manteve os olhos fixos em Lu Linyuan o tempo inteiro, como se as regras do palácio não existissem.

Lu Linyuan não demonstrou irritação. Sorriu e declarou: — Ministro Tong, seus méritos nesta campanha foram enormes, para minha grande satisfação. Promovo-o a duque de primeira classe, com título hereditário a ser transmitido a seu filho mais velho, Tong Zhiyin. Sua esposa legítima, senhora Tong Yun, receberá o título honorífico de primeira classe. Concedo-lhe também mil taéis de ouro.

Cada uma daquelas recompensas, tomada isoladamente, bastaria para que qualquer outro ministro se gabasse pelo resto da vida.

Tong Guowei, contudo, apenas esboçou um sorriso de obrigação e saudou o imperador com as mãos postas: — Agradeço a Vossa Majestade.

Em seguida abaixou as mãos e falou friamente: — Mas, enquanto este servo combatia longe de casa, minha filha não encontrou paz dentro do palácio. Isso muito me angustia.

Desde que recebera a notícia da vitória, Lu Linyuan sabia que Tong Guowei pediria benefícios para a filha.

Aliás, chamar aquilo de pedido seria generoso. Tratava-se praticamente de uma exigência aberta.

Sob a mesa, Lu Linyuan cerrou a mão, mas manteve a expressão impassível: — A Concubina Tong cometeu erros e passou bastante tempo refletindo sobre eles. Já é hora de suspender seu confinamento. Sanfu, informe a imperatriz de que deverá anunciar amanhã cedo um decreto a todo o harém encerrando a punição da Concubina Tong.

A ordem foi dada, mas Tong Guowei permaneceu imóvel, sem qualquer intenção de agradecer.

Parecia que esperava o imperador concluir o que tinha a dizer, olhando-o com expectativa.

Lu Linyuan então acrescentou: — Além disso, a Concubina Tong será promovida ao posto de consorte.

Tong Guowei pretendia que a filha recuperasse a posição de Consorte Nobre. Se pudesse torná-la imperatriz de uma vez, tampouco acharia que lhe faltassem qualidades para isso.

Mas como Lu Linyuan já havia cedido tanto, e ele próprio saíra daquela negociação em posição vantajosa, acabou dizendo, a contragosto: — Agradeço a consideração de Vossa Majestade.

Lu Linyuan fez um sinal para Sanfu, que ordenou aos criados que servissem o banquete.

As iguarias foram levadas uma após a outra aos três convidados. Lu Linyuan ergueu a taça e propôs um brinde à derrota dos piratas.

Os três ergueram as taças à distância e beberam de uma vez. Antes mesmo de Lu Linyuan anunciar o início da refeição, Tong Guowei largou o copo e pegou os hashis de osso. Tirou uma fatia da parte mais macia do peixe garoupa cozido no vapor, meteu-a na boca e começou a mastigar ruidosamente, soltando exclamações de aprovação.

Começar a comer antes do imperador era o equivalente a girar a mesa de um banquete justamente quando o chefe estava se servindo!

O temperamento explosivo de Lu Linyuan até tinha sido um pouco domado pela convivência com Ning Xiaoxiao, mas a tolerância só valia para ela, que podia se comportar como quisesse diante dele.

Tong Guowei estava indo longe demais naquela noite, com tanta arrogância e teatralidade.

Foi então que Chu Xingran, que até aquele momento não abrira a boca, soltou uma risada e se dirigiu a Tong Guowei:

— Ministro Tong, a campanha deve ter sido realmente difícil. Ouvi dizer que no exército o senhor mal tinha o suficiente para matar a fome, quanto mais a chance de provar pratos tão refinados. Meu coração até dói ao vê-lo comer com tamanha voracidade.

Ele chamou Xiao Yinzi, encarregado de servir as refeições: — Venha cá. Leve todos os pratos da minha mesa para o ministro Tong. Deixe-o comer bastante. Seria uma tragédia se ele saísse do palácio, morresse de fome e suas últimas palavras fossem uma acusação de que Sua Majestade não o recebeu adequadamente.

Tong Guowei largou os hashis e fuzilou Chu Xingran com os olhos: — Você não passa de um espião enviado pelo imperador! Falando claramente, é só um cachorro criado por Sua Majestade! De onde tirou coragem para zombar de mim?

Lu Linyuan não interveio; limitou-se a assistir ao espetáculo. Percebendo que tinha a aprovação silenciosa do imperador, Chu Xingran ficou ainda menos preocupado em poupar o adversário.

— Nós recebemos soldo da corte e vivemos do dinheiro imperial. Sua Majestade é nosso senhor.

— Os cães são mais leais do que os homens, então não há nada errado nessa comparação. Mas o ministro Tong já atravessou três reinados. Sua lealdade certamente deve ser dez ou cem vezes maior que a minha.

Ele apoiou o queixo na mão, fingiu refletir e sorriu com insolência:

— Ora, sendo assim, o ministro Tong não pode ser outra coisa senão o indiscutível rei dos cães!

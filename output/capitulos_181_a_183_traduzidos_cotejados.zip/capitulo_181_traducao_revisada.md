# Capítulo 181 — Que tipo de desgraçado você pensa que é?

Depois de se lavar e se arrumar, Ning Xiaoxiao ficou algum tempo com o queixo apoiado na mão, distraída enquanto esperava o café da manhã da cozinha particular.

De repente, percebeu que não se lembrava de nenhuma trama envolvendo piratas japoneses quando lera a obra original.

Se o episódio dos ocidentais tinha surgido porque ela comera KFC às escondidas, de onde diabos tinha vindo essa história de piratas?

Não podia simplesmente ter esquecido.

Afinal, uma jovem apaixonada e cheia de fervor antijaponês como ela jamais deixaria passar uma história tão empolgante, carregada de patriotismo.

Fechou os olhos e convocou o documento em sua mente. Queria conferir os próximos acontecimentos e descobrir que história era aquela de piratas surgidos do nada.

Só que, ao abrir o documento, descobriu que seu acesso, antes de pelo menos três ou quatro páginas, havia sido reduzido a pouco mais de cem caracteres!

Que palhaçada era aquela?

O sistema estava com algum bug de novo?

Ela chamou Xiao Qi: 【Xiao Qi, o que aconteceu com esse documento? Por que não consigo mais ver a trama adiante?】

Era sábado, dia de folga de Xiao Qi. Sua voz saiu mole, como se ainda estivesse dormindo:

【Espera aí, anfitriã. Vou colocar meus óculos e dar uma olhada.】

【...】

【Achei. É o seguinte, anfitriã: você conseguiu desviar um terço da trama e se integrar de verdade à história. Isso quer dizer que tudo o que acontecer daqui para a frente estará diretamente ligado a você. Por isso, a partir de agora, só poderá consultar os próximos cem caracteres da trama.】

Ning Xiaoxiao ￣□￣｜｜: 【Você perdeu o juízo? Como assim eu me integrei à trama?】

Xiao Qi riu às escondidas: 【Hehe! Você e o tirano só não se integraram fisicamente um ao outro ainda. O que mais falta para se integrar à história?】

Ning Xiaoxiao: 【...】

Xiao Qi: 【Mas não desanime, anfitriã! Há males que vêm para bem~ Você perdeu a possibilidade de ler muito à frente, mas agora não existe limite de caracteres para as alterações que fizer na trama! De agora em diante, poderá modificar quantos caracteres quiser com seu poder especial, mas só poderá utilizá-lo uma vez por dia~】

Aquilo era para ser uma coisa boa?

Antes, ela podia guardar os caracteres que acumulava e modificar a trama quando quisesse. Agora, só teria uma oportunidade por dia?

Ning Xiaoxiao: 【Você está ouvindo o absurdo que acabou de falar?】

Xiao Qi: 【Não, porque nem sou gente! Pronto, pronto, hoje é feriado oficial. Se você não pode dormir até mais tarde, eu posso~ Tchauzinho, anfitriã~】

Desconectou-se na mesma hora, sem lhe dar chance de fazer mais nenhuma pergunta.

Restou a Ning Xiaoxiao consolar a si mesma.

Antes, conseguia acumular só alguns caracteres por dia; mesmo depois de um mês, mal podia alterar cem. Agora poderia modificar cem de uma vez — ou ainda mais —, embora apenas uma vez ao dia. Pensando bem, não havia saído perdendo tanto assim.

O problema era não conseguir mais espiar o futuro. Teria de sobreviver naquele livro contando apenas com o que lembrava da obra original. A dificuldade de permanecer viva parecia ter aumentado sem que ninguém lhe avisasse...

Cerca de meia vareta de incenso depois, Qiaqia terminou de preparar o desjejum e o levou até ela.

O mingau de frutos do mar estava delicioso. Os camarões eram grandes e tinham a carne doce, e as vieiras secas estavam carnudas e bem servidas. Não havia café da manhã mais reconfortante para um dia de inverno do que uma tigela quentinha daquilo.

Só que aquela não era a temporada de pesca de camarão-marinho e, como a capital ficava longe da costa, frutos do mar eram produtos extremamente raros.

Vendo quanto ela estava gostando, Qiaqia lhe serviu mais uma tigela.

Ning Xiaoxiao mexeu o mingau com a colher e perguntou: — Lembra que, outro dia, a Consorte Duan pediu ao setor de cozinhas imperiais um Buda Salta o Muro e reclamou porque os camarões eram quase do tamanho de camarõezinhos secos? Como é que agora apareceram camarões assim?

Qiaqia respondeu: — Se todo mundo tivesse essa sorte, como a senhora perceberia o quanto Sua Majestade se importa com a senhorita?

Ela sorriu e piscou com ar travesso. — Este mês chegaram apenas oito porções desses camarões, cada uma com seis pares. Sua Majestade ordenou pessoalmente que guardassem tudo para a senhorita. Nem a imperatriz recebeu um sequer!

Logo cedo, Lu Linyuan havia aquecido tanto o estômago quanto o coração de Ning Xiaoxiao.

Ela pensou que a notícia da grande vitória contra os piratas japoneses havia chegado naquele dia. À noite, Lu Linyuan certamente ofereceria um banquete aos heróis da campanha e acabaria bebendo um pouco além da conta.

Por isso, ordenou a Qiaqia: — Prepare para mim cascas de laranja doce e de tangerina envelhecida, sândalo, flores de kudzu, sementes de cardamomo-branco e flores de feijão-mungo. Depois vá ao Instituto Médico Imperial e peça ao diretor Song um pedacinho de ginseng bem potente. Vou precisar disso daqui a pouco.

Eram ingredientes para uma sopa contra ressaca. No mundo moderno, quando Ning Dazhi voltava bêbado de compromissos sociais, Qi Meijuan reclamava com a boca enquanto, na prática, preparava uma sopa dessas para ele.

Ning Xiaoxiao já a vira fazer aquilo algumas vezes e aprendera um pouco só de observar.

Quando Qiaqia estava quase saindo, chamou-a novamente: — Leve também uma tigela daquele mingau para minha irmã. Acho que ela vai gostar.

Ela própria pegou uma bolsa de água quente e se preparou para visitar Gu Sijin e conversar um pouco.

Mas mal saiu do aposento lateral quando ouviu o estalo de uma tigela se quebrando na pequena cozinha.

Pensando que Qiaqia a tivesse derrubado sem querer, apressou-se até lá, preocupada que a criada pudesse ter se cortado nos cacos.

Quando chegou à porta, porém, ouviu Xiu'er, a criada pessoal da Consorte Duan, repreendendo Qiaqia:

— Explique direito! Por que a sua Nobre Dama Hua recebe quanto quiser de uma coisa que nem a nossa senhora consegue comer?

Xiu'er havia atirado no chão uma tigela perfeitamente boa de mingau de frutos do mar. Qiaqia, inconformada com o desperdício, respondeu sem se preocupar em poupá-la:

— Foi Sua Majestade quem presenteou nossa senhora com esses camarões! Se a Consorte Duan não recebeu nenhum, vá pedir ao imperador! Por que foi derramar um mingau tão bom no chão?

Xiu'er ergueu o queixo, arrogante: — E daí que foi um presente imperial? Acha isso grande coisa?

— Ponha uma coisa nessa cabeça: nossa senhora é consorte, enquanto a sua não passa de nobre dama! Enquanto morar no Palácio Zhongcui, a Consorte Duan será a senhora principal daqui. Até a Nobre Dama Gu, que também mora no palácio, vem apresentar seus respeitos de manhã e à noite. Mas, desde que ficou grávida, a Nobre Dama Hua nem olha direito para nossa senhora! Para quem ela está fazendo essa pose arrogante?

Uma diferença de posto bastava para esmagar alguém. E a Consorte Duan ainda era a mais elevada entre as consortes; sem uma Consorte Nobre acima dela, só ficava abaixo da imperatriz.

Mesmo humilhada, Qiaqia não se atreveu a discutir. Tinha medo de que alguma palavra sua criasse problemas para Ning Xiaoxiao.

Engoliu a raiva e agachou-se em silêncio para recolher a sujeira do chão.

Ao perceber que ela não reagiria, Xiu'er ficou ainda mais atrevida e lhe deu um chute no ombro enquanto estava distraída.

Qiaqia caiu no chão e cortou a palma da mão num caco afiado de porcelana. O sangue começou a escorrer imediatamente.

Ao ver aquilo, Xiu'er riu: — Sua ralé imunda! Escute bem, da próxima vez que você... Ai! Quem é?

Não conseguiu terminar. Sentiu uma dor lancinante no couro cabeludo e, ao virar a cabeça, viu Ning Xiaoxiao agarrando-lhe os cabelos com força, o olhar feroz.

— Quem você pensa que é, sua desgraçada, para se atrever a maltratar alguém meu?

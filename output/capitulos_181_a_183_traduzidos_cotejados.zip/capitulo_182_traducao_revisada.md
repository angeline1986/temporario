# Capítulo 182 — A Consorte Duan faz seu número de cachorro faminto na imundície

Era assim que as coisas funcionavam no palácio: quanto mais você aguentava calada e recuava, mais os miseráveis se aproveitavam e montavam em cima de você.

Como Ning Xiaoxiao era próxima de Gu Sijin, os outros achavam que ambas eram do mesmo tipo: bondosas, gentis e fáceis de intimidar.

Além disso, no passado, Ning Xiaoxiao só queria se agarrar à proteção de Gu Sijin e evitar qualquer envolvimento com Lu Linyuan. Por isso, mantivera a cabeça baixa, desenvolvendo-se discretamente, e acabara parecendo ainda mais inofensiva.

Mas as coisas haviam mudado.

Quando voltou ao mundo moderno, Qi Meijuan lhe dissera uma coisa:

— Você foi parar dentro de um livro, tem um poder especial, o homem mais poderoso dessa história claramente gosta de você e seus pais ainda podem lhe dar apoio. Por que diabos precisa bancar o coelhinho indefeso diante daquele bando de personagens de papel? Mulher, às vezes a gente precisa mostrar os dentes para se proteger e não ser pisoteada.

Ela já tinha engolido desaforos demais. Não queria continuar assim.

Xiu'er berrava de dor enquanto Ning Xiaoxiao a puxava pelos cabelos e batia sua cabeça contra o fogão com tanta força que o sangue começou a jorrar. Qiaqia ficou apavorada e correu para tentar separá-las.

— Minha senhora, pare, por favor! Eu estou bem! Xiu'er é a principal criada da Consorte Duan. Não vale a pena criar uma confusão tão grande por minha causa!

Ainda tinha medo de criar confusão? A confusão já estava armada.

Com tamanho escândalo, as pessoas logo começaram a se aglomerar.

Praticamente todos os criados do Palácio Zhongcui se reuniram diante da cozinha, e a Consorte Duan e Gu Sijin também apareceram ao ouvir os gritos.

Ao ver Xiu'er quase reduzida a meio cadáver nas mãos de Ning Xiaoxiao, até a Consorte Duan, que costumava disfarçar tudo com palavras doces, perdeu a paciência:

— Nobre Dama Hua! O que significa isso? Xiu'er é minha criada pessoal! Bater nela é o mesmo que me agredir! O imperador a mimou tanto que a senhora se esqueceu de seu lugar? Como ousa faltar assim com as regras?

Gu Sijin também ficou boquiaberta. Temendo que a Consorte Duan descontasse sua ira em Ning Xiaoxiao, tentou apaziguá-la: — Consorte Duan, acalme-se. Talvez tenha havido algum mal-entendido.

Aproximou-se, segurou o braço de Ning Xiaoxiao e balançou a cabeça, franzindo as sobrancelhas: — Xiaoxiao, solte Xiu'er primeiro...

Ning Xiaoxiao trocou um olhar com Gu Sijin, pedindo que não se metesse. Primeiro ordenou que Qiqi e as demais levassem Qiaqia para cuidar do ferimento. Depois arrastou Xiu'er pelos cabelos até a Consorte Duan e a atirou de joelhos diante dela.

— Já que a Consorte Duan quer falar de regras, vamos discutir as regras direitinho.

Apontou para o mingau espalhado pelo chão: — Aqueles camarões foram um presente de Sua Majestade. Xiu'er derramou tudo sem nem perguntar, conspurcando o presente. Em que regra isso se encaixa?

Xiu'er se arrastou até os pés da Consorte Duan, agarrou a barra de sua saia e choramingou: — Minha senhora, foi sem querer! Além disso... eu nem sabia que os camarões tinham sido presentes do imperador...

Ning Xiaoxiao cruzou os braços e a olhou de cima, com um sorriso frio.

— Não sabia? Ora, errar é errar. Se eu matasse sua mãe e depois dissesse que não sabia que era sua mãe, isso resolveria tudo?

Vendo como Ning Xiaoxiao estava furiosa, a Consorte Duan inicialmente pensou em invocar sua autoridade como senhora principal do palácio e castigá-la.

Mas reconsiderou. Ning Xiaoxiao realmente tinha o favor imperial, e, se os camarões fossem mesmo um presente de Lu Linyuan, Xiu'er certamente havia errado primeiro.

A Consorte Duan era inteligente e especialista em ferir os outros com palavras macias e intenções venenosas.

Sabia que aquele não era o momento de enfrentar Ning Xiaoxiao diretamente. Controlando-se, disse: — Xiu'er errou. Eu mesma vou discipliná-la quando voltarmos. Nobre Dama Hua, faça-me a gentileza de não levar isso adiante. Quanto aos ingredientes preciosos desperdiçados, vou repô-los.

Ning Xiaoxiao soltou uma risadinha: — Já que a Consorte Duan está pedindo, não serei tão insensata a ponto de recusar. Mas os ingredientes eram um presente do imperador. Xiu'er cometeu um grave desrespeito e deveria ser decapitada. Se o assunto chegar aos ouvidos de Sua Majestade, temo que ele precise aplicar a lei.

Ela fingiu ponderar por um instante antes de continuar: — Façamos assim. Como Xiu'er é uma criada da família da Consorte Duan, não quero que perca a cabeça por uma coisa tão pequena. Basta uma punição leve, para que aprenda a lição.

Consorte Duan: — Então diga. O que pretende fazer?

Ning Xiaoxiao: — Muito simples. Ela vai se deitar no chão e lamber esse mingau até deixar tudo limpo. Aí o assunto estará encerrado.

Todos prenderam a respiração, temendo por Ning Xiaoxiao.

O que significava ser uma criada pertencente à família da senhora? Significava representar a honra da própria consorte.

Se Ning Xiaoxiao obrigasse Xiu'er a lamber do chão o mingau derramado, a Consorte Duan perderia toda a dignidade diante do Palácio Zhongcui.

O rosto da Consorte Duan estava lívido. Gu Sijin puxou Ning Xiaoxiao pelo braço, querendo convencê-la a recuar.

Ning Xiaoxiao apertou a mão da amiga e, antes que ela pudesse falar, gritou para Xiu'er: — Ou lambe, ou morre. Escolha!

Xiu'er olhou chorando para sua senhora. A Consorte Duan inspirou profundamente e falou entre os dentes:

— Nobre Dama Hua, você realmente pretende chegar a esse ponto?

Quando uma criada ousava agir daquela maneira, era porque contava com o consentimento de sua senhora. Sem a permissão tácita da Consorte Duan, Xiu'er jamais teria se comportado de modo tão descarado.

Ning Xiaoxiao lançou à consorte um olhar de lado e pensou:

【Eu nem fui atrás de você e já veio correndo se oferecer para levar uma surra?】

Ning Xiaoxiao não estava mais com paciência para discutir.

Fechou os olhos, abriu o documento e reescreveu os próximos cem caracteres da trama.

No instante seguinte, a Consorte Duan pareceu enlouquecer. Sem a menor preocupação com a própria dignidade, curvou-se, agarrou a cabeça de Xiu'er e começou a esfregá-la contra a poça suja de mingau no chão.

Enquanto fazia isso, xingava furiosamente: — Come! Come essa porcaria!

O mingau estava misturado com terra e cinzas de carvão e tinha um gosto horrível. Xiu'er não conseguia engolir quase nada.

Ao ver que, depois de todo aquele tempo, ainda restava uma poça enorme, a Consorte Duan se irritou: — Inútil! Se não consegue terminar, eu ajudo!

Dizendo isso, jogou-se de bruços no chão, enterrou o rosto no mingau e começou a sorvê-lo freneticamente.

Todos os presentes no Palácio Zhongcui ficaram atônitos. As criadas da consorte correram para puxá-la: — Minha senhora! O que está fazendo? Isso está sujo! Não pode comer!

Mas a Consorte Duan se comportava como um cachorro faminto atirando-se numa pilha de imundície, sorvendo ruidosamente e até grunhindo como um porco:

— Oinc, oinc~ Não se metam! Não desperdiçar comida é uma virtude tradicional do povo chinês! Oinc, oinc~ Não vou levantar daqui enquanto não terminar!

Gu Sijin estava tão chocada que seus olhos quase saltaram das órbitas. Ning Xiaoxiao segurou a mão dela e disse baixinho: — Irmã, vamos voltar para nossos aposentos.

Ao cruzar a porta da cozinha, Ning Xiaoxiao fez questão de olhar para trás e ordenar: — Tragam dois pãezinhos cozidos no vapor para a Consorte Duan. Assim ela pode molhá-los no mingau e aproveitar melhor!

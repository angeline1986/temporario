# Validação e revisão cruzada — Capítulo 272

## Fontes e método
- Base em português: `novel capitulos 271 a 300 - ch.epub`, entrada `index_split_001.html`.
- Texto de controle: `novel_capitulos_271_a_300(20261106-202946).docx` (chinês tradicional); segundo DOCX idêntico por SHA-256.
- O EPUB contém 74 unidades narrativas para este capítulo, alinhadas por sequência às 74 unidades não vazias do DOCX.
- Intervalo real no DOCX, índices base zero: **79–155** (incluindo vazios); 74 índices não vazios, todos presentes no CSV.
- O EPUB inclui duas linhas de apresentação da coletânea antes do capítulo 271, excluídas do cotejo por não serem texto do capítulo.
- A tradução revisada utiliza a versão portuguesa do EPUB como referência de tradução existente, com correções guiadas pelo original chinês e continuidade dos capítulos anteriores. Aproveitou-se também a versão literária em português já elaborada anteriormente para este lote, após confronto das passagens e correção de divergências identificadas.

## Conferências estruturais
- CSV: **74** linhas, cabeçalho exato `indice_docx,original_chines,traducao_portugues`.
- Índices reais, únicos, crescentes; original chinês corresponde ao DOCX: **OK**.
- A tradução no CSV corresponde, na mesma sequência, ao Markdown: **OK**.
- Título, parágrafos, notas/apartes e marcadores presentes no DOCX incluídos: **OK**.

## Erros do EPUB e decisões de tradução relevantes
- EPUB alterna **Consorte Tong / consorte Tong**; chinês `佟嬪` exige **Concubina Tong**.
- `顧貴人` é **Nobre Dama Gu**, não consorte genérica.
- `嗩呐` mantido como **suona**, instrumento presente no contexto de funerais e festas.
- `刑服` é trocadilho sonoro com `幸福`, trocando felicidade por punição/pena; o português explicita “pena” e mantém a ironia.
- `茶味十足` descreve manipulação afetiva teatral, não sabor ou cheiro de chá.
- O expediente da Concubina Tong é uma tentativa de drogar o imperador, não fato consumado nessa cena; só a própria Tong é forçada a ingerir os pratos e bebidas.

## Alcance e limitações
A correspondência EPUB–DOCX foi verificada quanto a número e ordem das unidades. As intervenções editoriais acima foram examinadas em confronto com o chinês; a tradução foi revisada contextualmente. **Não foi realizada uma segunda certificação semântica independente de cada oração**. Correspondência estrutural não prova, isoladamente, equivalência semântica. A revisão não inclui capítulos posteriores ao 273.

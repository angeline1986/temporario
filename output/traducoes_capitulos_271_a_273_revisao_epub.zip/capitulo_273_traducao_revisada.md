# Capítulo 273 — Me dê

A Concubina Tong perdera completamente a cabeça.

Ela quase arrancou a roupa de baixo do pobre Sanfu com sua investida. Só quando sete ou oito guardas apareceram conseguiram separá-la dele à força.

Fora de si, ora gritava e rasgava as próprias roupas, ora soltava gargalhadas agudas e sinistras como o canto de uma coruja noturna.

Lu Linyuan mandou levá-la a um salão lateral, amarrar suas mãos e pés e jogá-la numa tina de água fria para ver se recuperava um pouco a lucidez.

As outras mulheres do harém tinham visto cada movimento de Tong e começaram a tirar suas próprias conclusões.

Aquele comportamento anormal só podia ter duas explicações:

Ou estava possuída por algum espírito maligno ou havia colocado alguma substância imunda e clandestina na comida e no vinho daquele dia, acabando por cair na própria armadilha.

Alguém mandou discretamente um servo chamar a imperatriz. Ela chegou quase ao mesmo tempo que o diretor Song, do Instituto Médico Imperial.

Depois de examinar cuidadosamente a comida e o vinho servidos no Palácio Yaohua, o diretor Song juntou as mãos em saudação e informou a Lu Linyuan:

— Majestade, tanto o vinho quanto os pratos contêm uma substância extremamente potente chamada “Pó da Paixão Desvairada”. Trata-se de um preparado aromático que estimula o desejo entre homens e mulheres. Seu efeito é violento: uma dose mínima basta para fazer quem o ingere perder a razão, ficar tomado pelo desejo e cometer atos indizíveis...

Todos ficaram alvoroçados. A imperatriz, apavorada, levou a mão ao peito e perguntou depressa:

— Esse remédio faz mal ao corpo?

O médico imperial respondeu: — Qualquer preparado estimulante desse tipo prejudica a saúde. E o Pó da Paixão Desvairada é especialmente forte. Durante o efeito, a pessoa perde completamente a noção do que faz; depois, há um grande desgaste de energia vital, com prejuízos à saúde.

— Que maravilha! Então a Concubina Tong estava tramando contra Sua Majestade?!

A imperatriz conduziu as concubinas numa reverência coletiva diante de Lu Linyuan e declarou: — Majestade, drogar o imperador é crime capital, punível com a execução dos nove graus de parentesco! E Tong vive no palácio há anos. Quem poderia lhe fornecer uma coisa tão suja? Só pode tê-la conseguido na casa da família quando voltou para visitá-los durante o Festival das Lanternas, há dois dias!

— O clã Tong não pode se eximir dessa história. Tong Guowei chegou ao ponto de pôr em risco a sagrada saúde de Vossa Majestade para conseguir uma noite de favor imperial para a filha? Como podemos continuar sendo indulgentes diante de tamanha traição?

O clã Tong já estava à beira do colapso. A atitude da Concubina Tong naquele momento equivalia a acelerar sua ruína.

Nos últimos tempos, Lu Linyuan havia arquitetado cuidadosamente os acontecimentos para fazer a imperatriz-viúva e a imperatriz se envolverem por iniciativa própria na disputa política da corte, usando os interesses de suas famílias de origem para conter Tong Guowei.

Mas ele tampouco ficara parado nos bastidores.

Em segredo, incumbira Chu Xingran e Ren Duanli de procurar os discípulos políticos e seguidores de Tong Guowei.

A maioria das pessoas ligadas a Tong Guowei ocupava cargos de prestígio na corte.

Tinham se aliado a ele sobretudo porque Tong lhes prometera benefícios sedutores.

Lu Linyuan não sabia exatamente quais eram essas vantagens, mas tinha certeza de que podia oferecer-lhes ainda mais.

Prometeu que, se mudassem de lado e enfrentassem Tong Guowei, depois da queda dele não só perdoaria os erros de lealdade cometidos até ali, como também lhes concederia feudos próprios para governar.

Era uma proposta tentadora. Os oficiais sabiam muito bem que, mesmo que Tong Guowei derrubasse Lu Linyuan e se tornasse imperador, seria quase impossível arrancar feudos de um homem tão velho e astuto.

E, caso recusassem, mesmo que Tong Guowei se rebelasse e Lu Linyuan fosse derrotado, este mobilizaria todos os soldados da Guarda dos Tigres e da Guarda Imperial para massacrar as famílias inteiras daqueles que naquele dia ajudassem o usurpador, dos mais velhos aos mais novos.

No fim, diante da combinação de promessas e ameaças de Ren Duanli e Chu Xingran, todos começaram secretamente a abandonar Tong Guowei e voltar a prestar lealdade à corte de Lu Linyuan.

Agora, o imperador ainda aguardava a resposta das últimas figuras decisivas.

Se também conseguisse conquistá-las, Tong Guowei não passaria de um tigre de papel. Nem seria necessário enviar tropas: bastaria atirar uma tocha para reduzir o clã Tong a cinzas, sem deixar vestígios.

Lu Linyuan sempre só atacava depois de ter certeza absoluta do sucesso.

Um único golpe para abater o inimigo; arrancar o mal pela raiz, sem deixar ameaças futuras.

E, evidentemente, esse momento ainda não havia chegado.

Por isso, não seguiu o conselho da imperatriz. Ordenou apenas que a Concubina Tong fosse confinada no Palácio Yaohua, sem receber visitas nem permissão para sair, completamente isolada do mundo exterior.

A imperatriz viu aquela excelente oportunidade de derrubar Tong ser desperdiçada com uma punição que lhe parecia quase inofensiva e quis insistir.

Mas Lu Linyuan não tinha interesse em ouvir mais uma palavra dela. Pegou Ning Xiaoxiao pela mão, subiu com ela à carruagem imperial e voltou ao palácio.

❤

Durante o trajeto de volta, Lu Linyuan permaneceu com um leve sorriso no rosto.

Ning Xiaoxiao perguntou do que ele ria. — De como você fica linda quando sente ciúme — respondeu ele.

Ao chegarem ao Palácio Chaoyang, Lu Linyuan foi primeiro tomar banho e trocar de roupa. Durante o banho, achou a água estranhamente quente naquele dia. Quanto mais se lavava, mais pequenas gotas de suor surgiam em sua testa.

Quando terminou, viu no espelho que suas bochechas estavam muito vermelhas. Pensou que fosse por causa do vapor e não deu importância.

Mais tarde, enquanto Ning Xiaoxiao tomava banho, ele ficou sentado num assento aquecido, bebendo água fria sem parar, tentando abafar o fogo inexplicável que se acendera em seu peito.

TOC, TOC, TOC!

De repente, Sanfu bateu à porta e entrou com o rosto tomado pelo pânico.

— M-Majestade... Hoje, no Palácio Yaohua, usei os utensílios de lá para preparar seu chá... Eu os lavei cuidadosamente, mas o médico imperial disse que aquela substância é tão potente que uma quantidade minúscula já provoca sintomas. Estou com medo de que o senhor... M-Majestade?

Lu Linyuan baixou as pálpebras, respirando cada vez mais pesadamente. As veias saltavam nos antebraços firmes e bem proporcionados.

Quando ele ergueu devagar a cabeça, Sanfu finalmente percebeu que seus olhos estavam injetados de sangue, tingidos de um vermelho assustador.

— Saia daqui.

A voz rouca e grave fez Sanfu fugir sem se atrever a ficar mais um instante, temendo que, num súbito acesso como o de Tong, o imperador acabasse fazendo com ele alguma coisa...

Só depois de sair dos aposentos é que o eunuco murmurou, com expressão chorosa:

— Ai, ai... Consorte Nobre, agora é melhor rezar para ter sorte!

— E, por favor, não me culpe! Este servo até se ajoelha para lhe pedir perdão!

Ning Xiaoxiao acabara de sair da tina de banho. Tinha pegado uma toalha para enxugar o corpo e estava prestes a se vestir quando, de repente, duas mãos ardentes lhe agarraram a cintura.

Ela estremeceu e se virou por entre as nuvens de vapor.

O homem apoiou o queixo em seu ombro, deixando a respiração quente roçar-lhe a clavícula.

— A-Yuan...

— Xiaoxiao. — Lu Linyuan mordiscou-lhe a orelha. A leve pontada de dor arrancou dela um gemido baixo.

Ele roçou delicadamente a ponta do nariz na borda de sua orelha e, com uma voz grave, envolvente e persuasiva, murmurou:

— Me dê.

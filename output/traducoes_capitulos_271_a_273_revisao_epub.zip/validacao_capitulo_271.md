# Validação e revisão cruzada — Capítulo 271

## Fontes e método
- Base em português: `novel capitulos 271 a 300 - ch.epub`, entrada `index_split_000.html`.
- Texto de controle: `novel_capitulos_271_a_300(20261106-202946).docx` (chinês tradicional); segundo DOCX idêntico por SHA-256.
- O EPUB contém 73 unidades narrativas para este capítulo, alinhadas por sequência às 73 unidades não vazias do DOCX.
- Intervalo real no DOCX, índices base zero: **3–78** (incluindo vazios); 73 índices não vazios, todos presentes no CSV.
- O EPUB inclui duas linhas de apresentação da coletânea antes do capítulo 271, excluídas do cotejo por não serem texto do capítulo.
- A tradução revisada utiliza a versão portuguesa do EPUB como referência de tradução existente, com correções guiadas pelo original chinês e continuidade dos capítulos anteriores. Aproveitou-se também a versão literária em português já elaborada anteriormente para este lote, após confronto das passagens e correção de divergências identificadas.

## Conferências estruturais
- CSV: **73** linhas, cabeçalho exato `indice_docx,original_chines,traducao_portugues`.
- Índices reais, únicos, crescentes; original chinês corresponde ao DOCX: **OK**.
- A tradução no CSV corresponde, na mesma sequência, ao Markdown: **OK**.
- Título, parágrafos, notas/apartes e marcadores presentes no DOCX incluídos: **OK**.

## Erros do EPUB e decisões de tradução relevantes
- EPUB chama Tong de **Consorte Tong**, mas o chinês emprega `佟嬪`, portanto **Concubina Tong**; `貴妃` refere-se à **Consorte Nobre Ning**. Corrigidos título e hierarquia.
- EPUB usa “anfitrião” para Ning em `宿主`; corrigido para **anfitriã**. `小七` permanece **Xiao Qi**, sem gênero humano obrigatório.
- `後麵一百字` são **cem caracteres seguintes**, não “últimas cem palavras”, como diz o EPUB.
- `【 】` preservados para pensamentos/sistema, embora o EPUB os altere para aspas normais em alguns pontos.
- `吃席` ganha conotação de banquete fúnebre no contexto; a paródia do funeral, retrato preto e branco e velas foi preservada.
- `qnmlgb` é abreviação vulgar em pinyin; adaptação expressiva em PT-BR, sem alegar tradução fonética literal.
- `老六` é xingamento coloquial dirigido a Xiao Qi; não se confunde com um personagem Lao Liu nesta passagem.
- A visão do documento é uma projeção da trama, não evidência de que a violência sexual planejada se consumou.

## Alcance e limitações
A correspondência EPUB–DOCX foi verificada quanto a número e ordem das unidades. As intervenções editoriais acima foram examinadas em confronto com o chinês; a tradução foi revisada contextualmente. **Não foi realizada uma segunda certificação semântica independente de cada oração**. Correspondência estrutural não prova, isoladamente, equivalência semântica. A revisão não inclui capítulos posteriores ao 273.

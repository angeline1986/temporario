# Validação e revisão cruzada — Capítulo 273

## Fontes e método
- Base em português: `novel capitulos 271 a 300 - ch.epub`, entrada `index_split_002.html`.
- Texto de controle: `novel_capitulos_271_a_300(20261106-202946).docx` (chinês tradicional); segundo DOCX idêntico por SHA-256.
- O EPUB contém 59 unidades narrativas para este capítulo, alinhadas por sequência às 59 unidades não vazias do DOCX.
- Intervalo real no DOCX, índices base zero: **156–217** (incluindo vazios); 59 índices não vazios, todos presentes no CSV.
- O EPUB inclui duas linhas de apresentação da coletânea antes do capítulo 271, excluídas do cotejo por não serem texto do capítulo.
- A tradução revisada utiliza a versão portuguesa do EPUB como referência de tradução existente, com correções guiadas pelo original chinês e continuidade dos capítulos anteriores. Aproveitou-se também a versão literária em português já elaborada anteriormente para este lote, após confronto das passagens e correção de divergências identificadas.

## Conferências estruturais
- CSV: **59** linhas, cabeçalho exato `indice_docx,original_chines,traducao_portugues`.
- Índices reais, únicos, crescentes; original chinês corresponde ao DOCX: **OK**.
- A tradução no CSV corresponde, na mesma sequência, ao Markdown: **OK**.
- Título, parágrafos, notas/apartes e marcadores presentes no DOCX incluídos: **OK**.

## Erros do EPUB e decisões de tradução relevantes
- O EPUB traduz erroneamente `苦茶子` por “sementes de chá amargo”; trata-se de gíria de internet para **cueca/roupa íntima**, corrigida no texto.
- `迷情散` é um nome narrativo de afrodisíaco: adotado **Pó da Paixão Desvairada** como tradução contextual, sem equivalência química externa.
- O narrador não confirma a suposição da imperatriz sobre a procedência do pó; seu discurso é acusação, não fato estabelecido.
- A promessa de concessão de feudos e a ameaça de massacres são movimentos políticos de Lu Linyuan, não atos já executados.
- Lu sofre efeitos tardios por utensílios potencialmente contaminados na preparação de chá: não dizer que ele bebeu diretamente o vinho drogado.
- O marcador `❤` foi preservado e o capítulo termina exatamente na fala “Me dê”, sem avançar ao 274.

## Alcance e limitações
A correspondência EPUB–DOCX foi verificada quanto a número e ordem das unidades. As intervenções editoriais acima foram examinadas em confronto com o chinês; a tradução foi revisada contextualmente. **Não foi realizada uma segunda certificação semântica independente de cada oração**. Correspondência estrutural não prova, isoladamente, equivalência semântica. A revisão não inclui capítulos posteriores ao 273.

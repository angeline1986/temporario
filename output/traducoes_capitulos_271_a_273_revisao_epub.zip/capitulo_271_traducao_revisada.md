# Capítulo 271 — Aniversário da Concubina Tong: Xiaoxiao vai ao banquete

— Pfff!

— Cof, cof, cof...!

Ning Xiaoxiao cuspiu no chão a sopa de abalone e bexiga natatória de peixe que tinha na boca. A nova missão anunciada por Xiao Qi a fizera engasgar tão feio que ela não parava de tossir.

Gu Sijin largou a tigela e os hashis e correu para seu lado. Enquanto lhe dava leves tapinhas nas costas, serviu-lhe uma xícara de água morna:

— Está vendo? Eu disse desde cedo para comer devagar, tomar cuidado para não se engasgar, mas você não me escuta. E então? Já está melhor?

Xiaoxiao respondeu de qualquer jeito que estava tudo bem, enquanto interrogava Xiao Qi mentalmente:

【Você está querendo arrumar confusão comigo de propósito, não é? Quando aquelas concubinas se desdobravam para fazer canalhices, você não me deixava ir atrás delas. Agora que A-Yuan está finalmente decidido a cuidar dos assuntos de Estado, você manda que eu vá atrapalhar? Não é só outra maneira de me obrigar a sabotar o homem?】

Ao ouvir as reclamações de Ning Xiaoxiao, Xiao Qi se sentiu ainda mais injustiçado.

Mas ele só estava cumprindo as ordens de Qi Meijuan...

Fora Qi Meijuan quem pedira que o sistema desse à filha uma missão para humilhar as mulheres do harém. A cabeça de um sistema não tinha as voltas e reviravoltas de uma mente humana. Xiao Qi pensara: Ning Xiaoxiao gosta de Lu Linyuan; se Lu Linyuan foi passar o aniversário de outra mulher, é claro que ela vai ficar irritada.

Achara que estava prestando um ótimo serviço. Quem diria que, mais uma vez, pisaria exatamente na mina errada?

【Então... se você não quiser cumprir esta missão, anfitriã, eu posso pedir à Agência de Administração do Espaço-Tempo que a troque por outra?】

Ning Xiaoxiao: 【???】

【Desde quando você, seu peste, ficou tão fácil de convencer?】

Normalmente, mesmo quando ela implorava para Xiao Qi trocar uma missão, ele se recusava. E hoje estava se oferecendo por vontade própria?

Quando alguma coisa parece boa demais, tem caroço nesse angu. Xiaoxiao não acreditava que Xiao Qi, que sempre parecera empenhado em contrariá-la, tivesse mudado de personalidade de repente.

Aquela missão certamente escondia alguma coisa além do que parecia.

Mas Xiao Qi já estava ocupado procurando seus superiores para pedir a substituição e nem respondeu.

Isso só reforçou as suspeitas dela.

Ela fechou os olhos e abriu o documento. Com seu nível atual de acesso, ainda conseguia espiar os cem caracteres seguintes da trama. Por precaução, resolveu dar uma olhada.

Mas que maravilha, hein!

Era daquelas coisas que você só descobre quando olha — e, depois de olhar, só dá vontade de mandar tudo à puta que pariu!

【Naquele dia, a Concubina Tong se arrumou cuidadosamente para imitar a Consorte Nobre e enganou Lu Linyuan, atraindo-o ao Palácio Yaohua para comemorar seu aniversário. Desde cedo, havia misturado ao vinho um afrodisíaco capaz de perturbar os sentidos e despertar o desejo, fazendo de tudo para convencê-lo a beber.】

【O medicamento era extremamente potente. Pouco depois de ingeri-lo, Lu Linyuan começou a sentir o corpo em chamas e, em meio à confusão dos sentidos, confundiu a Concubina Tong com a Consorte Nobre. Então...】 (Contem vocês mesmos se isso dá cem caracteres!)

Depois daqueles cem caracteres, todo o restante do documento aparecia coberto por um mosaico, à espera de que ela própria descobrisse o que aconteceria.

A pressão de Xiaoxiao disparou. Queria arrancar a roupa da Concubina Tong e jogá-la num chiqueiro naquele mesmo instante, para que pudesse satisfazer o cio à vontade.

【Que espécie de macaca desengonçada é você, balançando num cipó sobre o Grande Vale do Rift, na África?!】

【Você acha que vai disputar comigo uma coisa que nem eu mesma experimentei ainda?!】

Ela chamou Xiao Qi de volta e, fervendo de raiva, declarou: 【Não precisa trocar! Eu vou fazer essa missão!】

*

Enquanto isso, no Palácio Yaohua.

Lu Linyuan já estava ali havia quase um quarto de hora. Ficar a sós com qualquer mulher que não fosse Ning Xiaoxiao era uma tortura, segundo após segundo.

Pior ainda: a Concubina Tong não parava de se contorcer, posar e lançar olhares insinuantes, como se tivesse algum problema sério. Ele já cerrava os punhos, morrendo de vontade de lhe dar um soco na cara para curar aquela mania de fazer as feições dançarem.

Tanto a comida quanto o vinho estavam adulterados. A Concubina Tong conhecia bem a tática de não agir enquanto o adversário não agisse: se Lu Linyuan não comia nem bebia, ela também não comia nem bebia.

Quando os pratos esfriavam, mandava Xianglan levá-los para aquecer. Quando o vinho perdia o calor, ordenava que esquentasse outra jarra.

A paciência de Lu Linyuan se esgotou. — Se você não pretende comer nem beber, é melhor ir dormir cedo.

Ele se levantou e se virou para sair. — Tenho outros assuntos. Vou embora.

Vendo que ele ia partir, a Concubina Tong levantou-se imediatamente e correu atrás dele.

Abriu os braços e se lançou em sua direção. — Majestade~ Majestade, fique comigo mais um pouquinho~

Pelo tom da voz, Lu Linyuan percebeu de onde ela vinha e como se aproximava. Sem hesitar, girou o corpo e desferiu um chute rodado.

— Aaaah~~~!

A Concubina Tong saiu voando por vários metros e caiu pesadamente no chão, espalhando por toda parte as joias e pérolas que enfeitavam sua cabeça.

Lu Linyuan lançou-lhe um olhar. — Tentando me atacar de surpresa?

— Majestade... o senhor entendeu mal. Eu só queria...

BANG!

Antes que ela terminasse, alguém escancarou as portas do Palácio Yaohua com um chute.

Ning Xiaoxiao entrou sorrindo. — Ora, ora~ Será que cheguei tarde? Feliz aniversário, irmãzinha Tong~

Ao ver a Concubina Tong caída e Lu Linyuan parado junto à porta, perfeitamente “intacto”, ela soltou um profundo suspiro de alívio.

【Ainda bem, ainda bem! Por pouco o porco não fuçou a minha preciosa couve...】

Lu Linyuan: — ???

Ning Xiaoxiao aproximou-se com passos delicados, inclinou-se para ajudar Tong a se levantar e ainda sacudiu carinhosamente a poeira de suas roupas.

— Ora, irmãzinha Tong, por que tanta cerimônia? Somos todas irmãs da mesma família!

— Tsc, tsc! Foi só ouvir minha voz e você se apressou a se prostrar de corpo inteiro diante de mim. Com tanta formalidade, até fico sem jeito!

A expressão da Concubina Tong ficou horrível.

Naquele dia, ela havia tentado imitar Ning Xiaoxiao, vestindo-se de modo muito semelhante ao que a outra costumava usar.

Agora que a verdadeira dona daquele estilo irrompera no palácio, mesmo que conseguisse drogar Lu Linyuan, não adiantaria nada.

Tong queria xingar Xiaoxiao, mas os olhos de Lu Linyuan estavam tomados de uma ferocidade cortante. Ele a encarava como uma lâmina capaz de lhe raspar a carne dos ossos.

Aquele olhar era um aviso claríssimo:

Se ousar insultar a minha mulher, eu arranco a sua pele aqui mesmo!

A Concubina Tong estremeceu sob a ameaça e só conseguiu forçar um sorriso constrangido. — O que traz a senhora aqui, Consorte Nobre...?

— É claro que eu tinha de vir! — Ning Xiaoxiao sorriu radiante. — Seu aniversário acontece só uma vez por ano. E, como dizem, nunca se sabe o que chega primeiro: o amanhã ou uma tragédia. Vai que você nem vive até o ano que vem? Este pode ser seu último aniversário! Como eu poderia deixar de comemorá-lo como merece?

O rosto de Tong alternou entre o verde e o branco. Lu Linyuan, por outro lado, não conseguiu conter a risada ao ouvir aquelas palavras de sua pequena tirana.

Estava radiante por dentro e não achava nem um pouco que Xiaoxiao tivesse estragado seus planos.

Como suspeitava, embora ela dissesse que não se importava, ainda sentia ciúme quando ele ficava sozinho com outra mulher.

De repente, percebeu que gostava bastante daquela sensação de ser possessivamente reivindicado por sua amada.

Ning Xiaoxiao tomou o braço de Tong com a maior intimidade. — Não poderia vir ao seu aniversário de mãos vazias. Por isso, preparei um presente especial.

Ela bateu palmas. As portas do Palácio Yaohua se abriram novamente, e Gu Sijin entrou à frente de uma dezena de concubinas quase anônimas que viviam aposentadas em vida no harém.

Organizadas e disciplinadas, elas se dispuseram numa única fileira.

Gu Sijin ficou bem no centro, segurando contra o peito um retrato em preto e branco da Concubina Tong.

As outras mulheres se distribuíram dos dois lados, cada uma segurando uma vela branca.

Ao contemplar aquela cena, a Concubina Tong ficou tão furiosa que seus dentes e lábios tremiam.

— V-você... está preparando o meu funeral?!

# Capítulo 272 — Que a sua pena dure para sempre

Com a chegada daquelas mulheres, o Palácio Yaohua se transformou imediatamente numa enorme reunião com jeito de banquete fúnebre.

A Concubina Tong mal conseguia conter a fúria. — Consorte Nobre, por que não chama mais alguém para tocar uma suona também?

— Ora! — Ning Xiaoxiao cobriu a boca, fingindo surpresa. — Como adivinhou que eu já tinha providenciado uma suona especialmente para você?

Mal terminou de falar, Bengbeng apareceu caminhando todo garboso com uma suona nas mãos. Foi direto até Tong e começou a tocar uma marcha fúnebre bem ao lado do ouvido dela.

O barulho era tão estridente que a Concubina Tong sentiu que seus tímpanos iam estourar. Tapou os ouvidos e gritou: — Pare! Vou ficar surda! Pare agora!

— Majestade! O senhor não vai fazer nada enquanto a Consorte Nobre apronta uma coisa dessas?

O olhar de Lu Linyuan escureceu. — A Consorte Nobre está sendo gentil ao comemorar seu aniversário. É melhor tirar as mãos dos ouvidos e não desprezar a boa vontade dela.

Concubina Tong: — ???

Ning Xiaoxiao explicou com um sorriso: — Você entendeu mal minhas boas intenções. Entre o povo, quando há casamento, também se recebem as noivas ao som de tambores, gongos e suona. Na verdade, o instrumento é muito usado em ocasiões felizes. Seu aniversário é motivo de enorme alegria! Como Bengbeng sabe tocar, achei que ele poderia animar sua festa com uma bela música.

Mas aquilo que Bengbeng estava tocando não tinha absolutamente nada de alegre!

Ouvindo aquela melodia, Tong quase caiu em prantos; só lhe faltava passar um punhado de cinzas no rosto e começar a cantar:

Com um pãozinho de milho nas mãos, sem uma gota de óleo na comida...

— Agradeço a gentileza da Consorte Nobre! Mas simplesmente não consigo ouvir isso! Por favor, tenha piedade e faça parar!

Ning Xiaoxiao suspirou, resignada. — Ah... Você não gostou? Que pena.

Ela fez um sinal, e Bengbeng parou imediatamente. Então continuou: — Já que não gostou da suona, pedi à Nobre Dama Gu que compusesse, com as outras concubinas, uma canção de aniversário para você. Tenho certeza de que vai adorar~

Xiaoxiao piscou para as mulheres e levantou os braços como uma maestrina.

— Hoje é seu aniversário! Preparar... cantar~

As concubinas começaram a cantar em perfeita sincronia:

— Hoje é seu aniversário, trazemos nossos melhores votos~

— Num dia tão especial, de sorrisos radiantes, nos reunimos aqui~

— ...

Enquanto cantavam, aproximavam-se de Tong até cercá-la completamente. Justo quando chegaram ao refrão, ergueram as vozes com ainda mais entusiasmo:

— Diga bye-bye para todas as alegrias, diga hi-hi para todas as preocupações~

— Querida, querida, feliz aniversário! Que sua pena dure para sempre~

— Sua pena para seeempre~

Quando a música acabou, a Concubina Tong estava a um passo de enlouquecer por causa de Ning Xiaoxiao.

Admitia a derrota. Não tinha como vencer Xiaoxiao. Estava arrependidíssima da imprudência de ter provocado Lu Linyuan naquele dia!

Estava exausta. Agora só queria encontrar um canto vazio onde pudesse se esconder e esquecer o mundo.

Cambaleou até Lu Linyuan e fez uma reverência. — Majestade... estou cansada. Por favor, leve logo a Consorte Nobre embora.

Lu Linyuan franziu o cenho. — Como é? Pelo que está dizendo, a Consorte Nobre se empenhou tanto em comemorar seu aniversário e você não está feliz?

Ning Xiaoxiao se aninhou nos braços de Lu Linyuan e adotou uma voz dengosa, carregada daquela falsa inocência venenosa:

— A-Yuan, será que a Concubina Tong não gostou da surpresa que preparei?

— A-Yuan, eu sou sempre assim... Nunca consigo fazer nada direito... Buá, buá, buá~

Lu Linyuan adorava assistir às encenações de sua pequena tirana. Ou talvez nem fosse isso: ele simplesmente adorava ouvir a mulher choramingar em seus braços.

Afagou com carinho a cabecinha dela e a consolou: — Pronto, querida. Como ela não gostaria de um presente que você preparou com tanto cuidado?

Em seguida, virou-se para Tong com uma expressão feroz, mudando de rosto num piscar de olhos, e perguntou friamente: — Gostou ou não gostou?

A Concubina Tong comprimiu os lábios, segurando as lágrimas de desgosto. — Gostei... Gostei muito...

— Se gostou, por que não está sorrindo? Hein?

— Vou sorrir... Estou sorrindo...

Tong puxou mecanicamente os cantos dos lábios num sorriso mais triste que um choro.

Só então Xiaoxiao voltou a sorrir. — Assim está melhor. Uma mulher tão bonita quanto a Concubina Tong deveria sorrir mais.

Ao terminar, desviou o olhar para a mesa coberta de iguarias. — Oh! Quantas coisas gostosas!

Puxou Lu Linyuan pela mão até a mesa e chamou Gu Sijin e as outras concubinas para se aproximarem.

— Hoje é aniversário de Tong. Seria triste deixá-la sozinha; vamos fazer companhia a ela. Por acaso ainda não jantei, então aproveitarei para comer aqui.

— Não podem!

A Concubina Tong soltou um grito tão repentino que atraiu os olhares confusos de todos.

É claro que ela não podia permitir que comessem aquela comida. Sabia muito bem quanto afrodisíaco havia misturado aos pratos, e a quantidade a assustava.

Bastava provar um pouquinho para perder o controle. Se todas aquelas concubinas comessem um bocado, que cena completamente absurda acabariam protagonizando?

Ning Xiaoxiao a observou com um sorriso nos olhos sedutores. — Nossa, Tong, precisa ser tão mesquinha? Não nos deixa comer nem duas garfadas?

Pegou uma taça de vinho, estendeu-a a Tong e acrescentou: — Tudo bem, não precisamos comer. Mas, já que vim ao seu aniversário, o mínimo que posso fazer é brindar com você.

Tong ficou encolhida, sem coragem de aceitar o vinho. A expressão de Ning Xiaoxiao mudou de repente e ela ordenou, gelada: — Eu mandei você beber!

O pânico de Tong era evidente. Lu Linyuan também bradou: — A Consorte Nobre está falando com você. Não ouviu?

Os olhos de Tong estavam cheios de terror. Ela recuou passo a passo, balançando a cabeça sem parar.

Ning Xiaoxiao elevou a voz: — Guardas! Tragam a Concubina Tong à mesa e segurem-na para mim!

Os servos obedeceram e logo a levaram à força, mantendo-a presa diante da mesa.

Ning Xiaoxiao pegou um pedaço de carne bovina com os hashis e o aproximou da boca dela, numa voz implacável: — Coma!

Tong cerrou os dentes e sacudiu a cabeça. Xiaoxiao não teve a menor paciência: apertou-lhe o maxilar para forçar sua boca a abrir e enfiou a carne lá dentro.

Tong tentou cuspir, mas Xiaoxiao ameaçou: — Se ousar cuspir, quebro seus dentes!

Lu Linyuan assistiu a tudo sem dizer uma palavra. Chegou até a esboçar um sorriso de orgulho e admiração.

Minha mulher é incrível de tão durona! Dá vontade de erguer uma bandeira e torcer por ela~

Deixou Ning Xiaoxiao fazer o que bem entendesse diante dele. Ninguém sabia quantos pratos ela obrigara Tong a comer ou quanto vinho lhe dera à força. Aos poucos, a concubina começou a apresentar os primeiros efeitos.

Sentiu o corpo arder. De onde veio aquela força bruta, ninguém sabia, mas ela empurrou os servos que a seguravam e começou a desatar a roupa diante de todos.

Enquanto se despia, soltava arfadas ruidosas.

Seu rosto ficou tão vermelho que parecia ter sido escaldado com água fervente.

Todos ficaram chocados diante daquele comportamento enlouquecido.

— Auuuu~!

De repente, soltou um uivo estranho e se lançou descontrolada sobre Lu Linyuan.

Sanfu gritou: — Protejam Sua Majestade!

A Concubina Tong parecia uma cadela selvagem; àquela altura, perdera completamente a razão.

Ao ouvir a voz de Sanfu, desistiu prontamente do imperador e se atirou em direção ao eunuco.

Derrubou Sanfu no chão e começou a se esfregar nele, entre ruídos de sucção.

Sem conseguir afastá-la, Sanfu chorou e gritou para Lu Linyuan:

— Majestade, pare de rir! Venha salvar este seu servo, por favor!!

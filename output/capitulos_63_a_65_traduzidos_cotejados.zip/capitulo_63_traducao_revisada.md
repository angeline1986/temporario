# Capítulo 63 — Você se atreve a me dar ranho para comer?!

Enquanto isso, no Palácio Chaoyang.

Mais da metade dos médicos imperiais estava reunida ali, entrando e saindo dos aposentos sem parar para examinar Lu Linyuan.

A imperatriz-viúva e as concubinas também permaneciam de vigília no quarto.

Apontando para a tigela, a imperatriz-viúva exigiu de Sanfu: — Explique! Como essa porcaria foi parar na boca do imperador?!

Sanfu sempre soubera que Lu Linyuan não podia ingerir perila. O que jamais imaginara era que existisse alguém tão sem noção a ponto de colocar perila — que não tinha nada a ver com a receita — num doce medicinal de fritilária e nêspera!

Vendo que já não dava para esconder a verdade, preparou-se para contar tudo à imperatriz-viúva.

Foi então que Lu Linyuan, até aquele momento à beira da morte no leito imperial, falou de repente:

— Aquele remédio... fui eu mesmo que preparei. Coloquei perila por engano... Ninguém mais tem culpa...

Ao perceberem que ele despertara, a imperatriz-viúva e a imperatriz correram para perguntar como estava.

Mas, antes que conseguisse dizer mais algumas palavras, ele vomitou sangue e tornou a desmaiar.

O Palácio Chaoyang virou um caos. Depois de ouvir aquela declaração, Sanfu compreendeu o que estava acontecendo.

Lu Linyuan queria assumir toda a responsabilidade, sem envolver Ning Xiaoxiao.

A vontade de seu senhor era também a sua. Por isso, manteve a boca fechada e não disse mais nada.

*

Ning Xiaoxiao tinha guardado a bala de goma QQ na gaveta ao lado da cama. Como seu quarto recebia o sol da tarde, a luz incidia diretamente sobre a gaveta durante o dia.

Assim, quando a abriu... bem, digamos que ela ficou completamente petrificada.

━━∑(￣□￣*|||━━

Mas que diabos era aquela coisa?!

Desde que guardara a bala ali, não voltara a abrir a gaveta.

Depois de vários dias de calor, a goma se transformara numa poça de líquido vermelho... de viscosidade máxima.

Ning Xiaoxiao cutucou a meleca com o dedo. Ao retirá-lo, o negócio ainda formou um fio comprido e pegajoso!!

Enojada, perguntou: 【Xiao Qi!! Essa coisa ficou assim... ainda dá para comer?】

Xiao Qi: 【Hm... e por que não daria?】

Enfim, a bala QQ havia virado um “ranho” vermelho, mas era melhor aquilo do que nada.

Ning Xiaoxiao juntou a massa, embrulhou-a em papel e correu de volta ao Palácio Chaoyang. Então apertou o botão Reproduzir.

A trama voltou a correr.

Dois médicos imperiais saíram do quarto com expressão de enterro. — Majestade... o estado do imperador não é nada bom...

— Como assim, “não é nada bom”?! — A fúria da imperatriz-viúva explodiu. Ela atirou uma xícara no chão, fazendo-a em pedaços, e apontou para os médicos. — Se não salvarem o imperador, farei todo o Instituto Médico Imperial acompanhá-lo à sepultura!

Ning Xiaoxiao avançou dois passos e se ajoelhou diante dela. — Majestade, talvez esta serva conheça uma maneira de salvar o imperador.

A imperatriz-viúva lançou-lhe um olhar. — Você?

A Consorte Nobre disparou: — Criada insolente! Como ousa falar tamanho absurdo? Já não estamos aflitas o bastante? Veio aqui atrapalhar ainda mais?! Guardas, levem-na!

Gu Sijin protegeu Ning Xiaoxiao e murmurou: — Xiaoxiao, não pode falar levianamente diante da imperatriz-viúva. Você...

— Minha senhora, esta serva realmente tem confiança. Por que não permitem que eu tente?

A Consorte Nobre retrucou: — Tentar? O imperador é o soberano supremo, não uma cobaia sua! Se não conseguir curá-lo e ainda piorar seu estado, pode arcar com a responsabilidade?

Ning Xiaoxiao respondeu: — Dou minha própria cabeça como garantia! Se não conseguir salvar o imperador, pagarei com a vida!

A Consorte Nobre riu de incredulidade. — Sua cabeça? Que garantia vale sua cabeça? Como a vida miserável de uma criada pode ser comparada à do imperador?

Com a situação nesse impasse, Ning Xiaoxiao voltou a sentir vontade de dar uma surra naquela Consorte Nobre que só sabia mostrar os dentes.

De repente, Gu Sijin, que até então permanecera calada entre as consortes, ajoelhou-se ao lado dela e dirigiu-se à imperatriz-viúva:

— Majestade, esta concubina acredita que Xiaoxiao não fala sem fundamento. Se ela diz que pode fazê-lo, peço que lhe permita tentar. Caso não consiga curar o imperador, ou caso sua condição piore... estou disposta a assumir as consequências ao lado dela e pagar com a própria vida!

— Minha senhora, você...

Gu Sijin segurou a mão de Ning Xiaoxiao, com o olhar firme. — Não precisa dizer nada. Eu confio em você.

A protagonista angelical acabava de acertar Ning Xiaoxiao em cheio, mais uma vez.

Ouvindo aquilo, a Consorte Nobre começou a ficar inquieta.

Ninguém ofereceria a própria cabeça sem motivo. Se Gu Sijin estava disposta a apostar a vida, quem sabe aquela criada esquisita não tivesse mesmo um meio de trazer alguém de volta da beira da morte?

Droga! Ela conseguiu roubar a cena!

Diante do apoio incondicional de Gu Sijin, a imperatriz-viúva cedeu e permitiu que Ning Xiaoxiao tratasse Lu Linyuan.

Ning Xiaoxiao pediu que todos os médicos deixassem o quarto, ficando a sós com ele.

Olhou para o homem na cama. Seu rosto tinha boa cor, a pele parecia luminosa... Onde estava a aparência de alguém à beira da morte?

【Tsc, tsc. Rosto de personagem feito por computador é outra história. Mesmo tão doente, ele continua bonito de fazer sangrar o nariz!】

Lu Linyuan estava inconsciente, incapaz de ouvir as vozes ao redor. Mas a leitura de pensamentos levava a voz de Ning Xiaoxiao diretamente à sua mente. Assim, em meio ao sonho, ouviu aquela provocação e “despertou”.

Quando abriu os olhos, viu Ning Xiaoxiao de costas para ele, junto à cama.

Ela parecia procurar alguma coisa dentro da manga.

Ning Xiaoxiao retirou o papel que envolvia a goma QQ derretida. Estava prestes a oferecê-la a Lu Linyuan quando sentiu uma coceira no nariz.

Tentou segurar por um instante, ergueu a mão por reflexo e soltou um espirro daqueles.

Ao se virar, encontrou Lu Linyuan encarando-a de olhos arregalados. Sua primeira reação foi de alegria:

— O imperador acordou?

Sentou-se à beira da cama e falou com aquele tom sinistro de quem diz “querido, está na hora do remédio”:

— Vamos, Majestade, tome o remédio. Depois vai ficar bom~

Ao ver o líquido vermelho e viscoso repousando sobre o papel que ela segurava, Lu Linyuan sentiu o couro cabeludo formigar.

Até então ele só vira as costas dela. Pela sequência de movimentos e pelo espirro, parecera que Ning Xiaoxiao estava assoando o nariz.

Então...

Ela queria enfiar na boca dele o próprio ranho ensanguentado?!

Lu Linyuan respirou pesadamente, possesso: — Que insolência! Você ousa me dar seu ranho para comer?! Tenho sido bonzinho demais com você, é isso?!

Ning Xiaoxiao: — ...

Não havia tempo para explicações. Primeiro precisava fazê-lo engolir aquilo!

Lu Linyuan estava tão debilitado que não conseguia mover os braços nem as pernas.

Como quem alimenta uma criança, Ning Xiaoxiao foi colocando aos pouquinhos a bala QQ derretida na boca dele:

— Majestade, experimente! É docinho, uma delícia!

Lu Linyuan: — ...

Sem alternativa, ele engoliu uma porção após a outra daquele suposto “ranho sangrento”.

Teve vontade de morrer ali mesmo.

Um imperador, senhor de toda uma nação, à beira da morte... e ainda obrigado a comer o ranho de uma criada?

Ainda dava tempo de morder a própria língua e acabar com seu sofrimento?

Hm? Espere um pouco...

Ora... pensando bem, aquilo parecia... até gostoso?

Lu Linyuan estalou os lábios e saboreou melhor o gosto...

# Validação — Capítulo 65

- Fonte primária: `novel_capitulos_61_a_120(20261103-184549).docx`, capítulo 65.
- Unidades não vazias do original, título incluído: **78**.
- Registros de cotejo: **78**.
- Correspondências vazias: **0**.
- Limites conferidos entre os títulos dos capítulos 65 e 66.
- Revisão: tradução elaborada confrontando cada unidade original; **não houve segunda auditoria linguística independente**.
- A igualdade das contagens confirma a cobertura estrutural, não garante precisão semântica absoluta.

## Observações linguísticas

- O título 白頭偕老 antecipa o motivo dos cabelos brancos, mantendo o sentido idiomático de envelhecer juntos.
- A referência a “21” foi preservada e explicada apenas quando o próprio texto revela tratar-se de centímetros.
- As falas sobre virar “irmãs” e ficar praticamente eunuco são sarcasmo dos personagens, não uma mudança de gênero.

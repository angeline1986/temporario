# Validação — Capítulo 63

- Fonte primária: `novel_capitulos_61_a_120(20261103-184549).docx`, capítulo 63.
- Unidades não vazias do original, título incluído: **77**.
- Registros de cotejo: **77**.
- Correspondências vazias: **0**.
- Limites conferidos entre os títulos dos capítulos 63 e 64.
- Revisão: tradução elaborada confrontando cada unidade original; **não houve segunda auditoria linguística independente**.
- A igualdade das contagens confirma a cobertura estrutural, não garante precisão semântica absoluta.

## Observações linguísticas

- O título mantém a interpretação errada de Lu Linyuan: o suposto ranho é a bala QQ derretida.
- A fala 大郎起來吃藥了 remete a um bordão chinês de envenenamento; adaptada para soar ameaçadoramente familiar, sem acrescentar explicações dentro do diálogo.
- 川貝枇杷羹 foi traduzido de modo descritivo como doce medicinal de fritilária e nêspera.

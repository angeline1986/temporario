# Capítulo 65 — Quero envelhecer ao seu lado, de cabelos brancos

Mas nem tudo neste mundo produz resultados só porque alguém se esforça.

Quando uma coisa se recusa a erguer a cabeça, você pode passar um ano inteiro conversando com ela que não adianta.

Lu Linyuan simplesmente não conseguia aceitar a perspectiva de passar o resto da vida “de cabeça baixa”.

Na audiência da manhã, só conseguia pensar em seu futuro.

Depois da sessão, dispensou os presentes e fez a Sanfu uma pergunta em segredo:

— Depois de ser castrado, quanto tempo levou para sua voz ficar mais fina?

Sanfu respondeu: — Já faz algum tempo, creio eu. Por que a pergunta, Majestade?

— Curiosidade... só curiosidade!

Não era curiosidade, não. Era precaução para o futuro... (ou não).

Nos últimos dois dias, ele mal tivera ânimo para analisar os memoriais. Só pensava em como resolver aquele seu “problema delicado”.

Afinal, tratava-se de seu fiel companheiro, que lutara tantas batalhas ao seu lado, dia e noite. Como poderia permitir que ficasse paralisado assim, de uma hora para outra?

Não! Precisava haver uma solução!

Foi Ning Xiaoxiao quem me curou. Ela vai ter de assumir a responsabilidade até o fim!

Assim, mandou Sanfu levá-la ao Palácio Chaoyang.

*

Desde que se recuperara da doença, Lu Linyuan não chamara nenhuma concubina para passar a noite com ele.

Ning Xiaoxiao também lamentava a situação.

Um belo “21”, sem ter mais onde mostrar serviço. Que desperdício!

E havia um motivo para chamá-lo de “21”.

Na ocasião em que Lu Linyuan tomava banho, ela dera uma espiada involuntária e vira algo que não devia.

Mesmo sem experiência própria, não era completamente ignorante. Fazendo uma estimativa razoável, quando ele ficava “de cabeça erguida”, devia chegar a pelo menos vinte e um centímetros.

Que pena! Uma verdadeira maravilha da natureza acabaria agora compartilhando as mesmas tristezas de Sanfu.

Enquanto Ning Xiaoxiao lamentava a “morte prematura” do companheirinho de Lu Linyuan, Qiqi apareceu toda sorridente em seu quarto:

— Xiaoxiao, o eunuco Sanfu está te procurando~

Bastou ouvir o nome de Sanfu para a consciência dela começar a pesar.

【Será que aquele maldito imperador descobriu o problema lá embaixo e quer tirar satisfações comigo? Socorro...】

— Ai, ai, minha barriga está doendo! Qiqi, vá dizer a ele que estou com dor de barriga e não posso recebê-lo!

— Tá bom~ — respondeu Qiqi, antes de gritar para a entrada do palácio: — Eunuco Sanfu! Xiaoxiao disse que está com dor de barriga e não quer ver você!

Ning Xiaoxiao: ... Muito obrigada por nada!

No fim, como era de esperar, Sanfu a “capturou” e a levou ao Palácio Chaoyang, onde ficou a sós com Lu Linyuan, recém-promovido a eunuco honorário em sua imaginação.

Ela olhava para ele; ele a encarava. Os dois permaneceram calados, constrangidos.

Ning Xiaoxiao: 【Esse sujeito não vai me perguntar diretamente se tenho alguma coisa a ver com a impotência dele, vai? Ele morre de orgulho. Com certeza não vai tocar no assunto... vai?】

Lu Linyuan: — ...

Então você sabia desde o começo que, ao me curar, faria com que eu... não conseguisse mais levantar a cabeça?

Então foi de propósito, sua desgraçada!

Lu Linyuan fervia de raiva. Cerrara os punhos sobre a mesa com tanta força que as veias dos braços saltaram. Parecia prestes a acertar a cabecinha pouco provida de juízo de Ning Xiaoxiao com um soco do tamanho de um tijolo.

Nesse instante, ela voltou a resmungar mentalmente:

【E ele também não pode me culpar! Se eu não o tivesse tratado, já estaria morto e enterrado!】

【Depois que a doença foi curada, veio essa sequela. O que eu posso fazer...?】

【Nem somos inimigos de morte! Eu também não queria transformar nossa relação de “irmãos” em “irmãs”... Mas para curar sua impotência preciso de cem fios do seu cabelo! Se eu arrancar cem fios, você não vai arrancar até meus pelos do nariz e depois mandar cortar minha cabeça?!】

【Entre eu morrer e você virar praticamente um eunuco, só posso escolher a segunda opção...】

Ao ouvir aqueles pensamentos, Lu Linyuan ficou furioso e indignado.

Mas a razão lhe dizia que aquele não era o momento de confrontar Ning Xiaoxiao.

Afinal, pelo visto ela ainda conhecia uma maneira de curar seu problema.

Não eram apenas cem fios do cabelo dele?

Se isso bastasse para voltar a “erguer a cabeça” como um homem, ele até consideraria cortar o cabelo bem curtinho!

Portanto, por mais irritado que estivesse, precisava receber aquela ancestral dos infernos com um sorriso:

— Não mandei chamá-la por nenhum motivo especial. Queria apenas agradecer. Se naquele dia você não tivesse me dado aquilo para comer... eu não teria me recuperado tão depressa.

— Ah? Não foi nada, Majestade! O importante é que tenha recuperado a saúde! — Ning Xiaoxiao soltou o ar, aliviada por ter escapado mais uma vez.

Naquele dia, depois de dispensá-la com algumas palavras vagas, Lu Linyuan mandou Sanfu buscar um pouco de tinta branca na oficina Ruyi.

Sozinho no palácio, diante de um espelho, separou cuidadosamente mechas de cabelo preto e passou tinta branca em alguns fios, da raiz às pontas, com um pincel.

Para os antigos, corpo, cabelo e pele eram dádivas dos pais, e não deviam ser danificados levianamente. Quanto mais no caso de um imperador!

Mas até algo de significado tão profundo às vezes precisava ser sacrificado.

Só podia torcer para que Ning Xiaoxiao tivesse um mínimo de decência e realmente usasse os fios arrancados para resolver seu problema de uma vez por todas.

Em vez de trocá-los por chá com leite e ficar bebendo sem parar!

Naquela noite, Lu Linyuan mandou chamar Gu Sijin para servi-lo nos aposentos.

Depois de tanto tempo de exercícios sob suas ordens, os músculos do abdômen de Gu Sijin já estavam bastante definidos.

Se as concubinas do harém fossem classificadas pela forma física, Gu Sijin ocuparia, sem dúvida alguma, o primeiro lugar.

Ela fazia sua ginástica; Lu Linyuan levava Ning Xiaoxiao para ler memoriais em voz alta. Uma atividade não interferia na outra.

Só que, naquela noite, enquanto Ning Xiaoxiao lia os memoriais, Lu Linyuan parecia distraído.

Sentara-se diante de um espelho de bronze e examinava o alto da cabeça à luz morna das velas.

De vez em quando, suspirava: — A doença passou e parece não ter deixado marcas, mas surgiram tantos cabelos brancos na parte da frente da minha cabeça...

Ning Xiaoxiao estava quase adormecendo. Ao ouvir aquilo, despertou imediatamente.

【Cabelos brancos? Isso lá é cabelo branco? É prata brilhando na minha frente!】

Fechou depressa o memorial e ofereceu seus préstimos: — Majestade, já ouviu os mais velhos dizerem que um cabelo branco chama outro? Se não arrancar logo, daqui a pouco pode aparecer uma cabeça inteira deles!

Lu Linyuan só conhecia o ditado de que arrancar um fio branco fazia nascer outros três. Nunca ouvira aquela teoria absurda inventada por Ning Xiaoxiao.

Mesmo assim, concordou: — Parece que já ouvi algo do tipo.

— Não é?~ — Ning Xiaoxiao caminhou de mansinho até atrás dele, ansiosa para começar. — Que tal eu arrancar os fios brancos para o senhor? Majestade é tão bonito! Não pode deixar alguns fiozinhos estragarem sua aparência, pode?

He, he. O peixão mordeu a isca.

— Está bem. Arranque os que encontrar.

Ning Xiaoxiao quase soltou uma gargalhada. Tirou o grampo que prendia os cabelos de Lu Linyuan, fazendo os fios negros caírem como uma cascata.

Enquanto arrancava, contava mentalmente.

A cada fio, sua empolgação aumentava: 【Um, cinco, nove, dezoito, vinte e sete...】

Eram tantos que ela mal conseguia contar — ou parar de arrancar!

As mãozinhas de Ning Xiaoxiao tremiam de animação. 【Caramba! Eu fiquei rica, porra!】

Lu Linyuan lançou-lhe um olhar ressentido. Tinha a impressão de que, aos olhos dela, sua cabeça era um cofre ambulante:

— ... Mais devagar!

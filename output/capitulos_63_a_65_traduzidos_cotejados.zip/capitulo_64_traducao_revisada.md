# Capítulo 64 — O pequeno “Lu Linyuan” não consegue mais se levantar

Quanto à ideia de “comer ranho”, Lu Linyuan era contra com todas as forças.

Só que, depois de engolir aquela coisa, seu estado melhorou imediatamente.

A tosse parou, a garganta deixou de ficar seca e até as dores no corpo diminuíram bastante.

Ele pensou: Será que essa maluca veio mesmo me tratar?

E não aproveitar minha fraqueza para me mandar desta para melhor?

Vendo que a cor do rosto dele melhorara, Ning Xiaoxiao perguntou: — Como está se sentindo, Majestade? Melhorou?

— Hm.

Ela sorriu. — Então o remédio realmente funciona!

Desde pequena, Ning Xiaoxiao era uma boa menina que “não desperdiçava comida”. E, como só existia uma bala QQ capaz de neutralizar todos os venenos, não seria absurdo deixar Lu Linyuan comer até a última gotinha, certo?

O doce pegajoso grudara tanto no papel que já não conseguia raspá-lo. Ela fitou os lábios finos de Lu Linyuan por um instante.

— Majestade, ponha a língua para fora. Quero examinar a superfície dela.

Achando que ela faria algum exame médico, Lu Linyuan obedeceu e mostrou a língua.

Mal a língua apareceu, Ning Xiaoxiao teve outra de suas “crises de insanidade”: pá! Colou o papel lambuzado de calda bem na boca dele.

— Majestade, faça uma forcinha com a ponta da língua e lamba tudo direitinho~

— ...

Mais uma vez, Lu Linyuan teve a sensação de estar sendo feito de idiota!

Arrancou o papel da língua, amassou-o e jogou-o no chão. Então se levantou furioso, apontando um dedo para Ning Xiaoxiao:

— Isso é um absurdo! Você pensa que eu sou...?!

Hm? Que estranho...

Ainda há pouco, ele mal tinha forças para virar de lado. Como conseguira se levantar de repente?

E por que sua voz estava tão forte e firme?

Mas que... milagre da medicina?

Quem aguardava do lado de fora ouviu o barulho e abriu a porta. Depararam com Lu Linyuan de pé, ereto e cheio de energia. Onde estava o moribundo de instantes atrás?

A imperatriz-viúva se apressou a segurar a mão dele e perguntou, com a voz embargada: — Como está? Está se sentindo melhor? Venha, sente-se.

A imperatriz e a Consorte Nobre não ficaram para trás: cercaram Lu Linyuan pelos dois lados, disputando quem demonstrava mais preocupação.

— Rápido, médicos! Venham examinar o pulso do imperador!

Gu Sijin puxou Ning Xiaoxiao para um canto e perguntou baixinho: — Xiaoxiao, o que você fez desta vez para irritar o imperador?

Ning Xiaoxiao resmungou: — Ele é um poço de mau humor! Se passar um dia sem se irritar, parece que explode por dentro... Eu vim curá-lo com a melhor das intenções. Quem sabe por que ele surtou?

Depois de examinar o pulso de Lu Linyuan, o médico imperial arregalou os olhos, incrédulo:

— Um milagre! Um verdadeiro milagre! O imperador se recuperou em tão pouco tempo! Nunca se viu nem se ouviu falar de algo assim!

Os olhos da imperatriz-viúva brilharam. — É mesmo verdade? Não disseram que essa reação alérgica era extremamente difícil de tratar?

— Bem... este humilde súdito também não sabe explicar. — O médico voltou para Ning Xiaoxiao um olhar admirado. — Posso perguntar a essa jovem criada que método usou para curar Sua Majestade?

A pergunta deixou Ning Xiaoxiao sem resposta.

Como é que ela saberia explicar o tratamento?

Ela nem fazia ideia de como funcionava aquela bala QQ que eliminava todos os venenos...

Enquanto procurava uma desculpa, Lu Linyuan falou primeiro:

— Ela não fez nada. Quando entrou, eu já havia me recuperado, antes mesmo que pudesse me tratar.

É claro que ele precisava dizer aquilo para calar a boca de Ning Xiaoxiao.

Se aquela maluca saísse contando a todo mundo que o curara dando-lhe o próprio “ranho” de comer, onde ficaria a dignidade imperial?!

— Seja como for, o importante é que o imperador está bem — disse a imperatriz-viúva. — Caso contrário, eu não teria um instante de sossego.

Usando a necessidade de repouso de Lu Linyuan após a doença como justificativa, ela dispensou todos.

Ao regressar aos aposentos, Cailian soube do ocorrido no Palácio Chaoyang e não parou de repreender Ning Xiaoxiao.

— Sua sorte é que o imperador tem a proteção dos céus e melhorou sozinho! Se não tivesse conseguido curá-lo e ainda acontecesse alguma desgraça, nossa senhorita não acabaria morrendo junto com você?

Ning Xiaoxiao fez ouvidos moucos. Limitou-se a dizer: — Que cachorro raivoso é esse latindo sem parar? — E entrou no quarto, trancando a porta.

Fechou os olhos e se apressou a consultar os próximos acontecimentos da trama.

De fato, Lu Linyuan estava completamente curado.

Por algum motivo, naquele instante, sentiu-se tomada por um enorme alívio.

Era como se uma pedra que há muito pesava sobre seu coração finalmente tivesse caído. Soltou um longo suspiro.

Xiao Qi zombou: 【Não sei do que você está tão feliz, anfitriã. Se eu estivesse no seu lugar, estaria chorando!】

Do outro lado vinha uma barulheira, com acompanhamento musical:

【Que oportunidade maravilhosa de voltar para casa! Agora que deixou escapar, terá de aguentar dez anos dentro do livro! Dez anos! Dez anos atrás você não me conhecia, eu não pertencia a você, nós...】

Ning Xiaoxiao: 【Você começou a cantar?! O que está fazendo?】

Xiao Qi: 【Cof, cof... Hoje é sábado, minha folga! Saí com outros sistemas para uma confraternização. Estamos no karaokê~】

Ning Xiaoxiao: 【...】

Xiao Qi: 【Por que essa cara de insatisfação? Estou fazendo hora extra para te atender, sabia? Podia mostrar um pouco de gratidão! Ah, é verdade, tenho mais uma coisa para contar. O tirano melhorou... mas não ficou completamente bom.】

Ning Xiaoxiao: 【Como assim?】

Xiao Qi: 【Essa doença deixa sequelas. Sem tratamento específico, a impotência é praticamente certa. Daqui para a frente, o tirano vai poder te chamar de “irmãzinha”~】

Ning Xiaoxiao quase engasgou com a própria saliva. 【O quê?! Está me sacaneando? Você sabe muito bem que fui eu que o tratei! Com uma sequela dessas, ele vai achar que fiz de propósito! Se quer me ver morta, é só falar!】

Sem o menor sinal de culpa, Xiao Qi respondeu em tom debochado: 【Então que tal comprar para ele uma caixa de medicamento especial em pó, próprio para tratar esse probleminha?】

【Quanto custa... quer dizer, quantos fios de cabelo?】

【Cem~】

【CEM FIOS?!】 O queixo de Ning Xiaoxiao quase caiu. 【Está de brincadeira?! Se eu conseguir juntar cem fios de cabelo, sabe quantos lanches e chás com leite posso comprar? Por que gastaria tudo para tratar dele? Enlouqueci?!】

Depois de pensar um pouco, acrescentou: 【E outra: mesmo que ele se cure, o que ganho com isso? Quem vai aproveitar não sou eu! Que sejamos irmãs, então. Ser mulher é ótimo!】

Xiao Qi riu sem a menor cerimônia. 【Como quiser, anfitriã~ Ei, ei! Não muda a música! “Eu É Que Sou a Rainha” fui eu que escolhi! Anfitriã, depois a gente conversa. Vou disputar o microfone! Tchau!】

Dois dias depois, todos os sintomas restantes de Lu Linyuan haviam desaparecido. Ele voltara a ser um homem cheio de vigor, como se nunca tivesse estado à beira da morte.

Mas, na manhã do terceiro dia, percebeu que talvez tivesse sido cedo demais para comemorar esse “vigor”...

Porque, ao acordar, descobriu que certa parte dele... não estava mais “acordando”.

Antes, toda manhã ele “se levantava de cabeça erguida”. Desde que Ning Xiaoxiao o curara, porém, só conseguia ficar “de rabo entre as pernas”.

Era um problema íntimo demais para discutir com os médicos. Por isso, todas as manhãs, dava uns tapinhas na cabeça daquele companheiro desobediente e tentava encorajá-lo:

— Força! Levante-se! Você consegue!!

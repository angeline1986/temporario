# Relatório de revisão — Capítulo 31

## Fonte e correspondência

- Original: `novel_capitulos_1_a_60(20261103-131325).docx` (chinês tradicional).
- Delimitação: de `第31章` até antes de `第32章`.
- Unidades chinesas não vazias, incluindo título: **74**.
- Unidades portuguesas alinhadas: **74**.
- Unidades sem tradução: **0**.
- Cotejo verificável: `capitulo_31_cotejo.csv`.

## Observações de tradução

- A alteração da trama muda simultaneamente a reação da imperatriz-viúva, o enunciado sobre gostar de insultos, o gesto com Gu Sijin e a punição de cinquenta golpes para uma recompensa de cinquenta peças de ouro.
- O texto alterna uma versão futura entre sinais 〈 〉 e a versão efetivamente realizada após o uso de Reproduzir; ambas foram mantidas.
- O cargo de Gu Sijin (答應) foi vertido como 'dama Gu', sem confundi-lo com o título de Consorte Nobre.
- O insulto 老婊子 foi traduzido como 'velha vagabunda', preservando o caráter ofensivo necessário ao mal-entendido.

## Escopo e limites de validação

A correspondência 1:1 foi verificada por contagem, sequência e preenchimento; a tradução foi feita a partir do original e revista ao longo do trabalho, incluindo a coerência narrativa, as falas e as informações numéricas salientes. **Não houve uma segunda auditoria bilíngue independente, oração por oração**, portanto este lote é classificado como **tradução revisada com cotejo estrutural integral**, não como certificação de ausência absoluta de falhas semânticas.

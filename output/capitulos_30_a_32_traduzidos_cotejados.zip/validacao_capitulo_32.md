# Relatório de revisão — Capítulo 32

## Fonte e correspondência

- Original: `novel_capitulos_1_a_60(20261103-131325).docx` (chinês tradicional).
- Delimitação: de `第32章` até antes de `第33章`.
- Unidades chinesas não vazias, incluindo título: **65**.
- Unidades portuguesas alinhadas: **65**.
- Unidades sem tradução: **0**.
- Cotejo verificável: `capitulo_32_cotejo.csv`.

## Observações de tradução

- O humor sexual depende da ambiguidade de 不行 ('não dar conta' no sentido íntimo), seguida pelas perguntas inocentes de Gu Sijin.
- O nome 馬麝麝香 aparece no chinês como ingrediente do adorno, apresentado pela obra como prejudicial à gestação. Não é um parecer farmacológico nem afirmação de eficácia contraceptiva na vida real.
- O adorno é oco: o médico não detecta o pó no primeiro exame e só identifica a substância após a queda provocada por Ning Xiaoxiao.
- A Consorte Duan é diferente da Consorte Nobre e da Consorte Yun; as hierarquias foram mantidas.

## Escopo e limites de validação

A correspondência 1:1 foi verificada por contagem, sequência e preenchimento; a tradução foi feita a partir do original e revista ao longo do trabalho, incluindo a coerência narrativa, as falas e as informações numéricas salientes. **Não houve uma segunda auditoria bilíngue independente, oração por oração**, portanto este lote é classificado como **tradução revisada com cotejo estrutural integral**, não como certificação de ausência absoluta de falhas semânticas.

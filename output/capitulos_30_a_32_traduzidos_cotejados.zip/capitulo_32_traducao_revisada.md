# Capítulo 32 — Um kit completo de contracepção para você

Os gritos de dor da Consorte Nobre ficavam cada vez mais altos, fazendo o coração de Gu Sijin disparar de medo.

Ela se despediu rapidamente da imperatriz-viúva e fugiu do Palácio Xianshou como se tivesse asas nos pés.

Mal atravessou a entrada, Ning Xiaoxiao apareceu, fingindo encontrá-la por acaso.

— Minha senhora, já entregou os sutras à imperatriz-viúva?

Gu Sijin não disse uma palavra. Pegou a mão de Ning Xiaoxiao e a conduziu para longe dali.

Só depois de dobrar a esquina no fim da longa avenida é que Gu Sijin levou a mão ao peito, ofegante. — Quase morri de susto... Xiaoxiao, alguém quer me prejudicar.

Ela entregou o sutra a Ning Xiaoxiao. Depois de examinar os insultos escritos nele, a criada disse: — Ainda bem que minha senhora foi esperta e conseguiu trazê-lo de volta. Caso contrário, quem estaria sendo castigada no Palácio Xianshou agora provavelmente seria a senhora.

— Desde que entrei no palácio, não me lembro de ter ofendido ninguém. Quem poderia querer me prejudicar dessa maneira? A Consorte Nobre enlouqueceu e insultou a imperatriz-viúva, e veja que castigo recebeu! Eu não passo de uma dama de baixa posição, recém-chegada ao palácio. Se a imperatriz-viúva tivesse lido direito o sutra, será que eu teria escapado com vida?

Ela estava genuinamente apavorada. Seu rosto perdera toda a cor.

E não era para menos.

Desde que entrara no livro, Ning Xiaoxiao vinha levando a vida com uma despreocupação quase insolente.

Mas a obra original era, afinal, um verdadeiro romance de intrigas do harém. Cada consorte tinha seus próprios estratagemas; um instante de descuido bastava para cair na armadilha de alguém e acabar numa situação sem saída.

Quando Gu Sijin voltou a seus aposentos, um eunuco do Departamento dos Aposentos Imperiais acabara de chegar com uma ordem.

Naquela noite, Lu Linyuan havia escolhido novamente a placa dela.

Ao ouvir a «boa notícia», Gu Sijin sentiu imediatamente as pernas doloridas.

Sempre que ela acabava de se recuperar, Lu Linyuan aproveitava a oportunidade para convocá-la e atormentá-la até quase acabar com suas forças.

Parecia que, numa vida anterior, ela tinha assassinado toda a família de Lu Linyuan e despertado nele um ódio mortal.

Em particular, perguntou a Ning Xiaoxiao: — Xiaoxiao, você sempre me acompanha para ficar de vigília. Por que o imperador escolhe minha placa, mas depois me obriga a passar a noite inteira fazendo ginástica no Palácio Chaoyang?

Como Ning Xiaoxiao poderia saber o que se passava na cabeça de Lu Linyuan?

Então respondeu sem pensar: — Talvez ele simplesmente não dê conta.

— Não dê conta? De quê?

— Daquilo lá...

— Daquilo o quê?

*Minha nossa, agora vamos ficar abrindo uma boneca russa atrás da outra?*

Ning Xiaoxiao já se preparava para explicar, com toda a seriedade, os assuntos íntimos entre homens e mulheres àquela coelhinha inocente, quando a Consorte Duan afastou a cortina e entrou sorridente.

— Soube que o imperador escolheu a placa da minha irmãzinha outra vez!

A Consorte Duan era afável e se comportava com a elegância de uma dama de família ilustre. Durante o tempo em que as duas moraram no mesmo palácio, ela cuidara muito bem de Gu Sijin, que por isso a tratava com grande respeito.

Gu Sijin fez uma reverência e convidou-a a sentar. A Consorte Duan sorriu. — Estou no palácio há tantos anos e nunca vi Sua Majestade dedicar a ninguém tanta atenção quanto dedica à minha irmãzinha.

Pousou a mão sobre a de Gu Sijin e deu-lhe leves tapinhas. — Fico verdadeiramente feliz por você receber os favores imperiais.

— O imperador só tem curiosidade pela novidade que sou — respondeu Gu Sijin. — É com Vossa Alteza que ele demonstra uma afeição mais profunda.

— Com essa boquinha doce, quem não gostaria de você? — A Consorte Duan chamou sua criada pessoal. — Xiu'er, traga o presente.

Xiu'er retirou da manga um lenço de seda dobrado. Ao abri-lo, revelou uma pulseira de ouro arroxeado, de trabalho fino e requintado; era evidentemente uma peça valiosa.

— Consegui esta pulseira de proteção no Pavilhão Baoxiang durante as festividades de Ano-Novo passado. Infelizmente, venho ganhando peso e já mal consigo usá-la. Acho que ficaria perfeita em você.

Ela segurou a mão de Gu Sijin e, sem aceitar recusas, colocou a pulseira no pulso claro da jovem.

— Veja só! Um belo adorno para uma bela mulher. Esse tom de ouro realça ainda mais a brancura de sua pele.

Envergonhada com um presente tão caro, Gu Sijin tentou recusar repetidas vezes: — Consorte Duan, não posso aceitar! Não fiz nada para merecer tamanha generosidade.

A Consorte Duan segurou sua mão, impedindo-a de retirar a pulseira. — É só uma pequena lembrança de nossa amizade de irmãs. Se você não aceitar sequer isso, vou pensar que não deseja se aproximar de mim.

Sem saber como sair daquela situação, Gu Sijin acabou aceitando a contragosto. Pediu então a Cailian que buscasse um enfeite de cabelo dourado com incrustações de penas de martim-pescador, parte de seu enxoval quando entrara no palácio, e o ofereceu em retribuição.

Na superfície, as duas pareciam se dar maravilhosamente bem. Mas Ning Xiaoxiao, que observava tudo com frieza, era a única a conhecer as correntes perigosas por baixo daquela cordialidade.

A pulseira de ouro arroxeado que a Consorte Duan dera a Gu Sijin era oca por dentro e tinha sido preenchida com almíscar de origem equina altamente purificado.

Na lógica da história, tratava-se de uma substância capaz de prejudicar gravemente a saúde reprodutiva de uma mulher.

Na obra original, a Consorte Duan só presentearia Gu Sijin com a pulseira quando ela engravidasse pela primeira vez.

E seria justamente por causa daquele adorno que Gu Sijin perderia seu primeiro filho.

Depois que a Consorte Duan partiu, Gu Sijin não conseguia parar de admirar a pulseira. — Em todo este palácio, só a Consorte Duan me trata com verdadeira sinceridade.

Cailian concordou: — Na verdade, tirando a Consorte Nobre e a Consorte Yun, as outras senhoras têm tratado muito bem a senhorita.

Depois do incidente dos sutras, Gu Sijin ainda não sabia quem tentara prejudicá-la.

Já desconfiada das intenções das pessoas no palácio, soltou uma risada amarga. — Ninguém consegue enxergar o coração de outra pessoa. Como saber o que alguém realmente pensa?

Ning Xiaoxiao pensou: 【Ah, agora você ficou perspicaz, não foi? Anda toda contente com esse kit de contracepção que a Consorte Duan lhe deu, como se fosse um tesouro, e ainda vem falar que ninguém conhece o coração dos outros...】

Naquele momento, um médico do Instituto Médico Imperial chegou para examinar o pulso de Gu Sijin.

Durante a consulta, Ning Xiaoxiao se inclinou ao ouvido de Gu Sijin e sussurrou: — Minha senhora, que tal pedir ao médico que examine a pulseira que a Consorte Duan acabou de lhe dar? Assim a senhora pode ficar tranquila.

Embora não suspeitasse da Consorte Duan, Gu Sijin achou que a cautela de Ning Xiaoxiao não faria mal.

Ela tirou a pulseira e a entregou à criada, que por sua vez a passou ao médico. — Minha senhora pediu que comprassem esta pulseira no mercado. Poderia examiná-la e verificar se há alguma coisa errada?

O médico examinou o bracelete cuidadosamente, mas não encontrou nada de anormal.

— Minha senhora, não há nada de errado com esta pulseira.

A Consorte Duan era cuidadosa demais para fazer algo tão óbvio quanto envenenar alguém deixando seu próprio nome ligado ao presente.

O almíscar estava escondido no interior da pulseira e seu odor fora disfarçado com outras fragrâncias. Naturalmente, um exame superficial não revelaria nada.

Então, quando recebeu a pulseira de volta das mãos do médico, Ning Xiaoxiao fingiu que ela escorregara de seus dedos e a deixou cair com força no chão.

Cailian a repreendeu: — Insolente! Como ousa deixar cair...!

— O que é isso? — Gu Sijin percebeu uma rachadura na pulseira, de onde escapava um pó marrom-escuro.

O médico tocou um pouco do pó com a ponta do dedo e, pelo cheiro, identificou imediatamente o almíscar.

— I-isso... Minha senhora, esconderam uma grande quantidade de almíscar dentro desta pulseira! Se a senhora a usasse todos os dias, o pó penetraria gradualmente em seu corpo e poderia prejudicar sua saúde reprodutiva!

Ao ouvir aquilo, Gu Sijin sentiu um calafrio percorrer as costas. Todos os pelos de seu corpo se arrepiaram.

Ning Xiaoxiao permaneceu perfeitamente calma e pediu ao médico: — Agradecemos seu trabalho. Por favor, não conte a ninguém o que aconteceu hoje.

Em seguida, tirou algumas das sementes de ouro que Gu Sijin lhe dera e as ofereceu ao médico. Ele aceitou a recompensa, garantiu repetidas vezes que manteria o assunto em segredo e saiu muito satisfeito.

---

## Notas editoriais

- O humor sexual depende da ambiguidade de 不行 ('não dar conta' no sentido íntimo), seguida pelas perguntas inocentes de Gu Sijin.
- O nome 馬麝麝香 aparece no chinês como ingrediente do adorno, apresentado pela obra como prejudicial à gestação. Não é um parecer farmacológico nem afirmação de eficácia contraceptiva na vida real.
- O adorno é oco: o médico não detecta o pó no primeiro exame e só identifica a substância após a queda provocada por Ning Xiaoxiao.
- A Consorte Duan é diferente da Consorte Nobre e da Consorte Yun; as hierarquias foram mantidas.

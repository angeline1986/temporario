# Capítulo 31 — A senhora é mesmo uma velha vagabunda

【Faltam três minutos! A anfitriã deve impedir o colapso do mundo imediatamente!】

O zumbido estridente, acompanhado da contagem regressiva de Xiao Qi, estava dando dor de cabeça em Ning Xiaoxiao.

Ela apertou Pausar, congelou o tempo no mundo do livro e correu a toda velocidade para o Palácio Xianshou.

Espiando pela entrada, viu que Gu Sijin já havia entregado o sutra à imperatriz-viúva.

*Ferrou!* Embora a expressão da imperatriz-viúva estivesse congelada, a raiva transparecia em seus olhos e sobrancelhas.

Já era tarde demais para destruir o sutra antes que ela o lesse. Agora, só havia um caminho: alterar a trama.

Ning Xiaoxiao se escondeu num arbusto fora do Palácio Xianshou, pronta para examinar o que aconteceria em seguida.

Mas, assim que entrou na moita, pisou em algo macio.

Olhando melhor... santo Deus! Tinha pisado na mão da Consorte Nobre!

Então ela também estava escondida ali, espiando o que se passava no salão?

Ning Xiaoxiao não esquecera como Gu Sijin a tratara bem desde que entrara no livro.

Além disso, Gu Sijin era a protagonista da história. A Consorte Nobre a havia incriminado e quase provocado o colapso do mundo inteiro. Como Ning Xiaoxiao poderia deixar aquilo passar?

Aproveitando que a mulher estava imóvel, distribuiu-lhe duas bofetadas sonoras e depois enfiou um punhado de terra em sua boca. — Se vai ser tão desprezível assim, melhor assumir logo que é uma ordinária!

Ning Xiaoxiao se mudou para outro esconderijo e começou a estudar os acontecimentos seguintes:

〈Depois de ler o sutra e encontrar nele apenas insultos dirigidos a ela, a imperatriz-viúva enfureceu-se imediatamente.〉

〈Ela jogou o sutra de lado e disse a Gu Sijin com expressão sombria: “O que eu mais detesto é que me insultem!” Em seguida, esbofeteou Gu Sijin com raiva e ordenou: “Guardas! Deem cinquenta golpes de bastão na dama Gu!”〉

*Não é tão grave. Ainda bem que acumulei caracteres suficientes para alterar o texto!*

Seu cérebro trabalhou a toda velocidade. Depois de modificar a trama, ela apertou Reproduzir.

Depois de ler o sutra e encontrar nele apenas insultos dirigidos a ela, a imperatriz-viúva abriu um sorriso radiante.

Ela jogou o sutra de lado e disse a Gu Sijin, toda contente: — O que eu mais adoro é que me insultem! — Em seguida, ajudou Gu Sijin a se erguer com satisfação e ordenou: — Guardas! Deem cinquenta peças de ouro à dama Gu!

A Consorte Nobre, que acabara de cuspir a terra da boca, quase deixou o queixo cair quando viu a reação da imperatriz-viúva aos insultos escritos.

*???*

*O que está acontecendo?*

*Será que aquela velha bruxa é masoquista?*

*Gosta mesmo é de ser xingada?*

Depois de presentear Gu Sijin com ouro, a imperatriz-viúva agiu como se nada tivesse acontecido. Segurou a mão da jovem, perguntou por sua saúde e ainda a incentivou a se esforçar para lhe dar logo um netinho gorducho e saudável.

Quanto mais a Consorte Nobre observava, mais irritada ficava. Perguntou à criada Xianglan: — O que aconteceu? Tem certeza de que aquele sutra estava cheio de xingamentos?

— Absoluta! Fui eu mesma que escrevi, imitando a caligrafia da dama Gu. Não há como ter dado errado! E a própria imperatriz-viúva acabou de dizer que adora ser insultada... Minha senhora, será que acertamos sem querer justamente no gosto dela? Nossa armação saiu pela culatra e acabamos ajudando a dama Gu?

A Consorte Nobre insistiu: — O que exatamente você escreveu?

Xianglan gaguejou: — Segui suas ordens: escrevi as piores coisas possíveis. Que a imperatriz-viúva é uma velha vagabunda, que quando morrer ninguém vai enterrá-la, que nasceu de sangue desprezível e mereceu ser desprezada pelo falecido imperador... Coisas desse tipo.

A Consorte Nobre refletiu. — Todo mundo tem suas esquisitices. Lembra da Consorte Rong do falecido imperador? Ela gostava que ele a açoitasse. Quem diria que a imperatriz-viúva gosta de ser insultada...

— Então Vossa Alteza precisa caprichar! Não pode deixar a dama Gu ficar com todos os méritos!

A Consorte Nobre sorriu com arrogância. — Ah, isso é óbvio!

Ela saiu dos arbustos, ajeitou a aparência e entrou no Palácio Xianshou.

Ao vê-la, a imperatriz-viúva acenou. — A Consorte Nobre chegou? Venha, sente-se aqui ao meu lado.

A Consorte Nobre aproximou-se sorrindo e, ao passar por Gu Sijin, lançou-lhe um olhar atravessado.

Xianglan apresentou à imperatriz-viúva os sutras copiados à mão. A anciã os aceitou satisfeita. — Você e a dama Gu tiveram a mesma ideia. Vocês duas são muito dedicadas a mim.

*Hã?*

*Gu Sijin a xingou daquele jeito, e ela ainda acha que a garota é dedicada?*

A Consorte Nobre ganhou ainda mais coragem.

— Imperatriz-viúva... tenho uma coisa a lhe dizer.

— Hum? O que foi?

— A senhora... é mesmo uma velha vagabunda!

Imperatriz-viúva: “!!!”

Gu Sijin: “???”

Os dois corvos especializados em tornar o ambiente constrangedor apareceram na hora certa sobre o telhado, grasnando sem parar.

O sorriso da imperatriz-viúva congelou. Seus olhos se estreitaram. — O que foi que você disse?

A Consorte Nobre achou que a anciã apenas não tinha ouvido os insultos com clareza e não conseguira apreciá-los direito.

Por isso, limpou a garganta e elevou bastante a voz: — Eu disse que a imperatriz-viúva é uma velha vagabunda!

Imperatriz-viúva: “...”

— Uma velha vagabunda que vai morrer sem ninguém para enterrá-la!

Imperatriz-viúva: “...”

— Uma velha vagabunda que nasceu desprezível e mereceu ser rejeitada pelo falecido imperador!

Imperatriz-viúva: “...”

Até Gu Sijin ficou completamente estarrecida com o espetáculo absurdo da Consorte Nobre.

Ela se apressou em dizer: — Vossa Alteza, não pode se comportar assim diante da imperatriz-viúva!

A Consorte Nobre lançou-lhe um olhar feroz e soltou uma risada fria. — O quê? Só você pode agradar à imperatriz-viúva, e eu não? Eu... Ai!

Seu grito veio quando a imperatriz-viúva pegou a bengala com cabeça de fênix e lhe deu uma paulada.

— Imperatriz-viúva?! Por que está me batendo?

Furiosa, a anciã se apoiou na bengala, ofegante. — Eu sou uma vagabunda? Vou morrer sem ninguém para me enterrar?! Muito bem, Consorte Nobre, muito bem! Vivi mais de metade da minha vida e ninguém jamais ousou falar comigo desse jeito!

Consorte Nobre: “???”

*Hã? Por que ela não está seguindo o roteiro?*

A imperatriz-viúva nem lhe deu chance de se explicar. Gritou: — Guardas! Levem a Consorte Nobre e deem-lhe cinquenta golpes de bastão! E esbofeteiem-na sem piedade! Só quando acabarem com essa boca imunda é que ela vai aprender a lição!

Quase desmaiando de raiva, a imperatriz-viúva recebeu imediatamente os cuidados de Gu Sijin, que lhe acariciou as costas. — Imperatriz-viúva, talvez a Consorte Nobre não tivesse intenção de ofendê-la. A senhora...

— Quem falar em defesa dela receberá a mesma punição!

Gu Sijin ficou tão assustada que não ousou dizer mais nada. Nesse instante, percebeu pelo canto do olho o sutra que apresentara à imperatriz-viúva, agora pousado ao lado da anciã.

Estava coberto de palavras obscenas e insultos, ainda piores do que os que a Consorte Nobre acabara de proferir.

Ela compreendeu imediatamente que alguém lhe armara uma cilada.

Mas, por sorte, a imperatriz-viúva não tinha percebido o que estava escrito ali.

Enquanto levavam a Consorte Nobre ao pátio para receber a punição, a imperatriz-viúva também saiu, amparada por criadas, para supervisioná-la pessoalmente.

Rápida e esperta, Gu Sijin aproveitou a distração geral para esconder na manga o sutra que poderia condená-la à morte.

Do lado de fora do palácio, Ning Xiaoxiao observava tudo em silêncio. Ao ver Gu Sijin recuperar furtivamente o próprio sutra, sorriu com o orgulho satisfeito de uma mãe.

*Bom, pelo menos ela não é completamente burra.*

---

## Notas editoriais

- A alteração da trama muda simultaneamente a reação da imperatriz-viúva, o enunciado sobre gostar de insultos, o gesto com Gu Sijin e a punição de cinquenta golpes para uma recompensa de cinquenta peças de ouro.
- O texto alterna uma versão futura entre sinais 〈 〉 e a versão efetivamente realizada após o uso de Reproduzir; ambas foram mantidas.
- O cargo de Gu Sijin (答應) foi vertido como 'dama Gu', sem confundi-lo com o título de Consorte Nobre.
- O insulto 老婊子 foi traduzido como 'velha vagabunda', preservando o caráter ofensivo necessário ao mal-entendido.

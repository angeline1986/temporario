# Capítulo 30 — O mundo do livro está prestes a desmoronar

O diretor Song vinha todos os dias. Depois de quatro ou cinco dias de tratamento, Gu Sijin e Ning Xiaoxiao já estavam bem melhores.

Elas imaginavam que, ao voltarem a cumprimentar a imperatriz depois de se recuperarem, teriam de suportar mais uma rodada de comentários mordazes das consortes.

Para sua surpresa, porém, todas as trataram excepcionalmente bem naquele dia. Até a Consorte Nobre, que normalmente nem à imperatriz dava muita importância, perguntou: — Como está se sentindo? Mal entrou no palácio e já adoeceu duas ou três vezes. Com uma saúde tão frágil, precisa se cuidar.

Gu Sijin não estava acostumada com tamanha solicitude. — Agradeço a preocupação de Vossa Alteza. Fui incapaz de cuidar de mim mesma e acabei dando trabalho a todos.

A imperatriz disse: — Somos todas irmãs nesta família. Não precisa falar assim, como se fôssemos estranhas.

Naquele dia, a reunião das consortes para cumprimentar a imperatriz não se limitou às conversas de costume.

O Festival do Banho de Buda seria dali a dois dias. Como a imperatriz-viúva era uma devota fervorosa do budismo, as consortes discutiam que presente poderiam lhe oferecer antes da festividade para alegrá-la.

Todas deram sugestões, mas não conseguiram chegar a um acordo.

A Consorte Nobre, que costumava presentear os outros com ouro, prata e joias, propôs algo diferente: — A imperatriz-viúva nunca gostou de riquezas nem de agitação. Um presente deve tocar o coração de quem o recebe. Já que ela é tão devota de Buda, que demonstração de sinceridade poderia ser maior do que oferecermos sutras copiados por nossas próprias mãos?

As demais concordaram que era uma ótima ideia. A imperatriz decidiu: — Faremos como a Consorte Nobre sugeriu. Que cada uma copie dois volumes de escrituras budistas ao voltar para seus aposentos e depois os entregue a mim. Eu os levarei à imperatriz-viúva.

A Consorte Nobre retrucou: — E por que entregá-los à imperatriz? Não podemos levá-los pessoalmente depois de terminar? Incomodar Vossa Majestade com uma coisinha dessas nos faria parecer um bando de desajuizadas.

A imperatriz pensou apenas que a Consorte Nobre temia perder o protagonismo para ela. — Então faremos como você quer. Cada uma entregará suas cópias pessoalmente no palácio da imperatriz-viúva.

Na verdade, a Consorte Nobre fizera aquela proposta com um único objetivo: armar uma cilada para Gu Sijin.

Em instantes, o Departamento de Assuntos Internos enviaria papel, pincéis e tinta dourada aos palácios para a cópia dos sutras.

Só que os materiais destinados a Gu Sijin tinham sido adulterados com antecedência.

As folhas pareciam papel xuan de primeira qualidade, completamente em branco. Na realidade, já havia palavras escritas nelas com uma tinta especial, invisível até entrar em contato com um aroma muito forte de sândalo.

A tinta dourada enviada a ela também fora preparada. Não importava o que Gu Sijin escrevesse: diante de um cheiro intenso de sândalo, a escrita dourada desbotaria até desaparecer.

Em todo o palácio imperial, somente no Palácio Xianshou, residência da imperatriz-viúva, queimava-se sândalo durante o ano inteiro.

Assim, bastava Gu Sijin levar os sutras copiados à imperatriz-viúva. As palavras que ela escrevera sumiriam e, em seu lugar, surgiria o texto preparado de antemão pela Consorte Nobre.

E aquele texto não continha outra coisa senão insultos à imperatriz-viúva.

Muito satisfeita com a própria armação, a Consorte Nobre instruiu seus servos: — Fiquem de olho no Palácio Zhongcui. Assim que Gu Sijin sair levando os sutras à imperatriz-viúva, venham me avisar.

*

Palácio Zhongcui.

Depois de receber o papel, os pincéis, a tinta e a pedra de tinta enviados pelo Departamento de Assuntos Internos, Gu Sijin começou a copiar as escrituras com toda a concentração, sem perder um instante.

Ela era bondosa, mas não era tola.

Se todas dariam presentes iguais à imperatriz-viúva, a primeira a entregar o seu certamente conquistaria um pouco mais da simpatia dela.

Enquanto preparava a tinta para Gu Sijin, Cailian estava tão distraída que deixou a tinta dourada espirrar várias vezes, quase manchando o papel em que a senhora copiava o sutra.

— Cailian, será que pode prestar um pouco de atenção? Se cair uma gota de tinta no papel, terei de copiar a página inteira de novo.

Vendo que Cailian fazia beicinho e parecia infeliz, Gu Sijin acrescentou: — Se está entediada, vá chamar Xiaoxiao para substituí-la. Pode descansar um pouco.

— Desde que Ning Xiaoxiao voltou com a senhorita da visita de cumprimentos, desapareceu outra vez — resmungou Cailian. — Ela é especialista em fugir do trabalho. Onde a senhorita vai encontrá-la?

Até que Ning Xiaoxiao gostaria de matar serviço.

Mas, com Lu Linyuan por perto, tinha de dormir mais tarde que um cachorro, acordar mais cedo que uma galinha e trabalhar mais que um burro.

Mal terminara de acompanhar Gu Sijin na visita quando Lu Linyuan saiu da audiência matinal e Sanfu a convocou outra vez ao gabinete imperial.

Lu Linyuan estava sentado na cadeira do dragão, com uma montanha de memoriais empilhados à frente.

Assim que Ning Xiaoxiao chegou, ele bateu na mesa com um dedo. — Comece.

Era como se tivesse perdido a capacidade de cuidar de si mesmo: toda vez que precisava examinar memoriais, exigia que Ning Xiaoxiao os lesse em voz alta.

Ela não entendia por que ele fazia aquilo. Mas, por mais que reclamasse mentalmente, não ousava desobedecer ao tirano.

Restava-lhe pegar os memoriais, com a maior cara de coitada, e ler um após o outro.

Depois de quase duas horas duplas de leitura, com a garganta ardendo de tão seca, enfim terminou os memoriais daquele dia.

Ao ouvi-la tossir repetidamente, Lu Linyuan serviu-lhe, muito «atenciosamente», uma xícara de água. — Por que passou duas horas duplas lendo sem beber nada?

Ning Xiaoxiao bebeu como um boi sedento e respondeu, ressentida: — Porque Vossa Majestade não me deu permissão...

*Ah, claro. Justo agora resolveu ser obediente.*

*Há tantas coisas que proíbo você de fazer. E qual delas você deixa de fazer?*

Lu Linyuan não quis discutir. — Sua dor de barriga já passou?

— Sim, Majestade. Estou completamente recuperada.

Mal terminou de responder, um zumbido agudo ecoou dentro de sua cabeça, como uma sirene de ataque aéreo.

【Biiiiip! Alerta! Alerta! O mundo está prestes a desmoronar! A anfitriã deve salvar o mundo imediatamente!】

【Alerta! Alerta! Faltam cinco minutos para o colapso do mundo!】

*Mas que droga?!*

*Que história é essa?!*

*Passei a tarde lendo memoriais para esse tirano, e agora o mundo vai acabar?*

Ning Xiaoxiao perguntou mentalmente: 【Xiao Qi, explique direito! Por que o mundo vai desmoronar?】

Xiao Qi respondeu: 【A anfitriã deve consultar os acontecimentos seguintes e encontrar uma forma de resolver a crise o mais depressa possível. Se o mundo do livro desmoronar, a anfitriã desaparecerá junto com ele.】

Ning Xiaoxiao fechou os olhos às pressas, fez surgir o documento em sua mente e leu freneticamente os trechos seguintes.

Gu Sijin seria a primeira consorte a visitar a imperatriz-viúva com os sutras copiados à mão. Mas a Consorte Nobre adulterara seus materiais; assim que os sutras fossem abertos no palácio da imperatriz-viúva, todo o conteúdo se transformaria em insultos obscenos dirigidos à anciã.

A imperatriz-viúva ficaria furiosa, daria uma bofetada em Gu Sijin e mandaria arrastá-la para receber cinquenta golpes de bastão.

Por ser frágil demais para suportar o castigo, Gu Sijin ficaria gravemente ferida após os cinquenta golpes e acabaria morrendo.

Ning Xiaoxiao tentou ler o que vinha depois, mas encontrou na página seguinte três caracteres enormes e chamativos:

FIM DO LIVRO.

*Fim o cacete! Vai acabar é a sua mãe!*

*Autor desgraçado! Largou a história pela metade! Que morra de um jeito horrível!*

*Não dá para simplesmente abandonar tudo assim!*

O mais urgente era impedir que aquilo acontecesse.

Ela disse rapidamente a Lu Linyuan: — Majestade, esta serva precisa resolver um assunto. Peço licença para me retirar!

E saiu correndo, mas não tinha dado nem dois passos quando Lu Linyuan agarrou seu pulso. — Aonde pensa que vai? Por acaso eu a dispensei?

Não havia jeito. Com a vida em risco, não dava para se preocupar com a própria dignidade!

Ning Xiaoxiao fez uma careta aflita, cobriu o traseiro com a mão livre e começou a pular de um pé para o outro.

— Majestade! Há necessidades que ninguém pode segurar! Se não me soltar agora, eu vou acabar fazendo aqui mesmo...!

Lu Linyuan já tinha medo do que Ning Xiaoxiao era capaz de aprontar.

Não existia nada que aquela maluca não fosse capaz de fazer!

Por isso, soltou o pulso dela imediatamente. — Se ousar fazer suas necessidades no meu gabinete, hoje eu a mato sem falta!

Ning Xiaoxiao disparou, deixando Lu Linyuan sozinho, questionando tudo o que sabia sobre a vida...

---

## Notas editoriais

- O Festival do Banho de Buda (浴佛節) e a cópia de sutras são elementos religiosos e culturais da trama; o nome do festival foi preservado.
- A armadilha usa papel com tinta invisível e tinta dourada que desaparece sob um aroma intenso de sândalo. Esta é a lógica ficcional descrita na obra.
- 兩個時辰 equivale a aproximadamente quatro horas, embora na tradução se tenha mantido 'duas horas duplas' para preservar a unidade tradicional; não são duas horas comuns.
- A escrita abrupta de '全書完' ('Fim do livro') aparece dentro da história e provoca a ameaça de colapso; não é o fim do capítulo.
- O original contém insultos com efeito cômico grosseiro; as expressões foram adaptadas ao português brasileiro sem criar acontecimentos.

# Relatório de revisão — Capítulo 30

## Fonte e correspondência

- Original: `novel_capitulos_1_a_60(20261103-131325).docx` (chinês tradicional).
- Delimitação: de `第30章` até antes de `第31章`.
- Unidades chinesas não vazias, incluindo título: **73**.
- Unidades portuguesas alinhadas: **73**.
- Unidades sem tradução: **0**.
- Cotejo verificável: `capitulo_30_cotejo.csv`.

## Observações de tradução

- O Festival do Banho de Buda (浴佛節) e a cópia de sutras são elementos religiosos e culturais da trama; o nome do festival foi preservado.
- A armadilha usa papel com tinta invisível e tinta dourada que desaparece sob um aroma intenso de sândalo. Esta é a lógica ficcional descrita na obra.
- 兩個時辰 equivale a aproximadamente quatro horas, embora na tradução se tenha mantido 'duas horas duplas' para preservar a unidade tradicional; não são duas horas comuns.
- A escrita abrupta de '全書完' ('Fim do livro') aparece dentro da história e provoca a ameaça de colapso; não é o fim do capítulo.
- O original contém insultos com efeito cômico grosseiro; as expressões foram adaptadas ao português brasileiro sem criar acontecimentos.

## Escopo e limites de validação

A correspondência 1:1 foi verificada por contagem, sequência e preenchimento; a tradução foi feita a partir do original e revista ao longo do trabalho, incluindo a coerência narrativa, as falas e as informações numéricas salientes. **Não houve uma segunda auditoria bilíngue independente, oração por oração**, portanto este lote é classificado como **tradução revisada com cotejo estrutural integral**, não como certificação de ausência absoluta de falhas semânticas.

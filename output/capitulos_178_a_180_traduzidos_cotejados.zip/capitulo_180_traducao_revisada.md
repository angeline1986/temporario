# Capítulo 180 — A porca subiu na árvore!

Um tirano podia muito bem tomar alguém à força. Mas, se forçasse demais o arco, acabaria quebrando-o.

Lu Linyuan parecia um sujeito irresponsável, mas, quando se tratava da pessoa amada, era extremamente cuidadoso.

Se tentasse forçar alguma coisa enquanto Ning Xiaoxiao estava desconfiada e enciumada, seria uma atitude muito desprezível.

Depois de pensar um bocado, reuniu toda a sua força de vontade e fez um discurso motivacional para si mesmo:

Tudo bem! Este imperador consegue se controlar!

Mas, depois de chegar tão longe, se recuasse bem naquela hora, será que a maluca não começaria a imaginar que ele era incapaz de cumprir o serviço?

Quando Lu Linyuan estava nesse impasse, chegou seu “salvador”!

Sanfu, como se tivesse enlouquecido, começou de repente a gritar do lado de fora:

— Majestade! Boas notícias! Notícias maravilhosas!

A noite estava silenciosa. A voz de Sanfu caiu como uma bomba num lago tranquilo, fazendo Ning Xiaoxiao e Lu Linyuan estremecerem de susto.

Lu Linyuan saiu de cima de Ning Xiaoxiao, frustrado, e xingou na direção da porta:

— Grita, grita, grita! Que diabos está berrando no meio da noite, seu bagre gigante da Sibéria?!

Sanfu: “...”

Ning Xiaoxiao: “???”

【Caramba! E-e-espera... Por que ele está falando exatamente como eu? Será que voltou da viagem possuído por algum espírito?】

Ning Xiaoxiao levou a mão à testa. Já conseguia imaginar a cena histórica do tirano, numa futura audiência matinal, apontando para os ministros e gritando “idiotas!” para todos os lados.

Vendo que Lu Linyuan estava furioso, ela tentou aconselhá-lo com cuidado: — Majestade, o eunuco Sanfu não é homem de faltar ao protocolo. Se veio procurá-lo a esta hora, deve ser algo importante. Por que não escuta primeiro o que ele tem a dizer?

Era justamente uma saída honrosa que Lu Linyuan procurava. Mesmo assim, manteve a pose imperial e gritou, impaciente: — Desembucha!

Só então Sanfu ousou falar: — Majestade, o líder dos piratas japoneses, Meichuan Kuchaizi, foi assassinado pelo espião que o senhor enviou! Aproveitando a confusão interna dos invasores, o senhor Tong Guowei atacou com seus soldados e derrotou o inimigo de uma vez!

— As tropas principais já estão a caminho de volta. A notícia da vitória veio na frente. Amanhã cedo, o senhor Tong e o espião enviado por Vossa Majestade poderão comparecer ao palácio e relatar os detalhes pessoalmente!

— Que maravilha! Uma notícia realmente excelente! — Ning Xiaoxiao quase soltou uma gargalhada de alegria.

Piratas japoneses não eram simplesmente japoneses? Se a dinastia Qi conquistasse o Japão, não caberia retribuir, “por cortesia”, com um massacre em Tóquio?

Ning Xiaoxiao parecia ainda mais contente que Lu Linyuan. Curioso, ele perguntou: — Por que está tão empolgada com a derrota dos piratas?

Ela respondeu, sorrindo: — Quem é inimigo da dinastia Qi não pode ser boa coisa. Naturalmente, fico feliz por Vossa Majestade ao ouvir a notícia!

Lu Linyuan beliscou-lhe a bochecha, levantou-se com um movimento das mangas e disse: — Pelo visto, terei muito trabalho esta noite. Descanse cedo. Amanhã venho vê-la.

— Esta concubina se despede respeitosamente de Vossa Majestade!

Assim que ele saiu, Sanfu levou instintivamente as mãos à cabeça, numa postura defensiva.

Lu Linyuan lançou-lhe um olhar. — O que está fazendo?

Sanfu respondeu, magoado: — Eu... interrompi o momento íntimo de Vossa Majestade. Tenho medo de apanhar...

— Aos seus olhos, sou um homem tão cruel assim?

— N-não, claro que não.

— Abaixe as mãos.

Sanfu obedeceu, abrindo um sorriso: — Eu sabia que Vossa Majestade... Hein?

*Plaft!*

O tapa impiedoso chegou, como era de se esperar. Sanfu quase chorou de tanta injustiça. Só conseguia repetir mentalmente:

— Eu não fiz nada contra ninguém!

Depois de andar alguns passos, Lu Linyuan se lembrou de algo que ouvira nos pensamentos de Ning Xiaoxiao:

【Confiar em homem? Só quando porca subir em árvore.】

Olhou para o pinheiro coberto de neve diante da entrada do salão lateral oriental e teve uma ideia repentina. — Vá ao chiqueiro — ordenou a Sanfu.

Sanfu o(╥﹏╥)o: — Majestade, bater em mim já é uma coisa, mas agora quer me fazer morar no chiqueiro? O senhor tem mania de limpeza! Se eu realmente viver entre os porcos, não poderei servi-lo por dez dias, talvez meio mês...

— Não é que eu não goste de morar no chiqueiro, mas gosto mais ainda de servir Vossa Majestade.

Lu Linyuan revirou os olhos. — Que bobagem está resmungando? Quem mandou você morar no chiqueiro?

Apontou para o pinheiro e ordenou: — Vá buscar uma porca no chiqueiro e amarre-a naquela árvore.

Sanfu: “... Está bem, Majestade. O senhor realmente sabe se divertir...”

*

Na manhã seguinte, Ning Xiaoxiao acordou com as gargalhadas no pátio.

Ao abrir a janela treliçada, viu Bengbeng descendo do pinheiro junto à entrada, abraçado a uma porca.

Aquela cena era tão absurda que a deixou a ponto de abrir um espacate ali mesmo:

— Bengbeng, o que você está fazendo? Por que está subindo em árvore com uma porca nos braços logo cedo?

Qiqi explicou entre risinhos, cobrindo a boca: — Ninguém sabe como, mas hoje de manhã essa porca velha apareceu amarrada na árvore, grunhindo sem parar!

Ainda sonolenta, Ning Xiaoxiao lembrou vagamente que dissera no dia anterior que, se fosse possível confiar em homens, até porcas subiriam em árvores. Só podia ser uma maluquice de Lu Linyuan.

Esquecera completamente que aquelas palavras haviam sido apenas um comentário mental, jamais dito em voz alta.

Vendo que ela estava acordada, Qiqi entrou para ajudá-la a se lavar e se arrumar.

Naquele dia, assim que se sentou diante do espelho da penteadeira e se olhou, Ning Xiaoxiao soltou um grito, derrubando a bacia ao lado e espalhando água pelo chão.

— Minha senhora, o que aconteceu?

Ning Xiaoxiao apalpou o rosto que deveria ser o seu desde sempre e perguntou, apavorada: — O-o que aconteceu com meu rosto? Por que ele ficou assim?

As criadas a examinaram atentamente, sem compreender. — Mas ele sempre foi assim! A senhora está sentindo algum desconforto?

Sempre fora assim?

Mas aquele era claramente o rosto que ela tinha no mundo moderno. Seu rosto verdadeiro!

Então, para onde fora a Ning Xiaoxiao original da dinastia Qi?

Ela saiu perguntando a um monte de gente, quase enlouquecida, e todas as respostas foram iguais:

Ela sempre tivera aquele rosto.

Só mais tarde, ao entrar no espaço particular e encontrar um bilhete deixado por Ning Dazhi, descobriu que aquilo tudo era obra da própria mãe.

Às vezes, não sabia o que fazer com aqueles pais trapaceiros. Já não bastava não pensarem em como tirá-la logo de dentro do livro; ainda tinham transformado sua transmigração de alma numa transmigração de corpo inteiro!

Ah, ótimo! Por acaso queriam que ela nunca mais conseguisse voltar para casa?!

*

Enquanto isso, diante do portão leste da capital.

Ren Duanli e Lu Yiqiu haviam sido encarregados por Lu Linyuan de receber os responsáveis pela vitória contra os invasores japoneses.

Tong Guowei era pai da Consorte Nobre. Já tinha um histórico impressionante de vitórias militares e, depois de vencer aquela batalha, estava ainda mais arrogante. Não apenas ignorou a saudação de Ren Duanli como também fingiu não ver Lu Yiqiu quando este o cumprimentou.

Quando a comitiva de Tong Guowei passou, Lu Yiqiu soltou um bufo desdenhoso e resmungou para Ren Duanli: — Humpf! Quem ele pensa que é? Mais cedo ou mais tarde, vou pedir ao meu irmão que lhe dê uma lição...

Virou a cabeça e viu um homem bonito aproximando-se dos dois.

Devia ser o espião que Lu Linyuan enviara para se infiltrar entre os invasores japoneses quatro anos antes e que, depois de conquistar a confiança de Meichuan Kuchaizi, aproveitara a oportunidade para assassiná-lo.

Ao ver como era bonito, Lu Yiqiu ficou todo encantado: — Uau! Que gato!

Ren Duanli franziu a testa, cobriu os olhos de Lu Yiqiu com uma das mãos e, com a outra, deu um tapinha no ombro do belo rapaz que se aproximava, saudando-o com uma risada franca:

— Xingran! Há quanto tempo!

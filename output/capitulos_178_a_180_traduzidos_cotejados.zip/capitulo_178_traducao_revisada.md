# Capítulo 178 — A pessoa de quem gosto tem o mesmo nome que você

Ning Xiaoxiao mexia no celular, sentada num banco de descanso. Ao lado dela, Lu Linyuan apoiava os cotovelos nas coxas e a observava de soslaio.

Era a primeira vez que Lu Linyuan contemplava uma mulher vinda do mundo moderno. Mal encontrava palavras para descrever o que sentia.

Se, na dinastia Qi, ele se apaixonara primeiro pela alma de Ning Xiaoxiao, ali, no mundo moderno, o que o conquistara à primeira vista fora, sem dúvida, sua aparência.

Nunca fora alguém que julgasse as pessoas pela beleza. Mas, se uma alma interessante e um rosto bonito pertenciam à mesma pessoa, tanto melhor.

Só que aquilo que lhe parecia belo também atraía os olhos alheios.

Quase todos os que passavam lançavam uma olhadela aos dois.

Os homens olhavam para Ning Xiaoxiao; as mulheres, para Lu Linyuan.

Naquele dia, Ning Xiaoxiao usava uma saia curta. O olhar de Lu Linyuan passou pelas pernas alvas, longas e retas dela. Então, ele abriu o zíper da jaqueta, tirou-a e cobriu as pernas da moça.

Ela se virou para ele, mas, antes que pudesse falar, Lu Linyuan se adiantou: — Fique com ela. Você pode sentir frio.

— Ah, mas eu não estou com frio! — protestou Ning Xiaoxiao, tentando tirar a jaqueta.

A palma larga de Lu Linyuan pressionou a coxa dela por cima do tecido. Com a voz fria, declarou: — Se eu digo que está com frio, então está.

Só aí Ning Xiaoxiao percebeu o ciúme escancarado em sua expressão. Em tese, deveria sentir uma alegria secreta ao receber do namorado uma atenção tão possessiva. Mas, em vez disso, ficou irritada.

Porque tinha a impressão de que todas as atitudes estranhas de Lu Linyuan naquele dia se deviam simplesmente ao fato de ele ter ficado deslumbrado com a beleza dela.

Levantou-se e atirou a jaqueta de volta para ele. — Cansei de ficar sentada.

Lu Linyuan pegou a peça e a jogou displicentemente sobre o ombro. Pressionou a língua contra a parte interna da bochecha e perguntou, confuso: — Está zangada?

— Eu? Não. Por que ficaria zangada do nada?

Pois é. Por que estaria zangada?

Nem a Ning Xiaoxiao da dinastia Qi nem a Ning Xiaoxiao do mundo moderno tinham qualquer relação formal com Lu Linyuan.

Que direito ela tinha de sentir ciúme?

Tratou de recompor o humor. Afinal, estavam passeando; o importante era se divertir.

Então anunciou: — Vem. Sua irmãzona aqui vai te levar para pegar bichinhos de pelúcia.

Lu Linyuan nem teve tempo de reagir antes de ser arrastado por ela.

Por dentro, não conseguia entender:

【Como assim? Na terra dela, capturar criancinhas também é uma brincadeira?】

【Eu não gosto muito de pegar criancinhas. Prefiro fazer criancinhas com você...】

Só depois descobriu que os “bonequinhos” que Ning Xiaoxiao queria pegar eram mais daquelas coisas feiosas e peludas.

Ela dissera que ia ensiná-lo a ganhar bichinhos na máquina, mas era uma completa negação. Jogava pessimamente e, mesmo assim, não sabia parar.

Gastou cem yuans em fichas e não conseguiu tirar um único brinquedo.

Quando, enfurecida, estava prestes a ir embora, Lu Linyuan apanhou um punhado de fichas, animado: — Deixe-me tentar.

Colocou a ficha, movimentou a garra, baixou-a e... acertou!

Executava tudo com uma facilidade absurda. Era como se tivesse virado um bug ambulante do fliperama: qualquer pelúcia que Ning Xiaoxiao apontasse, ele pegava. Pouco depois, esvaziara duas máquinas inteiras.

Os outros homens saíam do shopping carregando sacolas de roupas, bolsas e cosméticos para as namoradas.

Já Lu Linyuan saiu carregando três sacolas abarrotadas de pelúcias. Um bando de crianças, heróis solitários diante daquela façanha, olhava com inveja, puxando a mão das mães e choramingando “Mãe, eu quero!”. A recompensa foi levar uma bela bronca.

À noite, o parque de diversões se enchia de barracas de comida. Para Ning Xiaoxiao, comida porcaria era simplesmente a melhor coisa do mundo!

Ela arrastou Lu Linyuan para provar tudo o que desejava: glúten grelhado, macarrão frio grelhado, bolinhas de polvo e muitas outras coisas. Ele aceitou praticamente tudo — exceto a porção de tofu fedorento, que jogou fora às escondidas.

Depois de comerem até se fartar, Ning Xiaoxiao calculou que já estava quase na hora de voltar para casa, despedir-se direito dos pais e regressar à dinastia Qi para retomar seriamente suas batalhas no harém.

Mas, quando estavam quase chegando à saída do parque, Lu Linyuan parou de repente, ergueu a cabeça e apontou para a roda-gigante iluminada: — O que é aquilo? É tão alto...

A paisagem do rio na cidade Z era famosa no país inteiro, especialmente à noite.

Mas Ning Xiaoxiao vivera ali por tantos anos e nunca parara para apreciar a vista de verdade.

Não sabia quando poderia voltar, nem se Lu Linyuan teria outra oportunidade de acompanhá-la.

Melhor não deixar arrependimentos.

Ela ergueu as sobrancelhas para ele, assumindo ares de irmãzona mandona: — Quer brincar? Eu te levo!

Convencida de que Lu Linyuan não conhecia sua verdadeira identidade, Ning Xiaoxiao abusava da liberdade de falar o que quisesse.

Entraram na roda-gigante e esperaram a cabine subir lentamente até o ponto mais alto. Dali, os letreiros luminosos da cidade se misturavam ao brilho ondulante do rio, compondo uma pintura multicolorida. Os dois ficaram tão absorvidos pela paisagem que até a respiração se aquietou.

Havia uma pequena fresta na cabine de vidro temperado. Por ela entrou furtivamente uma brisa úmida do rio, que bagunçou a franja de Ning Xiaoxiao.

Vendo-a concentrada na paisagem, Lu Linyuan, com a maior naturalidade, afastou os fios e os colocou atrás da orelha dela.

O gesto íntimo pareceu fazer a temperatura da cabine fechada subir sem parar.

De repente, uma ideia lhe ocorreu.

Queria perguntar a Lu Linyuan o que ele realmente sentia pela Ning Xiaoxiao do mundo antigo.

Mas uma pergunta direta poderia revelar sua identidade. Restou-lhe sondá-lo de maneira indireta:

— Ei, você gosta de alguém?

— Gosto. — Lu Linyuan respondeu com um aceno de cabeça, praticamente sem hesitar.

Baixou os olhos para as luzes coloridas ao pé da roda-gigante. Refletidas em suas pupilas, pareciam pedras preciosas, estrelas distantes, sonhos impossíveis de alcançar.

Só que Ning Xiaoxiao mal teve tempo de cair na melancolia: aqueles olhos de joia já se voltavam para ela.

Com um sorriso malandro, ele acrescentou: — Por coincidência, a pessoa de quem gosto tem exatamente o mesmo nome e sobrenome que você.

Ning Xiaoxiao: “!!!”

Sentiu o coração perder o compasso, impulsionado por uma mistura de adrenalina e dopamina.

Ainda assim, fez o possível para aparentar tranquilidade. — E vocês estão juntos?

— Não. — Lu Linyuan balançou a cabeça, entrelaçou as mãos atrás da nuca e se recostou preguiçosamente.

Ning Xiaoxiao insistiu: — Se gosta dela, por que não estão juntos?

Lu Linyuan deu um sorriso frio.

Heh. Boa pergunta.

Lembrou-se da definição que Ning Xiaoxiao lhe dera pouco antes para o xingamento “idiota”:

【Não muito inteligente, meio lenta para entender as coisas.】

Então respondeu: — Porque ela é uma idiota.

Ning Xiaoxiao: “???”

【Obrigada por nada! Que sujeito broxante!】

Depois, conversaram sobre muitas outras coisas, mas, por enquanto, não tocaram mais no assunto amor.

Depois de passar o dia inteiro passeando, Ning Xiaoxiao sentiu o cansaço chegar, embalada pela brisa agradável da noite.

Passou a responder distraidamente às palavras de Lu Linyuan, apoiou a cabeça no vidro temperado e fechou os olhos aos poucos.

Quando teve certeza de que ela dormira, Lu Linyuan se aproximou com cuidado, passou-lhe um braço pelos ombros e acomodou a cabeça dela contra o próprio ombro.

Ficou quietinho, controlando até o ritmo da respiração, com medo de despertar aquele coelhinho assustadiço.

Permaneceu contemplando, encantado, a bela paisagem abaixo.

Por um instante, desejou ficar ali. Abandonar o governo, as disputas e conspirações; viver com Ning Xiaoxiao como naquele dia, repetindo a rotina até que os dois envelhecessem juntos e os cabelos embranquecessem.

Com esse pensamento no coração, o sono também o venceu. Fechou os olhos para cochilar um pouco.

Quando os dois estavam profundamente adormecidos, um tênue clarão azul cintilou e eles desapareceram novamente no ar.

Na cabine da roda-gigante onde estiveram, restaram apenas as muitas sacolas de bichinhos de pelúcia...

*

Cena extra fictícia:

Ning Xiaoxiao: — Amor, aquele palácio que você construiu para mim na Ilha do Pinguim já está cheio de amigos meus.

(Olha para baixo, cutucando os dedos, estilo figurinha.jpg.)

Lu Linyuan puxou Ning Xiaoxiao, que estava sentada no sofá, para os braços. Com o indicador, brincou com os cabelos soltos dela e disse, deixando escapar um pouco de ciúme:

— Você tem amigos demais. Mal sobra tempo para me fazer companhia.

— Não, não! Podemos brincar todos juntos! Você entende o que eu quero dizer, né?

Lu Linyuan abriu um sorriso malicioso e deu um tapinha no traseiro dela:

— Já construí há tempos. O número da porta é 584082189.

Então a pegou no colo, enquanto ela se remexia, fazendo charme e protestando, levou-a até o quarto e fechou a porta com o pé.

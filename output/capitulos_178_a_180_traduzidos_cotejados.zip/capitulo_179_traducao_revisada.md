# Capítulo 179 — De volta à Antiguidade, de corpo e alma

Era como mergulhar mais uma vez numa escuridão sem limites, como uma planta flutuante à deriva num lago, levada pelo vento, sem saber onde iria parar.

Só que, daquela vez, no túnel do espaço-tempo, Ning Xiaoxiao avistou, não muito longe, uma mulher de costas para ela.

A desconhecida vestia um longo traje azul-lago de mangas largas, leve e esvoaçante. Era esguia e permanecia de pé, elegante, como se aguardasse alguém.

A corrente do tempo foi empurrando Ning Xiaoxiao até ela. Quando a mulher se virou lentamente, revelou um rosto idêntico ao seu.

Mais exatamente, aquele era o rosto que pertencia à Ning Xiaoxiao da dinastia Qi.

A mulher lhe sorriu: — Minha missão está cumprida. Daqui em diante, você terá de seguir o próprio caminho sozinha.

Ning Xiaoxiao não entendeu o significado daquelas palavras. Ia perguntar, mas o corpo da mulher começou a se fragmentar em símbolos digitais, que se espalharam ao vento e desapareceram no silêncio.

Ela continuou flutuando. A escuridão que a cercava começou a se iluminar com pequenos pontos de luz.

Os pontos se tornaram cada vez mais brilhantes e acabaram formando imagens coloridas, congeladas no tempo.

Como uma apresentação de slides, as imagens passavam rapidamente diante de Ning Xiaoxiao.

Algumas retratavam acontecimentos que ela havia vivido; outras, coisas que nunca experimentara.

Por exemplo, viu a si mesma vestida com as roupas cerimoniais de imperatriz. Lu Linyuan segurava sua mão, e os dois estavam numa plataforma elevada do Palácio Chaoyang, recebendo a reverência dos ministros ajoelhados.

A imagem mudou: apareceu um casal de crianças, um menino e uma menina, de rostos arredondados e muito vivazes, brincando ao redor dela e de Lu Linyuan. As sobrancelhas e os olhos da menina lembravam muito os de Lu Linyuan; já o nariz e a boca do menino eram praticamente iguais aos de Ning Xiaoxiao.

Outra cena surgiu: numa noite escura, Gu Sijin, com expressão feroz e sombria, empunhava um punhal reluzente e o cravava repetidas vezes no peito da imperatriz.

...

Enquanto Ning Xiaoxiao assistia, no túnel do espaço-tempo, àquele filme protagonizado por ela própria, Lu Linyuan já havia completado a travessia. Despertara antes e a observava sem piscar.

Como Qi Meijuan havia conseguido alterar os dados do livro, Ning Xiaoxiao agora possuía corpo e alma reunidos, tendo realizado uma transmigração física completa.

Mas nenhum dos personagens do livro perceberia que seu rosto mudara.

Naquele momento, Lu Linyuan não notava nada de errado ao fitá-la. Apenas sentia uma inexplicável novidade.

Aquela maluca vivia diante dele dia e noite. Por que, então, hoje parecia tão atraente, a ponto de ele não conseguir parar de olhar?

Chegava a ter vontade de engoli-la inteirinha...

Quando Ning Xiaoxiao acordou, aquele rosto bonito estava bem na frente do seu.

Instintivamente, olhou primeiro para os cabelos dele:

【Ufa... Ainda bem que o cabelo continua aí! Senão, que constrangimento...】

Lu Linyuan manteve a expressão tranquila, mas comemorou por dentro.

Então ela se preocupa com a dignidade deste imperador, afinal.

Só que, no instante seguinte, os pensamentos dela acabaram novamente com sua alegria:

【Se ele tivesse ficado careca de verdade e eu recebesse outra missão de fazer nele dois rabos de cavalo ou tranças, como ia conseguir completá-la?】

Lu Linyuan: “...”

Ning Xiaoxiao se espreguiçou de maneira teatral, bocejou e só então comentou: — Não sei por que fiquei com tanto sono. Acabei adormecendo do nada... Desculpe ter feito Vossa Majestade presenciar essa cena ridícula.

Lu Linyuan acompanhou a encenação que ela havia inventado: — Não faz mal. Eu também cochilei um pouco.

Ning Xiaoxiao tinha o hábito de prender alguma coisa entre as pernas ao dormir. Só assim se sentia verdadeiramente segura.

Antes, fazia isso com o cobertor ou o travesseiro. Mas, naquela noite, Lu Linyuan estava deitado ao seu lado, um enorme travesseiro de carne e osso. Assim que adormeceu, ela naturalmente jogou uma perna por cima dele.

Agora, acordada, ainda tinha a cabeça confusa por causa de tantos slides estranhos que vira durante a travessia. Por isso, esqueceu de retirar a perna.

Só percebeu quando viu o olhar de Lu Linyuan pousar nela. Assustada, tentou recolhê-la.

Mas Lu Linyuan foi ainda mais rápido.

Antes que ela pudesse se mexer, a mão grande dele cobriu sua panturrilha e a segurou com firmeza.

As pontas dos dedos desenharam círculos sobre o tecido fino da calça de Xiaoxiao, provocando cócegas e arrepios. O corpo dela estremeceu involuntariamente.

— Majestade... o senhor...

— Você está se aproveitando de mim.

— ???

— Toda vez que dormimos juntos, você faz uma cena, diz que não quer. Mas, depois que adormece, fica passando as mãos e as pernas por mim.

Lu Linyuan aproximou o corpo e, com a outra mão, deu um toque de leve na ponta do nariz dela. Com a voz rouca, perguntou:

— Você confia tanto assim na minha decência? Ou acha que bancar a difícil é uma maneira de despertar meu interesse?

Ning Xiaoxiao tentou explicar, aflita: — Majestade, o senhor entendeu errado... Eu...

— Shhh. — O dedo que repousava sobre o nariz dela deslizou lentamente até o arco do lábio superior. Ele se inclinou, aproximando o rosto do dela, e murmurou junto ao seu ouvido:

— Admito que essa estratégia funciona comigo.

Ning Xiaoxiao: 【Socorro!!! Será que a montanha-russa deixou esse homem com o cérebro avariado? O cérebro já não era lá essas coisas, e o cerebelo parece nem ter se desenvolvido!】

Aquela cantada melosa de Lu Linyuan era de dar vergonha alheia, mas as reações instintivas de seu corpo não mentiam.

Por mais que mentalmente o chamasse de galanteador cafona, o rosto vermelho, o coração acelerado e a respiração descompassada a lembravam de uma coisa:

Ela queria. Só não tinha coragem de admitir.

Lu Linyuan brincou com uma mecha de seus cabelos e falou num tom sedutor: — Tive um sonho estranho. Sonhei com uma moça que tinha exatamente o mesmo nome que você.

Ning Xiaoxiao empurrou o peito dele e respondeu depressa: — Sonhos não devem ser levados a sério! Já está tarde. Melhor Vossa Majestade voltar aos seus aposentos...

Lu Linyuan se lembrou do urso de pelúcia feioso e peludo. Arqueou uma sobrancelha, divertido:

— Você consegue dormir sem me abraçar?

Ele se aproximou mais, a um instante de tocar os lábios delicados de Ning Xiaoxiao.

Decidida a levar até o fim a encenação de se fazer de difícil, ela recuou sem parar. Quando sua cabeça estava prestes a bater na quina de um armário de jacarandá ao lado do leito aquecido, Lu Linyuan estendeu a mão rapidamente para protegê-la e a encurralou ainda mais, com um sorriso travesso:

— Agora não tem para onde fugir.

Ning Xiaoxiao pensou que, àquela altura, talvez fosse melhor simplesmente ceder.

Mas lembrou-se do que acontecera naquele dia, e o ciúme voltou com tudo:

【Aquele imperador cachorro foi todo solícito quando me viu no mundo moderno, como se nunca tivesse visto uma mulher na vida!】

【Minha mãe tinha razão: todos os homens do mundo, tirando meu pai, são farinha do mesmo saco. Veem uma mulher nova e já se apaixonam. Confiar em homem? Só no dia em que porca subir em árvore!】

Então, emburrada de ciúme, declarou: — Majestade, não fique tão confiante. Tenho mais saídas do que o senhor imagina!

Fechou os olhos e chamou o documento. Fosse com Retroceder, Pausar ou Modificar a trama, tinha como escapar daquela situação constrangedora.

Já Lu Linyuan, depois de ouvir seus pensamentos, ficou dividido entre rir e chorar.

Jamais imaginara que existisse no mundo uma mulher capaz de ter ciúme de si mesma e disputar consigo própria. Era mesmo uma bobinha...

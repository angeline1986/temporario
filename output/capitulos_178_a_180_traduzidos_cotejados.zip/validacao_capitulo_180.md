# Validação do capítulo 180

- **Fonte primária:** `novel_capitulos_121_a_180(20261105-150504).docx` (chinês tradicional).
- **Limites originais:** parágrafos índice base zero de 4122 até 4199, delimitados pelos títulos dos capítulos 180 e fim do documento.
- **Unidades não vazias incluindo título e eventuais notas:** 76.
- **Linhas do CSV (sem cabeçalho):** 76.
- **Cabeçalho do CSV:** `indice_docx,original_chines,traducao_portugues`.
- **Verificações:** cobertura integral dos índices não vazios da seção, ordenação, índices repetidos (nenhum), índices ausentes (nenhum), campos vazios (nenhum), compatibilidade parágrafo a parágrafo do Markdown com as traduções do CSV (confirmada).

## Decisões editoriais e observações

O tom violento de Ning sobre um eventual massacre em Tóquio é fala/pensamento de personagem e não endosso editorial. Preservados o ato de amarrar a porca à árvore, a compreensão de Lu sobre um pensamento não verbalizado, a revelação do rosto moderno e a aparição final do espião Xingran. “Meichuan Kuchaizi” translitera o nome jocoso do original; não houve padronização externa.

## Limitações

A revisão contextual acompanhou a tradução, mas não houve segunda auditoria semântica independente por outro tradutor. A correspondência estrutural 1:1 não garante sozinha a inexistência de erros de sentido em cada frase. O texto conserva o caráter ficcional, a ironia e as ambiguidades narrativas do original.

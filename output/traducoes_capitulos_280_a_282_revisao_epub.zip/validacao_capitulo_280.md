# Validação — Capítulo 280

**Chinês:** `novel_capitulos_271_a_300(20261106-202946).docx` (cópias DOCX confirmadas idênticas por SHA-256).

**Português-base:** `novel capitulos 271 a 300 - ch.epub`; seção `index_split_009.html`.

**Limites do capítulo no DOCX:** índices 607 a 679, base zero (inclusive espaços em branco).

**Unidades não vazias:** 70; correspondência por ordem 1:1 EPUB/DOCX, incluindo título e marcadores.

**Índices inicial/final:** 607 / 678.

## Ajustes editoriais e conferência

- Revisado o gênero de Chu Xingran e de Ning Xiaoxiao, e o tempo verbal de pensamentos narrados como discurso indireto.
- Mantida a diferença entre promessas de Lu Linyuan aos desertores e sua intenção secreta de puni-los.
- O trecho de previsão sobre a morte de Chu Xingran permanece uma possibilidade da trama consultada, não um fato já ocorrido.

## Limites

A estrutura 1:1 e a integridade do CSV/Markdown foram verificadas automaticamente. Houve cotejo contextual e correções editoriais focalizadas com o original chinês. **Não houve uma segunda auditoria semântica independente integral**, nem comprovação automática de equivalência semântica de cada frase. A tradução portuguesa do EPUB é a base e pode conservar inadequações pontuais não detectadas.

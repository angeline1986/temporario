# Validação — Capítulo 281

**Chinês:** `novel_capitulos_271_a_300(20261106-202946).docx` (cópias DOCX confirmadas idênticas por SHA-256).

**Português-base:** `novel capitulos 271 a 300 - ch.epub`; seção `index_split_010.html`.

**Limites do capítulo no DOCX:** índices 680 a 752, base zero (inclusive espaços em branco).

**Unidades não vazias:** 70; correspondência por ordem 1:1 EPUB/DOCX, incluindo título e marcadores.

**Índices inicial/final:** 680 / 751.

## Ajustes editoriais e conferência

- Preservados pensamentos 【 】, cotas de edição em caracteres chineses (字) e a antecipação de dez dias de permissões.
- Corrigido o falso sentido de “sistema de defesa” e a ironia sobre a visita dos pais à Agência de Administração do Espaço-Tempo.
- A trama original sobre Gu Sijin é tratada como narrativa projetada, não como acontecimentos já ocorridos na linha atual.

## Limites

A estrutura 1:1 e a integridade do CSV/Markdown foram verificadas automaticamente. Houve cotejo contextual e correções editoriais focalizadas com o original chinês. **Não houve uma segunda auditoria semântica independente integral**, nem comprovação automática de equivalência semântica de cada frase. A tradução portuguesa do EPUB é a base e pode conservar inadequações pontuais não detectadas.

# Capítulo 281 — Gu Sijin, não vá entrar para o lado sombrio...

Na trama original, a morte de Chu Xingran havia levado Gu Sijin a se tornar implacável.

Depois dessa mudança, Gu Sijin praticamente dizimou o harém da dinastia Qi. A obra não esclarecia se ela estava diretamente envolvida na morte de Lu Linyuan, mas as pistas espalhadas pela narrativa sugeriam que a assassina do imperador provavelmente fora ela.

Ao olhar para Gu Sijin, que tinha as sobrancelhas ligeiramente franzidas e os olhos marejados, Ning Xiaoxiao teve dificuldade em associá-la à protagonista feminina implacável, ardilosa e poderosa da obra original.

Quando alguém genuinamente bondoso e gentil vê destruídos os princípios aos quais sempre se agarrou, pode se tornar ainda mais cruel do que aqueles considerados impiedosos.

Ela não conseguiu evitar um arrepio, pensando silenciosamente consigo mesma:

【Chu Xingran não pode morrer... Se ele morrer e Gu Sijin acabar se tornando aquela mulher implacável, eu... eu não teria a menor chance contra ela!】

【Afinal, na história original, ela arrancou a pele da Consorte Nobre e chutou a imperatriz do alto de uma torre! Eu não quero acabar com a cabeça rachada!】

Independentemente de Gu Sijin se tornar má ou não, Ning Xiaoxiao sempre se lembrou de sua bondade.

Ela não merecia um fim tão trágico.

Ela já sofreu o suficiente na vida; ela merece uma vida melhor.

Ela estava decidida a ajudar Gu Sijin a mudar o destino de Chu Xingran. Mas, ao olhar para o documento, que exibia apenas cem caracteres e escondia o restante sob um mosaico, ficou sem saber como agir.

Como segundo protagonista masculino na obra original, a saída de Chu Xingran da história inevitavelmente ocupará uma parte significativa da narrativa.

Só tinha permissão para modificar cem caracteres por dia, o que não bastava para alterar todo aquele acontecimento.

Então chamou Xiao Qi e, com uma voz doce, tentou negociar:

【Então... meu querido Xiao Qi, posso te pedir uma coisinha? Será que existe alguma possibilidade — só uma possibilidade, viu...】

【De eu editar mais caracteres hoje, usando antecipadamente a cota dos próximos dias?】

Xiao Qi: 【... Anfitriã, você está jogando sujo! Assim fica difícil para mim...】

O fato de ser difícil significa que ainda há esperança.

Ning Xiaoxiao começou a fazer charme: 【Ah, meu querido Xiao Qi! Você é o melhor! Deixa eu pegar um pouquinho emprestado da cota futura! Depois eu compenso, está bem?】

Xiao Qi: 【Você acha que sua cota de edição é igual aos rins do seu marido? Que, se ficarem sobrecarregados, basta tomar um fortificante para recuperá-los?!】

O rosto de Ning Xiaoxiao escureceu instantaneamente:

【Se não dá, não dá! Mas por que você está insinuando que os rins do meu marido não prestam?】

【Os rins do meu marido funcionam muito bem!】

Xiao Qi: 【Então... felicidades para você.】

Após dizer isso, Xiao Qi, que estava quase dormindo, estava prestes a se desconectar, mas assim que fechou os olhos, o rosto 'gentil e benevolente' de Qi Meijuan apareceu de repente em sua mente...

Um “puta merda!” escapou-lhe imediatamente, espantando todo o sono.

Ning Xiaoxiao: 【??? Tudo bem não mudar minha permissão, mas por que está me xingando?!】

Xiao Qi se acovardou na mesma hora: 【Você entendeu errado, anfitriã! Eu poderia xingar qualquer pessoa, menos você!】

Parecia ter virado outro sistema: passou a bajular Ning Xiaoxiao sem o menor pudor.

【Você só quer antecipar a quantidade de caracteres que poderá modificar nos próximos dias, não é? Sem problema! Vou solicitar a autorização agora mesmo!】

'Bip bip bip'

Após um breve ruído mecânico, Xiao Qi trouxe boas notícias:

【Parabéns, anfitriã! A Agência de Administração do Espaço-Tempo aprovou seu pedido. Você pode antecipar a cota dos próximos dez dias. Hoje, seu limite de edição passa de 100 para 1.000 caracteres!】

Era muito raro aquele trapaceiro ceder tão facilmente.

Mas Xiao Qi parecia ter mudado de personalidade ultimamente. Antes, sempre zombava dos pedidos dela. Agora, atendia a tudo e aos poucos se tornava um sistema exemplar.

Ning Xiaoxiao ficou radiante: 【Eu sabia que Xiao Qi era o mais fofo de todos!】

Xiao Qi resmungou: 【Como se eu ousasse dizer não... Se eu não aceitasse...】

Ning Xiaoxiao: 【O que foi?】

Xiao Qi: 【Nada, nada! Divirta-se, anfitriã. Vou dormir um pouco!】

Xiao Qi certamente não ousaria recusar Ning Xiaoxiao.

Na verdade, não era só Xiao Qi: ninguém na Agência de Administração do Espaço-Tempo se atrevia mais a negar os pedidos de Ning Xiaoxiao.

Após retornar de sua transmigração anterior para dentro do livro, Qi Meijuan, juntamente com Ning Dazhi, dirigiu-se imediatamente à sede da Administração do Tempo e do Espaço.

Qi Meijuan invadira a sala do diretor, virara sua mesa e, erguendo o dedo médio, mandara-lhe uma “saudação cordial” extensiva a toda a família.

Ning Dazhi então arrastou o diretor para o banheiro e enfiou a cabeça dele no vaso sanitário, dando descarga doze vezes...

Xiao Qi vira tudo com os próprios olhos. Se ousasse contrariar Ning Xiaoxiao novamente, talvez fosse ele o próximo a levar uma série de descargas com a cabeça enfiada no vaso sanitário...

A vida de um sistema não é fácil. Não chore, Xiao Qi!

*

Naquela noite, a capital estava estranhamente silenciosa.

Os dois corvos do palácio, sempre encarregados de criar o clima, haviam convocado uma porção de companheiros e agora grasnavam sem parar nos galhos da residência Tong.

Tong Guowei e sua esposa tinham acabado de se preparar para ir dormir, mas mal haviam se deitado quando ouviram uma comoção no pátio.

"Pai! Algo terrível aconteceu, Pai!"

Clang!

O filho mais velho, Tong Zhiyin, abriu a porta do quarto com violência e correu, tropeçando, até a cama de Tong Guowei, branco de medo.

— Pai! O comandante dos Nove Portões chegou com a Guarda Tigre e cercou nossa residência!

Um lampejo de malícia brilhou nos olhos de Tong Guowei. De fato, o que estava destinado a acontecer finalmente havia acontecido.

Ele se levantou, vestiu a armadura que havia sido colocada ao lado e, calmamente, ordenou:

— Avise aos guerreiros de confiança e à Guarda de Penas que mantenham a defesa! A residência Tong é fácil de proteger e difícil de invadir. Abram caminho lutando!

Tong Guowei estava confiante.

Mesmo que a Concubina Tong não tivesse conseguido realizar seu plano no palácio, Tong Guowei já pretendia se rebelar mais cedo ou mais tarde.

Seus próprios arqueiros montados, juntamente com os muitos oficiais importantes que ele havia conquistado ao longo dos anos, se levantariam e se rebelariam contra Lu Linyuan sob seu comando.

Embora houvesse uma disparidade significativa na força das tropas entre os dois lados, as forças da Dinastia Qi estavam concentradas principalmente nas fronteiras externas.

As tropas estacionadas na fronteira não conseguem retornar a tempo caso ocorra um golpe palaciano.

Nos últimos dias, Tong Guowei vigiava de perto os movimentos das setenta e duas divisões militares das fronteiras. Se Lu Linyuan ordenasse seu retorno, ele iniciaria imediatamente a rebelião na capital.

Quando as tropas das fronteiras externas retornarem à capital, a Dinastia Qi provavelmente já terá mudado drasticamente.

Do lado de fora do portão, Chu Xingran liderou inúmeros Guardas Tigre para cercar a residência Tong em três camadas.

Chu Xingran gritou em voz grave: — Ministro Tong, o imperador deseja vê-lo. Faça o favor de vir comigo.

Tong Guowei não respondeu. Os guardas no pátio já estavam reunidos. Com sua preciosa espada em mãos, Tong Guowei não sentia medo algum.

Ele tirou um tubo de fogos de artifício usado para transmitir ordens. Assim que o acendesse, seus guerreiros ocultos na capital sob disfarce de civis desencadeariam um massacre indiscriminado.

Quando todo o povo estiver em perigo, esse será o melhor momento para ele romper o bloqueio da capital.

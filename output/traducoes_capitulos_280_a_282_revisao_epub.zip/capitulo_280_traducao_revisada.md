# Capítulo 280 — A família Tong à beira da desgraça

Para realizar o desejo de sua esposa de se tornar imperatriz o quanto antes, Lu Linyuan vinha se desdobrando nos últimos dias.

Ele se controlava para procurá-la apenas uma vez por dia; dedicava o restante do tempo a preparar o plano para eliminar de uma só vez todo o clã Tong.

Para não deixar Xiaoxiao preocupada, decidiu fingir que estava sem vigor.

Às vezes, depois de uma rodada, Xiaoxiao ainda não estava satisfeita e queria repetir a dose. Ele, porém, fazia corpo mole, dizia estar cansado e virava para o lado para dormir.

As mulheres da antiguidade talvez fossem um tanto reservadas e tímidas em relação a esses assuntos, mas Xiaoxiao acreditava na igualdade de gênero do fundo do coração e não se envergonharia de falar sobre tais coisas.

Se Lu Linyuan estava “sem condições”, Xiaoxiao só tinha uma saída: “aproveitar bem” seu poder especial.

Por exemplo:

Retroceder, retroceder e retroceder mais uma vez...

Todas as noites, depois de adormecer, Lu Linyuan se levantava silenciosamente e continuava trabalhando.

Ele trabalhou incansavelmente, tudo para cumprir o mais rápido possível a promessa que lhe fizera.

Finalmente, chegou o dia de fechar a rede.

Chu Xingran, que havia desaparecido do palácio por um bom tempo, foi ao gabinete imperial naquela tarde.

Inicialmente, Lu Linyuan estava discutindo assuntos com vários ministros, mas ao saber que se tratava dele, dispensou imediatamente os funcionários da corte e se encontrou com ele a sós.

— Majestade, já fizemos contato com o ministro Kang e o general Chen. Ambos estão dispostos a abandonar Tong Guowei e obedecer às suas ordens.

Lu Linyuan oferecera condições generosas: depois da queda de Tong Guowei, cada um dos que mudasse de lado receberia uma cidade e poderia governar seu próprio território.

Mas, por enquanto, tudo não passava de promessas verbais.

Tendo servido na corte por muitos anos, eles confiavam na integridade de Lu Linyuan e acreditavam em sua palavra, por isso estavam dispostos a abandonar as trevas e abraçar a luz simplesmente por causa de sua promessa.

Para Lu Linyuan, um imperador devia cumprir sua palavra diante de homens honrados. Mas por que haveria de manter promessas feitas a sujeitos desprezíveis?

Quando a árvore cai, os macacos se dispersam. Depois de eliminar Tong Guowei, ele não pouparia nenhum dos oficiais que haviam traído a dinastia Qi.

Assim, praticamente todas as cartas na manga de Tong Guowei já haviam sido persuadidas por Lu Linyuan a mudar de lado.

Tong Guowei desconhecia completamente tudo isso.

Tong Guowei só pensava em enfrentar as famílias da imperatriz e da imperatriz-viúva, além de se aliar a Gu Yanchuan, censor do Tribunal de Fiscalização. Nem percebeu que o verdadeiro caçador já descobrira seus pontos fracos e preparava o golpe fatal.

Tudo está pronto; esta noite é a oportunidade perfeita para cercar e aniquilar o clã Tong.

— A Concubina Tong tentou me drogar no palácio. Todo o harém testemunhou o ocorrido; ela não pode negar. Use isso como justificativa: esta noite, cerque a residência de Tong Guowei com seus soldados e traga toda a família dele, dos mais velhos aos mais jovens, ao palácio.

Chu Xingran juntou as mãos em sinal de aceitação da ordem: "Seu humilde servo certamente não falhará em cumprir seu comando!"

Lu Linyuan deu um tapinha no ombro dele: "Os soldados particulares da mansão de Tong Guowei são todos muito habilidosos em artes marciais. Tenha cuidado, caso ele fique desesperado."

Chu Xingran deu de ombros e sorriu com desdém: "Majestade, fique tranquilo, tenho confiança em lidar com aquele velho patife."

Lu Linyuan: "Que bom. Assim que terminar, eu te recompensarei com algo 'bom'."

O coração de Chu Xingran se agitou ao ouvir aquilo.

Na última viagem à residência de fontes termais, ele ouvira Ren Duanli dizer que Lu Linyuan e Ning Xiaoxiao estavam apaixonados e que o imperador até cogitava destituir a imperatriz.

Se o imperador só tinha olhos para Ning Xiaoxiao, talvez concordasse em lhe conceder Gu Sijin como recompensa por um grande feito?

Pedir ao imperador que lhe entregasse uma mulher do harém parecia um completo absurdo.

Mas Chu Xingran sofria tanto de saudade que não conseguia dormir. Já não suportava passar nem mais um dia afastado de Gu Sijin.

Ele então respirou aliviado e disse: "Este humilde súdito ousa pedir a Vossa Majestade mais um favor."

O sorriso de Lu Linyuan era enigmático. "Como você sabe que o que está pedindo não é algo que eu já tenha concedido?"

*

Naquele dia, Chu Xingran recebeu uma resposta clara de Lu Linyuan.

O imperador sabia havia muito tempo da relação entre Chu Xingran e Gu Sijin e já decidira reuni-los quando o assunto de Tong Guowei estivesse resolvido.

Chu Xingran é uma pessoa extremamente racional, mas agora mesmo, seus olhos se avermelharam diante do imperador.

Mais tarde, Lu Linyuan brincou: "Você não é a Xiaoxiao. Se chorar na minha frente, vou querer te bater. Se quiser chorar, encontre um lugar isolado e chore devagar."

Então ele foi procurar Gu Sijin.

Ele queria fazer uma surpresa a Gu Sijin. Por isso, não lhe contou que Lu Linyuan permitiria sua saída do palácio para que ficassem juntos.

Ele simplesmente disse a Gu Sijin que lideraria tropas para sitiar Tong Guowei naquela noite e que teria mais boas notícias para lhe contar depois que a missão fosse concluída.

Gu Sijin disse para ele ter cuidado com tudo, e então tirou seu próprio amuleto e o amarrou na cintura de Chu Xingran.

"Tong Guowei é astuto e traiçoeiro. Ouvi meu pai dizer que ele mantém muitos assassinos em sua casa, todos altamente habilidosos em artes marciais, insidiosos e implacáveis. Tenha cuidado em tudo o que fizer. Estarei esperando por você."

Chu Xingran sorriu, ergueu o queixo dela, ignorando suas objeções e a beijando apaixonadamente.

Após o beijo, seus narizes se tocaram, e ele sorriu maliciosamente, dizendo: "Você tem tão pouca fé no seu homem?"

Gu Sijin corou e o empurrou, dizendo: "Não fale bobagens, você não tem vergonha?"

Ele passou o braço em volta da cintura de Gu Sijin e depositou um beijo carinhoso em sua testa. "Espere por mim. Eu não me esqueci da minha promessa."

Gu Sijin se aconchegou nos braços dele e assentiu com firmeza.

É claro que ela o esperará, esperará por toda a vida.

Haviam suportado tantos anos. Que diferença fariam mais alguns dias?

No entanto, ela era alguém que não conseguia guardar segredos e, depois de retornar ao palácio, parecia distraída.

Ao vê-la assim, Ning Xiaoxiao perguntou o que havia de errado, mas ela se recusou a dizer.

Embora confiasse bastante em Ning Xiaoxiao, o assunto entre ela e Chu Xingran era, afinal, um grande tabu, e ela tinha vergonha de falar sobre isso na frente de Ning Xiaoxiao.

Mesmo sem dizer nada, Ning Xiaoxiao conseguiu adivinhar uma coisa ou outra.

Lu Linyuan acabara de visitá-la e lhe disse que iria derrotar Tong Guowei naquela noite.

Portanto, a partida de Gu Sijin agora há pouco provavelmente se deve a um encontro com Chu Xingran.

Ela deve estar preocupada que algo possa acontecer ao seu jovem.

Ning Xiaoxiao fingiu não saber do relacionamento dos dois e, em pensamento, abriu o documento da trama para consultar os acontecimentos seguintes.

Mas só podia visualizar cem caracteres de cada vez. Precisou consultar o documento repetidamente até descobrir o que aconteceria naquela noite na residência Tong.

【Chu Xingran liderou os soldados e cercou a residência Tong. Tong Guowei recusou-se a se render e resistiu até o fim.

Os guerreiros dispostos a morrer pela família aguardavam em posição de combate, prontos para atacar assim que a Guarda Tigre arrombasse o portão.

Tong Guowei, oculto no alto do pavilhão, preparou seu arco ao lado dos guardas de penas e dos guerreiros de confiança.

As pontas das flechas haviam sido embebidas em veneno mortal; quem fosse atingido não teria salvação.

Chu Xingran acabou atingido por uma flecha e morreu durante o confronto...】

Então, será que ele realmente perderá a vida neste cerco?

Ning Xiaoxiao se lembrava claramente de que a completa decadência de Gu Sijin na obra original se devia à morte de Chu Xingran...

Ning Xiaoxiao engasgou ao ver as sobrancelhas franzidas e a expressão preocupada de Gu Sijin...

# Validação — Capítulo 282

**Chinês:** `novel_capitulos_271_a_300(20261106-202946).docx` (cópias DOCX confirmadas idênticas por SHA-256).

**Português-base:** `novel capitulos 271 a 300 - ch.epub`; seção `index_split_011.html`.

**Limites do capítulo no DOCX:** índices 753 a 826, base zero (inclusive espaços em branco).

**Unidades não vazias:** 71; correspondência por ordem 1:1 EPUB/DOCX, incluindo título e marcadores.

**Índices inicial/final:** 753 / 825.

## Ajustes editoriais e conferência

- Corrigida a fala de Tong Guowei sobre a filha: “se morrer”, não “já está morta”.
- Recuperados o acendedor de pavio e o *dudou*, vestimenta tradicional omitida na tradução-base.
- A intervenção sobrenatural que altera o comportamento dos soldados não recebeu causa inventada.

## Limites

A estrutura 1:1 e a integridade do CSV/Markdown foram verificadas automaticamente. Houve cotejo contextual e correções editoriais focalizadas com o original chinês. **Não houve uma segunda auditoria semântica independente integral**, nem comprovação automática de equivalência semântica de cada frase. A tradução portuguesa do EPUB é a base e pode conservar inadequações pontuais não detectadas.

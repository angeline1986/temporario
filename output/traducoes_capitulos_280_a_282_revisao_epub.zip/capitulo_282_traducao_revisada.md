# Capítulo 282 — Quer apreciar minha dança?

Tong Guowei apertava o tubo de fogos de artifício na mão enquanto Tong Zhiyin lhe entregava um acendedor de pavio.

Quando ele estava prestes a acender o tubo, a senhora Huo se lançou à frente para impedi-lo:

— Meu senhor! Não, meu senhor!

Com os olhos marejados, a senhora Huo balançou a cabeça: — Pense bem! Yuanyuan ainda está no palácio. Se o senhor se rebelar agora, o imperador não poupará nossa filha! Meu senhor, ela é nossa filha de sangue!

— Sua desgraçada! Saia da minha frente!

Tong Guowei chutou a senhora Huo com força na parte inferior do abdômen. Ela gritou de dor e rolou no chão, agarrando a barriga.

Tong Guowei cuspiu na direção dela: — Se ela morrer, morreu! Não conseguiu nem resolver uma coisa tão simples e ainda me arrastou para essa situação! Você e ela são duas inúteis! Merecem morrer!

— Meu senhor! Por favor, não!

Apesar da dor, a senhora Huo rastejou até os pés de Tong Guowei, agarrando-se firmemente à perna da calça dele e chorando incontrolavelmente.

"Meu senhor... Yuan Yuan é devotada à família Tong. Ela não queria entrar no palácio a princípio, mas veio para cumprir nossos desejos. Embora tenha vivido uma vida de luxo no palácio todos esses anos, ela nunca teve um único dia de verdadeira felicidade... Meu senhor, eu imploro! O senhor não pode tratar Yuan Yuan assim..."

Tong Guowei não demonstrou qualquer consideração pelos seus anos de casamento, pisoteando repetidamente o rosto da senhora Huo.

— Vá para o inferno! Se abrir a boca de novo, mato você também!

O filho mais velho, Tong Zhiyin, interveio: — Mãe, não se meta nisso. Minha irmã nasceu mulher justamente para fortalecer a posição da família Tong na corte. Está no palácio há cinco anos e não conseguiu nem dar à luz um filho! O imperador dá mais atenção a uma criada desconhecida do que a ela!

"Uma mulher como essa é um lixo inútil se nasceu na família Tong. Seria melhor se ela morresse!"

A senhora Huo continuava tentando impedir Tong Guowei, que não conseguia acender o pavio.

Tong Zhiyin parecia ansioso para ver a capital mergulhar no caos. Ele pegou o tubo de fogos de artifício da mão de Tong Guowei.

"Pai! Eu vou fazer isso!"

Tong Zhiyin ergueu o tubo de fogos de artifício, soprou o acendedor até fazê-lo pegar fogo e, quando a chama estava prestes a tocar o pavio, estremeceu. Então... abriu um sorriso surpreendentemente sedutor?

Ele se virou, piscou para Tong Guowei, acendeu o tubo de fogos de artifício, levou-o aos lábios e cantou para Tong Guowei em voz aguda:

— Só de pensar em você, eu já...~

Boom

Assim que terminou de cantar as seis palavras, Tong Zhiyin enfiou o tubo de fogos de artifício na boca sem a menor hesitação.

Logo em seguida, o fogo de artifício explodiu em sua boca, abrindo sua cabeça e espalhando uma nuvem de sangue...

— Zhiyin!

O rosto da senhora Huo estava salpicado de sangue, e ela gritou alarmada antes de desmaiar.

Tong Guowei tinha apenas um filho, e ele morreu de forma tão inexplicável diante de seus olhos. Como ele poderia aceitar isso?

"Ah!!"

Ele rugiu para o céu, mas antes que pudesse terminar, o portão foi arrombado pelos Guardas Tigre.

Chu Xingran brandiu a Espada das Sete Estrelas e, num piscar de olhos, matou mais de uma dúzia de homens.

A lâmina estava manchada de sangue, que escorria da ponta.

Os assassinos restantes recuaram passo a passo, sem ousar fazer qualquer movimento.

Chu Xingran ergueu os olhos, o olhar penetrante percorrendo Tong Guowei com o olhar, e zombou:

— Está latindo por quê?

Dominado pela dor e pela raiva pela perda do filho, Tong Guowei brandiu sua preciosa espada com toda a força, gritando: "Parem eles!"

Depois de dizer isso, ele correu como um coelho sem rabo até o sótão no terceiro andar.

Os assassinos que ele mantinha eram todos mestres de artes marciais; soldados comuns da Guarda Tigre seriam mortos em um instante, não durando nem três movimentos.

As habilidades de artes marciais de Chu Xingran estão entre as melhores da Dinastia Qi. Em uma competição séria, nem mesmo Ren Duanli seria páreo para ele.

Não fosse por isso, jamais teria conseguido passar tantos anos infiltrado entre os piratas japoneses, matar Meichuan Kuchazi e sair ileso.

Ele brandiu sua espada para a frente sem olhar para os lados, matando com um único golpe qualquer um que se colocasse em seu caminho, sem lhes dar qualquer chance de revidar.

Durante o impasse, Tong Guowei ficou de pé na plataforma do sótão do terceiro andar e gritou para Chu Xingran:

"Ha, você acha que pode me subjugar assim? Você é tão estúpido quanto aquele imperador-cão!"

Ele tirou outro tubo de fogos de artifício do bolso, acendeu-o e apontou-o diretamente para o céu.

*Bang! Smack!*

Fogos de artifício explodem no céu noturno completamente escuro, lançando chamas de um tom carmesim.

Em instantes, a comoção vinda de todos os lados de a capital podia ser claramente ouvida.

Eram inúmeros assassinos disfarçados de civis que Tong Guowei havia emboscado na capital. Eles chegaram rapidamente à residência de Tong, e o Exército da Guarda Tigre foi imediatamente cercado pelos assassinos de Tong Guowei.

Chu Xingran franziu ligeiramente a testa ao ver isso; ele havia deixado passar um passo.

Ele jamais imaginou que Tong Guowei treinaria secretamente tantos assassinos, e era arrogante demais; a Guarda Tigre que cercava a residência de Tong hoje se resumia a apenas algumas centenas.

Enquanto uma tempestade sangrenta estava prestes a irromper, os olhos de Chu Xingran endureceram e ele apertou com força o cabo de sua espada.

Ele só tinha duas coisas em mente:

Derrotar os inimigos. Voltar para sua amada.

Mesmo que seja apenas por Gu Sijin, ele está determinado a lutar para sair dessa situação!

Ele não podia deixar Jin'er esperando em vão e vivendo com arrependimento pelo resto da vida.

Tong Guowei, observando tudo do alto, sorriu desdenhosamente: — Comandante Chu, tenha uma boa viagem... para o outro mundo!

Dito isso, ele ergueu a mão direita bem alto e a desferiu com força, dando a ordem:

"Matem-nos!"

Chu Xingran e os homens da Guarda Tigre se agruparam numa formação defensiva, prontos para resistir. A confusão certamente alertaria a Guarda Imperial; bastava aguentar mais um quarto de hora para virar o jogo.

Os assassinos, brandindo espadas e adagas, rugiram enquanto avançavam em direção a eles. Quando uma batalha sangrenta parecia iminente, todos os assassinos pararam a poucos metros dos Guardas Tigre.

Tong Guowei, perplexo, rugiu: "Quem mandou você parar? Mate todos eles!!"

À ordem, nenhum dos quase mil assassinos obedeceu.

Eles não apenas desobedeceram às ordens, como também largaram suas espadas e começaram a tirar as roupas?

Um após o outro, os homens tiraram as vestes exteriores e revelaram os *dudou* que haviam pegado das esposas ou até das mães octogenárias. Eram peças de todas as cores, numa visão de fazer arder os olhos.

Chu Xingran ficou boquiaberto diante da cena surreal. Tong Guowei também não acreditava no que via.

Não foram apenas os guerreiros de confiança. Até os homens da Guarda de Penas ao lado dele largaram os arcos e começaram a se despir...

"Vocês enlouqueceram! Todos vocês enlouqueceram! Um grande inimigo está à espreita! O que vocês estão fazendo!?"

Milhares de guerreiros, agora “prontos para entrar em ação”, gritaram em uníssono para Tong Guowei:

— Meu senhor, gostaria de apreciar a dança desta humilde serva?

Tong Guowei: “???”

No instante seguinte, esses assassinos tiraram de algum lugar todo tipo de instrumento musical e começaram a tocar música decadente.

Sob o olhar perplexo de Tong Guowei, os homens começaram a dançar bem diante dele?!

# Capítulo 144 — A gatinha que aquece a cama

A gata persa possuída por Ning Xiaoxiao era de uma beleza excepcional. Sua pelagem longa e sedosa era inteiramente branca, sem um único fio de outra cor.

Os olhos vivos e brilhantes apresentavam uma rara heterocromia: um era azul, e o outro, castanho. Ambos fitavam Lu Linyuan sem piscar.

Lu Linyuan brincou com os longos e finos bigodes em torno da boquinha dela, parecidos com espinhas de peixe. Depois, colocou-a sobre um assento aquecido e começou a desatar a toalha enrolada à cintura.

As pupilas de Ning Xiaoxiao se estreitaram como fendas, e seu miado traiu certa expectativa: — Miau~ Miaaau~~

Ela achou que finalmente veria alguma coisa. Mas, assim que tirou a toalha, Lu Linyuan a jogou sobre a cabeça da gata bisbilhoteira, enterrando-a sob o tecido.

Quando Ning Xiaoxiao conseguiu sair de debaixo da toalha, ele já havia vestido a roupa de dormir.

Lu Linyuan aproximou o braseiro do assento aquecido e pegou a toalha para secar cuidadosamente os pelos molhados de Ning Xiaoxiao.

Enquanto secava, alisava a pelagem, da cabeça à cauda, com tanta insistência que ela sentiu a pele repuxar e revirou os olhos.

— Miau~~ Miau~~!

【Pare de me acariciar desse jeito! Vai acabar me deixando careca!】

Lu Linyuan: 【Ah, é? Mal fiz dois carinhos e você já não aguenta? E quando passa os dias planejando arrancar meus cabelos, por acaso pensa se eu vou ficar careca?】

Quanto mais a acariciava, mais prazer tomava na tarefa. Não existe gato de pelos compridos que nunca solte pelos. Em pouco tempo, juntou pelinhos suficientes para formar uma bolinha do tamanho de uma bola de gude.

Como cães e gatos adoram brincar com bolinhas, Lu Linyuan balançou deliberadamente aquela bola de pelos diante dos olhos de Ning Xiaoxiao e a deixou cair à frente dela, provocando:

— Vai, vai brincar com sua bolinha da felicidade!

Ning Xiaoxiao olhou para o sorriso bobo dele, revirou os olhos em silêncio e, com uma patada certeira, lançou a bolinha ao chão.

【Vai você! Vai ser um imbecil sem rótulos nem limites!】

Lu Linyuan: — ...

Virou gata e ainda tem coragem de me insultar, é?

Hã! Mulher, ainda vou fazer você implorar por misericórdia!

Depois de secar completamente sua pelagem, Lu Linyuan a ergueu e a deitou de barriga para cima sobre o divã aquecido.

Sua mão grande acariciou a barriga redondinha, enquanto ele exibia um sorriso cheio de segundas intenções.

No instante seguinte, como se fosse atacado por mais um acesso de loucura, segurou as patinhas dela e a obrigou a fazer um espacate...

Manipuladas por ele, as patinhas se abriam e fechavam ritmicamente. O rosto felino de Ning Xiaoxiao parecia dizer que ela perdera toda a vontade de viver.

【Ele sempre foi tão doente assim?】

【Nunca ouvi dizer que gostasse de gatos. Por que está brincando tanto comigo agora?】

【Espera... Será que passa o dia sem amigos nem diversão e acabou ficando idiota de tanto tédio?】

【Nossa, pensando bem, dá até pena. Quando voltar ao normal amanhã à noite, vou lhe dar um bichinho de estimação...】

【Mas, se ele brincar assim com outro gato, vai acabar arranhado. Se for um cachorro, provavelmente vai levar uma mordida.】

【Que tal dar uma tartaruga de casco mole? Aguenta umas brincadeiras brutas, vive muito e, se for bem cuidada, pode até sobreviver a ele e acompanhá-lo até o caixão~】

Lu Linyuan: — ...

Vocês acham que estou brincando com uma gata porque não tenho nada para fazer?

Quero é brincar com você!

E ainda pretende me dar uma tartaruga para durar mais do que eu?

Pois você mesma parece uma tartaruga. Melhor criar você de uma vez!

Desde que Ning Xiaoxiao entrara naquele livro, aproveitava toda oportunidade — deliberadamente ou não, às claras ou pelas costas — para “atormentar” o tirano.

Ela desfigurara tanto o personagem do terrível imperador que ele mal parecia o mesmo. O problema era que Lu Linyuan nunca encontrava uma chance de se vingar.

Pois agora a oportunidade viera bater à sua porta!

Ela só voltaria à forma humana na noite seguinte. Ele precisava aproveitar aquelas vinte e quatro horas para recuperar toda a dignidade perdida!

Ergueu Ning Xiaoxiao no colo, lançou-a bem alto e a aparou com segurança.

O coração dela disparou com aquela brincadeira. Ning Xiaoxiao não parava de miar:

【Imperador cachorro! Você é um monstro!】

【Quem maltrata gatos merece ser atingido por um raio! Me ponha no chão agora!】

Lu Linyuan fez ouvidos moucos aos protestos felinos. Só voltou a aconchegar a atordoada Ning Xiaoxiao no colo depois de se divertir à vontade.

Ele a jogara ao alto sete ou oito vezes. Ning Xiaoxiao, que já tinha medo de altura, estava cada vez mais furiosa. E agora o tirano ainda tinha a audácia de aproximar aquele rostinho lindo para esfregar o rosto no dela?

Nem pensar!

Ela disparou as patas dianteiras e ativou a habilidade inata dos gatos: a “Palma Sem Sombra”.

As patinhas atingiram o rosto de Lu Linyuan numa velocidade impossível de acompanhar com os olhos. Em apenas dois segundos, ele levou mais de uma dezena de tapas.

Apesar das patadas, ela não estendeu as garras.

Afinal, se estragasse aquele rosto bonito, seria ela mesma quem ficaria triste, tá?

Lu Linyuan não se irritou nem um pouco. Em vez disso, coçou o queixo da gatinha e lhe falou com uma voz suave:

— Que temperamento, pequenina! Está com fome? Calma. Vou mandar preparar algo gostoso para você.

— Sanfu, entre.

Depois de receber vinte golpes de bastão por ter entrado sem bater, Sanfu finalmente aprendera as regras. Deu algumas batidas obedientes na porta e só entrou quando Lu Linyuan autorizou.

Assim que viu a gata nos braços do imperador, seu rosto mudou. — Ora! De onde saiu esse bicho? Xô! Xô daqui!

Ergueu o espanador cerimonial que trazia nas mãos e o lançou na direção do rosto de Ning Xiaoxiao.

Mas, antes que o espanador a atingisse, Lu Linyuan o arrancou das mãos dele e, num movimento de volta, bateu com ele na cabeça de Sanfu.

— Você tem a coragem de tocar na minha gata?

Sanfu: — ???

Ele ficou paralisado.

Seu senhor detestava cães e gatos, sobretudo os gatos. Além de soltar pelos, caçavam ratos e os comiam. Para Lu Linyuan, que tinha verdadeira mania de limpeza, aqueles animais eram um desastre ambulante.

Antes, quando algum gato de rua entrava no Palácio Chaoyang, Lu Linyuan sempre repreendia Sanfu por negligência no serviço. Às vezes, até aplicava um pequeno castigo.

Mas hoje era diferente. Não só segurava uma gata no colo, como proibia que a expulsassem e dizia que ela lhe pertencia!

Antes que Sanfu se recuperasse do espanto, Lu Linyuan ordenou: — Vá capturar dois ratos. Quero alimentar minha gata.

Ning Xiaoxiao: — Miau???

Sanfu: — Ah... Majestade... O senhor está falando sério?

Lu Linyuan lançou-lhe um olhar cortante. Sanfu imediatamente deu um tapinha na própria boca e saiu às pressas para caçar ratos.

Depois que ele se afastou, Lu Linyuan acariciou delicadamente a pelagem sedosa de Ning Xiaoxiao e sorriu. — Pronto, minha linda. Logo vai ter carninha para comer.

Ning Xiaoxiao: — Miau, miau, miau?

【Carninha uma ova! Você não tinha mania de limpeza? Um cachorro comeu sua mania de limpeza?!】

Ela deu um impulso com as patas traseiras e saltou dos braços de Lu Linyuan, tentando fugir.

Mas o imperador foi mais rápido: agarrou a pele da nuca dela e a puxou de volta.

— Quer fugir? Entrou na minha câmara, então agora é minha gata.

Depositou Ning Xiaoxiao na cama imperial, ergueu as sobrancelhas na direção das cobertas estendidas e pronunciou uma única palavra em tom de ordem:

— Entre.

Ning Xiaoxiao: — Miau, miau, miau?

Lu Linyuan: — Entre debaixo das cobertas e aqueça minha cama.

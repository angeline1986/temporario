# Validação — capítulo 144

- **Fonte:** `novel_capitulos_121_a_180(20261103-233558).docx` — chinês tradicional, DOCX.
- **Limites:** parágrafos 1608 a 1687 do DOCX (base zero); o capítulo seguinte foi excluído.
- **Parágrafos não vazios:** 77, inclusive título.
- **Linhas de dados do cotejo:** 77.
- **Índices ausentes:** 0; **índices duplicados:** 0; **campos vazios:** 0.
- **Procedimento:** tradução literária diretamente do chinês, cotejo parágrafo a parágrafo e verificação automática de campos, limites, índices e pacote ZIP.
- **Limitação:** o pareamento estrutural e a revisão durante a tradução não são uma segunda auditoria linguística independente integral; portanto não asseguram ausência de pequenas divergências internas.

## Decisões editoriais

- A pelagem branca e a heterocromia azul/castanho da gata foram mantidas.
- O tratamento divertido e provocativo de Lu Linyuan decorre do fato de ele saber a identidade da gata, fato desconhecido por Ning.
- O animal 鱉 foi vertido como tartaruga de casco mole, sem confundi-lo com tartaruga terrestre.
- Os vinte golpes aplicados a Sanfu pelo ato anterior de entrar sem bater e os dois ratos pedidos foram preservados.
- A ordem final de aquecer a cama encerra o capítulo, sem antecipar acontecimentos do seguinte.

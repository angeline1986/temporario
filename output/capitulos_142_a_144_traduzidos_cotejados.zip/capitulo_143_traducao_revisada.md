# Capítulo 143 — Socorro! Xiaoxiao virou uma gatinha!

Manipular o documento dentro da mente era mais ou menos como usar um computador: era preciso controlar um cursor e deslizá-lo pela interface.

Ao examinar o documento, Ning Xiaoxiao espirrou no mundo real. A versão dela dentro da mente também teve um espasmo na mão e, para sua desgraça, apertou o botão.

Aquilo já acontecera antes, mas antes não existia a opção 【Possessão】, poxa vida!

Se apertasse por engano Pausar, Retroceder ou Modificar, não seria o fim do mundo.

Só que desta vez parecia ter feito uma besteira monumental.

Quando abriu os olhos, Ning Xiaoxiao ainda não sabia o que acontecera.

Sentia a cabeça pesada, como se estivesse deitada sobre alguma coisa dura.

Quando despertou de vez, percebeu que estava deitada sobre a neve acumulada num telhado. O vento gelado fazia sua cabeça zunir. Imediatamente, questionou Xiao Qi em pensamento.

【Xiao Qi? O que está acontecendo? Como fui parar em cima de um telhado?】

Xiao Qi: 【Ha, ha.】

Ning Xiaoxiao: 【Está rindo do quê? Estou falando com você! Como vou descer daqui de cima?】

A voz de Xiao Qi estava carregada de sarcasmo: 【É só gritar por socorro para alguém vir tirar você daí!】

Ning Xiaoxiao pigarreou e gritou a plenos pulmões:

— Miau~~

【Puta merda! O que foi isso?!】

De susto, deu um salto que a lançou a mais de dois metros de altura. Depois de aterrissar perfeitamente, baixou os olhos para as próprias mãos.

Que miaurda era aquela? Tinham virado patas?!

— Miau? Miauu!!! Miau, miau?!

【XIAO QI!!!! POR QUE EU SOFRI UMA MUTAÇÃO?!】

Xiao Qi: 【Que tal pensar no que você fez antes de sofrer essa “mutação”?】

As lembranças foram clareando. Um simples tremor de mão bastara para transformá-la num gato? Que absurdo!

【Ei, ei! Não dava para pôr um botão de confirmação antes da possessão? Que sistema mais malfeito!】

Xiao Qi respondeu com frieza: 【Ah, você é muito cuidadosa. Tão cuidadosa que conseguiu se transformar num gato. Se sua mão tivesse tremido só um pouquinho mais e tocado no botão ao lado, você teria virado o porco do qual estão prestes a fazer churrasco na cozinha imperial. Aí sim teria sido uma maravilha de cuidado!】

Ning Xiaoxiao: 【Ai, eu não fiz de propósito! Anda, me transforme de volta!】

Xiao Qi: 【Impossível... Uma vez feita a possessão, você precisa ficar no corpo escolhido durante 24 horas inteiras antes de voltar automaticamente. Já que aconteceu, aproveite a vida felina, anfitriã. Tchauzinho!】

Dito isso, o sistema se desconectou imediatamente, sem se dispor a ouvir sequer uma reclamação dela.

A elegante gata persa fechou os olhos, ficou na ponta das patinhas à beira do beiral e deixou o vento gelado açoitar sua pelagem espessa. Em meio àquela desolação, passou a questionar o sentido da vida de gata.

Olhou para o chão, sete ou oito metros abaixo. Estendeu uma pata felpuda, arranhou o ar e a recolheu.

Buááá...

Era alto demais...

Não tinha coragem de pular...

Miau~

【Deixa pra lá. Vou me virar aqui no telhado esta noite. Se bem me lembro, cliquei num gato persa, todo fofinho e bonito. E se eu pular e algum gato macho tentar fazer safadezas comigo? Como vou encarar as pessoas depois? Buááá~】

Mas, ao ar livre, o inverno era terrivelmente frio.

Embora estivesse coberta de pelos, nem isso bastava para protegê-la do vento naquele telhado completamente exposto.

Caminhando com leveza sobre a neve fofa, percebeu de repente que num ponto do telhado a camada de neve era mais fina. Aproximou-se cautelosamente.

【Hein? Parece estar um pouquinho quente aqui?】

Os telhados do palácio imperial eram cobertos de telhas vitrificadas, que podiam ser deslocadas com facilidade.

Com as patinhas, afastou duas telhas. Pretendia aproveitar o calor que subia do cômodo e assim sobreviver à noite.

Mas, ao abrir a fresta, deparou-se com uma vista daquelas.

Aquele não era um telhado qualquer: era o da câmara de dormir do Palácio Chaoyang!

E, bem debaixo dela, estava Lu Linyuan, completamente nu dentro de uma banheira.

As velas lançavam uma luz amarelada e insinuante pelo quarto.

Entre vapores e névoa, o tronco nu de Lu Linyuan surgia acima da água. Gotas brilhavam em seus músculos peitorais e abdominais bem definidos, escorrendo lentamente pelos contornos do corpo.

De olhos fechados, ele se recostava na borda da banheira, aparentemente descansando.

Ning Xiaoxiao admirou a cena por uns instantes, mas logo desviou o olhar.

Não, não! Sou uma moça! Como posso espiar um homem tomando banho?

Mas queria tanto olhar!

Ela já admitira ser uma tarada de primeira. Qual era o problema de apreciar um bonitão no banho?

Então começou a encontrar desculpas para si mesma:

【Espera aí. Agora sou uma gata, não uma pessoa! Por que ficar com vergonha?】

【Não sou eu que quero espiar! É a gata!】

Quando estava prestes a se deleitar com aquela visão, uma das telhas sob suas patas virou sem que ela percebesse.

Seu corpinho “delicado” despencou com um “miau” e caiu bem no meio da banheira, espalhando água para todo lado.

Depois de passar a noite inteira fazendo espacate, Lu Linyuan só queria relaxar num banho. Que diabo de coisa acabara de cair do céu dentro da água?!

Ning Xiaoxiao não sabia nadar, e os gatos, por natureza, também costumam temer água.

Agitou as patinhas freneticamente na banheira e, esquecendo-se de que agora era uma gata, tentou desesperadamente agarrar alguma coisa.

Ao abrir e fechar as garras, quase agarrou por acidente o famoso “21”.

Felizmente, Lu Linyuan foi rápido: antes que ela conseguisse usar as garras, pescou a gata encharcada para fora da água.

Ning Xiaoxiao engolira água e soltou vários miaus entrecortados e engasgos. Ao recuperar os sentidos, percebeu que Lu Linyuan a encarava com seu olhar caracteristicamente ameaçador.

Ele não era propriamente compassivo, tampouco gostava de pequenos animais. Muito menos de uma criatura que caíra na sua banheira e quase atacara seu “pequeno Lu Linyuan”!

Enrolando uma toalha em torno do corpo com uma mão, segurou Ning Xiaoxiao pela pele da nuca com a outra e se preparou para jogá-la para fora.

Mas então uma voz familiar ecoou de repente em sua mente:

【Ai, meu Deus! Estou toda molhada! Se ele me jogar na neve assim, não vou virar um picolé? Socorro...】

Lu Linyuan franziu a testa e ergueu a gatinha até a altura dos olhos para examiná-la.

— Miau~ Miaaau~~

A gatinha soltou dois miados adoráveis e encostou a cabeça na palma da mão que a segurava, esfregando-se nela.

【Vou fazer cara de fofinha! Imperador cachorro, tenha piedade e me deixe ficar aqui!】

Ao ouvir as palavras “imperador cachorro”, Lu Linyuan teve certeza: aquela gata era a transformação da mulher maluca!

Desde que conhecera Ning Xiaoxiao, seu coração já fora treinado para suportar absurdos.

Por mais inacreditável que fosse uma situação, se envolvesse Ning Xiaoxiao, ele a aceitava rapidamente.

【Que diabos essa maluca está aprontando agora?】

Lu Linyuan olhou para o telhado e apertou um pouco mais a pele da nuca de Ning Xiaoxiao.

【Será que achou inconveniente ser humana e resolveu virar gata para me espiar tomando banho?】

Ora, ora... Interessante.

Já que você quer brincar, vou brincar direitinho com você.

Trouxe a gatinha para junto do peito, acariciou com o polegar seu narizinho rosado e lhe lançou um sorriso perversamente sedutor, como se estivesse flertando.

— Eu adoro gatinhos~

Ning Xiaoxiao: — Miau, miau, miau?!

【Socorro! Como é que ele consegue ser tão cafona e pegajoso até com uma gata?!】

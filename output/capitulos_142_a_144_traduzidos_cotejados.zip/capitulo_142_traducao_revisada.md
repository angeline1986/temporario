# Capítulo 142 — A função de possessão é desbloqueada

Se existissem níveis de vergonha alheia, Lu Lin-azar teria acabado de atingir o nível máximo de idiotice.

E o pior é que não podia se levantar. Caso contrário, seu augusto traseiro ficaria exposto ao público outra vez.

Sanfu já estava habituado às extravagâncias do amo. Hoje, pelo visto, Sua Majestade apenas inventara mais uma novidade para ampliar seus horizontes.

Mas, para a imperatriz, era diferente.

Aos olhos dela, Lu Linyuan era um homem imponente, vigoroso e majestoso, um soberano que dominava tudo sob o céu, um dragão a voar pelos nove firmamentos.

E, no entanto, para alegrar a pessoa que amava, ele era capaz de se rebaixar àquele ponto?

Então era assim que se revelava a diferença entre amar e não amar.

Uma onda de amargura invadiu o coração da imperatriz. Seus olhos arderam e ela retorceu o lenço entre os dedos, esforçando-se para não chorar.

Aos olhos de Lu Linyuan, porém, aquela resistência não passava de falta de bom senso.

— A porta do Palácio Chaoyang é enfeite para vocês dois? Fora daqui! E apresentem-se para receber a punição!

Por mais injustiçada que se sentisse, a imperatriz não esqueceu sua posição. Fez uma reverência respeitosa a Lu Linyuan. — Esta consorte reconhece seu erro. Que Vossa Majestade acalme sua ira.

Dito isso, saiu sem olhar para trás.

Sanfu percebeu que ela estava abalada e correu para alcançá-la. Interceptou-a no pátio. — Não leve a mal, Vossa Majestade Imperial. O imperador... Ai, a culpa é toda deste servo.

Deu um tremendo tapa no próprio rosto antes de prosseguir: — Achei urgente a notícia de que a imperatriz-viúva havia desmaiado de fome, então trouxe Vossa Majestade sem anunciar nossa chegada. Fui imprudente e acabei fazendo a senhora ser repreendida.

A imperatriz não o censurou. Pelo contrário, sorriu. — Não precisa se culpar. Eu também não pensei direito e interrompi um momento agradável do imperador. Pelo que vi, hoje é a Nobre Dama Hua quem o acompanha à noite. Não se sabe quando ele estará livre. Vou primeiro ao Palácio Shoukang cuidar da imperatriz-viúva. Quando tiver oportunidade, informe a situação dela ao imperador. Afinal, são mãe e filho. Que rancor entre eles precisaria durar até amanhã?

Sanfu concordou repetidas vezes e a acompanhou até a saída do Palácio Chaoyang. Não viu que, assim que ela lhe virou as costas, o sorriso se congelou.

No lugar dele surgiu um ódio impossível de esconder nos olhos.

*

No salão principal.

Lu Linyuan já fizera espacate e cantara, mas continuava de pernas abertas no chão, sem demonstrar qualquer intenção de se erguer.

— Você ainda não vai embora?

Ning Xiaoxiao o viu imóvel e temeu que ele tivesse sofrido uma cãibra de tanto forçar o espacate. Num raro acesso de bondade, ofereceu: — Majestade, o chão está frio. Já faz o tempo de queimar um incenso inteiro que o senhor está nessa posição. Quer que esta concubina o ajude a levantar?

— Não precisa! — Lu Linyuan afastou-lhe a mão com um gesto meio rígido. — Sei me levantar sozinho! Vá procurar um canto fresco e me deixe em paz!

As mudanças repentinas de humor do tirano já faziam parte da rotina de Ning Xiaoxiao. Afinal, ela já conquistara seus pontos de desvio da trama. Se ele queria que ela fosse embora, iria, ué!

Acenou para Lu Linyuan, desejou-lhe boa-noite e saiu.

Lu Linyuan espiou na direção da porta. Só depois de vê-la deixar o salão foi que se apoiou com uma mão no braço de uma cadeira e a outra no pé da mesa para, com grande dificuldade, ficar de pé.

Mal conseguira se equilibrar quando ouviu a porta ranger outra vez.

【Droga! Eu devia ter soldado os portões do Palácio Chaoyang e jogado a chave fora!】

Ning Xiaoxiao empurrou a porta, resmungando: — Majestade, deixei cair meu brinco. Voltei para procurá-lo... Hein?

Diante de seus olhos, Lu Linyuan executou mais um espacate perfeitamente fluido.

— Ma-Majestade... O que está fazendo? — ela gaguejou.

— E o que você tem com isso? Faço o que bem entender!

— Estou confortável assim. Resolvi fazer espacate por mais um tempo...

— Achou seu brinco? Então vá logo! Se continuar me incomodando, vai levar uns cascudos!

Enquanto Ning Xiaoxiao procurava o brinco, Lu Linyuan quase sentiu vontade de dar um tapa em si mesmo.

Ele já estava de pé. Para não deixar que ela visse a roupa rasgada entre as pernas, bastava sentar-se no trono, não bastava?

【Por que diabos resolvi fazer outro espacate?】

【É verdade: passar tempo demais com uma idiota faz a inteligência da gente cair.】

【Hein? Por que ela está vindo cada vez mais para perto?】

【O que pretende fazer?】

— Vo-você! Pare aí!

Quando Lu Linyuan a deteve, Ning Xiaoxiao já estava a menos de um zhang — cerca de três metros —, olhando fixamente para a região entre suas pernas.

— Para... para onde está olhando?

— Majestade... Meu brinco está preso debaixo da sua coxa, bem na virilha... — Ning Xiaoxiao apontou para a raiz da coxa dele, inclinando o corpo inteiro para a frente. — Será que o senhor não pode fazer espacate em outro lugar? Assim que eu pegar o brinco, vou embora!

— Não vou mudar de lugar! A... a vista daqui é ótima!

Seu constrangimento já estava prestes a transbordar para fora da tela. Com as mãos enormes e atrapalhadas, apalpou a própria virilha à procura do brinco. Quando o encontrou, ainda espetou o dedo no pino da joia. Era mesmo um azarado de marca maior.

Atirou o brinco para Ning Xiaoxiao. — Pegue! E SUMA DAQUI!!!!

Ning Xiaoxiao não fazia ideia de que doença o acometera. Com medo de que ele enlouquecesse e a mordesse, saiu voando dali.

Quando voltou ao Palácio Zhongcui, já era tarde da noite.

Depois de se lavar, estava pronta para uma ótima noite de sono, quando a voz de Xiao Qi surgiu em sua mente:

【Bip, bip, bip! Parabéns, anfitriã! Você concluiu a missão “Fazer o tirano cantar Conquista enquanto executa um espacate”. A missão rendeu 6 pontos percentuais de desvio da trama, elevando o índice acumulado para 26%. Como o índice ultrapassou um quarto do total, o sistema desbloqueou a função “Possessão”.】

Ning Xiaoxiao: 【Possessão? O que isso quer dizer?】

Xiao Qi: 【Essa função foi criada principalmente para melhorar sua experiência dentro do livro! Uma vez por mês, a anfitriã poderá possuir outro personagem da obra por um dia. Em termos simples, a alma do alvo será selada à força e você entrará no corpo dele, assumindo sua identidade por um dia.】

Ning Xiaoxiao levara ao extremo o princípio de aceitar as circunstâncias como vinham. Se não podia voltar para casa antes de terminar a trama, era melhor aproveitar aquela vida sem limites, na qual podia fazer as maiores loucuras sem sofrer punições legais!

Antes, ouvir falar de uma função tão absurda provavelmente a faria reclamar. Agora, só conseguia ficar empolgada.

【Então é uma espécie de incorporação? Nossa, que divertido! Posso possuir qualquer pessoa? Até aquele imperador cachorro?】

Xiao Qi riu com malícia: 【Hehe! Os protagonistas masculino e feminino não podem ser possuídos!】

Ah, qual é! Seu entusiasmo, que acabara de atingir o auge, despencou imediatamente.

Ela planejava possuir o tirano, convocar todas aquelas desgraçadas do harém e distribuir uns bons tapas em cada uma, só pelo prazer de fazê-lo.

Fechou os olhos e abriu o documento mental. Na parte inferior, além dos botões 【Retroceder】, 【Modificar】 e 【Pausar】, surgira um novo: 【Possessão】.

Sem perder tempo, clicou em 【Possessão】. Havia tantos personagens disponíveis que ela ficou tonta só de olhar.

Em resumo, podia se transformar em quem quisesse, exceto Lu Linyuan e Gu Sijin.

Continuou rolando o documento e então encontrou algo ainda mais absurdo.

【Xiao Qi, por que tem cães e gatos nessa lista? Também posso virar um deles?】

Xiao Qi: 【Hm... E por que não poderia? Ei, não! Anfitriã, não fique clicando aleatoriamente! Se clicar, vai se transformar na hora... Ai, meu Deus...】

O sistema assistiu, impotente, enquanto aquela curiosa — fosse por um tremor na mão ou por falta de juízo — tocava na opção “gato persa” escondida num canto.

E, num instante, ela desapareceu sem deixar vestígios...

# Validação — capítulo 143

- **Fonte:** `novel_capitulos_121_a_180(20261103-233558).docx` — chinês tradicional, DOCX.
- **Limites:** parágrafos 1524 a 1607 do DOCX (base zero); o capítulo seguinte foi excluído.
- **Parágrafos não vazios:** 81, inclusive título.
- **Linhas de dados do cotejo:** 81.
- **Índices ausentes:** 0; **índices duplicados:** 0; **campos vazios:** 0.
- **Procedimento:** tradução literária diretamente do chinês, cotejo parágrafo a parágrafo e verificação automática de campos, limites, índices e pacote ZIP.
- **Limitação:** o pareamento estrutural e a revisão durante a tradução não são uma segunda auditoria linguística independente integral; portanto não asseguram ausência de pequenas divergências internas.

## Decisões editoriais

- A duração da possessão é de 24 horas, sem possibilidade de reversão antecipada segundo Xiao Qi.
- O medo de descer do telhado e o medo de água são experiências da protagonista no corpo de gata.
- A referência íntima recorrente “21” foi conservada sem substituição de natureza.
- Lu Linyuan reconhece Ning Xiaoxiao pelos pensamentos, sobretudo pelo insulto “imperador cachorro”, não apenas pelo comportamento felino.
- A frase “não sou eu que quero olhar; é a gata” preserva a desculpa humorística interna da protagonista.

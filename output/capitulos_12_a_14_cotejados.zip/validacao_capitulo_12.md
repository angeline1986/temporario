# Relatório de conferência bilíngue — Capítulo 12

**Fonte primária:** DOCX chinês tradicional anexado em 03/11/2026.

**Fonte de tradução revisada:** `capitulo_12_traducao.md` do trabalho anterior.

- Unidades textuais não vazias do capítulo no DOCX, incluindo título: **64**.
- Unidades correspondentes com tradução em português: **64**.
- Unidades sem tradução: **0 na correspondência estabelecida**.
- Índices de parágrafo DOCX cobertos: **863–928**, incluindo apenas parágrafos não vazios.
- Tradução dividida em **83 blocos**; alguns blocos se agrupam para uma unidade chinesa, sem eliminação de texto.

## Inspeção linguística

Foi feita uma comparação capítulo a capítulo das unidades do original e da tradução anterior, examinando sequência narrativa, personagens, negações, ações, falas, números e humor. A tabela CSV documenta o alinhamento, preservando o índice de cada parágrafo DOCX.

## Observações e decisões

- O original especifica seis sementes por pessoa, de vinte a trinta para Ning, e uma quantia equivalente a um ano de soldo; informações preservadas.
- Cailian planeja incriminar Ning; Ning antecipa a armação; Gu Sijin perdoa Cailian. Sujeitos e ordem causal preservados.
- Os quatro nomes Qiqi, Qiaqia, Bengbeng e Lala seguem a romanização do texto anterior; o chinês apresenta grafia variável de Qiaqia (恰恰/洽洽).

## Conclusão e limites

**Cotejo bilíngue concluído no nível das 64 unidades do capítulo.** Não se encontraram lacunas de unidades na tradução alinhada. A auditoria é uma conferência editorial humana-assistida e não prova infalibilidade de cada interpretação; comentários de incerteza editorial constam acima.

# Relatório de conferência bilíngue — Capítulo 14

**Fonte primária:** DOCX chinês tradicional anexado em 03/11/2026.

**Fonte de tradução revisada:** `capitulo_14_traducao.md` do trabalho anterior.

- Unidades textuais não vazias do capítulo no DOCX, incluindo título: **70**.
- Unidades correspondentes com tradução em português: **70**.
- Unidades sem tradução: **0 na correspondência estabelecida**.
- Índices de parágrafo DOCX cobertos: **1010–1081**, incluindo apenas parágrafos não vazios.
- Tradução dividida em **80 blocos**; alguns blocos se agrupam para uma unidade chinesa, sem eliminação de texto.

## Inspeção linguística

Foi feita uma comparação capítulo a capítulo das unidades do original e da tradução anterior, examinando sequência narrativa, personagens, negações, ações, falas, números e humor. A tabela CSV documenta o alinhamento, preservando o índice de cada parágrafo DOCX.

## Observações e decisões

- Corrigida a tradução de 鐵樹開花: ‘a cica da casa dele floresceu’, em vez de ‘árvore-da-felicidade’, espécie diferente.
- O texto distingue pensamentos de Ning e conversas com o sistema: o imperador não ouve as conversas com Xiao Qi.
- Mantidas as trinta mil unidades de prata, o nome Wei Yan, os três minutos de retrocesso e a repetição proposital da leitura do memorial.
- A expressão jocosa 痔瘡見 foi preservada como brincadeira com hemorroidas; o jogo sonoro original não é plenamente transferível.

## Conclusão e limites

**Cotejo bilíngue concluído no nível das 70 unidades do capítulo.** Não se encontraram lacunas de unidades na tradução alinhada. A auditoria é uma conferência editorial humana-assistida e não prova infalibilidade de cada interpretação; comentários de incerteza editorial constam acima.

# Validação — capítulo 222

- **Fonte:** `novel_capitulos_212_a_270(20261105-204944).docx`, original chinês tradicional.
- **Limites no DOCX:** índices de parágrafo 729 (título) a 803 (imediatamente antes do próximo título), base zero.
- **Parágrafos não vazios:** 72; cada um incluído no cotejo, inclusive título e marcadores/notas autorais.
- **CSV:** cabeçalho exato `indice_docx,original_chines,traducao_portugues`; codificação UTF-8 com BOM para compatibilidade; índices reais de parágrafos do DOCX.
- **Verificação automática:** ausência de índices repetidos, campos de tradução vazios e parágrafos não vazios sem correspondência.
- **Decisões editoriais:** Especial de Qixi (Qingyang e Huanü). Mantidas a insinuação de intimidade no acampamento, a referência metalinguística a meme, os emojis, os tratamentos de nobreza e a homenagem aos pais. O horário de 亥時 foi apresentado de modo aproximado, como no original.
- **Limites:** a cobertura estrutural 1:1 e as verificações automatizadas não constituem uma segunda auditoria semântica independente integral. Tradução literária realizada com revisão editorial, mas passível de ajustes pontuais.

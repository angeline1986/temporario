# Capítulo 223 — Especial de Qixi: a mulher dominante × a garota meiga (2)

— Princesa mais velha, o que está fazendo?

Huanü ficou espantada e se levantou depressa, tentando ajudar Qingyang a ficar de pé:

— Princesa, não pode fazer isso! Você...

Qingyang colocou a mão no ombro dela, impedindo-a de se levantar.

— Aqui, com estas portas fechadas, não sou a princesa mais velha da dinastia Qi. Sou a pessoa a quem você pode confiar o resto da sua vida.

— Mas...

Huanü ainda queria protestar, mas, ao ver Qingyang oferecer o incenso no altar, sua voz foi ficando cada vez mais baixa.

O poder imperial estava acima de tudo. E quem desconhecia o orgulho de Qingyang?

Ela nem sequer dava importância à imperatriz-viúva e era capaz de esbofetear a imperatriz. Quando esteve no reino de Zhuyin, todos se ajoelhavam diante de seu soberano; Qingyang, porém, nem mesmo se dispunha a uma inclinação de cabeça por mera formalidade.

No coração de Qingyang, mulheres deveriam ter o mesmo status que homens.

A dignidade de uma filha não era menor que a de um filho: podia curvar-se diante do céu e da terra e ajoelhar-se diante dos próprios pais.

E, ainda assim, aquela mulher estava agora ajoelhada diante dos pais de Huanü.

Aquele gesto só podia significar que o amor por Huanü se estendia a tudo que lhe dizia respeito: em seu coração, Qingyang já considerava a família dela como sua própria família.

Curvou-se diante das tabuletas memoriais e declarou em voz grave:

— Pai, mãe, por minha causa, Mohua ficou presa no palácio e não pôde cuidar de vocês durante a doença nem cumprir os deveres de uma filha. Toda a culpa é minha.

— Vocês só tinham uma filha, Mohua. O último desejo de vocês certamente era que ela pudesse viver bem.

— Podem ficar tranquilos. De agora em diante, tudo o que existir neste mundo, se ela desejar, eu lhe darei.

— Enquanto eu viver, ninguém mais ousará maltratar Mohua. Peço que aceitem mais uma reverência minha.

Cada palavra era sincera. Não falava apenas para Huanü ouvir: era assim que Qingyang sempre havia agido.

Durante os incontáveis dias e noites em que fora obrigada a partir para um casamento político, não teria ela sofrido tanto quanto Huanü?

Se não fosse pela saudade que sentiam uma da outra, alguém com a personalidade de Qingyang preferiria tirar a própria vida a continuar vivendo daquela maneira.

Quando terminaram de prestar homenagem aos pais de Huanü, já estava completamente escuro.

As pessoas encarregadas de cuidar do lugar prepararam-lhes o jantar: apenas um mingau simples de painço e um prato de verduras silvestres refogadas.

Ao observar a comida tão singela sobre a mesa, Huanü sentiu o coração se apertar.

Certa vez, Qingyang lhe perguntara qual era a comida mais deliciosa do mundo.

Ela respondera que era o mingau de painço de sua terra natal, acompanhado das verduras silvestres típicas dali.

Uma observação casual que Qingyang, afinal, guardara silenciosamente na memória por todo esse tempo.

O vento do campo tinha um aroma muito particular.

Misturava o perfume das flores e frutas ao leve cheiro de forragem, transmitindo uma sensação de segurança, uma paz difícil de pôr em palavras.

Durante o jantar, Qingyang contou a Huanü:

— Aquele valentão que atormentava toda a região, uma única maçã podre que estragava o resto, já recebeu de mim o castigo merecido: mandei arrancar-lhe a pele e os ossos, e toda a sua família foi exilada para a fronteira. Os aldeões que você viu cuidando daqui não aceitaram meu dinheiro. Fizeram tudo por vontade própria.

Olhou ao longe, para os moradores que ainda trabalhavam nos campos, e sorriu com doçura.

— Gosto muito dos costumes daqui. Não há essas intrigas e disputas intermináveis. As pessoas se relacionam de forma tão simples e sincera.

— Quando voltarmos da estância de águas termais, a mansão da princesa na capital ainda precisará de algum tempo para ficar pronta. Sei que você não gosta de agitação, então pensei que poderíamos nos mudar para cá e viver uma vida tranquila, longe das preocupações do mundo.

As maquinações e disputas sem fim do palácio eram realmente desgastantes. Enquanto Qingyang estivera ausente, Huanü sofrera inúmeros insultos, olhares de desprezo e castigos físicos.

Para ela, aquele lugar nem sequer merecia o nome de gaiola dourada. Era o próprio inferno na terra, apenas revestido por uma camada de ouro.

Mas, se Qingyang estivesse ao seu lado, até o inferno poderia parecer doce.

Huanü pousou os hashis e usou seu próprio lenço de seda para limpar delicadamente o canto da boca de Qingyang. — Na verdade, não importa onde moremos. O importante é que eu possa ficar sempre ao seu lado, princesa. Viver na capital também não seria ruim. Estaríamos perto de Sua Majestade e dos demais, e poderíamos visitá-los com frequência.

Ela sorriu. — Até gosto bastante da Concubina Hua. Ela não tem nenhuma pose de consorte imperial. Ontem, durante o trajeto, veio brincar conosco com aquele jogo... Ah, sim, baralho! Hahaha! Ela tem tantas ideias divertidas. Não é à toa que o imperador gosta dela.

Lembrando-se de Ning Xiaoxiao, Qingyang também abriu um sorriso. — Sim. Ela é diferente daquelas mulheres que parecem ter sido criadas dentro de potes de maquiagem. Gostei dela desde a primeira vez que a vi.

Ao ouvir aquilo, Huanü não gostou nem um pouco.

Seu sorriso congelou. Ela soltou um resmungo: — Pensando bem... ela nem é tão diferente assim...

— Hahahaha! Ora, ora, de quem é esse pote de ciúmes que acabou de virar?

Qingyang deu uma gargalhada e cutucou a testa dela. — Estou só brincando. Se houvesse alguém neste mundo melhor que você, eu não teria acabado completamente rendida aos seus encantos.

— Princesa mais velha! Princesa, você está aí?

Bastou falar no diabo para ele aparecer.

Ning Xiaoxiao chamou duas vezes do lado de fora. Qingyang e Huanü trocaram um sorriso e abriram a porta.

Ao vê-la de bochechas infladas e fazendo bico de irritação, Qingyang perguntou: — O que foi, pequenina? Quem a deixou brava?

— Quem mais poderia ser? O imperador, claro...

Ning Xiaoxiao entrou e se jogou numa cadeira de madeira como um balão murcho, suspirando profundamente.

— Ele está bebendo no nosso quarto com o general Ren e o príncipe Jing. Eu disse que também podia beber, mas eles não deixaram e ainda me expulsaram... Não conheço ninguém por aqui e nem sei aonde ir. Só me restou procurar vocês...

— Expulsaram você? — Qingyang arqueou a sobrancelha e adotou uma expressão sugestiva. — Esse imperador, francamente... Convida os outros para beber sem nem perguntar se eles querem beber com ele. Se Yiqiu e Ren Duanli exagerarem na bebida, podem acabar atrapalhando os assuntos particulares que pretendiam resolver à noite.

Ning Xiaoxiao, que era a maior torcedora daquele casal, ficou imediatamente com os olhos brilhando. — PRINCESA!!! Você também percebeu?!

Qingyang sorriu. — Só um idiota não perceberia.

Huanü, que fora buscar água para Ning Xiaoxiao, voltou e entrou também na conversa. — O Pixiu do general Ren não deixa nem o imperador encostar nele, mas o príncipe Jing pode montá-lo à vontade e passear por aí como se fosse o dono. Hoje vi o príncipe até dar um nó na cauda de Pixiu! E o animal foi tão paciente com ele... Parece gostar muito dele de verdade.

Ning Xiaoxiao respondeu com um tom carregado de insinuação: — Vai ver o dono também gosta~

As três se entreolharam e desataram a rir ao mesmo tempo.

Quando os homens começavam a beber, perdiam completamente a noção do tempo. Ning Xiaoxiao só pôde se distrair jogando baralho com Qingyang e Huanü.

Mas as duas tinham viajado o dia inteiro e precisavam descansar, não é mesmo?

Depois de aproximadamente duas horas, Huanü já bocejava sem parar.

Ning Xiaoxiao não queria incomodá-las e estava prestes a se despedir quando Sanfu apareceu.

— Ah, então Vossa Senhoria está aqui! O imperador e o general Ren já terminaram de beber e Sua Majestade está procurando a senhora com urgência.

Ning Xiaoxiao revirou os olhos. — Agora que terminou de beber, lembrou que eu existo? Ah, claro! Só depois que a criança morre ele aparece para amamentá-la! Só se lembra de limpar o nariz quando a meleca já chegou à boca! Vá dizer a ele que hoje vou dormir aqui, com a princesa mais velha!

Princesa mais velha e Huanü: “???” NÃO, OBRIGADA!!

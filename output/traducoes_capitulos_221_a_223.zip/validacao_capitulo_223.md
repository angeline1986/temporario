# Validação — capítulo 223

- **Fonte:** `novel_capitulos_212_a_270(20261105-204944).docx`, original chinês tradicional.
- **Limites no DOCX:** índices de parágrafo 804 (título) a 871 (imediatamente antes do próximo título), base zero.
- **Parágrafos não vazios:** 65; cada um incluído no cotejo, inclusive título e marcadores/notas autorais.
- **CSV:** cabeçalho exato `indice_docx,original_chines,traducao_portugues`; codificação UTF-8 com BOM para compatibilidade; índices reais de parágrafos do DOCX.
- **Verificação automática:** ausência de índices repetidos, campos de tradução vazios e parágrafos não vazios sem correspondência.
- **Decisões editoriais:** Continuação do especial de Qixi. Mantida a identidade 茉花 (Mohua), usada na fala íntima de Qingyang para Huanü, sem trocar automaticamente os nomes. Preservadas as falas sobre a violência da represália ao valentão, a referência a baralho, o humor do casal e as exclamações finais em tom de meme. A expressão 達咩 foi adaptada pelo efeito de rejeição enfática.
- **Limites:** a cobertura estrutural 1:1 e as verificações automatizadas não constituem uma segunda auditoria semântica independente integral. Tradução literária realizada com revisão editorial, mas passível de ajustes pontuais.

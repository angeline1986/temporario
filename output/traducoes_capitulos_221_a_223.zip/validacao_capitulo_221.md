# Validação — capítulo 221

- **Fonte:** `novel_capitulos_212_a_270(20261105-204944).docx`, original chinês tradicional.
- **Limites no DOCX:** índices de parágrafo 653 (título) a 728 (imediatamente antes do próximo título), base zero.
- **Parágrafos não vazios:** 73; cada um incluído no cotejo, inclusive título e marcadores/notas autorais.
- **CSV:** cabeçalho exato `indice_docx,original_chines,traducao_portugues`; codificação UTF-8 com BOM para compatibilidade; índices reais de parágrafos do DOCX.
- **Verificação automática:** ausência de índices repetidos, campos de tradução vazios e parágrafos não vazios sem correspondência.
- **Decisões editoriais:** Especial de Qixi (Ren Duanli e Lu Yiqiu). Mantidos Pixiu, Xiaozhu como designação dos vaga-lumes, o apelido Xiao Lili, o contraste entre a fala fria e o cuidado do general e a nota autoral final sobre atualizar a página. O termo chinês 少女心 foi adaptado por seu efeito afetivo, sem atribuir um sentido literal inexistente.
- **Limites:** a cobertura estrutural 1:1 e as verificações automatizadas não constituem uma segunda auditoria semântica independente integral. Tradução literária realizada com revisão editorial, mas passível de ajustes pontuais.

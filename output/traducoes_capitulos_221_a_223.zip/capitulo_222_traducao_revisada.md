# Capítulo 222 — Especial de Qixi: a mulher dominante × a garota meiga (1)

Na quinta vigília da noite, Ren Duanli e Lu Yiqiu retornaram ao acampamento e encontraram Qingyang saindo da tenda usada como cozinha.

Ela carregava um prato de bolinhos de aparência pouco convidativa. Se um cozinheiro imperial apresentasse aquilo, seria caso de perder a cabeça; portanto, quase certamente ela mesma os havia preparado.

Lu Yiqiu ficou tão surpreso quanto se tivesse visto o sol nascer no oeste. — Uau! Irmã mais velha, você cozinhou?!

Desde pequena, Qingyang fora uma mulher extraordinária, que preferia as armas aos adornos femininos. Cozinhar, então, nem pensar. Nem nas festas de fim de ano, quando o falecido imperador pedia sua ajuda, ela concordava.

Mas que coisa surpreendente!

Ao notar que as luxuosas roupas de seda de Lu Yiqiu e Ren Duanli estavam cobertas por uma fina camada de umidade, além do evidente cansaço no rosto dos dois, Qingyang não conseguiu conter o riso:

— Yiqiu cresceu. Já conhece os prazeres de fazer certas coisas ao ar livre.

Ren Duanli: “???”

Lu Yiqiu: “!!!”

— Irmã! Que bobagem você está dizendo? Eu...

— O que você faz é problema seu. Agora que cresceu, não tenho vontade de me meter na sua vida. — Dito isso, ela lhe estendeu um bolinho. — Experimente e diga o que achou.

Lu Yiqiu se escondeu apavorado atrás de Ren Duanli. — Não, não! Você se esforçou tanto para preparar esses bolinhos... Como eu teria coragem de comê-los? Que mérito tenho eu para merecer uma iguaria feita por você? É melhor guardá-los e saboreá-los com toda a calma... Hum?!

A desvantagem de ser tagarela era que, com a boca abrindo e fechando sem parar, ficava muito fácil alguém enfiar qualquer coisa lá dentro.

Foi exatamente o que aconteceu: Qingyang perdeu a paciência com a falação e simplesmente enfiou o bolinho na boca dele.

O instinto de sobrevivência de Lu Yiqiu foi tentar cuspi-lo. Para sua surpresa, Ren Duanli cobriu-lhe a boca com a mão e declarou, com toda a seriedade:

— A princesa mais velha lhe concedeu comida. Cuspi-la seria desrespeitar uma autoridade superior.

Lu Yiqiu: “???” (Aqui vocês precisam contribuir com um meme de alguém que não fez nada para merecer isso.)

No fim, graças ao esforço conjunto dos dois, Lu Yiqiu não teve alternativa senão engolir aquele bolinho na marra.

Apesar da aparência pouco promissora, porém, o sabor era realmente delicioso!

Lu Yiqiu o elogiou sem parar e estendeu a mão para pegar outro.

Qingyang deu um tapa firme nas costas de sua mão. — Se quer comer, peça ao general Ren que faça para você.

Então, levando o prato, voltou para a própria tenda.

Lu Yiqiu lançou a Ren Duanli um olhar ressentido. — Minha irmã mandou você fazer para mim!

— Não faço.

— Minha irmã é a princesa mais velha! Se não obedecer às ordens dela, estará desrespeitando uma autoridade superior!

— Então vá prestar queixa às autoridades.

Lu Yiqiu: “(╬◣д◢)”

*

Quanto à pessoa para quem a princesa mais velha havia preparado aqueles bolinhos com as próprias mãos, nem era preciso dizer.

Quando a comitiva retomou a viagem, a princesa mais velha dividiu uma carruagem com Huanü.

Huanü passou o caminho inteiro dormindo. O motivo era simples: na noite anterior, ela e Qingyang haviam se divertido tanto juntas que a pobrezinha ficara exausta.

Inicialmente, Huanü adormecera apoiada na janela de madeira da carruagem. Vendo como aquela posição era desconfortável, Qingyang a deitou de comprido, com a cabeça repousando em seu colo, e ordenou ao cocheiro:

— Vá mais devagar. Nada de solavancos.

A ordem foi tão assustadora que o cocheiro quase preferiu dispensar os cavalos e puxar a carruagem com as próprias mãos...

A previsão original era percorrer uma distância maior naquele dia e parar apenas por volta da hora de Hai, pouco depois das nove da noite. Estimavam chegar então à cidade de Yunping.

Mas, durante uma pausa para descanso, a princesa mais velha foi falar com Lu Linyuan.

— Majestade, vamos parar mais cedo hoje. Dormi muito mal no acampamento ontem.

— Dormiu mal? — Lu Linyuan sorriu. — Pelo seu rosto radiante, irmã mais velha, eu pensaria que alguma coisa boa aconteceu.

Apesar da brincadeira, assim que soube o verdadeiro motivo de Qingyang querer parar antes, Lu Linyuan concordou sem hesitar.

Qingyang queria passar a noite em Minxiang, a cerca de quarenta li de Yunping.

E Minxiang era justamente a terra natal de Huanü.

Naquele dia, quando as carruagens finalmente pararam, Qingyang acordou Huanü.

Huanü esfregou os olhos sonolentos e, ao perceber que estava deitada no colo de Qingyang, ficou ao mesmo tempo aflita e comovida.

— Passei o caminho inteiro dormindo assim... Suas pernas devem estar dormentes, princesa...

Enquanto massageava as coxas de Qingyang, lamentou: — A culpa é minha. Hoje eu estava realmente cansada demais.

Qingyang sorriu e apertou de leve seu nariz. — A culpa é minha. Ontem à noite realmente fomos dormir muito tarde.

Huanü ficou vermelha e mudou imediatamente de assunto. — Chegamos a Yunping?

Ela abriu a janela da carruagem. Embora o céu já estivesse ficando cinzento com o cair da tarde, sentiu uma familiaridade difícil de explicar com a paisagem ao redor.

— Por que tenho a impressão de já ter estado aqui?

Qingyang apenas sorriu, sem responder. Desceu primeiro da carruagem e ajudou Huanü a descer.

Só então Huanü viu, na placa antiga e desbotada na entrada da aldeia, dois caracteres:

— Minxiang.

Ela ficou surpresa e encantada. — Como assim? Não tínhamos combinado passar a noite em Yunping? Como é que...?

— Venha comigo. — Qingyang segurou sua mão e a conduziu pelo caminho. Parecia conhecer o lugar melhor do que a própria Huanü, como se aquela fosse sua terra natal.

Os pais de Huanü haviam falecido, um depois do outro, anos antes. Segundo uma conterrânea que também servia no palácio, depois das mortes, a antiga casa da família fora tomada por um valentão famoso na região.

Mas, quando Qingyang a levou até a casa ancestral, Huanü ficou sem reação diante do que encontrou.

A residência continuava exatamente como antes, só que parecia nova, como se tivesse sido restaurada recentemente.

Duas senhoras idosas varriam a entrada, enquanto outras pessoas entravam e saíam da casa, dando-lhe um ar movimentado.

A princípio, Huanü supôs que fossem parentes do valentão. Mas, ao avistarem Qingyang, todos interromperam o trabalho, aproximaram-se e se ajoelharam respeitosamente diante dela.

Qingyang fez um gesto para que se levantassem e continuassem suas tarefas.

Só então Huanü perguntou: — Princesa, você conhece essas pessoas?

Qingyang a encarou com o olhar entristecido e fingiu irritação. — Você não deveria ter escondido de mim o que aconteceu com seus pais. Eu lhe disse: agora que voltei, ninguém neste mundo vai fazer você sofrer outra injustiça.

Segurou a mão de Huanü e entrou com ela na casa.

No centro da residência estavam as tabuletas memoriais dos pais de Huanü. As pessoas que entravam e saíam cuidavam da limpeza e das oferendas feitas diante delas.

Qingyang ordenou que todos se retirassem e fechassem as portas. Pegou bastões de incenso, acendeu-os e entregou três a Huanü, guardando outros três para si.

— Quando seus pais morreram, você não pôde estar ao lado deles nem cumprir seus deveres filiais. Sei que talvez esse seja o maior arrependimento da sua vida.

— Agora que estamos aqui, preste primeiro suas homenagens a eles.

As lágrimas brotaram imediatamente dos olhos de Huanü: por seus pais, com quem sentia ter uma dívida, e por tudo o que Qingyang fizera silenciosamente por ela.

Recebeu o incenso, ajoelhou-se diante das tabuletas memoriais dos pais, colocou as oferendas no altar e fez uma reverência profunda, chorando:

— Pai, mãe, fui uma filha ingrata. Sua filha veio visitar vocês...

De repente, a figura vestida de vermelho-vivo ao seu lado também se ajoelhou.

# Capítulo 221 — Especial de Qixi: o ingênuo × o grande general (2)

Durante todo o caminho, Ren Duanli não parou de bancar o durão.

De braços cruzados e com uma espada de jade branco presa à cintura, manteve o rosto impassível o tempo inteiro. Lu Yiqiu tagarelou sem parar durante a viagem, mas as respostas mais elaboradas que recebeu foram:

“Ah”, “Hum”, “Você tem razão” e “Se isso te faz feliz”.

Ele nem sequer se dignou a olhar para trás uma única vez...

Mais tarde, talvez por achar Ren Duanli insuportavelmente sem graça, Lu Yiqiu — falador e incapaz de deixar as mãos quietas — começou a brincar com a cauda de Pixiu...

Assim como os tigres, os leopardos também não gostam que mexam em suas caudas.

Pixiu soltou um rosnado de advertência, tão forte que espantou as aves da floresta nas montanhas e fez Lu Yiqiu começar de novo com seus gritos escandalosos.

Ren Duanli voltou a cabeça e lançou a Pixiu um olhar afiado, como se o advertisse a não assustar Lu Yiqiu.

Ofendidíssimo, Pixiu soltou um miado, abaixou a cabeça com resignação e deixou Lu Yiqiu dar um nó em sua cauda...

Na encosta intermediária do Vale dos Vaga-lumes ficava a nascente do riacho Qishui. Era também o único lugar de toda a dinastia Qi onde se podiam ver os vaga-lumes Xiaozhu no inverno.

Lu Yiqiu, que não tinha ficado calado um instante, arregalou os olhos e deixou o queixo cair diante daquele magnífico mar de estrelas. Foi Ren Duanli quem, delicadamente, fechou sua boca.

Disse que os Xiaozhu eram venenosos e que receava que algum entrasse voando na boca daquele idiota e acabasse engolido...

Naquela noite, o céu estava límpido. Uma lua crescente pendia na abóbada azul-escura, enquanto estrelas se espalhavam por toda parte como diamantes triturados.

Entre os arbustos envoltos em penumbra, incontáveis Xiaozhu pareciam estrelas caídas no mundo dos mortais. Voavam em bandos, cintilando suavemente e se deslocando na escuridão, até onde a vista alcançava.

Vistos à distância, formavam um rio de estrelas que parecia se unir ao firmamento, como se a Via Láctea tivesse sido puxada dos confins do céu até a terra.

Nem todos os elogios e palavras mais belas do mundo seriam capazes de descrever um centésimo daquele espetáculo de tirar o fôlego.

Até alguém tão frio e distante quanto Ren Duanli ficou fascinado por alguns instantes.

Lu Yiqiu escorregou das costas de Pixiu e correu para dentro do mar de luzes, saltitando de alegria como uma criança ansiosa para soltar fogos no Ano-Novo.

Acenou para Ren Duanli: — Xiao Lili! Venha brincar também!

— Não vou.

Ren Duanli encontrou uma árvore de tronco grosso e sentou-se no chão, apoiando as costas nela.

Os Xiaozhu daquele lugar pareciam não ter medo algum de pessoas.

Pousavam nas mangas de Lu Yiqiu, formando pequenos aglomerados que brilhavam como pérolas luminosas.

Ele correu para junto de Ren Duanli e estendeu o braço, exibindo a manga como uma criança orgulhosa de seu tesouro:

— Olha, olha! Não é lindo?

Ren Duanli franziu ligeiramente a testa e recuou de modo bastante perceptível. Com esforço, deixou escapar duas palavras entre os dentes: — É lindo...

Lu Yiqiu percebeu seu desconforto. — Xiao Lili tem medo de insetos?

— Medo disso? — Ren Duanli riu com desdém. — Não existe nada neste mundo que me dê medo.

— É mesmo?

Quase ao mesmo tempo que pronunciava essas palavras, Lu Yiqiu aproximou ainda mais a manga de Ren Duanli, de propósito.

A reação dele foi imediata: levantou-se num salto e se afastou de Lu Yiqiu.

Era a primeira vez que Lu Yiqiu via o imperturbável general Ren reagir com tamanha intensidade. Por isso, não resistiu à provocação:

— Quem diria! Nosso grande general Ren, que não teme nem o céu nem a terra, coberto de glórias militares e que matou incontáveis inimigos, tem medo de uns insetinhos?

Ele tocou delicadamente com a ponta do dedo o traseiro de um Xiaozhu. Sua luz ficou ainda mais intensa e a criaturinha, assustada, bateu as asas e voou.

— Ele é tão bonito! Por que você tem medo?

— Os Xiaozhu vivem muito pouco. Que importância tem serem belos e brilhantes? Sua beleza dura só um instante. Como tantas coisas boas deste mundo, não há como fazê-la permanecer.

Ren Duanli estalou os dedos para Pixiu, que descansava deitado no chão, e disse a Lu Yiqiu: — Vamos. Amanhã ainda temos caminho pela frente.

— Viemos andando por meia hora e, agora que finalmente chegamos, você já quer ir embora? Vá sozinho, então. Eu não volto.

Lu Yiqiu fez birra e se largou sentado no chão. Observando os Xiaozhu que passavam diante dele, murmurou:

— Acho que você está errado. Mesmo que as coisas boas deste mundo desapareçam num piscar de olhos, isso não muda o fato de que foram boas enquanto duraram.

— Se alguém passa a vida inteira seguindo obedientemente o caminho que todos consideram certo, mas nunca é feliz e não conhece sequer um instante de alegria, viver cem anos não seria também uma forma de tortura?

Ele estendeu a mão, e um Xiaozhu pousou na ponta de seu indicador.

— Por mim, preferiria ser como este vaga-lume: brilhar intensamente uma vez e viver a vida que eu realmente quero viver.

Ren Duanli o observou com expressão serena. Murmurou que aquilo era uma “teoria absurda”, mas, sem fazer alarde, sentou-se ao lado dele e permaneceu ali em silêncio, fazendo-lhe companhia.

Uma brisa suave soprava pela montanha e os Xiaozhu cobriam os campos. Uma paisagem tão bela era daquelas que só se encontram por acaso — talvez aquela fosse a única vez que a veriam na vida.

Lu Yiqiu, sempre tão falante, parecia ter algo no coração. Ficou calado, abatido, e os dois permaneceram lado a lado em silêncio. Depois de um tempo indeterminado, suas pálpebras ficaram pesadas e ele adormeceu.

Ren Duanli olhou para ele de lado, tirou a própria veste para cobri-lo e, com extrema delicadeza, acomodou a cabeça de Lu Yiqiu em seu ombro.

Observou os Xiaozhu que circulavam ao redor dos dois e sentiu um desconforto percorrer-lhe o corpo inteiro.

Mas fazer o quê? Afinal, ele gostava...

— Talvez eu consiga guardar essa beleza para você.

Falou tão baixinho que parecia estar dizendo aquilo tanto para Lu Yiqiu quanto para si mesmo.

*

Na manhã seguinte, quando Lu Yiqiu acordou, o céu mal começava a clarear.

A veste externa de Ren Duanli ainda o cobria. O general lavava o rosto à beira do riacho, enquanto Pixiu brincava na água rasa, tentando apanhar peixes.

Lu Yiqiu se espreguiçou e, sem querer, derrubou uma lanterna que estava ao seu lado.

Olhou-a de relance: ela ainda estava acesa?

Uma lanterna comum queimaria todo o óleo em, no máximo, quatro ou seis horas. Curioso, ele a levantou para examiná-la.

Só então percebeu: que óleo que nada!

Alguém havia esvaziado seu interior e colocado ali uma quantidade incontável de Xiaozhu.

Aglomerados, eles cintilavam sem parar, emitindo uma luz ainda mais bela e intensa que a de uma lanterna comum.

Lu Yiqiu adorava essas coisinhas delicadas, dignas de fazer suspirar qualquer coração romântico.

Olhou para a lanterna e depois para Ren Duanli, junto ao riacho, e permaneceu em silêncio por um instante.

Só havia os dois naquele vale. Então tinha sido ele quem fizera a lanterna?

Mas ele morria de medo de insetos...

Quanta coragem precisara reunir para capturar tantos, só para fazê-lo feliz?

Lu Yiqiu era o tipo de pessoa cujas emoções apareciam imediatamente no rosto. Nunca economizava palavras para mostrar o que realmente sentia.

Assim, quando estava feliz, fazia exatamente o que fez naquele momento: levantou-se, sacudiu a lanterna na direção de Ren Duanli e gritou:

— Xiao Lili! Obrigado!

Ren Duanli virou-se para ele e, num tom carregado de desdém, respondeu com uma ofensa:

— Seu maluco.

Mas, ao virar o rosto de volta, estava sorrindo.

(Tem mais depois! Se não aparecer, saia e atualize a página!)

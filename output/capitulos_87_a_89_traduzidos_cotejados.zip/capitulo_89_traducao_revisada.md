Capítulo 89 — Arrancando comida da boca do tigre, o tirano fica todo ressentido

O caso de Cailian enfim chegara ao fim.

Ning Xiaoxiao imaginara que ter sangue nas mãos a deixaria inquieta, mas seu coração parecia bem mais resistente do que ela supunha.

Precisava admitir: não era uma pessoa perfeita como Gu Sijin.

Tinha seus interesses e desejos. Quando alguém a maltratava, sentia ódio, e o lado sombrio de seu coração desejava que aqueles que a haviam humilhado tivessem um fim terrível.

Na época do ensino fundamental II, desenvolvera-se mais cedo que as outras meninas. Já usava sutiã tamanho B no primeiro ano e saltara para C no segundo. Alguns meninos sem a menor vergonha passaram a chamá-la de “Mengniu Suannai”, nome de uma marca de bebida láctea.

Naquela época, enfrentara três deles sozinha. De um arrancara um dente da frente a socos; de outro, deslocara a mandíbula; o terceiro acabara mudando de escola depois de apanhar.

Ela sempre fora durona.

Bastava alguém chamá-la por um apelido ofensivo para ela responder com os punhos.

A Consorte Nobre e Cailian haviam destruído algo que ela prezava acima de tudo. Então fazê-las pagar com a vida não era exagero... era?

Enquanto Ning Xiaoxiao relembrava sua juventude turbulenta, aquele espertinho do Xiao Qi apareceu.

【Bip, bip, bip! Parabéns, anfitriã! Missão concluída! O índice de desvio da trama aumentou em 3% e agora soma 14%!】

【A próxima recompensa da roleta será desbloqueada quando o índice acumulado chegar a 15%. Continue se esforçando!】

Ning Xiaoxiao: 【Da próxima vez, mande mais missões desse tipo, por favor. E menos tarefas para mexer com o tirano, ok?】

Xiao Qi: 【Este humilde sistema fará o possível para negociar com a administração de missões. Mas... por que você não quer receber tarefas para pregar peças no tirano? Quando o alvo são as consortes, você não demonstra a menor piedade. Será que...】

Ning Xiaoxiao: 【Não é nada disso! Eu não fiz nada! Pare de inventar! Só quero continuar viva! Lu Linyuan é o imperador. Se eu o irritar, perco a cabeça! Não quero morrer.】

Xiao Qi deu uma risadinha provocadora: 【Hehe... É mesmo? Mas faz muito tempo que você não o chama de imperador cachorro!】

Ning Xiaoxiao gaguejou: 【E-eu só esqueci! Amanhã volto a chamá-lo de imperador cachorro! Imperador cachorro velho! Old dog king!】

*

Gu Sijin despertou ao amanhecer do dia seguinte.

Ao saber da morte terrível de Cailian, não conseguiu conter as lágrimas.

Em seu coração, apesar de todos os erros, Cailian ainda fora sua criada por mais de dez anos.

Ninguém é feito de pedra. Até de um cachorro criado por tantos anos a gente se apega; quanto mais de uma pessoa.

Todos tentavam consolá-la, mas somente Ning Xiaoxiao foi direto ao ponto:

— Minha senhora chora pela relação de tantos anos entre vocês. Mas será que ela pensou nessa afeição que a senhora tanto valoriza? Se tivesse um pingo de humanidade e se lembrasse dos anos juntas, jamais teria feito aquilo.

— Se a acusação de adultério tivesse sido confirmada, era por si mesma que a senhora estaria chorando agora.

Gu Sijin compreendia tudo aquilo e respondeu: — É por mim mesma que choro agora. Pensar que a pessoa mais próxima de mim foi capaz de me tratar assim... isso mostra como este harém é assustador.

Tomou a mão de Ning Xiaoxiao. — Neste palácio, agora só posso confiar em você, Xiaoxiao. Você sabe que nunca desejei disputar o favor do imperador. Entrei no palácio apenas por causa da minha família. Não quero mais me envolver nessas lutas do harém. Não sou páreo para elas e tenho medo de cometer algum erro que prejudique meus parentes.

Após uma pausa, baixou a voz: — Xiaoxiao, quero evitar o favor imperial.

???

Evitar o favor? Mas você nunca recebeu esse favor de verdade! O que há para evitar?

E outra coisa! Mana, o que você pensa que está fazendo?!

Na história original, depois de ser incriminada por Cailian, você não encontrava coragem em meio ao desespero e começava a dar uma surra atrás da outra nos monstros do harém, iniciando sua jornada de evolução?

E agora vem me dizer que quer evitar o favor do imperador?

Se não se apressar a dormir com Lu Linyuan e ter filhos, como vai virar imperatriz-viúva no futuro?

Se você não virar imperatriz-viúva, como diabos vou conseguir terminar a trama e voltar para casa?!

— Minha senhora, esta serva acredita que, em vez de evitar o favor imperial, a senhora deveria se esforçar ainda mais para conquistá-lo.

— No instante em que entrou na Cidade Imperial, a senhora já foi arrastada para as disputas do harém. Não há como escapar delas.

— Antes, por ter o favor do imperador, suas rivais só ousavam atacá-la às escondidas. Se um dia perder até esse favor, vão passar por cima da senhora sem a menor cerimônia!

Enquanto conversavam, Xiao Yinzi, que servia na presença imperial, pediu audiência.

— Saudações à Atendente Gu. O imperador está preocupado com sua saúde e me enviou para saber como está.

Gu Sijin fez um esforço para parecer tranquila: — Estou bem. Obrigada pelo cuidado, e peço que agradeça a Sua Majestade por mim.

Xiao Yinzi prosseguiu: — Sua Majestade se lembrou do susto que a Atendente Gu levou ontem e mandou preparar alguns tônicos para acalmar os nervos.

Ele deu um tapa na própria testa e sorriu, sem graça: — Que cabeça a minha! Saí tão depressa que esqueci de trazê-los. Vou voltar e buscá-los agora mesmo.

Xiao Yinzi trabalhava para o imperador. Suas idas e vindas representavam a vontade imperial.

Gu Sijin não podia deixá-lo fazer outra viagem desnecessária. — Não precisa se incomodar, eunuco. Xiaoxiao, acompanhe o eunuco Yin para buscar os presentes.

Na verdade, Xiao Yinzi viera por ordem de Lu Linyuan justamente para levar Ning Xiaoxiao ao Palácio Chaoyang. Ao ouvir as palavras de Gu Sijin, respondeu prontamente: — Então peço à senhorita Xiaoxiao que venha comigo.

A cabeça avoada de Ning Xiaoxiao não percebeu a armação. Achou que bastaria buscar os presentes e voltar, mas Xiao Yinzi a conduziu diretamente aos aposentos de Lu Linyuan e ainda fechou a porta com toda a consideração.

Naquele dia, Lu Linyuan estava de folga e não precisava participar da audiência matinal. Quando Ning Xiaoxiao chegou, ele tomava café da manhã.

Havia mingau de camarão grande com abalone e pãezinhos recheados de caldo e ovas de caranguejo. Ning Xiaoxiao pensou:

【O old dog king não disse que essa comida era lavagem para porcos? Por que está comendo a mesma coisa hoje?】

Lu Linyuan aguçou os ouvidos, os olhinhos cheios de uma enorme dúvida:

Que bobagem estrangeira essa mulher está soltando tão cedo?

Ning Xiaoxiao não conseguia tirar os olhos do café da manhã. 【Humm... Será que ele quer me obrigar a comer de novo?】

Ainda se lembrava do sabor daquelas duas delícias da última vez. Lambeu os lábios, cheia de expectativa.

【Oinc, oinc! Eu aceito!】

Os dois grunhidos de porco que ela imitou mentalmente quase fizeram Lu Linyuan se engasgar com o mingau.

Ele tossiu com força duas vezes. Desta vez, Ning Xiaoxiao já sabia se adiantar:

— Se Vossa Majestade acha difícil engolir essa comida, esta serva pode ajudá-lo a acabar com ela!

Lu Linyuan se esforçou para conter a risada. Não podia perder a dignidade imperial diante dela.

Ergueu os olhos e a encarou friamente.

Dar a comida para você?

Nem sonhando! Eu... Hein?

Antes mesmo de concluir o pensamento, Lu Linyuan ficou boquiaberto.

Sem dizer mais nada, Ning Xiaoxiao pegou um pãozinho recheado de ovas de caranguejo e o enfiou na boca.

Enquanto mastigava, ainda fez uma expressão de sofrimento: — Que coisa horrível! Como a cozinha imperial ousa servir algo assim a Vossa Majestade? Que falta de dedicação!

Gulosa daquele jeito, com as bochechas estufadas, parecia um esquilinho que enchera a boca de nozes para estocar durante o inverno.

Por algum motivo, sempre que era Ning Xiaoxiao a ultrapassar os limites, Lu Linyuan parecia encontrar uma desculpa para perdoá-la.

Ele pedira a Sanfu que preparasse exatamente o mesmo café da manhã da outra vez porque, naquela ocasião, não conseguira comê-lo e passara dias desejando aqueles pratos.

E agora, outra vez, ficaria sem comer o próprio café da manhã.

Afinal, não podia disputar “lavagem de porcos” com Ning Xiaoxiao, podia? Tinha uma reputação a preservar!

Assim, empurrou a tigela de mingau para diante dela, contrariado.

Ao vê-la sorver o mingau com tanto prazer, sentiu-se um tantinho injustiçado.

Desde que essa mulher começou a aparecer diante de mim o tempo todo, não consigo nem fazer uma refeição decente!

Que absurdo! Desde que nasci, nunca passei por tamanho desaforo!

Dá até vontade de chorar... Ծ‸Ծ

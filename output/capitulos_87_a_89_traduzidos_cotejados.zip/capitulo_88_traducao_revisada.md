Capítulo 88 — Cailian é esquartejada por cinco cavalos

Com todos apontando para ela, ninguém acreditaria na Consorte Nobre, por mais que insistisse na própria inocência.

Mas a família dela ainda tinha grande importância nos assuntos da corte. Se Lu Linyuan a punisse com severidade, poderia provocar instabilidade política.

Antes de ser marido daquelas mulheres, ele era o imperador.

As consortes tinham inúmeros vínculos com os ministros; mexer em uma delas podia provocar uma reação em cadeia.

Para um soberano, preservar a estabilidade do governo era a prioridade absoluta.

Ele lançou à Consorte Nobre um olhar glacial e declarou solenemente: — A Consorte Nobre do clã Tong, arrogante, ciumenta e desrespeitosa com a lei, armou falsas acusações, semeou intrigas e perturbou a paz do harém. Por isso, determino que seja rebaixada à posição de...

Pretendia reduzi-la ao posto de Consorte, uma punição que lhe serviria de lição.

Mas, sem querer, seu olhar pousou sobre Ning Xiaoxiao, que estava ao lado.

Ela acariciava delicadamente a pulseira de jade no pulso, os lábios apertados e uma tristeza discreta nos olhos.

Por algum motivo, Lu Linyuan sentiu uma pontada no coração.

Não sabia explicar, mas aquela expressão dela despertava sua compaixão.

Então mudou a sentença: — Determino que lhe seja retirado o título honorífico, que seja rebaixada ao posto de Concubina e confinada por um mês. Não poderá sair sem convocação.

As demais mulheres do harém esconderam o contentamento e finalmente sentiram que haviam se vingado.

Um rebaixamento já seria uma punição severa. Mas a antiga Consorte Nobre fora reduzida a Concubina! Antes, só ficava abaixo da imperatriz; agora até as Consortes estariam acima dela. Como continuaria agindo com arrogância?

E perder o título honorífico era uma humilhação ainda maior que perder posição.

Para as consortes da época, receber um título do imperador era sinal de reconhecimento; vê-lo retirado, uma vergonha imensa.

Quando a notícia se espalhasse, dentro e fora do palácio, sua reputação estaria destruída.

Claramente, nenhuma delas imaginara que Lu Linyuan puniria a Consorte Nobre tão duramente por causa de Gu Sijin.

A família Tong era muito influente na corte. Com aquela sentença, Lu Linyuan aceitava provocar a insatisfação do clã para fazer justiça a Gu Sijin.

Ao mesmo tempo, uma dúvida intrigava as mulheres:

Se Gu Sijin nunca de fato dividira o leito com o imperador, o que fazia todas as noites no Palácio Chaoyang?

A Consorte Nobre chorava e gritava que era inocente, implorando que Lu Linyuan investigasse.

Incomodada com a gritaria, a imperatriz fez um gesto aos servos: — A Concubina Tong enlouqueceu. Levem-na de volta e não permitam que seus escândalos perturbem o sossego da imperatriz-viúva.

Resolvida a situação da mandante, era hora de cuidar dos cúmplices.

Lu Linyuan ordenou que o guarda fosse espancado até a morte. A esposa e o filho seriam enviados à fronteira como escravos, proibidos para sempre de voltar à capital.

Quanto a Cailian, ele ainda não havia pronunciado a sentença quando ouviu a criada implorar sem parar a Gu Sijin:

— Senhorita! Salve-me, por favor! Eu não quero morrer!

— Não se lembra de quando teve febre alta na cerimônia de maioridade? Foi o meu sangue que serviu de ingrediente para o remédio que a salvou!

— Sempre fui leal à senhorita! Desta vez, realmente me arrependo!

Ela enumerava seus atos de devoção, chorando de forma tão comovente que dava pena de olhar.

Gu Sijin ajudou-a a levantar do chão gelado e enxugou suas lágrimas, com os próprios olhos avermelhados. — Nunca imaginei que faria isso comigo. Eu lhe dizia que poderia perdoar qualquer erro seu, mas, se a acusação de hoje tivesse dado certo, toda a família Gu poderia ter sido condenada.

Ela balançou a cabeça e, cerrando os dentes, concluiu: — Desta vez, não posso mais poupá-la.

Então suplicou a Lu Linyuan: — Majestade, peço clemência. Pelos mais de dez anos que fomos senhora e criada, permita ao menos que o corpo dela permaneça inteiro após a morte.

Ning Xiaoxiao observava tudo com frieza.

Corpo inteiro?

Ela merecia isso?

Se Cailian saísse dali com o cadáver intacto, Ning Xiaoxiao escreveria o próprio nome ao contrário!

A situação já estava decidida. Ela havia seguido o curso da trama para levar Cailian à morte, sem usar nenhum de seus poderes especiais.

Portanto, se agora modificasse apenas a maneira como Cailian morreria, tornando-a um pouco mais “espetacular”, isso não violaria as regras.

Na trama original, Cailian fazia uma longa súplica. Ning Xiaoxiao selecionou suas falas, apagou tudo de uma vez, reescreveu a cena ao seu gosto e apertou o botão Reproduzir.

Lu Linyuan aceitou o pedido de Gu Sijin: — Nesse caso, permitam que seu corpo permaneça inteiro. Condeno-a ao suicídio.

Cailian se levantou de repente e mostrou o dedo do meio ao imperador.

— Majestade, não precisa deixar meu corpo inteiro! Eu gosto mesmo é de emoção!

— Por que não manda me cortar ao meio pela cintura? Quero descobrir se ainda consigo fazer espacate depois de dividida em duas!

— Se não mandar me cortar ao meio hoje, você é um otário!

Lu Linyuan: — ???

Nunca ouvira um pedido tão absurdo na vida.

— Muito bem. Já que deseja emoção, vamos até o fim. Sanfu, leve-a daqui e mande o Ministério das Punições preparar o local.

— Esta noite, ela será esquartejada por cinco cavalos!

Ao ouvir isso, Gu Sijin foi tomada mais uma vez por sua compaixão e tentou interceder repetidamente por Cailian.

Quando era mais jovem, vira por acaso uma execução daquele tipo. Até hoje, a lembrança lhe causava pesadelos.

Ao imaginar Cailian submetida à mesma crueldade, sentiu o coração disparar e desmaiou.

*

Depois que levaram Gu Sijin de volta ao Palácio Zhongcui, um médico imperial a examinou.

Segundo ele, ela desmaiara apenas pelo susto. Bastava dormir para se recuperar.

Qiqi e as demais criadas ainda estavam abaladas. — Nunca imaginei que Cailian fosse capaz de trair a própria senhora! Que sorte você ter pensado em tudo, Xiaoxiao. Se o plano dela tivesse dado certo, nós, servas, teríamos sido arrastadas para a desgraça junto com nossa senhora.

Ning Xiaoxiao balançou a cabeça com resignação. — Ela já vai morrer. Não precisam ficar falando disso.

Saiu conduzindo sua alpaca. Qiaqia lhe perguntou: — Aonde vai tão tarde, Xiaoxiao?

— Trabalhei com Cailian por muito tempo. Como ela está de partida, quero ir me despedir.

— Ah... mas por que levar a alpaca?

— Depois da despedida, aproveito para passear com ela.

Todas ficaram admiradas com a generosidade de Ning Xiaoxiao: até por alguém tão ruim quanto Cailian ela parecia ter compaixão, tal qual Gu Sijin.

Mal sabiam que, quando Ning Xiaoxiao dizia que iria “acompanhar Cailian em sua última jornada”, estava falando muito sério.

A execução aconteceria no campo de treinamento dentro do palácio, sob a responsabilidade de Xiao Yinzi.

Naquele momento, Cailian já estava deitada no centro do local de execução.

Uma corda estava amarrada a cada um dos quatro membros e ao pescoço; na outra ponta de cada corda havia um cavalo forte conduzido por um servo.

O esquartejamento por cinco cavalos consistia em fazer os animais dispararem em direções diferentes ao sinal do carrasco, dilacerando o condenado.

Ao ver Ning Xiaoxiao se aproximar, Xiao Yinzi a recebeu sorrindo: — Senhorita Xiaoxiao, o que faz aqui?

— Eu estava passeando com minha montaria, passei por aqui e vim ver a movimentação. — Ela acariciou a cabeça da alpaca. — Aquele cavalo da frente parece meio abatido. Que tal substituí-lo pelo meu?

Xiao Yinzi era esperto e compreendeu imediatamente o que ela queria.

Seu mestre já o avisara de que Ning Xiaoxiao não era uma pessoa comum e que um dia ascenderia a uma posição elevada. Ele sabia que valia a pena agradá-la.

— Se a senhorita não tivesse comentado, eu nem perceberia. De fato, aquele cavalo parece um tanto indisposto.

Ele pegou naturalmente as rédeas da alpaca das mãos de Ning Xiaoxiao. — Muito obrigado por emprestá-la. Assim, não preciso voltar até os estábulos imperiais para buscar outro animal.

Ning Xiaoxiao observou Xiao Yinzi substituir o cavalo da frente pela alpaca. Então sorriu de leve e murmurou:

— Antes, ela espetou sua bunda com um grampo de cabelo. Hoje, corra à vontade. Vai poder se vingar de tudo o que ela fez.

Capítulo 87 — A trama da Consorte Nobre é desmascarada

O guarda visivelmente entrou em pânico. Ao perceber que a situação estava prestes a fugir do controle, a Consorte Nobre estreitou os olhos e lhe lançou um olhar significativo.

Na história original, aquele guarda tinha esposa e filhos fora do palácio. Como trabalhava na corte, temia que algum erro seu acabasse envolvendo a família; por precaução, nunca havia informado às autoridades os dados da mulher e das crianças.

Os informantes da Consorte Nobre fora do palácio descobriram isso, e ela aproveitou a oportunidade.

Ameaçou o guarda para que obedecesse às suas ordens: se cumprisse a tarefa, ele morreria, mas ela garantiria uma vida de riqueza e conforto à sua família.

Se fracassasse, mandaria seus agentes secretos matarem a esposa e os filhos.

Só que, na trama original, Gu Sijin e Lu Linyuan já haviam passado por incontáveis noites de intimidade; sua marca de castidade há muito desaparecera.

Por isso, o plano da Consorte Nobre dava certo. No fim, o guarda se atirava de cabeça contra uma coluna decorada com fênix no Palácio Fengluan, morrendo e levando consigo a única testemunha. Gu Sijin acabava mandada para o Palácio Frio.

Agora, ao receber o sinal da Consorte Nobre, o guarda só podia sacrificar a própria vida para salvar a mulher e os filhos.

Ele gritou para Lu Linyuan: — Majestade! Este servo está disposto a morrer para provar que tudo o que disse é verdade!

Terminada a frase, levantou-se e disparou com toda a força em direção à coluna ornamentada.

Mas Ning Xiaoxiao já havia previsto o que faria e esticou a perna para lhe dar uma rasteira.

O homem perdeu o equilíbrio e caiu de cara no chão, quebrando os dois dentes da frente.

Os guardas imperiais avançaram em massa e o imobilizaram. Lu Linyuan ergueu a voz: — Tenha feito isso ou não, hoje você morrerá de qualquer maneira. Mas, antes, quero que veja duas pessoas.

Bateu palmas em sinal de ordem. Sanfu então conduziu ao salão uma mulher e uma criança, ambas vestidas com simplicidade.

Assim que viram o guarda, as duas correram até ele. A família de três pessoas se abraçou e chorou diante do imperador.

Lu Linyuan não era do tipo que se comovia com cenas familiares. Disse friamente: — Caluniar uma consorte imperial é crime capital, capaz de condenar todo o seu clã. Sua mulher e seu filho estão aqui agora; não precisa mais temer ameaças contra eles. Diga quem deu a ordem, e pouparei a vida de sua família.

A mão da Consorte Nobre apertou cada vez mais o lenço. Estava tão nervosa que quase parou de respirar.

Naquele ponto, se o guarda não contasse a verdade, toda a sua família morreria.

Sem outra saída, ele revelou tudo:

— Majestade... este servo é culpado!

— Foi a Consorte Nobre quem ameaçou minha família e mandou que eu violasse a Atendente Gu, para depois acusá-la de manter relações ilícitas comigo.

— Sem ter escolha, fingi obedecer. Mas amo apenas minha esposa e me recusei a traí-la. Além disso, a Atendente Gu era inocente. Por isso, não a desonrei.

— Mentira deslavada!

Antes que o guarda terminasse, a Consorte Nobre o interrompeu aos gritos, avançou dois passos, ajoelhou-se diante de Lu Linyuan e protestou:

— Majestade! Eu jamais fiz tal coisa! Sou a Consorte Nobre, e Gu Sijin não passa de uma Atendente. Que motivo teria para difamá-la?

Seus olhos se moveram rapidamente, enquanto ela improvisava uma saída.

De súbito, apontou para Gu Sijin e acusou, com ferocidade: — Foi ela! Ela e esse guarda armaram tudo para me incriminar! Peço que Vossa Majestade investigue com justiça!

A imperatriz havia suportado por muito tempo as alfinetadas da Consorte Nobre. Agora que finalmente encontrara uma falha, não deixaria a ocasião passar.

Declarou em voz firme: — Eu já estranhava. A Consorte Nobre nunca se interessou por flores; por que, de repente, ficou fascinada pelos crisântemos do Palácio Zhongcui? E ainda convidou todas nós para admirá-los? Agora entendo: não era um passeio para apreciar flores, mas uma armadilha mortal cuidadosamente preparada para a Atendente Gu!

A Consorte Yun também aproveitou para jogar lenha na fogueira: — Que crueldade, Consorte Nobre! A honra de uma mulher vale mais do que tudo. Como pôde caluniar a Atendente Gu dessa maneira? É verdade que a senhora tem posição superior, mas isso não a impede de invejar o favor que ela recebe: sete noites com o imperador em apenas um mês! Aposto que queria se livrar dela a qualquer custo!

A Consorte Nobre fuzilou com os olhos aquelas mulheres que aproveitavam sua desgraça. Ainda assim, ergueu o queixo com arrogância: — Não admitirei algo que não fiz! Parem de me difamar! Se são tão capazes, apresentem provas!

Ning Xiaoxiao trocou um olhar com Lu Linyuan. Ele ergueu discretamente uma sobrancelha, fazendo-lhe um sinal, e ela tomou a palavra:

— Majestade, ainda há outras coisas estranhas nesse caso. Deixemos a Consorte Nobre de lado por um instante: por que ninguém estava de vigília ontem à noite? Os portões do Palácio Zhongcui são trancados por dentro todas as noites. Sem um cúmplice ali, esse guarda teria escalado os muros de vários metros de altura?

Com a situação virando a seu favor, Gu Sijin conseguiu se acalmar um pouco.

Ela olhou para Cailian, ajoelhada ao lado. O rosto da criada estava lívido, e gotas enormes de suor lhe escorriam da testa até o chão.

Cailian a servira por mais de dez anos. Gu Sijin sabia muito bem interpretar seus gestos e suas palavras.

Ela a havia perdoado repetidas vezes, sem imaginar que um dia chegariam àquele ponto.

Pensando melhor, o sono profundo da noite anterior provavelmente tinha muito a ver com a tigela de leite fresco adulterado que Cailian lhe dera.

Gu Sijin era bondosa por natureza e conseguia tolerar muitas coisas. Mas, se Cailian e a Consorte Nobre tivessem conseguido incriminá-la por adultério com o guarda, não seria apenas ela a pagar o preço: toda a família Gu poderia ser arruinada!

Pensando nisso, endureceu o coração e resolveu não se calar mais.

— Majestade, ontem à noite eu não mandei Bengbeng voltar ao quarto nem pedi a Cailian que assumisse a vigília. Tampouco lhe disse que estava preocupada com ela e que podia ir descansar, ou qualquer outra bobagem sobre não precisar de ninguém de guarda.

— Antes de me deitar, Cailian trouxe uma tigela de leite fresco. Depois que bebi, fiquei tão sonolenta que perdi a consciência do que acontecia à minha volta. Imagino que tudo isso tenha sido obra dela!

Ning Xiaoxiao olhou para Gu Sijin com evidente aprovação.

Ora, ora! O coelhinho branco que ela criava finalmente aprendera a mostrar os dentes e morder!

Muito bem, muito bem! Isso é progresso!

Ao ouvir a acusação, as pernas de Cailian fraquejaram, e ela desabou no chão. — Não... não fui eu!

Arrastou-se até os pés de Gu Sijin, agarrou a barra da saia dela e chorou desesperadamente: — Senhorita! Acredite em mim! Não fiz nada disso! Sirvo à senhorita há tantos anos! Como poderia... Ah!

Ning Xiaoxiao a afastou com um chute e se voltou para o guarda: — Você seria capaz de reconhecer quem abriu o portão para você ontem à noite?

O guarda apontou para Cailian sem hesitar: — Foi ela!

Cailian começou a tremer dos pés à cabeça. Lu Linyuan a encarou de cima, impondo respeito mesmo sem demonstrar ira: — Quem mandou você fazer isso? Fale!

Para salvar a própria pele, Cailian só pôde entregar a Consorte Nobre.

Arrastou-se outra vez até Gu Sijin e bateu a testa com força no chão: — Senhorita, eu a traí! Me perdoe! Foi a Consorte Nobre quem me obrigou a fazer tudo! Se eu não obedecesse, ela me mataria! Tenha piedade, senhorita! Tenha piedade, Majestade!

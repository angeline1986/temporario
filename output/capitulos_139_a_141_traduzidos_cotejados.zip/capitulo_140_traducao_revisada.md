# Capítulo 140 — O tirano atira em Xiaoxiao

Aquela pergunta deixou Ning Xiaoxiao petrificada na mesma hora.

Ainda mais porque, depois de fazê-la com toda a seriedade, ele não conseguiu conter umas risadinhas maliciosas. Ficou evidente que estava se divertindo às custas dela.

— Ri, ri! Ri da sua própria cara!

Ning Xiaoxiao perdeu a paciência de repente e, sem dar qualquer aviso, desferiu um belo tapa na nuca de Lu Linyuan.

Como estavam muito próximos, ele nem teve tempo de reagir antes de ficar atordoado com o golpe.

— V-você... ousa bater em mim?!

Encarando o olhar incrédulo dele, Ning Xiaoxiao levantou a mão e bateu em sua cabeça de novo. — Não só ouso como ouso duas vezes!

Lu Linyuan: — !!!

— Ning Xiaoxiao! Dei-lhe liberdade demais, foi? Só porque tenho tolerado seus abusos, você pensa que pode montar na minha cabeça! Experimente me bater de novo e verá o que eu...

*Pá!*

Antes mesmo que ele terminasse a ameaça, Ning Xiaoxiao satisfez seu desejo.

Lu Linyuan arregalou tanto os olhos que pareciam dois sinos de bronze. Até beliscou a própria coxa para conferir se não estava sonhando.

— Ning Xiaoxiao! Que insolência! Eu...

— Tchauzinho!

Depois de desabafar sua raiva, Ning Xiaoxiao nem concedeu ao tirano o tempo necessário para espernear inutilmente.

Acenou sorridente para Lu Linyuan, estalou os dedos e fez o tempo retroceder três minutos.

*

Lu Linyuan aproximou-se, roçando o rosto junto ao dela, e baixou deliberadamente a voz: — Então... coça mesmo?

Ning Xiaoxiao fingiu timidez e o empurrou de leve, falando numa voz dengosa: — Ai, Majestade, não faça perguntas tão embaraçosas! Que tal falarmos de algo sério? Desmontei a arma de fogo e fiz desenhos de sua estrutura. Se Vossa Majestade os entregar à Oficina de Engenhos, eles deverão conseguir fabricar uma arma ainda mais poderosa que as ocidentais.

Ao ouvir falar de assuntos de Estado, Lu Linyuan abandonou imediatamente a brincadeira. — Ah, é? Deixe-me ver.

Ning Xiaoxiao tirou os desenhos de dentro das roupas. Quando Lu Linyuan estendeu a mão, ela se esquivou. — Majestade, não pode simplesmente pegá-los de graça. Isso me custou muito trabalho. Posso entregá-los, mas antes Vossa Majestade terá de atender a um pedido meu.

— Que pedido?

Ning Xiaoxiao fez charme. — Primeiro, Majestade, precisa prometer que vai atendê-lo!

— Se estiver ao meu alcance, farei o que pedir.

— Uma promessa do imperador não pode ser desfeita! — O sorriso de Ning Xiaoxiao tinha segundas intenções. — Na verdade, não é nada demais... Eu só queria ver Vossa Majestade fazendo um espacate!

Lu Linyuan: — ???

— Você está doente da cabeça? Já não lhe bastou ver Gu Sijin fazer espacate? Agora quer me ver fazendo também? Quer que eu abra você ao meio, isso sim?!

— Ai, Majestade! Já me prometeu! Não pode voltar atrás!

A resposta de Lu Linyuan foi categórica: — Não vou fazer espacate.

— Ai, Majestade! Só uma vez! Faz bem para o corpo e para a mente!

Lu Linyuan cerrou os dentes. — Não vou fazer! Tenho medo de rasgar a virilha!

— Aaaah, por favor, Majestade! — Ning Xiaoxiao se aproximou, segurou as mãos grandes dele e começou a balançá-las, manhosa. — Só um espacatezinho! Se não concordar, vou ter de queimar os desenhos...

Aquela chantagem descarada deu uma dor de cabeça em Lu Linyuan. Sem saber que fio de sua cabeça havia entrado em curto, acabou cedendo. — Está bem, está bem! Eu aceito! Pare de sacudir minha mão; você está me dando enjoo!

Só então Ning Xiaoxiao soltou sua mão, satisfeita. Mas ele impôs uma condição: — Posso concordar, desde que seus desenhos realmente permitam construir uma arma de fogo. Se estiver tentando me enganar, tenho mil maneiras de fazê-la pagar!

— Palavra dada é palavra cumprida! — Ning Xiaoxiao obrigou Lu Linyuan a bater sua palma contra a dela e só então entregou os desenhos.

Naquela mesma noite, Lu Linyuan mandou Sanfu levá-los à Oficina de Engenhos, ordenando que os artesãos trabalhassem durante a madrugada para fabricar a arma o mais depressa possível.

Na manhã seguinte, quando Ning Xiaoxiao foi apresentar seus cumprimentos à imperatriz, viu que as consortes Yun e Li e a Concubina Shen estavam com os rostos inchados feito cabeças de porco, depois de receberem oitenta tapas como punição.

Assim que a viram, desviaram do caminho como se tivessem encontrado uma peste. Nenhuma delas ousou abrir a boca para falar mais uma besteira.

A imperatriz assumiu a postura de senhora do harém e as repreendeu. Ordenou que dali em diante todas soubessem seu lugar, evitando fofocas e discussões que perturbassem a paz do palácio interno.

Mais tarde, servidores do Palácio Shoukang vieram informar que a imperatriz-viúva estava emburrada e se recusava a comer. A imperatriz encerrou a audiência matinal e foi às pressas tentar acalmá-la.

Dessa vez, Lu Linyuan estava decidido a dar uma lição na imperatriz-viúva. Do começo ao fim, não perguntou sequer uma vez por ela.

Afinal, já havia descoberto pelos pensamentos de Ning Xiaoxiao que aquela mãe desgraçada viveria até passar dos noventa anos. Não seria tão fácil morrer de raiva por causa dele.

À noite, Ning Xiaoxiao recebeu uma convocação imperial e correu entusiasmada ao Palácio Chaoyang.

Ao chegar, encontrou Lu Linyuan sentado no trono, manuseando uma arma cuja semelhança com uma pistola moderna chegava perto dos noventa por cento.

Ning Xiaoxiao exclamou, radiante: — Uau! Os artesãos da oficina trabalham tão depressa assim? Conseguiram fazer uma em apenas um dia?

A expressão no rosto de Lu Linyuan estava sombria, muito diferente da habitual, quase irreconhecível.

Ele emanava uma presença poderosa e opressiva que deixou Ning Xiaoxiao desconfortável.

— Pois é. Em apenas um dia, conseguiram fazê-la.

Lu Linyuan girou a pistola duas vezes na palma da mão e, de repente, parou e apontou o cano para Ning Xiaoxiao.

Ela se assustou com o gesto inesperado. — M-Majestade?

Um sorriso sinistro, quase sanguinário, surgiu nos lábios de Lu Linyuan. — Estou apenas brincando. Por que tanto medo?

Ele deixou a pistola sobre a mesa imperial e chamou-a com um gesto. — Aproxime-se.

Ning Xiaoxiao foi até a mesa, e Lu Linyuan ergueu as sobrancelhas. — Você quer tanto assim me ver fazendo espacate?

A expressão dele era assustadora; havia uma malícia estranha em seu semblante. Intimidada, Ning Xiaoxiao mal ousou responder, limitando-se a um discreto “hum”.

— Mas eu não quero fazer.

De repente, Lu Linyuan pegou a pistola e apontou-a diretamente para a cabeça de Ning Xiaoxiao. — O que mais odeio é que façam de mim um brinquedo!

Assim que terminou de falar, sem lhe dar tempo de compreender o que acontecia, apertou o gatilho resolutamente.

Ning Xiaoxiao franziu o cenho e fechou os olhos. Mas o estampido violento que esperava não veio. Ainda assim, sentiu algo atingir sua cabeça e um líquido morno começar a escorrer.

Ela abriu os olhos, apavorada, e Lu Linyuan disparou outra vez contra ela, sem a menor piedade.

*Psssh!*

Um jato de água saiu do cano e acertou bem a testa de Ning Xiaoxiao.

Ning Xiaoxiao: — ???

Que porra era aquela? Tinham fabricado uma pistola de água?!

Só podia ser brincadeira!

— Está se divertindo?

*Psssh!*

— Estou perguntando se está se divertindo!

*Psssh!*

— É só porque alguém não perde a paciência que você acha que pode tratá-lo como idiota?!

*Psssh!*

— Agora eu fiquei realmente furioso!

*Psssh, psssh, psssh!*

A cada frase, apertava o gatilho mais uma vez, até deixar Ning Xiaoxiao encharcada feito um pintinho na chuva.

Ning Xiaoxiao limpou a água do rosto, constrangida, e deu uma risadinha tola. — Desculpe, foi um erro! Um pequeno erro! Dê-me mais dois dias, Majestade, e desta vez tenho certeza de que vou conseguir!

Lu Linyuan estava fora de si:

— Fique quieta!

— Deixe-me terminar de esguichar esta água para descarregar minha raiva!

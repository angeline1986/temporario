# Validação — capítulo 140

- **Fonte:** `novel_capitulos_121_a_180(20261103-233558).docx` — chinês tradicional, DOCX.
- **Limites:** parágrafos 1284 a 1364 do DOCX (índices reais, base zero); capítulo seguinte excluído.
- **Parágrafos não vazios:** 78, incluindo título e notas quando presentes.
- **Linhas de dados do CSV:** 78.
- **Índices ausentes:** 0; **duplicados:** 0; **campos vazios:** 0.
- **Método:** tradução integral e cotejo parágrafo a parágrafo; checagem automática dos índices, dos campos e da integridade dos arquivos.
- **Limitação:** o pareamento 1:1 e a revisão durante a tradução não constituem uma segunda auditoria semântica independente integral. A ausência de linhas vazias não demonstra por si só ausência de omissões internas ou divergências de sentido.

## Notas editoriais

- A narrativa contém um retrocesso explícito de três minutos, separando o primeiro episódio de agressões da linha temporal subsequente.
- O pedido de Ning Xiaoxiao é condicionado ao êxito de fabricar uma arma funcional; a primeira tentativa acaba em pistola de água.
- A encenação de disparo de Lu Linyuan não causa ferimento por bala: o líquido é água, revelado progressivamente pelo texto.
- A referência aos oitenta tapas às consortes foi mantida.
- A imperatriz-viúva permanece no Palácio Shoukang e Lu Linyuan se recusa a perguntar por ela.

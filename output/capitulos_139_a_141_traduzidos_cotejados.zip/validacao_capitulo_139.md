# Validação — capítulo 139

- **Fonte:** `novel_capitulos_121_a_180(20261103-233558).docx` — chinês tradicional, DOCX.
- **Limites:** parágrafos 1209 a 1283 do DOCX (índices reais, base zero); capítulo seguinte excluído.
- **Parágrafos não vazios:** 72, incluindo título e notas quando presentes.
- **Linhas de dados do CSV:** 72.
- **Índices ausentes:** 0; **duplicados:** 0; **campos vazios:** 0.
- **Método:** tradução integral e cotejo parágrafo a parágrafo; checagem automática dos índices, dos campos e da integridade dos arquivos.
- **Limitação:** o pareamento 1:1 e a revisão durante a tradução não constituem uma segunda auditoria semântica independente integral. A ausência de linhas vazias não demonstra por si só ausência de omissões internas ou divergências de sentido.

## Notas editoriais

- 華貴人 mantido como Nobre Dama Hua, conforme o glossário dos capítulos recentes.
- A lâmina de barbear é usada para acesso ao espaço especial; Gu Sijin interpreta equivocadamente sua finalidade como depilação íntima.
- A referência a 3,1415926 foi preservada exatamente.
- O personagem Xiao Yinzi anuncia que o imperador escolheu a placa de Ning Xiaoxiao para a noite, sem antecipar acontecimentos íntimos.
- O trocadilho 陸臨冤 sobre o nome de Lu Linyuan foi adaptado como “Lu Lin-azar”.
- A observação de que raspar causa crescimento mais grosso dos pelos é fala de personagem, não afirmação médica do tradutor.

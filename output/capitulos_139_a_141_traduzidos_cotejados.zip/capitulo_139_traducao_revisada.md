# Capítulo 139 — Espalhem a notícia: Xiaoxiao vai raspar os pelos das pernas!

Embora Ning Xiaoxiao estivesse cheia de reclamações, uma missão, depois de anunciada, não podia ser alterada.

Com medo de levar uma bronca, Xiao Qi saiu de fininho, todo debochado.

Ela não podia usar os poderes especiais durante a missão. Sem modificar a trama, não conseguia imaginar como faria o tirano abrir um espacate diante dela...

Depois de muito pensar, só lhe restou uma alternativa: chantagem e recompensa.

【Isso! Posso oferecer os desenhos da pistola em troca! Ele faz um espacate e eu entrego os projetos!】

【Hoje, ou você abre as pernas, ou eu morro!】

Assim que voltou ao palácio, correu à penteadeira, abriu a gaveta e tirou a lâmina de barbear.

Mas, num descuido, deixou-a cair no chão.

Quando se abaixou para pegá-la, a porta se abriu de repente.

Era Gu Sijin. Ao entrar, a primeira coisa que viu foi Ning Xiaoxiao curvada, com a lâmina na mão, parecendo prestes a arregaçar a perna da calça.

As duas trocaram um olhar constrangido por dois segundos. Ning Xiaoxiao logo se endireitou e pôs a lâmina sobre a mesa.

— Irmã, você voltou? Como está a imperatriz-viúva?

Gu Sijin balançou a cabeça, com expressão serena. — Não há nada de grave com sua saúde, mas ela ficou furiosa. Quando acordou e descobriu que a haviam levado ao Palácio Shoukang, fez um escândalo daqueles.

Aproximou-se devagar, segurou a mão de Xiaoxiao e sentou-se com ela no assento aquecido. — Na verdade, eu estava mais preocupada com você. Durante os dias em que ficou no Palácio Chaoyang tratando Sua Majestade, vivi com o coração na mão. Tinha medo de que algo desse errado, de que não conseguíssemos salvar o imperador e você acabasse perdendo a vida também.

Ning Xiaoxiao exibiu um sorriso esperto e convencido. — Ah, irmã, não precisa se preocupar comigo! Desde quando eu faço alguma coisa sem ter certeza do que estou fazendo?

Gu Sijin sorriu, fingindo repreendê-la, e cutucou sua covinha. — O importante é que agora está tudo bem. Você deve estar exausta depois de tantos dias de agitação. Vou deixá-la descansar.

Ela se levantou, foi até a porta e parou. Lançou um olhar para a lâmina sobre a mesa e, depois de hesitar, resolveu aconselhá-la:

— Xiaoxiao, é perfeitamente normal uma mulher ter uma penugem nas pernas. É melhor não raspá-la... Dizem que, quanto mais se raspa, mais os pelos crescem, escuros e grossos. Aí sim você arranjaria um problema...

— Mas eu... — Ning Xiaoxiao ficou completamente sem jeito. — Essa lâmina não é para raspar os pelos das pernas!

— Se não é para as pernas, será que... — Gu Sijin olhou de relance para a parte interna das coxas de Xiaoxiao e ficou vermelha num instante. — Ah, você é mais jovem mesmo... Entende dessas brincadeiras muito melhor do que eu!

E, como se tivesse descoberto um segredo escandaloso, saiu correndo em pânico.

— ...

Ning Xiaoxiao levou a mão à testa, desolada. Ao olhar para a lâmina na mesa, teve vontade de abrir um buraco no chão e se enfiar nele.

Pronto. Agora não havia mais como explicar!

Pelo menos Gu não era uma matraca como aquele imperador azarado. Caso contrário, no dia seguinte todo o palácio saberia que ela usava uma lâmina de barbear em segredo para...

Passado o vexame monumental, ainda precisava cuidar do que importava.

Apertou a lâmina na mão, recitou mentalmente 3,1415926 e conseguiu entrar no espaço especial.

Da última vez, o lugar estivera completamente vazio. Agora estava abarrotado de seus salgadinhos, doces e bebidas favoritos.

Nem precisava perguntar: seus pais tinham preparado tudo.

Ela se acomodou confortavelmente num pufe, comendo tiras de massa apimentadas e bebendo refrigerante geladinho, e deixou um bilhete no espaço, toda contente.

Afinal, era a filhinha preciosa da família, e seus pais sempre faziam de tudo para atender a seus pedidos.

Quando voltou ao espaço naquela noite, o bilhete sobre a mesa tinha sido substituído por uma folha de desenhos técnicos.

Ning Xiaoxiao deu uma olhada: o processo de fabricação da pistola estava ilustrado com toda a clareza, até mesmo em cores.

Com aquele projeto, os artesãos da Oficina de Engenhos só precisariam copiar o modelo para fabricar uma pistola.

【Depois de uma contribuição tão grande, pedir que ele faça um espacate não é exagero, é?】

【Por que só de pensar nisso já fico tão animadinha?】

Com os desenhos nas mãos, correu para o Palácio Chaoyang como um raio.

No meio do caminho, encontrou por acaso a liteira imperial que vinha buscá-la. Xiao Yinzi cumprimentou-a sorrindo com uma reverência: — Que coincidência, Nobre Dama Hua! Sua Majestade escolheu sua placa para passar a noite com ele. Estávamos justamente indo buscá-la!

Antes que Xiao Yinzi terminasse suas gentilezas, Ning Xiaoxiao já havia se enfiado na liteira. — Chega de conversa! Andem, depressa!

Xiao Yinzi abafou uma risadinha. — Sabemos que a senhora está ansiosa. Vamos partir imediatamente!

É claro que estava ansiosa.

Mal podia esperar para ver Lu Lin-azar abrir um espacate!

Quando chegou ao Palácio Chaoyang, Lu Linyuan ainda examinava memoriais.

Ao vê-la, largou o pincel e assumiu uma expressão um tanto solene.

Ning Xiaoxiao estava prestes a anunciar que desmontara a arma e descobrira sua estrutura, mas ele falou primeiro:

— Há uma coisa que desejo muito saber. Como você costuma zombar de mim quando estamos longe um do outro?

Ning Xiaoxiao congelou. — Hã? Eu nunca disse nada de Sua Majestade...

— Nunca? Então por que a Nobre Dama Gu me procurou no Salão Baohua esta tarde e disse aquelas coisas absurdas?

— O que foi que ela disse?

— Ela disse... — As faces de Lu Linyuan ganharam um tom rosado visível. — Disse que todo mundo tem pelos no corpo e que eu... não deveria ser exigente demais com você. E também... que, se raspar tudo naquela região, a coceira fica insuportável...

Ele ainda pareceu dizer mais alguma coisa, mas Ning Xiaoxiao já tinha desligado a audição por vontade própria.

Estava tão constrangida que seus dedos dos pés poderiam cavar uma Cidade Proibida inteira no chão.

【Essa Gu está com algum problema na cabeça? O que deu nela? Acha que é engraçada?】

【Espera... Como ela sabe que raspar provoca coceira? Será que ela...】

【Ahá! Mistério resolvido! Então é você quem entende dessas brincadeiras!】

Ao ouvir aqueles pensamentos, Lu Linyuan ficou ainda mais convencido de que Gu Sijin dissera a verdade: aquela maluca realmente raspava os pelos às escondidas...

Mas por que faria uma coisa dessas sem nenhum motivo?

Será que era para agradá-lo?

Tsc... Aquela garota tinha cada artimanha!

— Venha cá. — Com seu gesto habitual de chamar gatos e cachorros, fez um sinal para Ning Xiaoxiao com o indicador.

Ela se aproximou, mortificada, pronta para se explicar, mas o ouviu declarar com toda a seriedade:

— O lótus que brota das águas é belo por natureza, sem precisar de adornos. Não gosto de agrados forçados. O melhor é deixar as coisas como são. Entendeu?

O “entendeu?” veio com uma entonação ascendente e uma sobrancelha arqueada, numa pose tão afetada que parecia ter mergulhado a cara num barril de óleo!

【Entendi o cacete!】

— Majestade... A Nobre Dama Gu entendeu tudo errado! Não usei a lâmina para... Quero dizer, eu ia usá-la para... Ai, não! Eu nem usei! É que...

Sentindo que qualquer explicação só pioraria as coisas, desistiu de tentar.

— Esqueça. O que Sua Majestade disser está dito...

Lu Linyuan balançou a cabeça, impotente, embora sorrisse com carinho. — Não faça mais uma bobagem dessas. Uma lâmina é afiada, e sua pele é delicada. E se você se cortar?

Ning Xiaoxiao estava a ponto de enlouquecer por causa daquele sujeito. — Majestade! Será que podemos... parar de falar dessa lâmina de uma vez?!

Lu Linyuan assentiu. — Podemos. Então vou fazer outra pergunta.

Aproximou-se, roçando o rosto junto ao dela, e baixou deliberadamente a voz: — Então... coça mesmo?

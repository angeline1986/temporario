# Capítulo 141 — O tirano faz espacate e canta

A pistola era pequena, mas água era o que não faltava.

Ning Xiaoxiao já nem conseguia enxergar direito de tanta água que recebera no rosto quando, de repente, um pano enorme veio voando de algum lugar e caiu em sua cara.

— Seque-se sozinha.

— Tá...

Ela pegou o pano e secou os cabelos molhados. Parecia uma criança que havia aprontado, cabisbaixa e com uma expressão de dar pena.

O inverno na capital era muito frio. Mesmo depois de secar os cabelos, seus lábios ainda tremiam um pouco de frio.

Mas Lu Linyuan, aquele sujeito insensível feito uma pedra, não demonstrou pena alguma. — Ning Xiaoxiao, por acaso tenho cara de idiota?

Depois de dizer isso, irritado, chutou bruscamente na direção dela o braseiro que estava aos seus pés. — Você me entrega os desenhos de uma pistola de água? Está tentando enganar quem, afinal?!

Aquele gesto “sem intenção” do tirano deixou Ning Xiaoxiao bem mais aquecida.

Enquanto se esquentava junto ao fogo, explicou: — Majestade, escute! Foi só um pequeno erro. Pode ficar tranquilo! Dê-me mais dois dias e eu conseguirei desenvolver uma arma de fogo de verdade!

— E se não conseguir?

— Se não conseguir, eu faço um espacate para o senhor. Está bom assim?

Lu Linyuan ergueu o queixo, orgulhoso. — Por hoje, vou poupá-la.

Apertou o gatilho mais duas vezes, e o último jato de água caiu no braseiro, fazendo um chiado. — Mas, falando sério, esse negócio até que é divertido.

Ah, pronto.

O espírito de criança ainda estava vivíssimo, não é?

Pelo tom de voz dele, Ning Xiaoxiao já conseguia prever o futuro:

Aquele idiota provavelmente passaria os dias correndo atrás dela e esguichando água em seu traseiro, feito uma criança sem juízo.

Só de pensar que toda aquela confusão acontecera porque seu pai irresponsável havia trocado os desenhos, Ning Xiaoxiao teve vontade de apontar uma arma para a cabeça do próprio velhote.

Voltou ao palácio naquela mesma noite, trancou a porta, pegou a lâmina de barbear e entrou no espaço. Ali, escreveu furiosamente uma redação de oitocentos caracteres para reclamar de Ning Dazhi.

Quando voltou ao espaço na manhã seguinte, os novos desenhos já tinham sido enviados.

Junto deles havia uma resposta curta de Ning Dazhi:

【Sua mãe disse que brincar com armas é perigoso. Achou melhor você se contentar com uma pistola de água.】

【Desta vez roubei os desenhos dos arquivos criptografados dela. Garanto que não haverá erro.】

【Aliás, sua letra é meio feia. Da próxima vez escreva menos. Fica tudo amontoado, e seu pai sofre só de olhar.】

A resposta de Ning Xiaoxiao foi ainda mais curta:

【Minha mãe disse que minha letra é igual à sua.】

*

Desta vez, quando os desenhos foram entregues à Oficina de Engenhos, os artesãos precisaram de um dia a mais para fabricar a arma.

Assim que terminaram, Lu Linyuan mandou chamar Ning Xiaoxiao ao Palácio Chaoyang para que ela visse com os próprios olhos o que aqueles novos desenhos eram capazes de produzir.

No começo, Ning Xiaoxiao ainda temia que o pai tivesse inventado alguma outra maluquice.

Mas Lu Linyuan disparou contra um alvo, e o estampido foi ensurdecedor. A bala atravessou diretamente o boneco colocado a vinte metros de distância. Naquele instante, Ning Xiaoxiao finalmente pôde erguer a cabeça com orgulho!

— Viu só, Majestade? Eu disse que desta vez daria certo!

O recuo provocado pelo disparo deixou o tirano impressionadíssimo.

As armas de fogo ocidentais eram poderosas, sem dúvida. Mas, comparadas àquela que segurava agora, não tinham nem metade de sua potência.

Se, no dia em que protegeu Ning Xiaoxiao, ele tivesse sido atingido por uma bala daquela arma, nem mesmo um imortal celestial teria conseguido salvá-lo.

Pesou na mão a pistola, ainda bastante compacta e leve, e pousou o olhar em Ning Xiaoxiao, toda cheia de si. Sorriu.

Agora tinha certeza de que encontrara um verdadeiro tesouro.

Mas o sorriso desapareceu logo, porque seu precioso tesouro só tinha uma coisa na cabeça: vê-lo abrir um espacate.

— Majestade... — Ning Xiaoxiao esfregou as mãozinhas, cheia de expectativa. — A arma ficou pronta. Não está na hora de cumprir sua promessa?

— Cof, cof. — Lu Linyuan fingiu não entender. — Que promessa? Prometi o quê?

Ning Xiaoxiao respondeu: — Nem pense em fugir, Majestade! Tem um monte de leitores olhando! Tenha um pouco de vergonha na cara...

Lu Linyuan: — ...

Ele permaneceu imóvel, recusando-se a ceder. Ning Xiaoxiao fez um biquinho e ficou com uma carinha de tamanha decepção que dava até pena.

— Está bem, está bem! Pare com essa cara! Eu faço o espacate!

Levantou a túnica imperial e começou a afastar as pernas pouco a pouco.

Vira Gu Sijin fazer espacate como se não fosse nada. Mas quando tentou, descobriu que era duro feito pedra: chegou à metade do movimento e não conseguiu descer mais.

— Força, Majestade!

— Não tenho mais força!

— Majestade, tem que fazer assim! — Preferindo agir a ficar dando instruções, Ning Xiaoxiao apoiou as mãos nos ombros de Lu Linyuan e empurrou seu corpo vigorosamente para baixo.

A pressão provocou uma dor lancinante na virilha dele, que mostrou os dentes de dor. — Ai! Mais devagar!

— Aguente só um pouquinho, Majestade! Seus músculos é que estão muito rígidos. Já vai melhorar!

Ning Xiaoxiao reuniu toda a força e deu um empurrão brusco. Acompanhado de um grito de dor de Lu Linyuan, o espacate finalmente se completou.

Ao mesmo tempo, encoberto pelo grito, ouviu-se um “rrrááás” que só ele percebeu.

Era o som das calças rasgando na virilha. E também do coração dele se partindo...

Sem notar nem um pouco seu constrangimento, Ning Xiaoxiao bateu palmas, animando-o. — Uau! Majestade, que incrível! O movimento ficou perfeito!

Lu Linyuan: — ...

Naquele momento, não tinha mais energia para discutir. Só queria que ela fosse embora depressa, antes que percebesse que suas calças estavam abertas na virilha!

— Já fiz o espacate. Agora você pode ir embora, não pode?

Ning Xiaoxiao sorriu sem jeito. — Majestade, é que... Eu também queria ouvir o senhor cantar!

Lu Linyuan rugiu, furioso: — Nem pense nisso!

— Aaaah, Majestade! Só uma música! Eu canto e o senhor repete. Quando terminarmos, vou embora na mesma hora, está bem?

Ele estava exausto. Já não tinha forças para discutir com Ning Xiaoxiao. Só queria voltar logo aos aposentos e trocar de calças...

Então soltou um longo suspiro e cedeu, cheio de resignação. — Está bem. Pode cantar...

Ning Xiaoxiao jamais imaginara que conseguiria concluir uma missão tão difícil com tamanha facilidade.

Abriu um sorriso de boba, limpou a garganta e começou a cantar:

— Finalmente você encontrou uma maneira de decidir quem venceu...

Lu Linyuan: 【Você decidiu quem venceu, claro! Muito bonito! Que maravilha para você!】

— O preço da vitória ou da derrota foi deixar nós dois em pedaços...

Lu Linyuan: 【Eu é que fui despedaçado! Não bastasse isso, minhas calças também se rasgaram na virilha!】

...

— E assim fui conquistado por você... Bebi o veneno que você escondeu...

Lu Linyuan: 【Gostou de me atormentar, foi? Não bastou o espacate? Agora quer me envenenar e apunhalar pelas costas?!】

— Minha história chegou ao fim; meu amor e meu ódio foram enterrados...

Lu Linyuan: 【Não sei se seu amor e seu ódio serão enterrados. Mas sei que você vai acabar enterrada logo mais! Por minhas próprias mãos!】

Reclamar mentalmente era uma coisa; ele ainda precisava cantar. Caso contrário, Ning Xiaoxiao perceberia a calça rasgada, e ele morreria de vergonha!

Justamente quando chegaram ao refrão, Sanfu entrou acompanhado da imperatriz.

— Majestade, Sua Majestade, a imperatriz, disse que...

Assim que cruzaram a porta, a imperatriz e Sanfu ficaram petrificados.

A cena diante deles era surreal demais:

Lu Linyuan estava abrindo um espacate diante de Ning Xiaoxiao, cantando para ela com toda a força dos pulmões:

— “E assim fui conquistado por você...”

Até os dois corvos do palácio encarregados de dar o tom dramático, mesmo em pleno inverno rigoroso, tiveram de cumprir sua obrigação: pousaram num galho seco e começaram a grasnar.

(Nota da autora: Hoje foram três atualizações. Em 20/6, pedi licença e publiquei só um capítulo, não foi? Estou compensando hoje.)

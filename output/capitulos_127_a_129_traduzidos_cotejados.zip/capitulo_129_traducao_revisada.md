# Capítulo 129 — Homem durão tem que usar lacinho

A cabeça de Ning Xiaoxiao estava zunindo. Para ter certeza de que não sonhava, beliscou com força o braço de Sanfu.

— Aaah! Senhora Ning! O que está fazendo?! — Sanfu fez uma careta de dor e implorou para que parasse.

— Ah, então está tudo certo... Pode se retirar. Vou levar o médico extraordinário para tratar Sua Majestade.

Depois de dispensar Sanfu e ficar sozinha com o pai, Ning deu um pulo de tanta alegria.

— Seu velhote! O que você está fazendo aqui?!

Em casa, Ning nunca fizera cerimônia com Ning Dazhi. Agora, para confirmar que ele era real, começou a apalpá-lo sem parar.

— Desde quando você deixou crescer essa barba? A mamãe não dizia que, se você deixasse a barba crescer, ia ficar com mingau grudado nela quando comesse, e por isso não deixava?

Curiosa como uma criança, deu um puxão na barba cheia de Ning Dazhi. Só que não soube dosar a força: com um *rrrip*, arrancou metade dela.

— É... é falsa?

Ning Dazhi lançou-lhe um olhar irritado, afastou sua mão com um peteleco e, enquanto colava a barba de volta, resmungou: — Com esse seu jeito estabanado, não esperava que você sobrevivesse tanto tempo depois de entrar no romance...

Quando a euforia passou, Ning finalmente perguntou: — Pai, por que você também veio parar aqui? E... como é que um velhote cujo único entretenimento é assistir ao noticiário da TV sabe o que significa “entrar num romance”?

— Também conheço YYDS, *shuan Q*, *dame* e ainda... — Ning Dazhi deu um peteleco na testa da filha. — É de fazer qualquer um perder a paciência!

Apesar da felicidade, Ning Xiaoxiao achava tudo cada vez mais estranho.

Ning Dazhi usava roupas comuns da dinastia Qi, mas tanto a barba quanto os cabelos compridos eram falsos. Evidentemente, estava disfarçado.

Além disso, quando ela entrara no romance, sua consciência simplesmente ocupara o corpo da personagem original. Ning Dazhi, por outro lado, parecia ter atravessado inteiro, com corpo e tudo, do mundo moderno para a Antiguidade — e não demonstrava o menor nervosismo com a situação.

Para completar, a aparência da personagem cujo corpo Ning ocupava não era nem um pouco parecida com a sua. Como Ning Dazhi a reconhecera imediatamente?

Tinha tantas perguntas que estava prestes a despejá-las todas, mas Ning Dazhi cobriu-lhe a boca com a mão.

— Silêncio. Não temos tempo para explicações agora. Primeiro precisamos salvar meu genro.

Dizendo isso, arregaçou as mangas e entrou nos aposentos com a naturalidade de quem conhecia o caminho. Deixou Ning Xiaoxiao para trás, completamente perdida:

【Seu genro? Desde quando ele virou seu genro?! Ô, velhote, não começa a espalhar boato, não!】

O pai de Ning Xiaoxiao era um excelente cirurgião-chefe. Com ele ali, retirar a bala do corpo de Lu Linyuan seria brincadeira de criança.

Quando Ning entrou correndo nos aposentos, Ning Dazhi já havia organizado cuidadosamente os instrumentos cirúrgicos e estava desinfetando tudo com álcool.

Vendo a filha parada, olhando sem fazer nada, ele resmungou, impaciente: — Vai ficar só assistindo? Não consegue perceber o que precisa ser feito? Tire logo as bandagens dele!

Havia tanto tempo que o pai não brigava com ela... Antigamente, Ning odiava ouvir suas broncas. Só depois de passar tanto tempo longe de casa percebera como era bom ter os pais por perto, reclamando e falando em seus ouvidos.

Ela retirou cuidadosamente as faixas das costas de Lu Linyuan. Enquanto isso, Ning Dazhi estendeu a mão e deu duas palmadas sonoras no peito do imperador.

— Opa! Esse peitoral está muito bem trabalhado.

Talvez tivesse batido com força demais. Mesmo inconsciente, Lu Linyuan tossiu violentamente duas vezes, e o sangue voltou a escorrer da ferida nas costas.

Ning se apressou em impedi-lo: — Ah, pai! O que você está fazendo?!

— Ué? Já está preocupada com ele? — Ning Dazhi provocou. — Você pode apertar o peito dele, mas seu pai não pode dar umas palmadas?

O rosto de Ning ficou vermelho na mesma hora. Ela mordeu o lábio e respondeu, envergonhada: — Ah, pai, para de falar bobagem, eu... Hein?

De repente, percebeu uma coisa. Ergueu os olhos para Ning Dazhi, chocada. — Espera aí... Como você sabe que eu apertei o peito dele?

— Ah, isso... — Ning Dazhi gaguejou por um momento antes de rir. — Sua mãe vive apertando o meu. Você puxou a ela, é igualzinha.

Ning Xiaoxiao: “￣□￣｜｜” — Era mesmo necessário contar isso?

Todos os instrumentos cirúrgicos estavam desinfetados. Ning Dazhi começou a retirar a bala de Lu Linyuan.

Aplicou anestesia local, desinfetou a região ferida, ampliou a abertura com um bisturi e separou os tecidos aderidos. Graças às décadas de experiência médica, logo localizou a bala dentro da ferida.

Com uma pinça cirúrgica, retirou-a num movimento rápido, preciso e decidido. Depois comentou: — Esse rapaz tem sorte. Se o tiro tivesse entrado um pouquinho mais para o lado e atingido o pulmão, amanhã você já estaria indo ao funeral.

Durante todo o procedimento, Ning Xiaoxiao observou sem respirar direito. Sem perceber, amassou tanto a barra da própria saia que ela ficou coberta de vincos.

Ning Dazhi olhou de lado para ela. — Você se importa muito com ele?

— Não — Ning respondeu, tentando parecer tranquila. — Ele ficou assim porque levou um tiro para me proteger. Por uma questão de gratidão e de consciência, quero que se recupere.

— Sei... — O olhar perspicaz de Ning Dazhi parecia enxergar tudo. Ele comentou, cheio de segundas intenções: — Tomara que seja só isso!

Ning mudou de assunto. — Pai, você teve que abrir uma ferida enorme nas costas dele. Vai ficar cicatriz, não vai?

— Não tem como evitar. No máximo, posso fazer uma sutura bonita.

Passou o fio de sutura de tripa de carneiro pela agulha e começou a costurar a pele das costas de Lu Linyuan, ponto por ponto, com o cuidado de quem bordava um tecido.

Ning achou o quarto um pouco escuro e perguntou: — Velhote, você está enxergando bem sem os óculos? Quer que eu acenda mais duas velas?

— Não precisa, não. Dá trabalho. — Ning Dazhi se virou, tirou da mochila uma pequena luminária das *Fadinhas Mágicas Balala*, colocou-a ao lado da cama e apertou o botão. Num instante, o quarto ficou intensamente iluminado.

Ning Xiaoxiao arregalou os olhos. — Mas... essa não é a luminária que eu usava quando era criança? Lembro que dava até para escolher sete cores de luz!

Fazia tanto tempo que não via um aparelho moderno que ficou inexplicavelmente animada. Apertou o botão de ajuste e ativou o modo em que as sete cores piscavam alternadamente.

Ao ver as luzes mudando diante de seus olhos, sentiu por um momento como se tivesse voltado à infância.

Quando começara a dormir sozinha, fechava a porta do quarto todas as noites, ligava aquela luminária no modo multicolorido, jogava um lençol nos ombros e, segurando uma caneta com enfeite de varinha mágica, fingia ser uma das fadinhas sobre a cama.

Ela ainda estava perdida nas lembranças quando ouviu o pai reclamar, num tom indignado:

— Eu aqui dando pontos e você fazendo uma balada? Você acha isso educado?

— ...

Uns dez minutos depois, a sutura estava terminada. Ning Dazhi bateu as mãos e começou a guardar os instrumentos. — Prontinho!

Ning se aproximou para examinar a ferida nas costas de Lu Linyuan e descobriu que aquele pai sem-vergonha tinha costurado... um laço de fita?

— “???” Pai! Você fez a sutura desse jeito? Quando sarar, a cicatriz não vai ficar em forma de lacinho? Mas isso...

— Qual é o problema? Um homem durão também amarra o cadarço em forma de laço, não amarra?

Ning Dazhi explicou com toda a seriedade: — Além do mais, a cicatriz fica nas costas. Ele nem vai conseguir vê-la. Quando vocês tirarem a roupa para fazer aquelas coisas que elevam o amor a outro patamar, não vai ser você a única a olhar? Se é para minha filha ver, é claro que vou costurar um desenho de que minha filha goste.

— ...

O pior é que o raciocínio dele fazia tanto sentido que eu nem conseguia contestar...

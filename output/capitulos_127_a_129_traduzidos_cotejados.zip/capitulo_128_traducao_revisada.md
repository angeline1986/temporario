# Capítulo 128 — Eu sou seu pai

Com Ning Xiaoxiao ao seu lado, a respiração irregular de Lu Linyuan foi se estabilizando aos poucos, e o suor em seu corpo diminuiu.

Os médicos imperiais haviam lhe administrado uma decocção para aliviar a dor. Por enquanto, sua vida não corria perigo imediato.

A imperatriz-viúva ainda aguardava uma resposta do lado de fora. Por ora, Ning só podia tentar ganhar um dia de cada vez.

Ela estava prestes a sair para dar satisfações quando, ao chegar à porta, ouviu a imperatriz-viúva dando ordens a Sanfu.

— Vá libertar o príncipe ocidental. Não podemos ofender o Ocidente, ou eles podem deixar de nos vender armas de fogo e ainda vir criar problemas para Da Qi.

Sanfu já ia obedecer e seguir até a prisão quando Ning Xiaoxiao escancarou a porta dos aposentos.

Abriu-a com tamanha força que o estrondo contra o batente fez todos no salão estremecerem.

Todos se voltaram para ela. A imperatriz-viúva ia perguntar pelo estado de Lu Linyuan, mas Ning se antecipou e gritou para Sanfu:

— Não vai soltar ninguém!

Sanfu ficou imóvel, como se tivesse os pés presos ao chão, sem saber se avançava ou recuava.

A imperatriz-viúva lhe lançou um olhar atravessado. — Ousa impedir o cumprimento de uma ordem minha?

Ning Xiaoxiao não suportava aquela velha insuportável, cuja cabeça parecia ter sido tão apertada pelos costumes feudais quanto os pés das mulheres pelas antigas faixas.

【Já rompi com ela mesmo. Se agora eu bancar a respeitosa, não vai fingir que nada aconteceu. Em vez de andar de rabo entre as pernas, é melhor enfrentá-la até o fim. E, quando Xiao Qi voltar, por que eu teria medo dessa velha que não morre nunca?】

Seu rosto estava frio. Sua presença parecia até mais imponente que a da imperatriz-viúva.

— Por maior que seja a autoridade de Vossa Majestade, ela não está acima dos decretos do imperador. Sua Majestade despertou por um instante. Assim que abriu os olhos, ordenou que eu não deixasse o príncipe ocidental nem seus acompanhantes serem libertados.

— E só porque você diz que foi uma ordem do imperador, temos de acreditar?

— Se não acredita, pode continuar dando ordens. Mas o harém não deve interferir nos assuntos de Estado. Se Vossa Majestade pretende decidir questões da corte, é melhor considerar se pode assumir as consequências. Se libertarmos o príncipe agora e ele espalhar a notícia de que o imperador está gravemente ferido, Da Qi ficará sem um líder em condições de governar. Não estaremos dando a gente mal-intencionada a oportunidade perfeita para se aproveitar da situação?

Aquelas palavras bastaram para calar a imperatriz-viúva.

Depois de refletir, ela também achou que Ning tinha razão. Mas, por orgulho, jamais admitiria isso em voz alta.

Manteve a expressão gelada e apenas mudou de assunto: — Estou perguntando quando o imperador vai acordar.

— Em três dias.

A imperatriz-viúva não disse mais nada. Cravou um último olhar feroz em Ning Xiaoxiao e partiu levando a imperatriz e as outras mulheres.

Naquele momento, observando-a se afastar, Ning finalmente entendeu por que a relação de Lu Linyuan com a própria mãe era tão ruim.

Desde o princípio, ela parecia preocupada com o filho. Mas o que realmente lhe importava era o poder supremo do trono.

Ning Xiaoxiao passou o restante daquele dia no Terraço Tonghua, acompanhando Lu Linyuan.

As consortes dos diversos palácios tentaram aparecer uma a uma para demonstrar solicitude, mas Sanfu barrou todas na porta.

A cada poucos minutos, Ning tentava entrar em contato com Xiao Qi. Nunca conseguia.

Os médicos haviam sido claros: no estado em que se encontrava, Lu Linyuan aguentaria no máximo três dias. Se Xiao Qi não retornasse da licença médica nesse prazo, ele não estaria condenado à morte?

Assim, Ning precisou se preparar para o pior.

Se Xiao Qi ainda não tivesse voltado no dia seguinte, ela teria de encontrar uma maneira de retirar a bala do corpo dele.

Só assim haveria alguma possibilidade de a ferida cicatrizar.

Os médicos imperiais raramente recorriam a cirurgias. Preferiam tratar os ferimentos sem abrir o corpo.

Além disso, os costumes antigos ensinavam que o corpo, a pele e os cabelos eram dádivas dos pais. Pedir àqueles médicos que abrissem Lu Linyuan para retirar a bala era quase impensável.

Mas, entre os médicos do povo, as regras não eram tão rígidas.

Ning mandou chamar Sanfu e ordenou: — Dos condenados que estão na prisão, escolha alguns que não tenham matado ninguém, apenas cometido crimes como corrupção e recebimento de subornos. Traga-os aqui. E traga também a pistola que disparou nas mãos do príncipe ocidental hoje.

Os homens mantidos na ala dos condenados à morte, como o nome dizia, já haviam recebido sentença de execução.

Sanfu estranhou, mas cumpriu as ordens de Ning Xiaoxiao.

Os guardas trouxeram três prisioneiros que não tinham cometido assassinato e aguardavam a execução principalmente por crimes de corrupção. Os três se ajoelharam no pátio e olharam para Ning, perplexos.

Ela disse: — Vocês cometeram crimes puníveis com a morte. Hoje posso lhes dar uma chance de começar de novo. Aceitar ou não depende de vocês.

Os três trocaram olhares e assentiram juntos.

Ning caminhou para trás deles, pegou a pistola das mãos de Sanfu, apontou-a à região da omoplata direita de cada um e disparou à distância.

Ouviram-se três tiros. Dois homens ficaram com ferimentos semelhantes ao de Lu Linyuan; no terceiro, Ning errou a mira, e ele morreu na hora.

Sanfu ficou estarrecido. — Mas... senhora Ning, está usando esses homens como alvos de tiro?

Ela devolveu a pistola a Sanfu. — Enterre o que morreu. Leve os dois que ainda respiram para fora do palácio e ofereça uma recompensa generosa. Quem conseguir retirar as balas sem matá-los receberá mil taéis de ouro.

Só então Sanfu compreendeu: Ning estava, na verdade, tentando encontrar um médico extraordinário entre o povo para salvar Lu Linyuan.

Em outras palavras, o estado do imperador era tão grave que nem ela sabia como tratá-lo.

Sanfu servia Lu Linyuan desde pequeno, e os dois tinham uma ligação profunda de senhor e servo. Tudo que dizia respeito ao imperador era assunto de máxima importância para ele.

A notícia do grave ferimento não podia vazar. O método de Ning para encontrar alguém habilidoso era brutal, mas, naquele momento, parecia a melhor alternativa de que dispunham.

Sanfu imaginara que, se nem os médicos imperiais conseguiam tratar o ferimento, talvez uma recompensa exorbitante não atraísse ninguém capaz. Para sua surpresa, mal o anúncio foi publicado e alguém se apresentou.

Era um homem de meia-idade, alto e magro, com uma barba cheia que lhe cobria as faces. Tinha um certo ar de sábio errante.

Ninguém sabia como conseguira, mas, em menos de duas horas, retirou as balas dos corpos dos dois condenados.

Sanfu quis levá-lo imediatamente ao palácio, mas ele pediu: — Este humilde homem contraiu um leve resfriado. Se for realmente necessário entrar no palácio e apresentar-me diante de Sua Majestade, peço permissão ao senhor eunuco para cobrir o rosto com um véu e não transmitir a doença às pessoas nobres.

Quando Sanfu o trouxe ao Terraço Tonghua naquela noite, Ning Xiaoxiao reparou que ele usava um chapéu de palha e cobria o rosto com um véu. A aparência suspeita a fez ficar alerta. Em vez de deixá-lo entrar diretamente, perguntou:

— Sanfu diz que o senhor é um médico extraordinário. Com quem aprendeu medicina?

O homem respondeu: — Não posso revelar minha linhagem de mestres a muita gente. Minha senhora, podemos conversar a sós por um instante?

Ning se aproximou um pouco. O homem inclinou a cabeça para seu ouvido e disse, com voz grave:

— Eu sou seu pai.

Ning Xiaoxiao: “???”

【Ah, não! Vai querer tirar uma com a minha cara?】

Ela lhe deu um tremendo tapa. O chapéu do homem chegou a cair. Ainda mais irritada, retrucou:

— Seu pai é que sou eu!

— Sanfu, prenda esse...

Ia mandar Sanfu deter aquele sujeito desrespeitoso, mas, ao enxergar a metade superior do rosto dele, tão familiar, ficou paralisada de susto.

Diante do olhar “furioso” do homem, estendeu a mão trêmula e retirou o véu que lhe cobria o rosto.

Puta merda!!

É... é... é mesmo o meu pai de verdade?!

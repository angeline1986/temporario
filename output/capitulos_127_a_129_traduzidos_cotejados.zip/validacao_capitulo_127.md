# Validação — capítulo 127

- **Fonte:** `novel_capitulos_121_a_180(20261103-233558).docx` (chinês tradicional, DOCX original).
- **Limites:** índices de parágrafo do DOCX de 424 a 494, zero-based; capítulo seguinte excluído.
- **Unidades não vazias:** 68, incluindo título e demais unidades textuais.
- **Unidades do CSV:** 68; **índices ausentes:** 0; **índices duplicados:** 0; **campos vazios:** 0.
- **Cotejo:** uma linha para cada parágrafo não vazio, com índice real do DOCX, texto chinês e tradução correspondente.
- **Revisão:** tradução integral com leitura da fonte, alinhamento 1:1 e verificação programática de integridade. **Não constitui segunda auditoria semântica independente integral**.

## Notas editoriais e cuidados

- Título 殺母奪子 significa matar a mãe para tomar seu filho; a ameaça é planejada em conversa, não executada neste capítulo.
- A imperatriz-viúva declara sua intenção de fazer Ning morrer de hemorragia após o parto; isso é plano de personagem, não acontecimento confirmado.
- Ning considera que Lu Linyuan pode tê-la protegido por causa do suposto herdeiro; o narrador confirma que ele já conhecia a natureza da falsa gravidez e agiu para protegê-la.
- O capítulo termina numa reflexão do narrador sobre o instinto de Lu Linyuan, sem afirmar que Ning reconheceu seus sentimentos.

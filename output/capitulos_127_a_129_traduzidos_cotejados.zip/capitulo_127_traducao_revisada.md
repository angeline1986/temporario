# Capítulo 127 — Matar a mãe e tomar-lhe o filho

Da última vez, quando a epidemia assolara o palácio, todos os médicos imperiais haviam ficado de mãos atadas. Fora Ning Xiaoxiao quem conseguira reverter a situação. Isso era verdade.

Ao se lembrar do ocorrido, a imperatriz-viúva afrouxou os dedos que apertavam sua bengala com cabeça de fênix. Baixou os olhos estreitos e apagados, refletiu por alguns instantes e disse: — Muito bem. Permitirei que tente. Mas, se não conseguir curar o imperador, não pense que deixarei o que aconteceu hoje passar em branco!

Ning Xiaoxiao não lhe deu atenção. Entrou diretamente nos aposentos e fechou a porta.

Assim que saiu, todas as consortes começaram a comentar sua arrogância e insolência: usava o filho como escudo e não respeitava ninguém.

A imperatriz-viúva não suportava aquela tagarelice. Levou a mão à testa e franziu as sobrancelhas.

A imperatriz dispensou as demais e ficou sozinha para cuidar dela.

Serviu-lhe uma xícara de chá e a consolou: — É verdade que a Dama Ning se comportou mal. Mas o herdeiro imperial que carrega no ventre é seu salvo-conduto. Mãe, considere que ela ainda é uma criança imatura. Não vale a pena se aborrecer tanto e prejudicar a própria saúde.

A imperatriz-viúva soltou um riso frio. — Quer ela consiga curar o imperador, quer não, jamais permitirei que uma feiticeira capaz de confundir a cabeça do soberano permaneça ao lado dele!

A imperatriz assumiu uma expressão pesarosa e insinuou com cuidado: — Só podemos pedir aos céus que protejam Sua Majestade e o façam sobreviver. Mas, se acontecer o pior... o filho no ventre da Dama Ning será seu único sucessor. Ela veio de uma condição muito humilde; quem foi oprimido durante muito tempo costuma guardar rancor. Se um dia se tornar imperatriz-viúva, quem sabe como se vingará de ter sido repreendida publicamente pela senhora hoje...

— Ah! Ela, imperatriz-viúva? Só nos sonhos! Tomara que o imperador fique bem. Mas, se algo acontecer com ele, acha mesmo que eu a deixaria viver?

A imperatriz-viúva tomou a mão da imperatriz e falou com uma intenção bastante clara nas entrelinhas: — Nunca gostei de pessoas desobedientes. Você, por exemplo, sabe obedecer; por isso gosto de você. Grave bem: a dinastia Da Qi terá uma única imperatriz, você. E, não importa de quem seja o filho que um dia suba ao trono, a imperatriz-viúva será você também.

A imperatriz era inteligente. Entendeu perfeitamente, mas fingiu confusão. — Mãe, a senhora quer dizer...?

A proteção dourada da unha do dedo mínimo da imperatriz-viúva roçou de leve o dorso da mão dela. Sua voz saiu baixa e severa: — Conservaremos quem me agrada e eliminaremos quem me desagrada. Ning tem sorte, é verdade. Mas essa sorte só durará até dar à luz o herdeiro. Quando o imperador se recuperar e ela tiver a criança, morrerá de uma hemorragia no parto. Então você, senhora do Palácio Central, será a única mãe legítima do herdeiro. Entendeu o que estou dizendo?

Matar a mãe para tomar-lhe o filho era uma crueldade sinistra. Como a imperatriz, mestra em esconder veneno atrás de palavras piedosas, não compreenderia?

Ela sorriu e fez uma reverência à imperatriz-viúva. — Obrigada, mãe, por pensar tão cuidadosamente no meu futuro.

* * *

Os aposentos estavam aquecidos e silenciosos. Os estalos das brasas no braseiro quase abafavam a respiração fraca de Lu Linyuan.

Ele jazia de lado na cama, com a parte superior do corpo parcialmente descoberta. Uma fina camada de suor cobria seus músculos esculpidos, tornando seus contornos ainda mais marcantes.

Faixas brancas envolviam suas costas. O sangue vivo que as manchava desenhava uma flor de lótus vermelha, dolorosa até de olhar.

O coração de Ning Xiaoxiao estremeceu.

A imagem daquele instante crítico não parava de voltar à sua mente: Lu Linyuan surgindo diante dela de repente, como uma muralha erguida para protegê-la.

A dinastia Qi importava armas de fogo do Ocidente havia muito tempo. Lu Linyuan conhecia perfeitamente seu poder de destruição.

Portanto, no instante em que não havia tempo sequer para reagir, talvez ele tivesse levado apenas 0,1 segundo para decidir.

E sua decisão fora se colocar diante de Ning Xiaoxiao para protegê-la, mesmo sabendo que poderia morrer por isso.

Ning Xiaoxiao, que lera a obra original inteira, simplesmente não conseguia compreender. Como um homem tão calculadamente egoísta seria capaz de se sacrificar por alguém sem esperar nada em troca?

Afinal, no romance original, cada passo de Lu Linyuan era ditado por planos e interesses.

Se até uma fênix só pousava onde havia tesouros, o que dizer dele, um dragão que sobrevoava os nove céus?

Por um instante, ocorreu-lhe a possibilidade de que ele tivesse se apaixonado por ela.

Mas logo descartou a ideia.

Ela era bonita, sem dúvida, mas o harém estava cheio de mulheres igualmente belas e delicadas.

Além disso, ele tinha Gu Sijin, seu par romântico oficial. Por que se apaixonaria por uma mulher atrapalhada e engraçadinha como ela?

Então, o motivo mais provável para tê-la protegido naquele dia era o suposto “herdeiro imperial” em seu ventre.

Entretanto, quaisquer que fossem os motivos dele, o fato era que arriscara a vida para salvá-la.

Ela não podia ficar devendo uma vida a ele.

Chamou Xiao Qi desesperadamente em sua mente, apertando tanto o botão do documento acinzentado que quase o destruiu. Mas era tudo inútil.

Quando já estava tomada pela ansiedade e pelo desamparo, pareceu ouvir Lu Linyuan murmurar durante o sono.

— Ning Xiaoxiao...

Ele... estava chamando seu nome?

Ning Xiaoxiao se aproximou e respondeu baixinho: — Majestade, estou aqui.

— Vai ficar aqui... o tempo todo?

Ela hesitou por dois segundos, segurou a mão dele e respondeu com firmeza:

— O tempo todo.

— Então fique... longe de mim... Tenho medo de... pegar sua burrice...

Ning Xiaoxiao: “???”

【Mas olha só! Está quase dando o último suspiro e nem sonhando consegue deixar de me zoar?】

Mesmo assim, não soltou a mão que ela própria havia tomado.

Entrelaçou delicadamente os dedos aos dele e falou num sussurro:

— Lu Linyuan, vou salvar você. Não vou deixar que morra.

— Aguente firme. Só preciso que me dê um pouco mais de tempo. Assim que Xiao Qi voltar, vou conseguir salvá-lo.

— Você não é o homem que mais se importa com o próprio império? Não foi pelo herdeiro em meu ventre que me protegeu hoje?

— Pois vou lhe contar uma coisa: não existe filho seu na minha barriga. Eu não estou grávida.

— Então é obrigado a aguentar e acordar. Senão, ficará sem sucessor, e outra dinastia acabará tomando o lugar da Qi.

Lu Linyuan conseguia ouvi-la.

Ela achava que ele a havia protegido por causa do herdeiro imperial, sem saber que Lu Linyuan conhecia havia muito tempo a verdadeira natureza do que havia no ventre dela.

O gesto dele, portanto, não tivera motivação egoísta nem nascera de algum grande plano para proteger a sucessão do império.

Ele simplesmente quisera protegê-la.

Entre tomar a decisão e se mover para aparar o disparo, num gesto contínuo e instintivo, mal tivera tempo de pensar.

Tudo parecera muito mais uma reação natural.

Mas, diante do perigo, a primeira ordem instintiva que o cérebro costuma dar é proteger a própria vida.

Portanto...

Talvez houvesse algum problema sério com o cérebro de Lu Linyuan. Alguma doença grave, mesmo.

Ele contrariara seu instinto e dera a ordem de se destruir para salvar outra pessoa.

Ou talvez, lá no fundo de seu inconsciente, aquela mulher tivesse se tornado, sem que ele percebesse, mais importante do que ele próprio.

Ning Xiaoxiao já ouvira uma declaração de amor daquelas capazes de deixar qualquer mulher suspirando:

“Vou contrariar minha natureza, desobedecer aos meus instintos e amar você para sempre.”

O que ela não sabia era que, quando se tratava de amor, não deveria existir necessidade alguma de contrariar ou desobedecer.

Porque, para ele, ela própria havia se tornado um instinto.

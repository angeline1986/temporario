# Validação — capítulo 129

- **Fonte:** `novel_capitulos_121_a_180(20261103-233558).docx` (chinês tradicional, DOCX original).
- **Limites:** índices de parágrafo do DOCX de 565 a 627, zero-based; capítulo seguinte excluído.
- **Unidades não vazias:** 60, incluindo título e demais unidades textuais.
- **Unidades do CSV:** 60; **índices ausentes:** 0; **índices duplicados:** 0; **campos vazios:** 0.
- **Cotejo:** uma linha para cada parágrafo não vazio, com índice real do DOCX, texto chinês e tradução correspondente.
- **Revisão:** tradução integral com leitura da fonte, alinhamento 1:1 e verificação programática de integridade. **Não constitui segunda auditoria semântica independente integral**.

## Notas editoriais e cuidados

- O pai Ning Dazhi atravessou aparentemente com o próprio corpo, segundo a perspectiva de Ning; o mecanismo ainda não é explicado.
- Expressões de internet YYDS, 拴Q e 達咩 foram preservadas e transliteradas, sem inventar um significado contextual que o original não explicita.
- A luminária 巴啦啦小魔仙 remete à série infantil chinesa Balala the Fairies; «Fadinhas Mágicas Balala» é adaptação identificável.
- O texto descreve procedimento cirúrgico ficcional; não constitui orientação clínica. O laço é intencionalmente cômico.

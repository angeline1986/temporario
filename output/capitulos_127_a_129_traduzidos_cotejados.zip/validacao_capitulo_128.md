# Validação — capítulo 128

- **Fonte:** `novel_capitulos_121_a_180(20261103-233558).docx` (chinês tradicional, DOCX original).
- **Limites:** índices de parágrafo do DOCX de 495 a 564, zero-based; capítulo seguinte excluído.
- **Unidades não vazias:** 67, incluindo título e demais unidades textuais.
- **Unidades do CSV:** 67; **índices ausentes:** 0; **índices duplicados:** 0; **campos vazios:** 0.
- **Cotejo:** uma linha para cada parágrafo não vazio, com índice real do DOCX, texto chinês e tradução correspondente.
- **Revisão:** tradução integral com leitura da fonte, alinhamento 1:1 e verificação programática de integridade. **Não constitui segunda auditoria semântica independente integral**.

## Notas editoriais e cuidados

- Ning atribui ao imperador uma ordem para manter o príncipe preso, mas não há confirmação narrativa de que o imperador tenha despertado para dar tal ordem; preservar caráter de alegação.
- A cena dos presos é brutal: Ning os fere com uma arma para replicar o ferimento do imperador; um deles morre. Não se trata de tratamento médico recomendado.
- 「一個時辰」 equivale aproximadamente a duas horas; foi traduzido por «menos de duas horas».
- O médico revela «我是你爹» e Ning responde insultando-o da mesma maneira antes de reconhecer o rosto do pai; preservar a virada de humor.

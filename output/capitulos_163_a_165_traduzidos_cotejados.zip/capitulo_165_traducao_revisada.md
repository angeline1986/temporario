# Capítulo 165 — Eu bati na sua esposa

Não havia nada mais satisfatório do que acompanhar uma história ou série em que os protagonistas se vingavam lindamente. Quer dizer, havia sim: ver aquela cena acontecer bem diante de seus olhos.

Ning Xiaoxiao se deliciou com o espetáculo e suspirou de admiração em pensamento:

【Irmã, que mulher poderosa! Eu te amo! Virei fã de carteirinha!!!】

No romance original, a princesa Qingyang era uma figura digna de pena.

Para pôr fim a uma guerra, o imperador anterior a mandara casar-se por aliança política no Reino Zhuyin. Por razões desconhecidas, ela perdera a capacidade de ter filhos naquele lugar. Naturalmente, perdeu também a posição de esposa principal e acabou rebaixada a concubina do soberano de Zhuyin.

Mais tarde, quando o soberano morreu, mandaram-na de volta à dinastia Qi por não ter descendentes. Nunca mais se casou.

No mundo moderno, não eram poucos os casais jovens que optavam por não ter filhos, e ninguém ficava apontando o dedo para julgá-los.

Mas, na antiguidade, uma mulher incapaz de engravidar era considerada como se tivesse perdido metade da própria vida. Seria desprezada aonde quer que fosse.

Embora a princesa Qingyang aparecesse pouco na obra original, Ning Xiaoxiao nunca esquecera aquela pobre mulher cuja vida fora destruída pelo sistema feudal.

Quem diria, porém, que a princesinha frágil e delicada que Ning imaginava seria, na verdade, uma mulher madura, dominadora e incrivelmente poderosa?

Enquanto a contemplava, distraída, Xiao Qi apareceu de repente:

【Bip, bip, bip! Parabéns, anfitriã, você concluiu a missão “Fazer com que a imperatriz leve um baita tabefe diante de todo mundo”.】

【Recompensa: mais 2 pontos percentuais no índice de desvio da trama. Índice acumulado atual: 32%.】

Ning Xiaoxiao ficou boquiaberta: 【Mas eu nem bati nela! Como é que...?】

Xiao Qi: 【Você foi reprovada no vestibular, anfitriã? Preste atenção no enunciado! A missão era fazer com que ela LEVASSE um tabefe, não dizia que você tinha que dar o tapa! Quando era para bater no tirano, você sabia muito bem usar os outros de bode expiatório. Por que ficou burra justo na vez da imperatriz?】

Ou será que havia outra possibilidade? Talvez não estivesse sendo burra: talvez quisesse mesmo acertar a imperatriz com dois belos tapas por conta própria.

De qualquer maneira, alguém concluíra a missão por ela, ainda que por coincidência. Ning Xiaoxiao ficou radiante, e sua admiração por Qingyang disparou.

A imperatriz, que acabara de levar duas bofetadas, estava furiosa e humilhada. Mas Qingyang era a grã-princesa, e seu retorno de um casamento diplomático fazia dela uma espécie de benfeitora da dinastia Qi. Por razões políticas e familiares, nem mesmo a imperatriz ousava fazer-lhe alguma coisa.

Uma das presentes, porém, não suportou. A Consorte Yun era muito próxima da imperatriz e protestou, indignada: — Como a grã-princesa pode bater na imperatriz? Sua Majestade ocupa o palácio central e é a mãe da nação! A senhora...

— Prefere que eu bata em você? — Qingyang lançou-lhe um olhar cortante. Sua presença esmagadora fez a Consorte Yun congelar de medo. Ela não ousou soltar nem mais um pio.

A imperatriz cobriu o rosto e começou a soluçar baixinho.

Qingyang observou-a de alto a baixo com profundo asco. — Ouça bem: trate de abandonar essas intrigas sórdidas. Para agradar à imperatriz-viúva, imaginou que, depois de ser enviada para um casamento político, eu nunca mais voltaria ao palácio. Então sugeriu a ela que a tabuleta memorial de minha mãe fosse transferida para o Templo Taigu? Está querendo morrer?

A imperatriz conteve as lágrimas. — Grã-Princesa, houve um engano. Não tive nada a ver com isso...

— Engano? Isto aqui não é um tribunal, e eu não sou magistrada para ficar ouvindo suas desculpas.

Qingyang franziu as sobrancelhas e estreitou os olhos, fitando-a de maneira ameaçadora. — Você tem três dias para devolver a tabuleta memorial de minha mãe ao mausoléu do falecido imperador.

Fez uma pausa e espetou duas vezes a têmpora da imperatriz com seus dedos finos e delicados. Sua voz ficou feroz:

— Caso contrário, farei toda a família Zhu entrar em fila na latrina todos os dias para comer um quilo de merda por cabeça!

Depois da ameaça, soltou uma risada fria e se virou para sair.

Por onde passava, nenhuma das consortes ousava erguer a cabeça para encará-la.

Ao chegar perto de Ning Xiaoxiao, no entanto, deteve-se. Após encará-la por alguns instantes, estendeu a mão e ergueu-lhe o queixo.

Suas unhas compridas e delicadas, sem protetores ornamentais, roçaram a pele macia de Ning Xiaoxiao. Não chegava a doer, apenas fazia cócegas.

Depois de examiná-la por um bom tempo, perguntou: — Foi você que fez a imperatriz-viúva desmaiar de raiva?

Intimidada pela presença de Qingyang, Ning Xiaoxiao fitou aqueles olhos astutos. Parecia impossível mentir diante deles.

Acabou assentindo sem pensar. Para sua surpresa, Qingyang sorriu. — Bonita e ainda sabe fazer coisas que me agradam. Gostei de você.

Dito isso, puxou Ning Xiaoxiao pelo braço e a levantou da cadeira, deixando-a desnorteada. — A neve parou. Venha dar uma volta comigo.

Mal tinham dado dois passos quando Gu Sijin se levantou e segurou também o pulso de Ning Xiaoxiao.

Gu Sijin não sabia muito a respeito da grã-princesa Qingyang, mas vira que aquela mulher ousava bater até na imperatriz. Não podia ser alguém com quem se brincasse.

Temendo que Ning Xiaoxiao fosse maltratada, apertou os lábios e reuniu toda a coragem para dizer: — Grã-Princesa, a Nobre Senhora Hua sofreu um aborto há pouco tempo. Não convém que se exponha ao frio. Receio que não possa acompanhá-la num passeio pelos jardins.

Qingyang pousou seus dedos longos e finos sobre o pulso de Gu Sijin e, num movimento brusco, afastou-lhe a mão. — Vai sentada na liteira. Não vai morrer congelada.

Ning Xiaoxiao foi praticamente arrastada para fora do Palácio Fengluan. Preocupada com Gu Sijin, gritou da entrada: — Irmã, não se preocupe! A grã-princesa não tem más intenções!

Fora do palácio, Qingyang praticamente a empurrou para dentro da própria liteira. Depois, atirou-lhe uma bolsa de água quente que uma criada acabara de entregar, mandando-a segurá-la junto ao corpo.

Quando a liteira começou a andar, perguntou friamente: — Como sabe que não tenho más intenções?

Ning Xiaoxiao respondeu: — Porque a grã-princesa odeia a imperatriz-viúva e a imperatriz! De todo o harém, ninguém tem intenções piores que aquelas duas. A senhora as odeia, eu também as odeio. Como eu não tenho más intenções, é claro que a senhora também não tem!

— Hahaha! — Qingyang riu abertamente, sem cerimônia. Havia em seus gestos uma liberdade ousada, quase de um jovem despreocupado. — Você realmente não tem amor à própria vida. Mora no harém e ainda se atreve a ofendê-las? Acha que vai conseguir viver em paz?

Ning Xiaoxiao respondeu: — Quer eu as ofenda ou não, elas encontram alguma coisa para me atormentar todos os dias. Que diferença faz?

Qingyang sorriu de leve, sem responder.

Por um instante, teve a impressão de enxergar em Ning Xiaoxiao a pessoa que ela mesma fora no passado.

Há momentos em que encontramos em alguém um reflexo de nós mesmos.

Mas, infelizmente, a sombra só se alonga atrás de nós. Quando conseguimos reconhecê-la, significa que já caminhamos um longo trecho e não somos mais quem éramos antes.

*

Para surpresa de Ning Xiaoxiao, Qingyang não a levou para passear coisa nenhuma. Conduziu-a diretamente ao Palácio Chaoyang.

Quando as duas entraram, Lu Linyuan estava examinando memoriais oficiais. Ao ouvir o movimento, ergueu os olhos. Surpreendeu-se ao ver Qingyang acompanhada de Ning Xiaoxiao, mas logo recuperou a expressão habitual e sorriu para a princesa:

— Irmã mais velha, você voltou.

Qingyang respondeu brevemente. Sabia que o episódio no Palácio Fengluan acabaria chegando aos ouvidos de Lu Linyuan. Por isso, resolveu contar-lhe primeiro:

— Preciso avisar Sua Majestade de uma coisa. Acabei de bater na sua esposa.

— ...

O sorriso desapareceu imediatamente do rosto de Lu Linyuan, e a irritação tomou conta de suas feições.

Desde pequenos, ele e Qingyang sempre haviam tido uma relação muito próxima. Mas, ao ver Ning Xiaoxiao encolhida timidamente atrás da irmã, não conseguiu conter a raiva.

Sua voz saiu baixa e pesada, quase sílaba por sílaba: — Repita o que disse.

Qingyang não se intimidou nem um pouco com sua autoridade imperial. Respondeu tranquilamente:

— Eu disse que bati na sua imperatriz.

— ...

— Cof, cof... Ah, na imperatriz. — Lu Linyuan soltou um longo suspiro de alívio. O sorriso voltou a seus lábios.

— Ah, então não tem problema.

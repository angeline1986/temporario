# Capítulo 163 — A imperatriz-viúva virou boazinha?

Com a chegada do inverno rigoroso, o clima da capital ficava cada vez mais frio.

A imperatriz sempre fora generosa e, por isso, simplesmente dispensou as visitas de cortesia matinais e vespertinas de todo o harém.

Mas, como nora, ela não se poupava a esforços: mesmo sob uma nevasca de flocos grandes como penas de ganso, insistia em ir diariamente ao Palácio Shoukang prestar seus respeitos à imperatriz-viúva.

Pensando bem, já fazia algum tempo que a imperatriz-viúva se mudara para o Palácio Shoukang.

No início, fizera escândalo e se recusara a comer. Desmaiara duas vezes de fome e nem assim conseguira arrancar de Lu Linyuan uma palavra de preocupação. Nos últimos dias, passara a atirar para fora tudo o que havia no palácio e a gritar que podiam muito bem deixar aquela velha morrer congelada no Shoukang.

Na verdade, embora morasse no Palácio Shoukang, ocupava o salão principal, tão espaçoso quanto o do Palácio Xianshou.

O que sempre a incomodara era a questão de status.

Ela, a digníssima imperatriz-viúva, obrigada a dividir uma residência com as consortes viúvas! Não era o mesmo que permitir às mulheres que derrotara nas disputas do harém assistir de camarote à sua humilhação?

Quando a imperatriz chegou, por coincidência uma colcha acolchoada de seda bordada de Suzhou voou pela janela treliçada, lançada pela imperatriz-viúva, e caiu a seus pés.

A imperatriz fez um sinal a Xiangling para que apanhasse a colcha. Depois, tomou-a nos braços, entrou no salão e ordenou que todos aguardassem do lado de fora.

Ao vê-la, a imperatriz-viúva se acalmou um pouco.

A imperatriz estendeu a colcha sobre o leito, sacudiu a neve acumulada e a aconselhou com delicadeza:

— Mãe, não se irrite tanto. Acabará fazendo mal à própria saúde.

A imperatriz-viúva perguntou: — O imperador continua indo todos os dias ao Palácio Zhongcui para ficar com aquela Ning?

— A Nobre Senhora Hua sofreu um aborto há pouco tempo. É jovem e delicada; é natural que fique mais sensível depois de passar por isso. É justo que Sua Majestade lhe faça companhia — respondeu a imperatriz, com um sorriso tingido de amargura.

A imperatriz-viúva bufou: — Justo? Como assim, justo? Você é a imperatriz! Há quanto tempo ele não lhe faz companhia?

A imperatriz respondeu com humildade serena, como se aquilo não a preocupasse nem um pouco: — O primeiro dever de uma consorte é servir bem a Sua Majestade. Se ficar ao lado da Nobre Senhora Hua o deixa feliz, não importa se eu consigo vê-lo ou não.

Vendo que seus olhos estavam vermelhos, embora ainda sorrisse, a imperatriz-viúva sentiu pena e segurou sua mão. — Ah, minha filha... Você tem tantas qualidades. Seu único defeito é ser boa demais.

— Preciso dar uma boa conversa no imperador. Desprezar assim a própria imperatriz! Acaso pretende seguir o exemplo do imperador Zongwu e favorecer uma concubina em detrimento da esposa?

A imperatriz sacudiu a cabeça repetidas vezes. — Não, mãe, por favor. Não me sinto injustiçada. Tudo o que faço por Sua Majestade, faço de livre e espontânea vontade.

Ela ergueu o lenço de seda, enxugou discretamente algumas lágrimas nos cantos dos olhos e, após recuperar o fôlego, prosseguiu: — Na verdade, vim hoje pedir à senhora que pare de enfrentar Sua Majestade com tanta teimosia.

— Que ressentimento entre mãe e filho precisa durar até o dia seguinte? Hoje, o imperador dá muita importância à Nobre Senhora Hua, mas a senhora insiste em bater de frente com ele. Se dificultar a vida dela, é claro que ele criará dificuldades para a senhora. Por que não dar o primeiro passo? Aproveite o aborto recente para visitá-la e oferecer algumas palavras de consolo. Quando o imperador vir que as duas fizeram as pazes, certamente permitirá que a senhora volte ao Palácio Xianshou.

A imperatriz-viúva sempre fora orgulhosa. Em outros tempos, jamais admitiria baixar a cabeça diante de Ning Xiaoxiao.

Mas agora a situação era diferente.

Entre demonstrar simpatia por Ning Xiaoxiao por alguns instantes e suportar indefinidamente as ironias e provocações das consortes viúvas no Palácio Shoukang, ela preferia a primeira opção.

Bastou a imperatriz lhe dizer algumas palavras e oferecer uma saída honrosa para que aceitasse de bom grado.

A imperatriz acompanhou-a até a liteira que a levaria ao Palácio Zhongcui. Depois de vê-la partir, ouviu Xiangling murmurar: — Majestade, o administrador da Casa Imperial informou hoje mesmo que a senhora do Palácio Zhongcui mandou retirar o telhado do Palácio Xianshou. Por que mandou a imperatriz-viúva visitá-la?

A imperatriz olhou-a com expressão afável. — E você, o que acha que eu pretendo?

Depois de tantos anos servindo-a, Xiangling compreendeu sua intenção com um único olhar.

A imperatriz queria que a imperatriz-viúva descobrisse, no meio de sua tentativa de reconciliação, que Ning Xiaoxiao mandara arrancar o telhado do Xianshou. Assim, passaria a odiá-la ainda mais.

Mesmo entendendo, Xiangling ainda estava um pouco preocupada: — Compreendo. Mas, se a imperatriz-viúva descobrir que a senhora teve participação nisso... não ficará furiosa? Ela sempre diz que detesta as intrigas do harém.

— Detesta? Ora, ora... — A imperatriz ergueu uma sobrancelha, desdenhosa. — Quando disputava poder com as mulheres do falecido imperador, tramou contra muita gente e também foi alvo de inúmeras tramas. Como poderia detestá-las?

— Vamos. Não pretendo ficar me congelando neste lugar. Basta voltar ao palácio e esperar pelas “boas notícias” vindas do Zhongcui.

Xiangling respondeu obedientemente e, com um sorriso sinistro, ajudou a imperatriz a entrar na liteira.

*

Enquanto isso, a chegada da imperatriz-viúva provocou uma bela agitação no Palácio Zhongcui.

Ela ignorou até a Consorte Duan, que saíra para recebê-la, e seguiu diretamente para os aposentos laterais de Ning Xiaoxiao.

Ao vê-la, Ning Xiaoxiao se levantou para recebê-la, ao menos por formalidade. Mas a imperatriz-viúva segurou-lhe a mão e a fez sentar novamente, sorrindo: — Sua saúde ainda está frágil. Não precisa se levantar.

— Obrigada, imperatriz-viúva — respondeu Ning Xiaoxiao sem entusiasmo, retirando a mão com certa rigidez.

Naquele dia, a velha parecia ter enlouquecido: segurava a mão de Ning Xiaoxiao, fazia perguntas atrás de perguntas e demonstrava preocupação até com os menores detalhes.

Ning Xiaoxiao sabia muito bem que tipo de velha desgraçada tinha diante de si.

Aquele sorriso todo não passava de uma inconveniência: era como um sapo subindo no peito do pé. Não precisava morder para dar nojo.

Por isso, enquanto a velha falava, Ning Xiaoxiao deixava tudo entrar por um ouvido e sair pelo outro. Nem prestava atenção no que aquela criatura tagarelava.

Depois de algum tempo de conversa, a imperatriz-viúva começou a tentar criar intimidade:

— Antes nunca tivemos oportunidade de conversar com calma. Agora percebo que nos damos muito bem. Você tem algum nome de infância, algum apelido? Como seus familiares a chamavam? Posso usar esse nome também?

Ning Xiaoxiao pensou um pouco e começou a mentir com a maior cara de pau: — Quando era pequena, adorava comer mochi e beber espuma de leite fervido. Por isso meus parentes me chamavam de Ma Mo. A senhora pode me chamar assim quando estivermos a sós.

A imperatriz-viúva achou estranho e repetiu baixinho: — Ma Mo? (Nota da autora: “mom”, mamãe, em inglês.)

Ning Xiaoxiao respondeu toda contente: — Oi! (Nota editorial: ao repetir “Ma Mo”, a imperatriz-viúva soa como se chamasse Ning de “mamãe”, provocando a resposta de quem atende a esse chamado.)

A imperatriz-viúva sorriu. — Também acho Ma Mo um nome carinhoso. Vou chamá-la assim daqui por diante.

Depois de tanta preparação, a imperatriz-viúva finalmente chegou ao verdadeiro assunto.

O sorriso desapareceu de seu rosto. Ela suspirou e balançou a cabeça. — Ma Mo, desde que vim morar no Palácio Shoukang, nada me parece confortável. Todos os dias minhas costas e minha cintura doem, e até perdi o apetite. Você sabe que passei muitos anos no Palácio Xianshou. Por isso eu...

Ela não conseguiu terminar. Um criado do palácio entrou de repente, interrompendo-a.

Primeiro, ele prestou respeitos à imperatriz-viúva e a Ning Xiaoxiao. Depois anunciou:

— Nobre Senhora Hua, conforme suas ordens, terminamos de remover tudo.

A imperatriz-viúva o repreendeu, aborrecida: — Que falta de modos! Não percebe que estou conversando com a Nobre Senhora Hua? — Fez uma pausa, bebeu um gole de chá e perguntou: — Aliás, o que foi que vocês terminaram de remover?

O criado não se atreveu a responder. Ning Xiaoxiao, por sua vez, assumiu uma expressão inocente e lançou à imperatriz-viúva um sorriso travesso:

— O telhado do Palácio Xianshou, ué~

— ???

A imperatriz-viúva teve um espasmo tão violento que derrubou a xícara de chá. O líquido escaldante se espalhou pela mesa inteira.

Seus lábios tremeram; antes que conseguisse dirigir um único insulto a Ning Xiaoxiao, soltou um “ééérr” e desmaiou de novo.

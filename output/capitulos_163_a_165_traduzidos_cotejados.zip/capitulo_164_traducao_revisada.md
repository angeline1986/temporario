# Capítulo 164 — Um belo tabefe na cara da imperatriz

A imperatriz-viúva precisou ser carregada para fora do Palácio Zhongcui.

A remoção causou uma enorme confusão. A Consorte Duan e Gu Sijin saíram atraídas pelo tumulto e se assustaram ao ver a cena.

— Mas o que aconteceu?

A Consorte Duan aproximou-se dos servos e ajudou-os a levar a imperatriz-viúva até sua liteira, do lado de fora.

Gu Sijin só tinha olhos para Ning Xiaoxiao, temendo que ela se metesse em problemas. Puxou-a para um canto e perguntou baixinho: — Ela estava conversando normalmente com você. Como foi desmaiar desse jeito?

Ning Xiaoxiao sorriu. — O pessoal da Oficina Imperial veio comunicar que o telhado do Palácio Xianshou tinha sido retirado. Assim que ouviu, ela revirou os olhos. Mas não fui eu quem arrancou o telhado com as próprias mãos. Irmã, não precisa se preocupar que vão me culpar se acontecer alguma desgraça com ela.

Que desgraça poderia acontecer com a imperatriz-viúva?

Vaso ruim não quebra. Aquela praga ainda viveria muito tempo.

Ouvindo-a falar assim, Gu Sijin ficou um pouco mais tranquila. — Desde que não tenha nada a ver com você... Caso contrário, as consortes vão usar o episódio para inventar fofocas. Vão afogá-la só de tanto cuspir veneno!

Depois, as duas foram comer de braços dados. Nenhuma se preocupou em saber como a imperatriz-viúva estava depois de ser levada ao Shoukang.

Após a refeição, Ning Xiaoxiao se preparava para um cochilo. Mal fechou os olhos e Xiao Qi já começou a fazer barulho:

【Bip, bip, bip! Anfitriã, chegou uma nova missão!】

【Nova missão: “Fazer com que a imperatriz leve um baita tabefe diante de todo mundo.”】

【Recompensa pelo sucesso: 2 pontos percentuais no índice de desvio da trama. Penalidade pelo fracasso: menos 10% de vitalidade da anfitriã~】

Ning Xiaoxiao: 【De novo tenho que dar um tabefe nele? Já não fiz essa missão antes? Você... Hã? Espere aí!】

Ela se imobilizou por um instante, até compreender:

【Que história é essa? Dar um tapa na imperatriz?】

Xiao Qi: 【Hehehe, isso mesmo~】

Desde que entrara no livro, cerca de 20% das missões de Ning Xiaoxiao tinham como objetivo impedir um romance entre Gu Sijin e Lu Linyuan. Os outros 80%, basicamente, consistiam em “torturar” Lu Linyuan.

Pela primeira vez, ela não precisaria atormentar o imperador azarado. Além disso, no romance original, a imperatriz era uma falsa sonsa que escondia muito bem sua maldade. Um tabefe seria até pouco para ela.

Percebendo a alegria de Ning Xiaoxiao e sua vontade de entrar logo em ação, Xiao Qi comentou:

【Tsc, tsc. Você fica toda feliz só porque não vai maltratar o tirano, é? Será que consegue demonstrar esse seu afeto de maneira ainda mais escancarada?】

Ning Xiaoxiao: 【... Se você trocar a missão por “dar um tabefe em Xiao Qi”, vou ficar mais feliz ainda!】

Xiao Qi: 【Não, não, nem pensar~ Até mais, anfitriã! Vou ficar offline, tchau!】

*

Naquele dia, a imperatriz-viúva permaneceu desacordada no Palácio Shoukang por dois shichen — aproximadamente quatro horas — e só despertou aos poucos depois de receber acupuntura dos médicos imperiais.

No dia seguinte, a imperatriz, que havia suspendido as visitas de cortesia de todo o harém, convocou novamente as consortes para uma reunião logo cedo em seu palácio.

Ao receber a notícia, Gu Sijin ficou bastante inquieta e correu procurar Ning Xiaoxiao. — A imperatriz-viúva e a imperatriz são como mãe e filha. Esse espetáculo todo é claramente para humilhar você. Xiaoxiao, por que não finge estar doente hoje? Vou pedir a Qiqi que chame o imperador. Com ele presente, certamente ficará protegida.

Mal terminara de falar quando Bengbeng se intrometeu: — Hoje receio que Sua Majestade não tenha tempo. Quando fui à Casa Imperial buscar a mesada deste mês do nosso palácio, ouvi dizer que a Grã-Princesa Qingyang regressa hoje à corte. A comitiva dela já deve estar chegando.

O rosto de Gu Sijin ficou ainda mais preocupado. — E agora? Não podemos simplesmente...

— Irmã, não se preocupe comigo. — Ning Xiaoxiao pousou a mão sobre a dela e a afagou delicadamente. — A reforma do Palácio Xianshou foi ordenada pelo imperador. A imperatriz não pode me culpar pelo desmaio da imperatriz-viúva. Eu não só não posso fingir doença como preciso ir. Se não aparecer, aí sim parecerei culpada.

Ora, que pergunta! Se eu não for, como vou dar aquele tabefe na cara dela?

*

Ao chegarem ao Palácio Fengluan, encontraram um ambiente realmente pesado.

Em tese, era a primeira vez que Ning Xiaoxiao retomava as visitas de cortesia depois de seu “aborto”. Mesmo que fosse só por aparência, as demais consortes deveriam demonstrar preocupação e perguntar como ela estava.

No entanto, todas tinham expressões sombrias, como se quisessem mostrar deliberadamente sua desaprovação.

Comparada às outras, a imperatriz apenas perdera o sorriso caloroso de costume. Seu semblante, porém, não parecia tão ruim.

Gu Sijin e Ning Xiaoxiao chegaram um pouco atrasadas. Mal prestaram respeitos e se sentaram, a Consorte Li começou a falar com sarcasmo:

— Nobre Senhora Hua, você ainda tem a cara de pau de se sentar?

Ning Xiaoxiao respondeu com calma: — E por que não teria?

A Consorte Li retrucou: — Você deixou a imperatriz-viúva tão furiosa que sua saúde ficou abalada! Acha mesmo que há lugar para você se sentar no Palácio Fengluan? Olhe para si mesma. Você merece?

Ao ouvir aquilo, a Atendente Xi, sentada perto da entrada, não conseguiu conter uma risadinha.

(Nota da autora: essas consortes de menor importância são apenas figurantes do harém; vou mencioná-las brevemente e seguir em frente, tá?)

Ning Xiaoxiao piscou seus olhos grandes e úmidos, abriu o documento da trama e alterou o que aconteceria em seguida.

A Atendente Xi ainda ria quando, de repente, disparou contra a Consorte Li:

— Você merece, merece demais! Você e uma porca formam o casal ideal!

Consorte Li: — ??? Como ousa! Uma simples atendente se atreve a me desrespeitar? Guardas! Levem-na e encham a boca dela de tapas!

O salão mergulhou em confusão, deixando a imperatriz com dor de cabeça.

Ela ergueu a mão para interrompê-las e disse severamente: — Chega de tumulto. Convoquei todas aqui hoje por causa do que ocorreu com a imperatriz-viúva.

Seu olhar pousou em Ning Xiaoxiao e, com palavras doces que escondiam veneno, ela continuou: — Sei que não teve intenção de prejudicá-la, mas a imperatriz-viúva desmaiou enquanto estava a sós com você. Não é possível dizer que não tenha nenhuma responsabilidade. Como imperatriz, preciso aplicar uma punição leve. Caso contrário, as outras consortes dirão que a favoreço injustamente.

Era evidente que a imperatriz procurava confusão, mas Ning Xiaoxiao não tinha medo.

Afinal, viera ali justamente para dar-lhe um tabefe. Quanto mais aquela ordinária a provocasse, mais prazeroso seria acertar-lhe a cara.

Ela se preparava para ouvir a punição quando, de repente, ouviu uma discussão do lado de fora.

— Princesa! Sua Majestade, a imperatriz, está reunida! Grã-Princesa, não pode entrar sem autorização!

Todos olharam para a entrada do salão. Uma mulher alta, vestida com uma capa vermelho-escarlate de brocado de Sichuan decorada com motivos de nuvens, afastou bruscamente o criado que bloqueava seu caminho e entrou sem hesitar.

Assim que cruzou a porta, uma presença invisível e imponente irradiou de seu corpo, envolvendo em certa frieza o salão antes acolhedor.

Ning Xiaoxiao a observou discretamente. Olhos amendoados e oblíquos, sobrancelhas arqueadas e boca delicada: seus traços deveriam transmitir suavidade e elegância. Ainda assim, havia sob aquela aparência a aura aterradora de uma guerreira implacável.

A sensação lhe era familiar. Depois de pensar um pouco, percebeu que era exatamente a mesma impressão que tivera ao conhecer Lu Linyuan.

Ao vê-la, a imperatriz finalmente abriu o primeiro sorriso do dia. — Princesa Qingyang, voltou? Por que não avisou antes? Eu poderia ter...

— Foi você quem mandou a imperatriz-viúva transferir a tabuleta ancestral de minha mãe para o Templo Taigu? — Qingyang parou junto ao trono da imperatriz e fitou-a de cima, interrompendo-a com uma voz dura.

A imperatriz ficou constrangida e tentou explicar: — Entendeu mal. Aquilo foi uma decisão da imperatriz-viúva. Eu...

PÁ!

Antes que terminasse, Qingyang ergueu a mão de repente e lhe aplicou um tapa sonoro, com toda a força.

O golpe deixou não apenas a imperatriz, mas todos os presentes, inclusive Ning Xiaoxiao, completamente perplexos.

Com a mão sobre a face ardendo, a imperatriz olhou para ela, incrédula. — Qingyang, você...

PÁ!

O segundo tapa de Qingyang foi ainda mais forte. Depois de acertá-la, lançou-lhe um olhar de profundo desprezo:

— A imperatriz-viúva não presta, mas você também não fica atrás!

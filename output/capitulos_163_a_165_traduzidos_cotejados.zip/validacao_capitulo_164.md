# Validação — capítulo 164

- **Fonte primária:** `novel_capitulos_121_a_180(20261103-233558).docx`, chinês tradicional.
- **Título original:** 第164章 給皇後一個大逼兜
- **Limites do DOCX:** parágrafos 3017 a 3088 (base zero); excluído o título do capítulo 165.
- **Parágrafos não vazios (incluindo título):** 69.
- **Linhas de cotejo:** 69.
- **Índices ausentes / extras / duplicados:** 0 / 0 / 0.
- **Campos vazios:** 0.
- **Cabeçalho CSV:** `indice_docx,original_chines,traducao_portugues`.

## Escolhas editoriais e verificações de sentido

A missão exige que a imperatriz **receba** um tapa, não que Ning seja sua autora. O intervalo 兩個時辰 equivale a aproximadamente quatro horas. O texto preserva a nota da autora sobre as consortes secundárias e diferencia os cargos 常在 (Atendente) e 貴人 (Nobre Senhora).

## Limitações

A validação automática comprova o alinhamento estrutural dos parágrafos não vazios, mas não certifica ausência de omissões dentro de um parágrafo ou total equivalência semântica. A revisão linguística foi feita durante a tradução, não por um segundo revisor independente.

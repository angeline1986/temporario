# Validação — capítulo 163

- **Fonte primária:** `novel_capitulos_121_a_180(20261103-233558).docx`, chinês tradicional.
- **Título original:** 第163章 太後洗白了？
- **Limites do DOCX:** parágrafos 2953 a 3016 (base zero); excluído o título do capítulo 164.
- **Parágrafos não vazios (incluindo título):** 61.
- **Linhas de cotejo:** 61.
- **Índices ausentes / extras / duplicados:** 0 / 0 / 0.
- **Campos vazios:** 0.
- **Cabeçalho CSV:** `indice_docx,original_chines,traducao_portugues`.

## Escolhas editoriais e verificações de sentido

O apelido 麻沫 (Ma Mo) foi mantido, com nota editorial para o jogo sonoro com “mom” (mamãe). O suposto aborto permanece descrito segundo o conhecimento dos personagens, não como fato clínico. O plano da imperatriz antecede a visita da imperatriz-viúva.

## Limitações

A validação automática comprova o alinhamento estrutural dos parágrafos não vazios, mas não certifica ausência de omissões dentro de um parágrafo ou total equivalência semântica. A revisão linguística foi feita durante a tradução, não por um segundo revisor independente.

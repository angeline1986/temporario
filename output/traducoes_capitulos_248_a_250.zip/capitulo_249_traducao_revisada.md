# Capítulo 249 — Não bata! Eu sou sua mãe!

Xiao Qi: 【Parabéns, anfitriã! A recompensa sorteada desta vez foi a “Pílula da Força”. Depois de tomá-la, você terá uma força descomunal por vinte e quatro horas.】

【Não se deixe enganar pelo seu corpinho delicado, frágil como o de Lin Daiyu, aquela donzela que parece que o vento vai levar. Depois de tomar a Pílula da Força, você poderia até apresentar ao público uma versão de “Lin Daiyu arrancando um salgueiro pela raiz”!】

Ning Xiaoxiao: ￣□￣｜｜

【E para que eu arrancaria um salgueiro? Estou com tanta falta do que fazer assim?】

Ela esfregou a Pílula da Força entre os dedos. Aquilo não parecia ter muita utilidade...

De todo modo, era melhor guardá-la no espaço particular antes que Xiao Lu a “comesse por engano” outra vez.

*

Os ministros reunidos na Academia Bitong só começaram a se dispersar durante a tarde. Outros memoriais de felicitação pelo Ano-Novo chegaram do palácio e se amontoaram como uma pequena montanha sobre a mesa imperial de Lu Linyuan.

Como era uma ocasião festiva e todos queriam começar o ano com bons presságios, naquela noite Lu Linyuan precisava terminar de ler e despachar todos aqueles memoriais.

Ele trabalhou à luz de velas até tarde. Ning Xiaoxiao o acompanhou em silêncio, levando de vez em quando pedaços de fruta cortada até sua boca. A convivência dos dois era harmoniosa como a de um casal.

A certa altura, Lu Linyuan ergueu a cabeça para alongar o pescoço. — Está dolorido. Venha massagear um pouco.

Ning Xiaoxiao se colocou atrás dele e apertou suavemente os músculos tensos da nuca. — A força está boa assim?

Lu Linyuan hesitou por um instante. Ninguém sabia que ideias impróprias lhe passaram pela cabeça. Ele soltou uma risadinha. — Está ótima.

— Do que está rindo?

— De nada.

Ele se virou, deixando o olhar percorrer Ning Xiaoxiao com um interesse cheio de segundas intenções.

???

Ning Xiaoxiao percebeu subitamente o que ele estava pensando. Pegou um memorial e o colocou sobre o rosto de Lu Linyuan. — Continue trabalhando sozinho. Comigo aqui, você vive se distraindo e não vai acabar nem ao amanhecer. Vou voltar para o meu quarto~

Saiu como quem fugia de alguma coisa, disparando até a porta num piscar de olhos.

Lu Linyuan gritou atrás dela: — Não durma muito cedo! Quando terminar isto, vou procurá-la! Ouviu?

Ning Xiaoxiao olhou por cima do ombro, acenou e mostrou a língua, toda travessa: — Ouvi! Vou voltar e dormir imediatamente! Boa noite!

Pensando bem, apesar de já estarem havia tanto tempo na residência das fontes termais, Ning Xiaoxiao ainda não tinha dormido uma única noite no Pavilhão Tingyu, embora aquele quarto tivesse sido preparado especialmente para ela.

Depois de se lavar, jogou-se na cama de braços e pernas abertos. Pensando em seu querido, abraçou um travesseiro e rolou de alegria sobre o colchão.

Pretendia esperar por ele, mas passara o almoço inteiro conversando com Qiqi e comendo tirinhas picantes, sem tirar uma soneca. Assim que encostou a cabeça no travesseiro, o sono veio com força.

Depois de lutar por algum tempo contra as pálpebras pesadas, acabou adormecendo.

Mal parecia ter mergulhado no sono quando alguém bateu de leve em seu ombro. Ouviu uma voz masculina junto à orelha:

— Filhinha, acorde.

Sem pensar, achou que fosse Lu Linyuan. Virou-se, irritada, abriu um bom espaço ao lado na cama e murmurou dengosamente:

— Já deixei seu lugar livre. Não me incomode, estou morrendo de sono...

— Filhinha, pare de dormir!

O homem levantou a voz, segurou seus ombros e a sacudiu duas vezes.

Ning Xiaoxiao já acordava de mau humor por natureza; quando alguém perturbava seus sonhos, tornava-se um rojão pronto para explodir.

Puxou a coberta e se ergueu até ficar meio sentada. De olhos semicerrados, reclamou: — Ah, que inferno! No meio da noite você...

Parou no meio da frase. Quando distinguiu quem estava ao lado da cama, o susto dissipou inteiramente seu sono.

— Príncipe Jing?

Lu Yiqiu estava de pé junto à cabeceira, observando-a com um sorriso cheio de carinho.

Ning Xiaoxiao dormia de roupa de dormir. Ao encontrar um homem adulto como Lu Yiqiu à beira de sua cama no meio da madrugada, sua primeira reação foi puxar a coberta e se enrolar nela:

— Por que você não está dormindo? O que veio fazer nos meus aposentos a esta hora?

Ela falara alto demais. Assustado, Lu Yiqiu cobriu rapidamente a boca dela. — Psiu! Não grite!

???

Um homem aparece de madrugada ao lado da sua cama, acorda você à força e ainda tapa sua boca quando tenta gritar?

Mesmo sendo gay, isso continuava absurdo demais!

Ning Xiaoxiao começou a ficar furiosa. Mordeu com força a mão de Lu Yiqiu, obrigando-o a soltá-la por causa da dor.

— Alteza, príncipe Jing! Homens e mulheres precisam respeitar certos limites! Normalmente suas maneiras desregradas não fazem mal a ninguém, mas agora passou dos limites!

Enquanto soprava os dedos mordidos, Lu Yiqiu explicou: — Não sou o príncipe Jing coisa nenhuma! Eu sou sua mãe!

Ning Xiaoxiao: — E agora ainda vem me xingar?

Lu Yiqiu estava quase desesperado. — Eu... Me diga uma coisa: você tem ou não uma marca vermelha na nádega esquerda?

Instintivamente, Ning Xiaoxiao cobriu o próprio traseiro.

Mas que diabos?! Nem Lu Linyuan sabia da marca em sua bunda. Como Lu Yiqiu podia saber?

Será que ele... a tinha espiado tomando banho?

Aquele ainda era o mesmo sujeito adorável que ela conhecia?

Furiosa, Ning Xiaoxiao agarrou um travesseiro e começou a golpeá-lo.

— Não, não bata! Se bater em mim, um raio vai cair na sua cabeça!

— Essa marca na sua bunda não é de nascença! Eu derramei água fervente sem querer quando você era pequena e queimei seu bumbum!

— Sua fruta preferida é morango, e seus pratos favoritos são a carne cozida e apimentada que sua mãe prepara e a panela picante mala xiang guo!

— Você é alérgica à penicilina! Basta sentir a serragem e a poeira das reformas de casa para atacar sua rinite!

— Vai continuar batendo? Pense com calma!

— Com número ímpar, muda; com par, não muda. O sinal depende do quadrante!

Ning Xiaoxiao: — ???

No começo, estava tão entretida batendo nele que mal ouvira o que Lu Yiqiu tagarelava. Mas aquelas últimas frases bastavam para provar quem ele realmente era.

Ele... era mesmo a mãe dela?

Ning Xiaoxiao deixou cair o travesseiro, com o rosto tomado de perplexidade. — Mãe? Como você ficou desse jeito??

Lu Yiqiu: — Nem me fale... Deu outro problema na hora de entrar no livro...

Depois de uma longa explicação, Ning Xiaoxiao soube que sua mãe, Qi Meijuan, tinha entrado no mundo do livro para visitá-la. Só que a máquina de transmigração dera defeito outra vez e a fizera entrar no corpo de Lu Yiqiu...

Assim, embora mãe e filha estivessem felizes com o reencontro, não se abraçaram nem tiveram outros contatos físicos, procurando manter uma distância social educada.

Quando aceitou o que acontecera, Ning Xiaoxiao deixou de se sentir tão constrangida.

Puxou Qi Meijuan, que agora tinha a aparência de Lu Yiqiu, para sentar-se em sua cama. Qi Meijuan, como toda mãe zelosa, começou a disparar pergunta atrás de pergunta, querendo ter certeza de que a filha estava vivendo bem naquele mundo de ficção.

Mãe e filha conversavam animadamente quando Lu Linyuan apareceu de repente, carregando uma caixa de comida:

— Xiaoxiao, preparei uma sopa doce para você. Venha...

Seis olhos se encontraram.

Silêncio. Um silêncio mortal.

Ao ver Ning Xiaoxiao e Lu Yiqiu sentados na cama, rindo e conversando, Lu Linyuan teve a impressão de enxergar uma luz verde ofuscante diante dos olhos... uma bela cor de chifres.

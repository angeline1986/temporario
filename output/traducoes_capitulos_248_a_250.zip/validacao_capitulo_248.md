# Validação — Capítulo 248

- **Fonte primária:** `novel_capitulos_212_a_270(20261105-204934).docx`, texto chinês tradicional.
- **Faixa de parágrafos DOCX (índices base zero):** 2557–2626.
- **Unidades não vazias:** 67, incluindo o título e quaisquer apartes presentes no trecho.
- **Cotejo:** 67 traduções para 67 parágrafos chineses; índices preservados do DOCX, sem duplicatas nem campos vazios.
- **Correspondência Markdown/CSV:** gerada a partir das mesmas unidades traduzidas, na mesma ordem.

## Decisões editoriais

A metáfora 燈下黑 foi traduzida como “sombra sob a lâmpada”, preservando a explicação metalinguística da autora. 對食 designa uma união/companhia afetiva reconhecida em contexto palaciano, frequentemente envolvendo eunucos; optou-se por “autorizar a união” sem impor casamento civil moderno. 貴妃 foi mantido como Consorte Nobre. “Tirinhas picantes” representa 辣條. O vínculo entre Qiqi e Bengbeng foi mantido como possibilidade afetiva, sem declarar casamento concretizado.

## Escopo da validação

A cobertura 1:1, os limites, a existência dos arquivos e a integridade dos CSVs são verificáveis mecanicamente. Houve tradução e leitura editorial, mas **não foi realizada uma segunda auditoria semântica independente e integral**. Cotejo estrutural não certifica por si só equivalência semântica perfeita de cada frase.

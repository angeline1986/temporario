# Validação — Capítulo 250

- **Fonte primária:** `novel_capitulos_212_a_270(20261105-204934).docx`, texto chinês tradicional.
- **Faixa de parágrafos DOCX (índices base zero):** 2703–2785.
- **Unidades não vazias:** 80, incluindo o título e quaisquer apartes presentes no trecho.
- **Cotejo:** 80 traduções para 80 parágrafos chineses; índices preservados do DOCX, sem duplicatas nem campos vazios.
- **Correspondência Markdown/CSV:** gerada a partir das mesmas unidades traduzidas, na mesma ordem.

## Decisões editoriais

A perspectiva alterna entre Qi Meijuan, que ocupa o corpo de Lu Yiqiu, e Lu Linyuan, que consegue ouvir os pensamentos de Ning Xiaoxiao. “Cento e oito truques” preserva a hipérbole do original. A expressão de mãos “esquerda seis, direita sete” foi traduzida pelo resultado da falta de coordenação, sem afirmar diagnóstico médico. “Sem nenhuma condição” conserva o valor de 無條件, confiança sem condições; nenhuma infidelidade é confirmada.

## Escopo da validação

A cobertura 1:1, os limites, a existência dos arquivos e a integridade dos CSVs são verificáveis mecanicamente. Houve tradução e leitura editorial, mas **não foi realizada uma segunda auditoria semântica independente e integral**. Cotejo estrutural não certifica por si só equivalência semântica perfeita de cada frase.

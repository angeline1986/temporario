# Capítulo 248 — Xiaoxiao concede um casamento a Qiqi

Sua Xiaoxiao vivia lhe fazendo aquelas perguntas bobas.

É claro que ela era boa. Muito boa. Maravilhosa. Boa em tudo.

E, quando o amor é profundo, a sensação de não ser digno do outro costuma ser recíproca.

Ning Xiaoxiao achava que não era boa o bastante; Lu Linyuan também achava que não era bom o bastante.

Aos olhos dele, o fato de Ning Xiaoxiao aceitá-lo e querer ficar ao seu lado já era o maior motivo de orgulho de sua vida.

Mais até do que ser imperador.

Era algo que merecia ser gravado em seu epitáfio daqui a cem anos:

“Conquistar Xiaoxiao vale mais do que conquistar o mundo.”

E era exatamente assim.

Havia tantos anos que governava o mundo, podendo decidir a vida e a morte de milhares com uma única palavra. Ainda assim, mesmo com todo o poder imperial nas mãos, jamais tivera uma noite de sono verdadeiramente tranquila.

Seu mundo era originalmente sombrio, sem luz; toda claridade vinha apenas da aura de Filho do Céu.

O brilho dessa aura era ardente, intenso, ofuscante, e iluminava até os cantos de escuridão invisíveis da dinastia Qi.

Mas ele próprio, de pé sob aquela luz poderosa, permanecia sempre na sombra projetada pela lâmpada.

(PS: Talvez alguns leitores mais jovens não conheçam essa expressão. Explico: “escuridão sob a lâmpada” se refere à área que permanece escura bem debaixo de uma luminária, porque a própria luminária bloqueia sua luz.)

Até que, um dia, aquela garota luminosa invadiu seu mundo. Aproximou-se passo a passo e, com sua luz talvez fraca, mas constante, iluminou a sombra diante dele.

Só então ele pôde enxergar a si mesmo e ver como aquele mundo realmente era.

Por isso, mesmo que ela não pudesse prever o futuro nem livrá-lo de desgraças e dúvidas, ele ainda se apaixonaria por ela sem hesitar.

❤

Naquela noite, Ning Xiaoxiao dormiu profundamente, aconchegada nos braços de Lu Linyuan.

Quando acordou de manhã, ele já estava no escritório recebendo ministros que haviam chegado de diferentes regiões.

Ao se levantar, viu três tigelinhas de preparados medicinais sendo aquecidas em fogo baixo, num braseiro ao lado da cama. Junto delas, havia um bilhete dele:

“Uma tigela de água com açúcar mascavo, uma de chá de gengibre com açúcar mascavo e uma de tônico para repor o sangue e a energia. Escolha.”

“Se não conseguir beber, não jogue fora. Tenho pena das minhas plantas.”

— Pfff!

Ning Xiaoxiao caiu na risada. Ela, que sempre reclamava do amargor dos remédios, naquele dia se comportou de maneira surpreendentemente obediente.

Bebeu as três tigelas, ficou tão cheia que até arrotou e, então, escreveu uma resposta no bilhete:

“Lido. Bebi tudo. Agora me elogie.”

Depois de se lavar e se arrumar, ouviu de Sanfu que, como o dia seguinte seria a véspera do Ano-Novo, numerosos ministros tinham vindo naquele dia desejar um feliz ano novo a Lu Linyuan.

Não seria apropriado uma concubina participar dos assuntos da corte, portanto ela avisou a Sanfu:

— Vou voltar primeiro ao Pavilhão Tingyu. Quando A-Yuan terminar de trabalhar, venha me avisar.

E saiu passeando. Xiao Yinzi, que estava ao lado de Sanfu, coçou a nuca:

— Nossa... Desde que o imperador anterior morreu, nunca mais ouvi ninguém chamar Sua Majestade assim... Mestre, o senhor acha que o imperador precisa mimar muito a Consorte Nobre para permitir isso?

Sanfu lhe deu um cascudo com as costas da mão. — Já que sabe, não trate de servi-la direito? Quando voltarmos ao palácio, as tarefas do Palácio Fengyi serão prioridade absoluta. Até os assuntos da imperatriz terão de esperar!

— Mestre... Já que Sua Majestade gosta tanto da Consorte Nobre, será que um dia vai depor a imperatriz?

Sanfu o fulminou com o olhar e lhe deu um chute no traseiro, exasperado. — Está cansado de viver? Como ousa dizer uma coisa dessas em voz alta? Vá! Vá ficar de castigo olhando para a parede!

Xiao Yinzi soltou um “sim” todo magoado e se retirou com o rabo entre as pernas.

Sanfu, por sua vez, contemplou as costas de Ning Xiaoxiao, que se afastava aos pulinhos, e murmurou com um sorriso:

— Hum... E por que não?

De volta ao Pavilhão Tingyu, Ning Xiaoxiao tirou de seu espaço particular dois pacotes de tirinhas picantes, abriu-os, despejou o conteúdo num prato e chamou Qiqi para comer e conversar com ela.

Lembrava-se de que Qiqi completara vinte e quatro anos havia dois dias.

As criadas deixavam o palácio aos vinte e cinco. Então perguntou: — No ano que vem você fará vinte e cinco anos. Já pensou no que quer fazer quando sair? Você é habilidosa, borda melhor do que as mestras da oficina. Poderia abrir uma loja de bordados e vender tecidos. Com certeza conseguiria se estabelecer na capital.

Qiqi balançou a cabeça timidamente. Ning Xiaoxiao acrescentou: — Se o problema for dinheiro, não se preocupe. Não tenho uma fortuna sem fim, mas consigo separar mil ou oitocentos taéis de prata para você.

Qiqi ficou boquiaberta e acenou com as mãos depressa:

— Não, não! Não foi isso que quis dizer! Até um funcionário de terceiro escalão da corte precisaria trabalhar décadas para juntar oitocentos ou mil taéis. Como uma simples criada como eu poderia aceitar tanto dinheiro...?

— Balancei a cabeça porque não quero sair do palácio. Quero continuar servindo à senhora e à senhora Gu para sempre!

— Não quer sair? — Ning Xiaoxiao sorriu serenamente e perguntou, fingindo não saber a resposta: — E como fica seu casamento? Aos vinte e cinco, uma mulher já é considerada crescidinha na dinastia Qi. Se esperar mais alguns anos, vai passar da melhor idade para ter filhos.

— Nunca pensei em ter filhos... — Qiqi baixou a cabeça, mexendo sem jeito num pequeno bambu junto aos pés. — Para ser sincera, nunca gostei de crianças. Acho muito barulhentas. Eu tinha um irmão seis anos mais novo. Ele matou alguém numa briga e foi condenado à decapitação. Meus pais morreram de desgosto por causa disso.

— Tenho tanto medo... Mal sei conduzir minha própria vida, quanto mais educar uma criança. Tenho pavor de criar alguém com o mesmo temperamento rebelde do meu irmão e acabar pagando com a própria vida. Não vale a pena.

— Você não precisa ter filhos, mas não seria bom ter companhia? Senão vai viver sozinha. Quando Qiaqia, Lala e as outras chegarem à idade de sair do palácio, ficará até difícil encontrar alguém com quem conversar.

— Ainda tem o Bengbeng... — escapou de Qiqi. Percebendo o que dissera, ficou imediatamente vermelha.

Ning Xiaoxiao riu. — Até que enfim falou a verdade, não foi?

Beliscou a bochecha fofinha de Qiqi. — Gostar de alguém não tem nada a ver com gênero. Por que se deixar prender pelo julgamento dos outros? Se vocês realmente se gostam, quando voltarmos ao palácio posso autorizar a união de vocês dois, para que fiquem juntos de cabeça erguida.

Qiqi se apressou: — Eu não quero isso...

Ficou ainda mais envergonhada, como um botão de flor prestes a desabrochar. O rubor de suas faces se espalhou até o pescoço.

— Além disso... Ele é que tem de tomar a iniciativa, não acha? Afinal, sou uma moça...

Ning Xiaoxiao segurou sua mão e sorriu. — Claro que sim.

Daquele jeito, Ning Xiaoxiao entendeu os sentimentos de Qiqi.

A personalidade da criada era muito parecida com a sua, só que Qiqi era ainda mais corajosa.

Quando gostava de alguém, gostava com toda a intensidade, sem recuar diante da posição social da outra pessoa.

Naquele dia, Ning Xiaoxiao conversou com Qiqi sobre muitas outras coisas. Só quando a moça foi tirar uma soneca após o almoço é que se lembrou de algo.

Seu índice de desvio da trama havia chegado a 50%. Sempre que o índice atingia um marco redondo, ela ganhava uma oportunidade de girar a grande roleta.

Assim, chamou Xiao Qi para cobrar sua recompensa.

Xiao Qi não discutiu e fez a grande roleta surgir imediatamente.

Ning Xiaoxiao fechou os olhos e girou-a com força. Dessa vez, o ponteiro parou na recompensa chamada “Pílula da Força”.

Um clarão azul passou por sua palma, e uma pílula marrom do tamanho de uma bolinha de gude apareceu em sua mão.

Ning Xiaoxiao a examinou por alguns instantes. 【Que troço é esse?】

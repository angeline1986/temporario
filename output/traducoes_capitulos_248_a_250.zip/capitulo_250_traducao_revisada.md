# Capítulo 250 — Eu confio em você incondicionalmente

— LU! YI! QIU!!

Lu Linyuan praticamente cuspiu as três sílabas entre os dentes cerrados.

Ele sabia que não poderia haver nada entre Ning Xiaoxiao e Lu Yiqiu. Mas sua esposa estava de roupa de dormir, e aquele homem tinha invadido os aposentos dela no meio da noite. Aquilo não era se aproveitar da esposa dele?

Enfurecido, largou a bandeja sobre a mesa; os recipientes tombaram, derramando a sobremesa por metade do móvel.

Então arregaçou as mangas e cerrou os punhos, pronto para partir para cima do próprio irmão mais novo.

Ning Xiaoxiao nunca tinha visto Lu Linyuan bater seriamente em ninguém. Só ouvira Sanfu contar que, certa vez, um ministro apoiador de rebeldes levara um soco dele em plena corte e ficara com metade do corpo paralisada...

Sua mãe havia acabado possuindo o corpo de Lu Yiqiu por uma sucessão de acidentes. Se levasse um soco de Lu Linyuan e, quando voltasse a si, descobrisse que aquele rapaz adorável ficara paralisado, sem conseguir coordenar os dedos das mãos, não seria uma injustiça terrível?

Sem contar que, naquele momento, o soco dele acertaria a própria sogra!

Quando viu Lu Linyuan avançar furioso, prestes a atingir o rosto de Qi Meijuan, Ning Xiaoxiao não conseguiu pensar em como impedi-lo. Atirou-se entre os dois, oferecendo o próprio corpo como escudo.

Por sorte, o punho de Lu Linyuan parou a menos de uma polegada do rosto de Ning Xiaoxiao.

O vento do golpe desarrumou os fios de cabelo sobre sua testa. Ela apertou os olhos, com as sobrancelhas contraídas, e ao mesmo tempo sentiu uma força puxá-la para o lado por trás.

Qi Meijuan colocou-se à frente de Ning Xiaoxiao e perguntou num tom nada amistoso: — Qual é a sua, garoto? Vai bater na sua mulher, é?

Lu Linyuan ficou atônito por um instante.

Ora vejam! Depois de passar tanto tempo com Ren Duanli, seu irmão tinha ficado atrevido desse jeito?

Ele lançou um olhar gelado a Lu Yiqiu e disparou com dureza: — Por acaso são poucas as vezes em que eu já bati em você?

Observando os dois à beira de uma briga, Ning Xiaoxiao sentiu a cabeça latejar:

— Majestade, não se precipite, ele...

— Me chame de A-Yuan. — Mesmo furioso, Lu Linyuan não se esquecia de corrigir a maneira como a esposa o chamava.

Ning Xiaoxiao: — ...A-Yuan. Na verdade, o príncipe Jing discutiu com o general Ren. Estava se sentindo injustiçado e veio conversar comigo...

【Socorro! Não consigo inventar mais nada! Como vou explicar que ele é minha mãe?】

Lu Linyuan: — ???

Como é que é?

Aquele sujeito era sua mãe?

Ele examinou Lu Yiqiu. Antes, apesar de viver fazendo birra e se comportar de maneira mimada, seu irmão não tinha gestos particularmente femininos.

Mas, observando-o agora com atenção, da postura à expressão, tudo nele revelava um toque de feminilidade.

Mas que maravilha... Sua mãe também saía por aí aparecendo onde não devia, igualzinha a você?

Não existem coisas absurdas por natureza; quando aparecem pessoas absurdas em número suficiente, o absurdo simplesmente acontece...

Enquanto Lu Linyuan tentava digerir aquela realidade fantástica, Ning Xiaoxiao puxou Qi Meijuan para um canto e sussurrou baixinho:

— Mãe! Não fique peitando ele. É um cabeça-dura de primeira, não consegue raciocinar direito. Tome cuidado, senão ele vai acabar batendo em você mesmo...

Qi Meijuan era uma pessoa de fora daquele universo. Quanto a Lu Linyuan, um personagem de papel, sua única exigência era que ele tratasse muito bem sua filha.

Ele não estava tão furioso justamente porque o próprio irmão vira sua esposa usando roupas de dormir?

No fundo, tinha medo de que Ning Xiaoxiao fosse prejudicada.

Portanto, aos olhos da sogra, a reação dele acabava contando como um ponto positivo.

Os três ficaram num impasse, até que Qi Meijuan foi a primeira a entrar no personagem e quebrar o gelo.

Aproximou-se, segurou o braço de Lu Linyuan e começou a fazer manha, imitando o jeito descarado que Lu Yiqiu costumava ter:

— Ah, irmãozão! Eu não conseguia dormir e vim bater um papo com minha cunhada. Por que quer me bater...?

Questão para reflexão: como é ser chamado de irmão pela própria sogra? Um sinal de que até os ancestrais estão sorrindo para você?

Agora ele não podia continuar zangado. Se sua sogra achasse que ele tinha tendências violentas e depois não aprovasse seu casamento com Ning Xiaoxiao, o prejuízo seria grande demais.

Assim, pigarreou e disse com fingida seriedade:

— Se não consegue dormir, pode vir conversar comigo. Sua cunhada teve um dia cansativo; você não deveria perturbá-la.

Qi Meijuan: — Irmão! Já terminei de conversar. Não quero mais papo, quero dormir.

Ela apontou para a porta. — Pode ir embora primeiro?

Lu Linyuan: — ???

Ning Xiaoxiao: — !!!

Ela puxou o braço de Qi Meijuan e fez sinais com os olhos para indicar que talvez fosse a mãe quem devesse sair.

Mas Qi Meijuan estava numa situação extremamente embaraçosa.

Quando acabara de transmigrar, Lu Yiqiu já tinha adormecido no Pavilhão Xiaoyao.

Qi Meijuan abrira os olhos e descobrira um homem lindo e seminu deitado ao seu lado. Aquele corpo, aquele rosto! Em uma palavra: perfeição!

Só que ela era casada com Ning Dazhi. Como poderia dividir a cama com outro homem pelas costas do marido?

Então cochichou para Ning Xiaoxiao: — Como é que a mamãe vai voltar? Tem outro homem deitado na cama do príncipe Jing! Minha filha querida, que tal eu dormir com você esta noite?

Lu Linyuan, com as orelhas em pé como as de um coelho, ouviu a conversa entre mãe e filha e respondeu imediatamente:

— Muito simples. Ou você volta à Academia Bitong e dorme comigo, ou sua cunhada vem dormir comigo e você dorme aqui sozinho. Escolha.

Depois de tanto tempo convivendo com Ning Xiaoxiao, ele também aprendera uma boa parte dos cento e oito truques que ela guardava na manga.

Se Qi Meijuan não queria dormir com Ren Duanli, muito menos iria querer dormir com ele.

Sendo assim, ela própria teria de permitir que a filha dormisse com ele.

Se a sogra desse sua bênção, aquela noite de sono seria certamente muito tranquila.

Ning Xiaoxiao achava que, como sua mãe sempre fora rigorosa ao criá-la, se descobrisse que ela dividia a cama com um homem antes do casamento, lhe daria uma bronca terrível.

Mas, para sua surpresa, ao ouvir aquilo, Qi Meijuan a empurrou alegremente na direção de Lu Linyuan:

— Então, irmão, leve logo sua cunhada para dormir!

Dito isso, correu para a cama, puxou a coberta e acenou para os dois: — Tchau, irmão~ Tchau, cunhadinha~

...

No fim daquela noite, Lu Linyuan levou Ning Xiaoxiao de volta à Academia Bitong, segurando o riso.

No caminho, permaneceu o tempo todo de mãos dadas com ela.

Ning Xiaoxiao olhou de soslaio e viu o sorriso que brincava nos lábios dele. Intrigada, perguntou: — Do que está rindo?

— De nada.

— Você não está bravo? Um homem normal, vendo uma cena como aquela, provavelmente começaria a imaginar um monte de coisas, não?

Lu Linyuan parou de repente e ergueu uma sobrancelha ao olhar para ela. — Aos seus olhos, eu não fui sempre um homem anormal?

— ...

Ele sorriu. — Eu confio em você.

Fez uma pausa e acrescentou três palavras: — Sem nenhuma condição.

A frase saiu de sua boca com naturalidade, mas, para Ning Xiaoxiao, tinha um valor imenso.

Mesmo quem nunca comeu carne de porco já viu um porco correr.

Quantos protagonistas de romances não transformavam mal-entendidos e coincidências melodramáticas em brigas que viravam tudo de cabeça para baixo?

Ser alvo de uma suspeita injusta era uma sensação terrível.

Felizmente, seu A-Yuan nunca a interpretara mal.

E aquele “eu confio em você” de Lu Linyuan não era uma justificativa inventada depois do acontecido.

Desde o primeiro instante em que vira a cena, ele não suspeitara de Ning Xiaoxiao nem por um segundo.

Só pensara em proteger sua esposa para que ninguém se aproveitasse dela.

Afinal, a base do amor não era justamente confiar no outro sem impor condições?

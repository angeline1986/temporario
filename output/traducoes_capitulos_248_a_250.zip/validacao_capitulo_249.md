# Validação — Capítulo 249

- **Fonte primária:** `novel_capitulos_212_a_270(20261105-204934).docx`, texto chinês tradicional.
- **Faixa de parágrafos DOCX (índices base zero):** 2627–2702.
- **Unidades não vazias:** 73, incluindo o título e quaisquer apartes presentes no trecho.
- **Cotejo:** 73 traduções para 73 parágrafos chineses; índices preservados do DOCX, sem duplicatas nem campos vazios.
- **Correspondência Markdown/CSV:** gerada a partir das mesmas unidades traduzidas, na mesma ordem.

## Decisões editoriais

大力丸 foi traduzido como “Pílula da Força”. A referência a Lin Daiyu arrancando o salgueiro combina a heroína delicada de O Sonho da Câmara Vermelha com um feito atribuído a Lu Zhishen; manteve-se o contraste cômico. A frase 奇變偶不變，符號看象限 é um mnemônico matemático chinês sobre funções trigonométricas; a tradução preserva a cadência aproximada, com explicação aqui. “Verde/chifres” refere-se à imagem idiomática de traição conjugal, embora o imperador não suspeite de Xiaoxiao. A visitante é Qi Meijuan no corpo de Lu Yiqiu, não o próprio príncipe agindo voluntariamente.

## Escopo da validação

A cobertura 1:1, os limites, a existência dos arquivos e a integridade dos CSVs são verificáveis mecanicamente. Houve tradução e leitura editorial, mas **não foi realizada uma segunda auditoria semântica independente e integral**. Cotejo estrutural não certifica por si só equivalência semântica perfeita de cada frase.

# Capítulo 95 — Xiaoxiao segura a coleira, e Yuanyuan corre atrás

Ning Xiaoxiao percebeu que havia algo estranho no ambiente e ergueu discretamente os olhos para observar Lu Linyuan.

Vendo seu rosto passar do preto ao verde e ao branco, pensou:

【O que deu nele? Foi envenenado?】

【A cara muda tanto de cor que já está ficando de um preto multicolorido...】

【Melhor abaixar a cabeça. Se ele olhar para mim e não gostar do que vê, vai arranjar outro problema...】

Eu vou olhar para você e não gostar do que vejo?

Já não estou gostando de você agora mesmo!

Ele pigarreou, autorizou as duas a se levantarem e disse:

— Quando cheguei, notei que o piso do pátio estava de um cinza encardido. Um horror.

Olhou para Ning Xiaoxiao e fez uma pergunta cuja resposta já sabia: — Ela é a criada responsável por este palácio?

— Sim, Majestade — respondeu Gu Sijin.

Lu Linyuan ralhou com frieza: — Que tipo de trabalho você anda fazendo? Vá limpar o chão do pátio até ficar impecável.

— ??? Mas, Majestade... os ladrilhos já são cinzentos! Mesmo que eu esfregue até gastar as pedras, eles não vão ficar brancos...

— Se mandei, obedeça! Se os ladrilhos são cinzentos, não sabe reformá-los e mudar a cor? Só dá desculpas, recebe salário sem trabalhar! Na hora de comer, não vejo você recusando nada; quando precisa fazer alguma coisa, é uma reclamação atrás da outra! Que falta de compostura!

Naquele dia, o tirano parecia um cachorro raivoso. Estava evidente que só queria atormentar Ning Xiaoxiao.

Ela nem sabia como ofendera aquele sujeito. Mas ele era o imperador, e ela apenas uma criada. Como poderia desobedecer?

Assim, engoliu as dez mil ofensas que tinha na ponta da língua e, com um sorriso forçado de dentes arreganhados, perguntou: — Então de que cor Sua Majestade deseja o piso? Vou providenciar agora mesmo.

— Preto multicolorido.

Lu Linyuan respondeu com aquela cor absurda sem hesitar nem por um segundo.

Não havia motivo especial. Só queria dificultar a vida de Ning Xiaoxiao. Do contrário, jamais conseguiria descarregar a raiva que sentia e acabaria tendo outro ataque impotente de fúria.

Ning Xiaoxiao aceitou respeitosamente a ordem descabida. Ao sair, resmungou em pensamento:

【Quer um preto multicolorido? É só encostar sua cara no chão e usar copiar e colar! Ou, pelo menos, olhar no espelho! Old dog king!】

Ôudi, dóguê, quim?

Quantas vezes ela já me chamou assim?

Hum... O que significam essas palavras esquisitas?

Lu Linyuan tinha uma reunião marcada com o Grande Acadêmico e o Ministro da Receita naquela tarde, mas agora não podia ir embora.

Se saísse, Gu Sijin certamente ajudaria Ning Xiaoxiao a pensar numa forma de lidar com a ordem.

Ele faria questão de ficar ali e observar a reforma do piso do Palácio Zhongcui. Se não ficasse bom, cortaria o salário de Ning Xiaoxiao, mandaria que esfregasse os penicos e a deixaria três dias sem comer!

Hum... Talvez dois dias.

Se ela morresse de fome em três, ainda sobraria para mim a tarefa de enterrar o corpo!

Só que Ning Xiaoxiao não se deixaria vencer por uma exigência dessas.

No ensino médio, estudara artes plásticas. Se não tivesse ficado dois pontos abaixo da nota exigida nas matérias gerais, já teria ingressado na Academia de Belas-Artes da capital.

Todos os professores diziam que ela tinha talento e sensibilidade. Na universidade, fizera muitos trabalhos de pintura mural para complementar o orçamento. Para ela, mudar a cor dos ladrilhos era praticamente o mesmo que pintar uma parede. Resolveria num instante.

Mandou Qiqi e as outras buscarem muitas tintas na Oficina Ruyi e, com pinceladas largas, começou a pintar os ladrilhos no centro do pátio.

Primeiro delimitou a área e cobriu toda a superfície com uma vasta camada de tinta preta.

Depois usou o fundo escuro para compor uma pintura.

Na parte inferior, desenhou árvores enfileiradas e grama verdejante; acima, nuvens de um branco suave, entre as quais despontava uma lua prateada.

Sob a lua, pintou duas pessoas.

Os rostos eram tão realistas que qualquer um reconheceria Ning Xiaoxiao e Gu Sijin à primeira vista.

Na mão esquerda, representou uma lanterna vermelha iluminando o caminho; na direita, desenhou uma coleira com a qual conduzia um cachorro sem raça definida, típico da China, de língua de fora.

Qiqi e as outras se aproximaram para espiar e não pouparam elogios ao talento dela.

— Uau, Xiaoxiao! Você pinta tão bem! Melhor até que os artistas da Oficina Ruyi!

— É verdade! A senhora e você parecem vivas no desenho! E esse cachorro! Se alguém olhasse à noite sem prestar atenção, pensaria que era de verdade!

— Xiaoxiao, você é incrível! Quando tiver tempo, pinta um retrato meu também?

Os comentários no pátio atraíram Lu Linyuan e Gu Sijin para fora.

Ao ver Ning Xiaoxiao com o pincel na mão, pintando com uma desenvoltura impressionante, os dois ficaram surpresos.

Ninguém imaginaria que uma simples criada pudesse ter tamanha habilidade.

Até Lu Linyuan, acostumado a apreciar grandes obras, não pôde deixar de elogiá-la em pensamento:

Com um domínio tão extraordinário, nem o melhor pintor do palácio provavelmente conseguiria se equiparar a ela.

Quem, afinal, é essa mulher maluca?

A admiração quase lhe subiu à cabeça, fazendo-o esquecer que fora ali justamente para implicar com Ning Xiaoxiao!

Quando ela terminou, ele perguntou: — A pintura é boa, mas onde está o preto multicolorido?

Ning Xiaoxiao enxugou o suor da testa e respondeu, sorridente: — É uma cena noturna, então o fundo é preto. Sobre ele, temos uma lua prateada, nuvens de um branco suave, árvores verdes, grama verde-azulada, flores de várias cores e até o manto de bordado Suzhou que minha senhora veste, que reúne muitos tons. Como é proibido usar amarelo como ornamento dentro do palácio, fiz questão de pintar também um cachorro amarelo!

O cachorro que Ning Xiaoxiao pintara representava Lu Linyuan.

E fora de propósito.

Ainda apontou para o animal e perguntou ao imperador: — Majestade, veja! O cachorrinho está até com a língua de fora! Não é uma gracinha?

Lu Linyuan examinou a pintura atentamente. Hm, era mesmo bem bonitinho.

Mas limitou-se a comentar: — Aceitável.

Ela cumprira a ordem imperial com excelência e ainda recebera elogios de todos.

Parecia que não haveria como implicar com ela naquele momento. Muito bem, vou descansar e volto a procurar defeitos à noite!

Quando estava para sair, ouviu outro pensamento debochado de Ning Xiaoxiao:

【Tchauzinho, meu adorável old dog king!】

*

Como ela insistia naquele apelido estranho, assim que Lu Linyuan voltou ao Palácio Chaoyang e se encontrou com o Grande Acadêmico, tratou de perguntar: — O senhor é muito instruído. Sabe o que significa “ôudi dóguê quim”?

O Grande Acadêmico acariciou a barba, refletiu um instante e disse: — Parece uma expressão de língua ocidental. Se for, a pronúncia provavelmente é *old dog king*.

Lu Linyuan franziu a testa. — E o que significa?

— *Old* significa velho; *dog* é cachorro; *king* é rei ou governante. Em nossa língua, dependendo do contexto, também poderia designar um imperador. Mas, nessa expressão, provavelmente não tem relação com Sua Majestade. Deve se referir a um cachorro já idoso que lidera uma matilha... um rei dos cães? Em resumo, um velho rei cachorro.

Ao ouvir a explicação, o rosto de Lu Linyuan voltou àquele preto multicolorido...

Que ultraje!

Então ela não se contenta mais em me chamar de imperador cachorro e agora passou a me chamar de velho rei cachorro?!

Muito bem! Excelente! Ning Xiaoxiao, você me paga!

Hm, espere...

Naquela pintura no chão do Palácio Zhongcui, Gu Sijin e ela estavam segurando a coleira de um cachorro...

Quer dizer que ela está me levando para passear como se eu fosse o cachorro?!

Ao perceber isso, o tirano, que passara a vida inteira resistindo teimosamente a tudo, quase perdeu o fôlego e desmaiou de indignação...

# Validação do capítulo 95

- Fonte primária: `novel_capitulos_61_a_120(20261103-205857).docx`, original em chinês tradicional.
- Limites: parágrafos DOCX 2525 (título) a 2603 (antes do capítulo seguinte). Índices baseados em zero, como na biblioteca python-docx.
- Unidades não vazias de origem: **76**. Unidades traduzidas e linhas de cotejo: **76**.
- Índices ausentes na tradução: **0**. Índices excedentes: **0**. Campos vazios: **0**.
- Conferência: alinhamento estrutural um a um; tradução produzida a partir dos parágrafos chineses. A equivalência semântica foi revista durante a redação, mas não houve segunda auditoria linguística independente. A equivalência quantitativa não comprova sozinha ausência de erros internos.
- Observações editoriais: O trocadilho 五彩斑斕的黑 foi mantido como “preto multicolorido”. “Old dog king” permanece em inglês e sua interpretação é explicitada na narrativa. O título usa o diminutivo Yuanyuan para o imperador. A escolha “cachorro sem raça definida, típico da China” traduz 中華田園犬 sem atribuir raça específica.
- Não foram incluídos acontecimentos do capítulo seguinte.

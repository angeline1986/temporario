# Capítulo 94 — Vou fazer Xiaoxiao experimentar o sofrimento de uma gravidez

No dia seguinte, quando Gu Sijin foi ao Palácio Fengluan apresentar seus respeitos à imperatriz, Ning Xiaoxiao fez questão de dobrar a manga interna da senhora, deixando à mostra um trecho de seu antebraço branco, exatamente onde antes ficava a marca de castidade.

O outono já começava a esfriar. Como a imperatriz não suportava o frio, os braseiros do Palácio Fengluan haviam sido acesos mais cedo.

Lá dentro, o calor era primaveril. Uma a uma, as consortes tiraram os mantos de frio; Gu Sijin fez o mesmo.

Os registros do Departamento dos Assuntos Imperiais não eram nenhum segredo de Estado. Bastava às consortes gastar algumas moedas para subornar alguém e descobrir quem havia sido chamada para servir ao imperador a cada noite.

Sabendo que Lu Linyuan convocara Gu Sijin novamente na véspera, a Consorte Yun zombou: — A Atendente Gu parece meio abatida hoje. O que foi? Ficou exausta fazendo espacate para entreter Sua Majestade ontem à noite?

A provocação provocou uma gargalhada geral.

Gu Sijin não deu explicações. Deixou que Yun falasse e apenas subiu mais um pouco a manga.

O gesto, fora de hora, naturalmente chamou atenção.

A Atendente Xiao, sentada ao lado dela, notou imediatamente a ausência da marca e exclamou: — Onde está sua marca de castidade?

Todos olharam em uníssono para o braço de Gu Sijin. De fato, sobre a pele alva como a neve, não havia mais o pontinho vermelho de cinábrio.

A Consorte Li perguntou: — Isso quer dizer que você...?

Gu Sijin sorriu com timidez: — Ontem à noite, Sua Majestade estava disposto a... e eu não o recusei. Pensando bem, fui teimosa demais antes. Sempre achei que esse tipo de intimidade só deveria acontecer quando os sentimentos fossem recíprocos e, por isso, resisti tanto. Mas depois daquela armação desprezível e de como Sua Majestade me protegeu, fiquei verdadeiramente comovida.

Mordeu de leve os lábios, com as bochechas coradas, como se estivesse morrendo de vergonha. — Assim, ontem à noite, nem Sua Majestade nem eu conseguimos conter nossos sentimentos e... ah! Só de lembrar, fico envergonhada.

Ning Xiaoxiao a ensinara a dizer tudo aquilo.

Até o tom de voz havia sido ensaiado várias vezes, antes, no Palácio Zhongcui.

Por isso, quando Gu Sijin terminou, todas ficaram de queixo caído.

Haviam zombado dela nos últimos dois dias, e agora ela lhes demonstrava com os próprios atos:

Se Gu Sijin quisesse conquistar o favor imperial, bastava mover alguns pauzinhos.

De quebra, deixava um aviso para que as consortes se comportassem: agora era, aos olhos de todos, a mulher que ocupava legitimamente o coração do imperador. Quem ousasse dificultar sua vida poderia sofrer as consequências das palavras sussurradas ao pé do travesseiro imperial.

Afinal, até a Consorte Nobre, a mulher mais arrogante e autoritária do harém, havia sido rebaixada ao posto de Concubina depois de enfrentar Gu Sijin.

Quem não teria receio dela?

Enquanto todas ainda estavam pasmas, a imperatriz foi a primeira a sorrir e felicitá-la: — Que notícia maravilhosa! Se você e Sua Majestade estão tão unidos, cuide bem da saúde. Se puder dar descendentes à família imperial, será uma alegria ainda maior.

Terminados os cumprimentos, Gu Sijin e Ning Xiaoxiao caminhavam por uma passagem do palácio quando a Consorte Yun foi atrás delas.

Dessa vez, porém, a atitude dela em relação a Gu Sijin era completamente diferente da anterior.

Desceu do palanquim e aproximou-se. Ao ver Gu Sijin prestes a saudá-la, segurou-a com um sorriso: — Entre irmãs, para que tanta cerimônia? Eu sempre disse que você não era uma mulher qualquer e que um dia o imperador reconheceria seu valor.

Gu Sijin respondeu com um sorriso frio e afastou delicadamente a mão de Yun. — O favor que recebo hoje pode desaparecer amanhã. Nunca fui uma pessoa de muita sorte. Sua Majestade só me considera uma novidade divertida, e isso não vai durar.

Terminou de falar, fez outra reverência e se afastou sem dar mais atenção à Consorte Yun.

Manteve a pose até a entrada do Palácio Zhongcui. Só então soltou o ar que vinha prendendo.

— Ufa! Estou exausta. — Levou a mão ao peito e respirou fundo algumas vezes. — Xiaoxiao, fui bem? Não deixei escapar nada, deixei?

— Minha senhora foi excelente. Depois de hoje, elas vão nos deixar em paz por um bom tempo!

Gu Sijin pegou a mão dela e a apertou com carinho. — Foi graças a você que conseguimos pensar em tudo. Sozinha, eu jamais teria imaginado uma estratégia dessas.

*

Depois do almoço, Gu Sijin voltou ao quarto para descansar.

Ning Xiaoxiao estava prestes a voltar ao próprio aposento e chamar Xiao Qi para receber a recompensa quando apareceu um jovem eunuco do Portão Kangding.

Trazia uma carta da família de Gu Sijin.

Ning Xiaoxiao foi entregá-la à senhora.

Naquele momento, Gu Sijin estava recostada preguiçosamente num assento acolchoado, lendo um livro. Ao saber que chegara uma carta de casa, apressou-se a abri-la.

À medida que lia, seus olhos ficaram vermelhos.

Ning Xiaoxiao lhe ofereceu um lenço limpo. — Minha senhora, o que aconteceu? Há algum problema em casa?

— Não. Meu pai e minha mãe estão bem. É que minha mãe escreveu dizendo como sente minha falta, e eu também sinto muita saudade dos dois.

Enxugou as lágrimas e releu várias vezes a pequena carta de apenas dez linhas.

Ning Xiaoxiao a observava e também sentiu um aperto no coração.

Ao menos os pais de Gu Sijin podiam trocar cartas com a filha. Ler aquelas palavras era quase como vê-los; ajudava a aliviar, ainda que por um instante, a dor da saudade.

Mas e ela?

Desde pequena, nunca passara mais de uma semana longe dos pais. Tinha a melhor mãe do mundo e o pai mais carinhoso que existia. Antes de entrar naquele livro, sempre pensava que, se um dia se casasse, jamais iria morar em outra cidade.

Não suportaria ficar tanto tempo longe da família.

E agora já fazia quase quatro meses que viera parar naquele lugar maldito.

Se também tivesse desaparecido no mundo real, seus pais deviam estar desesperados à sua procura.

Pensar nisso lhe apertava o peito e dava vontade de chorar.

Mas Gu Sijin parecia ainda mais chorona: as lágrimas caíam como contas de um colar partido, sem parar.

Ning Xiaoxiao compreendia a saudade da família. Não adiantaria consolá-la com palavras; melhor distrair sua atenção.

Curiosa, olhou o livro ao lado de Gu Sijin, cuja capa trazia dois personagens desenhados, e perguntou: — Minha senhora, que livro é esse? Tem duas pessoinhas coloridas na capa! Nunca vi um assim. Que interessante!

— É um romance popular. Leio para me distrair quando não tenho o que fazer.

Um romance...

Ning Xiaoxiao se arrependeu imediatamente de tocar no assunto.

【Só de falar em romance já me dá raiva! Se eu não tivesse tido a mão tão inquieta e escrito aquela historinha do tirano grávido, nunca teria sido transportada para este lugar infernal!】

【E ainda escrevi quinhentos caracteres! Nem no ensino médio eu conseguia fazer uma redação de quinhentas palavras! Buááá, dá vontade de chorar!】

— Ah, Majestade! Quando foi que chegou?

A voz surpresa de Bengbeng veio da porta. No instante seguinte, a porta se abriu e Lu Linyuan entrou lentamente, vestido com um robe de brocado negro decorado com nuvens douradas.

Seu semblante estava sombrio. Evidentemente, não estava de bom humor.

Gu Sijin se apressou a levar Ning Xiaoxiao para saudá-lo. — Longa vida a Sua Majestade.

Ele nem sequer lhes mandou levantar. Ficou apenas olhando as duas em silêncio.

Mais precisamente, o olhar em chamas estava fixo em Ning Xiaoxiao, como se quisesse arrancar-lhe a pele e os tendões naquele instante.

A dúvida que o atormentava havia tanto tempo enfim encontrara resposta.

Caso solucionado!

Muito bem! Maravilhoso!

Então foi mesmo você quem usou alguma feitiçaria às minhas costas para me deixar grávido!

As mãos pendidas ao lado do corpo se fecharam com tanta força que as veias saltaram sob a pele, como serpentes verdes enroscadas numa floresta.

【Mais cedo ou mais tarde, farei você experimentar todo o sofrimento de uma gravidez!】

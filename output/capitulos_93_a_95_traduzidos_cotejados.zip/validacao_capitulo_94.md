# Validação do capítulo 94

- Fonte primária: `novel_capitulos_61_a_120(20261103-205857).docx`, original em chinês tradicional.
- Limites: parágrafos DOCX 2452 (título) a 2524 (antes do capítulo seguinte). Índices baseados em zero, como na biblioteca python-docx.
- Unidades não vazias de origem: **70**. Unidades traduzidas e linhas de cotejo: **70**.
- Índices ausentes na tradução: **0**. Índices excedentes: **0**. Campos vazios: **0**.
- Conferência: alinhamento estrutural um a um; tradução produzida a partir dos parágrafos chineses. A equivalência semântica foi revista durante a redação, mas não houve segunda auditoria linguística independente. A equivalência quantitativa não comprova sozinha ausência de erros internos.
- Observações editoriais: Cenas de consumação entre Gu Sijin e o imperador são um relato ensaiado por Ning, não um acontecimento confirmado. O texto original diz 500字 (quinhentos caracteres) na primeira referência e 500個字 na segunda; a frase sobre redação escolar foi adaptada naturalmente.
- Não foram incluídos acontecimentos do capítulo seguinte.

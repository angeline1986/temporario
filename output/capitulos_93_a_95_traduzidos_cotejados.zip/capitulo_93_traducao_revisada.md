# Capítulo 93 — Majestade, andam dizendo que o senhor não dá conta

A dor de Gu Sijin não era muito forte. Sentira apenas uma pequena contração na parte inferior do abdômen, acompanhada de um arrepio frio. Depois de ficar agachada por um instante, passou.

Lu Linyuan perguntou: — O que houve?

— Não foi nada, Majestade. Talvez eu tenha tido uma cãibra no baixo-ventre ao erguer a perna.

— Sua constituição é mesmo peculiar. Até no baixo-ventre você tem cãibras? Enfim, vá descansar.

Ning Xiaoxiao sabia que as coisas não podiam ser tão simples. Se tivesse sido apenas uma “cãibra”, sua missão jamais teria sido concluída.

Ao ajudar Gu Sijin a se levantar, fez questão de dar uma olhada na marca de castidade em seu antebraço.

Como imaginava, a cor da marca estava desaparecendo aos poucos.

Isso significava que, de fato, a ginástica tinha rompido aquela membranazinha de Gu Sijin!

Rapaz, mas que espetáculo é esse?! Nunca vi uma dessas na vida. Hoje meus olhos se abriram!

Se a marca de castidade de Gu Sijin desaparecesse de repente sem que Lu Linyuan soubesse, não seria facílimo alguém armar contra ela no futuro?

Ning Xiaoxiao resolveu apontar aquilo na mesma hora. Exclamou: — Ah! Minha senhora, sua marca de castidade...!

A exclamação atraiu imediatamente os olhares de Gu Sijin e Lu Linyuan.

No braço claro da jovem, a marca avermelhada ia perdendo a cor.

Segundo aquela crença, a marca só desaparecia gradualmente dessa maneira no instante em que uma mulher perdia a virgindade.

Lu Linyuan nunca vira coisa igual. Ele nem sequer encostara em Gu Sijin. Mesmo quando seu “21” voltou a se erguer, fora graças às “provocações” de Ning Xiaoxiao, sem relação alguma com Gu Sijin.

Como era possível que ela tivesse perdido a marca simplesmente fazendo ginástica?

Olhou para Gu Sijin, completamente desnorteada, e depois para Ning Xiaoxiao, que parecia cheia de segundas intenções.

Vocês duas estão tentando me extorquir com uma fraude dessas, como se estivessem reivindicando a Lua?

Imediatamente, soltou três negativas em sequência, tentando salvar a própria reputação:

— Não fui eu! Não fiz nada! Parem de inventar!

Gu Sijin, atônita, viu a marca desaparecer diante dos próprios olhos. — M-mas... o que está acontecendo?

Ning Xiaoxiao explicou: — Ouvi dizer que exercícios muito intensos às vezes podem causar pequenas lesões nas partes íntimas de uma mulher, dando a falsa impressão de que ela perdeu a virgindade. Como Sua Majestade vive mandando minha senhora ao Palácio Chaoyang fazer ginástica, imagino que o esforço acumulado tenha provocado esse acidente hoje.

Pensou: 【Essa não é a oportunidade perfeita para a pequena Gu finalmente conquistar algum respeito no harém? Sem a marca, todas as consortes vão pensar que ela dormiu com o imperador. Quem ainda ousaria desrespeitá-la?】

Enquanto falava, lançou um olhar a Lu Linyuan e, sem a menor cerimônia, jogou a responsabilidade sobre ele. — De todo modo, minha senhora é uma consorte de Sua Majestade. Foi por causa do imperador que ela perdeu a virgindade, então não há problema nenhum.

Lu Linyuan: — ???

— Insolente! Não espalhe boatos a meu respeito! Foi ela quem se machucou fazendo ginástica. O que tenho a ver com isso?

— Mas foi Sua Majestade quem mandou que ela fizesse os exercícios! Por acaso vai negar sua responsabilidade? Agora que a marca desapareceu, se Sua Majestade não reconhecer o ocorrido, o que minha senhora deverá responder quando perguntarem?

Lu Linyuan sabia muito bem o que Ning Xiaoxiao pretendia e não admitiria aquilo de jeito nenhum.

— Se perguntarem, digam a verdade.

Vendo aquele caminho fechado, Ning Xiaoxiao precisou encontrar outra estratégia.

Fingiu estar aflita e suspirou: — Sua Majestade pensa que estou fazendo isso por minha senhora? É pelo bem do imperador! Sua Majestade nem imagina os rumores que correm às escondidas pelo palácio. São coisas tão horríveis que... ai, nem tenho coragem de repetir!

Deixou a frase pela metade, fazendo suspense. Achou que a curiosidade levaria Lu Linyuan a perguntar mais.

Mas ele respondeu: — Se não tem coragem, guarde para você! Estou cansado. Podem se retirar.

Ning Xiaoxiao: 【??? Por que ele não segue o roteiro?!】

【Não importa! Mesmo que não queira ouvir, vou contar!】

— Já que Sua Majestade deseja saber, vou arriscar a vida para lhe dizer!

Lu Linyuan: — ???

Quando diabos eu disse que queria saber?!

Antes que ele pudesse impedi-la, Ning Xiaoxiao já havia começado a falar sem filtro:

— Dizem por aí que Sua Majestade está no trono há quatro anos, mas nunca frequenta de verdade o harém. Como é um homem no auge do vigor, especulam que talvez tenha... algum problema íntimo...

— Em outras palavras, dizem que Sua Majestade... não consegue dar conta do recado...

A ousadia de Ning Xiaoxiao deixou até Gu Sijin boquiaberta. O rosto de Lu Linyuan alternou entre o verde e o branco, e a fúria em suas sobrancelhas dava a impressão de que ele despedaçaria Ning Xiaoxiao ali mesmo.

Gu Sijin se apressou: — Majestade, Xiaoxiao fala sem pensar. Peço que a perdoe. Assumirei pessoalmente as consequências do meu descuido e não permitirei que Sua Majestade seja envolvido.

Deu um empurrãozinho em Ning Xiaoxiao, franzindo a testa e balançando a cabeça. — Xiaoxiao, peça desculpas ao imperador, depressa!

Desculpas?

Pedir desculpas estava fora de questão. Já que abrira a boca, no mínimo precisava terminar e observar a reação de Lu Linyuan.

Bastava manter tudo dentro do limite de três minutos.

Se o irritasse de verdade, era só retroceder o tempo.

Quem não arrisca não petisca! Quem sabe não trocava uma bicicleta por uma moto?

Sem qualquer instinto de sobrevivência, Ning Xiaoxiao prosseguiu diante daquele vulcão prestes a entrar em erupção: — Mesmo que Sua Majestade não se importe com os rumores, já não está cansado de ouvir a imperatriz-viúva importuná-lo todos os dias? Agora que a marca de minha senhora desapareceu, o imperador tem uma desculpa perfeita para acalmar a imperatriz-viúva por algum tempo e fazê-la parar de se intrometer na vida do seu harém!

Lu Linyuan estreitou os olhos e olhou Ning Xiaoxiao de cima a baixo.

Essa mulher realmente estava cansada de viver!

Se ele não lhe desse uma lição naquele dia, ela acabaria acreditando que podia fazer o que quisesse com ele!

Estava prestes a anunciar um castigo quando ouviu os pensamentos dela, numa voz lastimosa:

【Por favorzinho, cai nessa só desta vez!】

【Eu sirvo à pequena Gu. Se ela não conseguir viver em paz no harém e todas essas consortes resolverem atacá-la, quem você acha que vai sofrer primeiro? Eu, é claro!】

【A pequena Gu ainda tem a família para protegê-la. E eu tenho o quê? Tenho é coisa nenhuma! Só quero me agarrar às pernas de alguém poderoso e viver de boa, feito um peixe preguiçoso. É pedir tanto assim?】

Ao se acalmar, Lu Linyuan começou a refletir.

O que Ning Xiaoxiao dizia não era inteiramente absurdo.

Ele conhecia muito bem as mulheres do próprio harém. Gu Sijin se tornara o alvo de todas; como sua criada pessoal, Ning Xiaoxiao certamente seria a primeira a sofrer com os ataques.

Se aquelas consortes a matassem com alguma intriga, ele não perderia um tesouro capaz de prever o futuro?

Além disso, estava realmente farto das cobranças diárias da imperatriz-viúva. Poderia aproveitar o incidente, usar Gu Sijin como escudo e calar a mãe.

É claro que jamais admitiria, nem sob pena de morte, que concordara para proteger Ning Xiaoxiao.

Preferia convencer a si mesmo de que tudo o que fazia atendia exclusivamente aos próprios interesses, sem a menor relação com ela.

Como se só assim pudesse preservar a dignidade suprema e a reputação de imperador.

Por fim, cedeu: — Pois bem! A honra de uma mulher é de suma importância. Também não quero que a Atendente Gu seja alvo de comentários injustos. Se alguém perguntar, vocês, senhora e criada, podem dizer o que quiserem. Fingirei que não ouvi nem vi nada.

Ning Xiaoxiao se abriu num sorriso e imediatamente puxou Gu Sijin para se curvarem em agradecimento pela graça imperial.

No entanto, mal terminou de falar, Lu Linyuan se arrependeu.

Eu ainda sou virgem, e uma das minhas consortes agora vai passar por mulher experiente antes de mim?

Que absurdo!

O cúmulo do ridículo!

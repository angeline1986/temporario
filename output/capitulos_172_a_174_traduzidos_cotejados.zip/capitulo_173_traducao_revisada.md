# Capítulo 173 — Ele é meu namorado; ela é minha esposa

Qi Meijuan era mulher de atitude: se aparecesse um tarado, ela partia pra cima mesmo!

Qual mãe, ao ver um homem pelado escondido no guarda-roupa da filha, não ia querer afiar a faca para o abate?

Ainda mais uma mãe com o temperamento dela.

Varreu o quarto com os olhos, pegou o esfregão atrás da porta e se preparou para acertar a cabeça de Lu Linyuan.

Ning Xiaoxiao ficou paralisada.

Lu Linyuan sabia artes marciais e era muito habilidoso. Se os dois começassem a brigar de verdade, não seria sua mãe quem acabaria levando a pior?

Desesperada, saltou para o meio dos dois e agarrou o cabo do esfregão.

— Poupe a vida dele, em nome do esfregão!

— Mãe, não bate! Ele... ele é meu namorado! — E, empurrando a cabeça do esfregão para baixo, repetiu: — Pra trás, pra trás!

Sem saber mais o que dizer, resolveu soltar uma bomba que deixaria todo mundo sem palavras junto com ela.

Qi Meijuan arregalou os olhos; Ning Dazhi tapou a boca para esconder o riso e ainda levantou o polegar para a filha.

Já Lu Linyuan abaixou silenciosamente a cabeça para olhar as próprias coxas:

【Maldição! Não foi você quem disse que gostava de coxas grossas? Foi por isso que me dediquei aos exercícios!】

【E agora está dizendo que minhas pernas parecem as de um elefante?!】

Ele era o imperador da dinastia Qi! E mesmo no mundo moderno continuava sendo imperador!

A situação já era humilhante o suficiente. Se Ning Xiaoxiao o insultasse e ele engolisse em silêncio, onde ficaria a majestade do Filho do Céu?

Pensou um pouco. Para xingar no mundo moderno, precisava usar os métodos modernos.

Lembrou que Ning Xiaoxiao lhe dissera que «esposa» era um insulto na terra natal dela. Então, inflando-se de autoridade, soltou no meio do silêncio:

— Pois você é que é uma esposa!!

(Nota da autora: Quem esqueceu essa piada pode voltar ao capítulo 81! Hora de revisar!)

A frase surpreendente tornou o constrangimento absoluto.

Qi Meijuan o fuzilou com o olhar: — Rapaz, você é bem atrevido! Não pense que pode fazer o que quiser só porque é bonito!

Ning Xiaoxiao decidiu levar sua encenação até o fim, fingindo não conhecer Lu Linyuan. Cutucou seu braço e sussurrou ao ouvido dele: — Ei, fiz tudo que podia por você! Aparecer desse jeito na minha casa... Se não quiser apanhar, trate de se apresentar direitinho aos meus pais!

A origem de Lu Linyuan lhe dera um orgulho arraigado. Se fosse qualquer outra pessoa, ele a ignoraria.

Mas a família de Ning Xiaoxiao era diferente.

A família dela seria também a sua no futuro. Precisava agradá-los.

Só que não fazia ideia das formas de tratamento usadas no mundo moderno. Como deveria chamar os pais de Ning Xiaoxiao?

Ela acabou de falar «pai e mãe» no meu ouvido. Será que está me ensinando como devo chamá-los?

Assim, pigarreou e declarou, com toda a solenidade:

— Pai, mãe, prazer em conhecê-los. Este imperador... eu me chamo Lu Linyuan.

Qi Meijuan: — ???

Ning Dazhi: — o(*￣︶￣*)o

Ning Xiaoxiao: — ￣□￣||

【Você é idiota, por acaso? Como é que... Ah, cansei. Que venha o fim do mundo!】

Por sorte, Ning Dazhi apareceu para salvar a situação: — Xiao Lu, não dá para ficar na nossa casa vestido desse jeito. Venha com o tio. Vou arranjar umas roupas para você.

Passou o braço pelos ombros de Lu Linyuan e o retirou daquele campo minado.

Depois que os dois homens saíram, Qi Meijuan assumiu uma expressão séria ao encarar Ning Xiaoxiao.

Como toda mãe que gosta de dar sermão, apontou para o celular da filha e começou:

— Quantas vezes a mamãe já disse para você parar de ler esses romances quando não tem nada pra fazer? Mas você não ouve! Quando era pequena, lia escondida debaixo do cobertor; cresceu e continua passando a noite acordada, lendo debaixo do cobertor! O que tenho que dizer para você finalmente...

Ning Xiaoxiao resmungou baixinho: — Se você não ficasse pesquisando tecnologia de viagem entre mundos aqui em casa, eu não teria sido sugada para dentro de um livro só porque estava lendo...

Qi Meijuan: — ... Entrou no livro, tudo bem, mas como conseguiu trazer alguém de lá pra cá? Você disse que ele é seu namorado? Você... se apaixonou por ele?

— Não, não, não! — Ning Xiaoxiao negou imediatamente. — Eu disse aquilo da boca pra fora, porque estava com medo de vocês brigarem de verdade. Quanto a ter trazido ele... foi um acidente. Desta vez só posso voltar por um dia, e ele não me reconhece agora. Mãe, você precisa colaborar com a minha encenação. Deixe ele passar esse dia no mundo moderno e pronto.

Fez um biquinho, puxou a manga de Qi Meijuan e manhosamente implorou: — Tá bom, mamãezinha? Se ele descobrir quem eu sou, quando voltarmos ao livro vai acabar me enfiando numa jaula para me estudar como se eu fosse uma alienígena...

— Quero ver ele ousar! — Qi Meijuan respondeu, irritada. — Se aquele moleque se atrever a prender você numa jaula, mando os trezentos guerreiros de Esparta para a cama dele com a minha máquina do tempo!

Ning Xiaoxiao já tinha ouvido do pai muitos segredos sobre Qi Meijuan.

Nas palavras dele: — Sua mãe tem habilidades pequenininhas, mas fala como se fosse a maioral.

A máquina do tempo dela vivia dando defeito. Se fosse tão poderosa quanto dizia, teria tirado Ning Xiaoxiao de dentro do livro há muito tempo; a filha não precisaria sofrer seguindo aquele enredo.

Ning Xiaoxiao ofereceu à mãe um sorriso constrangido, mas educado:

— Isso se você não acabar se mandando outra vez para Jornada ao Oeste e virando o Rei Chifre de Prata...

A vergonha passou depressa pelo rosto de Qi Meijuan. Mudou de assunto e voltou ao interrogatório: — Então você realmente não gosta daquele moleque?

Ning Xiaoxiao encarou diretamente os olhos da mãe e respondeu sem hesitar: — Não gosto.

Mas é justamente quando mentem que as pessoas às vezes ficam olhando fixamente nos olhos de alguém.

Tentam usar aquela expressão de quem não deve nada para disfarçar a mentira.

Os pais que criaram aquela filhinha conheciam bem demais o que se passava em seu coração.

Qi Meijuan soltou um suspiro quase imperceptível e perguntou: — Lembra quando era pequena e mentiu sobre suas notas do fim do semestre? A mamãe percebeu na hora, não foi?

Acariciou a franja de Ning Xiaoxiao e murmurou baixinho: — Se gosta mesmo dele, não precisa se preocupar com tantas coisas.

Ning Xiaoxiao não respondeu. Sempre fora assim: quando surgia um problema complicado, preferia não pensar nele, como se ignorá-lo pudesse fazê-lo desaparecer.

Abraçou Qi Meijuan e enterrou o rosto em seu colo, num tom cheio de manha:

— Mãe, estou com saudade da sua comida.

— O que quer comer? É só me dizer, que a mamãe faz!

— Mãe, você é a melhor.

Aninhada no abraço da mãe como uma criança que nunca crescia, sentia uma paz e uma felicidade imensas.

Enquanto isso, a situação de Lu Linyuan a sós com Ning Dazhi estava muito mais movimentada do que a conversa entre mãe e filha...

# Capítulo 172 — Um bonitão cai do céu

Era como estar num espaço de trevas sem fim, arrastada adiante por uma corrente de vento estreita e violenta.

Com a sensação de ausência de gravidade, Ning Xiaoxiao parecia uma partícula de poeira, flutuando por sabe-se lá quanto tempo naquele vasto mundo desconhecido.

Só quando seu corpo começou a recuperar o peso e surgiu uma claridade tênue à frente foi que abriu os olhos devagar.

Suas pálpebras estavam pesadas; a luz a obrigava a mantê-los quase fechados.

Ouvia o canto cristalino dos pássaros e, ao mesmo tempo, o barulho das senhoras fazendo ginástica dançante na praça, marcando os passos ao som de Eu Sou a Rainha.

— Ela tinha voltado.

Depois de se acostumar à claridade, Ning Xiaoxiao esfregou os olhos doloridos e observou o entorno.

Estava de pijama, deitada na caminha de seu quarto. Ainda abraçava sua almofada de pelúcia do Stitch, e a tela do celular junto ao travesseiro continuava acesa.

Pegou o telefone por instinto. A página ainda mostrava os comentários da obra original, O Tirano Morde Minhas Orelhas Todas as Noites.

Logo viu o comentário que havia escrito para zombar da ideia de o tirano engravidar: alguém o fixara em destaque.

Voltou à tela inicial para conferir a data: 13 de julho de 2022.

Quer dizer que passara mais de meio ano dentro do livro e, no mundo real, transcorrera apenas uma noite?

Sentou-se parcialmente, apoiada na cabeceira, e massageou as têmporas doloridas. Uma dúvida surgiu em sua cabeça:

Será que tinha mesmo entrado no livro?

Ou tudo não passara de um sonho?

Se fosse um sonho, então ela e Lu Linyuan...

BAM!

Um estrondo vindo do guarda-roupa interrompeu Ning Xiaoxiao antes que ela pudesse entrar em seu ritual de melancolia.

Seus olhos se voltaram lentamente para o armário. Prendeu a respiração, fixando a porta cuja pintura já estava descascando.

No instante seguinte, a porta foi empurrada por dentro, revelando diante dela Lu Linyuan, completamente nu, com o corpo de proporções perfeitas e os músculos à mostra.

Cof, cof. E, claro, com tudo o mais que vinha no pacote.

Sem saber se era susto ou alegria, Ning Xiaoxiao soltou um grito involuntário: — Aaaaaah!!!

Ning Xiaoxiao era originalmente uma pessoa do mundo moderno. Ao retornar, tudo se ajustara a ela, inclusive as roupas, que estavam perfeitamente no lugar.

Mas Lu Linyuan era um personagem de papel arrancado à força de dentro de um livro. De onde viriam suas roupas?

Só lhe restava cobrir as partes íntimas com a mão e fuzilar Ning Xiaoxiao com os olhos:

— Feche essa boca! Quem é você? Como ousa sequestrar este imperador e trazê-lo a este lugar infernal?

Tudo ao redor era estranho e incompreensível para ele, inclusive a mulher sentada na cama, que gritava feito louca enquanto o devorava descaradamente com os olhos.

Ning Xiaoxiao: — ???

【O túnel do tempo prendeu a sua cabeça na passagem? Você bebeu minha pílula de voltar pra casa e veio comigo, e ainda tem coragem de perguntar quem eu sou?】

【Se eu não sou Ning Xiaoxiao, sou quem? A avó do Liang Zhichao?】

Mal havia resmungado duas frases quando percebeu algo.

Apalpou o rosto e, num movimento rápido, pegou o celular, abriu a câmera frontal e se olhou.

Meu Deus do céu! Tinha esquecido completamente que sua transmigração fora apenas da alma!

Ao voltar do mundo antigo para o moderno, era natural que tivesse recuperado sua aparência original!

【Ah... eu voltei a ser eu mesma! Claro que ele não me reconhece!】

【Mas até que isso é bom. Só posso ficar aqui um dia. Se ele não me reconhecer, quando voltarmos posso me fazer de desentendida e fingir que não sei de nada! Se me reconhecer, aí sim não vou saber como explicar!】

O sistema e os poderes especiais de Ning Xiaoxiao não a acompanharam ao mundo moderno, mas a capacidade de Lu Linyuan de ouvir seus pensamentos veio junto com ele.

Depois de ouvir com toda a clareza o que se passava na cabeça dela, Lu Linyuan finalmente confirmou que aquela mulher era o verdadeiro corpo da sua maluca!

Tudo acontecera de maneira tão repentina que sua visão de mundo foi reduzida a cacos.

Mas, afinal, ele era o imperador, e sua capacidade de se adaptar ao novo beirava o absurdo.

Examinou com atenção a moça sentada na cama, de cabelos castanhos ondulados caindo sobre os ombros e olhos de corça fixos nele.

Comparado ao corpo de Ning Xiaoxiao na dinastia Qi, aquele corpo verdadeiro parecia mais delicado e adorável, com traços ainda mais refinados.

Bastaram poucos segundos para que ele se deixasse fascinar.

Aquele rosto, aquele corpo... gostava deles ainda mais, de maneira quase incontrolável, do que da aparência dela na dinastia Qi.

O seu amiguinho: 【Para de olhar! Continua assim que eu levanto, quer apostar?】

Os dois continuaram se encarando, constrangidos, sem que nenhum se dispusesse a dizer a primeira palavra.

Quem rompeu aquele silêncio embaraçoso, carregado de tensão íntima, foi a voz de Ning Dazhi do outro lado da porta:

— Minha menina! Será que a minha menina voltou?

— Dá pra sair da minha frente? Anda logo, homem!

A voz feminina que vinha atrás dele pertencia à pessoa de quem Ning Xiaoxiao sentia uma saudade imensa: sua querida mãe, Qi Meijuan.

Havia muito tempo que não ouvia a mãe resmungar. A voz familiar fez seus olhos se encherem de lágrimas na mesma hora.

Mas aquele não era momento de chorar!

Se os pais a vissem no quarto com Lu Linyuan, ainda por cima pelado, ela teria motivos de sobra para chorar de verdade!

Saltou da cama, correu até Lu Linyuan e, empurrando-o, enfiou-o novamente no guarda-roupa:

— Ei! Não diga nada! Se meus pais encontrarem você, acabou pra sua raça!

Sem lhe dar tempo de responder, bateu a porta do armário com um estalo.

No exato instante em que a fechou, a porta do quarto se abriu.

Qi Meijuan ficou imóvel por dois segundos ao ver Ning Xiaoxiao. Então as lágrimas brotaram de seus olhos, e ela avançou para abraçar a filha:

— Minha menina querida! Me perdoe! A mamãe fez você passar por tanta coisa!

Ning Xiaoxiao a abraçou e acariciou delicadamente suas costas. — Está tudo bem, mãe. Não está vendo que estou inteira, aqui com você?

Ao ver mãe e filha chorando juntas, Ning Dazhi tentou fazer uma piada para aliviar o clima:

— Mas a nossa menina nem sofreu tanto assim, né? Teve comida boa, tudo de que precisava e ainda podia escrever bilhetinhos pedindo que mandássemos coisas. Se isso é sofrimento, eu quero uma dúzia desses...

Qi Meijuan, que um segundo antes soluçava emocionada, parou de chorar, virou-se e deu um tremendo tapa em Ning Dazhi. — Cala a boca! Se continuar falando besteira, eu te mando para a Jornada ao Oeste, para virar aquela tartaruga que carrega o monge Tang através do rio!

Ning Xiaoxiao caiu na risada diante da cena.

Fazia tanto tempo que não via ao vivo as discussões entre a mãe esquentada e o pai que sempre acabava levando a pior.

Que coisa boa!

Com o rosto caído e o ar mais injustiçado do mundo depois do tapa, Ning Dazhi resolveu mudar de assunto:

— Filhota, vá trocar de roupa! Papai vai levar você para comer alguma coisa gostosa!

Ninguém imaginava que ele abriria a porta do guarda-roupa sem o menor aviso...

Assim que abriu a porta, Ning Dazhi deu de cara com Lu Linyuan escondido lá dentro.

Para arranjar alguma coisa que cobrisse suas vergonhas, Lu Linyuan havia apanhado um sutiã de Ning Xiaoxiao e o amarrado à cintura. Enquanto fazia isso, ainda se perguntara se a família dela era pobre no mundo moderno — afinal, por que aquela roupa tinha tão pouco tecido?

Ning Dazhi soltou um «Ah!» e imediatamente entendeu o que estava acontecendo.

Fechou o armário num impulso, despertando as suspeitas de Qi Meijuan.

Ela estreitou os olhos e perguntou: — O que está escondendo aí?

Ning Dazhi: — N-nada...

Ning Xiaoxiao também tentou impedir a mãe: — Mãe, aí só tem roupa! O que daria pra esconder?

Qi Meijuan conhecia bem aquela dupla de pai e filha. Quanto mais eles gaguejavam, mais certeza tinha de que escondiam alguma coisa.

— Sai da frente! — Ela empurrou Ning Dazhi para o lado e escancarou o guarda-roupa mais uma vez.

Ao ver Lu Linyuan escondido no armário da filha com aquela indumentária tão peculiar, quase deixou o queixo cair no chão:

— Você... você está usando o... da minha filha para cobrir o seu...?!

— Seu pervertido! Vai apanhar!

# Capítulo 174 — O tirano de roupa moderna: beleza de outro planeta

(Nota da autora: Hoje teremos três atualizações.)

Quanto mais Ning Dazhi olhava para o sutiã da filha amarrado à cintura de Lu Linyuan, mais aquilo o incomodava.

Por isso, depois de levá-lo ao próprio quarto, arrancou de uma vez aquela cobertura improvisada, antes que Lu Linyuan pudesse reagir.

O amiguinho de Lu Linyuan saltou para fora num estalo, fazendo Ning Dazhi soltar um assobio surpreso:

— Ora, ora! Nada mal de tamanho e formato.

Lu Linyuan virou-se depressa de costas, com indignação evidente na voz: — O que pensa que está fazendo?

Ning Dazhi não deu importância: — Nós dois somos homens. Está com vergonha de quê?

Pegou uma caixa de cuecas ainda lacrada na gaveta da mesa de cabeceira e a atirou para ele. — Vista isso.

Lu Linyuan abriu a embalagem com certa dificuldade e, sem que ninguém precisasse ensiná-lo, conseguiu vestir a peça. Só então descobriu que...

Era pequena. Apertava um pouco.

Ning Dazhi percebeu seu desconforto e brincou: — Dá um jeito. Melhor isso do que ficar sem nada.

Em seguida, vasculhou o guarda-roupa e tirou algumas roupas que comprara na promoção de 18 de junho e ainda não tinha usado. Até montou uma combinação caprichada para Lu Linyuan.

Depois de finalmente deixar aquele «selvagem» com uma aparência minimamente civilizada, começou a maquinar outra travessura.

Fez Lu Linyuan se sentar diante da penteadeira da esposa e disse, sorrindo: — Xiao Lu, feche os olhos. O tio tem uma surpresa para você.

Ning Dazhi já havia ido à dinastia Qi e retirado a bala do corpo de Lu Linyuan. Na cabeça do imperador, o pai de Ning Xiaoxiao era muito mais confiável que a própria filha.

Por isso, não desconfiou de nada e fechou os olhos.

Mas poucos segundos depois ouviu um zumbido e sentiu um frio repentino no couro cabeludo.

Abriu os olhos assustado e quase morreu do coração ao ver a própria aparência.

No espelho, seus cabelos compridos estavam soltos; metade continuava longa e esvoaçante, enquanto a outra metade estava raspada bem rente. Parecia um louco recém-fugido de um manicômio.

Ele só podia estar com algum problema na cabeça para ter confiado naquele sujeito!

Afinal, um homem capaz de gerar uma filha como Ning Xiaoxiao poderia por acaso ser uma pessoa normal?!

(Nota da autora: Deixe-me explicar uma coisa: quando ele voltar ao mundo antigo, o cabelo poderá recuperar a aparência original. O pai de Xiaoxiao sabe disso, por isso resolveu cortá-lo; quer que ele saia para um encontro com a filha parecendo um homem moderno normal. Então, por favor, nada de dizer que o pai dela foi mal-educado por cortar o cabelo dos outros sem pedir permissão. Estou avisando de antemão para evitar essa discussão!)

Com a máquina de cortar cabelo na mão, Ning Dazhi já agarrava os fios do outro lado da cabeça de Lu Linyuan para raspá-los também.

Lu Linyuan levantou o braço para impedi-lo e o encarou com uma expressão ameaçadora: — Está tentando me tonsurar como um monge?!

Ning Dazhi: — Cortar seu cabelo. Com esse cabelão, você parece um homem das cavernas. O tio precisa arranjar um penteado do nosso tempo para você.

Ele pesou a máquina na palma da mão. — Se não quiser cortar, tudo bem. Mas vou adiantar um spoiler: minha filha gosta de homens de cabelo curto.

Como assim, «se não quiser cortar, tudo bem»?

Lu Linyuan observou no espelho a própria cabeça, com metade dos cabelos raspados e metade compridos, e mergulhou em pensamentos...

Aquilo era mesmo dar alguma escolha a ele?!

Não havia jeito. Já que estava daquele modo, só lhe restava aceitar! Quem mandou ser tão idiota a ponto de roubar a bebida de Ning Xiaoxiao?

Roubar algo para beber tinha sido uma delícia na hora. Agora que a «retribuição» chegara, teria de aguentar.

Cerrou os dentes e praticamente cuspiu uma palavra: — Corte!

Entre os antigos, os cabelos não eram cortados, salvo em situações de luto nacional; cortá-los também podia ser entendido como uma maldição contra parentes próximos.

O fato de Lu Linyuan ter permitido tão prontamente que Ning Dazhi raspasse seu cabelo tão curto, além de saber que Ning Xiaoxiao gostava de homens de cabelo curto, talvez tivesse outra explicação:

Por exemplo, seus pais biológicos talvez já nem estivessem vivos.

Assim, para ele, desde que sua Xiaoxiao permanecesse a salvo, jamais precisaria enfrentar outro luto nacional em toda a vida.

*

Depois de quase uma hora sendo «trabalhado» por Ning Dazhi, Lu Linyuan saiu do quarto e acabou esbarrando em Ning Xiaoxiao, que vinha andando apressada e distraída.

Como Ning Xiaoxiao só alcançava o peito dele, bateu a testa diretamente nos músculos peitorais do homem. Doeu um bocado.

Ela recuou dois passos, segurando a testa, e ergueu a cabeça devagar. Quando viu Lu Linyuan vestido à moda moderna, ficou boquiaberta:

O homem havia se livrado dos longos e espessos cabelos negros e agora exibia um corte militar bem curto, com os fios recém-raspados aparecendo.

Tinha a coluna ereta, o pescoço longo e um pomo de adão bem marcado que se movia lentamente quando engolia em seco.

Com aqueles traços fortes e o penteado descomplicado, revelava um ar de bad boy que antes passava despercebido.

Vestia uma camiseta preta e, por cima, uma jaqueta esportiva branca.

O zíper da jaqueta estava aberto até a altura do peito, deixando entrever os peitorais discretamente salientes a cada respiração.

Os olhos negros demonstravam certa indiferença. Ao perceber a expressão nitidamente encantada de Ning Xiaoxiao, levou instintivamente o zíper até o pescoço.

Era como se quisesse anunciar ao mundo que ele, Lu Linyuan, era o homem mais recatado de todos: nem as leitoras poderiam olhar, muito menos a própria esposa.

Ning Xiaoxiao sempre achara que Lu Linyuan era um belíssimo homem de época. Mas agora parecia que as roupas modernas lhe caíam ainda melhor: sua beleza, que já atingia o teto quando usava trajes antigos, subira mais vários níveis.

Aquilo já não era o teto da beleza. Era a estratosfera!

E o mais importante: todas aquelas roupas eram do pai dela.

No pai, pareciam roupas de um velhote desleixado. Nele, eram um figurino de modelo elegante e inacessível.

Hmm. Ficava difícil resistir à vontade de levá-lo para a cama.

Lu Linyuan percebeu que os olhos dela o percorriam como um exército conquistando território. Por fora, manteve a serenidade; por dentro, estava radiante.

Até ouvir este pensamento de Ning Xiaoxiao:

【Puta merda! Se você faz uma coisa dessas, como é que vou arrancar seus cabelos daqui pra frente?! Aaaaaah!】

Lu Linyuan: — ...

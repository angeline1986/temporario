# Validação do capítulo 303

- **Original:** `novel_capitulos_301_a_360(20261107-181903).docx` (chinês).
- **Base revista:** `novel capitulos 301 a 360 - ch.epub` (`index_split_002.html`).
- **Índices DOCX:** 146 a 220 (índice absoluto, base zero).
- **Unidades não vazias originais:** 73.
- **Unidades em português:** 73.
- **Correspondência:** 1:1 por ordem de unidade; preservados título, falas e marcadores de fechamento aplicáveis.

## Ajustes e riscos

- Data auspiciosa não significa “pessoas de meia-idade”; omissão dos nomes de três acompanhantes; “贴贴” pede contato carinhoso, não beijo; PS da autora confundia a conclusão de um capítulo com “censura”.
- Harmonização de nomes, cargos e palácios conforme o glossário de continuidade; correções dirigidas de fluência e agente.

## Alcance real

**Revisão semântica focalizada**, com alinhamento estrutural por parágrafo. A parte não alterada da tradução-base EPUB foi preservada e não passou por auditoria frase a frase independente. A igualdade da contagem de unidades não comprova ausência de omissões dentro dos parágrafos, nem elimina a possibilidade de erros sutis de tradução. O CSV contém texto original e versão revisada para auditoria futura.

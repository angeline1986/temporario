Capítulo 303 — A cerimônia de nomeação da imperatriz (I)

No décimo segundo dia do terceiro mês do quinto ano de Qiyuan, o calendário indicava uma data extremamente auspiciosa, propícia a casamentos.

Na noite anterior, Ning Xiaoxiao se mudara para o recém-reformado Palácio Fengluan.

Paredes tratadas e tingidas de vermelho, cortinas vermelhas: para onde olhasse, havia um vermelho quente e acolhedor.

Ela, que normalmente não se importa com nada, teve insônia ontem à noite.

Assim como inúmeras outras jovens, ela havia fantasiado sobre seu futuro casamento.

Seja com um vestido de noiva branco imaculado ou adornada com um manto Xiuhe, ela jamais imaginou que um dia usaria um manto de fênix, seria celebrada por todo o país e o centro das atenções, casando-se com o imperador e se tornando a imperatriz que antes só vira em dramas televisivos.

No dia em que foi coroada imperatriz, o amanhecer chegou muito cedo.

Gu Sijin chegou logo cedo com Qiqi, Qiaqia, Bengbeng e Lala, receosa de que Ning dormisse demais e cometesse algum deslize naquele dia tão importante.

Ao chegarem, encontraram Ning Xiaoxiao sentada em frente à penteadeira, absorta em seus pensamentos.

Gu Sijin não resistiu à tentação de provocá-la: "Você ficou sentada assim a noite toda? Quem me disse ontem que ela não estava nem um pouco nervosa?"

Ning Xiaoxiao revelou seu lado infantil, agarrando-se ao braço de Gu Sijin e implorando: "Irmã... Estou com um pouco de medo..."

"Do que você tem medo? Acha que o Imperador pode te devorar?"

Antes que as palavras terminassem, o som de sinos e tambores pôde ser ouvido ao longe.

O som vinha do Portão Meridiano e anunciava o início da cerimônia de nomeação da imperatriz.

Após dezesseis notas marcantes, a Orquestra Danbi começou a tocar o movimento "Música Pacífica e Auspiciosa".

Os sons eram tão festivos que parecia que o Ano Novo estava quase chegando. Ning Xiaoxiao nunca tinha visto o palácio tão animado em todo o tempo em que estivera ali.

Ela ficou cada vez mais nervosa, suas pequenas mãos agarrando com força as mangas de Gu Sijin, amassando o delicado tecido de brocado.

Gu Sijin deu um tapinha leve no dorso da mão dela e sorriu:

— Por mais nervosa que esteja, só vai passar por isso uma vez. Ou pretende dizer ao imperador que desistiu de se casar?

“Se você ousar contar para ele, ele provavelmente vai te arrastar para o quarto e te dar uma boa ‘lição’ imediatamente.”

Em meio às brincadeiras entre as irmãs, Qiqi trouxe as vestes da corte da Imperatriz.

O manto da corte era de um dourado deslumbrante, bem diferente dos mantos da corte da imperatriz que Zhu Shi costumava usar.

Qiqi afirmou que Lu Linyuan instruiu especificamente o Departamento da Casa Imperial a confeccioná-lo dessa forma, e que era diferente do traje de corte da imperatriz em dinastias anteriores.

Qiaqia e Lala se aproximaram para ajudar, estendendo as vestes da corte e apresentando-as a Ning Xiaoxiao.

Só então ela conseguiu ver claramente o padrão do bordado nas roupas:

O manto era de cetim amarelo-vivo com desenhos de fênix e peônias, forrado com seda branca como a lua e delicados arabescos florais.

Na superfície acetinada, 172 bordadeiras da oficina de bordado em seda trabalharam durante toda a noite para bordar nove dragões dourados.

No peito e na parte posterior dos ombros havia dragões que se estendiam sobre a peça. Na frente, de cada lado, dois dragões disputavam uma pérola, seus corpos surgindo entre nuvens; à luz do sol, os dragões dourados pareciam ainda mais imponentes e vivos.

A lapela interna e as mangas são decoradas com padrões dourados de dragões em espiral, a bainha é adornada com penas de pássaros azuis e uma fita dourada brilhante pende da parte de trás da peça.

O que foi enviado ao palácio dela não era um manto de fênix; era claramente um manto de dragão disfarçado de manto de fênix...

Ning Xiaoxiao acariciou suavemente o tecido das vestes da corte da Imperatriz, seu olhar pousando nas garras douradas do dragão:

"Um, dois, três, quatro, cinco..." Ela ergueu o olhar de repente, com os olhos cheios de espanto. "Este é um dragão dourado de cinco garras? Apenas as vestes da corte do Imperador podem ser adornadas com um dragão dourado de cinco garras. Será que o pessoal do Departamento da Casa Imperial enlouqueceu?"

Gu Sijin cobriu a boca com a mão e riu: "A investidura da imperatriz é um evento importante. Como os servos do Departamento da Casa Imperial ousariam agir de forma tão imprudente? Em vez de dizer que são loucos, é mais preciso dizer que o Imperador os ama a ponto de enlouquecer. Se não fosse pelo decreto do Imperador, quem ousaria fazer isso?"

O momento auspicioso para a investidura foi escolhido, não deixando tempo para Ning Xiaoxiao se entregar aos seus sentimentos.

Antes mesmo que ela pudesse processar o que estava acontecendo, Qiqi e os outros já a haviam ajudado a vestir um manto de fênix e uma coroa de fênix.

Sua maquiagem era requintada e deslumbrante, fazendo-a parecer uma donzela celestial, superando todas as outras em beleza.

Ela não gostava de maquiagem, achando-a incômoda, e sempre aparecia sem maquiagem no palácio.

Ao vê-la completamente vestida hoje, até mesmo Gu Sijin não pôde deixar de suspirar: "O Imperador realmente tem olhos perspicazes. Quando nossa Xiaoxiao está bem vestida, ela fica ainda mais bonita do que as pessoas nos retratos."

Após tudo estar devidamente organizado, Ning Xiaoxiao foi escoltada para fora do palácio.

À porta, Lu Yiqiu, o emissário encarregado da investidura, passeava montado num Pixiu.

O Pixiu balançou sua cauda grossa e comprida, que estava amarrada com um laço vermelho.

Quando Lu Yiqiu viu Ning Xiaoxiao saindo de longe, ficou radiante e acenou para ela incessantemente.

— Cunhada imperial! Cunhada imperial!

Ele conduziu o Pixiu até Ning Xiaoxiao, deu duas voltas ao redor dela e arregalou os belos olhos amendoados, contemplando-a com entusiasmo quase indecente:

— Uau! Cunhada, você parece uma fada! Vem cá me dar um abraço!

Quando estava prestes a se aproximar dela, uma figura de azul-lago apareceu ao seu lado, agarrou-o pelo colarinho e o ergueu de cima do Pixiu.

— Ai! Xiao Lili, me solte! Tem tanta gente olhando! Eu também tenho uma reputação a zelar!

Ren Duanli, que costumava usar roupas pretas e manter uma postura fria, provavelmente nunca vestira nada tão festivo quanto aquele azul-lago.

Ele deixou Lu Yiqiu para trás, criando uma distância segura entre ele e Ning Xiaoxiao, depois se virou, lançou-lhe um olhar fulminante e sibilou em voz baixa:

— Se ousar desrespeitar a imperatriz, seu irmão vai arrancar seu braço e eu vou deixá-lo sem conseguir sair da cama!

Ao ouvir isso, Lu Yiqiu imediatamente murchou como um balão furado. Seu jeito adorável e desavisado divertiu Ning Xiaoxiao e aliviou um pouco sua tensão.

A noiva foi levada em uma liteira nupcial, escoltada por milhares de servos do palácio em ambos os lados da longa rua.

A liteira carregada por oito homens era extremamente estável. Se não fosse pela música cada vez mais alta e alegre, Ning Xiaoxiao talvez nem tivesse percebido que estava se aproximando cada vez mais de seu amado.

O Palácio Fengluan ficava perto do Palácio Chaoyang; Ning Xiaoxiao já percorrera aquele caminho inúmeras vezes.

Mas hoje, sentada na liteira da noiva, ela sentiu que o tempo estava passando excepcionalmente devagar.

Sua mente repassava incessantemente todas as experiências que tivera com Lu Linyuan nos últimos dias. Cada cena era claramente hilária, mas, sem perceber, uma névoa começou a se formar em seus olhos.

Após um período indeterminado, a liteira da noiva parou firmemente em frente ao portão do Palácio Chaoyang.

No instante em que ela saiu da liteira, inúmeras vozes de parabéns surgiram de todas as direções como uma onda gigante.

Ela foi ajudada a descer da liteira por Lu Yiqiu e viu funcionários civis e militares ajoelhados no chão, enquanto Lu Linyuan permanecia não muito longe dela, seu olhar penetrante encontrando o dela.

A luz do sol filtrava-se através dos galhos, fragmentando-se em inúmeras e finas listras douradas.

A luz caiu sobre Lu Linyuan e também desenhou um caminho luminoso entre os dois.

Naquele momento, ela estava extremamente nervosa, com medo de passar vergonha na frente de todos.

O oficial do cerimonial lhe ensinara o protocolo durante vários dias: ao descer da liteira, deveria caminhar até o imperador e se ajoelhar para agradecer a graça imperial.

Em seguida, o comandante da Guarda Imperial e o grande secretário lhe entregariam o livro de investidura e o selo de imperatriz.

Após receber os dois objetos, teria de se ajoelhar novamente em agradecimento ao imperador e à imperatriz-viúva, levantando-se apenas com a permissão dele.

Ela baixou a cabeça e murmurou o procedimento repetidamente, com medo de esquecê-lo, e deu um passo em direção a Lu Linyuan.

Então, um par de botas em formato de nuvem com estampa de dragão apareceu em sua visão periférica.

Ela ergueu os olhos surpresa e viu que Lu Linyuan estava parado à sua frente, com o mesmo sorriso carinhoso de sempre e os olhos cheios de alegria evidente.

O Ministério dos Ritos calculara exatamente cem passos entre a liteira da imperatriz e o imperador, símbolo de cem anos de união feliz.

Ela deu apenas um passo; deveriam ter sido noventa e nove passos.

Mas o homem que ela amava já estava bem na sua frente.

(PS da autora: Não deu para terminar a cerimônia num só capítulo; amanhã tem mais. Ah, o comandante da Guarda Imperial é aquele infeliz pai da ex-imperatriz. A filha perdeu o posto, mas ele ainda terá de entregar pessoalmente à Xiaoxiao o equivalente à certidão de casamento. Quero ver se não fica com a cara ardendo de vergonha!)

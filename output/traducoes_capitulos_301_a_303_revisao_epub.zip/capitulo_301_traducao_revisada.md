Capítulo 301 — Quero nomear Xiaoxiao imperatriz

As feições da imperatriz estavam distorcidas e aterrorizantes de medo.

Ela, que geralmente era calma e serena, entrou em pânico total, abandonando toda a sua compostura anterior, e continuou a se curvar diante de Lu Linyuan, chorando:

— Majestade, tenha piedade! Eu reconheço meu erro! Mesmo que todos esses anos servindo a Vossa Majestade não tenham rendido grandes méritos, ao menos me dediquei! Por favor...

— Não venha me envolver nisso!

Lu Linyuan a interrompeu rispidamente. Depois de espiar Ning Xiaoxiao pelo canto dos olhos, retrucou: — Explique direito: desde quando você me serviu?

Ele queria mesmo era selar com cola aquela boca que só dizia disparates.

A mulher já sabia que não sobreviveria e ainda queria arrastá-lo para o buraco?

Sua pequena ancestral era um poço de ciúmes. Se ouvisse aquela conversa e acreditasse que a ex-imperatriz já compartilhara sua cama, não acabaria arrancando a pele dele?

Essa mulher, mesmo à beira da morte, ainda me arranja problemas!

Com um gesto largo da mão, decretou: — Guardas! Levem a senhora Zhu e concedam-lhe a morte por suicídio!

Sanfu já havia preparado tudo e estava apenas aguardando a ordem de Lu Linyuan para começar a trabalhar imediatamente.

Sanfu, acompanhado de vários servos do palácio, agarrou os braços da ex-imperatriz, tapou-lhe a boca e começou a arrastá-la para fora.

Quando já estavam quase levando a mulher para fora, um eunuco anunciou à entrada:

"A Imperatriz Viúva chegou!"

A imperatriz-viúva entrou no Palácio Fengluan cercada por servos. Ao ver Sanfu e os demais arrastando a ex-imperatriz, repreendeu-os furiosamente:

"Como ousa! Como ousa você, um mero servo, ser tão desrespeitoso com a Imperatriz!"

Sanfu ficou imóvel, sem saber se avançava ou recuava. A imperatriz-viúva tornou a ordenar: — Solte-a agora!

— Não a soltem.

A voz fria de Lu Linyuan interrompeu a postura imponente da Imperatriz Viúva:

— Ela não é mais imperatriz. Agora é apenas Zhu, uma mulher do povo.

— Zhu atentou contra as mulheres do harém, conspirou para matar Tong no Palácio Frio e ainda tentou assassinar a Consorte Nobre Imperial. Acabou de confessar tudo com a própria boca. Retirei-lhe o livro de investidura e o selo da fênix e ordenei que tirasse a própria vida. Ao menos preservaria o corpo inteiro.

A Imperatriz Viúva olhou para trás e lançou um olhar significativo para Qingzhu. Imediatamente, Qingzhu liderou seus homens e resgatou a Imperatriz das garras de Sanfu.

Após escapar de sua situação difícil, a Imperatriz deslizou para a frente e ajoelhou-se, caindo de cara no chão diante da Imperatriz Viúva, batendo com a cabeça no solo.

— Imperatriz-viúva, salve-me... Não quero morrer... Fui injustiçada...

A Imperatriz Viúva baixou seus olhos de fênix e olhou para ela. "Como pode a mãe da nação chorar assim? Qingzhu, ajude-a a se levantar."

Qingzhu ajudou a Imperatriz a se levantar e a colocou atrás da Imperatriz Viúva. A Imperatriz Viúva suspirou e disse a Lu Linyuan:

— Imperador, não se pode decidir sozinho pela deposição da imperatriz. A família Zhu prestou grandes serviços na derrota do clã Tong. Mal esse clã foi erradicado, e o senhor já corre para depor a imperatriz. As pessoas podem acusá-lo de descartar aqueles que lhe serviram depois de conseguir o que queria.

— A imperatriz matou a Concubina Tong com as próprias mãos, mas isso também resolveu um problema para o imperador. Tong já estava condenada à morte; agora encontrou descanso. E quanto à alegação de que a imperatriz atentou contra a Consorte Nobre Imperial?

Seu olhar se voltou para Ning Xiaoxiao, que estava ilesa. — Afinal, a Consorte Nobre Imperial não sofreu ferimento algum. De que crime pretende acusar a imperatriz?

A Imperatriz Viúva falou de maneira séria e solene, mas Lu Linyuan nem sequer olhou para ela durante todo o tempo.

Ele chegou ao ponto de segurar a mão de Ning Xiaoxiao, e os dois conversavam em voz baixa sobre o que iriam jantar...

A Imperatriz Viúva ficou sem palavras por um longo tempo: "Sei que o Imperador tem grande apreço pela Consorte Imperial Nobre, mas depor a Imperatriz é uma questão séria, que pode causar tumulto na corte. O Imperador deve refletir cuidadosamente sobre isso."

"Que tal isso, Vossa Majestade, me dê um pouco de dignidade e puna a Imperatriz por uma ofensa menor, confinando-a aos seus aposentos por três meses e descontando de seu salário o equivalente a um ano?"

"Certo." Lu Linyuan sorriu calmamente e assentiu em concordância com a Imperatriz Viúva.

— Já que minha mãe pediu, naturalmente concordarei. Mas com uma condição: se Zhu continuar como imperatriz, minha mãe não poderá continuar sendo imperatriz-viúva; terá de se contentar com o título de consorte-viúva. Aceita?

"Você!" O rosto da Imperatriz Viúva empalideceu de raiva, e ela bateu sua bengala com cabeça de fênix no chão. "Como o Imperador pôde proferir palavras tão ultrajantes?"

Lu Linyuan zombou: "Não foi isso que aprendi com você? Por que você pode se comportar mal, mas eu não?"

Depois de tantas respostas cortantes, a imperatriz-viúva compreendeu que Lu Linyuan estava decidido: Zhu jamais recuperaria o posto de imperatriz.

Enquanto houver montanhas verdes, haverá lenha para queimar.

Se não podia preservar o título de Zhu, ao menos precisava preservar-lhe a vida.

Afinal, Zhu ainda lhe seria muito útil enquanto estivesse viva.

A imperatriz-viúva insistiu por muito tempo, e ela e Lu Linyuan acabaram em um impasse tão tenso que pareciam prestes a explodir.

Ning Xiaoxiao, que assistia em silêncio àquela confusão, também fazia seus próprios cálculos.

As palavras da Imperatriz Viúva não eram sem motivo.

Neste ponto, seria compreensível que Lu Linyuan anunciasse ao mundo os crimes de Zhu Shi e a depusesse do cargo de imperatriz. No entanto, executá-la certamente daria margem a críticas.

Ning sabia que Lu Linyuan agia por sua causa e, justamente por isso, também precisava pensar nele.

Ela também não queria que seu amado sofresse acusações injustificadas só porque ele queria protegê-la.

Mesmo que Lu Linyuan não se importasse, ela se importava.

Por fim, ela aconselhou: — Os crimes da imperatriz são imperdoáveis, mas ela sempre serviu diligentemente à imperatriz-viúva. Como a imperatriz-viúva não tem filhas, depois de tantos anos criou laços com Zhu. A-Yuan, por que não poupar sua vida, como ela pediu? Assim você também evita as críticas da corte.

Apesar das repetidas tentativas da Imperatriz Viúva de persuadi-lo até que sua garganta secasse, Lu Linyuan se recusou a ceder. No entanto, Ning Xiaoxiao precisou apenas dizer algumas palavras e agir de forma sedutora com Lu Linyuan, e ele concordou com tudo.

A imperatriz-viúva aproveitou: — Já que a Consorte Nobre Imperial também acha que Zhu pode permanecer no palácio, depois de depô-la o imperador poderia conceder-lhe o posto de Consorte Nobre e deixar que...

— Já que minha mãe gosta tanto de Zhu, mantê-la no palácio será uma demonstração de minha devoção filial. Quanto à família Zhu, reconheço seus serviços na derrota do clã Tong e lhes concederei essa consideração.

— Então decidi presentear minha mãe com Zhu: ela será a criada-chefe do Palácio Fengluan, cuidará pessoalmente de minha mãe e a acompanhará nas refeições, nos aposentos e por onde for. Assim aliviará sua “saudade”.

Zhu Shi: “???”

Imperatriz Viúva: "Imperador! Como pôde fazer isso...?"

Lu Linyuan a encarou com um olhar fulminante, sua aura gélida:

"Se você disser mais uma palavra, mudarei de ideia imediatamente e a farei ser despedaçada."

A imperatriz-viúva ficou aterrorizada com a ameaça e achou melhor não insistir.

Lu Linyuan não queria mais perder tempo com as duas. Tomou a mão de Ning Xiaoxiao e seguiu para a saída.

À porta do palácio, encontraram Xiao Yinzi, que vinha trazer uma mensagem:

— Majestade, as Oficinas Imperiais e o Departamento da Casa Imperial informaram que todos os preparativos para a cerimônia de investidura da Consorte Nobre Imperial estão concluídos. Pedem que Vossa Majestade e a consorte venham conferir.

— Não é necessário. — Lu Linyuan apertou a mão de Ning Xiaoxiao e sorriu para ela com ternura.

— Mandem confeccionar novas vestes cerimoniais de imperatriz e um manto de fênix. Peçam ao Observatório Imperial que escolha uma data auspiciosa e transformem a cerimônia de investidura da Consorte Nobre Imperial em uma cerimônia de nomeação da imperatriz.

— Quero nomear Xiaoxiao minha imperatriz.

# Validação do capítulo 301

- **Original:** `novel_capitulos_301_a_360(20261107-181903).docx` (chinês).
- **Base revista:** `novel capitulos 301 a 360 - ch.epub` (`index_split_000.html`).
- **Índices DOCX:** 3 a 69 (índice absoluto, base zero).
- **Unidades não vazias originais:** 65.
- **Unidades em português:** 65.
- **Correspondência:** 1:1 por ordem de unidade; preservados título, falas e marcadores de fechamento aplicáveis.

## Ajustes e riscos

- Pronome de gênero e agente da ação na captura de Zhu; troca de autor do assassinato de Tong; proposta de transformar Zhu em criada-chefe, não em imperatriz; perspectivas internas de Ning e da imperatriz-viúva.
- Harmonização de nomes, cargos e palácios conforme o glossário de continuidade; correções dirigidas de fluência e agente.

## Alcance real

**Revisão semântica focalizada**, com alinhamento estrutural por parágrafo. A parte não alterada da tradução-base EPUB foi preservada e não passou por auditoria frase a frase independente. A igualdade da contagem de unidades não comprova ausência de omissões dentro dos parágrafos, nem elimina a possibilidade de erros sutis de tradução. O CSV contém texto original e versão revisada para auditoria futura.

Capítulo 302 — Quem se opuser, levem para fora e decapitem

Todos sabiam em seus corações que, dado o carinho de Lu Linyuan por Ning Xiaoxiao, a Imperatriz eventualmente teria que abdicar e dar lugar a Ning Xiaoxiao.

Essa demonstração de tanto mimo desperta inveja e é verdadeiramente invejável.

Após saírem do palácio, os dois deveriam voltar juntos para o Palácio Chaoyang em uma liteira, mas Ning Xiaoxiao de repente teve uma ideia estranha.

Ela entrelaçou o dedo indicador no de Lu Linyuan, apertou a mão dele e disse: "Não é longe do Palácio Chaoyang, por que você não vem dar um passeio comigo?"

Lu Linyuan colocou a mão esquerda livre na testa da menina, acariciando suavemente seus cabelos macios, e acenou com a cabeça afetuosamente.

Os dois caminhavam de mãos dadas ao pôr do sol.

Ao verem isso, os criados do palácio na longa rua viraram as costas para a parede, ousando apenas observar contra a luz à distância, em pequenos grupos, depois que os dois se afastaram.

Todos no palácio diziam que Ning Xiaoxiao era uma bênção dos céus. Ela era uma serva que conquistou o coração do imperador em apenas um ano e se tornou a mãe da nação.

Mas somente Lu Linyuan sabia que ter Xiaoxiao era sua verdadeira bênção.

Ning Xiaoxiao permaneceu calada durante todo o caminho, mas não parava de resmungar em pensamento:

【Achei que ele apenas castigaria a imperatriz. Quem imaginaria que a deporia de verdade?】

【Será que ele é idiota?!】

【A política da corte ainda é um emaranhado, e a família Zhu não fica atrás da Tong em matéria de problemas.】

【Mal nos livramos dos chacais e já estamos criando tigres e leopardos...】

【Finalmente a corte tinha se estabilizado, sem precisar passar noites em claro resolvendo assuntos de Estado. Agora, com essa confusão, não teremos sossego.】

【Eu nem disse que precisava ser imperatriz! Saber que ele me ama já basta...】

【Esse cabeça-dura! Lerdo! Machista! Louco de amor! Que raiva!!!】

É claro que ela estava furiosa, pois sabia o quanto Lu Linyuan se esforçara nos assuntos de Tong Guowei e quantas noites passara acordado. Antes, sua vida diária consistia em passar tempo com ela ou tramar contra a corte imperial.

Como ela poderia não sentir pena do próprio homem?

Lu Linyuan a ignorou o tempo todo.

Ele adorava ouvir os pensamentos mais íntimos de Ning Xiaoxiao e mal podia esperar para que ela dissesse mais daquelas doces palavras que normalmente ela nunca diria.

Quanto mais ela agia dessa maneira, mais ele sentia a importância que tinha no coração dela.

Que sorte é ser envolvido pelo mesmo amor de alguém que você ama profundamente.

Eles deveriam estar voltando para o Palácio de Chaoyang, mas os dois vagaram sem rumo e não perceberam que haviam parado perto do Lago Imperial.

Ning Xiaoxiao de repente teve vontade de rir ao se lembrar de como havia planejado empurrar Lu Linyuan para o Lago Imperial a fim de completar sua missão de beijar o tirano à força, e de como havia sofrido e quase perdido a vida.

Então seu A-Yuan já a protegia incondicionalmente desde aqueles primeiros tempos...

Ela inclinou a cabeça para Lu Linyuan: — Na verdade, A-Yuan, você não precisava romper com a família Zhu por minha causa. Eles ainda têm alguma utilidade na corte; não é bom ofendê-los tão diretamente...

Sempre que algo lhe preocupa, ela não consegue evitar fazer beicinho, igualzinha a um patinho.

Lu Linyuan sorriu e estendeu a mão para beliscar os lábios dela. "Você realmente não confia no seu marido?"

Em tom arrogante, digno de um imperador, ele respondeu: — Se preciso daqueles parasitas para governar o império, em que sou diferente daquele inútil do imperador anterior?

Ning Xiaoxiao: “...”

【Você é muito nobre, muito grandioso... Quando fica arrogante, até o próprio pai você xinga. Melhor não mexer com você...】

Ao ouvir isso, Lu Linyuan sorriu com ar de quem sabe de algo.

Ele parou de repente, encostou-se no parapeito da ponte arqueada e puxou Ning Xiaoxiao para seus braços.

"No entanto, esse incidente me fez entender ainda mais os sentimentos de Xiaoxiao por mim."

"Hã?" Ning Xiaoxiao franziu a testa, confusa.

Lu Linyuan pressionou as pontas dos dedos contra a testa dela e massageou-a suavemente.

"Você acha que eu não sei quantas vezes a família Zhu te pregou peças secretamente? Qualquer um que se atreva a intimidar minha mulher, não importa quem seja, deve morrer. A única razão pela qual estou poupando a vida dela hoje é porque não quero que você carregue nenhum fardo psicológico."

“Eu sei que nós dois nos importamos um com o outro e não queremos que nenhum de nós se encontre em situações de perigo. É por isso que você me aconselhou a poupar a vida dela.”

— Sustentá-la custará só mais uma tigela de arroz, e isso lhe dará tranquilidade. Além do mais, acho que obrigá-la a se matar seria uma punição leve demais.

Seu olhar escureceu, e ele estreitou os olhos, olhando na direção externa ao palácio:

"Nem a família Zhu nem a família Guo são fáceis de lidar; não vou deixar nenhuma delas escapar."

"Naquele momento, farei com que ela veja seu próprio povo morrer um por um diante de seus olhos."

"O que poderia ser mais desesperador do que ver todas as pessoas que você ama morrerem bem diante dos seus olhos?"

Ao proferir essas últimas palavras, um sorriso sinistro, talvez até despercebido por ele mesmo, surgiu no canto de sua boca.

Se outras pessoas vissem isso, poderiam sentir medo ou achar estranho.

Ning Xiaoxiao, no entanto, sentiu uma onda de prazer secreto ao ouvir isso.

Para pessoas más, deixar que morram tão facilmente é, de certa forma, uma falta de respeito para com as almas que pereceram pelas suas mãos.

Além disso, o personagem de Lu Linyuan era originalmente concebido como um imperador tirânico e implacável.

Foi depois de conhecê-la que ele começou a ficar bobo e adorável.

No entanto, seja um cão-lobo grande, implacável e decidido, ou um cachorrinho carinhoso e afetuoso, Ning Xiaoxiao gosta de ambos.

Talvez receoso de que suas palavras fossem muito astutas e pudessem assustar sua esposa, Lu Linyuan parou por aí e não continuou.

Ele baixou a cabeça e esfregou a bochecha na de Ning Xiaoxiao, quase fazendo manha. — Depois da cerimônia de nomeação, mandarei apagar dos registros da corte e do harém qualquer menção a Zhu.

— De agora em diante, você será minha única esposa legítima.

— Não uma segunda imperatriz, nem uma esposa que substitui outra, mas a única mulher com quem escolhi me casar nesta vida. E aceitarei de bom grado até suas “broncas e surras”.

Seus lábios quentes e úmidos se moveram lentamente em direção à orelha de sua jovem esposa, e ele sussurrou:

"Ter Xiaoxiao é uma bênção extremamente afortunada que me foi concedida pelos Céus."

Quando ele começava com aquelas declarações melosas, Ning Xiaoxiao se arrepiava antes mesmo de se emocionar.

Lu Linyuan conseguia sentir claramente as emoções dela, e sua insistência em dizer aquelas palavras era, de fato, intencional.

Ele adorava ver a esposa corar e ficar envergonhada e sem jeito.

Assim como uma cereja, dá vontade de engolir inteira.

Naquele instante, ele tomou nos braços Ning Xiaoxiao, que fingia resistir, ansioso para levá-la aos aposentos e recompensar a si mesmo.

*

Depois de uma noite exaustiva, o tirano foi à audiência da manhã já esperando os comentários impertinentes de seus ministros.

Certamente viriam alegar que Ning Xiaoxiao não tinha virtudes suficientes para ocupar o posto e que não poderia ser nomeada imperatriz.

Antes que pudessem terminar de falar, Lu Linyuan os interrompeu com uma expressão sombria:

"Isso é assunto de família. Com quem eu me caso não é da sua conta."

"Mas Vossa Majestade..."

— Se alguém ousar questionar minha decisão mais uma vez, eu o decapitarei diante de toda a corte, como presente para a nova imperatriz.

Diante de sua postura firme, quem ousaria oferecer-lhe outro conselho?

Com isso, a questão de sua coroação como imperatriz foi resolvida, e ninguém mais ousou discuti-la.

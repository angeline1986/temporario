Capítulo 213 — Uma índole perversa

Depois de dois dias de serviço de Ying Shuang no Palácio Xianshou, um criado veio informar ao imperador que ele era fraco e havia adoecido.

Em circunstâncias normais, ninguém incomodaria o imperador por causa da doença de um simples servo. Portanto, a imperatriz-viúva queria pôr Lu Linyuan à prova.

Se ele não interferisse, ela deixaria Ying Shuang no abrigo de palha, entregue à própria sorte.

Se interferisse, provaria que Ying Shuang era um espião colocado ao lado dela para vigiá-la; nesse caso, precisaria redobrar a cautela.

Naquele momento, a imperatriz-viúva comia uma refeição vegetariana e fazia suas devoções no quarto. Qingzhu entrou às pressas, com uma expressão preocupada.

A imperatriz-viúva terminou de oferecer três varetas de incenso ao altar e só então lhe lançou um olhar. — O quê? O imperador mandou um médico imperial examiná-lo?

Qingzhu assentiu, tremendo: — Quem veio foi... o vice-diretor Song, da Academia Médica Imperial...

A imperatriz-viúva ficou profundamente chocada, e suas pupilas se contraíram.

Quando um servo do palácio adoecia, podia ser atendido por médicos subalternos ou aprendizes. Aqueles que mereciam um médico imperial geralmente eram confidentes de algum senhor.

Mas quem era o vice-diretor Song? Um dos principais responsáveis pela Academia Médica Imperial, que, em princípio, deveria atender apenas ao imperador, à imperatriz e à imperatriz-viúva.

Lu Linyuan o enviara sob o pretexto de impedir que Ying Shuang transmitisse a doença à imperatriz-viúva: curá-lo depressa também protegeria a saúde dela. Mas quais eram suas verdadeiras intenções? A imperatriz-viúva entendia cada vez menos.

Depois de curado, porém, ninguém ousou fazê-lo voltar ao abrigo de palha. Deram-lhe um quartinho simples para dormir.

Isso não significava que os maus-tratos tivessem diminuído.

No dia seguinte, assim que Ying Shuang recuperou um pouco das forças, Qingzhu já o pressionava a voltar ao serviço.

Durante a soneca da tarde, a imperatriz-viúva sonhou que seu filho havia voltado para procurá-la. Estava coberto de sujeira, com água imunda escorrendo dos cabelos desgrenhados.

Chorava lágrimas de sangue, dizia estar com frio e pedia que a mãe o abraçasse.

Mas, assim que ela correu para junto dele, a figura se desfez em fumaça, e suas mãos não encontraram nada.

A imperatriz-viúva acordou chorando inconsolavelmente. Qingzhu a servia havia muitos anos e sabia que ela voltara a sonhar com o filho.

Aquela criança era um assunto proibido no palácio. Depois da ascensão de Lu Linyuan ao trono, a imperatriz-viúva praticamente exterminara todos os que sabiam do caso. Somente Qingzhu, sua confidente, fora poupada.

Qingzhu lhe ofereceu um chá calmante e, enquanto enxugava suas lágrimas, aconselhou: — Imperatriz-viúva, o médico disse que seus olhos não estão bem. Precisa cuidar da saúde.

A imperatriz-viúva olhou para ela através das lágrimas, suspirou profundamente e disse:

— Qingzhu, você acha que eu errei?

— Será que cometi tantos pecados que acabei condenando meu pobre filho?

— Ele era apenas um recém-nascido! Por que o Céu foi tão cruel a ponto de deixá-lo ver o mundo uma única vez antes de lhe tirar a vida?

Aquelas palavras assustaram Qingzhu. Ela ficou visivelmente aflita, olhou em todas as direções e se apressou a falar num sussurro:

— Imperatriz-viúva! A senhora está confusa... O imperador está vivo, saudável e lhe demonstra devoção filial. Tudo isso é uma bênção que a senhora recebeu.

Aproximou o chá de seus lábios, lançou-lhe um olhar significativo e levou o indicador à boca, pedindo silêncio. Sua voz baixou ainda mais:

— Imperatriz-viúva, cuidado. As paredes têm ouvidos.

A imperatriz-viúva apertou o peito dolorido e ergueu a cabeça, contendo as lágrimas.

Era verdade. Por que sofria tanto?

Seu filho era o Filho do Céu, e ela era reverenciada como imperatriz-viúva, a mulher mais nobre do mundo. Sua família também havia alcançado glória sem igual. Os planos que fizera ao aprisionar Qin e o filho dela tinham dado todos os frutos que desejara.

Por que haveria de chorar?

Devia era sorrir.

Crac!

O barulho de louça quebrada veio do salão principal, seguido de uma discussão do lado de fora:

— Que tipo de serviço é esse? Este é um prato de jade! Quantas vidas você acha que tem para se atrever a quebrá-lo?

— Perdoe-me, senhor eunuco! Eu... não fiz de propósito. Quanto custa? Posso pagar ao Departamento de Assuntos Internos com meu salário...

— Você vai pagar? Com o quê? Quantos taéis ganha por mês? Não sabe que é um miserável?

— Ah! Senhor, piedade! Não me bata! Ah...

Um eunuco discutia com Ying Shuang. Pelo que se ouvia, Ying Shuang havia quebrado um prato por desajeitamento e agora era insultado e espancado.

Com a aprovação da imperatriz-viúva e por ordem de Qingzhu, qualquer pessoa do Palácio Xianshou podia bater e maltratar Ying Shuang quando quisesse, desde que o deixasse respirando.

Os gritos dele irritavam cada vez mais a imperatriz-viúva. Ela ordenou friamente a Qingzhu:

— Por que esse cachorro está latindo? Vá tapar a boca dele! Se Jinbao quiser bater nele, que o arraste para mais longe. Esse barulho me dá nos nervos!

Qingzhu obedeceu e saiu para cumprir a ordem. Depois que ela se afastou, a imperatriz-viúva fez outra oração budista por seu filho, que acreditava ter morrido tão cedo e de quem sentia saudade dia e noite.

Naquele mesmo instante, Lu Linyuan também oferecia uma vareta de incenso diante de um altar no Salão Baohua.

Naquele dia completavam-se dez anos da morte do médico imperial Zhao.

Lu Linyuan era grato porque, antes de morrer, Zhao escolhera contar-lhe aquele segredo. Pelo menos, ele não passaria a vida inteira tratando uma inimiga como se fosse sua mãe.

Mas, além de revelar o segredo, Zhao também lhe fizera um último pedido.

Em seu leito de morte, explicara a Lu Linyuan quem era Ying Shuang. Insistira que o rapaz não tinha culpa de nada: era apenas uma criança que desconhecia toda a história, fora criada ao seu lado e sempre o considerara seu pai biológico.

Zhao queria que Lu Linyuan não descontasse sua raiva nele, mas o enviasse para longe das intrigas da capital, onde pudesse ter uma vida simples e tranquila.

Lu Linyuan tinha apenas catorze anos naquela época. Apesar do ódio profundo, aceitara dar a Ying Shuang uma oportunidade de continuar vivo.

A corte concedera cem taéis de prata para o funeral do médico Zhao, e a imperatriz-viúva acrescentara mais cem.

Mas Ying Shuang pegara o dinheiro e se entregara aos prazeres, deixando o corpo de Zhao abandonado na velha casa, sem sequer providenciar o enterro.

Não queria gastar um único centavo com o velho. Os vizinhos só descobriram que Zhao estava apodrecendo na casa quando sentiram o mau cheiro.

Ao saber disso, Lu Linyuan investigou o caso discretamente e descobriu que alguém havia adulterado os remédios usados por Zhao durante sua doença.

Depois de entrevistar os vizinhos, os guardas secretos souberam que Ying Shuang era um sujeito perverso. Quando pequeno, fora mimado por Zhao como a coisa mais preciosa do mundo. Mas, ao crescer, chegara a espancá-lo por receber apenas uma pequena quantia de prata a menos. Mais de uma vez o insultara em público, mandando que o velho imprestável morresse logo.

Foi Ying Shuang quem misturou veneno aos remédios de Zhao, agravando e acelerando sua doença. Queria que, com a morte dele, ninguém mais o controlasse e pudesse embolsar toda a herança, além do dinheiro concedido pela corte para o funeral.

E, enquanto fazia tudo isso, acreditava sinceramente que Zhao era seu pai de sangue.

Depois de receber o dinheiro, foi para o condado de Zhou, a trezentos li da capital. Lá reuniu uma gangue de delinquentes que roubava, destruía, incendiava, estuprava e sequestrava sem nenhum escrúpulo.

Herdara perfeitamente toda a maldade da imperatriz-viúva. Mesmo tão jovem, tornara-se uma pessoa de índole completamente perversa.

Lu Linyuan lhe dera uma oportunidade. Fora o próprio Ying Shuang que decidira desprezar a própria vida.

Não podia culpar mais ninguém.

Capítulo 214 — A Consorte Nobre recupera o posto

Palácio Fengyi.

Naquele dia, Ning Xiaoxiao levantou-se bem cedo e começou a se arrumar logo pela manhã.

Quando terminou e estava prestes a chamar Gu Sijin para cumprimentarem a imperatriz, viu a amiga sentada junto ao assento aquecido com uma carta nas mãos e uma expressão abatida.

Aproximou-se, preocupada: — O que aconteceu, irmã? Quem a deixou assim logo cedo?

Gu Sijin lhe entregou a carta, indignada. — Veja você mesma.

Era uma carta enviada por sua família, escrita por sua mãe.

Nela, a mãe contava que:

Gu Yanchuan investigara um caso de comércio ilegal de sal durante quase um ano. Dois dias antes, finalmente seguira as pistas e capturara todos os responsáveis pelo esquema, prestando um grande serviço. No entanto, Tong Guowei simplesmente tomara para si todo o mérito diante do imperador, deixando Gu Yanchuan tão furioso que caíra gravemente enfermo.

Depois de ler, Ning Xiaoxiao ficou em silêncio por um instante. Gu Sijin suspirou, impotente: — Você viu. Não é que eu esteja com raiva do imperador. Só acho uma injustiça com meu pai.

— Ele passou mais de um ano às voltas com os comerciantes de sal. Você nem imagina quanto esforço fez para levar aqueles criminosos à Justiça. Trabalhou tanto que acabou desenvolvendo uma doença pulmonar debilitante. Sua saúde foi arruinada.

— E Tong Guowei, que não fez nada além de comandar soldados para prender uma pessoa, ficou com todos os louros?

Quanto mais falava, mais se exaltava. Mesmo com seu temperamento de coelhinha mansa, não conseguiu evitar elevar a voz:

— O imperador sabe perfeitamente que o mérito é de meu pai, mas recompensou apenas Tong Guowei! Nem me importo tanto com ouro e prata. O pior é que ainda promoveu um primo de Tong em Guanzhou! Quem na corte não sabe que Tong Ada é um completo inútil? Agindo assim, o imperador desanima os ministros leais que dedicam a vida ao reino!

Por mais inteligente que fosse, Gu Sijin também podia perder a perspectiva quando o assunto envolvia sua própria família.

Depois de ouvir aquele desabafo inflamado, Ning Xiaoxiao segurou a mão da amiga e a consolou com delicadeza:

— Não fique zangada, irmã. Lembre-se de uma coisa: quando algo parece estranho demais, há alguma coisa por trás. Todo mundo acha que o imperador errou. Mas ele não é burro. Você já pensou por que insistiria em fazer isso?

Gu Sijin ficou perplexa por um instante. Então levantou lentamente a cabeça. — Você quer dizer... que ele fez de propósito?

Ning Xiaoxiao sorriu e balançou a cabeça. — Se foi de propósito ou não, eu não saberia dizer. Só conheço um princípio: quando o Céu quer destruir alguém, primeiro o deixa enlouquecer de arrogância.

Dobrou a carta e a devolveu a Gu Sijin, que parecia pensativa. — Vamos, irmã. Ainda precisamos cumprimentar a imperatriz. Depois de amanhã vou à propriedade das fontes termais. Se chegarmos atrasadas hoje de novo, teremos de aguentar mais um sermão da Consorte Tong.

*

Naquela manhã, não havia nenhum assunto importante a tratar durante os cumprimentos à imperatriz.

As mulheres do harém só trocavam amenidades sem sinceridade ou, lideradas pela Consorte Li, bajulavam a Consorte Tong, elogiando a influência de sua família na corte.

Estavam no meio da conversa quando Sanfu chegou com um decreto de Lu Linyuan.

O texto do decreto era extremamente simples: uma única linha.

“Restituo à Consorte Tong o título de Consorte Nobre e lhe concedo autoridade para auxiliar na administração dos seis palácios.”

Seguindo a regra de que quanto menos palavras, maior a repercussão, aquele decreto foi como outra bomba lançada no harém.

Com a restauração do título de Consorte Nobre, todas se levantaram, fizeram reverências e a parabenizaram. Ela ergueu o rosto com orgulho, os olhos altivos, e sorriu para a imperatriz:

— A imperatriz disse certa vez que, depois de perder meu posto, só provaria minha capacidade se conseguisse recuperá-lo. Pois bem, Vossa Majestade: o que acha agora da minha capacidade?

A imperatriz abriu um sorriso forçado. — Recuperar seu posto é uma boa notícia. Meus parabéns.

A Consorte Nobre lhe lançou um olhar desdenhoso e se voltou para a multidão de concubinas que permaneciam em reverência. Seu sorriso tornou-se ainda mais insolente.

— Podem levantar-se. Acabaram de ouvir que o imperador me concedeu autoridade para auxiliar na administração dos seis palácios. Ele deseja que eu alivie um pouco o fardo da imperatriz.

— De agora em diante, qualquer assunto de vocês deve ser primeiro comunicado a mim. Eu decidirei se é necessário levá-lo à imperatriz. Não vão perturbá-la durante suas práticas de recolhimento por qualquer bobagem, entenderam?

As mulheres responderam em uníssono: — Entendemos.

Desde que ouvira o decreto, a imperatriz não conseguira recuperar a boa cor do rosto.

Ela encerrou a audiência. Quando todas saíram, finalmente explodiu, arremessando a xícara de chá no chão:

— Quem essa Tong pensa que é?! Só porque a família dela tem prestígio, acha que pode se colocar no mesmo nível que eu há tantos anos? Quem lhe deu esse direito?!

Xiangling apressou-se a protegê-la. — Majestade, contenha sua ira! Cuidado para não se cortar nos cacos...

— Conter a ira? Se eu continuar me contendo, logo nem terei mais o direito de ficar furiosa! O imperador lhe deu poderes para auxiliar na administração dos seis palácios, e ela já tem a ousadia de exigir que todas as consortes a consultem antes de qualquer coisa! Com essa usurpação descarada, por acaso pensa que a imperatriz já morreu?!

Enfurecida, bateu na mesa com tanta força que a palma ficou vermelha e dormente. — Outro dia Tong Guowei recebeu uma recompensa, e hoje a filha dele voltou a ser Consorte Nobre. Se amanhã Tong Guowei conquistar mais algum mérito, é capaz de o imperador mandar que eu abdique para dar lugar a ela!

A imperatriz valorizava enormemente sua posição como chefe do harém. Comparado ao desconforto de ver Lu Linyuan favorecer exclusivamente Ning Xiaoxiao, o que a Consorte Nobre representava era uma ameaça real.

As sucessivas demonstrações de boa vontade de Lu Linyuan para com Tong Guowei já pareciam deixar clara sua posição.

— Para mim, o imperador está é com medo de Tong Guowei, por isso corre atrás dele para agradá-lo! Senão, como permitiria que Tong tomasse para si o mérito que pertencia evidentemente a um censor do Tribunal de Inspeção?

— Não! Preciso encontrar uma maneira de fazê-lo cair! Enquanto ele continuar influente na corte, a Consorte Nobre vai querer pisar na minha cabeça todos os dias!

— O que ela pensa que é a minha cabeça? As pradarias intermináveis de Hulunbuir?!

Xiangling, constrangida, tinha uma expressão que dizia: “Não faço ideia do que responder a isso”.

Mais tarde, a imperatriz saiu furiosa em direção ao Palácio Xianshou para discutir uma estratégia com a imperatriz-viúva. Xiaoyinzi, escondido nas sombras, observou tudo com atenção.

Ele informou Lu Linyuan, que esboçou um sorriso frio. Tudo acontecia conforme seus cálculos.

Recompensar generosamente Tong Guowei e restaurar o posto da Consorte Nobre era uma forma de agitar o mato para assustar aquela cascavel que era a imperatriz.

Temendo perder o trono de imperatriz, ela certamente reagiria. Sua família e a da imperatriz-viúva eram cúmplices havia muitos anos e tinham formado uma facção poderosa. Se se unissem contra Tong Guowei, seria como colocar dois tigres para lutar.

Ambas as forças eram ameaças sérias para Lu Linyuan. Se entrasse diretamente em conflito com uma, despertaria a vigilância da outra.

Seria muito melhor provocar o confronto em segredo, assistir à luta de longe e, quando os dois lados estivessem se destruindo, aparecer para colher os benefícios. Não seria perfeito?

Mas esse plano engenhoso de matar dois coelhos com uma cajadada só também tinha seu inconveniente.

Por exemplo, restaurar o posto da Consorte Nobre poderia despertar o ciúme de sua queridinha.

Lu Linyuan largou o pincel imperial. Imaginou a cena de uma gatinha se enfiando debaixo da cama e deixou escapar um sorriso sedutor e encantador.

— Vá buscar minha pequena ancestral e traga-a aqui.

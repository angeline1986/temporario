# Validação — capítulo 213

- Fonte: `novel_capitulos_212_a_270(20261105-204934).docx`, chinês tradicional.
- Limite do DOCX: índices base zero 78–143, excluídos os parágrafos vazios.
- Unidades não vazias traduzidas: **63** (inclui título e marcadores de cena).
- Índices reais: primeiro 78; último 142.
- Duplicatas: **0**. Campos vazios: **0**. Ausências dentro das unidades não vazias do capítulo: **0**.
- Correspondência estrutural: uma linha de CSV por parágrafo não vazio; a ordem do Markdown acompanha a ordem do DOCX.

## Decisões editoriais

A filiação de Ying Shuang e a revelação feita pelo médico Zhao seguem o que o capítulo efetivamente narra; a crença da imperatriz-viúva sobre a morte do filho não foi transformada em fato. Li é unidade chinesa de distância, preservada.

## Alcance da verificação

Conferência estrutural automatizada de linhas, índices e arquivos. Tradução produzida com leitura do original e revisão editorial durante a composição; não foi realizada auditoria semântica integral por segunda pessoa independente. A correspondência 1:1 não constitui prova de equivalência semântica perfeita.

# Validação — capítulo 214

- Fonte: `novel_capitulos_212_a_270(20261105-204934).docx`, chinês tradicional.
- Limite do DOCX: índices base zero 144–202, excluídos os parágrafos vazios.
- Unidades não vazias traduzidas: **56** (inclui título e marcadores de cena).
- Índices reais: primeiro 144; último 201.
- Duplicatas: **0**. Campos vazios: **0**. Ausências dentro das unidades não vazias do capítulo: **0**.
- Correspondência estrutural: uma linha de CSV por parágrafo não vazio; a ordem do Markdown acompanha a ordem do DOCX.

## Decisões editoriais

Gu Yanchuan e Tong Ada mantidos conforme o original deste capítulo. Consorte Tong passa a Consorte Nobre Tong a partir do decreto. “Hulunbuir” preservado como referência geográfica da piada; “cascavel” reproduz a metáfora animal. As suspeitas de Gu Sijin são separadas das intenções reveladas ao fim do capítulo.

## Alcance da verificação

Conferência estrutural automatizada de linhas, índices e arquivos. Tradução produzida com leitura do original e revisão editorial durante a composição; não foi realizada auditoria semântica integral por segunda pessoa independente. A correspondência 1:1 não constitui prova de equivalência semântica perfeita.

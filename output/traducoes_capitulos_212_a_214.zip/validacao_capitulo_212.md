# Validação — capítulo 212

- Fonte: `novel_capitulos_212_a_270(20261105-204934).docx`, chinês tradicional.
- Limite do DOCX: índices base zero 3–77, excluídos os parágrafos vazios.
- Unidades não vazias traduzidas: **72** (inclui título e marcadores de cena).
- Índices reais: primeiro 3; último 76.
- Duplicatas: **0**. Campos vazios: **0**. Ausências dentro das unidades não vazias do capítulo: **0**.
- Correspondência estrutural: uma linha de CSV por parágrafo não vazio; a ordem do Markdown acompanha a ordem do DOCX.

## Decisões editoriais

Título 孝出強大 é um trocadilho com 笑出強大; tradução prioriza a ironia sobre a devoção filial. 應雙 é nome de sonoridade alusiva a 報應不爽; preservado em pinyin com explicação no corpo. “Uma Ameixeira” remete à trilha 一剪梅. A suposta morte do filho é a crença da imperatriz-viúva, não um fato narrativo confirmado.

## Alcance da verificação

Conferência estrutural automatizada de linhas, índices e arquivos. Tradução produzida com leitura do original e revisão editorial durante a composição; não foi realizada auditoria semântica integral por segunda pessoa independente. A correspondência 1:1 não constitui prova de equivalência semântica perfeita.

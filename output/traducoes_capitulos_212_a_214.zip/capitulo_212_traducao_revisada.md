Capítulo 212 — Uma demonstração e tanto de devoção filial

Naquela noite, Lu Linyuan teve um sono leve.

Ficou esperando o tempo todo que Ning Xiaoxiao o soltasse.

Só perto da quarta vigília conseguiu aproveitar o instante em que ela se virou na cama e afrouxou os braços.

Imediatamente se desvencilhou, vestiu o manto imperial e saiu do quarto na ponta dos pés.

Desde pequena, Ning Xiaoxiao tinha o hábito de dormir abraçada a alguma coisa. Quando soltava o objeto por um instante para mudar de posição, logo voltava a agarrá-lo.

Mas, ao estender o braço para abraçar Lu Linyuan de novo, encontrou o lado da cama vazio.

Abriu os olhos de repente. Vendo a porta entreaberta, imaginou que ele tivesse ido se aliviar.

E a cabecinha cheia de ideias maldosas voltou a trabalhar: decidiu esperar que ele retornasse para lhe pregar um susto.

Foi até o assento aquecido, abriu uma fresta na janela de treliça e espiou o pátio.

Uma camada espessa de neve cobria o chão. Uma figura amarelo-viva remexia alguma coisa entre os montes brancos.

【O que ele está procurando no pátio no meio da madrugada, em vez de dormir?】

Ainda intrigada, viu Lu Linyuan desenterrar o boneco de neve que havia arrancado de suas mãos e atirado pela janela pouco antes.

A neve recém-caída era fofa, mas o boneco tinha sido compactado até virar gelo; por isso, mesmo enterrado por algum tempo, continuava inteiro.

Era apenas um bonequinho horroroso que Ning Xiaoxiao fizera sem capricho. Nem ela queria olhar para aquilo uma segunda vez.

Mas, para Lu Linyuan, era o primeiro boneco de neve que sua amada lhe dera!

Ele queria guardar todas as primeiras vezes dela!

Segurando o boneco com todo o cuidado, Lu Linyuan foi até a varanda e deu um chute em Sanfu, que deveria estar de vigília, mas dormia profundamente.

Sanfu disparou: — Que filho da p...

Ao ver que era Lu Linyuan, mudou o discurso num piscar de olhos: — B-b-b-banana é um alimento de natureza fria, Majestade! Não convém comer demais no inverno...

— Que bobagem você está resmungando?

Se não estivesse segurando o boneco feito pela mulher, Sanfu provavelmente teria levado mais um tabefe na nuca.

Entregou-lhe o boneco: — Leve-o ao depósito de gelo e conserve-o muito bem. Se derreter, eu o recompensarei com cinquenta golpes de bastão.

Sanfu recebeu o boneco e ficou com cara de quem não entendia mais nada.

Desde quando seu senhor gostava dessas brincadeiras de criança?

Não tinha coragem de perguntar nem de comentar. Só lhe restou atravessar a neve no meio da madrugada, feito um pobre coitado, segurando o boneco como se fosse uma pepita de ouro, com uma trilha sonora melodramática de “Uma Ameixeira” tocando na própria cabeça.

Ning Xiaoxiao assistiu à cena com um sorriso radiante. Quando Lu Linyuan estava prestes a voltar, fechou a janela e se deitou de novo, fingindo que nada acontecera.

E, assim que ele se acomodou ao seu lado, abraçou-o com um pouco mais de força.

*

Naquele dia, a imperatriz-viúva voltaria do Palácio Shoukang ao Palácio Xianshou. Logo cedo, a imperatriz levou as mulheres do harém para recebê-la e fazer suas bajulações.

Todas acompanharam a imperatriz-viúva até o Xianshou. Ao perceber a decoração renovada, ainda mais luxuosa, as consortes não pouparam elogios, deixando-a radiante.

Conversaram e riram até a hora do almoço, quando enfim se dispersaram.

Enquanto preparava a refeição, Qingzhu comentou sorridente: — Afinal, Sua Majestade continua sendo um filho dedicado à senhora.

A imperatriz-viúva soltou um resmungo, com um sorriso que não chegava aos olhos: — Agora que tem mulher, esqueceu a mãe. Você acha que não sei o que ele pensa? Mandou-me ao Shoukang só para defender aquela Ning. Pois bem, vou mostrar àquela mulher do que sou capaz.

— Sua Majestade, o imperador, chegou!

Assim que o eunuco anunciou sua presença do lado de fora, a expressão sombria da imperatriz-viúva se iluminou como um sol de primavera, num sorriso maternal.

Lu Linyuan cumprimentou-a sem grande entusiasmo e perguntou sorrindo: — Mãe imperial, o que achou da reforma do Palácio Xianshou?

— Excelente. Vejo que o imperador se empenhou muito. Na verdade, já estou velha e tanto faz onde moro. Não precisava gastar tanto.

— A senhora se engana, mãe imperial. É minha mãe e cuidou de mim com tanta dedicação desde a infância. Agora que está envelhecendo, é natural que eu lhe ofereça tudo de melhor, para que desfrute tranquilamente da velhice.

Ela assentiu, satisfeita. — Já estou velha. Não desejo mais riquezas nem honrarias. Ficaria contente se o imperador me desse logo um netinho rechonchudo, para que eu aproveitasse a alegria de ter uma família.

O sorriso de Lu Linyuan se alargou: — Isso não é urgente. Eu e a Concubina Hua nos damos muito bem. Creio que em breve a senhora receberá boas notícias.

A ponta da sobrancelha da imperatriz-viúva estremeceu quase imperceptivelmente. — Que bom — respondeu, contrariando o que sentia.

— Como a senhora está retornando hoje ao Xianshou, Sanfu me contou que Xiaoshunzi, um criado daqui, foi descuidado e lascou uma ponta de sua penteadeira. Era aquela penteadeira com fênix que o imperador anterior lhe deu, e a senhora sempre a estimou muito. Por sua negligência, mandei Xiaoshunzi para os serviços penais.

Enquanto falava, Lu Linyuan bateu palmas três vezes. Xiaoyinzi entrou conduzindo o Escravo Porco.

Ele estava limpo e vestido com roupas novas de eunuco; assim, até parecia um ser humano.

Lu Linyuan apresentou: — Este é Ying Shuang, que servia na minha presença. Achei-o esperto e eficiente, por isso resolvi oferecê-lo à senhora.

Ying Shuang era o nome que Lu Linyuan acabara de dar ao Escravo Porco.

Um nome inspirado na expressão “a retribuição dos atos nunca falha”.

Ying Shuang saudou respeitosamente a imperatriz-viúva. Ela lhe lançou um olhar e disse: — Alguém escolhido pelo imperador certamente deve ser competente. Parece inteligente.

Lu Linyuan sorriu de leve. — Que bom que gostou, mãe imperial. Tenho assuntos de Estado a resolver, então não vou atrapalhar seu almoço.

Depois que ele saiu, os eunucos do Palácio Xianshou levaram Ying Shuang para lhe ensinar as regras do serviço.

O rosto da imperatriz-viúva ficou completamente sombrio. Ela empurrou para o chão a comida que Qingzhu colocara em seu prato. — O imperador está se tornando ousado! Agora precisa pôr gente sua até ao meu lado para se sentir seguro?

— E como a senhora pretende lidar com ele? — perguntou Qingzhu.

— Não posso matar levianamente um homem do imperador. Deem a ele todos os serviços mais pesados e imundos do palácio. Não permitam que me sirva de perto. Quero ver que informações ele conseguirá levar ao imperador desse jeito.

Dizendo isso, a imperatriz-viúva girou as contas do rosário budista e fechou os olhos, recitando o nome de Buda.

Estava tão irritada que perdeu o apetite. Mandou Qingzhu cuidar dos arranjos de Ying Shuang e voltou sozinha aos aposentos.

O altar budista do quarto mantinha incenso aceso o tempo todo. Depois de tantos anos, parecia que a própria imperatriz-viúva estava impregnada daquele cheiro de sândalo.

Ajoelhou-se diante das tábuas devocionais e orou com devoção, recitando o Mantra do Renascimento. Uma lágrima deslizou pelo canto de seus olhos.

Ao longo dos anos, já havia recitado e copiado aquele mantra dezenas de milhares de vezes.

Não passava um único instante sem sentir falta do filho que, segundo ela acreditava, morrera assim que nasceu. Tudo o que Lu Linyuan possuía deveria ter pertencido àquele menino.

Se seu pobre filho ocupasse o trono agora, certamente a trataria cem, mil vezes melhor do que Lu Linyuan.

Enquanto isso, no pátio, Qingzhu levou Ying Shuang até as latrinas e começou a dar ordens com arrogância:

— Está vendo esses baldes de excrementos? Vai esfregá-los três vezes por dia. Faça isso direito nos próximos dois dias, e depois lhe darei outras tarefas.

— Lembre-se: o Palácio Xianshou é o lugar mais rigoroso com as regras. Se cometer algum erro, mesmo tendo vindo por ordem do imperador, não escapará de uma surra. Entendeu?

Com o ar mais servil possível, Ying Shuang se curvou repetidamente. — Sim, sim, entendi.

Então baixou a voz e perguntou, cauteloso: — Posso perguntar à senhora Qingzhu onde fica meu alojamento?

— Seu alojamento? — Qingzhu respondeu friamente. — Você apareceu do nada. Acha que é fácil arranjar um quarto? — Olhou em volta e apontou para uma cobertura de palha no canto sudeste. — Aquilo serve para guardar flores na primavera e no verão. Está vazio agora. Fique lá por uns dois dias.

Ying Shuang olhou para o abrigo, aberto ao vento por todos os lados. Era inverno, e a neve aumentava a cada dia. Dormir ali não significava morrer congelado?

— Senhora... Com esse frio e essa neve, dormir ali vai ser gelado de... Ah!

Antes que terminasse, Qingzhu lhe acertou as costas com um chicote.

— Você é um servo, não um senhor! Acha que veio ao Palácio Xianshou para viver no luxo?

— Se não quiser dormir no abrigo, durma na latrina! E, se continuar reclamando, hoje fica sem comer!

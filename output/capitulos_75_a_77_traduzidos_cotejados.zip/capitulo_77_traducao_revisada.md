# Capítulo 77 — O tirano se antecipa: Ning Xiaoxiao fracassa numa missão pela primeira vez

Como imperador, Lu Linyuan parecia possuir o mundo inteiro.

Mas sempre soubera que, quando fechava as portas e ficava sozinho no silêncio, tudo aquilo não passava de areia escapando entre os dedos.

Em seus vinte e quatro anos de vida, parecia nunca ter pertencido a si mesmo.

Na infância, pertencia às expectativas da imperatriz-viúva; na juventude, às esperanças do antigo imperador; agora, era o esteio de todo o povo.

Jamais experimentara, nem por um instante, a verdadeira felicidade.

Hoje, porém, seu sorriso vinha do fundo do coração, livre de qualquer disfarce.

Por fim, formulou silenciosamente um desejo:

Que, de agora em diante, pudesse reencontrar aquele eu que nunca tivera a chance de ser.

Enquanto ele travava essa batalha íntima consigo mesmo, Ning Xiaoxiao começava uma disputa silenciosa com Xiao Qi.

【Anfitriã~ Você reparou que faz tempo que não recebe uma missão?】

Ning Xiaoxiao explodiu: 【Seu maldito Seis, ainda tem coragem de aparecer? Queria me matar de propósito? Pedi para escrever «Yuanyuan»! Que porcaria foi aquela?】

Xiao Qi fingiu estar magoado: 【Mas era «Yuan»... Da outra vez, você escreveu «Lu Linyuan, o pobre coitado» naquele burrinho de pelúcia. Achei que «Yuanyuan», com o caractere de «injustiçado», fosse um apelido carinhoso! Você não explicou direito e ainda me culpa...】

Ning Xiaoxiao revirou os olhos: 【Você devia abrir um porão e criar cogumelos. Porque juízo, pelo visto, não tem nem para conservar!】 — A ofensa original fazia um trocadilho entre «cultivo em adega» e «falta de educação».

Xiao Qi: 【Hehe~ Melhor receber sua missão primeiro~】

【Bip, bip! Nova missão disponível!】

【«Enfiar a cabeça do tirano no bolo». Recompensa: 2% no índice de desvio da trama. Fracasso: menos 10% de vitalidade da anfitriã~】

Ning Xiaoxiao já tinha desistido até de se indignar.

Sabia que, toda vez que aquele sistema maldito aparecia, não vinha coisa boa.

【O homem está comemorando o aniversário e eu vou esfregar bolo na cara dele? Isso é coisa que gente faz?】

【Não posso fazer nada, anfitriã~ Foi a missão que me passaram. Use sua inteligência e termine logo, tá? Coraçãozinho para você~】

Xiao Qi desconectou-se imediatamente, com medo de que ela começasse a xingar toda a sua família.

Ning Xiaoxiao observou Lu Linyuan, que ainda fazia seu pedido, e hesitou:

【Se eu simplesmente afundar a cara dele no bolo, como ele vai continuar feliz no próprio aniversário?】

【Ah, pelo menos ele já teve um momento de felicidade! Quando terminar o pedido e apagar as velas, vou tirá-las do bolo. Assim que ele se preparar para comer, enfio a cabeça dele lá dentro!】

【Foi mal, seu grande coitado!】

Lu Linyuan ainda estava emocionado com aquele «Que você seja feliz, e não apenas no aniversário». Como uma mulher tão maluca conseguira pensar em palavras tão bonitas?

Mas não se passara nem um minuto e ele já ouvira o plano dela.

Então todo aquele bolo de aniversário era só uma desculpa para afundar sua cabeça nele?

Não havia mais ninguém neste mundo de quem ela gostasse? Estava com tanta pressa de morrer?

Lu Linyuan abriu os olhos e apagou todas as velas de uma só vez.

Ning Xiaoxiao aplaudiu entusiasmada: — Uau! Velas apagadas, desejo realizado! Tenho certeza de que o pedido de Vossa Majestade vai se cumprir!

Enquanto retirava as velinhas, calculava mentalmente: 【Preciso escolher a hora certa e acertar de primeira! Depois digo que também é costume da minha terra... Afinal, ele parece esperto e governa bem, mas continua sendo um idiota. É até fácil enganá-lo.】

Toda a tolerância que Lu Linyuan demonstrara fora interpretada por ela como burrice.

Ele a observou trabalhar friamente e soltou uma risada sarcástica. — Quer saber que desejo fiz?

— Não sei~ Mas Vossa Majestade não devia contar. Dizem que o desejo não se realiza se for revelado.

— Não importa. Quero dividi-lo com você. Gostaria de ouvir?

A curiosidade de Ning Xiaoxiao despertou imediatamente, embora ela se fizesse de difícil. — Não é que eu queira muito, mas, se Vossa Majestade estiver desesperado para contar, posso ouvir um pouquinho.

Lu Linyuan fez um sinal com o dedo. — Aproxime-se. Vou lhe contar baixinho.

Ela largou as velas e foi saltitando até ele como um coelhinho. Lu Linyuan inclinou-se ligeiramente e murmurou junto ao ouvido dela: — Meu desejo é esfregar esse bolo na sua cara.

— Hã?

*Pá!*

Antes que Ning Xiaoxiao pudesse se espantar, Lu Linyuan já havia estampado o bolo inteiro no rosto dela.

Ela ficou imóvel por dois segundos. Então, numa lentidão quase cômica, removeu a cobertura e os pedaços de massa do rosto, revelando dois olhos arregalados de horror...

*Esse homem tem algum problema na cabeça?!*

Lu Linyuan arqueou as sobrancelhas, muito satisfeito com aquele visual inusitado. — E então? Surpresa? Não esperava por essa, não é?

Ning Xiaoxiao fechou os punhos de raiva. 【Surpresa uma ova, seu maldito imperador! Você está acabado!】

Fechou os olhos e abriu o documento mental, pronta para apertar Retroceder e esfregar repetidas vezes o bolo no rosto do tirano.

Mas foi então que um alarme estridente começou a soar em sua mente.

【Bip, bip! Atenção! Atenção!】

【A missão da anfitriã foi considerada fracassada. Vitalidade reduzida em 10%!】

Ning Xiaoxiao: 【??? Como assim? Eu não posso retroceder?】

Xiao Qi: 【O sistema avaliou que, mesmo retrocedendo, o tirano acabaria jogando o bolo na sua cara de novo. Então nem adianta perder tempo...】

De fato, só era possível voltar três minutos.

Aquele idiota fizera um pedido de aniversário justamente para esfregar bolo no rosto dela. Como ela não tinha força para enfrentá-lo, retroceder seria inútil.

Mas, como era a primeira vez que fracassava numa missão, não sabia o que aconteceria. Então perguntou a Xiao Qi:

【Perder 10% da vitalidade vai me causar algum problema imediato? Se eu puder viver até os cem anos, não vai ser cruel a ponto de me envelhecer dez anos de uma vez, vai?】

Xiao Qi: 【Nada disso. A anfitriã só vai dormir por um dia inteiro, sem outros efeitos. Só morrerá quando a vitalidade chegar a 0%.】

【E quando vou desmaiar?】

【Hmm... Agora mesmo...】

Mal Xiao Qi terminou de falar, Ning Xiaoxiao perdeu a consciência. As pernas cederam e ela começou a cair.

Lu Linyuan reagiu rapidamente, segurando-a pela cintura antes que atingisse o chão.

Olhando para ela, imóvel em seus braços, zombou: — Vai fingir que se machucou para me extorquir?

Ning Xiaoxiao não respondeu. Ele insistiu: — Está representando uma cena para mim, é isso?

Sabia que ela sentia cócegas. Por isso, passou os dedos várias vezes pela lateral de sua cintura fina. Mesmo assim, ela não reagiu.

Aquilo...

— Ning Xiaoxiao! Acorde! O que aconteceu com você?

Ele a sacudiu e percebeu que seus braços e pernas pendiam frouxos. Sua respiração ficara extremamente fraca e, por mais que a chamasse, ela não despertava. O pânico começou a tomar conta dele.

*Não pode ser, não pode ser...*

*Será que eu a matei com uma bolada de aniversário?*

Ergueu Ning Xiaoxiao nos braços e a depositou em sua própria cama. Naquele momento, nem se importou com a obsessão que tinha por limpeza.

Enquanto usava a manga do manto imperial para limpar os restos de creme e chocolate do rosto dela, gritou para a porta:

— Guardas! Chamem imediatamente os médicos imperiais!

# Capítulo 76 — Que você seja feliz, e não apenas no aniversário

O bolo que Xiao Qi entregara a Ning Xiaoxiao vinha numa embalagem caprichada. Para não despertar suspeitas, todos os materiais eram encontrados na dinastia Qi.

Doze camadas de papel xuan coladas formavam um papelão espesso, dobrado numa caixa quadrada.

O exterior fora pintado de preto e dourado, com contornos brancos.

Ao entregar o bolo, Xiao Qi não conseguiu esconder o orgulho:

【E aí, anfitriã? Não ficou lindo?~~】

Ning Xiaoxiao ficou sem jeito: 【Bonito até que é, mas... por que parece uma urna funerária?】

【Que urna funerária, o quê!? É estilo punk! Você não entende nada de estética!】

Ning Xiaoxiao: 【...】

O bolo estava bem embalado. Como ela já escolhera o modelo, não viu necessidade de conferir o conteúdo.

Recorreu ao seu velho truque.

Pausou o tempo, entrou tranquilamente no Palácio Chaoyang e se escondeu no guarda-roupa do tirano, aguardando em silêncio seu retorno do banquete.

Assim que Lu Linyuan atravessou a porta do quarto, ouviu os pensamentos de Ning Xiaoxiao:

【Já voltou tão depressa?】

【Quando tudo lá fora ficar quieto, vou saltar do armário e assustá-lo. Vai ser uma surpresa~】

Lu Linyuan franziu a testa para o guarda-roupa, sem palavras.

Ela... tinha vindo roubar suas roupas íntimas outra vez?

Com passos tão leves que quase não produziam som, aproximou-se do armário e ficou diante dele, esperando para ver que palhaçada ela faria.

Ning Xiaoxiao: 【Ué? Ficou tudo quieto? Chegou a hora!】

Ela escancarou a porta: — Majestade! Surpre...

A porta só se abriu pela metade: Lu Linyuan a segurava com a mão e a observava com uma expressão de quem acabara de encontrar alguém sem dois neurônios para esfregar.

Ning Xiaoxiao esgueirou-se por baixo do braço dele, apontou para a janela e riu constrangida: — Que tempo bonito hoje, não é...?

A mão grande de Lu Linyuan pousou sobre sua nuca, obrigando-a a virar o rosto e encará-lo. — O que pretende roubar de mim desta vez?

— Nada, nada! Vossa Majestade entendeu mal! Vim trazer um presente de aniversário!

Ela ergueu apressadamente a caixa diante dele. — Feliz aniversário, Majestade~

Lu Linyuan examinou a caixa e sua expressão ficou horrível.

— É meu aniversário e você me dá uma urna funerária? Quer que eu a coloque lá dentro?

— Não é uma urna, Majestade! É só que... parece um pouco... Ah! É um bolo de aniversário que eu fiz para Vossa Majestade!

Ela apertou um botão branco na tampa. As laterais da caixa se abriram, revelando um bolo de chocolate com recheio cremoso e transbordante.

Lu Linyuan jamais vira coisa igual. Curioso, perguntou: — Mas que diabo é isso?

Ao notar a mensagem escrita com creme vermelho de cereja na base do bolo, franziu a testa e leu: — «Yuanyuan, feliz aniversário»? O que significa isso?

Pensando que ele ficara irritado por ela usar um apelido derivado do nome dele, Ning Xiaoxiao explicou depressa: — «Yuanyuan» é a repetição do último caractere do nome de Vossa Majestade. Na minha terra, comemos bolo no aniversário e escrevemos nele o último caractere do nome da pessoa. É uma forma especial de desejar felicidades!

Lu Linyuan conteve a irritação com dificuldade. — Não sabia que meu nome era Lu Linyuan-com-o-caractere-de-«injustiça»!

Ning Xiaoxiao: 【Hã? O que houve? Por que ficou tão bravo? Não faz sentido...】

Até que seus olhos pousaram sobre os caracteres escritos por Xiao Qi.

Filho da mãe!

Aquele maldito sistema escrevera 【冤冤, feliz aniversário】, repetindo o caractere de «injustiça» em vez de 淵, o «Yuan» do nome do imperador!

Aquele canalha fizera de propósito para ferrá-la!

O imprestável Xiao Qi («Sete») devia mudar de nome: sete menos um, «Seis», o famoso trapaceiro!

Ning Xiaoxiao resolveu bancar a sonsa: — Ah? Não é esse o «Yuan» de Vossa Majestade? Não sei ler muito bem, talvez tenha escrito errado.

Três linhas imaginárias de exasperação surgiram na testa de Lu Linyuan. — Você não sabe ler? Então inventa os memoriais que lê para mim todos os dias?

Ele zombou em silêncio. *Sabe ler, sim. Quando escreveu «Eu amo Lu Linyuan», não errou um único caractere.*

Vendo que a desculpa não colava, Ning Xiaoxiao mudou de assunto: — Majestade, olha só! Esse bolo é mágico!

Ela levantou de baixo para cima a faixa de plástico que envolvia o bolo. O chocolate escorreu como uma cascata, cobrindo a massa.

Ela se exibiu toda orgulhosa: — Viu, Majestade? Não é incrível?

Incrível?

Incrível uma ova!

Lu Linyuan sentiu náuseas ao olhar aquilo. Pela textura, cor e forma, só conseguia pensar em... certa coisa...

A irritação acelerou sua respiração. — Na sua terra, oferecem merda aos aniversariantes?

Ning Xiaoxiao: — ...

Depois dessa comparação, nem ela conseguia mais olhar para o bolo da mesma maneira.

Mas quem seria capaz de resistir à tentação do chocolate?

Ela ia explicar quando Sanfu anunciou do lado de fora: — Majestade, o grão-secretário compôs um poema pelo seu aniversário. Deseja lê-lo?

Lu Linyuan respondeu com impaciência: — Não tenho tempo! Diga-lhe que faça algo útil em vez disso!

Ning Xiaoxiao não resistiu e cantarolou mentalmente um trecho de uma canção moderna: 【Por você escrevo poemas, por você faço o tempo parar, por você faço o impossível~】

Lu Linyuan: — ???

*Me alimentar com merda?*

*E ainda me alimentar com... um espelho?* — Ele interpretara completamente errado as palavras de som parecido da canção.

Sua irritação estava prestes a explodir quando Ning Xiaoxiao, toda sorridente e sem vergonha, disse:

— Majestade! Isto é chocolate, uma iguaria ocidental. Pode não parecer muito apetitoso, mas é uma delícia!

Antes que ele pudesse reagir, ela mergulhou um dedo no chocolate e encostou um pouquinho nos lábios dele.

Lu Linyuan: — !!!!

Instintivamente, ele quase vomitou, mas a língua tocou o chocolate por acidente.

E, depois de provar, teve de engolir o orgulho...

*Esse sabor... até que é bom!*

*Será que isso pode mesmo ser comido?*

*Enfim, ela vive inventando coisas esquisitas. Não teria coragem de me dar... aquilo para comer!*

Era inegável que Ning Xiaoxiao sabia aprontar.

— Majestade, antes de comer o bolo, precisa fazer um pedido!

Insistiu para que ele fechasse os olhos e formulasse um desejo, enquanto batia palmas e cantava ao lado dele uma canção num idioma que ele não compreendia...

E que, para ser sincero, não era lá muito afinada!

Sem conseguir se livrar da insistência dela, Lu Linyuan acabou fechando os olhos, meio a contragosto.

Foi nesse momento que ouviu um pensamento de Ning Xiaoxiao:

【Que você seja feliz, e não apenas no seu aniversário.】

Lu Linyuan não disse nada.

Mas, naquele instante, sem sequer perceber, os cantos de seus lábios se ergueram discretamente, formando uma curva bonita.

# Capítulo 75 — Você é mesmo uma inútilzinha

No dia do aniversário de Lu Linyuan, Gu Sijin pretendia levar Ning Xiaoxiao ao Terraço Tonghua para o banquete.

Mas Cailian não gostou nada da ideia. — Ultimamente, a senhorita leva Xiaoxiao para tudo e anda cada vez mais distante de mim...

Vendo o biquinho magoado dela, Gu Sijin cedeu: — Está bem, está bem. Se quer ir, eu levo você.

— Obrigada, senhorita! — Cailian imediatamente se agarrou ao braço de Gu Sijin, abrindo um sorriso.

Ao saber que não precisaria comparecer ao banquete, Ning Xiaoxiao ficou radiante.

A imperatriz-viúva e todas as consortes estariam presentes. Bastava cometer um errinho para ser castigada.

Por que não aproveitar esse tempo para fofocar com Qiqi, Qiaqia e as outras, ou tirar uma bela soneca?

Naquele meio-dia, depois que Cailian e Gu Sijin partiram para o Terraço Tonghua, Ning Xiaoxiao desenhou um baralho e ensinou às amigas como jogar Dou Dizhu, o jogo de cartas conhecido como «Combate ao Senhorio».

Estava prestes a derrotar todas quando Bengbeng avisou que Xiao Yinzi, do serviço imperial, a procurava na entrada.

Xiao Yinzi era aprendiz de Sanfu. Por que, justo no aniversário do imperador, não estava servindo seu mestre e vinha procurá-la?

Quando o encontrou, viu que ele segurava um pequeno frasco de porcelana branca.

Reconheceu-o imediatamente: era o remédio para feridas que comprara para Lu Linyuan dois dias antes.

— Xiaoxiao, Sua Majestade mandou devolver o remédio. Disse que a ferida já sarou e que não precisa mais dele.

Sem pensar muito, Ning Xiaoxiao pegou o frasco, agradeceu a Xiao Yinzi e voltou à partida de cartas.

Mais tarde, cansada de jogar, deitou-se sem se lembrar do frasco guardado junto ao peito. Ao se virar, ele pressionou seu busto avantajado.

Soltou um gemido, tirou o frasco e o largou numa mesinha. Ele tombou, a rolha se soltou e algumas sementinhas de ouro rolaram para fora.

Intrigada, despejou todo o conteúdo. Não havia nem um grão do pó medicinal; em compensação, caíram setenta ou oitenta sementinhas de ouro.

O medicamento lhe custara pouco mais de dez dessas sementinhas. Havia ali mais de cinco vezes a quantia que gastara.

Não era preciso perguntar quem colocara aquele ouro no frasco.

Então... o excedente seria uma espécie de pedido de desculpas do tirano?

Ora... talvez ele não fosse tão horrível quanto o romance original o pintava.

Ning Xiaoxiao lembrou-se de algo: segundo o romance, até morrer aos trinta e quatro anos, Lu Linyuan teria apenas um aniversário verdadeiramente feliz.

Ele era o imperador, aparentemente dono do maior poder do mundo. Mas no alto do poder também havia uma solidão terrível.

Tinha tantas obrigações que, até no próprio aniversário, precisava suportar as adulações interesseiras das consortes sem vontade nenhuma.

Seu único aniversário genuinamente feliz seria justamente aquele, quando completava vinte e quatro anos.

Na história original, àquela altura, ele e Gu Sijin já deveriam estar sinceramente apaixonados.

Por isso, depois de aturar as consortes no Terraço Tonghua, à noite Gu Sijin lhe prepararia uma comemoração íntima.

Só que a entrada de Ning Xiaoxiao naquele mundo tinha bagunçado tanto o enredo que o romance dos dois sequer começara.

Como Gu Sijin poderia lhe dar essa comemoração noturna?

Dançando «Compêndio de Matéria Médica» para ele durante a noite inteira?

Pensar nisso despertou nela uma inesperada pontinha de pena.

【E se... eu fizesse um bolo para ele?】

Chamou Xiao Qi: 【Xiao Qi, descobre para mim os ingredientes e o modo de preparo de um bolo?】

Xiao Qi respondeu prontamente: 【Cem gramas de farinha, quatro ovos, cem gramas de açúcar e um pouco de óleo. Bata os ovos com o açúcar usando hashis até formar uma mistura grossa e aerada. Acrescente a farinha e misture. Unte uma tigela com óleo para desenformar e cozinhe no vapor por uns quinze minutos. Mas por que quer saber, anfitriã?】

【Ah? Por nada... Só fiquei com vontade de comer bolo.】

Xiao Qi debochou: 【Vontade de comer, é? Ou vontade de fazer para certo «homem de fora»? Você sabe muito bem a resposta~】

Ning Xiaoxiao: 【...】

Era preciso reconhecer que as habilidades culinárias de Ning Xiaoxiao eram realmente «extraordinárias».

Desperdiçou um saco enorme de farinha, gastou vinte ou trinta ovos e quase esvaziou o pote de açúcar. Depois de sete ou oito tentativas, os bolos saíam duros o bastante para matar alguém ou moles como um fluido não newtoniano.

Até Xiao Qi perdeu a paciência: 【Anfitriã, você é mesmo uma inútilzinha~ Se as galinhas soubessem como você maltratou os filhotes delas, ficariam tão furiosas que até suas trompas entupiriam e nunca mais botariam ovos! Se não consegue fazer, pare de se torturar. Você ainda tem cabelos do tirano, não tem? É só comprar um bolo na lojinha!】

Comprar?

Restavam-lhe apenas quinze fios. Ela queria comprar alguma coisa gostosa para si. Gastá-los com bolo para ele?

Ele merecia tudo isso?

No entanto, apesar de bancar a durona, acabou abrindo a loja como se uma força invisível a guiasse. Com o coração sangrando, gastou todo o patrimônio em um bolo de aniversário de chocolate com recheio cremoso de quinze centímetros. Afinal, ela também poderia comer!

Além disso, os cabelos de Lu Linyuan voltariam a crescer. Se o deixasse contente no aniversário, não teria outras oportunidades de tosquiar aquele tirano, seu verdadeiro caixa eletrônico?

Escolheu um kit de aniversário que vinha com velas e permitia personalizar a mensagem escrita no bolo.

Quando Xiao Qi perguntou o que deveria escrever, ela pensou em «Sua Majestade», mas achou formal demais.

Depois de refletir, sugeriu: 【Por que não escreve «Yuanyuan»?】

Xiao Qi hesitou: 【Anfitriã... tem certeza?】

【Absoluta. Escreve assim. Depois eu explico para ele~】

Ning Xiaoxiao estava tão confiante que não fazia ideia do vexame monumental que se aproximava.

*

Naquele instante, uma verdadeira comédia se desenrolava no Terraço Tonghua.

Sob a liderança de Gu Sijin, a Consorte Nobre, a Consorte Yun e a Consorte Li executaram juntas uma coreografia:

— «Abertura de pernas do amor»!

Quando a dança terminou, só Gu Sijin permaneceu inteira. Para as outras, foi um completo desastre.

A Consorte Nobre reproduziu perfeitamente a cena lendária das calças abertas de Gu Sijin no dia da seleção das concubinas.

A perna da Consorte Li sofreu uma cãibra e ficou presa junto ao pescoço; ela levou um tempão para conseguir baixá-la.

A Consorte Yun teve sorte ainda pior: terminou a dança sendo carregada pelos médicos imperiais. Diziam que distendera justamente a parte do corpo usada para dar à luz...

De todos os espetáculos apresentados naquela noite, aquele foi o único que arrancou de Lu Linyuan um esboço de sorriso.

Ao vê-lo sorrir, a Consorte Nobre, que aparentemente também rachara o cérebro ao abrir as pernas, lançou-lhe um olhar envergonhado: — Vossa Majestade adora zombar desta concubina~

Lu Linyuan nem se dignou a responder. Apenas declarou friamente: — Já comemos, bebemos e abrimos as pernas. Estou cansado. Fiquem à vontade. — E foi embora.

Todos no banquete lhe desejaram alegria no aniversário.

Mas como poderia encontrar alegria enquanto precisava aturar aquelas pessoas?

Preferia voltar aos aposentos e ficar sozinho.

Jamais imaginaria, porém, que Ning Xiaoxiao já estava escondida dentro do guarda-roupa de seu quarto, pronta para lhe dar um susto de aniversário...

Quer dizer, uma surpresa!

# Validação do capítulo 320

- **Original chinês:** `novel_capitulos_301_a_360(20261107-181903).docx`.
- **Tradução-base portuguesa:** `novel capitulos 301 a 360 - ch.epub` (`index_split_019.html`).
- **Índices absolutos base zero do DOCX:** 1531–1596; unidades não vazias nos índices 1531–1595.
- **Unidades não vazias:** 63 no DOCX e 63 no EPUB; 63 linhas no CSV, incluindo o título.
- **Unidades modificadas:** 33 por correções dirigidas e normalizações.

## Revisão dirigida e decisões editoriais

A missão é considerada concluída enquanto Ning dormia; recompensa de +5 pontos percentuais, total 73%. Corrigidos pensamentos e interlocutores, falsas primeiras pessoas, recompensa por documento protegido por senha e morte da Consorte Nobre Viúva.

## Método e alcance

Cotejo estrutural unitário de todas as unidades não vazias; correções semânticas focalizadas das passagens identificadas. As demais unidades preservam, em maior ou menor grau, o EPUB. **Não houve auditoria semântica independente frase a frase do capítulo inteiro.** A equivalência em contagem não comprova ausência de omissões internas, mudanças sutis ou erros remanescentes. O original é a autoridade em caso de dúvida.

## Verificações

- CSV UTF-8; cabeçalho e índices absolutos originais preservados, sem duplicações.
- Tradução integral em sequência estrutural, com parágrafos, notas/divisórias presentes na fonte mantidos.
- O relatório não atribui qualidade de auditoria integral a verificações automáticas.

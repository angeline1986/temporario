Capítulo 321 — Você ainda tem a mim

Ao ouvir isso, o coração de Ning Xiaoxiao apertou.

Gu Sijin disse: — A Consorte Nobre Viúva sempre tratou muito bem o imperador quando ele era criança. Ouvi dizer que a imperatriz-viúva era muito severa com ele e vivia batendo e repreendendo o menino. A Consorte Nobre Viúva chegou a interceder várias vezes por ele junto ao antigo imperador e à imperatriz-viúva.

— Ela chegou a acolher o imperador por algum tempo em seu próprio palácio. Por isso ele e o Príncipe Jing cresceram tão próximos quanto irmãos de sangue.

Foi por essa razão que, depois de subir ao trono, Lu Linyuan sempre tratou tão bem a Consorte Nobre Viúva.

Todas as consortes do falecido imperador eram obrigadas a viver no Palácio Shou Kang para "passar seus anos restantes" após a morte dele, ou deixar o palácio para entrar em templos budistas e praticar o budismo, mantendo seus cabelos.

Somente a Nobre Consorte tinha permissão para deixar o palácio e se mudar para a residência do Príncipe Jing para desfrutar da vida familiar.

Mesmo depois de sua morte, Lu Linyuan lhe prestou todas as honras devidas.

Concedeu-lhe postumamente o título de Consorte Nobre Viúva Imperial. Sabendo que ela não se dava bem com o falecido imperador, não a sepultou no mausoléu imperial, mas no mausoléu reservado às consortes.

Também autorizou o Príncipe Jing a trasladar os restos mortais da mãe para seu próprio mausoléu quando este estivesse pronto, para que pudesse cumprir seu dever filial.

Lu Linyuan só retornou ao palácio no dia seguinte à morte da Consorte Nobre Viúva.

Ele estivera ocupado a noite toda e parecia extremamente cansado.

Ning Xiaoxiao foi para trás dele e massageou suavemente suas têmporas com seus dedos delicados:

— O Príncipe Jing sempre teve um jeito infantil. A morte da mãe deve ter sido um golpe terrível. Como ele está?

Lu Linyuan assentiu com a cabeça: "Depois desse incidente, percebi que Yi Qiu realmente amadureceu."

"Ele cuidou de todos os preparativos do funeral, e tudo foi feito corretamente e sem qualquer negligência."

— A Consorte Nobre Viúva nunca gostou de vê-lo chorar. Por isso ele não derramou uma lágrima durante toda a cerimônia.

Ning Xiaoxiao também se sentiu um pouco triste, então mudou de assunto: "Quando a Imperatriz Viúva soube da morte da Nobre Consorte, disse que queria sair do palácio para se despedir dela."

"Ela não merece isso."

Lu Linyuan pronunciou essas palavras friamente, e ao ver um claro lampejo de dúvida no rosto de Ning Xiaoxiao, a expressão feroz entre suas sobrancelhas desapareceu instantaneamente, substituída por um sorriso gentil:

"Já se passaram três dias, você sente minha falta?"

— Não senti — respondeu Ning Xiaoxiao, toda orgulhosa, fingindo indiferença.

"Ah, é? Você não quer?" O sorriso de Lu Linyuan era descaradamente provocador. "A saudade aumenta o amor, e você nem sente minha falta? Então terei que pensar em um jeito."

Dito isso, ele a puxou de surpresa e calou seus lábios com um beijo impetuoso.

*

Três dias depois.

Tarde da noite, na residência do Príncipe Jing.

A mansão do Príncipe Jing tem estado repleta de atividade nos últimos dois dias, com autoridades e nobres de toda a cidade vindo prestar suas homenagens e expressar seu pesar.

Ao cair da noite e com a dispersão da multidão agitada, a noite fica tão silenciosa que até o vento parece estar fazendo um alvoroço.

Lu Yiqiu estava sentado sozinho sob o corredor, abraçando os joelhos e segurando uma flor de magnólia já completamente seca.

Essa era a flor favorita da concubina imperial, mas não era época de florescimento.

Embora Lu Yiqiu geralmente pareça despreocupado e irreverente, ele é muito filial à sua mãe.

Todos os anos, nesta época, ele cavalgava até o resort de águas termais, colhia a primeira magnólia que desabrochasse na região, fazia um lindo buquê e o entregava pessoalmente à sua mãe.

A nova variedade de magnólia cultivada pelo Departamento de Flores e Aves foi plantada no Resort de Águas Termais por Lu Linyuan há muito tempo.

Este é o primeiro ano em que floresceu em todo o seu esplendor.

Na última visita à estância termal, a mãe lhe pedira que não se desse tanto trabalho, mas ele lhe prometera, sorrindo, uma surpresa.

Só que a Consorte Nobre Viúva nunca mais veria aquela surpresa.

A concubina imperial adoeceu gravemente de repente e nunca mais acordou após entrar em coma.

Lu Yiqiu colocou um buquê de flores de magnólia roxas claras em um vaso de vidro e o apresentou à cabeceira da Consorte Nobre, na esperança de que seu estado melhorasse e que ela o visse assim que abrisse os olhos.

Infelizmente, a flor murchou lentamente, assim como a vida vacilante da Nobre Consorte, que também chegou ao fim.

Cenas de momentos que passou com sua mãe lhe vieram à mente, todas repletas de seu amor e carinho.

Embora sua mãe soubesse que ele não gostava de mulheres, ela nunca o repreendeu. Em vez disso, o encorajou a fazer o que quisesse, dizendo que, contanto que ele fosse feliz, isso era tudo o que importava.

Enquanto recordava aqueles momentos, as lágrimas que se acumulavam nos olhos já lhe turvavam a visão.

De repente, ele sentiu uma sensação peculiar de farpas roçando levemente a pele no dorso da mão, acompanhada por uma sensação quente e úmida.

Quando recobrou os sentidos, viu que o Pixiu de alguma forma tinha ido parar ao lado dele, lambendo seu braço.

Pixiu ergueu os olhos, suas pupilas douradas encontrando o olhar de Lu Yiqiu. O grande leopardo negro miou como um gatinho, como se tentasse confortá-lo.

Atrás do Pixiu estava um homem alto e esguio com uma expressão gélida, olhando para ele de cima.

Ren Duanli sempre teve uma expressão severa, como se seus traços fossem naturalmente rígidos.

Mas hoje, um leve toque de mágoa era claramente visível em seus olhos brilhantes.

Durante os dias em que cuidava dos preparativos para o funeral de sua mãe, Ren Duanli deixou de lado todos os seus deveres oficiais e permaneceu silenciosamente ao seu lado.

Isso não significava falta de preocupação: Ren Duanli simplesmente não sabia como expressá-la.

Lu Yiqiu encontrou seu olhar penetrante, sua voz embargada pela emoção:

"Pequena Lili... Eu não tenho mais mãe..."

Após dizer isso, as emoções que vinham se acumulando dentro dele explodiram instantaneamente.

Ele abraçou os próprios joelhos com força e rompeu num choro desesperado, como o de uma criança.

"Waaaah... De agora em diante, ficarei completamente sozinho..."

Ren Duanli estendeu a mão e limpou a bolha de ranho que havia expelido acidentalmente, com a voz tão fria como sempre:

"Você ainda tem seu irmão."

"Mas meu irmão agora tem uma cunhada. Eu costumava ter minha mãe ao meu lado, mas agora... snif snif snif..."

Ren Duanli franziu a testa quase imperceptivelmente.

Ele detestava quando Lu Yiqiu chorava.

Não era por aversão: sempre que Lu Yiqiu chorava, o coração de Ren Duanli se agitava.

Ele sentou-se ao lado de Lu Yiqiu, hesitou por um momento e então levantou a mão de forma um tanto mecânica.

Uma mão larga pairou atrás de Lu Yiqiu, sem cair por um longo tempo.

Enquanto o menino soluçava tristemente, ele hesitou por um momento, mas finalmente colocou a mão no ombro de Lu Yiqiu.

Ele puxou o menino para seus braços e sussurrou em seu ouvido:

"Não chore."

"Você ainda me tem."

Ao ouvir isso, Lu Yiqiu ergueu os olhos cheios de lágrimas e fitou Ren Duanli com um ar de abandono.

— Você... vai ficar sempre ao meu lado?

Ren Duanli não conseguiu dizer nada sentimental; sua única resposta foi um "hmm" inexpressivo, como um pedaço de madeira.

"Waaaah~ Pequena Lili!"

Lu Yiqiu chorou ainda mais.

Ele se atirou nos braços de Ren Duanli, com lágrimas e ranho escorrendo por todo o corpo sem qualquer restrição.

Ren Duanli suspirou baixinho, olhou a própria palma e então, um pouco desajeitado, acariciou a nuca de Lu Yiqiu.

— Pronto, está tudo bem.

"Se você quiser chorar, simplesmente chore."

"Eu ficarei com você."

De repente, uma rajada de vento passou, levando embora as pétalas murchas da flor de magnólia que Lu Yiqiu segurava firmemente em sua mão.

A pétala flutuou ao vento e entrou no quarto onde a Consorte Nobre Viúva vivera.

Como se guiada por algo, acabou por flutuar e pousou no assento quente onde ela se sentava todos os dias para apanhar sol.

Quando tomava sol, a Consorte Nobre Viúva gostava de se recostar numa almofada macia de penas de ganso e olhar o corredor banhado de luz dourada pela janela.

E sentados agora sob o corredor estão Lu Yiqiu e Ren Duanli, suas figuras entrelaçadas.

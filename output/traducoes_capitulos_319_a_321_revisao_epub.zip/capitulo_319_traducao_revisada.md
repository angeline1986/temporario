Capítulo 319 — Vilões sem cérebro só merecem morrer

A Consorte Duan, com o corpo mole como lama, fez um enorme esforço para se ajoelhar diante de Gu Sijin e bater repetidamente a testa no chão:

"Sinto muito... tudo o que aconteceu antes foi culpa minha!"

"Eu não deveria ter te tratado dessa forma, não deveria ter conquistado sua confiança para depois te prejudicar!"

"Eu sei que errei... Eu imploro, eu imploro que me salve..."

Ela se agarrou à saia de Gu Sijin, chorando amargamente, suas palavras embargadas pelas lágrimas.

Ao ver a outrora altiva e poderosa Consorte Duan, agora como uma lentilha-d'água à deriva, curvando-se até o pó diante dela, Gu Sijin sentiu uma alegria incomparável.

Ouvir a voz rouca da Consorte Duan agora era como ouvir o grito de uma fênix em meio ao estilhaçar do jade em Kunshan, inexplicavelmente dando-lhe uma sensação de satisfação do fundo do coração.

Ela respirou fundo, expirou lentamente e sorriu serenamente.

"Está bem, aceito suas desculpas."

"No entanto, prefiro pedidos de desculpas que envolvam ações concretas em vez de apenas palavras vazias."

O sorriso sumiu do rosto de Gu Sijin. Seu olhar se tornou cortante ao percorrer a Consorte Duan, e ela declarou com ferocidade:

"Por exemplo, o mais apropriado seria você se desculpar comigo com a sua vida."

A Consorte Duan então percebeu que havia sido enganada por Gu Sijin, aquele coelhinho aparentemente inocente e inofensivo...

Antigamente, por mais cruéis que fossem a Consorte Nobre Tong ou a imperatriz Zhu, elas não poderiam fazer nada contra a Consorte Duan sem provas que a incriminassem.

Mas Gu Sijin era diferente.

Gu Sijin parecia uma louca.

Matava quem quisesse.

"Sua vadia... você disse que ia me salvar!"

Sangue negro escorria do canto da boca da Consorte Duan. Agarrando a saia de Gu Sijin, ela tentou se erguer apoiada nela.

Gu Sijin a chutou para longe sem cerimônia. Vendo que a expressão da Consorte Duan era feroz, como se estivesse prestes a proferir palavras obscenas daquela cadela, Gu Sijin rapidamente avançou e pisoteou seu rosto.

Ela pressionou os dedos dos pés contra a boca da Consorte Duan, selando-a para que ela não pudesse proferir uma única palavra.

— Quem está prestes a morrer não tem o direito de falar comigo.

"Isso dá muito azar."

Gu Sijin usou toda a sua força com o pé, e Consorte Duan, que já lutava para respirar, só pôde desistir aos poucos, com os olhos arregalados de raiva enquanto exalava seu último suspiro.

Xiuer esperou do lado de fora da porta por um longo tempo. Quando não ouviu mais nenhum movimento lá dentro, soube que Gu Sijin havia conseguido.

Ela reuniu coragem e empurrou a porta do quarto, onde viu Gu Sijin agachada no chão, limpando as manchas de sangue e as marcas de sapatos do rosto da Consorte Duan com um lenço.

A morte da Consorte Duan foi horrível; seus olhos estavam arregalados, quase saltando das órbitas.

Ao ver a cena, Xiuer sentiu náuseas, virou-se e teve sucessivas ânsias de vômito.

Gu Sijin ouviu o som, mas continuou tranquilamente a arrumar a aparência da falecida Consorte Duan.

Ao terminar, fechou os olhos da morta e perguntou a Xiuer, sorrindo:

— As pessoas merecem partir deste mundo bem-apresentadas, não acha?

Xiuer ficou tão assustada que quase perdeu a cabeça e só conseguiu gaguejar: "Sim... Vossa Excelência tem toda a razão..."

Gu Sijin olhou para trás, para ela, e disse: "Venha cá, está com medo de mim? Eu não vou te comer."

Xiuer se preparou e caminhou até Gu Sijin. Ela não ousou olhar diretamente em seus olhos, nem ousou olhar para o corpo sem vida da Consorte Duan. Ela apenas conseguiu desviar o olhar, com o corpo todo tremendo.

Gu Sijin caminhou calmamente até a bacia dourada ao lado dela, pingou duas gotas de suco de rosas e começou a lavar as mãos:

— Por que está aí parada? A Consorte Duan era sua antiga senhora. Vai deixá-la estendida nesse chão gelado? Ponha-a na cama.

Só de olhar para o cadáver, Xiuer estava apavorada. Como ousaria tocá-lo?

Ela ficou ali parada, atordoada e sem saber o que fazer, sentindo dormência nas mãos e nos pés, completamente incapaz de se mover.

De repente, sua bochecha foi beliscada com força e, em seguida, um líquido frio foi despejado em sua garganta.

Ao recobrar os sentidos, ela viu que Gu Sijin havia se aproximado dela, pegado o pote de jade e despejado o veneno em seu estômago.

Ao perceber o que estava acontecendo, Xiuer empurrou Gu Sijin com força, mas já havia engolido boa parte do veneno.

A reviravolta repentina dos acontecimentos a deixou incrédula. "Por que... por que você está me tratando assim?"

Gu Sijin inclinou a cabeça e sorriu levemente: "Então, como devo te tratar? Como uma irmã mais nova? Você nem merece isso! Já se esqueceu de como me tratou no passado?"

"Mas você disse que me perdoaria! E eu te ouvi e contei todos os planos da Consorte Duan, o que pode ser considerado uma reparação. Como você pôde..."

"Por que eu deveria te perdoar?" O sorriso de Gu Sijin congelou, seu rosto instantaneamente ficando tão frio quanto as profundezas do inverno.

— Se eu não tivesse descoberto que você mantinha um caso clandestino com um homem, não teria como chantageá-la para vigiar cada movimento da Consorte Duan.

— Nesse caso, você e sua senhora provavelmente já teriam escondido o veneno no rochedo artificial atrás do Palácio Fengluan para matar Xiaoxiao.

— Portanto, você não se arrependeu de coisa nenhuma. É burra como uma porca, não tem inteligência nem astúcia para me enfrentar e ainda teve a ousadia de imitar sua senhora, aquela mula, e bancar a vilã?

"Isto é absolutamente ridículo!"

Vendo que Xiu'er já havia sucumbido ao veneno e caído no chão, Gu Sijin caminhou em sua direção passo a passo, curvou-se e usou seu dedo indicador fino para levantar seu queixo.

"Se as pessoas más são tão desprovidas de inteligência em seus atos malignos, como podem merecer viver?"

Xiuer rangeu os dentes: "Você me matou, quem vai te proteger? Tanto a Consorte Duan quanto eu estamos mortas, você acha que vai sair impune?"

Gu Sijin soltou uma risada fria: — E ainda tenho de agradecer por você ter me contado de quem compraram o veneno. Já enviei uma mensagem por pombo-correio ao meu pai. Ele prendeu o médico que o forneceu; amanhã, o homem será levado ao palácio para confessar que vendeu o veneno a vocês.

"Vocês dois, senhor e servo, compraram veneno e o comeram. Estão cansados de viver. O que isso tem a ver com os outros?"

Xiuer sabia que não tinha saída, mas em seus últimos momentos, ainda pensava em seu amado.

Então ela chorou e implorou a Gu Sijin: "Posso morrer, mas Yelang não tem nada a ver com isso. Imploro, por favor, deixe-o ir?"

— Não. — Gu Sijin recusou sem hesitar. — Não é apenas uma questão de eu querer poupá-lo; mesmo que quisesse, agora já seria tarde.

Ela soltou o queixo de Xiuer, levantou-se lentamente e olhou para ela com desdém:

— Você não dizia que amava tanto o seu querido Yelang?

— Por isso, já mandei esfolá-lo, arrancar-lhe os tendões e jogar o corpo numa vala comum para alimentar os cães.

"Não!" Xiu'er exclamou em desespero, "Ele nunca te ofendeu, por que você está...?"

"O maior erro dele foi ter ficado com você." Gu Sijin ergueu a mão, ponderou por um instante e, de repente, sorriu gentilmente e disse:

— Ah, fazendo as contas, hoje é justamente o sétimo dia depois da morte dele.

"Se você andar mais depressa, talvez consiga alcançá-lo na estrada para o submundo."

— Assim, poderão se reencontrar até na morte. Não é maravilhoso?

Capítulo 320 — A morte da mãe do Príncipe Jing

Naquela noite, sem Lu Linyuan fazendo investidas indesejadas ao seu lado, Ning Xiaoxiao dormiu excepcionalmente bem.

Ela acordou naturalmente, se espreguiçou e bocejou sob os primeiros raios quentes do sol da manhã.

Hum. Ela descansou e se recuperou o suficiente; é hora de mandar a Consorte Duan embora.

Quando Ning Xiaoxiao estava prestes a chamar as criadas para ajudá-la a se lavar e se arrumar, a voz de Xiao Qi ressoou em sua mente:

【Bip, bip, bip! Parabéns, anfitriã, por concluir a missão de eliminar a Consorte Duan em 48 horas! Recompensa: mais 5 pontos percentuais no índice de desvio da trama. Total acumulado: 73%.】

【O quê?!】

Ning Xiaoxiao, que estava se sentindo bastante preguiçosa, imediatamente despertou de seus devaneios ao ouvir essas palavras:

【Eu durmo uma noite e ela já bateu as botas? Como morreu? Caiu da cama de madrugada, bateu de cara no chão e morreu?】

Xiao Qi: 【E como eu poderia saber? Quando não estou trabalhando na Agência de Administração do Espaço-Tempo, fico vagando pela mente da anfitriã.】

【Só consigo ver o que a anfitriã vê e saber o que ela sabe.】

【Hoje cedo recebi uma confirmação da Agência de Administração do Espaço-Tempo dizendo que você havia concluído a missão. Eu também fiquei sem entender nada...】

"Sua Majestade a Imperatriz?"

Bengbeng bateu levemente duas vezes na porta do quarto. "Este servo tem algo a relatar a Sua Majestade a Imperatriz."

"Entre."

Bengbeng entrou depressa e fez a saudação formal: — Majestade, aquela pessoa do Palácio Zhaochun... morreu.

— Como ela morreu?

Bengbeng: "Ela provavelmente foi morta pelo veneno que ela mesma conseguiu. Voltei para relatar e investiguei um pouco. Ela pediu a Xiuer que saísse do palácio para comprar veneno de um toxicologista. Esse veneno era originalmente destinado a prejudicar o filho que a Imperatriz esperava."

"Mas, de alguma forma, o veneno foi ingerido pelos dois, patrão e empregado... O médico envenenador pretendia fugir depois de pegar o dinheiro, mas acabou envolvido em outros casos de assassinato e foi preso pela Inspetoria, ocasião em que confessou tudo."

"A pessoa foi encaminhada para a prisão imperial. O Imperador não está no palácio, e este assunto ocorreu no interior do palácio. Exorto Vossa Majestade a Imperatriz a tomar uma decisão."

Ning Xiaoxiao permaneceu em silêncio por um momento após ouvir isso, sem saber se devia ficar com raiva ou se divertir.

A Consorte Duan estava inquieta, por tê-la ofendido no passado. Agora que Ning Xiaoxiao se tornara Imperatriz, ela estava naturalmente tão assustada quanto um pássaro ao menor sinal de um arco.

Ning Xiaoxiao já esperava que a Consorte Duan tentasse lhe fazer mal; só não imaginava que alguém tão convencida da própria inteligência acabaria sendo tão estúpida.

Tentara matar outra pessoa e acabara matando a si mesma?

Ela provavelmente se tornará uma lenda em uma única batalha; nos cinco mil anos de história da China, não há ninguém mais tolo do que ela.

"Aquele médico envenenador causou estragos na capital, e quem sabe quantas vidas ele tirou. É um desperdício de dinheiro mantê-lo na prisão e alimentá-lo. Seria melhor cortá-lo em mil pedaços e dar aos porcos."

Bengbeng aceitou a ordem: "Sim, este servo cuidará disso imediatamente. Mas a Consorte Duan..."

"O corpo dela ainda está no Palácio de Zhaochun. O Imperador ainda não retornou, então é difícil providenciar o sepultamento. Vossa Majestade, acha que deveríamos enviar o corpo dela primeiro para o Pavilhão Bingning?"

Ao ouvir isso, Ning Xiaoxiao cobriu o nariz com um lenço e disse com considerável desgosto: "Você está louco? Aquele Pavilhão Bingning é um lugar para armazenar frutas e verduras fora de época. Você jogou o cadáver dela lá dentro, quer comer as coisas que estão lá depois?"

Ning Xiaoxiao abanou a mão. — Deixem o corpo onde ela morreu.

"Ah... Mas Vossa Majestade a Imperatriz, já é verão..."

"O quê? Você está com medo que ela fique fedida?" Ning Xiaoxiao ergueu uma sobrancelha e zombou: "Então enrole-a em dois cobertores, para que o cheiro não se espalhe e cause repulsa nas pessoas. Ela está tentando prejudicar meu filho, o quê? Você espera que eu a trate com cortesia?"

"Este servo não ousaria! Este servo sabe o que fazer!"

Enquanto Bengbeng se apressava para cuidar dos preparativos do funeral da Consorte Duan, Ning Xiaoxiao sentiu um vazio no coração.

Na verdade, Ning Xiaoxiao tinha até esperado acordar e assistir à Consorte Duan se rasgar ao meio tentando fazer uma abertura de pernas...

Mas não! Como se previsse o futuro, a mulher escolhera antes uma maneira relativamente fácil de morrer. Saiu barato para ela!

No entanto, por uma reviravolta do destino, a missão foi concluída.

Como o índice de desvio da trama ultrapassara a marca de 70%, Ning Xiaoxiao, em teoria, deveria receber outra recompensa da grande roleta.

Ela então advertiu Xiao Qi: 【Não pense que não sei que, na última vez, você emperrou a roleta de propósito para ela parar na Pílula da Empatia Compartilhada! Se interferir de novo, eu vou...】

Xiao Qi: 【A anfitriã está imaginando coisas. Mesmo que eu quisesse interferir, agora não teria como. Restam apenas as recompensas pelos marcos de 70%, 80% e 90% do índice de desvio da trama. Elas não serão mais sorteadas na roleta: serão entregues diretamente, em valores fixos.】

Ning Xiaoxiao: 【Ah, muito bem! Você nem se dá ao trabalho de fingir mais, não é? Agora virou venda casada obrigatória?!】

Xiao Qi: 【￣□￣｜｜】

【Hehe! Recompensa entregue. Confira, anfitriã~】

Após dizer isso, Xiao Qi ficou offline num instante.

A recompensa era realmente diferente. Antes ao menos recebia objetos físicos; desta vez, como se o sistema tivesse abraçado a campanha de baixo carbono e proteção ambiental, abriu diretamente um novo documento na mente de Ning Xiaoxiao.

Ning Xiaoxiao fechou os olhos e operou o sistema, apenas para descobrir que clicar duas vezes no documento abria uma caixa de senha.

【Que história é essa?】

Xiao Qi a ignorou e apenas digitou lentamente um comentário que flutuou no topo do documento:

【A senha será informada à anfitriã quando o índice acumulado de desvio da trama alcançar 80%.】

Ning Xiaoxiao: “...”

Então a recompensa era... absolutamente nada de útil por enquanto?

*

Enquanto Ning Xiaoxiao tomava o café da manhã depois de se lavar e se arrumar, Gu Sijin apareceu para visitá-la.

Ela trouxe doces caseiros e chegou com um sorriso no rosto, parecendo estar de ótimo humor.

Eram os biscoitos amanteigados de leite de que Ning Xiaoxiao tanto gostava. Assim que a caixa foi aberta, um delicioso aroma de leite se espalhou.

Ning Xiaoxiao pegou um com as mãos nuas e enfiou na boca. "Que coisa feliz aconteceu com você tão cedo de manhã, irmã? Você ficou sorrindo o tempo todo!"

Ela cutucou Gu Sijin de leve com o ombro, ergueu uma sobrancelha com um sorriso travesso e provocou em voz baixa: "Você foi longe demais com o Governador Chu ontem à noite? Ainda está saboreando a lembrança?"

— Deixe de ser sem-vergonha. — Gu Sijin enfiou outro biscoito de leite na boca de Ning Xiaoxiao, calando suas insinuações picantes. — Soube hoje cedo que a Consorte Duan tentou prejudicá-la, mas acabou provando do próprio veneno e morreu. Fiquei muito satisfeita.

Gu Sijin acariciou por cima da roupa a barriga de Ning Xiaoxiao. — Essa criança tem até a proteção dos céus. É realmente uma bênção! Vou ter de ficar ao seu lado todos os dias para compartilhar dessa sorte~

"Sua Majestade a Imperatriz! Sua Majestade a Imperatriz!"

Enquanto as duas conversavam, Xiao Yinzi entrou tropeçando e ajoelhou-se diante delas, aflito:

"Vossa Majestade, algo aconteceu na residência do Príncipe Jing..."

— A Consorte Nobre Viúva faleceu...

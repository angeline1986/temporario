# Validação do capítulo 319

- **Original chinês:** `novel_capitulos_301_a_360(20261107-181903).docx`.
- **Tradução-base portuguesa:** `novel capitulos 301 a 360 - ch.epub` (`index_split_018.html`).
- **Índices absolutos base zero do DOCX:** 1462–1530; unidades não vazias nos índices 1462–1529.
- **Unidades não vazias:** 66 no DOCX e 66 no EPUB; 66 linhas no CSV, incluindo o título.
- **Unidades modificadas:** 24 por correções dirigidas e normalizações.

## Revisão dirigida e decisões editoriais

A Consorte Duan é morta por Gu Sijin; Xiuer também recebe veneno. Corrigidas trocas de sujeito e gênero, falsas falas em primeira pessoa, autoria da compra do veneno, o destino de Yelang e o humor cruel do desfecho.

## Método e alcance

Cotejo estrutural unitário de todas as unidades não vazias; correções semânticas focalizadas das passagens identificadas. As demais unidades preservam, em maior ou menor grau, o EPUB. **Não houve auditoria semântica independente frase a frase do capítulo inteiro.** A equivalência em contagem não comprova ausência de omissões internas, mudanças sutis ou erros remanescentes. O original é a autoridade em caso de dúvida.

## Verificações

- CSV UTF-8; cabeçalho e índices absolutos originais preservados, sem duplicações.
- Tradução integral em sequência estrutural, com parágrafos, notas/divisórias presentes na fonte mantidos.
- O relatório não atribui qualidade de auditoria integral a verificações automáticas.

# Validação do capítulo 321

- **Original chinês:** `novel_capitulos_301_a_360(20261107-181903).docx`.
- **Tradução-base portuguesa:** `novel capitulos 301 a 360 - ch.epub` (`index_split_020.html`).
- **Índices absolutos base zero do DOCX:** 1597–1682; unidades não vazias nos índices 1597–1681.
- **Unidades não vazias:** 83 no DOCX e 83 no EPUB; 83 linhas no CSV, incluindo o título.
- **Unidades modificadas:** 25 por correções dirigidas e normalizações.

## Revisão dirigida e decisões editoriais

Morte da mãe do Príncipe Jing e luto de Lu Yiqiu; preservada a distinção entre Consorte Nobre Viúva e imperatriz-viúva. Corrigidos sujeito, honras fúnebres, relação com Ren Duanli e passagens indevidamente escritas em primeira pessoa.

## Método e alcance

Cotejo estrutural unitário de todas as unidades não vazias; correções semânticas focalizadas das passagens identificadas. As demais unidades preservam, em maior ou menor grau, o EPUB. **Não houve auditoria semântica independente frase a frase do capítulo inteiro.** A equivalência em contagem não comprova ausência de omissões internas, mudanças sutis ou erros remanescentes. O original é a autoridade em caso de dúvida.

## Verificações

- CSV UTF-8; cabeçalho e índices absolutos originais preservados, sem duplicações.
- Tradução integral em sequência estrutural, com parágrafos, notas/divisórias presentes na fonte mantidos.
- O relatório não atribui qualidade de auditoria integral a verificações automáticas.

# Capítulo 98 — O Percevejo Mágico de Aladim

Só um idiota deixaria de fugir quando tem a chance.

Ning Xiaoxiao sentiu-se como uma condenada que acabara de receber o perdão e saiu correndo a toda velocidade.

Só que, por ter dançado com tanto vigor, o percevejo preso à manga já estava frouxo.

Além disso, ela saiu saltitando alegremente, sacudindo os braços de vez em quando. Numa dessas, o maldito percevejo se soltou e caiu no chão, sem que ela percebesse...

Depois que ela partiu, Lu Linyuan chamou Sanfu e ordenou: — Peça à Academia Médica Imperial que prepare outra panela daquela decocção para tratar irregularidades menstruais. Envie-a ao Palácio Zhongcui para Ning... para a Atendente Gu.

Sanfu reprimiu um sorriso. — Não se preocupe, Majestade. Sei o que fazer. Ah, mais uma coisa: o general Ren mandou notícias esta noite. Uma enchente bloqueou o caminho no sudoeste, então seu retorno à capital talvez atrase dois ou três dias.

— Entendi. Providencie a limpeza da residência do general com antecedência. E o príncipe Jing? Tem estado na capital ultimamente?

— Vossa Majestade conhece bem o temperamento do príncipe Jing. Ele sempre gostou de se divertir e costuma desaparecer por dias. Agora que o general Ren está voltando, aposto que vai se esconder ainda mais longe.

Lu Linyuan riu com frieza. — Não importa. Quando acabar o dinheiro, ele voltará por conta própria e cairá na armadilha. Com Ren Duanli de olho nele, terei uma preocupação a menos. Pode ir.

Depois que Sanfu saiu e ele ficou sozinho no aposento, a melodia de «Ai Ni» surgiu inexplicavelmente em sua cabeça.

Era como se aquela música, feita para acertar em cheio o coração dos homens, tivesse amaldiçoado seus membros. Começou a dançar involuntariamente e, de vez em quando, murmurava: — Humm... Acho que errei aquele passo agora há pouco.

Mal terminou de falar, arrependeu-se. Virou a mão e deu um tapa na própria nuca.

— Que palhaçada é essa?! Por que diabos estou estudando essa dança?!

Sentiu um arrepio e deu meia-volta para se lavar e ir dormir.

Foi então que pisou em cheio no percevejo.

Felizmente, ainda usava botas de corte, cujas solas eram grossas. O percevejo ficou encravado apenas na sola e não lhe feriu o pé.

*

Sanfu sempre resolvia tudo com eficiência. Gu Sijin e Ning Xiaoxiao mal haviam chegado ao Palácio Zhongcui quando os servidores da Academia Médica Imperial apareceram com uma panela de remédio.

— Sua Majestade está preocupado com a senhora. Mandou que preparássemos ainda esta noite esta decocção para tratar o frio no organismo e as dores abdominais. Também determinou que, daqui em diante, o remédio seja enviado todos os meses, nesta época. É um favor imperial concedido somente à senhora!

Gu Sijin imediatamente se ajoelhou para agradecer a graça imperial. Ning Xiaoxiao, por sua vez, pensou:

【Favor imperial?】

【Como é que isso pode ser um favor?】

【Ele está é criando uma galinha. Cuida dela, engorda, faz crescer... para depois se divertir abatendo-a.】

【Pobre pequena Gu! É vendida e ainda ajuda o vendedor a contar o dinheiro. Que bobinha!】

Depois de dispensar os servidores da farmácia imperial, Gu Sijin foi à pequena cozinha buscar duas tigelas de jade.

Serviu uma porção para si mesma e outra para Ning Xiaoxiao. — Xiaoxiao, quando sua menstruação veio este mês, você ainda sentiu dores no ventre?

Ning Xiaoxiao balançou a cabeça. — Foi muito melhor que da outra vez. Afinal, esta decocção trata o organismo, não apenas os sintomas. Naquela ocasião, tomamos tigeladas enormes por vários dias seguidos. Parece que já fez efeito. E a senhora?

— Comigo foi igual. Mas, já que Sua Majestade enviou o remédio, vamos tomá-lo por mais um mês para consolidar a melhora. No mês que vem já será inverno, e os sintomas podem voltar com mais facilidade no frio. Não podemos descuidar.

Ning Xiaoxiao detestava tomar remédios e não queria beber nada.

Mas Gu Sijin se comportou como uma mãezona: entre carinhos e insistência, fez com que tomasse duas tigelas grandes. Se Ning Xiaoxiao não tivesse dado uns tapinhas na barriga estufada para mostrar que estava cheia, provavelmente a senhora teria insistido numa terceira.

Depois do remédio e de ajudar Gu Sijin a se preparar para dormir, Ning Xiaoxiao correu para seu quartinho e trancou a porta.

Refletiu com cuidado. Naquele momento, parecia não ter nenhum desejo além de voltar para casa.

Podia, portanto, guardar a oportunidade de fazer um pedido ao Percevejo Mágico de Aladim para quando realmente precisasse.

Mas, ao apalpar a manga, ficou petrificada.

Cadê o percevejo?!

Eu não tinha prendido ele aqui?!

Tirou a roupa de cima e a examinou cuidadosamente à luz da vela. Tudo o que encontrou na manga foi um furinho deixado pela ponta. Do percevejo, nem sinal.

— Pronto, acabou! Deve ter caído em algum lugar no caminho de volta!

— O trajeto desde o Palácio Chaoyang é enorme! Vou demorar uma eternidade para encontrar!

Estava tão aborrecida que teve vontade de dar dois tapas na própria cara.

A recompensa que conquistara a duras penas não podia desaparecer assim! Por mais difícil que fosse, precisava tentar encontrá-la.

Saiu do Palácio Zhongcui no escuro, levando uma lanterna, e começou a vasculhar palmo a palmo as passagens do palácio.

Enquanto isso, no Palácio Chaoyang...

Lu Linyuan, depois de se lavar, deitou-se na cama, mas não conseguia dormir. Virava-se de um lado para o outro.

Bastava se lembrar de quando tivera enjoos de gravidez durante a audiência, com uma barriga enorme, e fora carregado de volta ao Palácio Chaoyang diante de todos, para sentir o rosto queimar de vergonha.

Aquela maluca! De todas as coisas possíveis, precisava me amaldiçoar a ficar grávido?!

Pelo visto, o castigo de hoje esteve longe de ser suficiente. Minha raiva nem passou!

Na próxima vez que ela chorar diante de mim, juro que não vou amolecer por causa daquelas lágrimas de crocodilo!

Resmungando mentalmente, foi ficando sonolento e acabou caindo num sono profundo.

Um quarto de hora depois de adormecer, uma fumaça azul-clara começou a sair da sola das botas de corte deixadas ao lado da cama.

Parecia haver alguma criatura viva embaixo de uma das botas, empurrando-a repetidas vezes.

— Tem alguém aí?! É assim que vocês recebem esta divindade suprema?!

— Por que estão me esmagando com uma sola de sapato?!

— Humanos estúpidos!

Uma força misteriosa empurrou a bota para longe. A fumaça se reuniu pouco a pouco, formando um homenzinho gorducho e inteiramente azul.

Ele flutuou até a cama de Lu Linyuan e o examinou. — Uau! Que homem bonito! Quero me agarrar nele!

— Cof, cof! Vamos ao assunto sério!

— Jovem, posso realizar um desejo seu. Diga agora o que deseja.

Lu Linyuan, meio adormecido, começou a sonhar.

No sonho, ele e Ning Xiaoxiao finalmente colocavam as cartas na mesa. Apontando para o nariz dela, ele rugia:

— Ning Xiaoxiao! Vou fazer você experimentar o que é estar grávida!

Só que o rugido do sonho escapou de sua boca como palavras murmuradas durante o sono.

Ao ouvi-lo, o espírito do percevejo acariciou a barba negra, pensativo.

— Problemas de infertilidade? Até para fazer um bebê vocês precisam da ajuda desta divindade?

— Está bem. Se quer que ela engravide, então que engravide.

Estalou os dedos, e a fumaça se dispersou. O gorducho azul desapareceu junto com ela.

*

Ning Xiaoxiao continuava procurando em cada pedacinho do corredor. Lembrou-se de Xiao Qi dizer que o Percevejo Mágico de Aladim era uma versão pirata da Lâmpada de Aladim. Resolveu então tentar chamá-lo baixinho:

— Percevejo mágico? Percevejo mágico? Está aí?

— Percevejo? Se estiver me ouvindo, responde! Está frio demais para você ficar estendido na rua a esta hora da noite!

— Percevejo, eu... Urgh!

Enquanto resmungava, uma onda de náusea a atingiu de repente. Sem aviso, apoiou-se na parede e começou a ter ânsias de vômito.

# Capítulo 96 — Eu quero mesmo é fazer você sofrer

Ning Xiaoxiao passou a tarde inteira chamando Xiao Qi, mas aquele peste não lhe deu a menor resposta.

Embora fosse fim de semana no mundo dos sistemas, normalmente bastava chamá-lo para ele aparecer.

Devia ter bebido demais no karaokê na noite anterior, depois de ser obrigado pelos outros sistemas a virar copos sem parar. Com aquela língua afiada, certamente era alvo de todo mundo por onde passava!

Ning Xiaoxiao desistiu de procurá-lo. A missão já estava concluída, e sua recompensa não sairia correndo.

Naquele dia, os portões do Palácio Zhongcui foram fechados cedo. Afinal, depois de a membranazinha de Gu Sijin ter se rompido no dia anterior, ninguém imaginava que Lu Linyuan voltaria a convocá-la para fazer ginástica naquela noite.

Mas Lu Linyuan parecia ter algum problema sério. A expressão «tratar uma dama com delicadeza» não existia em seu vocabulário; em vez de preservar uma flor, ele preferia esmagá-la.

Já havia escurecido quando o palanquim imperial de atendimento noturno estacionou diante do Palácio Zhongcui.

O servidor do Departamento dos Assuntos Imperiais sorria de orelha a orelha ao anunciar a boa notícia a Gu Sijin: — Parabéns, minha senhora! Sua Majestade escolheu sua placa de novo, mais uma vez, outra vez! O palanquim já está esperando lá fora. Apronte-se e vamos!

Gu Sijin ficou apreensiva. Colocou uma camada extra de tecido menstrual sob as roupas, com medo de que, depois de tantos pulos, acabasse sofrendo uma hemorragia...

Felizmente, naquele dia Lu Linyuan resolveu se comportar como gente.

Assim que ele entrou no aposento, Gu Sijin já assumiu a posição inicial, pronta para começar a saltar.

Lu Linyuan fez um gesto para detê-la. — Você não está bem. Hoje não precisa dançar.

Colocou diante dela um rolo de sutras budistas. — Sua caligrafia é boa. Quero presentear a imperatriz-viúva com estes sutras; copie-os para mim.

Gu Sijin soltou um suspiro de alívio tão grande que quase se atirou ao chão para agradecer a graça imperial.

Ela copiaria os sutras; Lu Linyuan, por sua vez, iria atormentar Ning Xiaoxiao.

Assim que saiu e viu Ning Xiaoxiao escondida atrás de uma coluna, estendeu a mão, agarrou-a pela gola e arrastou-a para o escritório. Tudo de uma vez, com uma fluidez assustadora.

Naquela noite, estava decidido a fazê-la pagar por todas as insolências e abusos de liberdade.

Se não lhe desse uma lição, dali a pouco ela estaria montando em seu pescoço e cantando vitória!

Ning Xiaoxiao já se habituara à rotina. Mal entrou no escritório, sentou-se na cadeira imperial, cruzou as pernas e pegou um memorial para ler.

Lu Linyuan lançou-lhe um olhar atravessado. — Quem mandou você se sentar?

— Ah? Ah... Então vou ler em pé.

— Em pé também não!

— Hein? Então... quer que eu leia deitada de bruços?

— Dançando. — Lu Linyuan indicou com os olhos o espaço livre diante da mesa. — Aquela dança «Ai Ni» que você apresentou da outra vez não era ruim. Estou pensando em transformá-la na ginástica oficial do harém. Dance de novo para eu ver o que ainda precisa melhorar.

【Você está bem da cabeça? Não seria melhor mandar elas dançarem «Bencao Gangmu»? Por que justamente «Ai Ni»? É dança de mocinha fofa! Aquelas velhas sem-vergonha têm alguma condição de fazer uma coreografia dessas?】

— O que está esperando? Comece logo!

Não havia jeito. Ela mesma tinha dado a ideia, afinal.

O tirano tomara gosto pela coisa. Quisesse ou não, ela teria de dançar.

Assim, Ning Xiaoxiao começou a dançar «Ai Ni» enquanto lia os memoriais.

O problema era que a melodia estava tão enraizada em sua cabeça que ela não conseguia ler as palavras em tom normal. Tinha de cantá-las.

Para piorar, o tirano ainda elogiou: — Muito bem. Continue.

Ela cantava e dançava sem ar, quase ofegando como um cachorrinho. Onde é que aquilo estava bom?!

Para Lu Linyuan, porém, nada disso importava.

Não fazia diferença se os passos eram corretos ou se ela desafinava. Sua verdadeira intenção era exaurir Ning Xiaoxiao!

Depois de oito repetições, sua cinturinha parecia prestes a se partir.

No começo, ainda mantinha a postura de uma idol, com um sorriso doce no rosto.

Agora, o controle da expressão fora para o espaço. Seu sorriso se transformara numa careta de choro, e ela cantava «Ai Ni» aos prantos.

Lu Linyuan ordenou em voz baixa: — Nada de chorar! Sorria para mim!

Buááá! Que homem cruel!

【Dançar «Ai Ni» é o cacete!】

【Quero é dançar «vou te matar»!】

Ning Xiaoxiao arreganhou os dentes num sorriso mais feio do que choro.

Perto do refrão, percebeu que Lu Linyuan havia baixado a cabeça para ler um tratado militar. Aproveitou para trocar a letra, cantando baixinho:

— Dentro do meu coração, você é um idiota de marca maior~ Amar é ter vontade de te dar uma surra até morrer!!

Como não ouvira direito o que ela cantou, Lu Linyuan voltou a repreendê-la: — Mais alto! Não estou ouvindo!

A fúria de Ning Xiaoxiao estava prestes a ultrapassar qualquer limite.

Eu te dei um dedo e você já quer o braço inteiro, é isso?! Está gostando de abusar, não está?!

Ela fechou os olhos, abriu o documento e apertou Pausar.

Ainda ofegante, deu passinhos curtos até Lu Linyuan, agora congelado, ergueu a mão e acertou-lhe um belo tapa.

— Quer que eu sorria, é?

— Quer que eu cante mais alto, é?

— Vou dar uma bofetada nesse *old dog king* que vai lhe causar toneladas de trauma psicológico!

Na opinião dela, Lu Linyuan só a atormentava porque estava cheio de energia e não tinha mais nada para fazer. Então decidiu lhe arranjar uma ocupação.

Abriu o documento e já se preparava para modificar a trama.

Foi quando Xiao Qi, desaparecido havia um dia inteiro, surgiu em sua mente com um bocejo:

【Bocejo~ Oi, anfitriã~ Acordei e encontrei doze chamadas perdidas suas! Nossa, como você é grudenta. Que irritação~】

【...Até que enfim apareceu! Já estava achando que tinha fugido com a minha recompensa!】

【Mas era minha folga! Não sou um escravo de escritório que trabalha das nove às nove, seis dias por semana! Pronto, pronto, aqui está seu prêmio!】

Mal terminou de falar, uma roleta gigantesca apareceu na mente de Ning Xiaoxiao.

Dessa vez havia ainda mais prêmios. Das dez divisões, apenas duas diziam «Tente outra vez».

Sem pensar duas vezes, Ning Xiaoxiao tentou girar a roleta.

Mas ela estava completamente travada. Por mais que tentasse, não saía do lugar.

【O que está acontecendo?】

【Você pausou o tempo do mundo. É claro que a roleta também não gira! Primeiro cancele a pausa, depois tente de novo.】

Ning Xiaoxiao voltou à posição de antes e continuou dançando como se nada tivesse acontecido.

Quando Lu Linyuan abaixou a cabeça para estudar o tratado militar, ela girou a roleta e viu o ponteiro parar numa casa vermelha.

Na seção da recompensa havia cinco caracteres: 【Percevejo Mágico de Aladim】.

【Que raio de coisa é essa? Não escreveram errado? Não deveria ser a Lâmpada Mágica de Aladim?】

【Nada disso~ É que não conseguimos acertar os direitos autorais com a Disney, então tivemos de mudar um pouco o nome para ficar na beiradinha da referência. Mas, apesar do nome diferente, funciona da mesma forma! É o grande prêmio! Ele pode realizar qualquer desejo da anfitriã!】

【Tudo isso?! Então eu quero...】

【Nem pense nisso!】 — Xiao Qi a interrompeu, indignado. 【O desejo não inclui voltar ao seu mundo de origem.】

【...】

Bem, melhor ter alguma coisa do que nada! Afinal, poder realizar qualquer outro desejo ainda era bastante útil.

Depois de um breve lampejo de luz azul, surgiu na palma de Ning Xiaoxiao um... percevejo de papel?

Ora essa! O percevejo mágico era mesmo um percevejo de verdade?!

Com medo de que Lu Linyuan notasse alguma coisa e roubasse também aquele prêmio, ela se apressou a escondê-lo.

Com a maior naturalidade, prendeu o percevejo na própria manga, com a ponta espetada no tecido, e continuou a dançar.

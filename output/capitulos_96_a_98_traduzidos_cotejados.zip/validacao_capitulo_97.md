# Validação — Capítulo 97

- **Fonte primária:** `novel_capitulos_61_a_120(20261103-205857).docx` (chinês tradicional).
- **Limites no DOCX (índices de parágrafo, base zero):** início 2685, capítulo seguinte em 2777.
- **Unidades não vazias, incluindo título:** 89.
- **Traduções preenchidas e alinhadas:** 89.
- **Índices faltantes:** 0; **índices adicionais:** 0; **campos vazios:** 0.
- **Conferência:** alinhamento estrutural 1:1 realizado durante a redação; revisão semântica de autoria, sem segunda auditoria linguística independente. A contagem não comprova por si só fidelidade integral de cada unidade.
- **Critérios:** preservar conteúdo, gênero, papéis, pensamentos entre 【】, humor, sarcasmo e causalidade. A paródia 阿拉燈神釘 é tratada como um percevejo/pino mágico, distinto da lâmpada de Aladim.
- **Nota editorial:** a paródia cantada por Lu Linyuan subverte a canção «Ai Ni». O termo 傻逼 é um insulto vulgar; a versão portuguesa o suaviza em parte como «idiota», opção que deve ser reavaliada numa revisão de registro.
- **Continuidade:** os pensamentos internos de Ning não significam conhecimento verbal de Lu sobre toda a situação; ele evita revelar a leitura mental.

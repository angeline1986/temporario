# Capítulo 97 — Amar é fazer você parar de respirar

Quando Ning Xiaoxiao chegou à vigésima sexta repetição, já não parecia uma mocinha meiga, e sim uma dançarina encharcada de suor, dessas que vivem no limite da sensualidade.

Teimosa como era, começara dançando enquanto xingava o tirano. Praticamente esgotou todos os palavrões que aprendera na vida.

Infelizmente, seu repertório de insultos era limitado. De tanto xingar, acabou sem palavras.

Quanto mais dançava, mais injustiçada se sentia.

【Buááá! Por quê?! Eu podia estar em casa comendo melancia e vendo televisão! Por que vim sofrer desse jeito aqui?】

【Esse imperador maldito deve ser um pervertido! Ele adora torturar os outros!】

【Como a pequena Gu não está bem e ele não pode atormentá-la, resolveu atormentar a mim!】

【Não quero mais ficar aqui! Quero voltar para casa! Buááá!】

Enquanto resmungava em silêncio, lágrimas de verdade lhe escorreram pelos olhos.

Misturadas ao suor, caíram em gotas brilhantes no chão.

Parecia que uma daquelas gotas também atingira o coração de Lu Linyuan, queimando-o de leve.

Chora, chora, chora! Por que tanta choradeira?!

Eu, um homem feito, fui obrigado por você a passar por uma gravidez, e nem assim chorei!

Com que direito você fica chorando?!

Ele limpou a garganta e perguntou, irritado: — Por que está chorando?

Ning Xiaoxiao fez biquinho, parecendo um patinho magoado. — Porque esta serva não consegue mais dançar...

Lu Linyuan continuou a falar com dureza de propósito: — Mandei você dançar para fortalecer o corpo! Faço isso pelo seu bem, e ainda se sente injustiçada?

Aquela repreensão foi a gota d'água para Ning Xiaoxiao.

Agachou-se, enterrou a cabeça entre os joelhos e abriu as comportas de uma represa:

— Buááá! O imperador sabe que meu período menstrual é próximo ao da minha senhora, e mesmo assim me obriga a pular sem parar! Quer que eu morra de tanto perder sangue?!

— Se ofendi Vossa Majestade em alguma coisa, é só dizer e acabar logo comigo! Buááá! Mas não me faça morrer de uma maneira tão vergonhosa! Buááá!

Chorava aos berros, como se tivesse sofrido a maior injustiça do mundo.

Lu Linyuan ficou momentaneamente sem reação.

Quem diabos sabe quando você menstrua?! Agora preciso anotar suas datas num calendário, por acaso?!

Você passou um tempão dançando sem dizer uma palavra! Como... como eu ia adivinhar que estava passando mal?!

Sentiu uma pontada de culpa.

Afinal, no último período menstrual de Ning Xiaoxiao, uma irregularidade no fluxo quase lhe custara a vida.

E ele acabara de obrigá-la a pular e dançar por tanto tempo. Será que realmente provocara uma hemorragia?

Quando alguém se importa, perde a calma com facilidade.

Ele se aproximou, agachou-se ao lado dela e cutucou-lhe a cabecinha com o indicador. — Ei. Como está se sentindo agora?

Ning Xiaoxiao virou o rosto para o outro lado e chorou ainda mais.

— Pare de chorar! Estou perguntando como você está! Precisa que eu chame um médico imperial?

— Buááá!

— Está doendo muito?

— Buááá!

— Está sangrando? Quer que eu dê uma olhada?

Ning Xiaoxiao: — ???

Lu Linyuan: — ...

— Craa! Craa!

Os dois corvos do palácio, responsáveis por anunciar situações constrangedoras, nem dormiam no meio da noite. Bastava surgir uma fofoca para aparecerem grasnando, sempre na primeira fila do espetáculo.

Como diabos é que eu poderia mostrar isso a você?!

Seu pervertido!

Ning Xiaoxiao olhou para Lu Linyuan através das lágrimas e começou a chorar ainda mais alto!

Lu Linyuan também percebeu o tamanho da indiscrição que acabara de cometer sem pensar. — Pare de chorar! Na pior das hipóteses, eu lhe peço desculpas!

— Buááá!

— Cale a boca! Proibido ficar nesse buá-buá!

— BUÁÁÁÁÁÁ!

— ...

Lu Linyuan sentia que a choradeira de Ning Xiaoxiao estava prestes a fazer sua cabeça explodir!

Só conseguia pensar numa coisa: faria qualquer coisa para que ela parasse de chorar.

— Diga logo. O que quer que eu faça para você parar?

Ao ouvir aquilo, Ning Xiaoxiao fungou duas vezes e respondeu numa voz doce e manhosa: — Vossa Majestade me fez dançar a noite inteira... Agora eu também quero ver Vossa Majestade dançar.

Lu Linyuan: — ???

— Quer que eu dance o quê? «Ai Ni», rebolando como você?

Seu rosto exprimia dez mil recusas. Ele balançou a cabeça como um chocalho. — Impossível! Absolutamente impossível! Sou o Filho do Céu! Como poderia me prestar a essas gracinhas?

Ao vê-lo recusar, Ning Xiaoxiao puxou o ar, abriu bem a boca e pareceu se preparar para mais uma torrente de lágrimas.

Lu Linyuan correu para tapar-lhe a boca com a mão e cedeu, apavorado:

— Eu danço! Eu danço! Só feche a boca!

Nunca tente discutir racionalmente com uma mulher, sobretudo com uma mulher adorável que parece ter torneiras instaladas nos olhos!

— Só não lembro direito da letra. Vai ter de se contentar com o que eu conseguir.

As faces de Lu Linyuan ficaram coradas e delicadas como as de uma jovem. Era a primeira vez, desde que entrara no livro, que Ning Xiaoxiao via aquela expressão no rosto perfeito do imperador.

Ele ficou a menos de dois metros dela, cerrou os dentes e começou sua apresentação de estreia:

— Se de repente você espirrar, é porque tem algum problema sério na cabeça~

— Se o canto do galo te acordar à meia-noite, ah, é porque você está doente~

— Sempre penso se as coisas que você diz não são sinal de doença mental~

— Está claramente muito doente, mas nem vai procurar o médico imperial~

— No meu coração, você é tão tapada quanto uma galinha~

— Amar é fazer você parar de respirar!

— So baby~ Se fizer menos besteiras suicidas, vai conseguir viver um pouquinho mais~

— Seja um pouco mais gentil, para que eu possa de verdade enxergar~

— Sua idiota~ Fale menos bobagem e deixe sua boca um pouco mais doce~

— Um pouquinho mais, para que eu possa fazer isso de livre e espontânea vontade~

— Amo você~~

Ao terminar, imitou o gesto clássico de Ning Xiaoxiao e fez um coraçãozinho com as mãos para ela.

ღ( ´･ᴗ･` )

O coraçãozinho atingiu Ning Xiaoxiao em cheio, bem no ponto fraco.

Ela se transformou numa fã apaixonada num piscar de olhos e aplaudiu com força, os olhos brilhando. — Uau! Majestade, que incrível!

【A letra estava indo tão bem no começo... Como é que de repente mudou completamente de estilo?】

【E ele não disse que não sabia dançar? Por que tenho a impressão de que dança melhor do que eu?】

【Aquela cinturinha se mexendo, aquele bumbum rebolando... Dá vontade de apertar!】

【Mas espera... Eu já disse a palavra «idiota» daquele jeito na frente dele? Buá! É tudo culpa dele, que me provoca! Eu sou uma garota doce e delicada, nunca falo palavrão! Nem pensar!】

Ela nunca havia pronunciado abertamente diante dele o palavrão chinês usado na canção. Mas em pensamento não perdia uma oportunidade de xingar Lu Linyuan com aquela expressão.

Lu Linyuan não compreendia exatamente o sentido da palavra; sabia apenas que, se Ning Xiaoxiao a usava para insultá-lo, não podia ser coisa boa.

Com medo de revelar seu segredo de que conseguia ouvir os pensamentos dela, apressou-se a dizer: — Pronto. Já dancei e já passei vergonha. Agora estamos quites. Nada de continuar chorando.

Ning Xiaoxiao enxugou as lágrimas. — Da próxima vez, Majestade, não me obrigue a fazer ginástica. Meus braços e pernas são frágeis. Se um dia eu quebrar algum osso, ainda vai precisar chamar um médico imperial para mim. Seria um desperdício de dinheiro...

— Se quebrar um osso, que fique manca! Não tenho dinheiro para pagar seu tratamento!

Lu Linyuan fez um gesto impaciente para dispensá-la. — Volte ao palácio com sua senhora. Saia da minha frente! Só de olhar para você fico tonto!

Ning Xiaoxiao não sabia se olhar para ela realmente o deixava tonto. Mas, se estivesse com tontura, certamente era porque acabara de rebolar com tanto entusiasmo que o sangue deixara de chegar ao cérebro!

# Capítulo 116 — O tirano é tomado pelo ciúme

As três pessoas no salão tinham pensamentos completamente diferentes.

Ning Xiaoxiao estava entretida com seu casal imaginário; Ren Duanli ficou com o rosto sombrio depois que o Príncipe Jing saiu abruptamente.

Só Lu Linyuan, aquele sujeito insuportável, estava ocupado comparando sua própria beleza com a do general.

Depois de um breve silêncio, Ren Duanli juntou as mãos diante do peito e respondeu:

— Majestade, este súdito passa a vida nos campos de batalha, viajando de um lugar para outro sem residência fixa. Qualquer moça que se casasse comigo acabaria sendo prejudicada. Um homem deve ter grandes ambições. Enquanto o império não estiver unificado, não tenho tempo para me dedicar ao romance.

— Encontrei a filha legítima do Duque Protetor do Reino apenas duas vezes, e brevemente. Não vale a pena que ela desperdice seus sentimentos comigo. Peço que Vossa Majestade recuse gentilmente o duque em meu nome. Por ora, não pretendo formar família.

Ao ouvi-lo, Ning Xiaoxiao quase não conseguiu esconder seu sorriso de fã apaixonada pelo casal.

Toda a capital sabia que a filha legítima do duque era de uma beleza capaz de eclipsar a lua, além de dominar música, xadrez, caligrafia e pintura. Inúmeros nobres haviam enviado propostas de casamento, mas ela era tão orgulhosa que sequer lhes dirigia o olhar.

Ren Duanli havia rejeitado uma candidata tão excelente sem sequer pensar duas vezes. Só podia ser porque guardava o adorável Príncipe Jing no coração!

Ela pensou: 【Que maravilha... Enquanto ele não se casar, ainda há esperança!】

Lu Linyuan: «???»

Você está me tratando como se eu nem existisse?

Ao notar pelo canto dos olhos o sorriso bobo de Ning Xiaoxiao, que quase babava, ficou ainda mais furioso.

【Maldição! Do que essa idiota está rindo?!】

【Eu estou sentado bem aqui e você ousa cobiçar outro homem?!】

Lu Linyuan examinou Ren Duanli de cima a baixo, sem encontrar nada em que ele fosse superior.

Se fosse obrigado a reconhecer alguma vantagem, seria apenas que o general, por passar tantos anos marchando em campanha, tinha pernas mais grossas.

Lembrou-se de que, desde que conhecera Ning Xiaoxiao, sabia de sua estranha mania de se agarrar às coxas dos outros: quanto mais grossas, melhor. Até fizera agachamentos por algum tempo por causa disso...

Será que ela estava interessada nas pernas grossas de Ren Duanli?

【Não! Preciso cortar pela raiz qualquer possibilidade de ser traído!】

Ren Duanli não aceitara o casamento; Lu Linyuan tampouco podia obrigá-lo.

Impor a união prejudicaria também a filha do duque. Seria uma maldade.

Depois de pensar muito, concluiu que o único jeito era impedir que Ren Duanli visitasse o palácio com frequência, eliminando qualquer oportunidade futura de encontro entre ele e Ning Xiaoxiao. Assim, uma «luz verde» de infidelidade jamais brilharia sobre sua cabeça.

— Já que não pretende se casar agora, não vou forçá-lo. Mas o Duque Protetor do Reino tem visitado o palácio com frequência. Como você recusou a filha dele, seria constrangedor se encontrassem. Enquanto estiver na capital, não venha ao palácio sem ser convocado por mim.

A ordem pareceu agradar especialmente a Ren Duanli. Ele concordou, pediu licença e saiu quase correndo.

Ning Xiaoxiao viu sua expressão desnorteada e teve certeza de que ia atrás do Príncipe Jing para se explicar.

Sentiu o coração adoçado, como se acompanhar aquele romance fosse mais emocionante do que viver um!

Ela acompanhou as costas do general com um olhar sonhador e continuou sorrindo feito uma boba.

Nem percebeu que o rosto de Lu Linyuan havia ficado terrivelmente sombrio.

— Do que está rindo?

De repente, ele lhe segurou o queixo, obrigando-a a voltar para ele aquele olhar apaixonado.

— Hã? Não estou rindo de nada... — Ning Xiaoxiao respondeu.

Lu Linyuan passou o polegar pelos lábios vermelhos dela e espalhou o batom no canto da boca. A bela jovem acabou parecendo um gatinho com a cara toda pintada.

— Escute bem. Agora você é uma das minhas concubinas. Seja de verdade ou de mentira, você me pertence.

Ele se inclinou sobre ela de modo dominador. Os rostos ficaram tão próximos que Ning Xiaoxiao conseguiu ver o reflexo de sua própria cara manchada nas pupilas dele.

A voz naturalmente grave de Lu Linyuan baixou ainda mais, quase um sussurro: — Fora eu, você não deve deixar o olhar repousar sobre homem algum. Se fizer isso, vou arrancar seus olhos!

【Socorro... Lá vem de novo esse discurso de presidente autoritário de romance barato. Homem violento merece cadeia! Que desapareça!】

Mesmo assim, era preciso ceder quando necessário.

Depois de tanto tempo convivendo com Lu Linyuan, Ning Xiaoxiao sabia que ele respondia melhor à doçura do que ao confronto.

Ela baixou os olhos, apertou os lábios e falou timidamente: — Majestade, não se preocupe. Quem recebe salário do soberano deve cumprir suas obrigações. Esta concubina recebe seu dinheiro e será uma esposa... digo, uma concubina que desempenhará suas funções direitinho!

— Direitinho? Ha! — Lu Linyuan sorriu de modo provocador e soltou seu queixo. — Falar é fácil. Agora que é minha concubina, precisa agir como tal. Esta noite vou jantar no Palácio Zhongcui. Você vai preparar a refeição. Algum problema?

Ela teria de cozinhar?

A última vez que tivera a ideia de preparar comida com as próprias mãos fora no mundo moderno, no aniversário do pai.

Começara às oito da manhã, comprando ingredientes, preparando tudo e assistindo a vídeos para aprender. Ao meio-dia conseguira servir quatro pratos e uma sopa.

O sabor até que era aceitável. Seus pais, seguindo o princípio de que «já que fomos nós que criamos nossa filha, precisamos engolir o que ela fizer», comeram tudo, quase chorando.

O resultado foi que, naquela mesma tarde, os três estavam alinhados em camas de hospital, reconsiderando todas as suas escolhas de vida...

Ning Xiaoxiao fez uma careta. — Majestade... não posso deixar de cozinhar? Minha comida realmente não é... muito gostosa.

Não dizer «horrível» era a última migalha de orgulho que lhe restava.

Mas Lu Linyuan tinha a personalidade de quem segue adiante mesmo sabendo que há um tigre na montanha. Negou sem hesitar: — Se mandei cozinhar, cozinhe. Nada de desculpas!

Ele olhou para o relógio de água de bronze. — São três da tarde, início da hora *shen*. Às seis, na quarta marca da hora *you*, irei ao Palácio Zhongcui. Se a refeição não estiver pronta, vou devorar você!

Devora-me?

De que jeito?

Pode explicar melhor... Eu não quero escrever, mas elas querem ler.

Sob a tirania de Lu Linyuan, Ning Xiaoxiao só pôde concordar, resignada. — Está bem. Mas, se a comida não ficar boa, não pode brigar comigo...

— Está bem — respondeu ele, indiferente.

Ning Xiaoxiao se virou para ir embora, mas de repente sentiu uma mão agarrar seu pulso e puxá-la para trás, fazendo-a cair no colo de Lu Linyuan.

Sentada sobre as pernas dele, arregalou os olhos, assustada como uma corça. — Majestade?

— Não se mexa.

Lu Linyuan começou a esfregar com os dedos a mancha de batom no rosto dela, como se Ning Xiaoxiao fosse a única exceção à sua obsessão extrema por limpeza.

— Minha mulher só pode passar vergonha diante de mim. Quando sair, deve sempre ofuscar todas as outras em beleza. Entendeu?

Ning Xiaoxiao estava tão constrangida que quase quis cavar um buraco com os dedos dos pés. Sorriu sem jeito.

【Socorro... Você não tem mais o que fazer? Vá arranjar emprego nos campos petrolíferos de Daqing! O país precisa que você produza petróleo...】

— Não tem problema, Majestade. É só eu voltar ao palácio e lavar o rosto.

— Não se mexa. Já vou terminar.

— Mas... Majestade, está esfregando tão forte que dói!

Lu Linyuan percebeu que o rosto dela ficava cada vez mais vermelho e parou os dedos. — Que batom é esse? Por que não consigo tirar essa cor, por mais que esfregue?

Ning Xiaoxiao estava à beira das lágrimas. — Já pensou na possibilidade... de ser Vossa Majestade quem está deixando minha pele vermelha de tanto esfregar???

Lu Linyuan ficou sem reação. Deu um sorriso constrangido, coçou a nuca e, depois de um longo silêncio, conseguiu dizer:

— ...Bem... que situação embaraçosa...


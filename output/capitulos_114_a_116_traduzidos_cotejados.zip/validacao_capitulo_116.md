# Validação — capítulo 116

- Fonte primária: `novel_capitulos_61_a_120(20261103-205857).docx` (chinês tradicional).
- Limites no DOCX: parágrafos indexados 4028 a 4099, inclusive; capítulo seguinte inicia em 4101.
- Total de unidades não vazias, incluindo título: **70**.
- Total de linhas no CSV: **70**; correspondência por índice original do DOCX: **70/70**.
- Campos sem texto ou índices sem correspondência: **0**.
- Revisão textual: realizada na redação, com verificação de sequência e preservação de discursos, pensamentos e notas autorais. **Não realizada auditoria semântica independente integral**, portanto o alinhamento estrutural não prova ausência de desvios internos.

## Cuidados editoriais e ambiguidades

A interpretação de Lu Linyuan é equivocada: Ning acompanha o romance imaginário do general com o Príncipe Jing; o imperador acredita que ela cobiça o general. “Luz verde” remete ao idiomatismo chinês do chapéu verde, símbolo de infidelidade. Mantidas ameaças verbais, gírias e a referência aos campos petrolíferos de Daqing. Horários conforme o próprio original: 15h e 18h.

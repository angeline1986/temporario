# Capítulo 115 — Você vai se casar, mas o noivo não sou eu

Diante das manhas do Príncipe Jing, a expressão de Ren Duanli sofreu uma mudança sutil, muito diferente da indiferença de Lu Linyuan.

Ele lançou um olhar ao príncipe e respondeu friamente: — Quer dinheiro? Muito bem. De agora em diante, o imperador me entregará seu estipêndio mensal. Nos meses em que trabalhar, devolvo o dinheiro. Quando não trabalhar, vou doá-lo em seu nome, para que acumule virtudes e boas ações.

O Príncipe Jing abriu um sorriso constrangido, embora educado: — Pois eu agradeço a você e a toda a sua família!

Ren Duanli puxou-lhe uma orelha. — Não tenho mais ninguém na família. Basta agradecer a mim.

Ning Xiaoxiao estava delirando com aquele casal imaginário.

【Por que puxar a orelha? Use a boca para calar a boca dele!】

【Assim ele passa a ser da sua família, e você deixa de ser sozinho!】

Lu Linyuan a encarou com desagrado. Ao perceber o sorriso impossível de esconder, perguntou: — Do que está rindo?

— De nada... — Ning Xiaoxiao respondeu. — Esta concubina só acha excelente a solução do general Ren. Além de fazer o Príncipe Jing trabalhar mais, vai aprofundar o sentimento entre os dois... Quer dizer, a amizade entre os dois.

— É mesmo? — Lu Linyuan sorriu. — Também acho excelente.

Ele se recostou, alongou o pescoço e falou preguiçosamente: — Como Atendente, você recebe cinquenta taéis por mês. Agora que está grávida, o Departamento de Assuntos Internos lhe concedeu mais quarenta taéis para despesas. Noventa taéis ao todo.

— Ouvi dizer que, desde que engravidou, é sempre a última a chegar para cumprimentar a imperatriz. Não pratica bordado nem lê poesia. Come, dorme, acorda e come de novo. Consegue ser ainda mais preguiçosa que o Príncipe Jing.

— A solução do general Ren me deu uma ideia. Já que você também gostou, vou adotá-la.

Lu Linyuan virou-se, afastou uma mecha de cabelo da testa dela e, diante de seu olhar confuso, provocou: — Pode continuar dormindo até tarde e dispensar as visitas à imperatriz. Aquele bando de mulheres reunidas todo dia não conversa sobre nada importante mesmo. Mas não pode negligenciar o bordado, a leitura e a caligrafia.

— Hã? Majestade... mas...

Ning Xiaoxiao não entendia absolutamente nada de bordado, e sua escrita nos caracteres da dinastia Qi era toda torta. Obrigar-lhe a ler e praticar caligrafia era praticamente uma tortura.

Ela abaixou a cabeça, demonstrando sua completa falta de vontade. — Vossa Majestade não sabe que descanso é a coisa mais importante para uma gestante?

Acariciou o ventre ainda plano e fingiu fragilidade. — E se esta concubina não descansar o suficiente e prejudicar o herdeiro imperial?

Lu Linyuan soltou uma risada fria. — Não tenho medo de que descanse pouco, mas de que descanse demais. A última mulher que passou a gestação só comendo e dormindo foi a Concubina Ke, do falecido imperador. No parto, o cordão umbilical se enrolou no pescoço do bebê; mãe e filho morreram.

Ele desviou os olhos dela e começou sua sessão diária de comentários venenosos:

— Pouco me importa se você morre. Mas nada pode acontecer ao meu filho.

Ning Xiaoxiao: «...»

Ela o encarou com uma expressão furiosa, embora ainda parecesse adorável.

【Ah, você se acha muito esperto?! Se em vez de fezes acumuladas houvesse mesmo um bebê na minha barriga, eu faria questão de dar à luz um menino gordinho para você!】

【Depois colocaria veneno na sua comida, mandaria você para o outro mundo e poria meu filho no trono. Eu governaria por trás da cortina, dormiria na sua cama de dragão, examinaria seus memoriais e gastaria seu dinheiro sustentando um monte de rapazes bonitos!】

Aquelas duas sequências de pensamentos atingiram Lu Linyuan como golpes sucessivos.

Como assim? A gravidez dela também era falsa? Na barriga só havia fezes acumuladas?

Ao descobrir aquilo, primeiro sentiu uma pontada de decepção. Depois, contraditoriamente, um pouco de alívio.

A decepção vinha de ter acreditado que logo seria pai. No fim, sua alegria fora em vão.

O alívio vinha de seu sentimento de culpa: achara que o desejo feito por brincadeira havia provocado a gravidez verdadeira de Ning Xiaoxiao.

Ela era uma moça inocente, que teria engravidado sem razão por culpa dele e precisaria suportar dez meses de gestação. Pensando bem, sua brincadeira daquele dia havia passado dos limites...

Assim era melhor. Ao menos não precisaria carregar culpa sempre que a visse.

Espere um instante...

Então ela tinha conseguido de graça um posto de concubina? E ele ainda precisava pagar todo aquele dinheiro extra por mês?

Que péssimo negócio...

Além disso, mesmo sem bebê algum, ela já planejava usurpar seu império e usar seu dinheiro para manter amantes?

Ha! Nem em seus sonhos!

Antes, descontar o estipêndio fora apenas uma brincadeira. Agora, ele estava falando sério.

— Você recebe noventa taéis por mês, três por dia. A partir de amanhã, bordará pela manhã, praticará caligrafia à tarde e lerá poesia à noite. Cada uma dessas três atividades valerá um tael diário. Se cumprir tudo e eu verificar, receberá o pagamento.

Caramba! Isso virou um sistema de bater ponto para ganhar por presença?

Por aquela miséria de salário, ele pretendia tratá-la como um burro de carga?

Ning Xiaoxiao naturalmente não gostou. — Majestade, para que me obrigar a fazer tudo isso...?

— Como assim, para quê? — Lu Linyuan perguntou com toda a seriedade. — Quando nosso filho nascer, poderá costurar roupas e gorros para ele e, sabendo ler e escrever, também poderá ensiná-lo.

— As roupas serão providenciadas pelas oficinas e pelo Departamento de Assuntos Internos. Quando chegar a idade de estudar, haverá eruditos na escola imperial. Esta concubina não tem grandes talentos; Vossa Majestade não teme que eu ensine nosso filho a seguir pelo caminho errado?

Nosso filho?

Ha!

Você fala disso com uma naturalidade impressionante!

Quanto ao pai dessas fezes na sua barriga, escolha quem quiser. Eu é que não serei!

Ele não a desmascarou; preferiu provocá-la.

— Se deixar tudo nas mãos dos outros, para que nosso filho precisará de você como mãe?

Ning Xiaoxiao fervia de raiva, mas não ousava responder em voz alta.

【Se eu fizer tudo sozinha, para que ele vai precisar de você como pai? Para crescer com um pai ausente?】

Na verdade, Lu Linyuan tinha interesses particulares ao exigir bordado, leitura e escrita.

Quando ela aprendesse a bordar direito, pretendia obrigá-la a costurar e bordar uma roupa de dormir para ele.

Já aprender a ler e escrever era ainda mais importante!

A letra dela parecia rabisco de galinha; a cada linha dos memoriais, deixava de reconhecer dois ou três caracteres. Isso atrapalhava terrivelmente a velocidade com que ele obtinha informações sobre o futuro.

Precisava treiná-la para aproveitar melhor suas habilidades!

Pouco antes, Ning Xiaoxiao assistira às fofocas sobre o Príncipe Jing e Ren Duanli. Agora os dois, em perfeita harmonia, acompanhavam a interação dela com o imperador como quem saboreava uma fofoca igualmente deliciosa.

Lu Linyuan lembrou-se de outro assunto e perguntou a Ren Duanli: — A filha legítima do Duque Protetor do Reino há muito nutre sentimentos por você. Há algum tempo, o duque veio me pedir que intercedesse por um casamento: a filha não aceita nenhum outro pretendente. Ela é bela, e a família tem uma das posições mais respeitadas da capital. Você também chegou à idade de se casar. Gostaria de autorizar essa união. O que acha?

A proposta repentina de casamento deixou Ren Duanli completamente perdido.

Ele nunca fora bom com palavras e não soube como responder.

Vendo seu silêncio, o Príncipe Jing comentou sem qualquer delicadeza: — Se é para casar, case logo. Você teria de casar algum dia mesmo. Meu irmão está oferecendo um casamento e você ainda vai fazer pouco caso?

Parece que lançou ao general um olhar de reprovação. Depois acenou para Lu Linyuan. — Irmão, vou visitar a imperatriz-viúva no Palácio Xianshou. Apareça lá mais tarde, está bem?

Dito isso, foi embora sem olhar para trás.

Ning Xiaoxiao já nem sabia se sua obsessão por casais imaginários a estava deixando louca. Pareceu-lhe ver uma sombra de tristeza atravessar os olhos do Príncipe Jing. Na mesma hora, uma triste música de fundo começou a tocar em sua cabeça.

【Você vai se casar... mas o noivo não sou eu...】

【Num cantinho onde ninguém vê, enxugo minhas lágrimas em segredo...】

Lu Linyuan: «...»

O que aquilo queria dizer?

Por que Ning Xiaoxiao iria chorar escondida só porque Ren Duanli ia se casar?

O imperador alternou o olhar entre ela e o general.

Espere...

Desde quando aqueles dois tinham alguma coisa?

E, convenhamos, o general nem era mais bonito que ele...

(Um aviso: quem não gostar do casal secundário pode pular essas partes. Ele mal ocupa espaço na história. Mas não venham me atacar dizendo que coloquei BL ou GL numa história de romance heterossexual. O amor não segue um único modelo; é diverso e inclusivo. O casal secundário quase não aparece, então quem não quiser ler pode simplesmente pular.)

(Ontem já começaram a me criticar, mas eu sou uma pessoa muito «tranquila»! Podem discutir ou até xingar os personagens, mas não me ataquem. Escrevo para entreter, não para ouvir insultos. Se quiserem xingar algum personagem, fiquem à vontade; cada um tem sua opinião, e eu respeito.)

(Mas, se me xingarem, vou xingar de volta. E não só isso: vou apagar a avaliação de vocês! Morra de raiva! Hehe~)

Por fim, como está fazendo calor, meus amores, cuidem-se para não passar mal! Amo vocês~

（づ￣3￣）づ╭❤～


# Validação — capítulo 115

- Fonte primária: `novel_capitulos_61_a_120(20261103-205857).docx` (chinês tradicional).
- Limites no DOCX: parágrafos indexados 3945 a 4026, inclusive; capítulo seguinte inicia em 4028.
- Total de unidades não vazias, incluindo título: **80**.
- Total de linhas no CSV: **80**; correspondência por índice original do DOCX: **80/80**.
- Campos sem texto ou índices sem correspondência: **0**.
- Revisão textual: realizada na redação, com verificação de sequência e preservação de discursos, pensamentos e notas autorais. **Não realizada auditoria semântica independente integral**, portanto o alinhamento estrutural não prova ausência de desvios internos.

## Cuidados editoriais e ambiguidades

Há uma nota autoral extensa sobre a presença de um casal BL secundário: preservada integralmente. O suposto estado de gravidez é uma farsa, assim como o próprio imperador descobre pelos pensamentos de Ning. O texto original menciona as mortes da Concubina Ke e de seu bebê; foi preservado como relato de personagem, não como orientação médica.

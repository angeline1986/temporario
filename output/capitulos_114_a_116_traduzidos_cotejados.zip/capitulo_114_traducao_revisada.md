# Capítulo 114 — O ingênuo e sedutor passivo × o general frio e distante

Só depois que Ning Xiaoxiao se sentou obedientemente ao seu lado é que Lu Linyuan encontrou disposição para lançar um olhar ao Príncipe Jing, que estava em pé diante dele, todo torto.

O príncipe parecia uma criatura sem ossos, largado de qualquer jeito, exalando preguiça da cabeça aos pés.

Mesmo quando Lu Linyuan o encarou com expressão sombria, ele não percebeu que havia algo errado em sua postura. Pelo contrário, reclamou, emburrado:

— Irmão! Você mandou o Xiao Lili soltar um leopardo atrás de mim! Não ficou com medo de aquela fera se enfurecer e me matar com uma mordida?

Ele cruzou os braços sobre o peito, fez beicinho e ficou olhando para os próprios pés, que chutavam o ar sem parar.

Lu Linyuan se perguntou se aquela habilidade de inverter a culpa não teria sido aprendida com Ning Xiaoxiao. Então elevou a voz:

— Fique direito diante de mim!

O Príncipe Jing fez ouvidos moucos. Soltou um «hmph!» pelo nariz e continuou exatamente como estava.

Ning Xiaoxiao espiou a expressão irritada do imperador e não conteve um risinho.

【Acho que a única pessoa no mundo capaz de deixá-lo completamente sem saída é esse irmãozinho dele!】

Lu Linyuan: «???»

【E você está rindo do quê? Qual é a diferença entre vocês dois?! Você é ainda pior do que ele!】

Quando Ning Xiaoxiao já se preparava para apreciar o espetáculo, Ren Duanli, que permanecia ao lado do Príncipe Jing, pronunciou duas palavras num tom casual:

— Fique direito.

A frase, dita sem esforço, teve o efeito de uma régua invisível. Ninguém sabia que nervo do Príncipe Jing ela havia atingido.

Ele estremeceu e, sem discutir uma única palavra, endireitou imediatamente as costas, assumindo uma postura militar impecável.

O contraste deixou Ning Xiaoxiao boquiaberta.

【Caramba... A última vez que obedeci tão depressa foi durante o treinamento militar da faculdade, diante do instrutor...】

Lu Linyuan virou ligeiramente os olhos para ela.

【Treinamento militar? Será que ela já serviu no exército?】

【Uma Hua Mulan da dinastia Qi?】

Seu olhar desceu lentamente e, ao parar no tamanho D do busto dela, descartou a hipótese na mesma hora.

Se Hua Mulan tivesse um busto daquele tamanho, não teria conseguido passar doze anos no exército e ainda ganhar a fama de que, quando dois coelhos correm lado a lado, é impossível distinguir o macho da fêmea.

Vendo que o Príncipe Jing finalmente se comportava, Lu Linyuan voltou ao assunto principal:

— O general Ren retornou vitorioso após derrotar os bárbaros do sul. Para recompensar os oficiais e soldados, precisamos consultar os registros militares. Ontem ele me pediu os livros, mas não consegui encontrá-los. Foi você quem implorou para ficar responsável por esse trabalho. Agora que está diante dele, explique-se.

Ren Duanli dirigiu ao príncipe um olhar ameaçador. O outro respondeu com um sorriso constrangido e desviou os olhos.

— Bem... Xiao Lili, não fique bravo. Não é que eu não tenha feito os registros! Preenchi dezesseis volumes inteiros! Só que... um dia antes de você voltar, ladrões invadiram a residência do Príncipe Jing e roubaram tudo!

O príncipe abaixou a cabeça e ficou batendo os indicadores um contra o outro. Parecia um aluno que não fizera uma linha do dever de férias e inventava para o professor que o cachorro havia comido tudo.

A desculpa era tão absurda que Ren Duanli, que não era nenhum idiota, não cairia nela.

Antes mesmo de se irritar, ele soltou uma risada de incredulidade: — E o ladrão aproveitou para roubar seu cérebro também?

Lu Linyuan costumava mimar bastante o irmão mais novo, mas uma coisa era uma coisa, outra coisa era outra.

Ele já havia insistido várias vezes para que o príncipe terminasse os registros militares. Mas este só adiava: amanhã, amanhã e mais amanhã. E, como sempre havia um amanhã, por que não adiar outra vez? Seu lema era simples:

*«Já que alguém precisa ser um inútil neste mundo, por que esse alguém não posso ser eu?»*

Agora os três exércitos comandados por Ren Duanli haviam prestado serviços extraordinários, mas não existiam anotações de quantos inimigos cada soldado abatera, qual mérito conquistara nem quanto deveria receber. Como distribuir as recompensas?

Quanto mais forte uma nação, mais importante manter o moral das tropas.

Aquilo não era brincadeira. Por isso, Lu Linyuan foi especialmente severo: — O dinheiro destinado às recompensas das tropas sairá do seu estipêndio. Não faltará um único tael.

Ao ouvir que o irmão ia mexer no seu bolso, o Príncipe Jing voltou a fazer manha como uma criança.

— Ah, irmão! O que recebo por mês mal dá para as minhas despesas! Se você entregar esse dinheiro a eles, vou morrer de fome...

Ele apertou os olhos secos, tentando espremer algumas lágrimas. — Irmão, você não vai mesmo ser tão cruel, vai?

Lu Linyuan não cedeu:

— Você cometeu um erro e não pode se safar toda vez que faz manha diante de mim. Os soldados arriscam a vida no campo de batalha para proteger o país e garantir o sustento de suas famílias. Por sua negligência, deixarão de receber o que lhes cabe. Quando a insatisfação se transformar em ressentimento e as tropas começarem a murmurar, como pretende apaziguá-las?

Embora o Príncipe Jing fosse pouco confiável no trabalho, sabia distinguir o certo do errado e compreender a gravidade da situação.

Doía-lhe perder seu querido dinheirinho, mas, diante do dever para com o país, precisava assumir a responsabilidade pelo erro que cometera.

Por isso não voltou a discutir, embora sua voz continuasse ressentida: — Está bem, então... Faremos como você disse, irmão...

Parecia que o assunto estava resolvido. Mas Ren Duanli, que até então acompanhara tudo friamente, movimentou-se.

Ele tirou do peito um livro de registros cuidadosamente encadernado e o apresentou ao imperador com as duas mãos.

— Este súdito sabia desde o começo que não podia confiar nele. Então, nos intervalos da campanha militar, preparei os registros por conta própria.

Lu Linyuan folheou rapidamente o livro e viu que as informações eram detalhadas. Não poupou elogios: — Você foi muito diligente.

O Príncipe Jing percebeu que o problema estava resolvido e imaginou que seu dinheiro estivesse salvo. Saltou de alegria, atirou-se sobre Ren Duanli e lhe deu um beijo estalado na bochecha.

— Uau! Xiao Lili é o melhor! Eu sabia que, não importava a besteira que fizesse, você e meu irmão me ajudariam a consertá-la!

O beijo deixou Ren Duanli completamente atordoado.

Ning Xiaoxiao viu o rosto habitualmente gelado do general corar. Um homem de ferro ficando todo tímido: que espetáculo maravilhoso!

【Aaaaaah! Podem me matar! Não quero mais saber do ship entre parentes! O ingênuo e sedutor passivo com o general frio e distante é o casal supremo!】

O Príncipe Jing aproveitou a oportunidade, com seu pequeno ábaco mental trabalhando a toda velocidade:

— Então... irmãooo, agora que os registros apareceram, você não precisa mais descontar meu salário, certo?

Lu Linyuan estava prestes a deixar o assunto de lado quando Ren Duanli se antecipou:

— Vossa Majestade pode transferir o estipêndio do Príncipe Jing para este súdito. Afinal, fui eu quem fez o trabalho dele. Depois de tanto tempo recebendo sem trabalhar, já passou da hora de aprender uma lição.

Lu Linyuan concordou imediatamente: — O general Ren tem razão. De agora em diante, entregarei a você todo o estipêndio mensal de Yiqiu.

O Príncipe Jing começou a pular desesperadamente, feito um macaco enlouquecido do monte Emei.

— Irmão, por que dar tanto dinheiro a ele?! É um brutamontes que só sabe guerrear! Nem entende de romance nem de diversão! Vai desperdiçar tudo!

Lu Linyuan olhou para ele com frieza e não respondeu.

Vendo que as manhas diante do irmão não adiantavam, o Príncipe Jing resolveu apelar para Ren Duanli.

Agarrou o braço do general e começou a balançá-lo de um lado para o outro. — Ah, Xiao Lili! Devolve meu dinheiro! Você sabe que adoro comer, beber e me divertir...

Fez um biquinho de pato; seus olhos estavam vermelhos. — Sem dinheiro, nem vejo mais sentido em continuar vivendo...


# Validação — capítulo 114

- Fonte primária: `novel_capitulos_61_a_120(20261103-205857).docx` (chinês tradicional).
- Limites no DOCX: parágrafos indexados 3877 a 3943, inclusive; capítulo seguinte inicia em 3945.
- Total de unidades não vazias, incluindo título: **65**.
- Total de linhas no CSV: **65**; correspondência por índice original do DOCX: **65/65**.
- Campos sem texto ou índices sem correspondência: **0**.
- Revisão textual: realizada na redação, com verificação de sequência e preservação de discursos, pensamentos e notas autorais. **Não realizada auditoria semântica independente integral**, portanto o alinhamento estrutural não prova ausência de desvios internos.

## Cuidados editoriais e ambiguidades

“骨科CP” refere-se a ship entre parentes; “YYDS” é uma abreviação elogiosa de fandom. A referência a Hua Mulan e ao tamanho D integra o humor original. O original usa 任斷離 para o general; mantém-se Ren Duanli por continuidade editorial. A atribuição da voz interior de Lu Linyuan é contextual. O título emprega terminologia de ship BL.

# Capítulo 103 — Esta serva está com pulso de gravidez!

Ning Xiaoxiao percorreu rapidamente a trama seguinte, mas descobriu que trechos inteiros haviam se transformado em mosaicos censurados. Não lhe davam a menor oportunidade de editá-los.

Entrou em pânico e chamou Xiao Qi para exigir uma explicação:

【Xiao Qi! Venha ver o que está acontecendo! O sistema pegou um vírus? Por que a trama inteira virou um mosaico?】

Xiao Qi fez uma rápida verificação e respondeu:

【Ah, não é vírus. A situação é a seguinte: quando grandes trechos da trama principal passam a envolver o anfitrião, ele deixa de poder consultar as partes que dizem respeito a si mesmo.】

Ning Xiaoxiao rolou depressa o texto e encontrou seis páginas inteiras cobertas de mosaicos.

【Como assim?! Eu sou só uma figurante descartável! De onde saíram tantas cenas minhas de repente?】

Xiao Qi: 【Cada escolha do anfitrião no mundo do livro influencia o desenrolar da história. Mas você não precisa se preocupar com isso. O final já está determinado: basta sobreviver até lá e tudo ficará bem.】

Sobreviver até o final?

Se não conseguisse superar essa história das ânsias, ela tinha a impressão de que morreria ali mesmo.

Sem poder alterar a trama, só lhe restava tentar reduzir ao máximo o ódio da imperatriz-viúva por ela.

Retrocedeu mais uma vez três minutos.

A imperatriz-viúva a encarava: — Você, criada! Enquanto estou falando, por que fica se remexendo desse jeito?

Dessa vez, Ning Xiaoxiao resolveu ficar em silêncio, esperando a náusea chegar.

Sem responder a nenhuma pergunta, soltou novamente um “UÉÉRGH!” e só então disse: — Imperatriz-viúva, esta serva deve ter comido alguma coisa estragada e não está passando bem. Comportei-me indevidamente diante de Vossa Majestade. Mereço punição.

E teve outra ânsia.

Tudo pareceu perfeitamente plausível. Dessa vez, a imperatriz-viúva apenas a olhou com certo asco, sem criar dificuldades.

— Muito bem. Atendente Gu, faremos como propôs a imperatriz: dois meses sem estipêndio e a cópia de doze volumes de sutras budistas. Aceita a punição?

Gu Sijin respondeu humildemente: — Agradeço a clemência da imperatriz-viúva. No futuro, respeitarei minha posição e não ultrapassarei novamente os limites.

A imperatriz-viúva assentiu: — Levantem-se e tomem seus lugares.

Faltavam dois meses para o ano-novo. A imperatriz-viúva e as concubinas mudaram de assunto e começaram a discutir os preparativos das festividades.

A hora de Lu Linyuan deixar a audiência matinal se aproximava. Todos os dias, ao sair da corte, ele visitava o Palácio Xianshou para cumprimentar a imperatriz-viúva. Como as conversas no Palácio Fengluan ainda demorariam, ela mandou um servo ao Salão Jinluan avisá-lo de que deveria vir diretamente ao Fengluan, para não fazer a viagem em vão.

— Segundo o Observatório Imperial, neste fim de ano nevará sem parar e a capital enfrentará uma onda de frio como não se vê há décadas. Pensei em pedir ao imperador que leve vocês à residência das fontes termais para fugir do frio. Além disso, todo ano a celebração no palácio é igual, sem novidade alguma. Lá poderíamos sentir a chegada da primavera mais cedo: seria um bom presságio para o ano que vem.

A residência ficava a mais de cem li da capital. Como havia muitas nascentes de água termal brotando do solo, a temperatura da região era um pouco mais alta do que nas demais.

Mesmo quando nevava no inverno, a neve não se acumulava ali. Nos dias de inverno mais amenos, flores de primavera chegavam a desabrochar no fim do décimo segundo mês. Era realmente um ótimo lugar para escapar do frio.

Mas o lugar não era tão espaçoso quanto a residência imperial de verão: ao todo, possuía menos de vinte quartos.

Mesmo que fossem, seria impossível levar todas as mulheres do harém.

A Consorte Yun comentou: — Ficamos felizes por Vossa Majestade pensar em nosso bem-estar. Mas a residência termal é pequena. Se uma irmã for e outra tiver de ficar, cedo ou tarde surgirão ressentimentos.

— Então escolheremos por posição — decidiu a imperatriz-viúva. — Irão as que ocupam o posto de Concubina ou superior; as demais permanecerão no palácio.

Ao ouvirem que teriam de ficar, as concubinas de postos inferiores — Prometidas, Atendentes e Nobres Damas — deixaram a decepção transparecer no rosto.

A única exceção foi Gu Sijin, que comemorou em segredo: se Lu Linyuan viajasse, ela não precisaria mais fazer aquelas ginásticas exaustivas!

A imperatriz sondou: — O arranjo de minha mãe imperial é muito apropriado. Mas a Concubina Tong também ocupa o posto de Concubina. Como será ano-novo, não poderíamos levá-la conosco?

O rosto da imperatriz-viúva escureceu quando ouviu o nome: — O imperador ordenou que ela ficasse confinada, sem sair a menos que fosse convocada. Para que levá-la? Para deixar o imperador contrariado? Que fique no palácio refletindo sobre seus erros.

— Sim — respondeu a imperatriz. — Só que, quando souber disso, a Concubina Tong provavelmente fará um escândalo.

— Como? Nem confinada consegue se comportar?

A imperatriz hesitou: — Bem...

A Consorte Yun aproveitou a deixa: — Vossa Majestade não sabe? Meu Palácio Zhaochun fica perto do Palácio Yaohua dela. Todas as noites precisamos ouvi-la cantar e tocar instrumentos! Mal termina *O Romance do Pavilhão Ocidental* e já começa *A Injustiça Sofrida por Dou E*. Se ela não dorme, ninguém mais consegue descansar!

A Concubina Tong tinha uma voz belíssima: cantava trechos de ópera Kunqu, melodias populares e ópera de Pequim. Até as cantoras do palácio ficavam um pouco atrás dela.

O falecido imperador adorava ouvir música. Naquela época, a Consorte Yi conquistara seu espaço no harém à força de uma voz de rouxinol. No auge dos seus favores, até a imperatriz-viúva precisava levar em conta sua opinião.

A Consorte Yun mencionou o assunto de propósito para despertar essas lembranças na imperatriz-viúva — e acertou em cheio.

— Qingzhu, vá ao Palácio Yaohua mais tarde e avise à Concubina Tong: se continuar com aquela cantoria infernal, terá de vir morar comigo. Quero ver se assim não consigo pôr ordem nela.

Enquanto conversavam, Ning Xiaoxiao teve mais duas ânsias de vômito.

Ela cobriu a boca, tentando não fazer barulho, mas Gu Sijin não conseguia deixar de se preocupar.

Perguntou baixinho: — Xiaoxiao, você comeu alguma coisa estragada? Além da náusea, está sentindo mais alguma coisa?

A imperatriz percebeu as duas cochichando. Nesse exato momento, Xiangling entrou para anunciar: — Imperatriz, o médico imperial Li chegou para verificar seu pulso de rotina.

Desejando demonstrar benevolência, a imperatriz disse: — Mande-o entrar. A criada da Atendente Gu parece estar sofrendo muito. Que o médico Li a examine primeiro.

Gu Sijin agradeceu prontamente: — Agradeço a Vossa Majestade, imperatriz.

Ning Xiaoxiao também agradeceu: — Esta serva agradece a preocupação de Vossa Majestade.

O médico Li era o médico pessoal da imperatriz. Permitir que ele examinasse Ning Xiaoxiao era conceder à criada uma honra extraordinária.

É claro que a própria imperatriz também ganhava com o gesto.

Enquanto o médico examinava o pulso de Ning Xiaoxiao, a imperatriz-viúva até elogiou a imperatriz: — Você tem tantas virtudes... Só é bondosa demais.

A imperatriz sorriu, envergonhada: — Sirvo minha mãe imperial todos os dias. Naturalmente, aprendi muito com seu exemplo.

No início, o médico Li mantinha uma expressão normal enquanto tomava o pulso de Ning Xiaoxiao. Mas, à medida que prosseguia, arregalou os olhos. Lançou a ela um olhar de espanto e terror.

Ning Xiaoxiao se assustou: — Doutor, não me assuste! Não vai me dizer que tenho alguma doença terminal, vai?

Como se tivesse visto um fantasma, o médico Li soltou o braço dela e se ajoelhou diante da imperatriz e da imperatriz-viúva. Respondeu tremendo:

— Imperatriz... Imperatriz-viúva...

— E-ela... O pulso dela indica gravidez!

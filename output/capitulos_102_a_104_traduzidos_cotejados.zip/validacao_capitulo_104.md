# Validação — capítulo 104

- Fonte primária: `novel_capitulos_61_a_120(20261103-205857).docx`, chinês tradicional.
- Intervalo de índices de parágrafos DOCX: **3200–3261** (o próximo título marca o limite superior exclusivo).
- Unidades não vazias da fonte, incluindo título: **59**.
- Unidades traduzidas no CSV: **59**.
- Índices ausentes, duplicados ou campos vazios: **0** na conferência estrutural automatizada.
- Tradução literária completa composta das mesmas unidades, preservando a ordem da fonte.

## Pontos editoriais

O diagnóstico e a acusação de gravidez permanecem sujeitos a contestação; não se afirma que a gravidez esteja comprovada. O original apresenta provável erro de grafia em 雇司機你, em contexto sobre Gu Sijin; a escolha contextual foi sinalizada na tradução. O exame físico de virgindade é uma crença dos personagens na ficção, não um método válido de comprovação médica. A expressão VIP é mantida como piada anacrônica.

## Limitações da validação

O cotejo estrutural 1:1 e a revisão realizada durante a tradução não equivalem a uma segunda auditoria linguística independente. Contagens iguais não comprovam, por si, ausência de omissões dentro de um parágrafo nem equivalência semântica perfeita. A tradução contém adaptações literárias de expressões coloquiais e de piadas chinesas.

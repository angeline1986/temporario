# Validação — capítulo 102

- Fonte primária: `novel_capitulos_61_a_120(20261103-205857).docx`, chinês tradicional.
- Intervalo de índices de parágrafos DOCX: **3074–3138** (o próximo título marca o limite superior exclusivo).
- Unidades não vazias da fonte, incluindo título: **62**.
- Unidades traduzidas no CSV: **62**.
- Índices ausentes, duplicados ou campos vazios: **0** na conferência estrutural automatizada.
- Tradução literária completa composta das mesmas unidades, preservando a ordem da fonte.

## Pontos editoriais

O capítulo contém insultos e linguagem chula na sequência que é revertida por Retroceder; esses insultos foram adaptados de modo explícito, sem suavização sistemática. A onomatopeia yue foi representada por UÉÉRGH e não deve ser tomada como fala intencional. O mecanismo Pausar/Retroceder é preservado.

## Limitações da validação

O cotejo estrutural 1:1 e a revisão realizada durante a tradução não equivalem a uma segunda auditoria linguística independente. Contagens iguais não comprovam, por si, ausência de omissões dentro de um parágrafo nem equivalência semântica perfeita. A tradução contém adaptações literárias de expressões coloquiais e de piadas chinesas.

# Capítulo 102 — A imperatriz-viúva repreende as concubinas, e Xiaoxiao tem uma ânsia de vômito bem na frente dela

A atmosfera no salão parecia ter endurecido como cola. A ira da imperatriz-viúva não diminuía.

— Faz apenas alguns dias que você conquistou os favores do imperador e já está se achando acima de todos? Tão inquieta, tão arrogante por contar com o favor imperial... Pelo visto, pretende seguir os passos da Concubina Tong.

Gu Sijin se apavorou e se ajoelhou depressa para responder: — A imperatriz-viúva me entendeu mal. Não foi essa minha intenção. Pensei apenas que os servos também são pessoas. Já vivem no palácio sem ninguém com quem contar, por isso quis lhes oferecer um pouco de conforto, dentro das minhas possibilidades. Mas me esqueci da diferença de posição entre senhores e servos. Peço que contenha sua ira. Reconheço meu erro.

Se até Gu Sijin, a senhora, estava ajoelhada, Ning Xiaoxiao naturalmente precisava se ajoelhar atrás dela.

Só que, assim que se ajoelhou, a sensação de que ia ter uma ânsia ficou ainda mais forte.

Ela se conteve com todas as forças. Não podia, justo naquele momento, jogar mais lenha na fogueira.

A imperatriz-viúva estreitou os olhos, acentuando as rugas nos cantos, e seu tom se tornou ainda mais severo: — O harém tem suas próprias regras. A imperatriz é bondosa e tolerante com vocês; muitas coisas ela deixa passar, fingindo não ver. Mas comigo não funciona assim!

A imperatriz logo fez uma reverência: — As palavras de minha mãe imperial são justas. Falhei em disciplinar as pessoas sob minha responsabilidade; peço que me puna. Mas, como é a primeira falta da Atendente Gu, cometida por boa intenção, não poderia perdoá-la desta vez?

— Não! — retrucou a imperatriz-viúva. — Um erro continua sendo um erro. Hoje dizemos que é a primeira vez; amanhã, que não foi intencional. Assim, as regras do harém não valerão nada! Não levaríamos outras pessoas a ultrapassar os limites? Se a Atendente Gu tem dinheiro particular para socorrer os criados, é porque não lhe falta prata. Pois que fique seis meses sem receber seu estipêndio! A quantia economizada será destinada aos pobres, para que sua boa intenção se cumpra por inteiro.

A imperatriz tentou convencê-la: — Mãe imperial, a punição certamente lhe servirá de lição. Mas estamos às vésperas do ano-novo, quando há tantas despesas. Se perder seis meses de estipêndio, talvez mal consiga atravessar o inverno. Que tal descontar apenas dois meses e ordenar que copie alguns sutras budistas para acumular méritos?

A falta de Gu Sijin não era tão grave. Ela admitira o erro com humildade, e a própria imperatriz intercedera por ela. A imperatriz-viúva já pensava em encerrar o assunto.

Mas, quando estava prestes a falar, notou a expressão esquisita de Ning Xiaoxiao, ajoelhada atrás de Gu Sijin.

Parecia impaciente: ora apertava o peito, ora tossia e limpava a garganta. Não tinha postura de serva nenhuma.

— Você, criada! Enquanto estou falando, por que fica se remexendo desse jeito?

Ning Xiaoxiao respondeu respeitosamente: — Imperatriz-viúva, esta serva não estava...

A imperatriz-viúva soltou um riso frio: — Eu vi muito bem, e você ainda ousa discutir? Humpf! Atendente Gu, essa é a ótima serva que você educou distribuindo prata e carvão?

O cérebro de Ning Xiaoxiao trabalhou a toda velocidade, procurando uma explicação.

Ela pretendia dizer: 【Vi que Vossa Majestade ficou zangada e estava pensando numa maneira de explicar que minha senhora não teve essa intenção.】

Mas, quando abriu a boca, provocou um desastre.

— Esta serva viu que Vossa Majestade ficou zangada e estava pensando... UÉÉRGH!

Aquela ânsia quase mandou a imperatriz-viúva desta para melhor.

Foi tão sonora que, no silêncio do Palácio Fengluan, parecia ecoar sem fim pelas vigas do teto.

As concubinas ficaram instantaneamente boquiabertas. Quase queriam erguer um polegar para Ning Xiaoxiao, em respeito à sua coragem suicida.

A imperatriz-viúva ficou tão furiosa que suas mãos tremiam: — Muito bem! Minhas palavras lhe dão vontade de vomitar, é isso? Pois vou deixar você vomitar à vontade! Guardas! Arrastem-na para fora e espanque-na com varas até cuspir sangue!

Pronto. Mais uma vez, fodeu tudo!

Como sempre, Gu Sijin foi a primeira a se colocar diante de Ning Xiaoxiao para protegê-la, abrindo os braços como uma ave de rapina:

— Acalme-se, imperatriz-viúva! Xiaoxiao não tem passado bem nos últimos dias. Ela não quis ofendê-la!

A imperatriz-viúva já não gostava de Gu Sijin e, depois da provocação de Ning Xiaoxiao, perdera de vez a paciência: — Tal senhora, tal criada! Até minhas ordens você ousa impedir? Quer protegê-la? Pois muito bem! Levem a Atendente Gu também e espanquem as duas!

Ning Xiaoxiao suspirou. Cansei. Melhor reiniciar.

Ela acertou um chute certeiro bem nas partes íntimas do guarda que avançava para agarrar Gu Sijin. Ele se contorceu de dor no chão.

Gu Sijin arregalou os olhos e balançou a cabeça: — Xiaoxiao! Não seja insolente!

— Enlouqueceram! Enlouqueceram todas! — gritou a imperatriz-viúva. — Prendam essa mulher imediatamente!

Sem a menor pressa, Ning Xiaoxiao ajudou Gu Sijin a se levantar e falou sem nenhum pudor: — Xiao Gu, você é boazinha demais! É por isso que elas montam em você. Por que perde tempo com essa velha desgraçada?

— ??? — A imperatriz-viúva explodiu. — De quem você está falando?

Ning Xiaoxiao lançou-lhe um olhar: — De você, sua velha desgraçada. Ouviu direitinho? Se não ouviu, volte ao palácio e copie isso cem vezes como castigo. Se ainda não aprender, mande gravar na árvore genealógica da sua família!

— Vo-você...

A imperatriz-viúva estava tão furiosa que mal conseguia articular uma frase.

Ning Xiaoxiao não ligava se ela morreria de raiva. Só queria desabafar:

— Você faz ideia de quantos criados morrem de frio no palácio quando chega o inverno? Ignora o sofrimento bem debaixo do seu nariz, mas adora bancar a santa e estender a mão aos pobres lá fora? Fica cultivando essa imagem de misericórdia com encenações baratas! Passa os dias comendo comida vegetariana e recitando sutras... Enfiou todos esses ensinamentos budistas na barriga de algum cachorro, foi?

A imperatriz-viúva bateu com força na mesa e gritou até ficar rouca: — Matem-na! Matem essa mulher!

Ning Xiaoxiao segurou a mão de Gu Sijin, tranquilizando-a: — Não tenha medo, Xiao Gu. Vou reiniciar tudo para nós duas.

Então mostrou o dedo do meio à imperatriz-viúva: — Adeus, sua velha desgraçada! Vai se foder!

Estalou os dedos e o tempo voltou três minutos.

A imperatriz-viúva encarava Ning Xiaoxiao: — Você, criada! Enquanto estou falando, por que fica se remexendo desse jeito?

Não! Ia vomitar outra vez!

Ning Xiaoxiao apertou depressa o botão Pausar, planejando ir vomitar do lado de fora e só então voltar.

Entretanto, ao chegar perto de uma cova de árvore fora do palácio, a náusea desapareceu de repente.

Ela se sentou no chão e esperou um bom tempo. Quando teve certeza de que não sentia mais ânsia, voltou e se ajoelhou atrás de Gu Sijin, apertando Reproduzir.

Com todo o respeito, respondeu à imperatriz-viúva: — Esta serva viu que Vossa... UÉÉRGH!

Outra vez?

Dessa vez, tinha conseguido falar só quatro caracteres antes de ter ânsia?

Estão de sacanagem comigo?

A imperatriz-viúva parecia ainda mais furiosa do que antes: — Que insolência! Olhar para mim lhe causa nojo, por acaso?

— N-não! Não é nada disso, imperatriz-viúva! Como eu poderia sentir nojo ao vê-la? Esta serva só queria... UÉÉRGH!

— Craaá! Craaá!

O corvo encarregado dos efeitos sonoros pousou mais uma vez num galho de pinheiro do pátio do Palácio Fengluan, deliciando-se com o espetáculo.

Ning Xiaoxiao finalmente compreendeu. Ao interromper o tempo dentro do livro, ela própria continuava sendo uma personagem daquele mundo. Podia se movimentar livremente, mas suas funções corporais ficavam suspensas. Por isso, mesmo que estivesse menstruada e sofrendo cólicas insuportáveis, ao pausar o tempo a dor desaparecia na mesma hora.

O mesmo princípio explicava a náusea.

Ou seja, não conseguiria escapar da ânsia de vômito diante da imperatriz-viúva simplesmente Retrocedendo ou Pausando.

Sua única saída, ao que parecia, seria modificar a trama.

Assim, pausou o tempo, fechou os olhos e convocou mentalmente o documento...

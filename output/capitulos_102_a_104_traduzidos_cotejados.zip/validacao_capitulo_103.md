# Validação — capítulo 103

- Fonte primária: `novel_capitulos_61_a_120(20261103-205857).docx`, chinês tradicional.
- Intervalo de índices de parágrafos DOCX: **3139–3199** (o próximo título marca o limite superior exclusivo).
- Unidades não vazias da fonte, incluindo título: **58**.
- Unidades traduzidas no CSV: **58**.
- Índices ausentes, duplicados ou campos vazios: **0** na conferência estrutural automatizada.
- Tradução literária completa composta das mesmas unidades, preservando a ordem da fonte.

## Pontos editoriais

O diagnóstico de pulso de gravidez é uma afirmação do médico Li, e não foi validado como fato objetivo da narrativa. Os postos das concubinas distinguem Concubina de Atendente. Foram mantidos os números: seis páginas censuradas, três minutos, dois meses, doze volumes, mais de cem li e menos de vinte quartos.

## Limitações da validação

O cotejo estrutural 1:1 e a revisão realizada durante a tradução não equivalem a uma segunda auditoria linguística independente. Contagens iguais não comprovam, por si, ausência de omissões dentro de um parágrafo nem equivalência semântica perfeita. A tradução contém adaptações literárias de expressões coloquiais e de piadas chinesas.

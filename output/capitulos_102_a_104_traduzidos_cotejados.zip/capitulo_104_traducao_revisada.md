# Capítulo 104 — Que conversa é essa que nem eu, um VIP, posso ouvir?

As palavras do médico Li foram como uma bomba lançada num lago tranquilo.

A explosão espalhou água por todos os lados, levantou ondas sucessivas e até deixou os peixes do fundo boiando de barriga para cima.

A Consorte Li cobriu a boca: — Como pôde acontecer algo tão indecente?

A Consorte Yun franziu a testa: — Que ousadia, Ning Xiaoxiao! Você se envolveu com um homem às escondidas, sem casamento, e profanou o harém!

A Atendente Xiao acrescentou: — A acusação de que sua senhora mantinha um caso era falsa, mas, no fim das contas, quem cometeu essa vergonha foi você?

O cérebro de Ning Xiaoxiao travou por alguns segundos.

Como é que é?

Pulso de gravidez?

Eu nunca nem toquei num homem! De onde saiu essa gravidez?!

Gu Sijin passava os dias ao lado dela e, naturalmente, não acreditava que Ning Xiaoxiao tivesse feito algo assim: — Médico Li, não poderia examiná-la de novo? Talvez tenha havido um engano. Isso envolve a honra de uma mulher; não se pode afirmar uma coisa dessas sem certeza.

— Esta serva jamais fez nada indevido! Muito menos poderia estar grávida!

A imperatriz interrompeu as discussões com voz grave: — Silêncio, todas vocês! Médico Li, examine-a outra vez. Já tivemos o caso da Concubina Tong; não podemos repetir acusações sem fundamento.

Segura de sua virgindade, Ning Xiaoxiao arregaçou a manga sem hesitar e ofereceu o pulso ao médico.

Dessa vez, o médico Li foi extremamente cuidadoso e repetiu o exame três vezes. Convencido de que o pulso indicava gravidez, voltou a se pronunciar:

— Informo à imperatriz que o pulso desta criada é, sem dúvida, de gravidez. Pratico a medicina há décadas e tenho confiança nesse diagnóstico. Se Vossa Majestade duvidar, pode convocar os médicos Chu e You, especialistas na saúde feminina, para examiná-la comigo.

— Não será necessário — cortou a imperatriz-viúva, severa. — Desde a primeira vez que vi essa criada, soube que ela não era flor que se cheire. Fale! Quem é o homem com quem você se deitou?

Quantos homens havia, afinal, dentro daquele palácio?

Ning Xiaoxiao nunca sequer conversara com os guardas dos portões. O homem com quem mais tinha contato era Lu Linyuan.

Ele era irritante, sem dúvida, mas pelo menos se comportava como um homem decente.

Mesmo naquela vez em que ela desmaiara no palácio dele, durante o aniversário, acreditava que Lu Linyuan jamais teria feito algo monstruoso contra ela.

Além do mais, ela menstruara havia apenas dois dias. Como poderia estar grávida de repente?

— Imperatriz-viúva, peço que investigue com justiça! Esta serva jamais teve relações indevidas com ninguém! Além disso, menstruei há poucos dias. A Atendente Gu pode confirmar.

Gu Sijin declarou: — É verdade, imperatriz-viúva. Xiaoxiao não está mentindo. Nossos ciclos costumam ser próximos e nós duas temos menstruações irregulares e dores na parte inferior do abdômen. Sempre que meu período chega, o dela vem poucos dias antes ou depois. Posso testemunhar isso!

A imperatriz ponderou: — Se ela menstruou há apenas alguns dias, a possibilidade de gravidez parece pequena. Mas também confio na capacidade do médico Li. Isso é...

— Basta ela dizer que menstruou para ser verdade? — zombou a Consorte Li. — Atendente Gu, você a acompanhou ao banheiro? Tirou as calças dela e viu com os próprios olhos?

— Isso...

— Isso o quê? Você não viu nada! Acredita só porque ela disse! Ora, se amanhã disser que é a deusa Chang'e do Palácio da Lua, descida ao mundo para conhecer a vida dos mortais, você também vai acreditar?

Na ocasião anterior, a Concubina Tong e Cailian não conseguiram derrubar Gu Sijin. Pelo contrário, acabaram contribuindo para que ela recebesse genuinamente os favores imperiais. Não eram poucas as mulheres do harém que morriam de inveja.

Agora que a gravidez secreta de Ning Xiaoxiao parecia fato consumado, todas queriam aproveitar a oportunidade. Uma falta da criada podia arrastar sua senhora à punição. Cada uma estava disposta a pisar em Ning Xiaoxiao, livrar-se dela, enfraquecer Gu Sijin e ainda manchar sua imagem diante da imperatriz-viúva.

Em todo o salão, ninguém além de Gu Sijin acreditava na inocência de Ning Xiaoxiao.

Vendo que Ning Xiaoxiao insistia em negar tudo, a imperatriz-viúva ordenou: — Levem essa criada ao Departamento de Punições. Apliquem uma tortura depois da outra! Quero ver por quanto tempo continuará defendendo o amante!

Gu Sijin se pôs diante de Ning Xiaoxiao e se prostrou repetidamente perante a imperatriz-viúva: — Tenha misericórdia! Tenho certeza de que Xiaoxiao nunca faria algo assim!

— Ah, você tem certeza? — A Consorte Yun soltou um riso frio. — E de que serve sua certeza? Quando uma criada comete uma falta grave, sua senhora também é punida. É óbvio que agora você tentará protegê-la!

Virando-se para a imperatriz-viúva, acrescentou: — Penso que a Atendente Gu está claramente encobrindo a criada. Talvez soubesse de tudo desde o começo. Caso contrário...

— Minha senhora não tem nada a ver com isso!

O grito repentino de Ning Xiaoxiao fez a Consorte Yun se assustar: — Por que grita comigo? Cuidado para não fazer força demais e acabar pondo a criança para fora!

Ning Xiaoxiao não podia envolver Gu Sijin outra vez. Se ela insistisse em entrar nessa confusão, as demais concubinas aproveitariam sua vulnerabilidade para destruí-la.

Ning Xiaoxiao era uma criada e não possuía a marca de castidade *shougongsha*. Não podia provar sua inocência tão facilmente quanto Gu Sijin fizera. [Nota editorial: o original contém aqui uma provável grafia errada do nome Gu Sijin.]

Mas, desde que ainda fosse virgem, acreditava que seria possível resolver o problema.

Por isso, disse à imperatriz-viúva: — Tenho como provar minha inocência. O médico Li diz que estou grávida; nesse caso, eu não poderia conservar minha virgindade. Vossa Majestade pode ordenar que uma funcionária da corte examine agora mesmo minhas partes íntimas. Assim, a verdade ficará clara.

Vendo-a falar com tamanha convicção e sem demonstrar medo, a imperatriz-viúva decidiu: — Façam como ela propôs. Qingzhu, chame uma funcionária para examiná-la!

*

Palácio Chaoyang.

Assim que terminou a audiência matinal, Sanfu contou a Lu Linyuan que a imperatriz-viúva o convocara ao Palácio Fengluan para prestar seus cumprimentos.

Lu Linyuan não tinha paciência para ouvir o falatório incessante das concubinas, então dispensou a visita naquele dia.

Naquele momento, estava no salão principal, discutindo com um grande erudito a visita de emissários ocidentais prevista para o início do mês seguinte. Aproveitava também para aprender algumas palavras estrangeiras.

— É uma alegria receber amigos que vêm de longe. Já comprei armas de fogo dos ocidentais, mas nunca lidei pessoalmente com eles. Como devo chamá-los de convidados de honra na língua deles?

O grande erudito respondeu: — *Very important person*.

Para Lu Linyuan, a pronúncia do homem parecia um zumbido de mosquito. — Diga algo mais simples.

— Então Vossa Majestade pode usar a abreviação: “VIP”. É simples e os emissários ocidentais entenderão.

Enquanto estudava com toda a dedicação, Lu Linyuan viu Xiao Yinzi entrar sorrateiramente, como um ladrão, e cochichar algo no ouvido de Sanfu.

Pela expressão dos dois, não devia ser boa notícia.

Então decidiu aplicar imediatamente o que acabara de aprender. Perguntou com toda a seriedade:

— Que conversa secreta é essa que nem eu, um VIP, posso ouvir?

Sanfu ficou constrangido: — Majestade... aconteceu algo no Palácio Fengluan. Dizem que o médico da imperatriz examinou Ning Xiaoxiao e encontrou um pulso de gravidez... A imperatriz-viúva ficou furiosa e está prestes a puni-la!

— O que você disse?! — Lu Linyuan saltou da cadeira. — Ela... ela está mesmo grávida?

Sanfu: — ...A julgar pela pergunta de Vossa Majestade, então isso realmente tem a ver com o imperador?

Talvez. Provavelmente. Quem sabe... tenha mesmo...

# Relatório de cotejo e revisão — Capítulo 20

## Base e abrangência

- Fonte primária: `novel_capitulos_1_a_60(20261103-131325).docx`, texto chinês.
- Unidades originais não vazias, incluindo título: **72**.
- Unidades traduzidas correspondentes: **72**.
- Lacunas estruturais no alinhamento: **0**.
- Arquivo de cotejo: `capitulo_20_cotejo.csv` (correspondência individual em ordem).
- A tradução foi realizada do original chinês, não do EPUB de referência.

## Revisão do conteúdo

Revisados o sangue na mão de Lu Linyuan, a túnica de Sanfu, a tentativa de Cailian de incriminar Ning e a declaração obtida por intimidação.

Nomes e convenções dos capítulos anteriores foram respeitados: Ning Xiaoxiao, Lu Linyuan, Gu Sijin, Sanfu, Consorte Duan, Consorte Nobre, Cao Ni Ma e a mecânica das alterações do enredo.

## Adaptações e pontos de atenção

- **‘Tire’:** a ordem curtíssima do imperador é ambígua, e Sanfu a interpreta como pedido para se despir por completo; preservar a situação equivocada é essencial para a piada.
- **Confissão escrita:** Cailian deixa a impressão digital no documento; Ning consegue assim uma prova que antes não possuía, apesar de ter prometido não entregá-la.
- **Roupa de Sanfu:** o imperador coloca sobre Ning a túnica que mandou Sanfu tirar, para esconder a mancha; não oferece a própria roupa.

## Limites da validação

A correspondência **72/72** atesta a existência de uma tradução para cada unidade do DOCX. Foi feita conferência de conteúdo e coerência narrativa na elaboração da tradução, incluindo nomes, números, referências e efeitos cômicos identificados. Isso **não** é uma certificação automática de precisão semântica: não houve segunda auditoria linguística independente e podem subsistir nuances a aperfeiçoar.

**Resultado:** tradução completa no nível das unidades de origem, com cotejo estrutural e revisão editorial realizada; sem pendências estruturais identificadas.

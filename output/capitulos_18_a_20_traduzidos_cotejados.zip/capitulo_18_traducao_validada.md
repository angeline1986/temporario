# Capítulo 18 — Pessoal, estou passada! Que espetáculo é esse?

Desde aquela noite em que fora “servir o imperador”, Gu Sijin não voltou a sair de seu palácio.

Dessa vez, estava realmente doente.

A série de exercícios que Lu Linyuan a obrigara a fazer era ainda mais puxada que a coreografia de “Compêndio de Matéria Médica”, de Liu Genghong. Até uma moça tão delicada e dócil quanto Gu Sijin, depois de voltar ao palácio e cair de cama, não conseguiu deixar de reclamar:

— Eu só estava doente, mas parece que Sua Majestade queria aproveitar a oportunidade para me matar...

Durante os dias em que esteve enferma, a Consorte Duan, que morava no mesmo palácio, foi visitá-la praticamente todos os dias.

A imperatriz, a Consorte Li e a Concubina Hui também apareceram uma vez, recomendando que descansasse bastante: o mais importante era se recuperar.

Gu Sijin, porém, não se esquecia das regras do palácio. Para não dar margem a comentários, bastou repousar quatro ou cinco dias e apresentar os primeiros sinais de melhora para ir prestar seus respeitos à imperatriz no Palácio Fengluan.

Assim que a viu, a imperatriz mandou as criadas colocarem uma almofada macia de penas de ganso em seu assento e lhe sorriu. — Já está completamente recuperada?

— Agradeço a preocupação de Vossa Majestade, imperatriz. Estou muito melhor.

— Mas ainda parece pálida. Ora, eu não disse que poderia voltar a me cumprimentar só quando estivesse inteiramente recuperada?

Gu Sijin respondeu sem deixar brecha: — Prestar meus respeitos à senhora de manhã e à noite é meu dever. Não ousaria negligenciá-lo.

A imperatriz assentiu várias vezes. — Você sabe se portar e respeita a etiqueta. Não admira que o imperador goste de você. Eu também gosto.

— A Consorte Nobre chegou!

Aquele ambiente harmonioso foi interrompido pelo anúncio.

Sempre que ia cumprimentar a imperatriz, a Consorte Nobre fazia questão de chegar um pouco atrasada. Só aparecia depois que todas já haviam prestado seus respeitos, como se sua entrada triunfal devesse deixar claro o quanto era especial.

Rebolando a cintura fina, aproximou-se do salão e fez uma reverência displicente. — Meus respeitos à imperatriz.

— Você chegou. Pode se levantar e tomar...

Antes que a imperatriz conseguisse terminar o “assento”, a Consorte Nobre já estava sentada.

Não era a primeira vez que a deixava constrangida daquele jeito. A imperatriz apertou discretamente o lenço na mão, sem dizer nada.

Quando ela se acomodou, as demais mulheres do harém se levantaram para saudá-la.

— Prestamos nossos respeitos à Consorte Nobre. Que Vossa Alteza tenha mil bênçãos.

Recostada preguiçosamente, ela descascou uma uva e a comeu, ignorando por completo as outras, que continuavam curvadas em reverência.

— As uvas do palácio da imperatriz são um tanto adstringentes. Parecem verdes.

A imperatriz respondeu com calma: — Sei que você gosta de uvas. Mas, com as enchentes deste ano no sul, as plantações foram prejudicadas; conseguir estas já foi difícil. Gaochang fica muito longe da capital, no norte. Mesmo assim, as uvas mais doces, da variedade “Bela Embriagada”, já estão a caminho. Quando chegarem, farei com que você receba sua parte primeiro.

A Consorte Nobre soltou uma risadinha. — As “Belas Embriagadas” de Gaochang chegaram ao meu palácio anteontem por correio urgente. Se eu esperasse os camelos e cavalos levarem um ou dois meses para trazê-las à capital, até a melhor das uvas teria gosto de mofo.

Os melhores produtos enviados ao palácio costumavam ser oferecidos primeiro à imperatriz, e só depois à Consorte Nobre.

Mas, por causa das enchentes no sul, o tio materno da Consorte Nobre ganhara prestígio como responsável pelo combate às inundações. Sua família também desfrutava de grande influência na corte; por isso, dentro do harém, ela conseguia praticamente tudo o que queria.

A imperatriz simplesmente mudou de assunto. — Conversamos há algum tempo. Será que você se esqueceu de que as outras ainda estão fazendo reverência?

Só então a Consorte Nobre fingiu se dar conta, soltou um suspiro e fez um gesto para que se levantassem.

Seu olhar percorreu a sala e parou em Gu Sijin. — Dama Gu? Já está curada?

— Graças à preocupação de Vossa Alteza, estou muito melhor.

— Se já está melhor, ajoelhe-se e peça desculpas à imperatriz. — A Consorte Nobre arqueou a sobrancelha. — Uma concubina deve vir ao Palácio Fengluan agradecer à imperatriz no dia seguinte ao serviço noturno, mesmo que esteja com um pé na cova. Você foi escolhida pelo imperador logo no primeiro dia e, depois de servi-lo, escondeu-se no seu palácio alegando doença. Ainda tem algum respeito pela imperatriz?

A imperatriz interveio em defesa de Gu Sijin: — Ela estava doente. Fui eu quem...

— Majestade, imperatriz. — A Consorte Nobre a interrompeu num tom severo. — Se as regras do harém não são respeitadas, isso não demonstra falta de rigor da imperatriz com suas subordinadas?

Gu Sijin não queria causar dificuldades à imperatriz e já se preparava para ajoelhar-se e admitir a falta.

Mal se levantara, porém, quando a Consorte Duan tomou a palavra em sua defesa:

— A doença da Dama Gu era causada pelo frio e podia ser transmitida a outras pessoas. Ela repousou com a autorização do imperador e da imperatriz. Por que isso incomoda tanto a Consorte Nobre? Afinal, foi também uma decisão do imperador. A Consorte Nobre acha que Sua Majestade também é incapaz de impor disciplina?

A Consorte Nobre continuou destilando comentários venenosos. Parecia ter dado corda à língua: não parava de falar.

Ning Xiaoxiao começou a se irritar com aquilo e, parada a um canto, deixou os pensamentos vagarem.

Já fazia dias que não modificava o enredo. Havia acumulado quase vinte caracteres disponíveis para alterações.

Desperdiçá-los seria uma pena. Por que não pregar uma peça na Consorte Nobre?

Deu uma olhada na passagem seguinte da história:

<Como a Consorte Duan machucara a garganta na infância, sua voz era grave e rouca, nada agradável. Assim que terminou de falar, a Consorte Nobre lançou-lhe um olhar atravessado e zombou: “Quem está falando? Esse grasnado de pato me dá dor de cabeça.”>

Ning Xiaoxiao acrescentou um único caractere à fala.

A Consorte Nobre olhou de lado para a Consorte Duan e disse com um sorriso frio:

— Quem está falando? Esse grasnado de pato me dá dor de teta!

*Consorte Duan: Que diabos ela está fazendo?*

*Imperatriz: Isso é coisa que se diga em voz alta?*

*Demais concubinas: Será que há algum romance secreto entre a Consorte Duan e a Consorte Nobre? Um amor entre mulheres?! Ai, já estou torcendo pelo casal!*

Todas olharam ao mesmo tempo para o peito da Consorte Nobre, com expressões que diziam mais do que palavras poderiam explicar.

Três segundos depois, a sala explodiu em gargalhadas.

A Consorte Nobre não fazia ideia de como deixara escapar uma frase tão indecente e sem pé nem cabeça.

Vermelha de vergonha, levantou-se para ir embora.

No original, estava escrito: <Morta de vergonha, a Consorte Nobre deu duas pancadas fortes na mesa e saiu a passos largos.>

Depois de uma nova alteração de Ning Xiaoxiao, a passagem ficou assim:

<Morta de vergonha, a Consorte Nobre deu duas pancadas fortes nas próprias tetas e saiu a passos largos.>

As demais concubinas arregalaram os olhos e trocaram olhares incrédulos.

*Meu povo, estou passada! Que espetáculo foi esse?!*

A imperatriz suspirou e balançou a cabeça. — Ai... Parece que a Consorte Nobre anda com algum problema sério na cabeça. Xiangling, vá buscar um médico imperial para examiná-la direito...

A Consorte Yun, ainda mais satisfeita com a humilhação alheia, cobriu a boca para rir. — E não se esqueça de chamar também um médico especialista nos problemas das mulheres da alta sociedade. Doença é para tratar, não para esconder!

Ning Xiaoxiao estava quase enlouquecendo de tanto segurar o riso. Mas Gu Sijin não rira uma única vez; como criada, ela não podia rir de outra senhora. Só lhe restava beliscar a própria coxa para aguentar.

Quem diria que, depois da audiência, mal tinham saído do Palácio Fengluan e, antes mesmo de Ning Xiaoxiao começar a rir, Gu Sijin já se dobrava em gargalhadas, quase ficando sem ar.

Ao vê-la rir, Ning Xiaoxiao também perdeu o controle. Só depois de um bom tempo gargalhando conseguiu dizer, ofegante: — Hahaha! Eu... eu me belisquei tanto para não rir que minha coxa deve estar toda roxa! Hahaha!

Gu Sijin mostrou a região entre o polegar e o indicador da mão, que ela própria havia beliscado até ficar vermelha, e riu por trás da mão. — Acha que foi só você?

Ning Xiaoxiao observou Gu Sijin rir sem a menor cerimônia. A deusa elegante estava se transformando numa doidinha.

E por que, de repente, aquela mulher lhe parecia até um pouco adorável?

---

## Notas de tradução

- **Liu Genghong e ‘Compêndio de Matéria Médica’:** referência à dança/rotina de exercícios popularizada pelo influenciador chinês; a referência vem do original.

- **Trocadilhos da Consorte Nobre:** a protagonista acrescenta um caractere para transformar ‘dor de cabeça’ em alusão aos seios e, depois, troca o objeto das pancadas de ‘mesa’ para ‘seios’. A redação em português adapta o resultado cômico sem reproduzir a semelhança gráfica do chinês.

- **‘Estou passada, pessoal’:** adaptação de 驚呆了老鐵, expressão informal de internet para espanto.

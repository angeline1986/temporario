# Relatório de cotejo e revisão — Capítulo 18

## Base e abrangência

- Fonte primária: `novel_capitulos_1_a_60(20261103-131325).docx`, texto chinês.
- Unidades originais não vazias, incluindo título: **67**.
- Unidades traduzidas correspondentes: **67**.
- Lacunas estruturais no alinhamento: **0**.
- Arquivo de cotejo: `capitulo_18_cotejo.csv` (correspondência individual em ordem).
- A tradução foi realizada do original chinês, não do EPUB de referência.

## Revisão do conteúdo

Revisadas as regras de reverência no harém, a intervenção da Consorte Duan, os dois usos de alteração de texto, a vergonha da Consorte Nobre e a reação final de Gu Sijin.

Nomes e convenções dos capítulos anteriores foram respeitados: Ning Xiaoxiao, Lu Linyuan, Gu Sijin, Sanfu, Consorte Duan, Consorte Nobre, Cao Ni Ma e a mecânica das alterações do enredo.

## Adaptações e pontos de atenção

- **Liu Genghong e ‘Compêndio de Matéria Médica’:** referência à dança/rotina de exercícios popularizada pelo influenciador chinês; a referência vem do original.
- **Trocadilhos da Consorte Nobre:** a protagonista acrescenta um caractere para transformar ‘dor de cabeça’ em alusão aos seios e, depois, troca o objeto das pancadas de ‘mesa’ para ‘seios’. A redação em português adapta o resultado cômico sem reproduzir a semelhança gráfica do chinês.
- **‘Estou passada, pessoal’:** adaptação de 驚呆了老鐵, expressão informal de internet para espanto.

## Limites da validação

A correspondência **67/67** atesta a existência de uma tradução para cada unidade do DOCX. Foi feita conferência de conteúdo e coerência narrativa na elaboração da tradução, incluindo nomes, números, referências e efeitos cômicos identificados. Isso **não** é uma certificação automática de precisão semântica: não houve segunda auditoria linguística independente e podem subsistir nuances a aperfeiçoar.

**Resultado:** tradução completa no nível das unidades de origem, com cotejo estrutural e revisão editorial realizada; sem pendências estruturais identificadas.

# Relatório de cotejo e revisão — Capítulo 19

## Base e abrangência

- Fonte primária: `novel_capitulos_1_a_60(20261103-131325).docx`, texto chinês.
- Unidades originais não vazias, incluindo título: **78**.
- Unidades traduzidas correspondentes: **78**.
- Lacunas estruturais no alinhamento: **0**.
- Arquivo de cotejo: `capitulo_19_cotejo.csv` (correspondência individual em ordem).
- A tradução foi realizada do original chinês, não do EPUB de referência.

## Revisão do conteúdo

Revisados os 30 mil taéis desviados por Wei Yan, sua execução, a fuga do cavalo provocada por Cailian, o resgate de Ning, a menstruação e a má interpretação da palavra “tia” pelo imperador.

Nomes e convenções dos capítulos anteriores foram respeitados: Ning Xiaoxiao, Lu Linyuan, Gu Sijin, Sanfu, Consorte Duan, Consorte Nobre, Cao Ni Ma e a mecânica das alterações do enredo.

## Adaptações e pontos de atenção

- **Cao Ni Ma (草泥馬):** nome do cavalo introduzido no capítulo 17; remete a um trocadilho com palavrão em chinês. Mantido como nome próprio.
- **‘Tia’ (大姨):** ao ouvir os pensamentos sobre a menstruação de Ning, o imperador interpreta literalmente a referência a uma ‘tia’ escondida na roupa, pois desconhece a gíria menstrual.
- **Sete Graus de Espaço (七度空間):** referência a uma marca de absorventes presente no texto chinês. O sangue no dorso do cavalo pertence à menstruação de Ning, não a ferimento no animal.

## Limites da validação

A correspondência **78/78** atesta a existência de uma tradução para cada unidade do DOCX. Foi feita conferência de conteúdo e coerência narrativa na elaboração da tradução, incluindo nomes, números, referências e efeitos cômicos identificados. Isso **não** é uma certificação automática de precisão semântica: não houve segunda auditoria linguística independente e podem subsistir nuances a aperfeiçoar.

**Resultado:** tradução completa no nível das unidades de origem, com cotejo estrutural e revisão editorial realizada; sem pendências estruturais identificadas.

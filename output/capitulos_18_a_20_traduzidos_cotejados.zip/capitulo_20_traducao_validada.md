# Capítulo 20 — O tirano põe um manto sobre os ombros dela com as próprias mãos

Assim que Lu Linyuan viu as roupas de Ning Xiaoxiao manchadas de sangue, entendeu na mesma hora de onde viera o sangue em sua palma.

Ning Xiaoxiao não apertara o botão Pausar.

Mas o tempo pareceu parar.

As únicas coisas que se moviam eram dois corvos que passaram voando sobre a cabeça deles, grasnando “crau, crau”, como se estivessem ali para completar a cena.

Lu Linyuan encarava Ning Xiaoxiao com os olhos em chamas, como se quisesse engoli-la viva.

— NING XIAOXIAO!!

— Aaaah! Majestade, não me bata! — Ning Xiaoxiao protegeu a cabeça com as mãos, magoada. — Todas as mulheres do palácio passam por isso. Não sou só eu... E... também não fui eu que enfiei a mão de Sua Majestade naquele lugar de propósito...

A fúria de Lu Linyuan não diminuiu. — Quer dizer então que a culpa é minha?

— Ah? Não, não! — Ning Xiaoxiao abanou as mãos repetidamente. — Sua Majestade se preocupa com todos os súditos do império e não hesitou em salvar até uma simples criada em perigo. Isso prova que é um soberano esclarecido, digno desse nome!

— Majestade! Majestade!

Enquanto conversavam, Sanfu chegou correndo na direção deles com um grupo de guardas, todos sem fôlego.

— Ai, esse Cao Ni Ma corre depressa demais! Majestade, está tudo bem com o senhor?

Sanfu tinha olhos atentos. Bastou um relance para ver o sangue na mão de Lu Linyuan. — Ah?! Majestade, o senhor está ferido? I-isso... depressa, chamem o médico imperial!

— Não é necessário! — Lu Linyuan escondeu a mão atrás das costas, fingindo calma. — É sangue que escorreu de um ferimento nas costas daquele animal. Não me aconteceu nada.

Lu Linyuan prezava demais a própria reputação. Se alguém descobrisse que sua mão estava coberta de sangue menstrual de Ning Xiaoxiao, ele morreria de vergonha ali mesmo.

Assim, para proteger sua dignidade, só lhe restava deixar o assunto para lá por enquanto, sem cobrar satisfações de Ning Xiaoxiao.

Ela percebeu seu constrangimento e se apressou em dizer: — Esta serva agradece a Sua Majestade por salvar sua vida! Vou levar Cao Ni Ma de volta agora mesmo e cuidar para que aprenda a se comportar!

Pretendia pegar as rédeas e conduzir o cavalo de volta, mas Lu Linyuan a impediu. — Fique onde está!

Ora, era óbvio que não podia deixá-la sair andando!

Se ela se mexesse, todos veriam a mancha de sangue atrás de sua roupa.

E quem sabia que tipo de fofoca os guardas e criados que estavam naquele corredor inventariam a respeito dele?

Talvez chegassem ao absurdo de dizer que ele estava com sangue na mão porque batera no traseiro de Ning Xiaoxiao.

Lu Linyuan olhou para Sanfu e ordenou friamente, com uma única palavra: — Tire.

— Ahn? Majestade... — Sanfu apertou os lábios, todo envergonhado. — Aqui mesmo? Acho que não é muito apropriado...

— Mandei tirar, então tire! Por que tanta conversa?

O rosto de Sanfu ficou vermelho num instante. Ele começou a tirar a roupa, todo cheio de acanhamentos.

Assim que Sanfu tirou a túnica de cima, Lu Linyuan a apanhou e a colocou sobre os ombros de Ning Xiaoxiao.

A roupa oficial dos eunucos era comprida e cobria perfeitamente a mancha embaraçosa atrás da saia dela.

Para evitar que alguém interpretasse mal o gesto, Lu Linyuan ainda fez questão de dar uma justificativa tão forçada que só chamava mais atenção. — Sua senhora acabou de se recuperar. Você anda pouco agasalhada. Não vá pegar um resfriado e transmiti-lo a ela.

Ning Xiaoxiao sabia perfeitamente por que ele fizera aquilo. Sorriu, dobrou os joelhos em agradecimento e se preparou para conduzir Cao Ni Ma, quando viu Sanfu pelo canto dos olhos.

*Será que esse sujeito tem algum parafuso solto?* Depois de tirar a túnica, agora estava tirando as calças em plena vista de todo mundo!

Lu Linyuan também percebeu aquela palhaçada incompreensível e acertou um tapa impiedoso na nuca do eunuco. — O que está fazendo?!

Sanfu respondeu: — Mas não foi Vossa Majestade que mandou este servo se despir...?

...

Ning Xiaoxiao conduziu Cao Ni Ma de volta ao Palácio Zhongcui. No meio do caminho, encontrou Qiqi, Qiaqia, Bengbeng e Lala.

Tinham saído para procurá-la.

— Xiaoxiao, você está bem? Cao Ni Ma sempre foi tão mansinho! Como pôde enlouquecer de repente?

— O principal é que você não se machucou!

Ning Xiaoxiao vira nitidamente Cailian espetar a garupa do cavalo com o grampo.

Entregou as rédeas a Bengbeng e pediu que levasse Cao Ni Ma primeiro. Depois, foi diretamente ao quarto de Cailian.

Abriu a porta com um chute. Cailian estava deitada na cama, comendo sementes de melão tranquilamente.

Ao ver Ning Xiaoxiao entrar furiosa, soltou uma risada fria. — A responsabilidade de cuidar daquele cavalo é sua. Ainda bem que ninguém se feriu quando ele enlouqueceu. Se alguém tivesse se machucado, nem dez cabeças suas bastariam para a execução!

Ning Xiaoxiao trancou a porta atrás de si. Foi até Cailian, tirou um grampo de cabelo e, com um movimento rápido, cravou-o quase por inteiro na coxa dela.

— AAAAAAH!

O grito de Cailian pôde ser ouvido por quase metade do Palácio Zhongcui. Ela começou a berrar por ajuda. — Socorro! Assassina! Me salvem! Ning Xiaoxiao enlouqueceu!

Logo ouviram-se batidas apressadas na porta:

— Xiaoxiao, acalme-se! Ela é uma serva que cresceu na família da nossa senhora! Se você a ofender, nossa senhora poderá castigá-la!

— É isso mesmo, Xiaoxiao. Abra a porta primeiro!

Mas Ning Xiaoxiao não tinha medo.

Quando percebeu que Cailian ia continuar gritando, acertou-lhe um tapa violento no rosto.

— Cale a boca! Se gritar de novo, arranco sua boca fora!

Seu rosto estava um tanto feroz ao dizer isso. Cailian só sabia intimidar os fracos; diante de alguém que reagia de verdade, perdia toda a coragem.

Não ousou mais gritar. Limitou-se a chorar.

— Você não tem medo de eu contar tudo à nossa senhora?

— Contar o quê? Que foi você quem enfiou um grampo na garupa do cavalo que acabou colocando o imperador em perigo, fazendo o animal disparar? Sabe quem aquele cavalo quase atropelou há pouco?

Cailian olhou para a roupa de Sanfu sobre os ombros de Ning Xiaoxiao e respondeu timidamente: — O... o eunuco Sanfu?

— Ele quase atropelou o imperador!

Cailian ficou visivelmente alarmada. — E-eu... Você é quem cuida daquele cavalo. O que isso tem a ver comigo? Que provas tem de que fui eu que o feri e o fiz enlouquecer?

— Quer provas? — Ning Xiaoxiao arrancou subitamente um grampo do penteado de Cailian. Na ponta ainda se podia ver um vestígio de sangue seco. — Vou entregá-lo agora ao imperador. O Tribunal de Revisão Judicial e o Ministério da Justiça certamente conseguirão as provas que tanto quer.

Ning Xiaoxiao virou-se para sair. Só então Cailian ficou realmente apavorada.

Jogou-se no chão, abraçou a perna de Ning Xiaoxiao e começou a implorar, chorando: — Xiaoxiao, não... Não faça isso! Por favor, me perdoe! Eu não fiz por querer! Prometo que nunca mais faço uma coisa dessas!

Na verdade, Ning Xiaoxiao não tinha a menor intenção de contar o ocorrido a Lu Linyuan.

Em primeiro lugar, naquele momento, ele provavelmente estava com tanta vontade de matá-la que nem iria querer escutar o que tivesse a dizer.

Em segundo, mesmo que lhe contasse, os métodos de investigação da Antiguidade eram precários. Um único grampo de cabelo não bastaria para condenar Cailian.

— Nós duas somos criadas. Nossa vida já é difícil, e eu não quero acabar com você. Mas você vem me provocando uma vez atrás da outra. Se eu deixar passar, tenho certeza de que vai ficar ainda pior!

Ning Xiaoxiao pegou papel e pincel e os colocou diante de Cailian. — Se quer que eu a perdoe, escreva uma declaração confessando que foi você quem fez isso hoje e deixe sua impressão digital. O documento ficará comigo. Se nunca mais vier me incomodar, prometo que não vou entregá-lo a ninguém.

Cailian ficou desconfiada, mas parecia não ter outra saída.

Por isso, escreveu uma confissão e marcou o papel com a impressão do dedo.

Ning Xiaoxiao pegou o documento e sorriu, erguendo o queixo na direção de Cailian. — Você não estava me perguntando que provas eu tinha?

Balançou a confissão diante dela e arqueou a sobrancelha. — Pronto, aqui está a prova. Agora mesmo vou entregá-la ao eunuco Sanfu. Quanto a você...

Sob o olhar horrorizado de Cailian, abriu lentamente os lábios e disse, com um sorriso frio: — É só esperar pela morte.

---

## Notas de tradução

- **‘Tire’:** a ordem curtíssima do imperador é ambígua, e Sanfu a interpreta como pedido para se despir por completo; preservar a situação equivocada é essencial para a piada.

- **Confissão escrita:** Cailian deixa a impressão digital no documento; Ning consegue assim uma prova que antes não possuía, apesar de ter prometido não entregá-la.

- **Roupa de Sanfu:** o imperador coloca sobre Ning a túnica que mandou Sanfu tirar, para esconder a mancha; não oferece a própria roupa.

# Capítulo 19 — O tirano obcecado por limpeza entra em desespero

Dez dias depois de a comitiva que transportava suprimentos de socorro partir para o sul, um dos guardas de ferro enviou a Lu Linyuan uma mensagem por pombo-correio:

<O comandante da infantaria, Wei Yan, agiu de maneira suspeita no Passo Nanyu: fugiu durante a noite com seus soldados de confiança, levando trinta mil taéis de prata destinados às vítimas. Conforme as ordens de Sua Majestade, nós o executamos no local. O vice-comandante Sun Zhichuan assumiu a escolta dos suprimentos até o sul. Continuaremos acompanhando a comitiva. Que Sua Majestade fique tranquilo.>

Era verdade, afinal. Aquela louca realmente conseguia prever o futuro.

Os dedos de Lu Linyuan se fecharam com força involuntária sobre a carta. Ele sentiu certa excitação.

Se ela sabia com antecedência dos desastres que atingiriam a corte, ele poderia evitar muitos problemas desnecessários.

Talvez até seu destino de vida ou morte pudesse ser alterado.

***

Palácio Zhongcui.

O céu estava limpo e o clima agradável. Gu Sijin tinha ido prestar seus respeitos à imperatriz-viúva acompanhando a Consorte Duan, levando Cailian para servi-las. Por isso, não havia quase nada para fazer no palácio — nem nenhuma desgraçada para lhe dar dor de cabeça.

Ning Xiaoxiao, Qiqi, Qiaqia, Bengbeng e Lala estavam sentados lado a lado no pátio, tomando sol.

Enquanto conversavam, ouviram Cao Ni Ma, amarrado ali perto, relinchar sem parar.

Qiqi perguntou: — Xiaoxiao, será que Cao Ni Ma está com fome?

— Mas eu já dei comida a ele hoje de manhã. — Ning Xiaoxiao se levantou, bateu a poeira das roupas, aproximou-se do cavalo e acariciou sua cabeça. — O que foi, hein?

Cao Ni Ma ficou olhando para ela com aqueles olhos grandes e úmidos. Piscou algumas vezes, e lágrimas brilhantes começaram a escorrer.

Qiqi e os demais se aproximaram para ver e começaram a falar todos ao mesmo tempo:

— Ai, por que está chorando? Dá até pena...

— Será que está passando mal?

— Acho que não. Os cavalos gostam de liberdade e de correr pelos campos. A gente prende ele aqui todo dia, com tão pouco espaço para se mexer. Talvez não aguente mais ficar confinado.

— É, faz sentido! Xiaoxiao, que tal levá-lo para passear?

*Passear com ele?*

*Eu tinha um golden retriever em casa e morria de preguiça de levá-lo para passear. Agora que vim parar dentro de um livro tenho que passear com cavalo também?*

Ning Xiaoxiao fez uma careta de desgosto. Mas Cao Ni Ma continuava relinchando, prolongando os sons como se choramingasse. Aquilo era de partir o coração. Ela acabou cedendo.

Desatou as rédeas presas ao poste e começou a conduzir Cao Ni Ma pelo pátio.

Ning Xiaoxiao crescera na cidade e nunca montara um cavalo.

Como Cao Ni Ma parecia dócil, pediu a Bengbeng que a ajudasse a subir e decidiu experimentar a diversão de cavalgar.

Qiqi e as outras a olharam com inveja. — Uau, Xiaoxiao! Você fica tão imponente montada nele!

A turma estava se divertindo quando Cailian voltou antes das senhoras.

Ao encontrar todos reunidos admirando Ning Xiaoxiao em cima do cavalo, Cailian ficou ainda mais irritada. — Só porque nossa senhora saiu, vocês estão aí matando serviço? Preferem ficar assistindo a esse circo em vez de cuidar das obrigações! Esperem até eu contar à senhora. Ela vai descontar todo o pagamento de vocês do mês que vem!

Sem vontade de discutir, Ning Xiaoxiao pediu que Bengbeng a ajudasse a descer.

Nesse instante, Cailian fingiu passar por eles. Mas já havia tirado um grampo do cabelo e, no momento em que Ning Xiaoxiao se preparava para desmontar, cravou-o com força na garupa do cavalo.

— Hiiiiii!

Assustado pela dor, Cao Ni Ma disparou com Ning Xiaoxiao nas costas, atravessou a saída do Palácio Zhongcui e saiu galopando pelo corredor do complexo imperial.

O vento assobiava em seus ouvidos. Os muros vermelhos e os telhados verdes dos dois lados passavam para trás como imagens de um projetor acelerado.

Ning Xiaoxiao enjoava até quando andava de carro. Agora, sacudida de um lado para o outro em cima do cavalo, estava tão tonta que não conseguia se concentrar.

Quando ficava nervosa demais, era incapaz de acessar o documento em sua mente.

Só pôde se agarrar com todas as forças ao pescoço do cavalo e gritar por socorro.

Naquele momento, Lu Linyuan caminhava na direção do Palácio Zhongcui. De longe, viu Cao Ni Ma correndo descontrolado pelo corredor, obrigando os servos do palácio a fugir para todos os lados.

— Que diabo é aquilo?

Sanfu respondeu: — Majestade, é Cao Ni Ma...

Lu Linyuan: — ...

Sanfu: — E parece que... Ning Xiaoxiao está montada nele...

Lu Linyuan: — !!! Que tipo de acrobacia essa mulher está tentando fazer agora?

Mal terminou de falar, ouviu Ning Xiaoxiao gritar por socorro em cima do cavalo.

Quando olhou com atenção, percebeu que o animal não tinha sela. Ning Xiaoxiao precisava apertar as pernas contra o dorso e se agarrar ao pescoço dele com as duas mãos para não cair.

Mas quanta força uma moça como ela poderia ter? Do jeito que o cavalo estava enlouquecido, não demoraria para ser arremessada longe.

Aquela louca era desajeitada. E se caísse de costas e batesse a nuca no chão? Não morreria ali mesmo?

Ele, Lu Linyuan, ainda nem tivera coragem de dar cabo dela. Como poderia permitir que um cavalo a machucasse?

Cao Ni Ma disparou em sua direção. Sanfu gritou: — O bicho enlouqueceu! Cuidado, Majestade!

Lu Linyuan não se esquivou. Quando o cavalo estava prestes a atingi-lo, inclinou-se ligeiramente, calculou o momento certo e, com um movimento ágil de lado, saltou para as costas dele.

Ning Xiaoxiao estava com tanto medo que nem ousava abrir os olhos. Só sentiu um peso aparecer atrás de si e percebeu um leve aroma amadeirado de incenso de agar, que o vento lhe trouxe aos poucos.

De repente, um par de mãos grandes envolveu sua cintura fina. Enquanto a firmava, o homem também segurou as mãos dela, que apertavam desesperadamente as rédeas.

— Solte.

Ao ouvir a voz firme e tranquila de Lu Linyuan atrás de si, ela soltou as rédeas e deixou o controle de Cao Ni Ma nas mãos dele.

Entre afrouxar e puxar as rédeas, o cavalo foi diminuindo a velocidade aos poucos.

Só então ele puxou as rédeas com força para trás, soltou um “ôôô” e fez Cao Ni Ma parar obedientemente.

Passado o perigo, Lu Linyuan olhou para Ning Xiaoxiao, que ainda tremia em seus braços. Quis repreendê-la, mas se conteve.

— Abra os olhos. Já passou.

Ning Xiaoxiao abriu os olhos só uma frestinha e viu que Cao Ni Ma tinha se acalmado por completo. Soltou um suspiro profundo, com a sensação de ter acabado de escapar da morte.

— Esta serva agradece a Sua Majestade por salvar sua vida!

— Se não sabe montar direito, não fique fazendo coisas perigosas dentro do palácio. Se está tão entediada que quer apresentar acrobacias, vá aprender a abrir espacate com sua senhora.

Ele a pegou pelo colarinho e a tirou de cima do cavalo como se fosse um pintinho, depositando-a no chão.

Quando se preparou para desmontar, apoiou a mão no dorso do cavalo e tocou em algo úmido e morno.

Olhou para a palma da mão e viu uma mancha vermelha intensa.

Como não havia ferimento nas costas do cavalo, voltou o olhar para Ning Xiaoxiao. — Você se machucou?

Ning Xiaoxiao ficou atônita. Machucada, não estava. O problema é que sua menstruação começara no dia anterior e, com tantos solavancos em cima do cavalo...

Ela apalpou discretamente a parte de trás da própria roupa...

*Merda! Vazou!*

【Desgraça! Eu sabia que, naquele dia em que arranquei os cabelos daquele imperador desgraçado, devia ter pedido uma embalagem de absorventes Sete Graus de Espaço!】

【Esses panos ordinários que se usam na Antiguidade saem do lugar com uma facilidade absurda. Vazou tudo pelos lados...】

Ning Xiaoxiao cobriu o traseiro com as mãos e se encostou ao pé do muro, abrindo um sorriso constrangido.

【Não! Nem que eu precise voltar andando colada ao muro o caminho inteiro, não vou deixar esse imperador desgraçado ver a mancha de sangue atrás de mim!】

【Ele é obcecado por limpeza! Se descobrir que o que está na mão dele é sangue da minha menstruação, vai me matar!!】

E assim, mantendo o rosto virado para Lu Linyuan e as costas grudadas no muro, avançava com dificuldade, um passinho de cada vez, sem parar de sorrir.

Quanto mais ela agia daquele jeito, mais curioso Lu Linyuan ficava.

Ele queria entender como aquela louca conseguira esconder a tia dela dentro das calças.

Então desmontou de um salto, avançou rapidamente, agarrou Ning Xiaoxiao pelo braço e a obrigou a virar de costas.

E foi assim que viu uma cena que jamais esqueceria...

---

## Notas de tradução

- **Cao Ni Ma (草泥馬):** nome do cavalo introduzido no capítulo 17; remete a um trocadilho com palavrão em chinês. Mantido como nome próprio.

- **‘Tia’ (大姨):** ao ouvir os pensamentos sobre a menstruação de Ning, o imperador interpreta literalmente a referência a uma ‘tia’ escondida na roupa, pois desconhece a gíria menstrual.

- **Sete Graus de Espaço (七度空間):** referência a uma marca de absorventes presente no texto chinês. O sangue no dorso do cavalo pertence à menstruação de Ning, não a ferimento no animal.

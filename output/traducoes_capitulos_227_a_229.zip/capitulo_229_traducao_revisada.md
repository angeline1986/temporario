Capítulo 229 — Sempre haverá alguém disposto a protegê-la, custe o que custar

A régua de castigo da Consorte Nobre era revestida de prata. Quando ela a brandiu, cortou o ar com um assobio.

Gu Sijin ergueu instintivamente o braço para se proteger. A régua atingiu seu antebraço, e o sangue imediatamente atravessou o tecido de seda verde-azulada de sua roupa de dormir.

Ela era teimosa. Mesmo diante daquela dor lancinante, apenas soltou um gemido abafado e se recusou a implorar perdão.

Percebendo que encontrara uma adversária obstinada, a Consorte Nobre ergueu novamente a régua e golpeou-a.

Qiqi e as outras não suportaram assistir. Correram e se colocaram à frente de Gu Sijin.

— Se Vossa Alteza precisa bater em alguém, bata nesta serva! Nossa senhora está doente. Por favor, não a maltrate mais!

A intervenção só deixou a Consorte Nobre ainda mais furiosa. — Estou punindo uma concubina culpada, e você, uma escrava imunda, ousa dizer que estou maltratando alguém?

— Ora, se quer tanto apanhar, farei sua vontade! Xianglan, mande levá-las daqui e aplicar cinquenta golpes de bastão em cada uma, para que sirvam de exemplo!

O Palácio Fengyi virou um caos. Na tempestade de neve, os gritos dilacerantes eram ainda mais aterrorizantes que o uivo do vento gelado.

Gu Sijin tentou proteger Qiqi e as outras, mas Xianglan a empurrou bruscamente ao chão.

Um grupo de pessoas avançou e começou a puxar e rasgar suas finas roupas de dormir.

O tecido foi arrancado pedaço por pedaço, deixando sua pele alva avermelhada pelo contato com a neve.

Lágrimas se acumulavam em seus olhos. Cruzou os braços firmemente sobre o peito para se cobrir e preservar o último vestígio de dignidade.

A Consorte Nobre trouxera quase metade dos criados do Palácio Yaohua para provocar confusão. Gu Sijin tinha apenas quatro ou cinco pessoas a seu serviço. Como poderiam enfrentá-los?

Qiqi e as outras foram arrastadas para o lado, onde os criados do Palácio Yaohua pegaram vassouras, lenha e outros objetos rígidos para espancá-las, sem lhes dar a menor chance de reagir.

A Consorte Nobre aproximou-se de Gu Sijin com um sorriso debochado. Vendo-a em farrapos e totalmente humilhada, ergueu uma sobrancelha.

— E então? Reconhece seu erro?

Os gritos das servas com quem convivia dia e noite se sucediam, cada vez mais altos, apertando dolorosamente o peito de Gu Sijin.

Ela rastejou até os pés da Consorte Nobre, agarrou a barra de suas vestes luxuosas e implorou com uma humildade que a reduzia a pó:

— Vossa Alteza, esta concubina reconhece seu erro... Pode me punir como quiser, mas, por favor, não mande bater mais nelas...

A Consorte Nobre soltou um bufo e livrou a roupa das mãos dela com um pontapé. — Você é mesmo uma peça rara! Numa hora dessas, ainda implora por essas escravas miseráveis? Acha que é uma bodisatva viva, dessas que ficam nos templos?

— Finge ser digna de pena para comprar a lealdade das pessoas. Para quem é todo esse teatro? Comigo isso não funciona!

Dito isso, desferiu uma sequência de golpes com a régua sobre o corpo e as costas de Gu Sijin.

Gu Sijin era de uma beleza extraordinária. Mesmo doente, depois de rolar pela neve e ficar naquele estado miserável, seu rosto sem maquiagem continuava deslumbrante.

A Consorte Nobre era extremamente ciumenta. Aquela beleza a enfureceu ainda mais. Assim que viu uma oportunidade, ergueu a régua para atingir o rosto dela.

De repente, uma figura vestida de preto saltou do outro lado do muro vermelho, aterrissou atrás da Consorte Nobre e segurou firmemente seu pulso.

A dor fez a Consorte Nobre soltar a régua manchada de sangue, que caiu sobre a neve.

— Que insolência! Quem ousa me impedir?

Gu Sijin ergueu a cabeça num sobressalto e deparou com aqueles olhos familiares que pareciam conter estrelas.

Era ele!

As pupilas de Chu Xingran tremiam violentamente. Ao ver Gu Sijin maltratada daquela forma, seu coração sangrou.

Ele largou o pulso da Consorte Nobre com um movimento brusco e a empurrou, fazendo-a cair na neve.

Então, ignorando os olhares chocados, tirou o casaco, agachou-se para cobrir os ombros de Gu Sijin e acolheu seu corpo trêmulo num abraço.

Depois de um instante de emoção, Gu Sijin voltou a si e ficou aterrorizada.

Não suportava imaginar as consequências de a Consorte Nobre testemunhar aquele gesto de Chu Xingran.

Começou a empurrá-lo com força, tentando escapar dos braços dele.

Mas ele parecia um rochedo. Por mais que se esforçasse, sua força se desfazia como água suave ao encontrar o peito firme dele.

Os criados do Palácio Yaohua correram para ajudar a Consorte Nobre a se levantar. Ela começou a berrar insultos: — Você enlouqueceu? Sou a Consorte Nobre nomeada pessoalmente pelo imperador! Como ousa colocar as mãos em mim?

Só depois de se firmar em pé percebeu Gu Sijin lutando dentro do abraço de Chu Xingran.

Chocada, apontou para os dois e gritou: — Vocês estão procurando a própria morte! Este é o recinto proibido do palácio imperial! Como um oficial de fora ousa abraçar uma concubina do imperador?

Gu Sijin cerrou os dentes e falou para Chu Xingran, baixinho e com urgência:

— Solte-me! Solte-me agora! Se você quer morrer, o problema é seu. Não me arraste junto!

Ela esperava que aquelas palavras cruéis o convencessem de que era uma mulher sem afeto nem lealdade.

Mas, quando uma mulher amada no passado reaparece, por melhor que esconda os sentimentos, o amor que não foi esquecido transborda por cada poro.

Ele não era um tolo insensível. Conseguia sentir aquilo.

Chu Xingran ajudou-a a ficar em pé, apertou o fecho do casaco que pusera sobre ela e então se virou, lançando um olhar feroz à Consorte Nobre.

Tinha uma vontade quase irresistível de torcer o pescoço dela com as próprias mãos.

Mas o pouco de razão que lhe restava o lembrou de que não podia fazer isso.

Se a Consorte Nobre morresse por suas mãos, isso não ajudaria em nada o grande plano de Lu Linyuan para destruir Tong Guowei e ainda implicaria toda a família de Gu Sijin.

Por isso, mudou o rumo da conversa e declarou com firmeza:

— Antes de partir, Sua Majestade ordenou expressamente a este humilde ministro que garantisse a segurança de cada senhora do palácio. Eu estava inspecionando a região do Palácio Fengyi quando ouvi gritos incessantes. Ao perceber que Vossa Alteza estava prestes a matar de pancadas a Nobre Dama Gu, não pude simplesmente ignorar.

A Consorte Nobre, humilhada e furiosa, começou a espernear: — Tenho autoridade para auxiliar na administração dos seis palácios! Disciplinar as concubinas é minha obrigação. Desde quando cabe a você se intrometer? Além disso, você é um oficial externo. Quem lhe deu permissão para invadir os aposentos das consortes?

Chu Xingran respondeu: — Por ordem verbal de Sua Majestade, enquanto eu estiver organizando a segurança do palácio, poderei entrar em qualquer residência, desde que avise previamente à respectiva senhora.

A Consorte Nobre cuspiu de desprezo. — Uma suposta ordem verbal não tem prova nenhuma! Hoje, você invadiu uma área proibida e ainda me agrediu. Cometeu um crime capital! As regras do palácio são rígidas. Exigirei que seja severamente punido!

Chu Xingran e a Consorte Nobre já tinham antigos ressentimentos.

Quando Tong Guowei foi lutar contra os piratas japoneses, Chu Xingran o fizera passar por uma situação humilhante de propósito.

Os piratas ocupavam uma ilha cercada de mar, fácil de defender e difícil de atacar.

Chu Xingran sabia muito bem que a entrada oriental da ilha era guardada por arqueiros, mas espalhou para Tong Guowei que o leste era o ponto mais fácil de penetrar.

Só quando Tong Guowei conduziu suas tropas para lá percebeu que caíra numa armadilha montada por Chu Xingran.

Os piratas sobreviventes, escondidos nas alturas da ilha, dispararam flechas contra os navios de Tong Guowei. As pontas estavam cobertas por um veneno que matava assim que entrava em contato com o sangue. Quem fosse atingido morreria sem remédio.

Tong Guowei não estava preparado e quase foi morto por uma flecha naquela batalha.

Mais tarde, ao retornar ao palácio, Tong Guowei relatou o episódio a Lu Linyuan. Chu Xingran explicou que também fora enganado por Meichuan Kuchazi e não sabia da verdade.

Por isso, Lu Linyuan não investigara mais o assunto.

Agora que a Consorte Nobre encontrara uma fraqueza de Chu Xingran, pretendia aproveitar para eliminá-lo e vingar a emboscada sofrida pelo pai.

Enquanto discutiam, Xianglan discretamente mandou alguém buscar a Guarda Imperial.

Naquele momento, os soldados já haviam invadido o Palácio Fengyi e cercado o local por dentro e por fora.

A Guarda Imperial respondia diretamente a Lu Linyuan. Entre as mulheres do harém, somente quem detivesse autoridade para auxiliar na administração dos seis palácios podia mobilizá-la.

A Consorte Nobre ergueu a mão e ordenou:

— Prendam imediatamente o comandante dos Nove Portões e levem-no para a prisão imperial!

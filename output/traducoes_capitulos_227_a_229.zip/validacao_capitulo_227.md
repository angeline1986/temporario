# Validação do capítulo 227

- Origem: DOCX chinês tradicional `novel_capitulos_212_a_270(20261105-204934).docx`.
- Limites: índices [1083, 1153) de parágrafos do DOCX, base zero.
- Unidades não vazias (incluindo título e apartes): **67**.
- Cotejo 1:1: **67 registros**, com índices reais, distintos, sem original/tradução vazios.
- Markdown: **67 unidades**, mesmas traduções na ordem dos parágrafos de origem.

## Decisões editoriais

Manter a cena da ameaça às famílias distinta da execução efetiva: o imperador ordena a ameaça para identificar o homem sem familiares. O envenenamento ocorre antes do retrocesso, mas é impedido depois da intervenção de Ning. O decreto é deliberadamente enganoso, uma manobra política. A expressão informal da autora sobre espacate e Ano-Novo foi adaptada pelo efeito cômico.

## Limitações

A revisão feita é editorial e de cobertura estrutural; não representa uma segunda auditoria semântica independente integral. Ambiguidades de tom e de nomes podem exigir revisão posterior.

Capítulo 228 — Gu Sijin é castigada pela Consorte Nobre

Num piscar de olhos, fazia meio mês que Ning Xiaoxiao havia deixado o palácio.

Com o Ano-Novo se aproximando, todos no palácio estavam ocupados com os preparativos para as festividades.

Todos os anos, o Departamento de Assuntos Internos distribuía antecipadamente os presentes festivos, de acordo com a posição de cada concubina.

Havia presentes tanto para as senhoras quanto para os criados que as serviam.

Mas, naquele ano, apenas Gu Sijin ficara sem receber os presentes de Ano-Novo.

Com Ning Xiaoxiao longe, a Consorte Nobre passou a descontar em Gu Sijin toda a raiva que guardava daquela.

Afinal, não fora justamente porque a falsa acusação de adultério contra Gu Sijin viera à tona que Lu Linyuan a rebaixara à posição de concubina, retirara seu título honorífico e a confinara?

Agora, sem aquela «peste» de Ning Xiaoxiao para protegê-la, podia acertar com Gu Sijin todas as contas antigas e novas.

Xiangling foi ao Departamento de Assuntos Internos, descobriu que a Consorte Nobre havia retido os presentes de Gu Sijin e informou à imperatriz.

— Majestade, a Consorte Nobre reteve por conta própria os presentes de Ano-Novo da Nobre Dama Gu. Isso contraria as regras... A senhora acha que deveríamos...

— Deveríamos o quê? — a imperatriz sorriu. — A Consorte Nobre não adora usurpar as atribuições alheias? Tenho alegado doença nestes últimos dias, e ela mandou que todas fossem prestar-lhe reverência diariamente no Palácio Yaohua. Por acaso eu lhe dei atenção? Foi ela quem não entregou os presentes a Gu Sijin. O que tenho a ver com isso?

A imperatriz não tinha a menor vontade de interferir. De qualquer maneira, Gu Sijin também estava longe de ser uma mulher inocente aos seus olhos.

*

Qiqi voltou do Departamento de Assuntos Internos depois de ser rejeitada e contou a Gu Sijin, magoada:

— Minha senhora... A Consorte Nobre reteve nossos presentes de Ano-Novo.

Gu Sijin já previra que seria tratada daquela forma. Não se irritou e ainda tentou tranquilizar Qiqi:

— Não fique zangada. Cof, cof... Mesmo que os presentes do palácio não cheguem durante o Ano-Novo, eu mesma pagarei as gratificações de vocês... Cof, cof...

Qiqi aproximou-se para acariciar as costas de Gu Sijin, que não parava de tossir. — Minha senhora, não foi isso que quis dizer...

Gu Sijin sorriu e segurou a mão dela. — Eu sei. Cof, cof... Mas vocês trabalham arduamente aqui o ano inteiro. Se, ao chegar o fim do ano, ficarem sem recompensa por estarem a meu serviço, vou sentir que falhei com vocês.

Qiqi serviu uma xícara de água quente, abanou-a para diminuir um pouco a temperatura e só então a ofereceu a Gu Sijin.

— Minha senhora, beba um pouco de água morna para aliviar a garganta.

— Desde que a Concubina Hua deixou o palácio, a imperatriz suspendeu as saudações obrigatórias das seis alas do harém por estar doente. Mas a Consorte Nobre passou a exigir que todas compareçam todos os dias para saudá-la.

— A senhora é Nobre Dama. Quando presta saudações à imperatriz, tem direito a ficar sentada no interior do salão. Mas a Consorte Nobre insiste em deixá-la do lado de fora, em pé, como se fosse uma mera Dama ou Atendente.

— E agora que o Ano-Novo se aproxima, a neve e o vento estão cada vez piores. A senhora pegou um resfriado, nós fomos tantas vezes pedir um médico ao Departamento Médico Imperial, mas a Consorte Nobre não deixa ninguém vir tratá-la...

Qiqi se sentia tão injustiçada em nome de Gu Sijin que quase começou a chorar enquanto falava.

Ela tirou de dentro das roupas um grande embrulho de ervas e mostrou-o à senhora: — Felizmente, hoje, depois das saudações, consegui estes remédios. Pedi a um aprendiz de medicina que conheço para examiná-los, e ele confirmou que são excelentes para tratar resfriados.

Gu Sijin perguntou, intrigada: — A Consorte Nobre proibiu o Departamento Médico Imperial de me tratar. De onde vieram essas ervas?

Qiqi abaixou a cabeça, corando. — Nestes dias em que saímos para prestar saudações, o senhor comandante, que está encarregado da segurança do palácio, nos acompanhou diariamente.

— Hoje... quando saí do Departamento de Assuntos Internos, ele me entregou estas ervas. Disse... disse que me viu usando roupas finas e ficou preocupado que eu pegasse um resfriado. Por isso, mandou que eu as usasse.

Seu rosto ficava mais vermelho e sua voz mais tímida a cada palavra. — Mas estou acostumada a servir e tenho uma saúde resistente. Não fico doente tão facilmente. Já que recebi o remédio, é muito melhor que a senhora o use.

Qiqi entendera tudo errado: acreditava que Chu Xingran ficava de prontidão todos os dias para acompanhar as idas e vindas das criadas e da senhora do Palácio Fengyi porque se interessara por ela.

Antes de deixar o palácio, Lu Linyuan autorizara Chu Xingran a morar temporariamente na ilha do lago imperial, para reforçar as medidas de segurança.

Chu Xingran, porém, não se dedicava quase nada às tarefas oficiais. Aproveitava toda brecha para tentar ficar a sós com Gu Sijin.

Havia tantos olhos vigiando Gu Sijin no harém que bastaria um deslize para lançar sua família inteira, e também Chu Xingran, numa desgraça sem volta.

Chu Xingran lutara tanto para chegar ao prestígio que tinha hoje. Gu Sijin não suportaria arrastá-lo para a ruína.

Por isso, tratava-o deliberadamente com frieza. Fora as saudações obrigatórias, quase nunca saía de seus aposentos.

Mesmo assim, todos os dias, na quarta vigília da noite, Chu Xingran já esperava do lado de fora do Palácio Fengyi apenas para acompanhá-la por parte do caminho.

Caminhavam um à frente e o outro atrás, sem trocar uma palavra, como se a simples visão um do outro já satisfizesse os desejos mais profundos de seus corações.

Naturalmente, o remédio que ele entregara a Qiqi se destinava a Gu Sijin.

Gu Sijin compreendia: ele não conseguia esquecê-la, assim como ela não conseguia esquecê-lo.

Mas, quando duas pessoas perdem a oportunidade de ficar juntas, perdem. Aferrar-se a algo condenado a não dar certo só faria as feridas se aprofundarem.

Depois de tomar a decocção preparada por Qiqi, Gu Sijin nem sequer percebeu o amargor extremo daquele medicamento.

Assim que terminou, disse estar cansada e foi dormir mais cedo.

Bons remédios contra o resfriado costumavam expulsar o frio acumulado no corpo. Em outras palavras, os sintomas poderiam piorar por um ou dois dias, mas a doença passaria mais depressa.

Na manhã seguinte, Gu Sijin acordou com o corpo dolorido, sem forças e um pouco febril.

Ao ver seu rosto pálido e a testa coberta de suor frio, Qiqi pediu que descansasse e foi ao Palácio Zhaochun solicitar dispensa das saudações em nome da senhora.

Mas, ao saber que Gu Sijin não viria, a Consorte Nobre explodiu: — Ontem, retive seus presentes de Ano-Novo, e hoje ela está tão doente que não pode vir? Está fazendo isso para me afrontar?

— Parece que conviveu tempo demais com aquela criada desprezível da família Ning e aprendeu todos os seus hábitos vulgares! Sou responsável por auxiliar na administração dos seis palácios e não permitirei que esses maus costumes se espalhem pelo harém!

Furiosa, levantou-se e partiu com um grande séquito rumo ao Palácio Fengyi, disposta a exigir satisfações.

Quando chegou, Gu Sijin ainda dormia. Todas as suas articulações doíam como se tivessem passado a noite mergulhadas em vinagre.

Mas, ao ouvir o tumulto no pátio e perceber que Qiqi e Lala pareciam estar sendo espancadas pelos criados da Consorte Nobre, forçou o corpo debilitado a se levantar e saiu às pressas, vestindo roupas finas.

Naquele dia, a neve caía com força incomum.

A Consorte Nobre, vestida de vermelho, estava parada na neve. Uma fina camada branca já se acumulara sobre sua capa curta.

Ela lançou a Gu Sijin um olhar enviesado. — Pensei que você tivesse morrido. Mas vejo que consegue andar e ficar em pé. Então não veio me prestar saudações hoje porque está ressentida de eu ter retido seus presentes?

Gu Sijin dobrou os joelhos numa reverência. — Esta concubina não ousaria.

— Não ousaria? Existe alguma coisa neste mundo que você, Gu Sijin, não ouse fazer? — A voz da Consorte Nobre ficou subitamente ríspida. — Ajoelhe-se!

Sem ousar desobedecer, Gu Sijin caiu de joelhos sobre a neve.

Com uma expressão arrogante, a Consorte Nobre caminhou até ela, rebolando, e lhe deu um tapa no rosto.

Um fio de sangue surgiu no canto dos lábios de Gu Sijin. Quando ergueu os olhos, havia uma ferocidade nova em seu olhar.

— Ainda tem a ousadia de me encarar? — A Consorte Nobre estendeu a mão para trás, e Xianglan lhe entregou uma régua de castigo.

— Você aprendeu todos os maus hábitos da Concubina Hua. Uma moça de família respeitável resolveu se misturar com uma vulgar que veio da criadagem e das escravas do palácio.

— Hoje vou ensinar a você o que significa respeitar as regras!

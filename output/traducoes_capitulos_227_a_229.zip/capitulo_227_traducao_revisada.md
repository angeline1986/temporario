Capítulo 227 — Continuarei caminhando ao seu lado

(Deixem-me desenvolver a trama por dois dias, tá? Aos queridos que levaram um susto ontem: eu pulo aqui mesmo, faço um espacate no ar, emendo uma reverência de joelhos com giro de 360 graus e ainda aproveito para desejar feliz Ano-Novo adiantado~)

A propriedade das fontes termais não era muito grande. Ao todo, havia pouco mais de uma dezena de criados do palácio servindo ali durante o ano inteiro.

A uma ordem de Lu Linyuan, todos foram detidos, e um dos quartos foi separado para os interrogatórios.

Quem ficou responsável por interrogá-los foi justamente Ren Duanli.

O incidente de pouco antes fora perigosíssimo. Se Ning Xiaoxiao e Lu Linyuan não tivessem percebido o perigo a tempo, Lu Yiqiu muito provavelmente teria perdido a vida.

Por isso, Ren Duanli sentia uma hostilidade ainda mais feroz contra quem agira nos bastidores.

Ele comandava tropas em campanhas havia anos. Metade dos territórios do reino de Qi fora conquistada por ele.

Alguém que sobrevivera aos campos de batalha, verdadeiros infernos, naturalmente não tinha métodos delicados.

Como a segurança do imperador estava em jogo, preferia condenar dez mil inocentes a deixar escapar um único culpado.

Tratou todos os dezesseis criados da mesma maneira e submeteu-os aos castigos mais severos do palácio.

Mas confessar significava morrer. Eles mantinham a boca fechada: não se sabia quantas tábuas de madeira grossas já haviam se partido de tanto golpeá-los, e nem assim alguém assumira a responsabilidade.

Mais tarde, Ning Xiaoxiao acompanhou Lu Linyuan até lá para que ele os interrogasse pessoalmente. Ainda à porta, ouviu os gritos terríveis dos criados. Temendo que a cena sangrenta a assustasse, Lu pediu que esperasse do lado de fora.

Assim que entrou, um cheiro forte de sangue lhe atingiu as narinas.

Observou os servos cobertos de ferimentos e perguntou, sem demonstrar emoção: — Conseguiram alguma coisa?

Ren Duanli juntou as mãos em saudação. — Respondendo a Vossa Majestade: esses servos não abrem a boca. Ainda não descobrimos quem os mandou agir.

Lu Linyuan ficou em silêncio por um instante, fez um gesto para os guardas interromperem a punição e então disse, em voz grave:

— Não tenho paciência para perder tempo com vocês. Quem comete um crime punível com a execução de nove gerações da família certamente não esperava escapar com vida. Mas não vou matá-los.

— Já mandei trazer seus parentes à propriedade. Enquanto não confessarem, ordenarei que sejam cortados em mil pedaços diante dos seus olhos.

Ao ouvi-lo, os criados começaram a chorar e gritar que eram inocentes.

Os olhos de Lu Linyuan se tornaram sombrios. Sua voz ficou ainda mais dura: — Não tenho tempo para ficar aqui brincando com vocês.

Ele bateu palmas três vezes. A porta se abriu de novo, e Sanfu entrou com guardas que conduziam um grupo de pessoas comuns.

Entre elas havia velhos de mais de setenta anos, mulheres grávidas e bebês de colo. Ao verem que seus parentes tinham sido realmente trazidos, os criados choraram até perder a voz, implorando para que Lu Linyuan os poupasse.

Lu Linyuan não deu atenção aos pedidos. Ergueu ligeiramente a mão, sinalizando aos guardas que começassem a torturar as famílias.

Pequenas lâminas foram encostadas à pele dos parentes. Quando estavam prestes a penetrá-la, Lu Linyuan apontou de repente para o segundo homem da esquerda, um sujeito magro, e ordenou:

— Prendam aquele homem.

Antes que alguém compreendesse o que acontecia, os guardas já o haviam derrubado e imobilizado no chão.

Lu Linyuan avançou dois passos e pisou na cabeça dele. — Dos dezesseis, você é o único sem parentes. Pode agir sem se preocupar com ninguém.

Ele não mandara trazer as famílias para massacrar inocentes, mas para testar se sua suspeita estava correta.

Afinal, tentar matar o imperador era um crime que acarretava a execução de nove gerações da família. Alguém com parentes dificilmente aceitaria tal tarefa, por mais dinheiro que lhe oferecessem.

O sujeito magro lançou um olhar feroz para Lu Linyuan e mordeu com força o veneno escondido entre os dentes. Sangue negro jorrou de sua boca e nariz; morreu imediatamente, levando consigo qualquer possibilidade de obter seu depoimento.

Do lado de fora, Ning Xiaoxiao, que espiava a sala por uma fresta da janela, pensou que, nas horas decisivas, era ela quem precisava salvar a situação.

Com a prática de sempre, retrocedeu a trama em três minutos, pausou-a e entrou na sala.

Abriu à força a boca do homem magro, tirou uma presilha de prata dos cabelos e usou-a para remover o veneno. Terminou o serviço, saiu tranquilamente e fechou a porta atrás de si.

A trama voltou a correr:

— Prendam aquele homem.

Com a cabeça esmagada sob o pé de Lu Linyuan, o sujeito tentou morder o veneno para se matar. Mas, depois de mastigar em vão, percebeu:

Que porra é essa? Cadê meu veneno?!

Com o autor do atentado capturado, Lu Linyuan mandou pendurá-lo, enfiar agulhas de prata nas pontas dos dedos, esmagá-los com instrumentos de tortura e jogar água salgada nas feridas. O objetivo era simples: não deixá-lo morrer, mas fazê-lo sentir, a cada instante, uma dor pior que a morte.

Quanto aos outros criados, Lu Linyuan mandou os médicos imperiais que o acompanhavam tratar seus ferimentos com os melhores unguentos e concedeu a cada um cem taéis de prata, permitindo que voltassem antecipadamente para casa e se reunissem às famílias.

O homem magro não suportou a tortura. Em meia hora, desmaiou quatro vezes, despertando sempre que água salgada extremamente concentrada era derramada sobre os machucados.

Depois de ficar praticamente irreconhecível, enfim abriu a boca.

— Foi... foi o senhor Tong...

A resposta não surpreendeu Lu Linyuan. Ele só queria ouvir uma confirmação clara da boca do criminoso.

Quando o imperador saiu da sala, Ning Xiaoxiao viu sua expressão carregada e o acompanhou em silêncio.

Apesar de absorto nas preocupações, ele não se esqueceu de segurar a mão dela.

De volta ao Pavilhão de Estudos Bitong, Lu Linyuan redigiu um decreto imperial e o entregou a Sanfu: — Diga a Ren Duanli que corte a cabeça daquele criminoso e a coloque numa caixa de brocado. Envie-a, junto com meu decreto, ainda esta noite, à residência dos Tong, na capital. Certifique-se de que seja entregue pessoalmente a Tong Guowei.

Enquanto ele escrevia, Ning Xiaoxiao permanecera ao lado, cuidando da tinta e do pincel.

Ela vira claramente o conteúdo do decreto:

«Um criado da propriedade das fontes termais foi instigado por terceiros a caluniar e incriminar meu estimado ministro Tong, tentando atribuir-lhe uma tentativa de regicídio. Com meu discernimento, percebi a verdade, mandei executar o culpado no local e restituí sua inocência.»

Ning Xiaoxiao sabia o que Lu Linyuan pretendia: alimentar a arrogância de Tong Guowei, fazendo-o acreditar que o imperador estava disposto a encobrir até mesmo uma tentativa de assassinato contra si próprio.

Assim, Tong Guowei agiria de maneira cada vez mais desenfreada.

Quando Sanfu se retirou, Lu Linyuan chamou Ning Xiaoxiao com um movimento dos dedos e a puxou para seus braços.

Apoiou o queixo no ombro perfumado dela, inclinou a cabeça e deixou os cabelos roçarem a pele delicada de seu pescoço, fazendo cócegas.

Aquele lobo grandalhão estava cansado e parecia procurar carinho.

— O que você acha do que aconteceu agora?

— A palavra isolada de um criado, sem provas, não bastaria. Mesmo que o caso viesse à tona, Tong Guowei poderia afirmar que alguém mandou o sujeito difamar um ministro importante. Vossa Majestade pensou muito à frente: o decreto representa confiança, e a cabeça, um aviso. Juntos, deixam Tong Guowei encurralado, sem uma saída fácil.

Ning Xiaoxiao fez toda uma análise séria. Lu Linyuan, porém, inclinou-se e depositou um leve beijo sugado em seu pescoço.

— Não foi isso que perguntei.

Ele a abraçou ainda mais forte. — Você tem medo de estar ao meu lado?

Ning Xiaoxiao afagou os cabelos no alto da cabeça dele e sorriu, travessa: — Medo do quê? De Vossa Majestade acordar no meio da noite e fazer um espacate na minha frente?

— Pfft!

Lu Linyuan soltou uma risada, coisa rara. Em seguida, ouviu os pensamentos que Ning Xiaoxiao não pronunciara:

【Claro que não tenho medo. Além de não ter medo, vou continuar caminhando ao seu lado e ajudar você a superar todas as dificuldades.】

【Ninguém tem o direito de maltratar o meu homem. Ninguém além de mim!】

Lu Linyuan não compreendia como uma jovem que, em sua percepção, apenas conseguia prever o futuro poderia ajudá-lo a superar essas tais dificuldades.

Mas bastaram aqueles pensamentos para aquecer por completo seu coração, solitário havia tanto tempo.

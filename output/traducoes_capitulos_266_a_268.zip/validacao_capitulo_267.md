# Validação — capítulo 267

## Fonte e limites

- Documento: `novel_capitulos_212_a_270(20261105-204934).docx` (chinês tradicional).
- Índices reais de parágrafo (base zero): 3909–3970, com último parágrafo não vazio 3969.
- Unidades não vazias, incluindo título, símbolos ou nota autoral: **59**.
- Correspondências presentes: **59**.
- Índices duplicados ou ausentes: **0**.
- Campos vazios na tradução: **0**.

## Decisões editoriais

A conversa dos eunucos é uma encenação articulada por Gu Sijin, conforme revelado ao final; a culpa de Tong não foi estabelecida como fato. A nota pós-escrita da autora foi mantida. Dali Si foi traduzido como Tribunal de Revisão Judicial.

## Limites de auditoria

O CSV foi verificado quanto à estrutura 1:1 com os índices de parágrafo do DOCX. O cotejo não constitui segunda auditoria semântica independente integral.

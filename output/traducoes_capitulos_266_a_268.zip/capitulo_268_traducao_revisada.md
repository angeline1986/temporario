# Capítulo 268 — Xiaoxiao toma a iniciativa

Enquanto Gu Sijin se dedicava a seus planos, Ning Xiaoxiao e Lu Linyuan estavam ocupados em suas próprias “batalhas noturnas”.

Ning Xiaoxiao pegou um tabuleiro de go e insistiu que Lu Linyuan jogasse gomoku com ela.

Na dinastia Qi, nem sequer existia esse jogo de cinco pedras em linha. Era a primeira vez que Lu Linyuan descobria que se podia jogar “go” daquela maneira.

No início, aproveitando-se de que ele não conhecia as regras, Ning Xiaoxiao o derrotou sem misericórdia.

Ainda declarou, cheia de confiança, que quem perdesse dez partidas teria que cumprir um pedido do vencedor.

Lu Linyuan se animou na mesma hora. Aprendia depressa, e o gomoku tinha regras simples e poucas variantes. Logo, reverteu a situação e passou a encurralar Ning Xiaoxiao jogada após jogada, sem lhe dar a menor chance de reação.

Depois de perder nove partidas seguidas, Ning Xiaoxiao já estava suando em bicas.

Inflou as bochechas de indignação, arregaçou as mangas e assumiu a postura de quem jurava lutar com Lu Linyuan até a morte.

Lu Linyuan contemplou a gatinha do outro lado do tabuleiro, mostrando as presinhas e tentando parecer ameaçadora. Seu sorriso se aprofundou.

Bastava colocar mais uma peça para formar uma linha de cinco e vencer.

Aquela bobinha da Ning Xiaoxiao encarava fixamente a casa vazia do tabuleiro, pensando consigo mesma:

【Ele não está vendo, não está vendo, não está vendo!】

Hehe. Eu não sou cego.

Mas, se tivesse de escolher entre ganhar a partida e deixar a esposa feliz, então...

Talvez não fosse tão ruim fingir-se de cego.

Os dedos de Lu Linyuan, segurando uma peça preta, hesitaram. Diante do olhar ansioso de Ning Xiaoxiao, ele a colocou descaradamente em outra posição.

— Hahaha! Perdeu, viu só?!

Ning Xiaoxiao abriu um sorriso radiante e pousou a peça branca que já estava pronta para jogar.

Cinco em linha. Aquela partida era dela.

Com a arrogância típica de quem acaba de levar vantagem, provocou e zombou de Lu Linyuan à vontade.

Ele a tratou com a paciência de quem agrada uma criança, sorrindo calorosamente: — Está bem, está bem. Minha Xiaoxiao é a melhor de todas.

Depois disso, ele continuou “jogando mal”, e Ning Xiaoxiao venceu sete partidas seguidas, ganhando a disputa.

Lu Linyuan abriu os braços, desistindo de qualquer resistência: — Pronto. Agora pode me fazer seu pedido.

Enquanto falava, deitou-se todo esparramado no assento aquecido:

— Pode fazer o que quiser comigo.

— Admito que conseguiu o que queria.

— Eu me rendo.

Ning Xiaoxiao fingiu puxar o cinto de brocado de Sichuan que usava na cintura, enrolou-o na mão, esticou-o e sorriu maliciosamente:

— Nesse caso, é melhor aguentar firme!

Ela esticou o cinto até fazê-lo estalar. Lu Linyuan, entrando demais na brincadeira, franziu a testa, fechou os olhos e murmurou, simulando medo:

— Vá devagar... Estou com medo...

Estava apenas brincando com a esposa, mas não esperava sentir, no instante seguinte, um toque quente nos lábios.

Abriu os olhos surpreso e descobriu Xiaoxiao inclinada sobre ele, dando-lhe um beijo leve. Ela mantinha os grandes olhos úmidos abertos e o observava com um sorriso travesso.

— Acha que eu não percebi que você perdeu de propósito?

O corpo leve e macio da jovem repousava sobre o dele, sem causar o menor desconforto.

Mas havia uma questão de orgulho masculino: ele jamais permitiria que a esposa invertesse as posições e assumisse o controle!

Por isso, agarrou de repente os pulsos de Ning Xiaoxiao e a virou, trocando de posição com ela.

Um sorriso irresistível apareceu em seus lábios, e ele ergueu uma sobrancelha:

— Há coisas em que posso deixar você vencer. Em outras, não.

— Como no que vamos fazer agora.

E a beijou ardentemente com os lábios ligeiramente quentes.

❤

Sempre que estava a sós com Ning Xiaoxiao, Lu Linyuan oscilava à beira da loucura de tanto se conter.

Nessas horas, só uma ideia lhe vinha à cabeça:

Dar logo um belo tapa na imperatriz e fazê-la desocupar o posto para alguém mais merecedor.

Caso contrário, com aquela pequena sedutora circulando ao seu redor todos os dias, cedo ou tarde ficaria tão reprimido que perderia até as habilidades marciais...

Felizmente, a estratégia que armara na corte começava a cercar seus adversários por todos os lados; em breve, ministros corruptos e rebeldes seriam arrancados pela raiz.

Garantir que o povo vivesse em paz e o país prosperasse era seu dever como imperador.

Um dever maior que o céu, maior que a própria vida, mas incapaz de competir com um único sorriso de Xiaoxiao.

Quanto mais a amava, mais culpado se sentia por não conseguir lhe conceder logo a posição que desejava para ela.

Embora Xiaoxiao repetisse que não dava importância a essas coisas.

Oferecer-lhe tudo aquilo era seu dever como marido — algo que deveria ter colocado nas mãos dela desde o início do relacionamento.

Como estava em dívida com Xiaoxiao, só poderia compensá-la com uma vida inteira de amor, proteção e cuidados.

E, naturalmente, seria um prazer fazer isso.

Naquele dia, quando voltou da audiência matinal, a preguiçosa Ning Xiaoxiao ainda dormia.

Lu Linyuan se sentou à beira da cama e a contemplou em silêncio. Cada detalhe daquele rosto parecia feito sob medida para tocar seu coração.

Dava vontade de beijá-la, de brincar com ela,

e de vê-la, sob a luz difusa da lua, com uma expressão de prazer e satisfação no rosto.

— A-Yuan, não pode...

Ning Xiaoxiao estalou os lábios e murmurou corando, em meio ao sono:

— A-Yuan, você realmente não pode comer isso...

???

Era mesmo o tipo de coisa que ela podia dizer em voz alta?

Lu Linyuan ficou profundamente impressionado e abriu um sorriso satisfeito:

Como esperado, até sonhando ela pensava no meu corpo.

Inclinou-se para acordar Ning Xiaoxiao daquele sonho de teor duvidoso com um beijo.

Mas, assim que chegou perto, ouviu o restante da frase:

— Isso é água suja de restos de comida! A-Yuan, pare de comer! Você está me assustando...

— ...

Lu Linyuan franziu as sobrancelhas e apertou com força uma das bochechas dela, fazendo-a saltar como um bolinho de carne.

— Ai, ai, ai! Dói, dói!

Ning Xiaoxiao acordou num sobressalto e se sentou parcialmente na cama. Seu olhar encontrou o de Lu Linyuan, que tinha uma expressão sombria.

— Por que está me beliscando?

— Com o que você estava sonhando? — perguntou ele, secamente.

Ning Xiaoxiao sabia desde criança que falava dormindo. No sonho, por alguma razão absurda, vira Lu Linyuan abraçado a um balde de restos líquidos de comida e devorando seu conteúdo. A cena a deixara enojada...

【Droga! Será que falei tudo isso dormindo e ele ouviu?】

Ela improvisou imediatamente um sorriso: — Ah, sonhei que nós dois saímos para comer coisas deliciosas~

E ainda estalou os lábios, fingindo saborear a lembrança.

Lu Linyuan lançou-lhe um olhar de lado: — Desde que você tenha achado gostoso. Todo o palácio sabe o quanto a mimo. É claro que deixarei todas as delícias para você. Coma bastante, só tome cuidado para não engasgar!

Ning Xiaoxiao: — ...

Mais tarde, Qiqi trouxe uma bacia com água para ajudá-la a se lavar. Lu Linyuan mandou que deixasse a bacia de lado, pegou uma toalhinha, molhou-a e fez sinal para Ning Xiaoxiao:

— Venha aqui. Ning Xiaoxiao se aninhou obedientemente em seus braços e deixou que ele lhe limpasse o rosto como se estivesse dando banho numa gatinha.

— Amanhã é o décimo quinto dia do primeiro mês lunar, o Festival das Lanternas. Na audiência de hoje, Tong Guowei disse que sua esposa principal está gravemente doente e talvez nem sobreviva ao ano. Pediu autorização para que a filha fosse para casa acompanhá-la.

Ning Xiaoxiao bocejou, preguiçosamente: — Concubinas acima do posto de Concubina podem pedir licença para visitar a família por dois ou três dias em casos de doença grave. Mas, A-Yuan, você acredita mesmo que, com dezesseis médicos extraordinários em sua residência, Tong Guowei deixaria a própria esposa adoecer tão gravemente?

# Validação — capítulo 268

## Fonte e limites

- Documento: `novel_capitulos_212_a_270(20261105-204934).docx` (chinês tradicional).
- Índices reais de parágrafo (base zero): 3971–4058, com último parágrafo não vazio 4057.
- Unidades não vazias, incluindo título, símbolos ou nota autoral: **85**.
- Correspondências presentes: **85**.
- Índices duplicados ou ausentes: **0**.
- Campos vazios na tradução: **0**.

## Decisões editoriais

Gomoku foi mantido como nome de jogo de cinco peças em linha sobre um tabuleiro de go. O símbolo de coração foi preservado. O comentário de Lu sobre a imperatriz é um pensamento, não uma ação concluída. A doença da esposa de Tong Guowei é uma alegação, e Ning a questiona.

## Limites de auditoria

O CSV foi verificado quanto à estrutura 1:1 com os índices de parágrafo do DOCX. O cotejo não constitui segunda auditoria semântica independente integral.

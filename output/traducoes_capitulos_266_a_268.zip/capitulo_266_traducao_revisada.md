# Capítulo 266 — O trouxa que mantém os pés no chão

— Como recompensa, vou lhe dar algo muito gostoso para comer.

Enquanto Lu Linyuan dizia isso, Ning Xiaoxiao, sentada em seu colo, sentiu nitidamente alguma coisa inquieta dar um pequeno salto, como se a convidasse a explorar quanto antes aquele território desconhecido.

— ...

【Parece que ele mora no Planalto de Loess, de tanto que a coisa se ergue.】

Ning Xiaoxiao não entrou na brincadeira. Preferiu retrucar, fingindo interpretar as palavras ao pé da letra:

— Obrigada, mas parei de comer. Estou de dieta!

Só que ele foi ainda mais atrevido: — Eu não disse que era comida.

— ...

Muito bem. Mais uma vez, ele conseguira deixar a própria esposa sem palavras.

— Majestade, os criados do Palácio Yuxiu já vieram solicitar sua presença três vezes hoje...

A voz fina de Sanfu soou do lado de fora: — A Consorte Li não para de chorar. Seus olhos foram prejudicados pelo incêndio, e o médico imperial disse que, se continuar assim, talvez perca a visão de vez...

Lu Linyuan não demonstrou a menor preocupação; respondeu casualmente:

— Não fui eu quem mandou que ela chorasse. Por que o Palácio Yuxiu vem me incomodar com isso?

— O pessoal de lá acha que, se Vossa Majestade tiver um momento para visitá-la, talvez isso a conforte.

Ao ouvir isso, Lu Linyuan fechou a cara e espiou discretamente a expressão da esposa em seus braços.

Ainda bem... Xiaoxiao não parecia aborrecida.

Aquele moleque do Sanfu estava tentando acabar com a vida dele?

Com a esposa ali no colo, ainda tinha coragem de sugerir que fosse visitar outra mulher?

Ele pigarreou e respondeu com solenidade: — Também não quero que ela chore sem parar. Faça o seguinte: diga aos criados do Palácio Yuxiu que, se a Consorte Li continuar chorando, deem-lhe uma pancada na cabeça e a façam desmaiar.

— Desmaiada, ela não vai chorar. Se acordar e voltar a chorar, batam de novo. Uma pancada por crise de choro, até ela parar.

Ning Xiaoxiao: — ???

【Caramba! Desse jeito, se o fogo não a matou, as pauladas vão terminar o serviço...】

Mas sua compaixão pela Consorte Li durou exatamente um segundo, antes que um sorriso impossível de esconder surgisse em seu rosto.

Sanfu foi transmitir o recado. Ning Xiaoxiao, então, decidiu provocar Lu Linyuan e assumiu de propósito uma expressão de profunda piedade.

— A-Yuan, no fundo, a Consorte Li também sofreu uma desgraça que não esperava. Ela sempre deu tanta importância à beleza, e agora perdeu tudo. O trauma psicológico deve ser enorme. Que tal você...?

— Nem pensar! Você se preocupa com o trauma psicológico dela, mas não tem medo de que eu fique traumatizado ao ver aquele rosto? Quando ela era bonita eu já não tinha interesse em olhar; agora, pelo que vocês contam, está toda queimada. Vou fazer o quê lá? Ver um fantasma?

Ele ergueu o queixo de Ning Xiaoxiao e sorriu com malícia: — Além disso, não me canso nem de olhar para você. Onde eu arranjaria vontade de olhar para outra pessoa?

— A-Yuan, você não tem nem um pouquinho de compaixão pelas belas mulheres?

— Não venha tentar me chantagear moralmente como faz a imperatriz-viúva.

Lu Linyuan endireitou-se de repente, colocou Ning Xiaoxiao sobre a mesa imperial e começou a contar nos dedos, com a mais séria das expressões:

— Para começar, foi ela que insistiu em entrar no palácio. Ninguém a obrigou.

— Entrar no harém foi escolha dela; eu nunca a escolhi. Passou todos esses anos comendo, morando e se vestindo às minhas custas, e ainda recebendo prata de graça!

— E não fui eu quem incendiou o rosto dela! Ainda tenho que pagar o tratamento. Aqueles medicamentos para queimaduras custam dezenas, até centenas de taéis de ouro. Ouro de verdade!

Quanto mais falava, mais indignado ficava. Por fim, deu um tapa na própria coxa: — Por que eu haveria de ter pena dela? Pensando bem, quem merece compaixão sou eu!

Então apoiou o queixo na coxa de Ning Xiaoxiao, deixou a cabeça pender e fez um biquinho abatido:

— Sou tão coitadinho... Preciso de um beijinho da minha esposa.

Ning Xiaoxiao deu uns tapinhas na cabeça daquele enorme cão-lobo: — Você fica sufocado se passar um dia sem dizer uma indecência?

Lu Linyuan ergueu as sobrancelhas, os olhos brilhando: — Fico!

— Você...

Antes que ela terminasse, Lu Linyuan se levantou de repente e selou a boca dela com um beijo exigente.

O hálito quente e levemente perfumado invadiu sua boca. Ela ofereceu apenas uma resistência simbólica antes de corresponder ao beijo.

Justo nesse momento, Sanfu escancarou a porta, aflito: — Majestade! A Consorte Li, ela...

Queria anunciar que a consorte pretendia se jogar num poço, mas, ao ver a cena diante de si, ficou petrificado.

Ning Xiaoxiao estava sentada na mesa imperial, de costas para a porta. Lu Linyuan a abraçava e beijava com paixão.

Daquele ângulo, a parte inferior dos corpos estava encoberta. A imaginação de Sanfu disparou, e ele quase morreu de susto.

Sem sequer esperar que Lu Linyuan interrompesse o beijo, começou a dar tapas no próprio rosto e fugiu a toda velocidade...

*

Pelo jeito de Lu Linyuan, mesmo que a Consorte Li realmente se matasse, ele provavelmente só diria, por formalidade, que ela descansasse em paz...

Ela tentara se jogar num poço dentro do próprio palácio, mas os criados a impediram antes mesmo que chegasse à borda. No fim, fizera muito alarde para pouca ação.

A imperatriz chegou acompanhada de várias mulheres do harém. Todas tentaram animá-la, dizendo que, enquanto houvesse vida, haveria esperança.

Entre lágrimas, a Consorte Li respondeu: — Vocês ainda têm esperança. Eu já não tenho nenhuma...

Era verdade: para uma mulher que colocava a própria beleza acima de tudo, perder o rosto equivalia ao desabamento do mundo.

Ela desejava morrer de coração; meia dúzia de conselhos não a faria mudar de ideia.

Naquela noite, quando os criados adormeceram, ela saiu às escondidas do Palácio Yuxiu.

Sua visão estava gravemente prejudicada; enxergava tudo através de uma névoa.

Mas conhecia bem o local depois de tantos anos morando ali. Sabia que havia um poço seco perto da esquina diante da entrada e seguiu em sua direção, tropeçando e tateando pelo caminho.

Já estava à beira do poço, cerrando os dentes e se preparando para saltar e pôr fim à própria vida,

quando alguém a abraçou firmemente por trás.

Entre soluços, a pessoa perguntou: — Minha senhora, por que fazer uma coisa dessas?

A Consorte Li reconheceu a voz de Gu Sijin. Debateu-se com todas as forças e gritou com a voz rouca como a de um corvo no inverno:

— Não me impeça! Deixe-me morrer!

— Eu me olhei no espelho! Meu rosto, meu cabelo... Buáá... Até minha voz... Acabou! Perdi tudo!

— Que sentido tem continuar viva desse jeito, sem parecer gente nem fantasma? A morte seria minha libertação. Só assim tudo terminaria!

Gu Sijin a abraçou ainda mais apertado, sem soltá-la nem por um instante.

A Consorte Li chorava, e Gu Sijin chorava junto.

— Minha senhora! Pense bem! Mesmo que não queira mais viver, precisa pensar em seus parentes!

— O suicídio de uma concubina é um crime grave. Se a senhora saltar e acabar com tudo, o que acontecerá à sua família? E ao irmão que acabou de ser promovido? Todos sofrerão as consequências...

Família.

Sim, ela ainda tinha uma família.

Era irônico: desde que uma mulher entrava naquele palácio, uma gaiola dourada de quatro paredes, nem mesmo a decisão de viver ou morrer lhe pertencia.

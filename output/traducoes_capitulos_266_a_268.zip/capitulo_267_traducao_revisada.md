# Capítulo 267 — Gu Sijin mata com uma faca emprestada

O apelo à família funcionou exatamente como se esperava.

Ao perceber que a Consorte Li se acalmara e parara de se debater, embora ainda soluçasse sem parar, Gu Sijin a soltou, enxugou-lhe as lágrimas e aconselhou com ternura:

— Além disso, se a senhora tirar a própria vida agora, os únicos a sofrer serão aqueles que se importam com a senhora. Quem a deixou nesse estado provavelmente vai até acordar rindo de alegria!

— Por isso, precisa continuar viva, e viver bem! Só assim terá a oportunidade de descobrir quem lhe fez isso e devolver cada gota do sofrimento que lhe causaram!

A Consorte Li ficou imóvel. Tão consumida pela tristeza, nem sequer se lembrara de pensar em vingança até Gu Sijin tocar no assunto.

— É... Você tem razão! — murmurou, tomada pelo ódio. — Não posso morrer! E, se tiver de morrer, vou arrastar a desgraçada que me fez isso para o inferno comigo!

Gu Sijin respondeu, com a voz embargada: — Minha senhora, não volte a pensar em algo assim. Pelas pessoas que ama, deve proteger a própria vida.

A Consorte Li assentiu energicamente e, apalpando à procura da mão de Gu Sijin, segurou-a e agradeceu de todo o coração.

Ela não conseguia enxergar a expressão de Gu Sijin.

Não via que, embora a outra a consolasse entre soluços, seus lábios se curvavam num sorriso sombrio.

Morrer era uma coisa extraordinariamente fácil.

Bastava o coração e a respiração pararem, fechar os olhos para sempre e nunca mais enfrentar as confusões deste mundo, nem sentir dor física ou sofrimento emocional.

Para a Consorte Li, naquele momento, a morte seria o alívio definitivo.

Mas Gu Sijin insistia em lhe oferecer salvação, uma razão para suportar a vida a qualquer custo.

Pois somente continuando viva ela seria obrigada a exibir aquele rosto devastado e sofrer, de corpo e alma, nesse inferno em vida.

A Consorte Li nunca gostara de Gu Sijin, mas todos reconheciam a bondade dela.

Agarrou-lhe a mão e pediu ajuda para avaliar quem seria o principal suspeito.

Gu Sijin hesitou: — Isso... Minha senhora, a pergunta me põe numa posição muito difícil. Nem os investigadores do Tribunal de Revisão Judicial, que examinaram tudo no palácio, encontraram pistas. Não seria apropriado eu fazer suposições. É um assunto grave demais, e tenho receio de falar sem fundamento...

A Consorte Li suspirou: — Esqueça. Sei que você nunca quer ofender ninguém. Não vou conseguir nenhuma resposta perguntando a você.

Gu Sijin amparou-lhe o braço: — Já é tarde, o sereno está forte e a chuva de primavera deixou o chão escorregadio. Deixe que eu a leve de volta ao palácio.

Seguiram rumo ao Palácio Yuxiu. Quando estavam prestes a virar uma esquina, viram, junto à base da muralha, o brilho morno de uma lanterna.

Pouco adiante, ouviram dois eunucos conversando:

— Ah, toda vez que passo pelo Palácio Yuxiu me lembro da tragédia da Consorte Li... Eu estava de serviço por perto naquele dia e fui dar uma olhada. A cena era horrível; tive pesadelos por várias noites...

— Todo mundo no palácio sabe que a Consorte Li prezava a aparência acima de tudo. Quem seria cruel a esse ponto?

Um dos eunucos baixou a voz: — Ouvi dizer que o Tribunal já esclareceu o caso. O fósforo branco apareceu no rosto dela porque alguém o misturou ao pó facial que ela usava todos os dias. Na ocasião, depois de a Consorte Nobre castigá-la, apenas algumas concubinas foram visitá-la. Os investigadores são competentes: não deixam passar nem a menor pista. A Consorte Li é uma das quatro consortes de maior posição. Você acha mesmo que um caso desses terminaria em silêncio?

O outro eunuco perguntou, curioso: — O que quer dizer? Ouviu alguma coisa?

— Ora, nem precisa ouvir rumores. Desde que a Consorte Nobre Tong foi rebaixada a Concubina Tong, a Consorte Li não perdeu a chance de zombar dela, abertamente ou pelas costas. Acha que a Concubina Tong não guardaria rancor? No dia em que a Consorte Li foi castigada, Tong mandou Xianglan visitá-la. E você sabe muito bem como anda a situação na corte. Só se a culpada fosse ela é que o imperador engoliria o caso sem investigar mais a fundo.

Os dois se afastaram. A Consorte Li e Gu Sijin já não puderam ouvir o resto.

Mas aquelas poucas palavras foram suficientes para fazer a Consorte Li cerrar os punhos, rangendo os dentes de ódio.

— É verdade... Como o Tribunal não descobriria quem quis me ferir? Não é que não tenham descoberto. Descobriram alguém que o imperador não pode punir...

— Tong Guowei domina a corte com mão de ferro, e aquela desgraçada da Concubina Tong já guarda rancor de mim há tempos. Achei tão estranho quando Xianglan veio me visitar naquele dia!

Agarrou de repente o pulso de Gu Sijin, tremendo: — Foi ela! Só pode ter sido ela! Nobre Dama Gu, leve-me agora mesmo até o imperador! Exijo que ele faça justiça!

Gu Sijin segurou sua mão e ponderou com serenidade: — Minha senhora, pense bem. Primeiro, não se pode tomar a conversa de dois eunucos como verdade. Mas, ainda que seja verdade, se o imperador pudesse resolver o caso, já teria resolvido. Se decidiu fechar os olhos por causa de Tong Guowei, de que adiantará procurá-lo agora?

A decepção da Consorte Li era visível. Depois de um longo silêncio, suspirou com a voz embargada:

— Concubina Tong! Você me reduziu a esse estado! Nunca vou perdoá-la! Nunca!

Gu Sijin apertou os olhos ao observá-la e esboçou um sorriso frio.

Durante todo o caminho de volta, insistiu para que a Consorte Li não fosse provocar a Concubina Tong, sob pena de acabar atraindo desgraça para si.

Mas a Consorte Li já não tinha condições de ouvir tais conselhos.

Provavelmente já estava planejando como se vingar de Tong.

Após deixá-la em seu palácio, Gu Sijin virou numa rua interna. Dois eunucos, cada um com uma lanterna, esperavam por ela.

Assim que a avistaram, abriram sorrisos bajuladores e correram para recebê-la:

— Saudações, Nobre Dama Gu. Nós a acompanharemos com as lanternas até seu palácio.

Com uma expressão impassível, Gu Sijin tirou de dentro das roupas duas notas de cinquenta taéis de prata e entregou uma a cada um.

— Quem recebe dinheiro precisa saber controlar a própria língua.

— Pode ficar tranquila, Nobre Dama Gu. Sabemos o que fazer!

Mas o outro eunuco parecia insatisfeito: — Nobre Dama Gu, meu pai está doente, e é uma doença cara. Tenho que cumprir meus deveres filiais e cuidar dele por muito tempo. Então... caso eu fique sem dinheiro no futuro, será que a senhora poderia me emprestar um pouco, por generosidade?

Achando que descobrira um ponto fraco de Gu Sijin, ele pretendia chantageá-la indefinidamente.

Os olhos de Gu Sijin ficaram gelados. Ela o examinou de cima a baixo e sorriu:

— A doença do seu pai não tem nada a ver comigo. Se puder viver, que viva. Se não puder, que morra.

— Sua família mora no condado de Wucheng. São seis pessoas ao todo, incluindo seus irmãos mais novos, que ainda são crianças.

Ela se aproximou do eunuco, encostou seus dedos delicados sob o queixo dele e, erguendo um pouco as sobrancelhas, continuou com a voz mais doce possível:

— Se tentar me chantagear com isso, garanto desde já que nem juntando os restos de sua família inteira vocês conseguirão formar um cadáver completo.

Os dois eunucos tremeram de pavor. Caíram de joelhos diante dela e começaram a bater a testa no chão sem parar:

— Tenha misericórdia, Nobre Dama Gu! Nunca mais ousaremos!

Gu Sijin soltou uma risadinha e deu dois tapinhas na bochecha do homem: — Sumam.

Ela recolheu as lanternas que eles haviam deixado cair e foi embora com passos elegantes.

Os eunucos ficaram sentados no chão, encharcados de suor frio. Quando se entreolharam, só havia terror em seus olhos.

Nota da autora: Nossa irmã Gu declara que nem dez imperatrizes juntas seriam páreo para ela sozinha~

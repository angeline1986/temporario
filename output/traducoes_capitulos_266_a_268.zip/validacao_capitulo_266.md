# Validação — capítulo 266

## Fonte e limites

- Documento: `novel_capitulos_212_a_270(20261105-204934).docx` (chinês tradicional).
- Índices reais de parágrafo (base zero): 3835–3908, com último parágrafo não vazio 3907.
- Unidades não vazias, incluindo título, símbolos ou nota autoral: **71**.
- Correspondências presentes: **71**.
- Índices duplicados ou ausentes: **0**.
- Campos vazios na tradução: **0**.

## Decisões editoriais

O título 人間清醒大冤種 é humorístico; traduziu-se de maneira idiomática. A expressão 黃土高坡 produz uma imagem insinuante cuja adaptação preserva o efeito, sem afirmar uma etimologia. A condição da Consorte Li e a tentativa de suicídio permanecem explicitadas.

## Limites de auditoria

O CSV foi verificado quanto à estrutura 1:1 com os índices de parágrafo do DOCX. O cotejo não constitui segunda auditoria semântica independente integral.

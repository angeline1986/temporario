# PÍLULA DE CONTINUIDADE ATUALIZADA — NOVEL CHINESA (ATÉ O CAPÍTULO 50)

**Atualização:** 3 de novembro de 2026. **Último capítulo traduzido: 50. Próximo capítulo: 51.**

## 1. Fonte e regras inegociáveis

- Original primário: `novel_capitulos_1_a_60(20261103-131325).docx` (chinês tradicional; capítulos 1–60).
- Traduzir exclusivamente desse DOCX. EPUBs portugueses, quando disponíveis, servem apenas como referências secundárias.
- Produzir português brasileiro literário, fluente e fiel, preservando humor, sarcasmo, personalidade, gênero, diálogos, pensamentos, números e causalidade, sem omissões nem acréscimos inventados.
- Entregar cada capítulo em `.md`, cotejo `.csv` com `indice_docx,original_chines,traducao_portugues`, e relatório `.md`.
- A contagem 1:1 não é prova suficiente de precisão semântica. Não prometer validação absoluta ou segunda auditoria independente quando não realizada.
- Manter lotes de até três capítulos; próximo lote: **51, 52 e 53**.

## 2. Progresso

- Capítulos 1–11: traduções e cotejos produzidos anteriormente, conforme pílula original; sem auditoria linguística independente plena.
- Capítulos 12–14: cotejos completados nesta conversa.
- Capítulos 15–47: traduções e cotejos estruturais com revisão durante a tradução, gerados em lotes consecutivos. O último lote anterior foi 45–47.
- Capítulos **48–50**: traduzidos nesta etapa com cotejo estrutural.
- Capítulos **51–60**: não traduzidos neste trabalho. **Restam 10 capítulos.**

### Lote 48–50

| Capítulo | Unidades originais (título incluído) | Status |
|---|---:|---|
| 48 | 34 | Tradução revisada + cotejo por unidade + relatório |
| 49 | 38 | Tradução revisada + cotejo por unidade + relatório |
| 50 | 74 | Tradução revisada + cotejo por unidade + relatório |

Total: **146 unidades**, todas com correspondência não vazia. Isso comprova cobertura estrutural, não fidelidade absoluta.

## 3. Glossário e consistência

- 寧瀟瀟 = **Ning Xiaoxiao**, mulher, protagonista transmigrada, humor sarcástico.
- 陸臨淵 = **Lu Linyuan**, imperador, homem; escuta pensamentos de Ning dentro de certo raio, mas não necessariamente o sistema Xiao Qi.
- 三福 = **Sanfu**, eunuco.
- 顧似錦 = **Gu Sijin**, mulher.
- 小七 / 系統 007 = **Xiao Qi / sistema 007**.
- 朝陽宮 = **Palácio Chaoyang**; 仙壽宮 = **Palácio Xianshou**; 辛者庫 = **Xinzheku**.
- 劇情崩壞值 = **índice de desvio da trama**.
- 暫停 / 播放 / 倒退 = **Pausar / Reproduzir / Retroceder**.
- 常在 = **Atendente**, posto do harém; 顧常在 = **Atendente Gu**, não confundir com Consorte Nobre.
- Pensamentos ou mensagens relevantes podem estar em **【 】**, conforme perspectiva e texto chinês.
- A inconsistência do nome do pai de Gu Sijin no original continua anotada: 顧川河 no cap. 6 e 顧延川 no cap. 13. Não normalizar sem decisão editorial.

## 4. Continuidade narrativa crítica (45–50)

- 45–46: os mal-entendidos com o KFC, o velho do logotipo e os alimentos enviados pelo sistema levam o imperador a suspeitar que o retratado seja pai de Ning. Preservar a comicidade sem criar equivalência sonora falsa.
- 47: Ning consegue xampu com a economia de fios de cabelo do imperador; altera frases do enredo para poder dormir no quarto de Lu Linyuan, cumprindo missão de abraçá-lo à noite.
- 48: Xiao Qi exige que ela o abrace durante o sono; a missão rende **1%**, levando o índice acumulado a **11%**. Ning ganha uma roleta e sorteia uma bala de goma QQ que, na ficção, cura venenos e doenças. Lu Linyuan acha que o abraço noturno foi um pesadelo; derrama o xampu sobre a cama.
- 49: Sanfu e criadas confundem a poça de xampu com secreção íntima e presumem um encontro sexual entre Ning e Lu. O imperador escuta as conjecturas, percebe que parte do sonho aconteceu de verdade e exige que Ning lhe devolva a “honra”.
- 50: Ning sonha com sua família no mundo moderno. Xiao Qi permite trazer uma posse antiga: a **pulseira de jadeíta presenteada pela mãe**; exige em troca a **roupa íntima do tirano**. Prazo **12 horas**, com vantagens especiais bloqueadas durante a missão. Ning descobre que Lu está na sala de estudos conversando com os ministros Chen e Guan sobre a fome em Lingnan e corre ao Palácio Chaoyang. Lu ouve o pensamento sobre o roubo, apesar da porta entre eles. **O capítulo termina com sua indignação.** Não antecipar o resultado da tentativa no capítulo 51.

## 5. Arquivos recentes

- `capitulo_48_traducao_revisada.md`, `capitulo_49_traducao_revisada.md`, `capitulo_50_traducao_revisada.md`
- `capitulo_48_cotejo.csv`, `capitulo_49_cotejo.csv`, `capitulo_50_cotejo.csv`
- `validacao_capitulo_48.md`, `validacao_capitulo_49.md`, `validacao_capitulo_50.md`
- `capitulos_48_a_50_traduzidos_cotejados.zip`

A pílula anterior `pilula_continuidade_traducao_novel(1).md` permanece útil para as decisões e armadilhas dos capítulos 1–14. Ao mudar de chat, reanexar **o DOCX chinês, esta pílula e preferencialmente os capítulos revisados recentes**. Caminhos `sandbox:` de outros chats não devem ser presumidos existentes.

## 6. Próxima ação

Traduzir os capítulos **51, 52 e 53** diretamente do DOCX, verificando título e limites do capítulo, criando um registro por unidade original, cotejando significado e gerando três arquivos por capítulo. Progredir então para 54–56, 57–59 e 60; se necessário, reduzir o tamanho do lote para garantir qualidade.

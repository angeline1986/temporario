# Relatório de conferência — Capítulo 49

Fonte: `novel_capitulos_1_a_60(20261103-131325).docx`, original em chinês tradicional.

## Correspondência estrutural

- Unidades originais, incluindo título: **38**.
- Unidades traduzidas, incluindo título: **38**.
- Correspondências ordenadas e não vazias: **38/38**.
- Limites: do título 49 até antes do título 50.

## Decisões e pontos críticos

- 常在 é título do harém traduzido como Atendente; “Atendente Gu” preserva o tratamento estabelecido antes.
- A substância sobre a cama é xampu, mas Sanfu o interpreta como secreção íntima; o texto português mantém a insinuação sem torná-la uma descrição explícita.
- A história passa da suspeita de Sanfu à convicção equivocada de Lu Linyuan de que o pesadelo foi uma relação íntima; a atribuição das conclusões foi preservada.
- A expressão 清白 (“honra”, “inocência/pureza”) constitui o refrão do título duplo dos capítulos 48–49.

## Limites reais

A tradução foi feita a partir do original chinês e cotejada por unidade, com verificação dos eventos e termos narrativos principais. O alinhamento e a contagem foram verificados por código; isso não certifica equivalência linguística total. Não houve auditoria independente. **Classificação: tradução revisada com cotejo estrutural e revisão semântica não independente.**

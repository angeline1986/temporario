# Capítulo 50 — Em plena luz do dia, você vai roubar minha roupa de baixo?

Lu Linyuan jurou que, dessa vez, daria uma lição em Ning Xiaoxiao!

Caso contrário, dentro de mais dois dias aquela maluca provavelmente se atreveria até a montar em sua cabeça para treinar espacate!

Mas já estava na hora da audiência da manhã. Se quisesse puni-la, teria de esperar até o fim da sessão.

*

Naquele dia, era a vez de Cailian acompanhar Gu Sijin na visita de cumprimentos à imperatriz. Assim, Ning Xiaoxiao, que passara a noite em claro, voltou ao alojamento e mergulhou direto debaixo das cobertas.

Ela também teve um sonho.

Só que o sonho dela era com seus pais.

Sonhou que havia concluído todas as missões e conseguido voltar ao mundo moderno.

Seu pai estava na sala lendo o jornal, enquanto a televisão, sintonizada no noticiário, falava bem alto.

Sua mãe se ocupava na cozinha, preparando carne de porco braseada ao molho de soja, o prato favorito da filha.

Os três comiam juntos, conversando e rindo. Depois iam às compras, ao cinema, a um restaurante e davam uma volta para passear.

À noite, de volta à casa, ela se aconchegava no colo da mãe para assistir com ela a uma novela boba.

O pai trazia um prato de frutas que acabara de cortar e comentava, sorrindo: — Vocês duas, mãe e filha, sem mim não conseguiriam nem cuidar da própria vida.

Enquanto comia as frutas cortadas pelo marido, a mãe piscava para Ning Xiaoxiao: — Ouviu? Quando for arranjar namorado, escolha alguém como seu pai, que cuide de você e a mime a toda hora.

Aquela era a rotina de Ning Xiaoxiao no mundo moderno. Agora, porém, havia se tornado algo quase inalcançável.

Quanto maior a felicidade sentida no sonho, mais dolorosa era a diferença ao acordar.

Ela ficou olhando, atordoada, para o céu azul além da janela, com um aperto no coração.

Xiao Qi perguntou: 【Hospedeira, você está com saudade de casa?】

Ning Xiaoxiao respondeu: 【Estou.】

Xiao Qi disse: 【Então vamos fazer o seguinte: como você tem cumprido suas missões com tanta dedicação, este sistema pode lhe oferecer uma recompensa: trazer um objeto de outro lugar até aqui.】

Curiosa, Ning Xiaoxiao perguntou: 【Como assim?】

Xiao Qi explicou: 【Você pode escolher qualquer objeto que possuía no mundo moderno, e eu o trarei para o mundo do livro, para aliviar sua saudade. Mas preste atenção: o objeto escolhido precisa fazer sentido neste mundo. Nem pense em trazer celular, computador, televisão, geladeira ou coisas assim...】

Havia muitas restrições, mas era melhor que nada.

Ning Xiaoxiao pensou com cuidado e, por fim, decidiu trazer a pulseira de jadeíta que sua mãe lhe dera.

Era uma peça que a mãe havia reservado para seu enxoval de casamento. Ning Xiaoxiao ainda se lembrava de como ela brincara ao entregá-la:

— Filhinha, se você não conseguir se casar no futuro, volte para casa com essa pulseira. Sua mãe vai sustentar você pelo resto da vida~

Ah, como sentia saudade da mãe...

Depois de verificar a compatibilidade da pulseira de jadeíta com o mundo do livro, Xiao Qi anunciou: 【Parabéns, hospedeira! A pulseira de jadeíta tem cem por cento de compatibilidade com o mundo do livro. Você pode trazê-la para cá.】

【É sério? Então me dê logo!】

【Mas, para receber a pulseira de jadeíta, a hospedeira primeiro precisa fazer uma troca de objetos.】

Assim que Xiao Qi terminou de falar, outra roleta apareceu na mente de Ning Xiaoxiao.

Aquela era muito mais complicada que a Roleta da Sorte: tinha mais de cem espaços apertados, com os nomes das coisas mais esquisitas.

Pelos das pernas do tirano, unhas da imperatriz, meias da Consorte Nobre...

Ning Xiaoxiao perguntou: 【O que é isso agora?】

【Hehehe~】 Xiao Qi soltou uma risadinha irritante e explicou: 【A hospedeira gira a roleta e precisa usar o objeto em que o ponteiro parar para trocar comigo pela pulseira de jadeíta.】

Muito bem. Ela já devia saber que não seria tão fácil tirar vantagem daquele sistema desgraçado!

Ning Xiaoxiao girou a roleta, e o ponteiro acabou parando na parte inferior.

Naquele espaço, cinco caracteres chamativos anunciavam:

“Roupa íntima do tirano”.

Ao ler aquilo, Ning Xiaoxiao sentiu todos os pelos do corpo se arrepiarem.

【Você quer que eu roube aquilo do tirano? Não, não, não! Eu me recuso...】

Xiao Qi tentou animá-la: 【Mas a hospedeira já viu antes! Por que esse escândalo todo? Se não concordar, vai desperdiçar sua única chance de trazer um objeto de outro lugar, viu?】

Ning Xiaoxiao ponderou o risco de morrer ao fazer aquilo e a saudade que sentia da família. Por fim, reuniu coragem e tomou uma decisão arriscada:

Ela ia roubar!

Xiao Qi anunciou: 【Muito bem, hospedeira! Você terá doze horas para roubar a roupa íntima do tirano. Durante esse período, para impedir que trapaceie, suas vantagens especiais ficarão temporariamente desativadas. O bloqueio será retirado assim que conseguir roubar a roupa íntima ou quando as doze horas se esgotarem.】

Quando o assunto era colocá-la numa enrascada, Xiao Qi nunca a decepcionava.

Mas, na verdade, Ning Xiaoxiao já tinha um plano em mente.

A roupa íntima do tirano ficava em seus aposentos. Depois da audiência, ele normalmente ia à sala de estudos imperial para analisar memoriais ou consultar tratados militares, em vez de voltar direto para o quarto.

Então, se ela conseguisse entrar sem ser vista nos aposentos do tirano, poderia roubar o que bem entendesse, certo?

Mãos à obra!

Primeiro, precisava descobrir para onde Lu Linyuan iria depois da audiência.

Ainda sobrara um pouco do bolo de osmanthus que Gu Sijin preparara no dia anterior. Ning Xiaoxiao colocou os pedaços numa caixa de comida e fingiu que ia levá-los ao imperador a pedido de Gu Sijin.

Ao chegar à sala de estudos imperial, viu Sanfu diante da porta e concluiu que Lu Linyuan certamente estava lá dentro.

Assim que a avistou de longe, Sanfu correu para recebê-la, todo curvado e com um sorriso bajulador. — Ora, ora! Xiaoxiao! O que traz você aqui?

*Xiaoxiao?*

*Desde quando eu tenho tanta intimidade com ele?*

*Por que ficou tão feliz em me ver?*

*Esse homem tem algum problema?*

— Eunuco Sanfu, minha senhora preparou bolo de osmanthus e pensou em mandar um pouco a Sua Majestade.

Sanfu pegou a caixa de comida, com um sorriso ainda maior: — Para uma coisinha dessas, você nem precisa vir pessoalmente! Da próxima vez que quiser entregar alguma coisa, basta mandar me avisar. Eu mesmo enviarei alguém para buscar.

Ning Xiaoxiao: “???”

【Esse velho está bem da cabeça? Por que de repente está me tratando tão bem?】

【Espera... Na antiguidade não era comum eunucos e criadas formarem casais de conveniência? Será que ele quer fazer... aquilo comigo?】

Ning Xiaoxiao estremeceu involuntariamente e recuou dois passos, para ficar mais longe de Sanfu. — Então peço que entregue o bolo de osmanthus a Sua Majestade. Ah, a propósito, por que o senhor não está lá dentro, atendendo o imperador enquanto ele escreve?

Sanfu suspirou: — O ministro Chen e o ministro Guan estão discutindo assuntos com Sua Majestade. Ultimamente houve uma grande fome na região de Lingnan. Imagino que o imperador ainda terá muito com que se preocupar.

Ao ouvir aquilo, Ning Xiaoxiao ficou radiante por dentro.

【Melhor ainda se ele estiver cheio de preocupações! Enquanto os ministros o mantiverem ocupado, ele não voltará tão cedo para os aposentos. Assim, vou ter mais tempo para roubar a roupa íntima dele, não vou?】

Então se despediu rapidamente de Sanfu e correu para o Palácio Chaoyang.

Embora a capacidade de Lu Linyuan de ouvir pensamentos tivesse um limite de distância, ele ainda conseguia ouvir claramente os de Ning Xiaoxiao quando estavam separados por apenas uma porta.

Naquele momento, dentro da sala de estudos, Lu Linyuan escutava os ministros relatarem a situação da fome. Seu rosto começou a ficar cada vez mais sombrio.

*Em plena luz do dia, diante de todo mundo, você pretende roubar minha roupa íntima?*

*Ning Xiaoxiao!*

*Tenho vontade de abrir essa cabecinha sua para descobrir de que ano é a papa que você guarda aí dentro!*

---

## Notas editoriais

- A lembrança materna é uma pulseira de jadeíta destinada ao enxoval, e o sistema exige permuta, não presente gratuito.
- O prazo exato é de doze horas; durante a missão, todas as vantagens especiais ficam desativadas até sucesso ou expiração.
- A roleta enumera pelos da perna do tirano, unhas da imperatriz e meias da Consorte Nobre; o objeto sorteado é roupa íntima do imperador.
- 對食 refere-se a relacionamento ou união de conveniência entre eunuco e criada no contexto palaciano; a versão usa “casais de conveniência” com alusão do pensamento de Ning.
- Lu Linyuan escuta o pensamento de Ning através de uma porta, graças à curta distância, e descobre a intenção de roubar suas roupas íntimas.
- A fome em Lingnan e os ministros Chen e Guan são preservados como assunto da reunião.

# Capítulo 49 — Devolva a minha honra! (Parte 2)

Quando saiu dos aposentos, Lu Linyuan ordenou a Sanfu: — Mande alguém trocar todos os lençóis e cobertores da minha cama.

Depois disso, foi se lavar.

Sanfu chamou duas criadas e mandou que entrassem para trocar a roupa de cama.

Só que, enquanto arrumavam tudo, as duas viram imediatamente o xampu derramado sobre o lençol.

Começaram a cochichar, curiosas: — O que será isso? Até que tem um cheirinho bom.

— Não faço ideia. Nunca vi nada parecido...

Os cochichos chamaram a atenção de Sanfu. Ele entrou agitando seu espanador e repreendeu: — Mandei vocês trabalharem! O que estão resmungando aí?

— Eunuco Sanfu, veja só: que coisa é essa na cama de Sua Majestade?

— Que coisa? — Sanfu lançou um olhar preguiçoso na direção indicada, mas seus olhos brilharam ao ver aquela poça de xampu.

Tocou-a experimentalmente. A textura pegajosa que ficou em seus dedos fez sua imaginação tomar um rumo bastante indecente.

Aquela cor, aquela consistência, aquela sensação... Aquilo provavelmente era... do próprio Lu Linyuan.

*Espere aí... A Atendente Gu não voltou para o seu palácio na segunda metade da noite passada?*

*Então aquilo... veio de onde?*

Sanfu perguntou: — Vocês estavam varrendo o pátio desde cedo. Viram alguém sair do quarto de Sua Majestade?

Uma criada respondeu: — Foi Ning Xiaoxiao, que serve à Atendente Gu. Nós a vimos sair correndo, toda atrapalhada, dos aposentos de Sua Majestade durante a quarta vigília da noite.

— Então foi mesmo ela? — Um sorriso carregado de segundas intenções surgiu no rosto de Sanfu.

Pelo visto, nem as três mil beldades do harém conseguiam despertar no imperador a mesma paixão que Ning Xiaoxiao.

Sanfu lançou outra olhada ao xampu espalhado na cama e suspirou, impressionado:

*Vejam só... Ele realmente não conseguiu se conter!*

As criadas ficaram confusas com aquele sorriso inexplicável. — Por que está rindo, senhor? Afinal, o que é isso? O senhor sabe?

— Tolas! — Sanfu sacudiu o espanador e baixou a voz, fingindo mistério. — Não perguntem o que não lhes cabe perguntar!

Embora não dissesse nada explicitamente, o sorriso malicioso em seu rosto falava por si.

As criadas entenderam de imediato o que ele estava insinuando e ficaram vermelhas até a raiz dos cabelos.

Sanfu pigarreou e tratou de aconselhá-las: — Hum, hum! Daqui para a frente, mantenham os olhos bem abertos quando estiverem de serviço! Quem hoje é uma galinha-do-mato pode amanhã subir ao galho e virar fênix. Pensem bem em quem devem agradar e tratar com respeito. Servir à pessoa certa pode lhes trazer muitas vantagens no futuro~

De rostos ainda corados, as criadas responderam em coro: — Sim, senhor! Agradecemos pelo conselho!

Naquele instante, Lu Linyuan, já lavado, estava parado do lado de fora do quarto, com os pés pesados como chumbo.

Ele ouvira perfeitamente toda aquela “conspiração em voz alta” de Sanfu e das criadas.

Seu rosto ardia de vergonha. Se tentasse explicar aquilo à força, só tornaria a história ainda mais suspeita...

*Então tudo o que aconteceu ontem à noite não foi um sonho?*

*Ning Xiaoxiao realmente se aproveitou de mim só porque peguei o xampu dela?*

【Então ela me abraçou, me apalpou e me prendeu com as pernas como se eu fosse um travesseiro... Tudo aquilo aconteceu de verdade?】

【E ainda ergueu meu queixo e disse que eu não escaparia das mãos dela??】

Dentro do quarto, a “aula explicativa” de Sanfu continuava.

Cada absurdo que ele inventava com a maior naturalidade parecia uma humilhação pública dirigida a Lu Linyuan...

Tomado pela vergonha e pela fúria, Lu Linyuan cerrou os dentes e apertou os punhos com força:

【Ning Xiaoxiao!】

【DEVOLVA A MINHA HONRA!】

---

## Notas editoriais

- 常在 é título do harém traduzido como Atendente; “Atendente Gu” preserva o tratamento estabelecido antes.
- A substância sobre a cama é xampu, mas Sanfu o interpreta como secreção íntima; o texto português mantém a insinuação sem torná-la uma descrição explícita.
- A história passa da suspeita de Sanfu à convicção equivocada de Lu Linyuan de que o pesadelo foi uma relação íntima; a atribuição das conclusões foi preservada.
- A expressão 清白 (“honra”, “inocência/pureza”) constitui o refrão do título duplo dos capítulos 48–49.

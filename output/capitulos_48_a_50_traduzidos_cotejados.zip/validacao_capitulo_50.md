# Relatório de conferência — Capítulo 50

Fonte: `novel_capitulos_1_a_60(20261103-131325).docx`, original em chinês tradicional.

## Correspondência estrutural

- Unidades originais, incluindo título: **74**.
- Unidades traduzidas, incluindo título: **74**.
- Correspondências ordenadas e não vazias: **74/74**.
- Limites: do título 50 até antes do título 51.

## Decisões e pontos críticos

- A lembrança materna é uma pulseira de jadeíta destinada ao enxoval, e o sistema exige permuta, não presente gratuito.
- O prazo exato é de doze horas; durante a missão, todas as vantagens especiais ficam desativadas até sucesso ou expiração.
- A roleta enumera pelos da perna do tirano, unhas da imperatriz e meias da Consorte Nobre; o objeto sorteado é roupa íntima do imperador.
- 對食 refere-se a relacionamento ou união de conveniência entre eunuco e criada no contexto palaciano; a versão usa “casais de conveniência” com alusão do pensamento de Ning.
- Lu Linyuan escuta o pensamento de Ning através de uma porta, graças à curta distância, e descobre a intenção de roubar suas roupas íntimas.
- A fome em Lingnan e os ministros Chen e Guan são preservados como assunto da reunião.

## Limites reais

A tradução foi feita a partir do original chinês e cotejada por unidade, com verificação dos eventos e termos narrativos principais. O alinhamento e a contagem foram verificados por código; isso não certifica equivalência linguística total. Não houve auditoria independente. **Classificação: tradução revisada com cotejo estrutural e revisão semântica não independente.**

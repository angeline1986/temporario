# Capítulo 48 — Devolva a minha honra! (Parte 1)

Os músculos bem proporcionados de Lu Linyuan eram uma delícia de abraçar no começo, mas, depois de tanto tempo, acabavam ficando um tanto desconfortáveis contra os braços.

Além disso, Ning Xiaoxiao tinha o hábito de puxar o cobertor todo para si enquanto dormia.

Por isso, naquela noite, mal pegou no sono e Xiao Qi já começou a tagarelar dentro da sua cabeça:

【Hospedeira! Você soltou os braços! Abrace de novo!】

【Hospedeira! Pare de prender o cobertor entre as pernas! Prenda ele, ora!】

Ela passou a noite inteira dormindo mal e acordou quando o céu mal começava a clarear.

【Bip, bip, bip! Parabéns, hospedeira, pela missão concluída! O índice de desvio da trama aumentou em 1%, chegando a 11% no total. Você ganhou uma rodada na Roleta da Sorte!】

Mal Xiao Qi terminou de falar, uma grande roleta adornada com luzinhas multicoloridas apareceu na mente de Ning Xiaoxiao.

A roleta estava dividida em partes iguais e exibia prêmios como “macarrão instantâneo da sabedoria”, “tiras apimentadas da superforça”, “bala de goma QQ antivenenos” e assim por diante.

Tirando três espaços bem destacados com “Obrigado pela participação”, todos os outros prêmios pareciam, ao mesmo tempo, completamente idiotas e incrivelmente poderosos.

Convencida de que acabaria tirando um “Obrigado pela participação”, Ning Xiaoxiao girou a roleta sem a menor expectativa. Depois de um número indeterminado de voltas, o ponteiro parou em “bala de goma QQ antivenenos”.

Um brilho azulado cintilou sobre sua palma, e uma bala de goma vermelha apareceu instantaneamente em sua mão.

Ela apertou a balinha entre os dedos. 【Que diabo é isso?】

Xiao Qi respondeu: 【Parabéns, hospedeira! Você ganhou a bala de goma QQ antivenenos. Ela pode eliminar qualquer veneno mortal ou doença difícil de curar que exista no mundo do livro. Basta comer uma e o problema desaparece!】

Ora, aquilo era uma coisa boa!

Vivendo naquele harém onde as pessoas devoravam umas às outras, quem garantia que um dia ela não acabaria vítima de alguma armação?

Pelo menos aquela bala poderia salvar sua vida se alguém conseguisse envenená-la ou fazer algum mal a ela.

Depois de guardar a bala cuidadosamente, Ning Xiaoxiao saiu devagar da cama do tirano e escapuliu pela porta na ponta dos pés.

Ao sair dos aposentos de Lu Linyuan tão cedo, acabou sendo vista pelas criadas que serviam perto do imperador.

— Não era a Atendente Gu quem devia passar a noite com Sua Majestade? Então por que a criada dela está saindo furtivamente do quarto do imperador logo de manhã?

— Precisa perguntar? Se Sua Majestade não tivesse permitido que ficasse, como ela poderia passar a noite ali? Melhor não nos metermos nos assuntos dos nossos senhores. Vamos trabalhar.

Naquela noite, Lu Linyuan tivera um pesadelo.

Sonhara que Ning Xiaoxiao havia montado nele outra vez!

Dessa vez, no sonho, ela passeava as mãos por todo o seu corpo: primeiro pelos peitorais, depois pelo abdômen e, depois do abdômen, por...

Por fim, ainda teve a audácia de jogar uma perna por cima dele e prendê-lo com força entre as coxas...

E ele, como se estivesse sofrendo uma paralisia do sono, não conseguia nem resistir, muito menos soltar um grito.

No final do sonho, Ning Xiaoxiao ergueu seu queixo e, com um sorriso de vilã perigosamente sedutora, declarou: — Você nunca vai escapar das minhas mãos~

Lu Linyuan despertou num sobressalto. Ao perceber que estava sozinho na cama e que tudo não passara de um sonho, soltou um longo suspiro, como quem acabara de escapar da morte.

Levantou-se por hábito para se lavar, mas havia esquecido que, na noite anterior, para impedir que Ning Xiaoxiao roubasse seu xampu, dormira abraçado ao pote de cerâmica.

Ao se sentar bruscamente, derrubou o pote na cama. O xampu escorreu por todos os lençóis.

Olhou para aquela poça de xampu, sentindo uma pontada de pesar.

Pelo visto, não teria a sorte de aproveitar aquela maravilha...

(PS da autora: Hoje os dois capítulos foram separados. Serão três capítulos publicados ao todo.)

---

## Notas editoriais

- A missão da noite anterior acrescenta 1 ponto percentual, elevando o índice de desvio da trama a 11%.
- 百毒消QQ糖: bala de goma QQ antivenenos, item fantástico que remove venenos e enfermidades difíceis dentro da história; não é afirmação médica.
- Os prêmios de comida foram adaptados como produtos cômicos, preservando sua função na roleta. O original traz uma aparente omissão/erro tipográfico na quantidade de partes da roleta; não foi inventado um número.
- O pesadelo de Lu Linyuan reproduz sensações reais da noite anterior sem que ele saiba, preservando o mal-entendido.
- A nota de publicação da autora foi mantida como texto separado.

# Capítulo 90 — É com você que eu me importo

Ning Xiaoxiao comia com gosto quando Lu Linyuan perguntou, num tom frio: — Tenho uma coisa a lhe perguntar.

Na madrugada anterior, por volta da quarta vigília, Ning Xiaoxiao se levantara para ir ao banheiro. Ao passar pelo quarto de Gu Sijin, estranhara não haver ninguém de guarda.

Espiou pela fresta da porta e viu um homem desconhecido deitado na cama de Gu Sijin.

Imediatamente, lembrou-se da trama original: a Consorte Nobre e Cailian se uniriam para acusar Gu Sijin de ter um caso com um guarda, levando-a ao Palácio Frio.

A Consorte Nobre e Cailian estavam por trás da armação. Xiaoxiao ainda guardava rancor pelo episódio da pulseira. Era como se suas inimigas lhe entregassem de bandeja a oportunidade perfeita de vingança!

Sabia que o guarda não havia tocado em Gu Sijin. Por isso, em vez de acordá-la, fora diretamente procurar Lu Linyuan.

Assim que o encontrou, despejou uma enxurrada de informações, explicando com tantos detalhes e provas como a Consorte Nobre e Cailian haviam tramado contra Gu Sijin que parecia até ter participado do plano.

Sabia inclusive onde estavam escondidos a esposa e os filhos do guarda, fora do palácio.

Até então, Lu Linyuan pensava que os dons proféticos dela se limitassem ao destino do império. Pelo visto, aquela garota conhecia os meandros de praticamente tudo.

Sua curiosidade por Ning Xiaoxiao aumentou ainda mais.

Ele perguntou: — Se ontem você viu sua senhora deitada na cama com um guarda, por que não a acordou antes de vir me contar? Por que permitiu que as outras consortes os encontrassem?

O mais lógico seria acordar Gu Sijin, expulsar o guarda e resolver primeiro o perigo imediato.

A dúvida de Lu Linyuan era perfeitamente razoável.

Xiaoxiao explicou: — A princípio, eu ia acordá-la. Mas depois pensei: de que adiantaria? Se as responsáveis não conseguissem desta vez, voltariam com um plano ainda pior. E eu não teria sempre a sorte de descobrir a armação com antecedência. Em vez de só frustrar esta tentativa, achei melhor contar tudo a Vossa Majestade para que acabasse de uma vez com essas práticas perversas no harém. Só assim elas aprenderiam a se comportar.

Ao ouvi-la, Lu Linyuan passou a enxergar aquela bobinha sob outra luz.

Sempre achara que ela fosse meio atrapalhada e, como tantas outras, não soubesse o que fazer diante de um problema.

Não esperava que tivesse inteligência para recorrer à autoridade imperial e proteger Gu Sijin de futuros ataques.

Embora detestasse ser usado pelos outros, quando se tratava de Ning Xiaoxiao, Lu Linyuan encontrava uma justificativa bem conveniente:

Isso nem chega a ser me usar, chega?

Afinal, foi a Consorte Nobre quem cometeu a maldade. A família Tong domina a corte há tempos, e eu já queria pôr um freio na arrogância deles.

Se Xiaoxiao não tivesse colocado o bastão de castigo diretamente nas minhas mãos, teria dado um trabalho danado encontrar um pretexto para punir a Consorte Nobre.

Hum?

Espere aí...

Como foi mesmo que acabei de chamar essa louca?

...

Lu Linyuan endireitou a postura. Seus dedos compridos tamborilavam sobre a mesa, produzindo pequenos toc-tocs.

— E como tinha tanta certeza de que eu acreditaria apenas na sua versão dos fatos e me meteria nessa confusão?

Ning Xiaoxiao, já satisfeita, soltou um arroto, cobriu a boca com um sorriso constrangido e respondeu: — Como isso pode ser uma confusão sem importância? Estamos falando de uma consorte de Vossa Majestade! Além disso... o imperador certamente se importa muito com a Atendente Gu, não é?

【Afinal, ela é a protagonista! Se você não se importa com ela, vai se importar com quem?】

【Se eu servisse outra pessoa, alguma Atendente Xiao ou Concubina Shen, por exemplo, você nem me daria ouvidos.】

【E não seria só ignorar, não! Capaz de me expulsar daqui aos berros!】

No fundo, Ning Xiaoxiao sempre acreditara que toda a paciência, gentileza e tolerância que Lu Linyuan demonstrava com ela vinham do brilho de Gu Sijin como protagonista da história.

Ao ouvir esses pensamentos, Lu Linyuan sentiu uma irritação inexplicável.

Ele não compreendia exatamente o que significava “protagonista”; supunha que Xiaoxiao chamasse Gu Sijin assim por ser sua senhora.

Mas entendera muito bem que ela achava que ele castigara severamente a Consorte Nobre e Cailian por causa de Gu Sijin.

Pensava que ele se importava com Gu Sijin e, portanto, ficara furioso ao vê-la injustiçada?

Hah! Que idiota!

【Nunca foi com essa sua tal protagonista que me importei. Eu ouvi sua tagarelice ontem de madrugada porque você salvou minha vida!】

Seu mau humor ao despertar atingia níveis máximos.

Certa vez, uma criada o acordara na quarta vigília ao quebrar um vaso de flores. Ele a mandara para a Xinzheku, de onde até hoje não saíra.

Na madrugada anterior, Ning Xiaoxiao surgira no Palácio Chaoyang berrando como um porco no abate. Se fosse outra pessoa, talvez já tivesse perdido a cabeça.

Quando ela lhe contara tudo pela primeira vez, ele ouvira nitidamente seus pensamentos.

Por um lado, queria salvar Gu Sijin; por outro, tinha suas próprias razões.

Ela ainda não superara o fato de a Consorte Nobre e Cailian terem quebrado a pulseira que ganhara da mãe.

Lu Linyuan pensara que era apenas uma pulseira cara: bastaria comprar outra idêntica para compensá-la.

Mas esquecera que o valor de uma joia é uma coisa; o carinho de uma mãe, outra, que não se pode substituir.

Como era um sujeito pouco sensível a essas sutilezas, só agora percebia a diferença.

Por isso, decidira entrar na encenação de Xiaoxiao e punir duramente a Consorte Nobre e Cailian, dando-lhe a chance de desabafar sua mágoa.

Também seria uma forma de retribuir por ela ter salvado sua vida.

Tudo isso parecia fazer sentido. Só que até Lu Linyuan parecia ter se esquecido de um detalhe:

Xiaoxiao só o salvara naquele dia porque, antes, ele lhe comprara uma pulseira.

*

Vendo que Lu Linyuan permanecia calado, Ning Xiaoxiao pensou que precisava impulsionar a trama, ajudar Gu Sijin a conquistar uma posição mais alta e, assim, voltar logo para casa.

【Que tal dar uma mãozinha e fazer ele finalmente dormir com Gu Sijin?】

— Majestade, minha senhora ficou muito abalada com o que aconteceu ontem. Que tal chamá-la para passar a noite com Vossa Majestade? Isso também serviria para consolá-la.

Uma raiva sem nome incendiou Lu Linyuan.

Você é idiota, por acaso?!

Ele explodiu: — Não cabe a uma criada se intrometer em quem eu escolho para passar a noite!

Ning Xiaoxiao abaixou a cabeça, fez biquinho e começou a choramingar:

— Está bem... eu errei...

Lu Linyuan continuou implacável: — Vou deixar uma coisa bem clara! Depois do escândalo no Palácio Zhongcui, os favores de sua senhora chegaram ao fim! Cailian era uma criada nascida na casa da família Gu. Como posso saber se o que fez não foi consequência da incapacidade de Gu Sijin de controlar os próprios servos?

— Se Vossa Majestade não quer chamá-la, está bem... — resmungou Xiaoxiao, magoada. — Mas precisava ser tão bravo?

O rosto de Lu Linyuan ficou verde de raiva [○･｀Д´･ ○]:

【Eu durmo com quem bem entender! O que você tem a ver com isso?!】

【E ainda quer mandar em mim? Ora, faça-me o favor!】

【Se continuar falando absurdos, vou é levar VOCÊ para a cama agora mesmo!】

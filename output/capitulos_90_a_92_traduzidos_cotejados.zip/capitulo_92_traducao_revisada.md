# Capítulo 92 — Toda fofinha, ela dança “Ai Ni” para o tirano

Xiao Qi só se preocupava em distribuir missões. Descobrir como completá-las era problema de Ning Xiaoxiao.

E que solução ela poderia encontrar?

Já haviam se passado sete dias inteiros desde que Xiao Qi anunciara a missão.

Sete dias completos, e Lu Linyuan não convocara Gu Sijin nem uma única vez.

Desde o incidente com Cailian, Gu Sijin perdera até a oportunidade de dançar sua ginástica ao som de “Compêndio de Matéria Médica” no Palácio Chaoyang.

O prazo da missão era de apenas dez dias. Se Lu Linyuan continuasse sem vê-la, Xiaoxiao não podia simplesmente imitar Cailian, arranjar um guarda qualquer e fazer com que ele a desonrasse!

Quando já não sabia o que fazer, uma boa notícia veio do departamento responsável pelas convocações noturnas.

Naquela noite, Lu Linyuan escolhera a placa de Gu Sijin.

E a razão para tê-la escolhido era muito simples.

Havia vários dias que não via Ning Xiaoxiao. Sem aquela maluca berrando e resmungando perto dele, começava a ficar entediado.

Além disso, fazia tempo que não a punha para ler memoriais. Já estava na hora de ouvir mais umas previsões sobre o futuro!

O ritual da visita noturna de Gu Sijin seguiu exatamente como antes.

Assim que chegaram, Lu Linyuan a mandou fazer ginástica sozinha e se retirou para o escritório para examinar os memoriais.

Ao sair do quarto, lançou um olhar a Ning Xiaoxiao, que estava parada à porta, distraída. Pigarreou. — Sabe o que tem de fazer, não sabe?

— Ah? Sei, sim, sei...

Ela o seguiu cabisbaixa, maquinando sem parar uma forma de concluir a missão.

【Como é que vou convencer esse homem a cair de boca em Gu Sijin, afinal?】

【A Xiao Gu é tão linda! Não é possível que ele não sinta absolutamente nada por ela!】

【Não, assim não dá. Preciso pensar direitinho num jeito de mandar esse sujeito direto para a cama dela!】

Lu Linyuan: — ???

Eu sou algum gato ou cachorro que você cria? Vai me mandar para a cama de quem bem entender?

Por que essa maluca anda tão empenhada em fazer alguém violar minha castidade?

O que exatamente está tramando?

Quanto mais pensava em como Ning Xiaoxiao falava dele, mais irritado Lu Linyuan ficava.

Decidiu então lhe dar uma bela lição, sem demora:

— Pensando bem, hoje não precisa ler os memoriais. Lembro que, da última vez, um bolo a deixou desacordada por quase meio dia. Sua saúde deve ser péssima.

— Você serve sua senhora, mas mal consegue carregar alguma coisa. Para que serve uma criada assim?

— Portanto, decidi que, a partir de hoje, fará ginástica com sua senhora.

O rosto de Xiaoxiao era a própria imagem da recusa. — Ah? Majestade... não precisa, precisa?

— Se eu digo que precisa, precisa! — Lu Linyuan a agarrou pela gola e a arrastou de volta ao quarto.

Naquele momento, Gu Sijin pulava de um lado para o outro, encharcada de suor. Ao ver o imperador entrar mal-humorado, empurrando Xiaoxiao, pensou que a moça tivesse aprontado alguma coisa. Nem esperou recuperar o fôlego para perguntar: — Majestade, Xiaoxiao fez algo errado?

— Não foi nada. Continue seus exercícios. Ela é responsável por cuidar pessoalmente de você, mas é fraca e parece estar sempre doente. Como vai cuidar de sua senhora se mal consegue cuidar de si? Vai se exercitar junto com você.

Gu Sijin sorriu aliviada. — Então venha, Xiaoxiao! No fim das contas, fazer exercício faz bem.

Ning Xiaoxiao olhou para Gu Sijin, coberta de suor, e sua expressão dizia um sonoro “nem pensar!”.

O mais constrangedor é que Lu Linyuan exigia que gritassem palavras de ordem durante a ginástica.

Gu Sijin comandava a aula, recitando animadamente:

— Quem tem a parte externa das coxas mais bonita?

— A parte externa das minhas coxas é a mais bonita? — repetia Xiaoxiao, pulando.

— Quem tem a pelve mais alinhada?

— Minha pelve é a mais alinhada?

— Quem não tem aquele balanço, balança-balança-balança, na parte externa das coxas?

Ning Xiaoxiao: — ???

Chega. Cansei. Pode acabar o mundo!

Ela não aguentava a intensidade daquela ginástica e muito menos os slogans vergonhosos. De repente, teve uma ideia e sugeriu a Lu Linyuan: — Majestade, esses exercícios até ajudam o corpo, mas não têm beleza nenhuma... Que tal eu ensinar outra dança à minha senhora?

Era óbvio que Lu Linyuan só queria provocá-la.

Sabendo que ela detestava gritar aqueles lemas, respondeu: — Pode ser. Mas, enquanto ensinar, terá de dançar e recitar as palavras de ordem.

— Claro, Majestade! Sem problema!

Ning Xiaoxiao não dava conta da ginástica, mas, depois de tantos anos acompanhando ídolos pop, cantar e dançar diante de Lu Linyuan não parecia nada difícil.

Lembrou que era o dia de folga de Xiao Qi e que, pela manhã, ele mencionara que iria ao karaokê com outros sistemas. Então o chamou mentalmente: 【Ei, seu malandro! O que está fazendo?】

Do outro lado vinha uma barulheira. 【Estou cantando num karaokê! O que foi, anfitriã?】

【Perfeito! Coloque “Ai Ni”, da Cyndi Wang, para mim. O imperador-cachorro quer me ver dançar!】

Quem não gosta de assistir a uma garota bonita dançando? Xiao Qi também gostava!

Assim, sem discutir, colocou a música para Ning Xiaoxiao.

Seguindo o ritmo da batida que ouvia em sua cabeça, ela começou a dançar.

E as supostas “palavras de ordem” viraram versos absurdos de uma paródia feita por ela:

— Se você espirrar de repente, é porque está com alguma doença esquisita!

Se o galo te acordar de madrugada, é porque você esqueceu de alimentá-lo.

Vivo pensando no que você disse... Será que você disse alguma coisa?

Quero tanto acreditar, mas meu nome não é Acredita!

No seu coração, há o lado esquerdo e o lado direito!

“Amor” é só a tradução de “love”!

So baby, fale um pouquinho mais de amor e um pouquinho menos de bobagem,

Mostre mais atitude, deixe eu ver do que você é capaz.

Oh, bye! Fale menos; minha sugestão é dizer logo adeus.

Mais um pouquinho, e um traço a mais transforma “grande” em “cão”!

Amo você!

Depois de cantar o último “amo você”, ainda fez um coraçãozinho com as mãos para Lu Linyuan.

ღ( ´･ᴗ･` )

Sua apresentação açucarada foi como a flecha de Cupido: acertou em cheio o coração de Lu Linyuan.

【Droga! Que coisa mais fofa!】

Ao mesmo tempo, seu “21” também começou a se erguer involuntariamente.

Ele tentou mudar de posição para disfarçar o constrangimento e comentou, com o rosto impassível: — Nada demais. Achei bem comum.

Gu Sijin, por outro lado, exclamou, encantada: — Xiaoxiao, você dança tão bem!

— Já que a Atendente Gu gostou, ensine a coreografia mais uma vez.

É claro que ele jamais admitiria que queria assistir de novo!

Assim, Ning Xiaoxiao conduziu Gu Sijin por mais uma rodada da dança.

Durante todo o tempo, Lu Linyuan não tirou os olhos de Xiaoxiao.

Enquanto ela saltitava, seus seios também balançavam sem parar; ele ficou vermelho até as orelhas, com o coração disparado como um motor em alta velocidade.

Afinal, quem resistiria a uma garota fofinha e bem-dotada?

No meio do refrão, Gu Sijin fez uma careta de dor, levou a mão à parte inferior do abdômen e parou.

Ning Xiaoxiao correu para ampará-la. — Minha senhora, o que houve?

— Eu... acho que estou com dor de barriga...

Dor de barriga?

Mas não era época de menstruação! Por que o abdômen começara a doer do nada?

Enquanto Xiaoxiao tentava entender, uma fanfarra de missão concluída soou em sua mente.

Xiao Qi: 【Bip, bip! Parabéns, anfitriã! Missão cumprida, índice de desvio da trama +1%! Total acumulado: 15%!】

Ning Xiaoxiao ficou paralisada de espanto.

Que história era aquela?

Como a missão podia ter sido concluída de repente?

Uma hipótese completamente absurda surgiu em sua cabeça:

Será que, de tanto fazer exercício, ela tinha rompido o hímen...?

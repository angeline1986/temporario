# Validação — Capítulo 90

- Fonte primária: `novel_capitulos_61_a_120(20261103-184549).docx` (chinês tradicional).
- Unidades do original, incluindo título: **67**.
- Unidades traduzidas e alinhadas: **67**.
- Correspondências vazias: **0**.
- Conferência estrutural: **concluída** para as unidades extraídas do DOCX.
- Revisão de tradução: realizada durante a redação; **não foi executada uma segunda auditoria linguística independente**.
- Os capítulos foram tratados sem antecipar conteúdo posterior; pensamentos entre 【 】 e referências a nomes e posições do harém foram preservados.
- Observações: preservar a diferença entre o afeto de Lu Linyuan por Xiaoxiao e a percepção equivocada da protagonista; título interpretado como declaração interna do imperador.

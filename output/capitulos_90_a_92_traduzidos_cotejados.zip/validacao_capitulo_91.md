# Validação — Capítulo 91

- Fonte primária: `novel_capitulos_61_a_120(20261103-184549).docx` (chinês tradicional).
- Unidades do original, incluindo título: **52**.
- Unidades traduzidas e alinhadas: **52**.
- Correspondências vazias: **0**.
- Conferência estrutural: **concluída** para as unidades extraídas do DOCX.
- Revisão de tradução: realizada durante a redação; **não foi executada uma segunda auditoria linguística independente**.
- Os capítulos foram tratados sem antecipar conteúdo posterior; pensamentos entre 【 】 e referências a nomes e posições do harém foram preservados.
- Observações: “forçar o boi a beber água” foi mantido como imagem idiomática; sarcasmo das consortes e nova missão foram preservados.

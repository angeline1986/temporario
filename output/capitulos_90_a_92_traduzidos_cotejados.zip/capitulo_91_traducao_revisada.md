# Capítulo 91 — Xiao Qi inventou outra missão absurda

A única maneira que Gu Sijin encontrava de evitar os favores imperiais era fingir estar doente.

Mas, depois de tantas noites supostamente passadas com o imperador, continuar virgem deixava óbvio para as demais consortes que seus privilégios eram uma farsa.

Antes, quando adoecia, a imperatriz a dispensava da saudação matinal. Agora, por duas vezes enviara alguém ao Palácio Fengluan para avisar de seu mal-estar e não recebera autorização alguma para faltar.

Naquele dia, quando compareceu à saudação a contragosto, notou que a atitude das demais consortes mudara visivelmente.

Se antes só a Consorte Nobre destilava sarcasmo, agora até a Atendente Xiao, que ocupava o mesmo posto que ela, fazia questão de humilhá-la.

— Ora, Atendente Gu! Como está discretamente vestida hoje! Tantos tons claros... está de luto por aquela serva traiçoeira que mordia a mão que a alimentava?

Ela escondeu o sorriso atrás da mão. — Dizem que os criados nascidos e criados numa família aprendem tudo observando os patrões. Se a minha Fu'er fizesse uma traição dessas, eu mesma lhe arrancaria a pele antes de o imperador decidir o castigo. Mas a Atendente Gu é tão bela e bondosa... Não admira que receba tanta “atenção” de Sua Majestade.

A Consorte Yun zombou: — O que não entendo é por que o imperador a convoca todas as noites e nunca encosta um dedo em você. Será que acha mesmo suas aberturas de pernas tão boas que a chama apenas para dar um espetáculo e divertir a corte?

A Consorte Li emendou: — Pois é. Uma mocinha de família sem grande distinção que consegue divertir o imperador abrindo as pernas... até que é uma sorte e tanto.

As provocações vinham de todos os lados, deixando o rosto de Gu Sijin em chamas. A imperatriz, como senhora do harém, ao menos interveio:

— Chega. Contenham a língua. Depois do que aconteceu com a Concubina Tong, é melhor tomarem cuidado para não seguir o mesmo caminho.

A Consorte Yun bufou: — Ela? Hmph! Colheu exatamente o que plantou! Nunca suportei aquela arrogância. Depois de tanto tempo sendo pisoteada por ela, finalmente posso respirar aliviada.

As consortes continuaram tagarelando por um bom tempo, sempre às custas de Gu Sijin.

Ela já previra que a saudação seria assim; não ousou responder e suportou todos os insultos.

Quando enfim pôde sair, encontrou a Consorte Yun outra vez, no caminho de volta ao palácio, acompanhada por Ning Xiaoxiao.

A Consorte Yun fez sua liteira alcançar Gu Sijin e a chamou: — Atendente Gu, está livre hoje?

Gu Sijin fez uma reverência respeitosa. — A Consorte Yun deseja alguma coisa?

A outra sorriu. — Estou entediada, sem nada para me distrair. Se tiver tempo, venha ao meu palácio e apresente sua famosa abertura de pernas. Assim poderá me divertir um pouco.

Sabendo que ela estava procurando encrenca, Gu Sijin alegou ter assuntos a resolver em seus aposentos.

A Consorte Yun fechou a cara. — Que assunto tão importante pode ter uma mera atendente? Está tentando me enganar?

— Sou uma consorte do imperador, não uma cantora nem uma dançarina do palácio. Se Vossa Alteza está entediada, pode convocar artistas para se apresentarem.

— Insolente!

A Consorte Yun se aproximou e ergueu o queixo de Gu Sijin com o indicador. — Sou uma consorte de grau superior, e você é apenas uma atendente. Acha que não posso lhe dar ordens?

Gu Sijin ergueu os olhos e a encarou em silêncio, com uma dureza crescente no olhar.

Assim que seus olhares se cruzaram, a Consorte Yun lhe deu uma bofetada.

— Que olhar é esse que você dirige a mim?

Gu Sijin também era teimosa. Sabia que a outra procurava uma desculpa para atacá-la e que não escaparia. Continuou encarando-a com desafio.

A Consorte Yun ergueu novamente a mão, mas desta vez Ning Xiaoxiao se colocou à frente e segurou seu pulso.

— E de onde saiu essa criada imunda? Estou disciplinando uma consorte. Como ousa me impedir?

Ning Xiaoxiao afastou-lhe a mão com força e disse, séria: — Eu jamais ousaria impedir Vossa Alteza. Só peço que pense bem antes de agir. A senhora não acredita mesmo que Sua Majestade chama minha senhora todas as noites só para vê-la fazer espacates, acredita?

Ela fitou a Consorte Yun e começou a inventar, com a maior seriedade: — Vou lhe contar a verdade. Não é que o imperador não queira consumar a união. É minha senhora quem não aceita. Ela deseja o amor sincero de Sua Majestade, não apenas o prazer da carne. Se quisesse dividir o leito com ele, bastaria dizer sim.

A Consorte Yun caiu na gargalhada. — Hahaha! Ele a ama? Você acha que sou idiota para cair nessa mentira?

— Sou eu quem faz a vigília todas as vezes que minha senhora vai aos aposentos imperiais. Sei melhor que ninguém o que acontece entre eles. Do contrário, como eu teria conseguido chamar Sua Majestade tão depressa quando a Concubina Tong e Cailian tentaram incriminá-la?

— Sou apenas uma criada sem importância. Que influência teria diante do trono? E se minha senhora não ocupasse um lugar especial no coração do imperador, ele castigaria tão severamente a Concubina Tong, cuja família é tão poderosa na corte, apenas para defender uma atendente sem favores?

— Claro, se não acredita, pode perfeitamente espancar minha senhora até a morte aqui mesmo, nesta avenida.

Dizendo isso, puxou Gu Sijin e a empurrou para a frente da Consorte Yun.

Gu Sijin: — ???

Ning Xiaoxiao prosseguiu: — Mas pense bem: e se eu estiver dizendo a verdade? Nesse caso, o próximo tapa não atingirá apenas o rosto da minha senhora, e sim a pessoa mais querida do imperador. Se ele voltar a convocá-la esta noite e perguntar de onde veio o ferimento, Vossa Alteza acha mesmo que poderá arcar com as consequências?

A confiança com que falava não parecia nem um pouco a ousadia de uma simples criada.

Se Gu Sijin não fosse realmente favorecida, nem com dez vidas aquela empregadinha teria coragem de falar assim com ela.

A Consorte Yun ponderou por um momento. Por coincidência, um trovão abafado ecoou no céu claro, dando-lhe uma desculpa conveniente para recuar. — Parece que vai chover. Não vou perder mais tempo com vocês. Vamos.

Gu Sijin apertou a mão de Ning Xiaoxiao e mordeu os lábios. — Você mentiu para protegê-la. Quando ela descobrir que não recebo favores, vai usar isso contra você. Por que se colocar em perigo por minha causa?

Xiaoxiao sorriu despreocupadamente. — Com aquele cérebro de porco? Não tenho medo dela. O importante é que a senhora está bem.

Ela acariciou delicadamente a face avermelhada de Gu Sijin. — Dói?

Gu Sijin balançou a cabeça, com lágrimas nos olhos. — Você deve sofrer tanto por servir a uma senhora tão inútil quanto eu...

Ning Xiaoxiao se preparava para dizer algumas palavras de consolo quando Xiao Qi surgiu de repente com uma nova missão:

【Bip, bip! Anfitriã, chegou uma nova missão para você!】

【Faça Gu Sijin perder a virgindade!】

【Recompensa: índice de desvio da trama +1% e uma rodada na roleta. Se falhar, sua vitalidade cairá 20%!】

Ning Xiaoxiao ficou atônita. 【Está de brincadeira comigo? A trama já se desviou tanto que Lu Linyuan nem quer mais fazer aquilo com ela! O que espera que eu faça?】

【Forçar o boi a beber água? Tenho medo de que, antes de conseguir abaixar a cabeça dele, leve um coice!】

# Validação — Capítulo 210

- **Fonte primária:** `novel_capitulos_181_a_211(20261105-152737).docx` — chinês tradicional.
- **Limites no DOCX:** parágrafos de índice base zero **1920** a **1992** (excluindo os vazios do cotejo).
- **Unidades não vazias:** **70**, incluindo título e eventuais notas da autora.
- **CSV:** cabeçalho exato `indice_docx,original_chines,traducao_portugues`; **70** linhas de dados.
- **Verificações automatizadas:** índices iguais à extração do DOCX; ausência de duplicações e de campos vazios; texto dos campos iguais aos utilizados para montar a tradução integral em Markdown.
- **Decisões editoriais:** O pó da invisibilidade havia sido recebido no capítulo 207. Aqui sua ingestão é acidental. O efeito envolve intangibilidade, inaudibilidade e supressão da audição dos pensamentos por Lu Linyuan; não se trata de simples invisibilidade visual. O capítulo termina no suspiro de Lu, sem antecipar o 211. O título é adaptado pelo humor da cena interrompida.
- **Limitação:** a validação 1:1 comprova a cobertura estrutural dos parágrafos, não a perfeição da tradução em cada frase. Tradução e revisão contextual feitas no mesmo processo, sem segunda auditoria semântica independente integral.

# Capítulo 208 — Não tenha medo, Majestade. Estou aqui.

Durante todos aqueles anos em que vivera sozinho no Palácio Chaoyang, ele quase nunca apagava as luzes à noite.

Sanfu esperava que adormecesse para entrar às escondidas e apagar as velas.

Tinha pavor da escuridão, e ainda mais de lugares úmidos e fechados, pois passara a infância inteira num ambiente sombrio, sem jamais ver a luz do dia.

Quando um pesadelo invade a realidade, é como um carrasco empunhando uma lâmina ensanguentada.

Ele obriga você a erguer o rosto e olhar para a faca, mas não a descarrega em seu pescoço: limita-se a roçar incessantemente a parte mais delicada da nuca, até levá-lo ao desespero e fazê-lo desmoronar por dentro.

Agora, aquela faca invisível estava encostada no pescoço de Lu Linyuan.

E ele nem sabia a quem implorar misericórdia.

*

Depois de deixar o Palácio Chaoyang, Ning Xiaoxiao não conseguia se livrar da sensação de que havia algo errado.

Àquela hora da noite, com Ren Duanli e Chu Xingran fora do palácio, aonde Lu Linyuan poderia ter ido?

Por alguma razão, parecia haver uma força invisível insistindo para que ela voltasse.

Por fim, incapaz de suportar a inquietação, decidiu procurar Sanfu e perguntar pelo paradeiro do imperador.

Quando chegou ao portão, Sanfu estava voltando do Departamento de Assuntos Internos.

Ao encontrá-la, ele se curvou com um sorriso bajulador: — Ora, Concubina Hua! O que a traz aqui a uma hora dessas?

E, erguendo as sobrancelhas com uma expressão maliciosa, acrescentou: — Sentiu saudade de Sua Majestade?

— Onde você se meteu a essa hora, em vez de servir o imperador? — perguntou Ning Xiaoxiao.

— Sua Majestade pretende trazer a imperatriz-viúva de volta ao Palácio Xianshou antes da viagem à residência das fontes termais. Fui mandar preparar tudo, é claro!

A imperatriz-viúva era, afinal, a mãe de Lu Linyuan. Por mais que Ning Xiaoxiao detestasse aquela velha bruxa, não cabia a ela impedir que ele cumprisse os deveres filiais. Por isso, limitou-se a perguntar: — E o imperador? Para onde foi?

— Sua Majestade? — Sanfu hesitou, espantado. — Não está nos aposentos?

O coração de Ning Xiaoxiao deu um salto. Cada vez mais, algo lhe parecia errado.

Sanfu quis ir verificar, mas ela pensou que, se Lu Linyuan realmente estivesse preso na câmara secreta que construíra, seria um tanto humilhante se a história viesse a público.

Por isso o impediu: — Se está nos aposentos, ótimo. Eu mesma vou entrar. Não se meta onde não foi chamado, senhor Sanfu.

A expressão “não se meta” despertou imediatamente o espírito fofoqueiro de Sanfu. Ele recuou, curvando-se e fazendo um gesto de convite: — Sim, sim! Que distração a minha! Por aqui, Concubina Hua.

Assim que entrou nos aposentos, Ning Xiaoxiao trancou a porta por dentro.

Apressou-se até a estante, afastou-a e encostou o ouvido na parede, atenta a qualquer ruído vindo de trás dela.

Ouviu uma respiração quase imperceptível. Sem saber ao certo se era a de Lu Linyuan, chamou através da parede: — Majestade, está aí dentro?

Naquele estado, Lu Linyuan já não conseguia ouvir nada além das vozes de suas próprias alucinações.

O suor encharcara suas vestes imperiais amarelas. Ainda encolhido num canto, apertava os ouvidos com tanta força que a pressão parecia prestes a romper-lhe os tímpanos.

Já não distinguia as lembranças que lhe atravessavam a mente da realidade ao redor.

Em sua cabeça, voltara a ser a criança que a imperatriz-viúva prendia com correntes e chicoteava. Não conseguia fugir, e ela sequer lhe permitia chorar.

Restava-lhe fechar os pequenos punhos, sufocar a dor e as lágrimas e suplicar que a mãe parasse de bater nele.

— Mãe...

— Mãe, minha consorte...

— Seu filho errou... Por favor, não bata mais em mim...

— Dói...

As palavras saíam entrecortadas, como soluços vindos das profundezas da terra.

Quando sua mente estava prestes a se despedaçar...

A porta se abriu.

Com esforço, Ning Xiaoxiao puxou a porta da câmara secreta. Por um instante, a luz intensa das velas dos aposentos pareceu se transformar em sol, iluminando a figura arrasada de Lu Linyuan.

E Ning Xiaoxiao era aquele sol.

Nunca o vira tão desamparado. Os cabelos negros estavam colados ao rosto pelo suor, a pele, lívida. De olhos cerrados e sobrancelhas contraídas, tremia sem parar e murmurava súplicas, como se implorasse que alguém deixasse de espancá-lo.

Naquele instante, Ning Xiaoxiao esqueceu todo o resto.

Não queria saber o que acontecera com ele, nem o que acabara de enfrentar.

Sabia apenas que ele estava apavorado e que precisava ficar a seu lado.

Sem hesitar, agachou-se, envolveu Lu Linyuan num abraço apertado e afagou-lhe as costas. Então disse, com a voz mais suave e acolhedora do mundo:

— Não tenha medo, Majestade... Estou aqui.

Sua voz foi como um raio de luz ardente que devolveu calor ao coração congelado de Lu Linyuan.

Ele enterrou o rosto no peito dela, como uma criança indefesa, esforçando-se para conter o choro.

Ning Xiaoxiao continuou abraçada a ele até que os tremores diminuíram e sua respiração voltou ao ritmo normal.

Só então ele recuperou a consciência do que o cercava e ergueu lentamente a cabeça, encontrando os olhos dela.

No olhar de Ning Xiaoxiao não havia susto nem espanto; apenas preocupação e carinho.

— Está se sentindo melhor, Majestade?

Lu Linyuan assentiu e se levantou com a ajuda dela.

Foi então que, das profundezas da passagem secreta, voltou a soar o entrechocar de correntes. Instintivamente, Ning Xiaoxiao tentou espiar a escuridão.

Quase por reflexo, Lu Linyuan ergueu a mão para cobrir-lhe os olhos e disse, ainda com a voz fraca:

— Não olhe. Este lugar é imundo. Vai sujar seus olhos.

Ela assentiu obedientemente, ajudou-o a se sentar num assento aquecido e lhe serviu uma xícara de chá quente. — Beba um pouco, Majestade. Vai fazer bem à garganta.

Em vez de pegar a xícara, ele pousou a mão sobre a dela e murmurou: — Acabei assustando você.

— Não. — Ning Xiaoxiao balançou a cabeça com firmeza. — Já está melhor?

— Sim. — Ele assentiu, mas evitou encontrar os olhos dela. Parecia uma criança que fizera alguma coisa errada. Depois de hesitar longamente, perguntou, com dificuldade:

— Você... tem medo de mim?

— Pfft!

Ao ouvi-lo, Ning Xiaoxiao soltou uma gargalhada. — Por que eu teria medo de Vossa Majestade?

Ela estendeu a mão e acariciou-lhe os cabelos da testa, como quem faz carinho num lobo enorme e dócil:

— Fica tranquilo! Todo mundo tem medo de alguma coisa. Ter medo do escuro não é nenhuma vergonha.

— Pode ficar sossegado, Majestade. Não vou gostar menos de você por isso.

O coração gelado de Lu Linyuan começou a se aquecer outra vez. Com a ponta dos dedos, ele acomodou atrás da orelha uma mecha rebelde do cabelo dela e disse, tão baixinho que mal se ouviu:

— Obrigado.

Brincar e provocar era da natureza de Ning Xiaoxiao. Ela fez uma careta travessa e se aproximou, protegendo uma orelha com a mão enquanto fingia surdez:

— Hein? O que o imperador disse? Não ouvi!

Lu Linyuan inclinou-se para a frente. O hálito quente roçou a penugem da orelha dela, fazendo cócegas.

Então sua voz grave, de timbre irresistível, soou bem junto ao ouvido de Ning Xiaoxiao:

— Fique aqui comigo esta noite.

— Pode ser?

——— Pausa para falar de coisas sérias ———

PS: Como hoje já escrevi palavras suficientes, cá estou eu outra vez para dizer umas coisinhas.

Eu escrevo romance de época. Não é porque a história é uma comédia absurda que vocês devem esquecer que se passa na Antiguidade.

Não venham discutir comigo que o protagonista é cruel, que o escravo chamado Zhinu é inocente e coisas do gênero.

O protagonista é um imperador, um homem de outra época, não alguém com a mentalidade moderna. A imperatriz-viúva matou a mãe biológica dele; naquela época, ele poderia até mandar exterminar os nove graus de parentesco da família materna dela. Então não me venham com esse discurso de que a família não deve pagar pelos crimes de alguém.

E tem mais: posso passar um dia escrevendo sem ganhar nem um centavo de determinado leitor, mas desde aquela história da pulseira e, agora, por causa do tirano, apareceu um monte de gente para me atacar.

Basta eu escrever alguma coisa que não agrada a alguém e começam os insultos. Hoje nem sei quantas mensagens recebi de gente pondo nas minhas costas as ações do protagonista, me acusando de não ter valores morais.

Antes perguntavam o que o filho tinha a ver com os erros da imperatriz-viúva. Agora, se vocês acham erradas as atitudes do protagonista, o que EU tenho a ver com isso? Eu não sou ele!

Se eu ao menos ganhasse dinheiro para ser xingada, vá lá. Mas nem ganho, e ainda precisam me atacar dizendo que não tenho princípios?

Tenho tantos leitores que seria impossível escrever exatamente o que cada um quer. Se a história realmente ofendeu você, se desperdicei tanto do seu tempo e causei desconforto, então peço desculpas.

Desejo que todos sejam pessoas gentis, com menos hostilidade — não só aqui comigo.

Por trás dos romances que vocês leem há incontáveis dias e noites de trabalho dos autores. Existem tantos livros por aí: se não gostarem deste, procurem outro de que gostem. Desculpem pelo tempo de leitura que sentiram ter perdido.

Por fim, tanto a quem vai continuar lendo quanto a quem pretende parar, desejo uma vida tranquila e tudo de bom.

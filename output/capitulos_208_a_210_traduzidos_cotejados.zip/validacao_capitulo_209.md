# Validação — Capítulo 209

- **Fonte primária:** `novel_capitulos_181_a_211(20261105-152737).docx` — chinês tradicional.
- **Limites no DOCX:** parágrafos de índice base zero **1817** a **1919** (excluindo os vazios do cotejo).
- **Unidades não vazias:** **100**, incluindo título e eventuais notas da autora.
- **CSV:** cabeçalho exato `indice_docx,original_chines,traducao_portugues`; **100** linhas de dados.
- **Verificações automatizadas:** índices iguais à extração do DOCX; ausência de duplicações e de campos vazios; texto dos campos iguais aos utilizados para montar a tradução integral em Markdown.
- **Decisões editoriais:** A primeira nota autoral informa alteração do ritmo de publicação a partir de 1º de agosto (data da obra, não a data desta tradução). O comentário final da autora sobre Pausar/Retroceder foi preservado; ela esclarece que Ning não se esqueceu dessas funções, sem antecipar o próximo capítulo. A expressão 21劫 é um jogo humorístico ambíguo, vertido como “vinte e uma provações” sem lhe atribuir explicação não comprovada.
- **Limitação:** a validação 1:1 comprova a cobertura estrutural dos parágrafos, não a perfeição da tradução em cada frase. Tradução e revisão contextual feitas no mesmo processo, sem segunda auditoria semântica independente integral.

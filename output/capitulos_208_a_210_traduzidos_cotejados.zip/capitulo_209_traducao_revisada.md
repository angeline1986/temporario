# Capítulo 209 — Desta vez, ela não vai escapar

(Hoje haverá apenas uma atualização: vou me encontrar com leitores. Amanhã, 1º de agosto, passarei de dois para três capítulos por dia. Amo vocês!)

As cinco palavras “fique aqui comigo esta noite” continuavam ecoando sem parar na cabeça de Ning Xiaoxiao.

Ela sabia muito bem o que ele queria dizer, mas insistiu em se fazer de desentendida:

— Claro! Quer que eu fique para fazermos o quê? Jogar go, jogar cartas ou dançar “Te Amo”?

— Dormir.

— ...

Era a primeira vez que Lu Linyuan fazia um pedido daqueles de maneira tão direta.

Até então, ou inventava algum pretexto para atrair Ning Xiaoxiao ao Palácio Chaoyang e depois prendê-la ali com desculpas nas quais nem ele acreditava;

ou aparecia nos aposentos dela para bancar o folgado: dizia que Ning Xiaoxiao devia aquecer sua cama e depois ir dormir no assento aquecido. Mas quando foi que não ficou acordado até ela adormecer de exaustão, para então se enfiar debaixo das cobertas?

《A outra pessoa enviou um convite para “dividir a cama”. Ning Xiaoxiao hesitou por um instante e apertou “Recusar”.》

— Melhor deixar essa história de dormir para lá, não? Eu me mexo muito à noite e tenho medo de incomodar Vossa Majestade...

Lu Linyuan ergueu os olhos e a encarou.

O rosto estava marcado pelo cansaço; as partes brancas dos olhos, tomadas por veias avermelhadas. Ele comprimiu os lábios, adotou uma expressão digna de pena e começou a fazer o papel do chá-verde mais dissimulado do mundo:

— Você sabe que tenho medo do escuro e ainda assim tem coragem de me deixar sozinho?

Ao dizer isso, entrelaçou o mindinho no dela e baixou a voz: — Estou com medo...

Está com medo?

Com medo é o caralho!

Mas, como diz o ditado, quando um homem sabe fazer charme, a alma da esposa vai pelos ares!

Ning Xiaoxiao não suportava aquela carinha sofrida. Mesmo sabendo que ele estava fingindo, não conseguia rejeitá-lo.

Ou talvez essas também fossem desculpas que inventava para si mesma.

Porque, no fundo... ela também queria dormir com Lu Linyuan.

Na câmara secreta, Lu Linyuan transpirara tanto que, de tanto abraçá-lo e ajudá-lo a andar, Ning Xiaoxiao também acabara coberta de suor.

Embora o suor daqueles personagens de papel tivesse cheiro de perfume de luxo, eles próprios não pensavam assim.

Lu Linyuan ordenou que Sanfu preparasse uma tina de banho e mandou Ning Xiaoxiao se lavar e trocar de roupa no aposento lateral.

Entre nuvens de vapor, nada melhor do que água quente para aliviar o cansaço.

Quando saiu limpa e trocada, descobriu que Lu Linyuan continuava à espera diante da porta.

— Majestade? Ainda não tomou banho?

— Vou agora.

Lu Linyuan passou por ela e seguiu direto para o aposento lateral.

Mas... lá dentro só havia uma tina de banho!

E ela acabara de usar aquela água. Como ele pretendia se lavar?

— Majestade... — Ela o chamou. — Sanfu preparou uma tina só. Não seria melhor pedir outra?

Lu Linyuan olhou por cima do ombro e sorriu: — Não precisa. No inverno, a água é escassa. Vou usar a mesma que você.

Em seguida, aproximou o nariz do pescoço de Ning Xiaoxiao, inspirou suavemente e, satisfeito, foi embora.

Ning Xiaoxiao: ￣□￣｜｜

【ESCASSA É O CACETE!】

【Você, que tem mania de limpeza em estágio terminal e toma dois banhos por dia até no inverno, agora vem me falar em economizar água?!】

【Você...】

De repente, percebeu alguma coisa e ficou imóvel, sem conseguir pensar.

Que barreira psicológica uma pessoa obcecada por limpeza precisaria superar para tomar banho na água usada por outra pessoa?

A menos que já considerasse aquela pessoa parte inseparável de si.

Lu Linyuan não tinha o menor pudor de se despir diante de Ning Xiaoxiao. Enquanto ela permanecia paralisada, ele já havia tirado toda a roupa.

Quando recobrou os sentidos e viu a cena, Ning Xiaoxiao fugiu em pânico. Lu Linyuan a observou escapar como um coelhinho assustado e murmurou, divertido:

— Fugindo de quê? Não é como se você nunca tivesse visto.

De repente, percebeu um detalhe e gritou na direção da porta:

— Ei! Se vai fugir, ao menos feche a porta para mim!

*

Mais tarde, quando Lu Linyuan voltou do banho, Ning Xiaoxiao já estava deitada na cama por livre e espontânea vontade.

Dormia do lado de dentro, junto à parede, de costas para ele, abraçada a um travesseiro que acabara de tirar do armário.

Ele sentou-se na beirada e chamou:

— Por que está abraçada a esse travesseiro?

— ...

— Estou falando com você.

— ...

Nenhuma resposta. A respiração dela era tranquila, como se estivesse dormindo.

Mas os pensamentos frenéticos faziam um barulho ensurdecedor na cabeça de Lu Linyuan:

【Estou fingindo bem, não estou? Sem falhas? Hmm... Será que devo roncar um pouquinho?】

【Ele até usou a mesma água do meu banho! Se eu não fingir que dormi, hoje não escapo de vinte e uma provações...】

Lu Linyuan contemplou as costas dela, que subiam e desciam suavemente conforme respirava, dividido entre o riso e o espanto.

Mas talvez fosse melhor assim. Enquanto ela fingia dormir, ele poderia desabafar tudo o que guardava no peito sem que nenhum dos dois precisasse ficar constrangido.

Deitou-se de lado, passou um braço ao redor de Ning Xiaoxiao e a puxou delicadamente para perto, acariciando a pele macia do braço dela.

Depois de permanecer assim em silêncio por algum tempo, começou a falar consigo mesmo, numa voz lenta e baixa:

— Sou imperador. Não posso ser fraco nem medíocre. Preciso ser perfeito para merecer a posição que ocupo.

— Mas, depois de conhecer você, entendi que nunca precisei ser perfeito.

— Posso falar palavrões sem me preocupar, comparecer à audiência com duas marias-chiquinhas, arrancar uma coxa de frango com as mãos e devorá-la com você... Posso fazer muitas coisas que antes jamais faria, ou sequer ousaria fazer.

— Também não preciso ser corajoso a todo instante. Posso deixar meus medos e lágrimas à mostra e permitir que as emoções humanas se manifestem naturalmente.

— Vivi tantos anos como uma pessoa fria... Só agora descobri que um ser humano de verdade tem calor.

— Sou muito grato por ter encontrado você. Graças a você, pude enfim ser eu mesmo.

— Quero ficar sempre ao seu lado e espero... que você também queira permanecer ao meu.

— Em vez de ficar abraçada a esse maldito travesseiro!

Ele esticou o braço por cima de Ning Xiaoxiao, arrancou-lhe o travesseiro dos braços e o jogou no chão.

Depois, virou-a delicadamente de frente para si e colocou a mão dela sobre o próprio peito.

— Se gosta de abraçar alguma coisa para dormir, de agora em diante abrace a mim.

— Sou quentinho, gostoso de apertar e, de quebra, estou vivo.

— Na primavera, posso lhe contar histórias. No verão, espantar os mosquitos. No outono, cobri-la com o edredom. E, no inverno, aquecê-la.

Ele inclinou ligeiramente a cabeça para beijar a testa da mulher amada, que agora dividia também seu travesseiro:

— Boa noite, meu pequeno sol.

Cada uma das palavras de Lu Linyuan havia acertado em cheio o coração de Ning Xiaoxiao.

Quando o amor é recíproco, cada um sempre sente que o outro oferece muito mais do que recebe.

Para Ning Xiaoxiao era assim: tudo de belo que existia no mundo estava ligado a Lu Linyuan. Desde o começo, fora ele quem aceitara todas as suas excentricidades e a mimara a ponto de transformá-la numa pequena louca sem limites.

Ela esperou em silêncio até que a respiração de Lu Linyuan ficasse profunda, sinal de que adormecera. Só então apertou um pouco mais o braço que repousava sobre ele e o abraçou com cuidado para não acordá-lo.

E respondeu à pergunta que ele fizera, num sussurro mais baixo que um zumbido de mosquito:

— Vou ficar sempre ao seu lado. Para sempre, sempre.

Ela não era boa com declarações de amor. Só de dizer aquilo em voz alta já ficava toda arrepiada de vergonha.

Mas a humilhação suprema ainda estava por vir.

Lu Linyuan, que supostamente dormia profundamente, abriu os olhos de repente, apertou a mão dela contra o próprio peito e virou o rosto para encará-la com um sorriso provocador:

— Você só deixa de fazer pose depois que eu dou o primeiro passo, não é?

Ning Xiaoxiao ficou em choque: 【Esse miserável agora também faz ataques-surpresa?!】

Ela torceu o punho, tentando se soltar, mas, no instante seguinte, viu Lu Linyuan virar-se sobre ela. Seu corpo a cobriu como uma montanha.

O luar atravessava obliquamente a janela treliçada e iluminava-lhe o rosto. A pele era clara e fria; os lábios, avermelhados. O hálito quente roçou as bochechas de Ning Xiaoxiao:

— Já fui piedoso e deixei você escapar tantas vezes.

— Desta vez, não vai fugir.

*

Esclarecimento carinhoso da autora:

Mas ela pode Retroceder ou Pausar, não pode?

Será que se esqueceu?

Não se esqueceu, não.

E, aproveitando, vou me xingar por vocês: autora que interrompe a cena assim merece o pior!

Reunião encerrada!

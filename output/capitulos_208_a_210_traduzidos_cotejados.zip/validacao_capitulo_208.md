# Validação — Capítulo 208

- **Fonte primária:** `novel_capitulos_181_a_211(20261105-152737).docx` — chinês tradicional.
- **Limites no DOCX:** parágrafos de índice base zero **1726** a **1816** (excluindo os vazios do cotejo).
- **Unidades não vazias:** **88**, incluindo título e eventuais notas da autora.
- **CSV:** cabeçalho exato `indice_docx,original_chines,traducao_portugues`; **88** linhas de dados.
- **Verificações automatizadas:** índices iguais à extração do DOCX; ausência de duplicações e de campos vazios; texto dos campos iguais aos utilizados para montar a tradução integral em Markdown.
- **Decisões editoriais:** O capítulo preserva integralmente a longa nota final da autora, como parágrafos separados, inclusive sua defesa do contexto histórico ficcional e comentários sobre a recepção dos leitores. A fala infantil 母妃 conserva o caráter de tratamento materno de consorte. Não transformar as alucinações do imperador em fatos atuais.
- **Limitação:** a validação 1:1 comprova a cobertura estrutural dos parágrafos, não a perfeição da tradução em cada frase. Tradução e revisão contextual feitas no mesmo processo, sem segunda auditoria semântica independente integral.

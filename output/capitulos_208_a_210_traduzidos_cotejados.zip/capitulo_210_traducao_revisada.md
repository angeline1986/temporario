# Capítulo 210 — Rolou... mas não rolou de verdade

No inverno da dinastia Qi, era comum que vento e neve aparecessem de repente no meio da noite.

Mas naquela noite o Palácio Chaoyang estava especialmente aconchegante.

Enquanto o vento gelado fazia as janelas treliçadas estremecerem, Lu Linyuan se aproximava pouco a pouco da jovem sob seu corpo, até pousar os lábios sobre os dela, macios e doces.

Seu beijo era delicado, mas Ning Xiaoxiao continuava visivelmente nervosa.

Ela agarrava o travesseiro com tanta força que amarrotava o tecido de seda, formando uma confusão de vincos.

Lu Linyuan pousou a mão direita, de dedos longos e juntas marcadas, sobre a mão esquerda dela e a acariciou de leve, tentando aliviar-lhe a tensão.

Quando a sentiu relaxar, segurou-lhe a mão e, aproveitando a oportunidade, entrelaçou os cinco dedos aos dela, apertando-os com firmeza.

Em todo o tempo que se conheciam, já haviam andado de mãos dadas inúmeras vezes. Ainda assim, era a primeira vez que entrelaçava os dedos aos da pessoa amada.

Havia algo de indescritivelmente especial nisso, como uma alma que vagara solitária por muito tempo e enfim encontrara sua metade perfeita. A adrenalina fazia a temperatura subir, a respiração acelerar e os rostos corarem.

Era o prelúdio de uma onda de prazer.

Entre um beijo e outro, Lu Linyuan prendeu delicadamente o lábio da jovem entre os dentes e lhe deu uma mordidinha.

— Hum...

Ning Xiaoxiao soltou um gemido suave e manhoso. Era impossível saber se sentira dor ou se estava fazendo charme, dividida entre recuar e corresponder.

Lu Linyuan interrompeu o beijo depressa e apertou os próprios lábios, como se saboreasse a lembrança.

Roçou a ponta do nariz no arco dos lábios dela e abriu um sorriso cheio de carinho. A voz rouca trazia um toque de persuasão:

— Doeu?

— Não tenha medo. Não vou fazer nada que deixe minha Xiaoxiao desconfortável.

Então, com um gesto um pouco brusco, arrancou a própria roupa de dormir e a atirou ao chão, expondo o peito e os músculos bem definidos.

Ning Xiaoxiao fitou o homem à sua frente, metade banhado pelo luar, metade iluminado pelas velas, e não conseguiu evitar engolir em seco.

Essa viagem para dentro de um livro valeu cada segundo!

Seu rosto estava vermelho de vergonha, mas Lu Linyuan percebeu sem dificuldade a cobiça estampada no olhar dela.

Ele não tinha a menor intenção de esconder da pequena esposa o corpo esculpido por anos de artes marciais. Ao contrário: sentindo os olhos dela sobre si, contraiu de propósito os músculos para tornar o espetáculo ainda mais impressionante.

Não era a primeira vez que Ning Xiaoxiao contemplava aquele físico. Ainda assim, toda vez parecia uma experiência inteiramente nova.

Resumindo:

— Nunca se cansava de olhar.

Vendo seus olhos brilharem como os de uma gata faminta diante de um pote de ração, Lu Linyuan também começou a sentir vontade.

Seu sorriso se alargou.

— Então, vai ficar só olhando?

— !!!

Ning Xiaoxiao sempre fora uma fera nas palavras e uma completa novata na prática.

Em voz alta ou nos próprios pensamentos, adorava soltar todo tipo de provocação indecente. Mas, quando chegava a hora de verdade, virava uma noiva muda, incapaz de articular uma palavra.

Desviava os olhos e recolhia os dedos, como se Lu Linyuan fosse uma labareda: quente demais para olhar ou tocar.

Quanto mais ela reagia assim, mais irresistivelmente sedutora parecia aos olhos dele.

Ele se inclinou até seu ouvido. A barba recém-nascida roçou a cartilagem delicada e fez cócegas.

— Está com vergonha? — perguntou.

— ...

Ele beijiscou o lóbulo da orelha dela, aproximou-se ainda mais e, com toda a delicadeza, começou a tirar-lhe as vestes externas.

Lá fora, o vento aumentou. Uma das janelas treliçadas, que não estava trancada, se abriu de repente, deixando entrar flocos de neve grandes e leves como penas.

Lu Linyuan franziu a testa.

Até os céus pareciam decididos a atrapalhar seu romance.

Ele nunca se esquecia de que Xiaoxiao sofria com cólicas menstruais e era sensível ao frio. Por isso, reprimiu o fogo que sentia no peito, puxou o edredom e a envolveu cuidadosamente dos pés à cabeça.

Naquele instante, ela se parecia ainda mais com uma gatinha.

As bochechas estavam rosadas, uma mãozinha saía debaixo da coberta e agarrava uma ponta do tecido, enquanto os olhos enormes, vivos e cintilantes o observavam.

Naquele olhar havia um pouco de inquietação, medo do desconhecido e também certa...

... expectativa tão discreta que quase passava despercebida.

O sorriso carinhoso de Lu Linyuan não desaparecera nem por um momento. Ele ajeitou cuidadosamente a coberta ao redor dela e, dobrando o dedo, deu-lhe uma leve batidinha na ponta do nariz.

— Fique bem coberta, para não passar frio. Vou fechar a janela.

Ele se levantou com as roupas de Ning Xiaoxiao nas mãos. Ao ver as chamas das velas dançando sobre a mesa, teve uma ideia e olhou por cima do ombro para sua preciosa amada: — Aproveito para apagar as luzes e tratar dessa sua “doença” chamada timidez.

Caminhou até a janela e, de passagem, pendurou as roupas de Ning Xiaoxiao no suporte junto à cabeceira.

O vento forte fez a capa de brocado de Shu esvoaçar, desenhando uma silhueta azulada na escuridão da noite.

Enquanto isso, Ning Xiaoxiao permanecia deitada, tentando se preparar psicologicamente.

Afinal, diante de uma experiência inteiramente nova, era natural que a expectativa viesse acompanhada de nervosismo.

Ainda mais quando a novidade era tão extraordinária e... especialmente bem-dotada.

Perdida nesses pensamentos e olhando fixamente para as pinturas de nuvens auspiciosas e dragões no dossel da cama, não percebeu que o saquinho de pó da invisibilidade recebido da grande roleta acabara de cair de suas roupas.

A embalagem era um embrulho muito simples de papel oleado, com apenas uma pitada de pó sem cor nem cheiro.

Ao cair, uma das dobras do papel se abriu. O vento frio levantou o pó e o soprou diretamente contra o rosto de Ning Xiaoxiao. A cada inspiração, ele entrou silenciosamente por suas narinas.

Lu Linyuan fechou e trancou a janela, apagou as seis velas acesas nos aposentos e se lançou de volta à cama, impaciente.

Só que... caiu no vazio?!

Passou as mãos por toda a cama, procurando desesperadamente. O edredom ainda estava quente, mas Ning Xiaoxiao, uma pessoa de carne e osso, simplesmente desaparecera diante de seus olhos enquanto ele fechava a janela!

Mas que inferno! Cadê ela?!

Mais de uma vez, as mãos de Lu Linyuan atravessaram diretamente o corpo de Ning Xiaoxiao.

Ela parecia uma projeção holográfica ou, melhor dizendo, um daqueles fantasmas invisíveis e intangíveis dos filmes de terror.

A própria Ning Xiaoxiao também se assustou. Só quando avistou o embrulho de papel aberto no chão entendeu tudo e soltou mentalmente um palavrão:

【Então era essa a pegadinha que aquela porcaria estava preparando para mim?!】

【Uma noite de amor vale ouro! Xiao Qi!!! SEU FILHO DA MÃE, DEVOLVE MEU DINHEIRO!】

Depois de ingerido, o pó da invisibilidade não tornava simplesmente a aparência de alguém invisível: transformava a pessoa num estado semelhante ao de uma alma. E o sistema era tão completo que até as roupas e joias usadas pela pessoa naquele dia desapareciam junto com ela.

Ninguém podia ver, tocar ou ouvir quem tivesse ingerido o pó da invisibilidade.

Naturalmente, nessas condições, Lu Linyuan também não conseguia ouvir os pensamentos de Ning Xiaoxiao.

Ele olhou instintivamente para o suporte de roupas, agora vazio. Então deixou os ombros caírem e soltou um suspiro tão discreto que quase não se ouviu.

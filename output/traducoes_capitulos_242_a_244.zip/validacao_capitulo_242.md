# Validação — capítulo 242

- **Fonte:** `novel_capitulos_212_a_270(20261105-204934).docx`, original chinês tradicional.
- **Limites no DOCX:** parágrafos com índices de 2085 (inclusive) a 2153 (exclusive); unidades não vazias: **65**.
- **Unidades do cotejo:** 65, incluindo o título e eventuais notas de autora.
- **Índices:** mantidos os índices originais de parágrafo no DOCX (base zero); sem ausências no intervalo não vazio, sem duplicações.
- **Campos:** nenhum original ou tradução vazio.
- **Coerência estrutural:** CSV e MD possuem 65 segmentos correspondentes e na mesma ordem.

## Decisões editoriais

A nota da autora sobre intoxicação por cogumelos foi traduzida como paratexto, sem atribuí-la a personagem. “Consorte Nobre” corresponde a 貴妃. Mantidos separadamente o plano, o ato e a expectativa de vingança de Gu Sijin. O conteúdo médico integra a ficção e não foi validado como orientação de saúde.

## Limites da validação

Este procedimento comprova cobertura e integridade estrutural 1:1. Houve revisão tradutória durante a redação, mas **não** uma segunda auditoria semântica independente integral. Não se reivindica precisão médica para a nota da autora.

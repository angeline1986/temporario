# Capítulo 242 — Então que a Consorte Yun seja enterrada com ela

— Por quê...?

A voz de Gu Sijin, embargada pelo choro, soava desesperada:

— Por que ela fez isso? Antes, eu até suportava que todos me maltratassem e humilhassem, mas o que Qiqi fez de errado? Por que nem ela foi poupada?!

Qiaqia tentou consolá-la: — Minha senhora, não fique assim. A culpa não é sua...

Lala disse: — Nós é que não protegemos Qiqi. Se naquele dia tivéssemos ido com ela ao Departamento de Assuntos Internos, em vez de ficarmos preparando a surpresa de aniversário, ela não teria...

Aquilo era como um espinho cravado no coração de Bengbeng.

Tinha sido ideia dele organizar a surpresa para o aniversário de Qiqi. Também tinha sido ele quem mandara a moça buscar sozinha as recompensas de Ano-Novo no Departamento de Assuntos Internos.

A culpa e a fúria explodiram de uma vez dentro dele, deixando apenas um pensamento:

Faria a Consorte Yun pagar com sangue!

Enxugou as lágrimas com a manga e disparou em direção à porta.

Gu Sijin o deteve com um grito: — Pare aí! Aonde pensa que vai? Enfrentar a Consorte Yun até a morte? Quer impedir Qiqi de descansar em paz até no outro mundo?

Bengbeng parou, o corpo estremecendo de soluços. — Eu só quero justiça. Só quero fazer justiça por Qiqi!

Quase gritou aquelas palavras entre lágrimas. Gu Sijin sentiu o coração estremecer. Não podia perder mais ninguém que estivesse ao seu lado.

Ela o alcançou rapidamente e segurou seu braço. — Você precisa continuar vivo para conseguir justiça por ela.

Ela compreendia: tinha sido ela quem levara Qiqi à morte.

Sua bondade e sua disposição para suportar tudo haviam convencido as mulheres do harém de que ela era dócil e fácil de pisotear.

Embora Xiaoxiao já tivesse sido promovida a Consorte Nobre, Qiqi acabara morrendo por causa dela.

Ela nunca procurava fazer mal a ninguém e, mesmo quando alguém a tratava com crueldade, preferia não guardar rancor.

Acreditava que sinceridade gerava sinceridade; era assim que as relações humanas deveriam ser. Não era desse modo que ela, Xiaoxiao e Qiqi se tratavam?

Mas por quê...?

Por que sua bondade se transformara, um dia, numa lâmina capaz de ferir as pessoas que ela mais amava?

As lembranças do passado vieram em ondas, revolvendo e rasgando suas certezas, destruindo e reconstruindo a visão de mundo daquela jovem de família ilustre.

Ela estava errada.

Completamente errada.

Ao lembrar todas as humilhações que sofrera desde que entrara no palácio, seu coração se tornou cada vez mais frio.

Se Xiaoxiao não houvesse permanecido ao seu lado durante todo aquele tempo, provavelmente já teria sido morta pelas conspirações de outras mulheres do harém.

Estava cansada de viver sendo humilhada. Também percebia que, se não refreasse sua compaixão sem limites, todos a quem estimava acabariam sofrendo por causa de seu coração de bodisatva.

*Bum!*

Um trovão sacudiu os céus da cidade imperial, e uma chuva inesperada começou a cair.

Era a primeira chuva na passagem do inverno para a primavera. As gotas geladas doíam ao atingir a pele.

Gu Sijin ergueu os olhos para as nuvens negras. Com os dedos delicados, enxugou as lágrimas, enquanto seu olhar se tornava implacável.

Consorte Yun...

Neste inverno rigoroso, Qiqi terá de percorrer sozinha o caminho para o outro mundo.

Pois vá fazer companhia a ela na morte!

*

Depois disso, Gu Sijin pediu a pessoas de fora do palácio que recuperassem o corpo de Qiqi no terreno onde eram abandonados os cadáveres. Encontrou um lugar auspicioso e providenciou um enterro digno.

Enterrou com ela a pulseira que pretendia lhe dar e o enfeite de cabelo que Bengbeng comprara para a jovem.

Na manhã seguinte, levantou-se cedo e se maquiou cuidadosamente diante do espelho. Não havia nela o menor sinal visível de tristeza.

Foi apresentar cumprimentos à imperatriz. Durante toda a visita, não mencionou Qiqi. Quando a Consorte Yun e as outras a ridicularizaram, aproveitando a promoção de Ning Xiaoxiao a Consorte Nobre, Gu Sijin manteve-se submissa e não respondeu a uma única provocação.

Terminada a audiência, voltou direto aos seus aposentos e trancou as portas do quarto.

Faltavam apenas alguns dias para o Ano-Novo, e o tempo já começava a esquentar. Não era mais necessário manter tantos braseiros acesos.

Ainda assim, ela acendeu sete ou oito braseiros no quarto, aquecendo o ambiente como se fosse pleno verão.

Tirou do armário um pacote de cogumelos orelha-de-pau secos, despejou-os numa bacia de cobre e observou-os absorver água e inchar pouco a pouco. Depois, colocou a bacia perto dos braseiros.

(PS: Se você não entendeu o que ela está fazendo, há uma explicação no fim do capítulo.)

Naquela manhã, ela conseguira secretamente a lista de pratos servidos à Consorte Yun pela cozinha imperial. Um deles, porco mu shu, aparecia com frequência.

Era um prato típico da terra natal de Yun, que o encomendava à cozinha imperial a cada poucos dias.

O porco mu shu, prato tradicional de Shandong, não era difícil de preparar: levava fatias de carne suína salteadas com ovos e cogumelos orelha-de-pau, e o molho era engrossado antes de servir, resultando num acompanhamento saboroso para o arroz.

Os cogumelos ficaram de molho por um dia e meio no quarto aquecido de Gu Sijin. Sua superfície começara a ficar viscosa, exalando um odor levemente desagradável.

Gu Sijin os lavou com cuidado três ou quatro vezes usando água com amido, até retirar a viscosidade e disfarçar o cheiro. Só então chamou Bengbeng.

Nos últimos dias, ele vinha procurando secretamente uma forma de vingar Qiqi. Gu Sijin percebera tudo.

Por isso, disse: — Está quase na hora de preparar as refeições. Vá à cozinha imperial e procure o cozinheiro Liu, que cuida das refeições da Consorte Yun e dos nossos aposentos.

Ela tirou uma nota de cinquenta taéis de prata e a entregou a ele.

— Dê-lhe esse dinheiro e peça que prepare uma boa refeição para nós. Depois, sem que ele perceba, substitua pelos daqui os cogumelos que ele usará hoje à noite no porco mu shu da Consorte Yun.

— Sei que você gostava de Qiqi e quer vingá-la. Mas uma vingança não pode custar sua própria vida. Entendeu?

Bengbeng ficou surpreso por um instante. Jamais imaginara que a própria Gu Sijin agiria contra a Consorte Yun.

Logo, porém, recebeu os cogumelos com lágrimas nos olhos e prometeu que faria tudo direito.

Sempre fora esperto, e não decepcionou Gu Sijin: em menos de meia hora, já havia cumprido a tarefa e retornado.

Naquela noite, depois de receber o dinheiro de Gu Sijin, a cozinha imperial preparou um verdadeiro banquete para o Palácio Fengyi.

Gu Sijin convidou Qiaqia, Lala e Bengbeng a se sentarem. Senhora e criados reuniram-se à mesa, mas o lugar de honra permaneceu vazio.

Era o lugar de Qiqi.

Aquela refeição era apenas uma forma de oferecer à jovem, morta injustamente, a comemoração de aniversário que lhe fora negada.

Gu Sijin não costumava beber, mas naquela noite bebeu bastante.

Bêbada, caiu na cama e adormeceu, tentando não pensar em nada que a fizesse chorar.

(PS da autora: Cogumelos orelha-de-pau deixados de molho de um dia para o outro podem desenvolver colônias de bactérias, sobretudo em temperaturas elevadas. Segundo a explicação da autora, o período de incubação desse tipo de intoxicação costuma ser de meio dia a um dia. No início, a pessoa apresenta apenas sintomas leves, como náuseas, vômitos, diarreia, tontura e fraqueza generalizada, mas logo podem surgir icterícia, aumento do fígado, sangramentos sob a pele, vômito com sangue e alterações de consciência. Quando se ingere uma quantidade mínima, uma intoxicação leve ainda pode ser tratada com recursos da medicina moderna; porém, se houver ingestão excessiva e intoxicação grave, nem mesmo a medicina atual consegue salvar a pessoa. Fica a dica prática para vocês, meus amores: no futuro, lembrem-se de não comer cogumelos orelha-de-pau deixados de molho de um dia para o outro.)

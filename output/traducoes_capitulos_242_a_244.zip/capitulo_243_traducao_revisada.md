# Capítulo 243 — Qiqi voltou

Na manhã seguinte, quando foi ao Palácio Fengluan apresentar cumprimentos à imperatriz, Gu Sijin reparou que a Consorte Yun não parecia nada bem.

Sentada em seu lugar, Yun tinha ânsias de vômito de tempos em tempos. Seu rosto estava assustadoramente pálido.

A imperatriz perguntou: — Consorte Yun, está se sentindo mal?

— Talvez eu tenha pegado um resfriado. Ontem dormi a noite toda com a janela aberta porque estava com calor. Não é nada grave — respondeu Yun.

A imperatriz disse, demonstrando preocupação: — Se está doente, peça logo a um médico imperial que a examine. Não deixe uma doença pequena se tornar algo grave.

Naquele mesmo dia, a caminho de seus aposentos depois da visita, a Consorte Yun desmaiou dentro de seu palanquim.

Bilian mandou chamar depressa um médico imperial. Assim que examinou o pulso da consorte, ele percebeu algo anormal, semelhante a um envenenamento.

A notícia se espalhou pelo palácio como uma explosão.

Yun estava ligada à imperatriz e era um de seus principais braços direitos.

Naturalmente alarmada, a imperatriz ordenou uma investigação minuciosa para descobrir como uma substância tóxica fora parar no estômago de Yun.

Mas todos os criados de Yun afirmaram que ela comera normalmente nos últimos dias, recebendo as refeições preparadas na cozinha imperial.

A única comida vinda de fora fora um prato de rolinhos de peônia presenteado pela imperatriz.

A cozinha imperial guardava amostras das refeições. Contudo, Bengbeng já havia entrado às escondidas e trocado a amostra do porco mu shu servido naquele dia, por ordem de Gu Sijin. Por isso, a investigação não encontrou nada suspeito ali.

Como os rolinhos de peônia haviam sido preparados nos próprios aposentos da imperatriz, não restara nenhuma amostra.

Assim, a imperatriz se tornou a principal suspeita.

Na verdade, o plano de Gu Sijin tinha falhas por toda parte. Bastaria que a imperatriz investigasse a fundo para seguir as pistas até o Palácio Fengyi.

Mas Gu Sijin sabia que ela não ousaria fazer isso.

Os rolinhos enviados pela imperatriz à Consorte Yun não continham veneno; continham, porém, uma dose considerável de medicamentos contraceptivos.

A imperatriz era calculista até com as mulheres que a apoiavam. Não admitiria que nenhuma delas desse à luz um herdeiro imperial antes dela. Depois de tantos anos de submissão e tantos medicamentos que lhe prejudicavam o corpo, talvez Yun nunca pudesse ter filhos.

Se investigasse até o fim, a imperatriz acabaria expondo suas próprias ações. Só lhe restava engolir aquele prejuízo em silêncio.

Sem descobrir a origem da intoxicação, os médicos não conseguiam indicar um tratamento adequado.

Enquanto os remédios se mostravam inúteis, o estado de Yun piorava dia após dia. Em apenas três dias, ela passou a vomitar sangue, e diversos órgãos sofreram danos pela intoxicação, causando-lhe um sofrimento terrível.

Quando pequena, Gu Sijin comera cogumelos orelha-de-pau deixados de molho de um dia para o outro e quase morrera.

Por isso conhecia a gravidade daquele risco.

Yun estava à beira da morte. Uma a uma, as consortes foram visitá-la, e a imperatriz mandou levar a notícia às pressas à residência das fontes termais, na esperança de que Lu Linyuan voltasse antes do fim e pudesse ao menos se despedir dela.

*

Naquela noite, enquanto organizava os pertences deixados por Qiqi no Palácio Fengyi, Gu Sijin ouviu lamentos de luto ecoarem por todo o harém.

A Consorte Yun havia morrido.

Diziam que, antes de morrer, ela vomitara tanto sangue que encharcara a cama e o chão. Seus olhos estavam saltados, e sua aparência na morte era horrível.

Por alguma razão, em vez de sentir medo ao ouvir aquilo, Gu Sijin experimentou uma satisfação que lhe brotava do fundo do peito.

Levou Bengbeng consigo e foi ainda naquela noite aos aposentos de Yun, para a despedida final.

Diante do corpo, chorou inconsolavelmente, exatamente como faria a Gu Sijin compassiva de antes.

Ao vê-la, a Consorte Li não resistiu a comentar com a Consorte Duan: — Ela nem era tão próxima de Yun. Por que está chorando desse jeito?

Duan soltou uma risada fria. — Você ainda não a conhece? Essa mulher teria pesadelos até se esmagasse uma formiga. Deixe-a fazer o que quiser.

Bilian era a criada-chefe dos aposentos de Yun e servia à família da consorte desde antes de sua entrada no palácio. As duas tinham um vínculo profundo.

Mesmo com os olhos inchados de tanto chorar, Bilian organizava os ritos fúnebres, correndo de um lado para o outro e insistindo em cuidar pessoalmente de tudo.

À meia-noite, dirigiu-se ao templo budista do palácio para buscar escrituras de oração pelos mortos, que seriam queimadas em homenagem a Yun.

Para chegar mais rápido, escolheu um atalho. No escuro, porém, alguém a puxou de repente e lhe tapou a boca.

À luz da lua, Bilian percebeu que Bengbeng era quem a segurava. Diante dela, de expressão feroz, estava Gu Sijin!

Gu Sijin pesou na mão a pedra que carregava e avançou devagar na direção de Bilian.

Os olhos de Bilian estavam cheios de terror. Bengbeng lhe tapava a boca com força, e seus grunhidos abafados eram incompreensíveis.

Gu Sijin levou o indicador aos lábios, exigindo silêncio.

— Psiu. Não faça barulho.

— Não quero ouvir suas explicações. Não me interessa se você matou Qiqi com um tijolo ou uma pedra, nem se a golpeou uma ou duas vezes.

— Só sei que você e a Consorte Yun eram profundamente apegadas uma à outra.

— Agora que Yun morreu, não vai querer ficar sem sua Bilian, vai?

Mal terminou de falar, sem a menor hesitação, desferiu um golpe violento com a pedra na testa de Bilian.

Uma vez, duas, três...

Só parou quando Bilian deixou de respirar. Então tirou um lenço, limpou com toda a calma o sangue das mãos e lançou um olhar a Bengbeng.

Entendendo o recado, ele arrastou o corpo de Bilian e o jogou num poço seco próximo.

*

Naquele momento, Gu Sijin não era a única pessoa que sofria: Ning Xiaoxiao também estava de coração partido.

Um mensageiro chegou à residência das fontes termais para dizer que a Consorte Yun estava morrendo, e perguntou se Lu Linyuan desejava regressar para vê-la.

Lu Linyuan respondeu friamente: — Se está doente, chamem um médico imperial! Por acaso eu sei curar doenças?!

Sentada ao lado dele, Ning Xiaoxiao estava prestes a rir quando ouviu o mensageiro acrescentar, constrangido:

— Há mais uma coisa... A criada-chefe dos aposentos de Sua Alteza, a Consorte Nobre, sofreu uma queda, bateu a cabeça numa pedra e... faleceu.

A afeição de Ning Xiaoxiao por Qiqi não era menor do que a de Gu Sijin.

Ao ouvir a notícia inesperada, ficou atônita por um longo tempo antes de conseguir reagir.

Lu Linyuan a abraçou, enxugando suas lágrimas incessantes. Fez tudo o que podia para consolá-la, desejando apenas aliviar sua dor.

Naquela noite, deitada nos braços dele, Ning Xiaoxiao não conseguiu dormir de jeito nenhum.

As lembranças dos momentos passados com Qiqi não saíam de sua cabeça. Lamentava não estar no palácio e não ter conseguido salvá-la como fizera com Lu Yiqiu.

Virou-se de lado e chorou até molhar o travesseiro. Xiao Qi, que já havia encerrado seu expediente, não suportou mais assistir àquilo:

【Hospedeira, Qiqi não era uma personagem da trama principal nem das tramas secundárias do romance original. Assim como Qiaqia, Bengbeng e Lala, ela recebeu um nome dado por você. Portanto, essas pessoas foram criadas por você depois de sua transmigração.】

【A hospedeira não pode alterar a vida ou a morte dos personagens do romance original. Mas pode decidir a vida ou a morte dos personagens que criou, modificando a trama.】

Ao ouvir aquilo, Ning Xiaoxiao sentiu que havia desperdiçado um litro inteiro de lágrimas.

【Seu Lao Liu desgraçado! Você tinha mesmo que esperar eu chorar até ficar com os olhos inchados para me contar isso?!】

Sem perder tempo discutindo com Xiao Qi, abriu depressa o documento da trama em sua mente e modificou cem caracteres da sequência dos acontecimentos.

Alterou as lembranças de todos, determinando que Qiqi tivesse ido desde o início com ela para a residência das fontes termais, em vez de permanecer no palácio.

Assim que terminou a alteração, ouviu uma voz meiga e familiar do outro lado da porta.

Era uma voz suave e baixinha, idêntica àquela que, no palácio, costumava acordá-la de madrugada para oferecer uma ceia:

— Xiaoxiao~ Preparei bolinhas de arroz doce com vinho de arroz fermentado. Quer comer?

Mal ouviu a voz de Qiqi, as lágrimas que Ning Xiaoxiao acabara de conter voltaram a transbordar.

Chorando de alegria, apressou-se em sair da cama para vê-la.

Mas, assim que se mexeu, a mão grande de Lu Linyuan voltou a prender sua cintura.

Sem abrir os olhos, ele murmurou, um tanto impaciente:

— Traga mais uma tigela. Eu também quero.

(Autora: Minha adorável Qiqi, eu jamais deixaria ela morrer! Meus amores, gostaram da montanha-russa emocional?~)

(Autora: Essa parte da trama terminou. Amanhã, a mãe da Xiaoxiao vem passar férias na residência das fontes termais!~)

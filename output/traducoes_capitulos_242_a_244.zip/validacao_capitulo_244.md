# Validação — capítulo 244

- **Fonte:** `novel_capitulos_212_a_270(20261105-204934).docx`, original chinês tradicional.
- **Limites no DOCX:** parágrafos com índices de 2235 (inclusive) a 2309 (exclusive); unidades não vazias: **71**.
- **Unidades do cotejo:** 71, incluindo o título e eventuais notas de autora.
- **Índices:** mantidos os índices originais de parágrafo no DOCX (base zero); sem ausências no intervalo não vazio, sem duplicações.
- **Campos:** nenhum original ou tradução vazio.
- **Coerência estrutural:** CSV e MD possuem 71 segmentos correspondentes e na mesma ordem.

## Decisões editoriais

Mantida a explicação do mecanismo de autocorreção do sistema, que reconstrói as causas da morte de Yun e Bilian após a alteração retroativa. A nova versão explicita que Bengbeng não participou. “Dudou” foi adaptado como peça íntima; “mania de limpeza” preserva a brincadeira afetiva, sem inventar homofonia chinesa.

## Limites da validação

Este procedimento comprova cobertura e integridade estrutural 1:1. Houve revisão tradutória durante a redação, mas **não** uma segunda auditoria semântica independente integral. Não se reivindica precisão médica para a nota da autora.

# Validação — capítulo 243

- **Fonte:** `novel_capitulos_212_a_270(20261105-204934).docx`, original chinês tradicional.
- **Limites no DOCX:** parágrafos com índices de 2153 (inclusive) a 2235 (exclusive); unidades não vazias: **79**.
- **Unidades do cotejo:** 79, incluindo o título e eventuais notas de autora.
- **Índices:** mantidos os índices originais de parágrafo no DOCX (base zero); sem ausências no intervalo não vazio, sem duplicações.
- **Campos:** nenhum original ou tradução vazio.
- **Coerência estrutural:** CSV e MD possuem 79 segmentos correspondentes e na mesma ordem.

## Decisões editoriais

Mantido o contraste entre a ação executada na primeira linha temporal e a reescrita posterior. A afirmação de Xiao Qi de que certos personagens foram criados pela hospedeira é fala do sistema. Notas metanarrativas finais mantidas como notas autorais.

## Limites da validação

Este procedimento comprova cobertura e integridade estrutural 1:1. Houve revisão tradutória durante a redação, mas **não** uma segunda auditoria semântica independente integral. Não se reivindica precisão médica para a nota da autora.

# Capítulo 244 — A palavra “mania de limpeza” tinha um significado bem específico

Ning Xiaoxiao abriu a porta do quarto. Qiqi estava ali, diante dela, sã e salva.

Era uma jovem adorável, com olhos grandes, redondos e inocentes, um narizinho arrebitado e bochechas fofas como pãezinhos, que davam vontade de apertar.

Ning Xiaoxiao não conseguia descrever o que sentia. Abraçou Qiqi com força, deixando a moça um tanto surpresa com aquela atitude incomum:

— Xiaoxiao... O que aconteceu com você?

Ning Xiaoxiao não respondeu; apenas escondeu um sorriso no rosto.

Mas, antes que pudesse abraçá-la por muito tempo, uma força autoritária separou seus braços dos de Qiqi.

Com o olhar frio, Lu Linyuan fez Ning Xiaoxiao passar os braços ao redor de seu pescoço, virou-lhe a cabecinha e a puxou contra o próprio peito. Só então disse a Qiqi:

— Não é nada. Sua senhora está tendo um ataque de maluquice. Vá preparar a comida.

— ...

Desde que começara a namorar Lu Linyuan, aquele pobre coitado parecia fazer questão de marcar território a todo instante.

Outro dia, ela trocara apenas algumas palavras a mais com Ren Duanli, e Lu Linyuan o trancara por três dias no Pavilhão Xiaoyao de Lu Yiqiu, proibindo-o de sair. A desculpa era que Lu Yiqiu precisava “dar um jeito nele”.

Hoje, bastara abraçar Qiqi por tempo demais para o ciúme dele aflorar outra vez.

O pior é que ele era teimoso demais para admitir que estava com ciúmes. Preferia usar sua mania de limpeza como pretexto:

— Você já se lavou, mas Qiqi acabou de sair da cozinha, com cheiro de fumaça e gordura por todo o corpo. Se a abraça usando roupa de dormir, esse cheiro não vai passar para você?

Ning Xiaoxiao revirou os olhos, sem paciência. — Ah, claro, claro. Então Vossa Majestade está dizendo que eu sou suja?

Lu Linyuan: — ...Não.

— Se não acha que sou suja, então está com ciúmes, não está?

Lu Linyuan: — ...

Mais tarde, Qiqi trouxe duas tigelas de bolinhas doces de arroz fermentado. Ning Xiaoxiao comeu com satisfação e não se esqueceu de elogiar:

— Sua comida está cada vez melhor. Acho que ficou até mais gostosa que a dos cozinheiros imperiais.

— Cof, cof. — Lu Linyuan pigarreou, mexendo o conteúdo da tigela com a colher. — Para mim está mais ou menos. Doce demais, chega a enjoar. Ainda dá para melhorar.

Ning Xiaoxiao olhou de soslaio para a tigela dele, quase vazia.

Aquilo era “mais ou menos”? Ele tinha comido até mais do que ela!

...

Só depois que terminaram a ceia e Qiqi levou as tigelas e os talheres é que o imperador pareceu finalmente ter saciado seu ciúme por aquela noite.

— Faltam três dias para o Ano-Novo. Amanhã, se não tivermos nada para fazer, venha passear comigo.

E acrescentou: — Vamos à cidade de Xifeng.

Ora, ora. Ele ainda não tinha esquecido a história de comprar umas peças íntimas para ela, tinha?

Mas Ning Xiaoxiao, criada no século XXI, nunca fora uma garota muito tradicional.

Naquele dia, vira as peças íntimas que a princesa mais velha comprara para Huanü. E, pensando bem, aquelas peças sensuais eram mesmo muito mais bonitas do que as tradicionais.

Mostravam o que deviam mostrar e cobriam o que deviam... Bem, pensando melhor, quase não cobriam nada.

De qualquer modo, seriam usadas para o homem que amava. Ao ver a expectativa nos olhos de Lu Linyuan, magnanimamente concordou.

Um espanto fugaz brilhou nos olhos de Lu Linyuan. Evidentemente, ele não imaginava que Ning Xiaoxiao aceitaria tão facilmente e embarcaria naquela sua “armadilha”.

Aproximou-se dela centímetro a centímetro, prestes a cobrir seus lábios com os próprios. Mas Ning Xiaoxiao se esquivou com a leveza de um coelhinho.

Lu Linyuan franziu a testa. — Por que está fugindo?

Ning Xiaoxiao provocou: — Você não disse que tem mania de limpeza? Acabei de comer e não escovei os dentes. Não quero lhe causar repulsa~

Ela se levantou para sair, mas Lu Linyuan foi atrás e segurou seus ombros, fazendo-a se virar.

— Essa minha “mania de limpeza” tem um significado muito específico.

— Quando se trata de você, é a mais pura e irresistível das minhas manias.

Os lábios se encontraram, e os dois perderam qualquer vergonha...

Vamos interromper a cena bem aqui e fazer uma transição dramática e esplendorosa.

❤❤❤

O corpo de Bilian foi encontrado no poço seco no dia seguinte.

O poço era muito profundo e a queda causara inúmeros ferimentos. Assim, o golpe fatal na testa podia ser explicado como uma pancada sofrida durante a queda.

Todos sabiam que Bilian fora criada da família da Consorte Yun desde os seis anos e que as duas tinham uma relação muito próxima.

Por isso, ninguém estranhou a hipótese de que ela se suicidara para acompanhar sua senhora na morte.

Como Ning Xiaoxiao havia modificado a trama, a morte de Yun já não tinha relação direta com Qiqi. E o sistema corrigia automaticamente as incoerências da história para que os acontecimentos voltassem a fazer sentido.

Assim, Yun continuou morrendo pelas mãos de Gu Sijin, e Bilian também. As razões, porém, já não tinham nada a ver com Qiqi.

Naquele dia, após apresentar cumprimentos à imperatriz, Gu Sijin encontrou Chu Xingran esperando por ela no caminho de volta aos aposentos.

Ele a levou a um canto reservado do jardim imperial. Como estavam dentro do palácio, não fez nada impróprio; apenas trocaram palavras de saudade depois de tantos dias sem se ver.

Mas Bilian, escondida nas proximidades, ouviu toda a conversa.

Voltou e contou tudo à Consorte Yun, que usou o segredo para chantagear Gu Sijin: exigiu que ela passasse a servi-la e procurasse uma oportunidade de levar Ning Xiaoxiao à morte.

Gu Sijin entrou em pânico quando soube. Jamais faria mal a Xiaoxiao, mas, se desobedecesse a Yun, a consorte certamente contaria o caso à imperatriz.

Então, não apenas Chu Xingran correria risco de vida, como sua família também seria envolvida.

Seus parentes, Chu Xingran e Ning Xiaoxiao eram os pontos mais vulneráveis de Gu Sijin.

Ela suportaria ser maltratada pelos outros, mas jamais permitiria que ferissem as pessoas que amava.

Assim, depois de uma noite inteira de conflito, tomou uma decisão que, mesmo agora, ao recordá-la, lhe causava arrepios.

A Consorte Yun não podia continuar viva.

Era a primeira vez que Gu Sijin fazia mal a alguém; de uma só vez, tirara duas vidas.

Fizera tudo pessoalmente. Bengbeng não participara de nada.

Imaginara que a consciência a atormentaria, mas, para sua surpresa, encontrou uma paz interior como nunca havia sentido.

No passado, tratava todos com bondade, e por isso todos se sentiam livres para humilhá-la e tratá-la como se não fosse gente.

Agora entendia: se a sinceridade não era correspondida, se tratar os outros com gentileza só rendia desprezo, por que viver como a bodisatva Guanyin, tentando salvar todos os seres do sofrimento?

Não bastava proteger aqueles que realmente importavam para ela?

A noite avançava.

Sentada sob a varanda, ergueu os olhos para a lua. O céu parecia uma cortina azul-escura; nuvens acinzentadas cobriam parte da lua brilhante e, aos poucos, eram levadas pelo vento.

Ao contemplar a cena, sentiu como se o nevoeiro que obscurecia seu coração também fosse dissipado pela brisa.

Não queria mais ser uma bodisatva.

Daquele dia em diante, queria apenas ser uma pessoa de carne e osso.

(PS da autora: O “escurecimento” de Gu Sijin significa que ela finalmente entendeu que deseja ser uma pessoa normal, e não que de repente resolveu virar uma psicopata. Ela não vai prejudicar Xiaoxiao nem se colocar contra ela. Nada daquela trama melodramática de duas amigas brigando e puxando o cabelo uma da outra.)

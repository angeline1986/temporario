# Relatório de revisão — capítulo 28

## Fonte e delimitação

- Fonte primária: `novel_capitulos_1_a_60(20261103-131325).docx`, chinês tradicional.
- Intervalo: início de `第28章` até antes de `第29章`.
- Unidades chinesas não vazias, inclusive o título: **76**.
- Unidades traduzidas e alinhadas no CSV: **76**.
- Ausência de unidade traduzida: **0**.
- Ordem estrutural preservada: **sim**.

## Critérios de revisão

Tradução produzida diretamente do chinês, com controle de parágrafo por parágrafo. Foram revisadas a sequência, a atribuição de falas, nomes, números e os pontos de ambiguidade listados abaixo. Os diálogos, pensamentos e intervenções do sistema mantêm a diferenciação narrativa.

## Notas e limites

- O original traz o eufemismo sonoro 我俏麗嗎 como disfarce de um insulto. Mantida a formulação aparentemente inocente com nota para não apagar o jogo de palavras; a réplica do imperador depende de entender a frase literalmente.
- 商陸 é fitolaca (Phytolacca), planta tóxica cuja raiz pode se assemelhar a outras raízes medicinais; o texto da novel afirma a evolução dos sintomas em dois shichen, isto é, aproximadamente quatro horas.
- Na alteração do enredo, a maldição originalmente dirigida aos ancestrais e à família do médico passa a invocar os ancestrais e a família do imperador. As duas versões foram mantidas.
- 痛經 refere-se a cólicas menstruais, não a uma doença desconhecida do leitor; a ignorância do imperador é intencional.

**Classificação:** tradução revisada com cotejo estrutural integral. A correspondência 1:1 e a revisão do próprio tradutor não equivalem a uma auditoria linguística independente; possíveis nuances contestáveis devem ser examinadas diretamente no CSV antes de se afirmar uma validação definitiva.

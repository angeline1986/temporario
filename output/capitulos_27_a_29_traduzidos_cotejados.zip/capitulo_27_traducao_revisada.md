# Capítulo 27 — Tudo o que você quiser, eu lhe darei

Quando uma pessoa sofre uma reação de estresse, costuma cerrar os dentes com força.

Era exatamente o que acontecia com Ning Xiaoxiao.

Seus dentes estavam tão apertados, involuntariamente, que, por mais ar que Lu Linyuan soprasse, não conseguia fazê-la voltar a respirar.

Ele não teve escolha senão apertar com força as bochechas dela entre o polegar e o indicador da mão direita, obrigando-a a abrir a boca. Depois, usou a língua para afastar seus dentes e finalmente conseguiu soprar ar para dentro de sua boca.

Sanfu e os demais espectadores da cena nunca tinham visto algo semelhante. Cochichavam baixinho:

— O imperador deve gostar muito dessa criadinha, não? Ela já morreu e ele não para de beijá-la!

— Credo... Será que Sua Majestade tem alguma perversão? Tipo... necrofilia?

A conversa ficava cada vez mais absurda!

Lu Linyuan não ouvia aqueles comentários, mas Sanfu ouvia.

Ele lançou um olhar feroz aos guardas e os repreendeu em voz baixa: — Se continuarem falando bobagens, eu mesmo arranco o que vocês têm entre as pernas!

Todos cobriram imediatamente a virilha e fecharam a boca.

Depois das repetidas tentativas de Lu Linyuan de reanimá-la, Ning Xiaoxiao começou a recobrar a consciência.

Depois de um afogamento, é comum a pessoa ficar desorientada por algum tempo.

Ela achava que ainda estava debaixo d'água. Ao sentir alguma coisa lisa e escorregadia dentro da boca, imaginou que um peixe do lago imperial tivesse nadado até ali. Assustada, mordeu o tal «peixe» sem pensar duas vezes.

— Ugh...

Lu Linyuan sentiu a dor e se afastou dela imediatamente.

Em meio à névoa que lhe turvava a visão, Ning Xiaoxiao viu que ele estava encharcado da cabeça aos pés, com os cabelos molhados grudados no rosto.

Parecia um desastre... mas continuava absurdamente bonito.

Ela murmurou um «Majestade» e desmaiou outra vez.

Não estava fingindo: afinal, não havia nenhum comentário passando por sua cabeça.

Lu Linyuan verificou sua respiração. Ao constatar que ela voltara a respirar, ordenou imediatamente a Sanfu: — Levem-na de volta e chamem um médico imperial.

— Sim, Majestade. Vocês aí, depressa! Levem-na ao Palácio Zhongcui!

Lu Linyuan os deteve: — O Palácio Zhongcui fica longe demais do Instituto Médico Imperial. Vamos perder tempo no caminho. Levem-na ao Palácio Chaoyang.

Todos: «...»

***

Quando Ning Xiaoxiao acordou, descobriu que estava deitada numa cama aquecida, com a cabeça apoiada num travesseiro de jade, em um dos aposentos laterais do Palácio Chaoyang.

Lu Linyuan estava sentado ao lado, num assento aquecido, conversando com um médico imperial sobre seu estado.

Quem a examinava era o vice-diretor He, do Instituto Médico Imperial. Ele atendia exclusivamente Lu Linyuan e a imperatriz-viúva; nem mesmo a imperatriz conseguiria requisitar seus serviços se adoecesse.

— Pode ficar tranquilo, Majestade. Depois da acupuntura, o quadro desta criada se estabilizou. Ela deve acordar a qualquer momento.

Lu Linyuan assentiu e, em seguida, advertiu todos com severidade: — Se alguém disser uma única palavra sobre o que aconteceu hoje, será executado sem perdão!

Sanfu, os guardas, o médico e os demais servidores ajoelharam-se para receber a ordem: — Obedeceremos, Majestade!

Ning Xiaoxiao assistia a tudo.

Depois que afundara no lago imperial, a terrível sensação de sufocamento provocada pela água aos poucos desaparecera. Em seu lugar, sentira uma paz e um conforto como nunca antes.

Em seguida, cenas de sua vida inteira começaram a passar repetidamente diante de seus olhos, enquanto ela ouvia Xiao Qi gritar para que aguentasse firme.

Pouco antes de perder a consciência, viu um feixe de luz ofuscante.

Alguém surgiu contra a luz, passou um braço por sua cintura, abraçou-a com força e nadou vigorosamente em direção à margem.

Num instante, todas as lembranças voltaram.

Ela se recordava até dos mínimos detalhes de como Lu Linyuan lhe fizera respiração boca a boca.

【Bip, bip, bip! Nossa anfitriã tem uma sorte danada e escapou da morte! Deixe-me bater palmas para você!】

Uma salva de palmas começou a ecoar na cabeça de Ning Xiaoxiao, exatamente como aquele efeito sonoro constrangedor de aplausos que toca nas salas de karaokê e faz todo mundo querer desaparecer de vergonha.

Quando os aplausos terminaram, Xiao Qi prosseguiu: 【Parabéns por concluir a missão «Dançar balé com o tirano»! O índice de desvio da trama aumentou 2% e agora está em 7%!】

Naquele momento, Ning Xiaoxiao já não estava tão preocupada em saber se completara ou não a missão.

Uma única dúvida ocupava sua mente:

*Então... foi ele quem me salvou?*

Ning Xiaoxiao tossiu duas vezes, chamando a atenção de Lu Linyuan.

Ao ouvir o som, ele finalmente sentiu o peso que carregava no peito desaparecer.

Mas logo retomou sua pose de imperador. Aproximou-se da cama, baixou os olhos para ela e disse: — Se quer morrer, da próxima vez escolha um lugar onde não haja ninguém. Não morra na minha frente. Dá azar.

Com a voz fraca, Ning Xiaoxiao respondeu: — Esta serva... agradece a Sua Majestade por salvar sua vida.

O vice-diretor He aproximou-se para tomar seu pulso e então declarou: — Não há mais nada de grave. Daqui a pouco prescreverei um remédio para expulsar o frio do corpo. Basta que ela o tome.

Lu Linyuan assentiu em silêncio. Sanfu aproximou-se sorrindo e fez um gesto cortês ao médico: — Vice-diretor He, permita que este servo o acompanhe até a saída.

Ao ouvir aquele nome, Ning Xiaoxiao ficou surpresa.

【Vice-diretor He? Não é aquele médico imperial que troca o ginseng da farmácia imperial por falsificações para ganhar dinheiro?】

【Na farmácia imperial, os medicamentos de melhor qualidade ficam ao alcance das mãos. Os de qualidade inferior, depois de algum tempo, acabam guardados nas prateleiras mais altas. Os senhores do palácio quase nunca precisam dos que já estragaram; quando não são usados, esses produtos acabam descartados e queimados periodicamente.】

【Foi justamente porque quase ninguém usava o ginseng das prateleiras superiores que o vice-diretor He começou a substituí-lo por ginseng falso.】

【Só que a mãe do príncipe Duan adoeceu. Sem saber da troca, um médico pegou justamente o ginseng falso para tratá-la. Depois de tomar aquilo, ela morreu.】

【Isso acabou provocando indiretamente uma rixa entre Lu Linyuan e o príncipe Duan. Foi a partir daí que o príncipe começou a pensar em se rebelar; mais adiante, tornou-se uma das principais forças da revolta.】

Lu Linyuan ouviu com absoluta clareza toda aquela análise que Ning Xiaoxiao fazia do enredo.

E o pensamento seguinte dela o surpreendeu.

【E se eu avisasse Lu Linyuan?】

*Muito bem. Pelo menos sabe retribuir um favor. Finalmente parou de me chamar de imperador maldito.*

【Afinal, o imperador maldito acabou de salvar minha vida.】

Lu Linyuan: «...»

— Cof! Cof, cof, cof!

Ning Xiaoxiao, cujo estado já se estabilizara, de repente começou a tossir desesperadamente. Levou uma mão ao peito e, fingindo estar passando muito mal, falou com voz débil:

— Majestade... esta serva está com dificuldade para respirar. Acho que estou prestes a morrer...

— Ouvi dizer que o ginseng é um fortificante poderoso. Talvez me ajude a aguentar mais um pouquinho...

— Então... Majestade... será que eu poderia pedir uma raiz de ginseng para tomar?

Os servidores presentes ficaram pasmos com aquele pedido.

A criada estava cansada de viver?

O imperador tivera a bondade de salvá-la, e ela ainda tinha a cara de pau de pedir ginseng?

Desde quando uma simples criada tinha categoria para consumir ginseng?

Ning Xiaoxiao, por sua vez, já havia feito o que estava ao seu alcance. Agora deixaria o resto nas mãos do destino:

【Pronto, já pedi. Se ele for pão-duro demais para me dar, o problema será dele. Vai merecer o que acontecer, e estaremos quites! Não vou ficar devendo favor nenhum a ele!】

Todos esperavam que Lu Linyuan desse uma bronca em Ning Xiaoxiao. Para surpresa geral, porém, ele assentiu e disse a ela com uma voz extraordinariamente gentil:

— Tudo o que você quiser, eu lhe darei.

Todos: «...»

Só Sanfu estava com aquela expressão de quem acabara de presenciar um casal perfeito. Mal conseguia segurar o risinho:

*Isso, pode continuar mimando ela!*

---

## Notas editoriais

- O episódio do afogamento continua diretamente do capítulo 26. A reanimação boca a boca e a mordida são acontecimentos narrados, não instruções de primeiros socorros.
- O valor acumulado do índice de desvio da trama passa a 7%, após acréscimo de 2% pela missão de balé.
- O vice-diretor He é mencionado como possível responsável pela substituição criminosa do ginseng. As acusações surgem inicialmente nos pensamentos da protagonista, que o imperador ouve.

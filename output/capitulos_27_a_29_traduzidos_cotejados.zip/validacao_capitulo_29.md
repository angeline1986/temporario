# Relatório de revisão — capítulo 29

## Fonte e delimitação

- Fonte primária: `novel_capitulos_1_a_60(20261103-131325).docx`, chinês tradicional.
- Intervalo: início de `第29章` até antes de `第30章`.
- Unidades chinesas não vazias, inclusive o título: **78**.
- Unidades traduzidas e alinhadas no CSV: **78**.
- Ausência de unidade traduzida: **0**.
- Ordem estrutural preservada: **sim**.

## Critérios de revisão

Tradução produzida diretamente do chinês, com controle de parágrafo por parágrafo. Foram revisadas a sequência, a atribuição de falas, nomes, números e os pontos de ambiguidade listados abaixo. Os diálogos, pensamentos e intervenções do sistema mantêm a diferenciação narrativa.

## Notas e limites

- 宋院判 é chamado de diretor Song após a promoção; anteriormente o personagem é apresentado como vice-diretor do Instituto Médico Imperial.
- 答應 é um posto feminino de baixa hierarquia na corte. Neste capítulo, foi traduzido como dama de companhia, sem confundi-lo com imperatriz/consorte nobre; a equivalência hierárquica é aproximada.
- A expressão coloquial 救人痛經猶如再生父母 foi adaptada a um agradecimento hiperbólico, mantendo o exagero humorístico.
- O texto narra a aplicação de acupuntura como parte da ficção; não constitui recomendação médica.

**Classificação:** tradução revisada com cotejo estrutural integral. A correspondência 1:1 e a revisão do próprio tradutor não equivalem a uma auditoria linguística independente; possíveis nuances contestáveis devem ser examinadas diretamente no CSV antes de se afirmar uma validação definitiva.

# Capítulo 28 — Eu mesmo vou tratar da doença dela

Quando Lu Linyuan declarou «Tudo o que você quiser, eu lhe darei», todos ficaram com aquela cara de quem estava torcendo pelo casal. A única exceção foi o vice-diretor He: ele ficou com vontade de bater a própria cabeça contra uma parede até morrer.

Por dentro estava em pânico, mas não deixou transparecer nada.

Afinal, tinha colocado o ginseng falso na prateleira mais alta. Dificilmente alguém iria mexer ali.

Mesmo assim, para não correr riscos, disse a Lu Linyuan: — Então irei à farmácia imperial buscar o ginseng e preparar uma decocção para esta jovem tomar.

Ele a chamara de «jovem», não de «criada», prova de que também percebera que Lu Linyuan a tratava de maneira diferente.

Juntou as mãos num gesto respeitoso e pediu licença. Não havia dado sequer dois passos quando Lu Linyuan o deteve: — Você é o vice-diretor. Como poderia mandá-lo servir uma criada? Sanfu, leve alguns homens à farmácia imperial e traga duas raízes de ginseng, quaisquer que sejam.

Ning Xiaoxiao aproveitou a oportunidade para dar mais uma espetada: — Senhor Sanfu, pode escolher as que estiverem na prateleira mais alta? Ouvi dizer que os remédios guardados lá em cima já não têm tanta qualidade e estão prestes a ser jogados fora. Se uma serva como eu os usar, ao menos não serão desperdiçados.

Lu Linyuan pareceu concordar plenamente. Assentiu: — Faça como ela pediu. Uma simples criada não merece remédios de primeira.

Ning Xiaoxiao: — ... Eu sou uma gracinha, por acaso? [Nota do original: uma versão disfarçada, mais delicada, de um xingamento grosseiro.]

Assim que falou, levou a mão à boca.

Aquilo devia ter ficado apenas em sua cabeça, mas escapara em voz alta antes que conseguisse se controlar.

Lu Linyuan não percebeu o sentido oculto. Apenas a examinou de alto a baixo:

— Quando a tiraram do lago imperial, ainda havia algas presas ao seu cabelo. Você e a beleza não têm nada a ver uma com a outra! Escapar por um fio da morte, isso sim tem a ver com você!

Ning Xiaoxiao: «...»

Ao perceber que Sanfu já estava chegando à porta, o vice-diretor He ficou tão assustado que uma camada de suor fino lhe cobriu a testa.

— Majestade... não seria melhor que eu mesmo fosse? O senhor Sanfu não entende de medicamentos. A senhorita Ning está enfraquecida e com frio no corpo; precisa de um bom fortificante. Um ginseng de qualidade inferior talvez não tenha grande efeito.

— Não importa. — Lu Linyuan acenou com a mão. — Mesmo um efeito pequeno ainda é algum efeito. Basta que aquilo não a mate.

【... O que eu faço? Já me arrependi de ajudar esse imperador maldito! Bem que ele merece que alguém acabe com a raça dele!】

Mas agora era tarde demais para se arrepender.

A farmácia imperial não ficava longe do Palácio Chaoyang. Andando depressa, Sanfu conseguiria ir e voltar em cerca de quinze minutos.

Assim que o ginseng chegou, o vice-diretor He estendeu a mão para recebê-lo. Mas Lu Linyuan ordenou: — Sanfu, leve as raízes para o aprendiz de farmácia preparar o remédio.

Sanfu obedeceu e, no exato instante em que os dedos do vice-diretor estavam prestes a tocar o ginseng, virou-se sem a menor cerimônia e foi embora.

O vice-diretor He observou-o afastar-se, com a mão ainda paralisada no ar:

*Cansei. Pode acabar o mundo.*

Mal Sanfu levou o ginseng à pequena cozinha, o aprendiz percebeu que havia alguma coisa errada com as raízes.

Sanfu o conduziu imediatamente à presença de Lu Linyuan para relatar a descoberta:

— Majestade, este medicamento não é ginseng. É fitolaca.

— A fitolaca se parece muito com o ginseng, mas é venenosa, sobretudo a raiz. Quando ingerida por engano, pode provocar intoxicação em até quatro horas. A pessoa pode apresentar vômitos e convulsões; em casos graves, palpitações e até a morte!

Assim que ouviu a explicação do aprendiz, Ning Xiaoxiao resolveu dar um espetáculo.

Arregalou os olhos de corça, encarou Sanfu, aterrorizada, e choramingou: — Eu nunca tive desavença nenhuma com o senhor Sanfu. Por que o senhor quer me matar desse jeito?

Sanfu: «???»

— Majestade! Este servo não tem nada a ver com isso! Segui suas ordens e peguei exatamente o que estava na prateleira mais alta da farmácia imperial! Peço que Sua Majestade apure os fatos!

Lu Linyuan bateu levemente os nós dos dedos na mesa, produzindo um toc-toc ritmado.

— Transmitam minha ordem: quero que todos os medicamentos da farmácia imperial sejam examinados. Descubram de onde veio o problema.

Quando ouviu que Lu Linyuan mandara investigar tudo, as pernas do vice-diretor He amoleceram tanto que ele quase caiu de joelhos.

Por mais que tentasse, não conseguia entender como tivera tamanho azar. Trocara o ginseng apenas no dia anterior; nem sequer conseguira vender o produto verdadeiro e já estava prestes a perder a cabeça por causa daquilo!

Depois de uma investigação preliminar, a verdade começou a vir à tona.

Os medicamentos prestes a vencer realmente tinham sido substituídos por falsificações.

E o vice-diretor He, que tinha acesso privilegiado ao estoque graças ao cargo, tornou-se naturalmente o principal suspeito.

Era um veterano do Instituto Médico Imperial. Já administrava os serviços médicos no reinado do imperador anterior e nunca cometera um erro ao tratar pacientes. Aos olhos dos colegas, era um médico dedicado, responsável e incorruptível.

Confiando na reputação construída ao longo de tantos anos, ajoelhou-se diante de Lu Linyuan e começou a chorar, apelando para os sentimentos do imperador.

— Majestade! Eu jamais faria algo assim! Sou inocente! Sirvo diligentemente no palácio há mais de vinte anos e nunca roubei nada sob minha responsabilidade! Um médico deve ter compaixão: como eu poderia pôr a vida de alguém em risco? Suplico que Sua Majestade investigue até o fim e limpe meu nome!

Na verdade, se Lu Linyuan não tivesse ouvido os pensamentos de Ning Xiaoxiao e, assim, soubesse que o homem de fato cometera o crime,

talvez acreditasse naquela defesa comovente.

Mas, como ainda não dispunha de provas, também não podia simplesmente puni-lo de imediato.

Ning Xiaoxiao não pretendia se meter naquele assunto.

Só que, ao lembrar a maneira como Lu Linyuan a tratara pouco antes, sentiu a raiva ferver novamente.

Fazia muito tempo que não alterava as palavras do enredo e tinha acumulado tantos caracteres disponíveis... Seria um desperdício não usá-los. Por que não aproveitar a oportunidade para pregar uma peça no tirano?

Ela percorreu rapidamente o trecho seguinte da história:

«Ao ver Lu Linyuan em silêncio, o vice-diretor He acreditou que suas lágrimas e declarações de lealdade estivessem funcionando. Então continuou chorando: “Majestade, juro pelos meus próprios antepassados! Se alguma vez fiz algo assim, que toda a minha família tenha uma morte horrível!”»

Ning Xiaoxiao fez uma pequena alteração e sorriu, satisfeita.

Ao ver Lu Linyuan em silêncio, o vice-diretor He acreditou que suas lágrimas e declarações de lealdade estivessem funcionando. Então continuou chorando:

— Majestade, juro pelos antepassados de Sua Majestade! Se alguma vez fiz algo assim, que toda a família de Sua Majestade tenha uma morte horrível!

Assim que pronunciou aquelas palavras, o silêncio tomou conta do recinto.

Lu Linyuan ficou furioso. As veias saltaram em seu pescoço esguio.

Cerrou os punhos com tanta força que os dedos estalaram. — Guardas! Arrastem esse homem para fora e executem-no pelo suplício dos mil cortes!

Diante da fúria do tirano, ninguém ousava sequer respirar alto.

Justo naquele momento, Ning Xiaoxiao soltou um «Ah!» repentino.

Todos se voltaram para ela. Lu Linyuan também a observou com os olhos sombrios.

Ao vê-la apertando o baixo-ventre, com o rosto contraído de dor, perguntou: — O que houve?

Ning Xiaoxiao balançou a cabeça, constrangida: — Na... nada...

Uma dor surda e pesada percorria seu baixo-ventre em ondas, como se alguém socasse sua barriga repetidas vezes, em intervalos regulares.

Sua testa estava coberta de suor frio, seu rosto perdera a cor e ela mal tinha forças para falar.

Tinha mergulhado no lago imperial e tomado um banho de água gelada justamente quando estava menstruada. Se aquilo não lhe causasse cólicas, o que causaria?

Lu Linyuan percebeu que ela não tinha nada de bem e insistiu: — Afinal, o que você tem? Se há algum problema, fale!

— Agradeço a preocupação de Sua Majestade, mas esta serva... realmente não tem nada.

【E o que você quer que eu diga? Que estou com cólicas menstruais na frente de todo esse povo????】

【Não dá! Se eu não sair daqui, vou acabar tendo um sangramento enorme! Aí o tirano vai ver que manchei a cama dele de sangue e mandar cortar minha cabeça!】

Reunindo toda a determinação que lhe restava, ela se levantou, fez uma reverência para pedir licença a Lu Linyuan e saiu mancando.

Lu Linyuan: «...»

*Cólicas menstruais? O que seria isso?*

*É alguma doença que ela trouxe desde o ventre materno?*

*Espera... Essa doença ainda provoca hemorragia?*

*Será que pode matar?*

*Não, preciso perguntar aos médicos imperiais que doença rara e difícil de tratar é essa.*

---

## Notas editoriais

- O original traz o eufemismo sonoro 我俏麗嗎 como disfarce de um insulto. Mantida a formulação aparentemente inocente com nota para não apagar o jogo de palavras; a réplica do imperador depende de entender a frase literalmente.
- 商陸 é fitolaca (Phytolacca), planta tóxica cuja raiz pode se assemelhar a outras raízes medicinais; o texto da novel afirma a evolução dos sintomas em dois shichen, isto é, aproximadamente quatro horas.
- Na alteração do enredo, a maldição originalmente dirigida aos ancestrais e à família do médico passa a invocar os ancestrais e a família do imperador. As duas versões foram mantidas.
- 痛經 refere-se a cólicas menstruais, não a uma doença desconhecida do leitor; a ignorância do imperador é intencional.

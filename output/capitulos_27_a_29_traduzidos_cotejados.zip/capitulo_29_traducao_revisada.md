# Capítulo 29 — Eu me preocupo com você, mas não vou admitir

O recém-promovido vice-diretor do Instituto Médico Imperial assumiu a direção e correu para se apresentar ao imperador e agradecer pela nomeação.

Sua chegada foi providencial. Lu Linyuan dispensou os demais e lhe perguntou com um ar misterioso: — Ministro Song, sabe que doença é essa chamada «cólica menstrual»?

O diretor Song acariciou a barba e pareceu desconcertado. — Bem... Receio que meus conhecimentos sejam limitados, Majestade. Nunca ouvi falar de uma doença com esse nome. Poderia descrever os sintomas com mais detalhes?

Lu Linyuan refletiu por um instante. — Dor de barriga, suor frio, rosto pálido e... e até hemorragia?

— Pela descrição de Sua Majestade, parece se tratar de... alguma irregularidade da menstruação. É uma questão de saúde feminina, que pode ser aliviada com acupuntura. Posso perguntar qual das senhoras do harém está sofrendo disso?

Se havia tratamento, não devia ser uma doença tão grave.

O problema era que ele não podia simplesmente mandar um médico imperial tratar uma criada.

Pensou um pouco e concluiu que, afinal, as duas eram mulheres. Talvez Gu Sijin tivesse o mesmo problema de Ning Xiaoxiao.

Mandar um médico tratar uma criada chamaria atenção demais; mandar um médico atender uma consorte, por outro lado, era perfeitamente normal.

Além disso, Gu Sijin era bondosa e próxima de Ning Xiaoxiao. Não deixaria a criada sofrendo sem fazer nada.

Por isso respondeu casualmente: — É a Dama de Companhia Gu. Vá examiná-la.

— Às ordens, Majestade.

***

Ning Xiaoxiao voltou ao Palácio Zhongcui praticamente com meia vida. Sentia que a menstruação já havia espancado seu ventre até deixá-lo dormente.

Quando chegou, Qiqi estava varrendo o pátio.

Ao vê-la naquele estado deplorável, correu para ampará-la. — Xiaoxiao, o que aconteceu com você?

Com pouquíssimas forças, Ning Xiaoxiao respondeu: — Estou menstruada... Meu baixo-ventre está doendo...

— Você também está com dor de barriga? Nossa senhora também! Menstruou ontem à noite e hoje está com tanta dor que não consegue sair da cama. Mandei Qiaqia preparar chá de gengibre com açúcar mascavo. Tome um pouco também, está bem?

Aquelas duas realmente eram senhora e criada unidas até no sofrimento.

Tinham cólicas menstruais ao mesmo tempo!

De qualquer modo, Gu Sijin era sua senhora. Se estava doente, Ning Xiaoxiao, como criada, precisava ao menos ir visitá-la.

Quando chegou, Gu Sijin estava deitada, segurando uma bolsa de água quente sobre o baixo-ventre em pleno verão. Seu rosto estava branco como papel e coberto de suor. Era praticamente Ning Xiaoxiao em outra versão.

Ning Xiaoxiao aproximou-se da cama e perguntou: — Minha senhora, como está se sentindo? Por que não manda chamar um médico imperial?

Gu Sijin apertou os lábios e balançou a cabeça. — Não precisa de tanto transtorno... Acabei de entrar no palácio. Se já mandar chamar um médico, vou dar motivo para falarem de mim.

Depois de dizer isso, olhou para Ning Xiaoxiao e só então percebeu que ela também segurava a barriga e parecia sofrer muito. — E você? O que aconteceu? Venha, sente-se.

Segurou a mão de Ning Xiaoxiao e a fez sentar-se à beira da cama. As mãos das duas estavam frias como gelo. — Você também está naqueles dias?

Ning Xiaoxiao assentiu, franzindo as sobrancelhas. Gu Sijin ficou em silêncio por um instante e chamou Cailian.

— Cailian, vá ao Instituto Médico Imperial chamar um médico.

Cailian ficou confusa. — Mas, quando sugeri isso há pouco, a senhorita não disse que seria inconveniente chamar um médico logo depois de chegar ao palácio? Por que agora...?

— Porque não sou só eu. Xiaoxiao também está sofrendo. Ela parece até pior do que eu. Se um médico não examiná-la, não vou conseguir ficar tranquila.

Mais uma vez, Ning Xiaoxiao ficou impressionada com a grandeza de espírito de Gu Sijin.

*Mas que anjo na Terra era aquela mulher?*

Estava com cólicas e preferia aguentar a dor a chamar um médico. Mas, assim que via uma serva passando pelo mesmo sofrimento, mandava buscar um imediatamente?

Mesmo que a protagonista fosse uma dessas mulheres que bancam a santinha, era difícil não se render à sua bondade e ao seu caráter!

Ning Xiaoxiao se apressou em negar: — Não precisa, minha senhora. Esta serva está bem.

Cailian lançou-lhe um olhar atravessado. — Se está menstruada e com dor, devia ficar quietinha no palácio. Mas não! Saiu sabe-se lá para onde logo cedo e ninguém sabe por onde andou. Vive sumindo e aparecendo sem que ninguém entenda nada.

— Minha senhora! Minha senhora! O diretor Song chegou! — anunciou Lala, radiante, do lado de fora.

Gu Sijin estranhou.

Song acabara de ser promovido à direção do Instituto Médico Imperial. Em princípio, sua função era atender apenas o imperador, a imperatriz e a imperatriz-viúva.

Por que apareceria, assim, sem mais nem menos, nos aposentos de uma simples dama de companhia?

Mesmo surpresa, ela se levantou para recebê-lo.

O diretor Song entrou devagar e disse com um sorriso: — Não se incomode em se levantar, minha senhora. Sua Majestade está preocupado com a sensibilidade ao frio que a aflige e me enviou pessoalmente para examiná-la.

Gu Sijin ficou paralisada por um momento. Depois, corando, perguntou:

— O imperador? Mas minha menstruação começou só ontem... Ainda nem tive tempo de pedir aos servidores que avisassem o Departamento dos Aposentos Imperiais. Como Sua Majestade soube?

— Quando uma jovem entra no palácio, o Departamento de Assuntos Internos registra aproximadamente as datas de sua menstruação. Talvez Sua Majestade se preocupe tanto com a senhora que tenha até consultado esses registros.

O coração de Gu Sijin se aqueceu de repente.

Quem diria que Lu Linyuan lhe dedicava tanta atenção?

Ela se sentou num assento aquecido. Depois de examinar seu pulso, o diretor Song compreendeu a situação.

Então tirou suas agulhas de prata e começou a tratá-la com acupuntura.

Gu Sijin ficou apreensiva. — Mas como posso permitir uma coisa dessas? O senhor é o diretor e, em princípio, só deveria atender o imperador e a imperatriz. Eu não passo de uma simples dama de companhia, eu...

O diretor Song sorriu. — É uma ordem imperial, minha senhora. Não precisa diminuir a própria importância.

Ao assistir àquela cena, Ning Xiaoxiao também ficou chocada com a manobra inesperada do tirano.

Ela se esforçara tanto para impedir que o romance entre o protagonista e a protagonista original avançasse!

Por que o tirano estava fazendo aquilo de repente?

Se os dois acabassem juntos, como ela conseguiria desviar a trama?

Não encontrou resposta alguma. E, como a barriga ainda doía, perdeu a vontade de pensar no assunto.

O diretor Song realmente dominava a medicina. Bastou aplicar algumas agulhas em pontos específicos, aparentemente sem esforço, para que a cor voltasse ao rosto de Gu Sijin e sua dor abdominal desaparecesse.

Ela se apressou em agradecer. Song acenou com a mão: — Não fiz mais que cumprir meu dever. Nos próximos dias, voltarei para realizar novas sessões de acupuntura e consolidar o tratamento.

Gu Sijin agradeceu repetidas vezes. Quando estava prestes a acompanhá-lo à saída, percebeu de relance que o rosto de Ning Xiaoxiao parecia cada vez pior.

Ela segurava a barriga e dava sinais de estar sofrendo demais.

Gu Sijin pediu ao diretor Song que aguardasse mais um instante, voltou à penteadeira e retirou algumas moedas de prata de uma gaveta para lhe entregar.

Ele se apressou em recusar: — Não posso aceitar. Tratar minha senhora faz parte de minhas obrigações. Não poderia receber seu dinheiro.

— Por favor, aceite. Tenho mais um favor a lhe pedir. — Ela praticamente colocou as moedas à força na mão de Song. Depois pediu a Qiqi que ajudasse Ning Xiaoxiao a se aproximar e suplicou:

— Sei que isso não está de acordo com as regras, mas Xiaoxiao é a criada que mais me ajuda. Ela também está sofrendo por causa da menstruação. O senhor é um médico de coração generoso... Poderia examiná-la também?

Ning Xiaoxiao não esperava nem por um instante que Gu Sijin pediria ao diretor que tratasse dela também.

Se a notícia se espalhasse, Gu Sijin não acabaria sendo punida?

— Minha senhora, esta serva está bem. Não precisa mesmo...

Gu Sijin apertou sua mão com força e lançou-lhe um olhar que dizia para ficar calada.

O diretor Song também não resistiu aos apelos insistentes de Gu Sijin e acabou aplicando acupuntura em Ning Xiaoxiao.

*Quem salva alguém de uma cólica menstrual merece ser chamado de pai ou mãe pela segunda vez!*

Depois daquele episódio, boa parte dos preconceitos que Ning Xiaoxiao alimentara contra Gu Sijin por ter lido o romance original se desfez.

Nos dias seguintes, o diretor Song foi diariamente ao Palácio Zhongcui aplicar acupuntura em Gu Sijin e Ning Xiaoxiao.

A notícia logo se espalhou por todos os seis palácios, levada pela boca dos criados da Consorte Duan.

Além de contar com o favor imperial, Gu Sijin ainda tinha um imperador que se lembrava até das datas de sua menstruação e mandava o diretor médico atendê-la pessoalmente?

Quem não se apaixonaria por um homem tão atencioso?

Mas, se toda essa atenção fosse dedicada a outra mulher, e não a você, que mulher conseguiria não sentir ciúmes?

Gu Sijin já era motivo de inveja entre as consortes. Depois daquele episódio, passaram a odiá-la ainda mais, rangendo os dentes de raiva.

---

## Notas editoriais

- 宋院判 é chamado de diretor Song após a promoção; anteriormente o personagem é apresentado como vice-diretor do Instituto Médico Imperial.
- 答應 é um posto feminino de baixa hierarquia na corte. Neste capítulo, foi traduzido como dama de companhia, sem confundi-lo com imperatriz/consorte nobre; a equivalência hierárquica é aproximada.
- A expressão coloquial 救人痛經猶如再生父母 foi adaptada a um agradecimento hiperbólico, mantendo o exagero humorístico.
- O texto narra a aplicação de acupuntura como parte da ficção; não constitui recomendação médica.

# Relatório de revisão — capítulo 27

## Fonte e delimitação

- Fonte primária: `novel_capitulos_1_a_60(20261103-131325).docx`, chinês tradicional.
- Intervalo: início de `第27章` até antes de `第28章`.
- Unidades chinesas não vazias, inclusive o título: **79**.
- Unidades traduzidas e alinhadas no CSV: **79**.
- Ausência de unidade traduzida: **0**.
- Ordem estrutural preservada: **sim**.

## Critérios de revisão

Tradução produzida diretamente do chinês, com controle de parágrafo por parágrafo. Foram revisadas a sequência, a atribuição de falas, nomes, números e os pontos de ambiguidade listados abaixo. Os diálogos, pensamentos e intervenções do sistema mantêm a diferenciação narrativa.

## Notas e limites

- O episódio do afogamento continua diretamente do capítulo 26. A reanimação boca a boca e a mordida são acontecimentos narrados, não instruções de primeiros socorros.
- O valor acumulado do índice de desvio da trama passa a 7%, após acréscimo de 2% pela missão de balé.
- O vice-diretor He é mencionado como possível responsável pela substituição criminosa do ginseng. As acusações surgem inicialmente nos pensamentos da protagonista, que o imperador ouve.

**Classificação:** tradução revisada com cotejo estrutural integral. A correspondência 1:1 e a revisão do próprio tradutor não equivalem a uma auditoria linguística independente; possíveis nuances contestáveis devem ser examinadas diretamente no CSV antes de se afirmar uma validação definitiva.

# Capítulo 47 — Finalmente dormindo na mesma cama

Na manhã seguinte, quando Ning Xiaoxiao se levantou para se lavar, encontrou Qiqi, Qiaqia, Bengbeng e Lala reunidas, discutindo alguma coisa.

Aproximou-se. — Do que vocês estão falando?

— Xiaoxiao, veja isto! — Qiqi lhe entregou um retrato. — Desde cedinho, o pessoal do Departamento de Assuntos Internos está espalhando estes cartazes pelo palácio. Disseram que o imperador dará uma grande recompensa a quem já tiver visto esse homem e puder fornecer alguma pista útil.

Ning Xiaoxiao olhou de relance e ficou petrificada.

Mas que diabos... Não era o velhinho do KFC?!

【Pra que Lu Linyuan está procurando esse homem?】

【Ele está bem da cabeça?】

【Não me diga que realmente acreditou que esse sujeito é meu pai?!】

【...】

Naquele dia, quase todo mundo no palácio discutia quem seria o velhinho de barba branca. Só Ning Xiaoxiao estava com saudade do frango que ele fazia.

Ela se escondeu no quartinho para matar serviço e começou a enrolar os fios do cabelo nos dedos, entediada. Não parava de pensar numa maneira de arrancar mais um tufo dos cabelos de Lu Linyuan para satisfazer seu apetite insaciável por compras.

Mas, antes de encontrar um plano, percebeu que seus dedos estavam todos engordurados de óleo do cabelo.

E olhe que tinha lavado a cabeça no dia anterior! Já estava oleosa outra vez!

De repente, pareceu entender por que as mulheres da antiguidade quase nunca usavam franja e preferiam prender o cabelo para cima.

Se tivessem franja, bastaria um dia para os fios ficarem grudados uns nos outros de tanta oleosidade...

Ela adorava limpeza; para ela, andar com o cabelo oleoso era praticamente uma sentença de morte.

Ainda lhe restavam quatro fios de cabelo de Lu Linyuan. Deu uma volta pela loja de conveniência e descobriu que um frasco de xampu custava exatamente quatro fios. Comprou-o sem nem piscar.

Depois de lavar o cabelo, despejou o xampu que sobrou num pote de cerâmica e saiu para ajudar Qiqi e as outras nos afazeres.

Mal apareceu, o perfume residual do xampu espalhou-se pelo ar, como se pudesse ser sentido a quilômetros.

Qiqi e as demais perceberam que a fragrância vinha dos cabelos de Ning Xiaoxiao e perguntaram, curiosas e invejosas: — Xiaoxiao, o que você usou para lavar o cabelo? Por que está tão cheiroso?

Ning Xiaoxiao fez mistério. — Ah, só sabão de menta e vagens de gledítsia, desses comuns. Misturei um pouquinho de suco de flores frescas.

Naquele dia, parecia um difusor de perfume ambulante: aonde quer que fosse, alguém lhe perguntava sobre a fragrância.

Até a Consorte Duan e Gu Sijin ficaram encantadas e pediram que Ning Xiaoxiao preparasse um xampu igual para elas.

Isso acendeu uma ideia em sua cabeça.

【É mesmo! Se todo mundo gosta desse cheiro, Lu Linyuan também vai gostar, com certeza!】

【Quando ele me chamar esta noite para ler os memoriais, levarei o xampu. Se perguntar por que meu cabelo está tão cheiroso, vou me oferecer para lavar o dele! Hehehe! Assim poderei arrancar quantos fios quiser! Genial!】

Ela ainda se gabava mentalmente por ter encontrado uma maneira infalível de tirar proveito do tirano quando Xiao Qi apareceu com uma nova missão.

【Bip, bip, bip! Anfitriã, temos uma missão nova para você!】

【Durma uma noite inteira abraçada ao tirano!】

【Se concluir a missão, o índice de desvio da trama aumentará 1%. Se falhar, sua expectativa de vida será reduzida em 10%. Depois de concluída, o sistema liberará uma recompensa!】

A recusa estava estampada no rosto de Ning Xiaoxiao.

【Dormir uma noite inteira? Se eu passar a noite abraçada a ele, perco bem mais que 10% da minha vida! Se quer me matar, diga logo...】

Xiao Qi: 【Hehehe~ Por que tanta resistência, anfitriã? O tirano é bonito e tem um corpão. Dormir com ele nem seria um mau negócio para você~】

【Além disso, quando você acompanhava grupos masculinos de idols no mundo moderno, não vivia gritando “Gatinho, eu topo!” para eles? O tirano é muito mais bonito que aqueles integrantes de boy band.】

Ning Xiaoxiao: 【Chega, chega! Não precisa expor meus podres! Está bem, vou dormir com ele...】

Afinal, era só dormir uma noite, não fazer outra coisa.

Quando Lu Linyuan pegasse no sono, ela se deitaria discretamente ao lado dele e alteraria uma frase da trama, acrescentando: «Naquela noite, ele dormiu profundamente». Problema resolvido, não?

Ao cair da noite, Lu Linyuan realmente escolheu outra vez a placa de Gu Sijin e mandou chamá-la para servi-lo nos aposentos.

Gu Sijin já desenvolvera praticamente um reflexo condicionado ao entrar no Palácio Chaoyang. Antes mesmo que Lu Linyuan lhe atribuísse uma «tarefa», começou a pular por conta própria.

Lu Linyuan, como de costume, levou Ning Xiaoxiao ao escritório e mandou que lesse os memoriais.

Mas havia uma diferença naquele dia: enquanto os dois estavam a sós, ele percebeu um perfume incomum vindo dela.

Nunca sentira aquele aroma, que era realmente agradável.

Quando descobriu que vinha dos cabelos de Ning Xiaoxiao, perguntou: — O que você passou no cabelo? Tem uma fragrância muito peculiar.

Ning Xiaoxiao: 【Aí vem! Aí vem! O peixão mordeu a isca!】

— Majestade, esta serva usou um xampu que preparou! O perfume dura muito, controla a oleosidade por bastante tempo e ainda acaba com a caspa. Vossa Majestade não gostaria de experimentar?

【Diga que quer experimentar! Aí vou tirar o xampu e lavar sua cabeça! Enquanto estiver lavando, vou arrancar seus cabelos sem parar!】

Lu Linyuan: — ... Não quero lavar o cabelo agora. Falaremos disso amanhã de manhã. Mostre-me esse seu xampu.

Ning Xiaoxiao parecia aprender uma lição e ficar ainda menos esperta. Mesmo depois de ter tantas coisas confiscadas pelo tirano, continuava sem criar juízo. Como uma boboca obediente, tirou o pote de cerâmica com xampu e o entregou a Lu Linyuan.

Ele abriu o recipiente, e uma fragrância intensa se espalhou pelo ar.

Observou a substância cremosa, branco-leitosa, e tocou nela com a ponta do indicador. Para sua surpresa, quando afastou o dedo, ela até formava fios viscosos.

Tanto a cor quanto a textura lembravam um certo líquido que ele próprio era capaz de produzir. Suas bochechas coraram um pouco.

— Que... que coisa é esta?

— Xampu! Minha fórmula especial! Majestade, se colocar um pouco de água e esfregar, faz até espuminha! É muito divertido!

Lu Linyuan seguiu as instruções, molhou o dedo e esfregou de leve. Como prometido, formou-se uma porção de bolhas.

Ning Xiaoxiao fazia tudo aquilo para convencê-lo a deixá-la lavar seus cabelos na manhã seguinte.

Quem diria que Lu Linyuan se divertiria tanto com a espuma? Sorrindo, declarou: — Gostei disso. Vou ficar com ele.

Ning Xiaoxiao: ???

— Majestade, mas isso...

— Isso o quê? Nem é uma coisa tão preciosa. Agora não posso nem ficar com ela? — Lu Linyuan fechou o pote, guardou-o cuidadosamente e ordenou: — Continue lendo os memoriais!

Depois de amaldiçoar mentalmente os dezoito antepassados de Lu Linyuan umas dez mil e oitenta e seis vezes, Ning Xiaoxiao continuou a leitura dos memoriais enquanto refletia sobre a missão.

【Já perdi meu xampu; não posso ficar no prejuízo de novo! Já que esse imperador maldito pegou meu xampu, hoje à noite eu tenho que dormir com ele!】

Lu Linyuan estava bebendo água e quase morreu engasgado quando ouviu aquilo.

*O quê?!*

*Eu pego seu xampu e você já quer dormir comigo?*

*Não é um preço alto demais...?*

Por instinto, fechou um pouco mais a gola das vestes. — Estou cansado. Pode se retirar.

Ning Xiaoxiao não protestou. Fez uma reverência respeitosa e saiu.

Lu Linyuan ainda se arrepiava ao lembrar do dia em que ela lhe apalpara o peito. Por isso, ao se deitar, trancou deliberadamente a porta dos aposentos pelo lado de dentro, para não lhe dar nenhuma oportunidade de «tirar liberdades» com ele.

Mas, por mais cauteloso que fosse, não podia competir com o poder de uma única alteração de Ning Xiaoxiao na história.

*Trancou a porta, foi?*

Bastou acrescentar um caractere: agora a porta *não estava trancada*.

*Tem o sono leve, é?*

Bastou mudar um caractere: agora ele *dormia profundamente*.

Quando Ning Xiaoxiao voltou a entrar às escondidas no quarto imperial, Lu Linyuan já estava num sono profundo.

Ela caminhou até a cama e observou demoradamente o belo rosto dele. Seu olhar desceu aos poucos, até notar que ele estava dormindo abraçado ao pote de cerâmica com o xampu.

Tsc, tsc. Estava com medo de que ela voltasse para roubá-lo?

Ning Xiaoxiao ergueu o queixo de Lu Linyuan com um dedo e abriu um sorriso cheio de segundas intenções.

— Acha mesmo que pode escapar das minhas mãos?

Então, com a maior naturalidade do mundo, como se estivesse indo para a própria cama, deitou-se ao lado dele.

Lembrando que a missão exigia abraçá-lo, puxou-o para seus braços sem pensar duas vezes.

*Hmm... Que sensação boa! Boa demais, droga!*

---

## Notas editoriais

- O cartaz do velhinho do KFC é consequência direta da ordem imperial no capítulo 46.
- No início do capítulo, restam quatro fios do imperador; o xampu custa exatamente quatro. Não confundir com os seis fios guardados no capítulo 45, pois há uma intenção intermediária de comprar chá com leite.
- 薄荷皂角: menta e vagens de gledítsia usadas tradicionalmente na limpeza; não significa saponária botânica.
- A missão exige abraçar o imperador durante uma noite, dá 1% de desvio de trama e prevê penalidade de 10% da vida útil; a recompensa é anunciada, não revelada neste capítulo.
- 哥哥我可以: frase de fã de idol que manifesta atração/entusiasmo; adaptada para “Gatinho, eu topo!”, sem apresentar a versão como tradução literal.
- Ning altera duas condições narrativas: porta trancada → não trancada; sono leve → sono profundo. São alterações intencionais de caracteres, não inconsistências.
- No trecho do xampu há insinuação sexual baseada na aparência viscosa do produto, sem identificação anatômica explícita no original.

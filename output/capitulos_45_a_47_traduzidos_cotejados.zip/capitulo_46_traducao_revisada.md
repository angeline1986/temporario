# Capítulo 46 — Então o velhinho do KFC é seu pai?

Lu Linyuan fez tudo num único movimento. Antes que Ning Xiaoxiao pudesse reagir, a coberta já havia sido arrancada.

Ao mesmo tempo, o balde de frango escondido ali caiu no chão, rolou duas vezes e parou ao lado dos pés de Lu Linyuan.

— Majestade, isso...

Ela estava prestes a se explicar, mas Lu Linyuan já apanhara o balde do chão.

Ning Xiaoxiao levou a mão à testa. 【Ferrou! Como vou explicar de onde veio essa coisa...?】

Assim que pegou o balde, a primeira coisa que Lu Linyuan viu foi o velho de barba branca estampado nele.

Examinou com atenção aquele homem tão diferente das pessoas da dinastia Qi e perguntou, desconfiado: — Quem é este?

O cérebro de Ning Xiaoxiao trabalhou a toda velocidade. Em dois segundos, ela inventou uma explicação ao mesmo tempo plausível e absurda.

Baixou os olhos, apertou levemente os lábios e assumiu uma expressão muito triste. — Esta serva não ousaria mentir a Vossa Majestade. Isso... na verdade é um retrato do meu pai!

— Seu pai? — Lu Linyuan examinou novamente o velhinho do KFC. — Está dizendo que esse velho de barba desgrenhada é seu pai?

Ning Xiaoxiao assentiu vigorosamente. — Sim!

— Seu pai tem uma aparência um tanto... desleixada. — Lu Linyuan soltou um risinho frio. — Mas, para ter uma filha tão jovem quanto você, deve ser um velho bastante vigoroso. Uma pérola nascida de uma ostra velha, hein?

Ning Xiaoxiao: — ...

【Não pode ser! Preciso dar um jeito de tirar o balde das mãos dele! Se abrir a tampa e descobrir que está cheio de frango frito, vai roubar minha comida outra vez!】

Ela se aproximou de Lu Linyuan e continuou sua história descarada. — Majestade, minha vida foi muito sofrida! Eu e meu pai nos perdemos um do outro há muitos anos. Sempre quis encontrá-lo. Por isso trouxe o retrato dele para o palácio, esperando que, se surgisse uma oportunidade, alguém pudesse fazer cópias e espalhá-las por aí. Mesmo que houvesse apenas uma chance mínima de reencontrar meu pai, eu precisaria tentar.

Vendo que Lu Linyuan prestava atenção, tentou aproveitar para pegar o balde.

Mas, assim que estendeu a mão, ele se esquivou.

— Quem diria que você é tão dedicada ao pai? Até me comovi.

Lu Linyuan abraçou o balde e disse com toda a seriedade: — Façamos assim. Levarei o retrato e mandarei o pessoal da Oficina Ruyi produzir várias cópias para afixar por toda parte. Faremos o possível para encontrar seu pai. O que acha?

— Ah, bem... Majestade, na verdade...

— Eu sei, não precisa dizer mais nada. — Lu Linyuan pousou o indicador sobre os lábios delicados dela e balançou a cabeça. — Não precisa me agradecer. Uma grande bondade dispensa palavras. Basta cumprir bem seus deveres.

Ning Xiaoxiao tinha o péssimo hábito de ficar com o cérebro completamente travado nos momentos decisivos.

Por que precisava inventar tanta explicação para Lu Linyuan?

No instante em que ele descobriu o balde, não teria bastado apertar Retroceder e acabar com o problema?

Ficara enrolando tanto que perdera todo o tempo!

Agora, mesmo que apertasse Retroceder, não adiantaria mais nada!

Lu Linyuan já se preparava para sair abraçado ao balde quando ouviu Ning Xiaoxiao resmungar mentalmente:

【Imperador maldito! Tomara que você coma até estourar!】

Ela olhou para o joelho de porco à moda de Dongpo, os camarões cristalinos e o Buda Salta o Muro sobre a mesa e se consolou um pouquinho.

【Ah, deixa pra lá. Pelo menos esses pratos parecem gostosos, já que fiquei sem o frango. Quando der fome à noite, posso esquentá-los e comer com Qiqi e as outras.】

Lu Linyuan, já com um pé para fora, deu meia-volta e apanhou a bandeja da mesa.

Ning Xiaoxiao arregalou os olhos. — Majestade, o senhor... O que está fazendo?

— Ah, vi que você parecia estar sofrendo para comer esses pratos. Devem ter sido preparados de um jeito que não lhe agrada. Vou mandar jogá-los fora.

— Não, Majestade! Seria um desperdício jogar tudo fora...

— Que desperdício? A comida é feita para ser consumida. Se você não gosta dela, que diferença faz jogá-la fora ou deixá-la comer? No fim, desaparece do mesmo jeito.

...

*Ele falou de um jeito tão convincente que nem sei como retrucar.*

No fim, só lhe restou observar, impotente, Lu Linyuan partir com o balde de frango no braço esquerdo e a bandeja na mão direita, como se nada tivesse acontecido.

【Imperador maldito!!! Espere só! Na próxima vez que você se meter em problemas, quero ver se esta senhora aqui vai ajudá-lo!】

【Ufa... Pelo menos guardei alguns fios de cabelo. Se fiquei sem o frango, vou arranjar um chá com leite para beber.】

Lu Linyuan, que ainda estava à porta, sentiu-se tentado.

*Chá com leite...*

Apertou os lábios. Também queria!

Mas olhou para o balde de frango em seus braços, pensou um pouco e resolveu desistir.

Se roubasse também o chá com leite, ela provavelmente se enforcaria ali mesmo, diante dele.

De volta ao Palácio Chaoyang, a primeira coisa que Lu Linyuan fez foi abrir a tampa do balde para descobrir que iguaria tão extraordinária havia dentro.

Mal levantou a tampa, o cheiro do frango frito tomou o ar.

Os alimentos obtidos na loja de conveniência do sistema permaneciam sempre em seu estado mais delicioso. Por isso, embora tivesse se passado tanto tempo, os hambúrgueres, os pedacinhos de frango empanado e todo o resto continuavam quentinhos.

Lu Linyuan provou um por um e de repente começou a achar que os servos da cozinha imperial eram um bando de incompetentes.

Por quê?!

Por que só estava comendo algo tão delicioso agora?!

Como imperador, naturalmente tinha consciência de que precisava se precaver.

Comeu apenas metade de cada item e mandou Sanfu levar o restante à cozinha imperial. — Ordene aos cozinheiros que desenvolvam pratos idênticos a esses! Quem conseguir preparar os melhores será recompensado!

*

Na hora do jantar, Ning Xiaoxiao encarava os dois pãezinhos rústicos de milho e o pratinho de verduras em conserva ácida que estavam sobre a mesa. Não tocava na comida; apenas apoiava o queixo nas mãos e questionava as próprias escolhas de vida.

Enquanto lamentava sua sorte, ouviu alguém bater à porta.

— Quem é?

— Abra. Sou eu! — respondeu Sanfu em voz baixa do outro lado.

Ning Xiaoxiao abriu a porta e viu Sanfu entrar depressa, carregando uma caixa de comida.

Ele retirou os pratos, um por um. Eram os mesmos três do almoço: joelho de porco à moda de Dongpo, camarões cristalinos e Buda Salta o Muro.

E ainda estavam quentinhos.

Ela ficou encantada. — Eunuco Sanfu, isso é...?

— Cof, cof. Sua Majestade disse que seria um desperdício jogar esses pratos fora, até para alimentar os cães. Por isso mandou que eu os aquecesse de qualquer jeito e os trouxesse a você.

Depois de dizer isso, saiu apressado.

Ning Xiaoxiao olhou para os pratos ainda soltando vapor. De repente, perderam todo o encanto.

【Então esse imperador maldito está dizendo que valho menos que um cachorro? Pois não vou comer!】

Irritada, largou os palitinhos de lado, voltou para a cama e cobriu a cabeça para dormir.

Mas a comida estava com um cheiro irresistível!

Obrigada a escolher entre a própria dignidade e a tentação da boa comida, decidiu-se sem hesitar pela segunda opção.

*Ah... Que delícia!*

Depois de cumprir a tarefa, Sanfu voltou ao Palácio Chaoyang para prestar contas. Lu Linyuan, ocupado em examinar memoriais, perguntou: — Entregou?

— Entreguei, Majestade. Mas há algo que este servo não entende. Aqueles pratos foram preparados na hora por ordem de Vossa Majestade, com ingredientes escolhidos entre os melhores. Por que Vossa Majestade mandou dizer que eram sobras do almoço?

— O que você tem a ver com isso? — Lu Linyuan ergueu os olhos e lançou-lhe um olhar atravessado. Em seguida, tamborilou os dedos sobre uma pilha de folhas de papel xuan sobre a mesa.

Sanfu entendeu na mesma hora. Aproximou-se, pegou as folhas e viu que todas traziam o mesmo desenho: um velhinho sorridente de barba branca. — Majestade, quem é esse homem?

— Por que você anda fazendo tantas perguntas ultimamente?

— ... Este servo merece morrer!

— Leve essas imagens e mande espalhá-las dentro e fora do palácio. Quem encontrar esse velho receberá uma grande recompensa de mim.

---

## Notas editoriais

- O retrato estampado no balde é do velhinho do KFC; Lu Linyuan acredita ironicamente na história de que seria o pai de Ning Xiaoxiao.
- O recurso Retroceder tem alcance limitado. Ning percebe tarde demais que deixou passar a janela para desfazer o incidente.
- A primeira bandeja é levada embora junto com o KFC; a bandeja entregue por Sanfu à noite foi preparada novamente, com ingredientes de qualidade. A afirmação de que eram sobras é deliberadamente falsa dentro da trama.
- Os alimentos adquiridos no sistema permanecem quentes e frescos; Lu Linyuan envia metades à cozinha para reproduzir os pratos.
- Papel xuan é um tipo tradicional de papel chinês, citado explicitamente na cena da encomenda de retratos.

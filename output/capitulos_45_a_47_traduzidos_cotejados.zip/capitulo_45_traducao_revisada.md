# Capítulo 45 — O tirano lhe dá comida na boca

Mo Yesuo perdera duas disputas seguidas. Como a vitória era decidida por melhor de três, suas chances haviam acabado.

Pretendia tirar vantagem da dinastia Qi, mas acabara saindo tosquiado. Agora, só lhe restava afogar as mágoas em vinho, bebendo sem parar à mesa.

Lu Linyuan parecia empenhado em ser o homem mais provocador do mundo. — Se o rei de Xiliang gostou tanto deste vinho, mandarei separar duas ânforas para levar quando partir. É o mínimo que posso fazer para retribuir sua generosidade em viajar milhares de li até aqui para me presentear com soldados, cavalos e provisões.

Encerrado o banquete, a primeira providência de Lu Linyuan foi ordenar a Sanfu que levasse homens para prender o diretor do Departamento de Assuntos Internos.

Assim como Sanfu, o diretor era um eunuco de primeiro escalão, um dos servos mais influentes da Cidade Imperial.

Por isso, em particular, os dois viviam se desprezando mutuamente.

Como o imperador resolvera puni-lo sem dar qualquer explicação, Sanfu não resistiu à curiosidade: — Posso perguntar a Vossa Majestade que crime ele cometeu?

Lu Linyuan respondeu com indiferença: — Hoje estou de mau humor. Deu vontade de mandar cortar a cabeça dele.

Sanfu não ousou abrir a boca de novo. E se o imperador continuasse de mau humor e resolvesse levar sua cabeça também? Seria como se meter numa fofoca e acabar virando o alvo dela!

Quando estava prestes a sair, Lu Linyuan o chamou de volta: — Peça também à cozinha imperial que prepare alguns pratos.

Recordou os nomes dos pratos que Ning Xiaoxiao mencionara mentalmente há pouco. — Quero joelho de porco à moda de Dongpo, camarões cristalinos e Buda Salta o Muro.

— O joelho de porco eu entendo, Majestade. Mas Vossa Majestade sempre achou frutos do mar muito cheirosos de peixe e nunca os comeu. Hoje, por que...?

— Não disse que são para mim. Quando ficarem prontos, mande entregá-los a Ning Xiaoxiao, no Palácio Zhongcui.

Pensou por um instante e acrescentou: — Não. Quando ficarem prontos, tragam-nos até mim. Eu mesmo vou levá-los a ela.

Ao ouvir isso, Sanfu deixou escapar um sorriso sugestivo.

Será que seu senhor finalmente viveria um romance bem açucarado?

Que maravilha!

Daqui para a frente, a senhorita Polegar finalmente poderia se aposentar!

*

No caminho de volta ao palácio com Gu Sijin, Ning Xiaoxiao precisou aguentar um longo sermão.

— Xiaoxiao, não pense que estou ralhando sem motivo, mas nunca mais faça algo tão perigoso! Quando você estava quebrando aquela pedra sobre o peito, quase morri de susto. Meu coração veio parar na garganta, de tanto medo de que acontecesse alguma coisa com você.

Ning Xiaoxiao sorriu. — Não se preocupe, minha senhora. Esta serva não faria nada sem ter certeza de que daria certo. Antes de entrar no palácio, eu viajava com uma trupe de artistas de rua para ganhar a vida. Já apresentei muitas vezes o número de quebrar pedras sobre o peito. É moleza.

Cailian espiou o peito de Ning Xiaoxiao e comentou, entre invejosa e ressentida: — Ah, então é por isso que são tão grandes. Ficaram inchados de tanto levar pedrada...

Gu Sijin ainda fez outras recomendações, mas Ning Xiaoxiao não estava nem aí para ouvi-las.

Sua cabeça só conseguia pensar no KFC!

Ao retornar, Gu Sijin retocou a maquiagem e se preparou para apresentar seus cumprimentos à imperatriz.

Quando uma consorte era promovida, precisava agradecer formalmente à imperatriz. Mas a promoção dela fora tão repentina, seguida da visita do rei de Xiliang, que ainda não tivera oportunidade de fazê-lo.

Assim que Gu Sijin saiu com Cailian, Ning Xiaoxiao trancou a porta de seu pequeno quarto pelo lado de dentro. Sentou-se na cama e começou a contar, um por um, os fios de cabelo que havia arrancado do tirano.

【Um, dois, três... Caramba! Vinte e seis fios inteirinhos! Só preciso de vinte para trocar por um balde de frango. Ainda sobram seis! Já tenho como comprar um chá com leite!】

【Hum... Mas o balde de frango não vem com bebida? Melhor economizar!】

Separou seis fios do cabelo do imperador, embrulhou-os em papel e escondeu o pacotinho debaixo do travesseiro.

Nesse instante, Xiao Qi também apareceu com boas notícias.

【Bip, bip, bip! Parabéns, anfitriã, por concluir a missão! O índice de desvio da trama aumentou 3% e agora chegou a 10% no total!】

Finalmente completara um décimo?

Então precisava se recompensar, e depressa!

Ning Xiaoxiao abriu a loja de conveniência em sua mente e, sem perder tempo, trocou vinte fios do cabelo do tirano por um balde de frango do KFC.

O balde se materializou em suas mãos. Ao sentir o cheiro irresistível do frango frito e ver o rosto familiar daquele velhinho de barba branca estampado na embalagem, quase se ajoelhou diante dele para proclamar: Você é meu deus!

Tudo acabara de ser preparado: os hambúrgueres, as coxas de frango, os nuggets e os pedacinhos de frango empanado estavam tão quentes que queimavam os dedos. E o refrigerante vinha até com gelo!

Aquilo era o próprio paraíso!

Ela atacou a comida como um furacão. Quando havia comido mais da metade, a barriga já estava redonda de tão cheia. Resolveu guardar o resto para terminar à noite.

Foi então que ouviu um barulho na porta.

Na verdade, não era alguém batendo: estavam tentando empurrar a porta para entrar, mas a fechadura não deixava.

— Quem é?

— Em plena luz do dia, você tranca a porta porque está fazendo alguma coisa às escondidas?

A voz fria de Lu Linyuan veio do outro lado, assustando tanto Ning Xiaoxiao que ela quase derrubou o balde de frango que segurava.

— Eu estava dormindo, Majestade! Já vou, já vou! Espere só um instantinho!

Em pânico, colocou o balde sobre a cama e puxou a coberta por cima. Limpou a gordura dos cantos da boca e só abriu a porta depois de ter certeza de que não havia nada estranho em sua aparência.

Assim que abriu, ficou paralisada.

O tirano carregava uma bandeja com três pratos suntuosos: joelho de porco à moda de Dongpo, camarões cristalinos e Buda Salta o Muro.

Pareciam tão cheirosos, bonitos e apetitosos que superavam até as iguarias vistas no banquete daquele dia!

Lu Linyuan percebeu sua expressão de espanto e sentiu uma pontinha de orgulho. — Você se saiu bem no número da pedra quebrada sobre o peito. Esta comida é sua recompensa.

Enquanto falava, entrou e pousou a bandeja sobre a mesa. Depois olhou para Ning Xiaoxiao, que continuava imóvel. — Sente-se. Por que está me encarando?

— Ah... sim...

Ning Xiaoxiao sentou-se diante de Lu Linyuan. Os pratos pelos quais salivara tanto pouco antes agora não lhe despertavam o menor apetite.

Afinal, comera praticamente um balde inteiro de frango sozinha e bebera um copo cheio de refrigerante. Mesmo que um chef de restaurante três estrelas Michelin preparasse um banquete ali, não conseguiria engolir mais nada.

Como ela demorava a pegar os talheres, Lu Linyuan achou que estivesse envergonhada. Então, usando os palitinhos, retirou um pedaço de abalone do Buda Salta o Muro e o levou até a boca dela, ordenando:

— Coma.

Ning Xiaoxiao: — ...

【Ele está me dando comida na boca pessoalmente... Se eu não aceitar, não vai parecer uma tremenda falta de consideração?】

Inspirou fundo e se obrigou a engolir o pedaço de abalone.

Lu Linyuan perguntou: — Está gostoso?

Ela assentiu e respondeu, sem nenhum entusiasmo: — Está, está muito gostoso...

— Então coma bastante. Termine tudo isso.

Ning Xiaoxiao: — ...

【Acabei de comer meu KFC! Como vou ter apetite agora?!】

Lu Linyuan franziu as sobrancelhas.

*KFC?* Na cabeça dele, os sons soaram como *ken ji*: *morder o ji* de quem?

*E ela já terminou de morder?*

Uma irritação surda tomou conta dele. Seus olhos percorreram o pequeno quarto até se fixarem na cama de Ning Xiaoxiao.

A coberta estava amontoada de qualquer jeito, formando um volume que parecia esconder uma pessoa.

*Ora, Ning Xiaoxiao! Você é mesmo atrevida!*

*Eu lhe dou comida, roupas e um teto, e você tem coragem de esconder um homem dentro do palácio?*

Sem dizer uma palavra, Lu Linyuan foi até a cama e arrancou a coberta de uma vez...

---

## Notas editoriais

- 西涼王 e 摩謁挲: rei de Xiliang e Mo Yesuo, conforme convenção anterior; 啟朝: dinastia Qi.
- 東坡肘子, 水晶蝦仁 e 佛跳牆: joelho de porco à moda de Dongpo, camarões cristalinos e Buda Salta o Muro, mantendo os nomes culinários e sua identidade.
- 全家桶: balde de frango do KFC; 20 fios de cabelo compram um balde; dos 26 fios, Ning guarda seis. A missão acrescenta 3 pontos percentuais, totalizando 10%.
- 肯德基 (*Kendeji*) remete a KFC em chinês; 陸臨淵 interpreta 啃誰的基 de maneira obscena. Foi mantida a confusão com nota, sem atribuir a ela um equivalente exato em português.
- 拇指姑娘 (menina/garota Polegar) funciona como insinuação sobre a vida íntima anterior de Lu Linyuan; mantido o eufemismo sem inventar cena.

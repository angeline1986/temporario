Capítulo 156 — Começa uma nova missão suicida

Cerca de meia hora antes, Ning Xiaoxiao estava escondida em seu espaço particular, comendo besteiras, lendo uma novel e matando o tempo sem fazer nada, quando Xiao Qi apareceu de repente para lhe apresentar uma nova missão.

— Fazer o tirano comparecer à corte com o penteado do Sanmao.

Era outra missão vantajosa que Xiao Qi conseguira para ela. Sucesso: mais 4 pontos percentuais no índice de desvio da trama. Fracasso: perda de 10% da vitalidade. Se ignorasse o absurdo da tarefa, a relação entre recompensa e penalidade era excelente.

Ning Xiaoxiao ainda quebrava a cabeça, tentando descobrir como fazer Lu Linyuan se submeter, quando ouviu Gu Sijin chamá-la do lado de fora.

Ora, mas aquilo não era exatamente o que diziam sobre procurar por toda parte e encontrar a solução sem esforço?

Ele se entregou de bandeja! Se eu não lhe fizer o penteado do Sanmao, estarei desperdiçando a disposição que demonstrou ao cair sozinho na armadilha!

Com um grande sorriso, abriu a porta e correu ao encontro dele.

De repente, lembrou-se de que acabara de «perder a criança» e não podia parecer feliz demais. Mudou a expressão num piscar de olhos, produzindo um belo choro misturado com sorriso:

— Buuááá! Majestade! Finalmente veio me visitar!

Lu Linyuan franziu a testa diante daquela expressão «complexa». — Você está chorando ou rindo?

Ning Xiaoxiao mentiu com a maior seriedade: — Fico tão feliz ao ver Sua Majestade que tenho vontade de sorrir. Mas, quando me lembro da criança que carregava... não consigo conter as lágrimas.

Ora, vejam só!

Vai mesmo usar essa desculpa para tudo, até para justificar uma viagem à Lua?

Tomou gosto por me representar uma peça de teatro?

Lu Linyuan queria explodir de raiva, mas não tinha um motivo que pudesse admitir em voz alta.

Afinal, fora ele próprio quem, num momento de imprudência, desejara que Ning Xiaoxiao «engravidasse».

Ele mesmo criara aquela pestinha mimada. Agora, que alternativa lhe restava senão continuar a mimá-la?

Engoliu a irritação e, curvando o indicador, enxugou as duas lágrimas que ela conseguira espremer com tanto esforço. — Não chore. Vai acabar machucando os olhos.

Ao lado deles, Gu Sijin assistia à cena com a expressão de quem acabara de provar um doce romântico. Riu discretamente: — Estou um pouco cansada, então não vou atrapalhar Sua Majestade e minha irmã enquanto conversam a sós.

Curvou-se diante do imperador. Ao passar por Ning Xiaoxiao, inclinou-se para lhe sussurrar ao ouvido:

— Capriche esta noite e amanhã já poderá comemorar uma nova gravidez!

Ainda fez um gesto de incentivo com o punho e saiu toda satisfeita.

Naquele exato momento, apenas duas palavras ecoavam na cabeça de Lu Linyuan: «Fuja agora».

Tinha absoluta certeza de que, se não escapasse imediatamente, no instante seguinte se tornaria um «brinquedo» de Ning Xiaoxiao.

Antes que ela dissesse qualquer coisa, apressou-se a falar: — Eu só estava passeando sem nada para fazer. Já vou embora. Descanse cedo.

Como permitir que um pato prontinho para ir à panela abrisse as asas e fugisse?

Ning Xiaoxiao agarrou depressa o braço de Lu Linyuan e disparou a primeira desculpa que lhe ocorreu: — Majestade, está nevando tanto! É melhor ficar aqui!

Nevando tanto?

Lu Linyuan fitou os poucos floquinhos que caíam do céu. Depois de um momento em silêncio, estendeu a mão e observou um floco menor que um grão de arroz pousar em sua palma e derreter no mesmo instante. Então perguntou, meio constrangido:

— Repita, por favor: o que é que está tão grande assim?

Ning Xiaoxiao: 【Você! Você é grande! O maior de todos!】

Ela tinha tantos poderes especiais! Não acreditava que fosse incapaz de manter aquele pobre tirano ao seu lado!

Fechou os olhos com naturalidade, abriu o documento e começou a editar a trama.

No texto original, o tempo naquele momento era descrito por quatro caracteres: «a nevasca está prestes a cessar». Depois de apenas três segundos pensando, trocou-os por «granizo caindo violentamente».

No instante em que confirmou a alteração, pedras de granizo do tamanho de punhos começaram a despencar do céu, quase matando Lu Linyuan ali mesmo.

Ele recuou um passo e se abrigou sob o beiral. Foi então que ouviu Ning Xiaoxiao comentar naquele tom irritantemente provocador: — Está vendo, Majestade? Agora ficou grande!

Lu Linyuan: «...»

Essa maluca realmente nasceu para ser minha desgraça!

Se tentasse retornar ao palácio naquelas condições, talvez antes de chegar ao meio do caminho já anunciassem a «boa notícia» de sua morte.

Sem alternativa, deixou-se conduzir, relutante, para dentro do quarto de Ning Xiaoxiao.

Só então ela reparou no saco de tecido que Lu Linyuan carregava.

Com uma voz manhosa, perguntou: — O que é isso? Sua Majestade ficou com pena de mim por ter perdido a criança e preparou um presente?

Lu Linyuan olhou para ela com olhos claros e um sorriso indulgente. Sua voz foi gentil: — Se gostar, pode ficar com ele. Abra e veja.

Ning Xiaoxiao abriu uma fresta no saco. Assim que viu a ponta de um monte de memoriais empilhados lá dentro, fingiu não enxergar nada e tornou a fechá-lo, como se aquilo nunca tivesse acontecido.

— Deixa para lá, Majestade. Desde que perdi a criança, Sua Majestade me deu tantas coisas boas! Não devemos ser gananciosos. Prefiro não aceitar.

— Desde quando cabe a você escolher? — Lu Linyuan retirou dois memoriais do saco e os atirou para Ning. — Hoje vai aceitar, queira ou não! Entendeu?

Ela realmente não queria ler aquilo.

Nunca imaginara que, tantos anos depois de terminar o ensino médio, acabaria transmigrando só para ter de passar os dias lendo chinês clássico sem uma única anotação explicativa. O que fizera para merecer aquilo?

Por outro lado, talvez fosse a oportunidade perfeita para negociar com o tirano.

— Posso ler, mas Sua Majestade terá de atender a um pedido meu. Depois que eu terminar, deixará que eu lhe faça um penteado novo e irá à corte usando-o!

Lu Linyuan não esperava que ela tivesse a audácia de fazer uma proposta tão absurda abertamente.

Estreitou os olhos e examinou o pescoço longo e claro de Ning Xiaoxiao. Então provocou:

— Se está cansada de manter a cabeça sobre os ombros e quer mudá-la de lugar, basta me dizer diretamente. Não precisa de tantos rodeios.

Ning Xiaoxiao sentiu um arrepio gelado nas costas, que fez os pelinhos de sua nuca se eriçarem.

Instintivamente levou a mão à parte de trás do pescoço. Mesmo assim não desistiu e passou a usar sua arma mais perigosa: a lábia.

— Ah, Majestade! Tenho fundamentos científicos! Tudo isso é para o seu próprio bem!

— Diga uma coisa: quanto é 18.537 multiplicado por 29.572? Sabe a resposta?

Lu Linyuan: «???»

— Está vendo, Majestade? Não sabe! E sabe por quê? Porque seu cabelo é espesso e volumoso demais. Isso sobrecarrega seu cérebro.

Aproximou-se, ergueu delicadamente os cabelos do tirano e, com movimentos ágeis, separou três mechas na frente, reproduzindo o penteado clássico do personagem Sanmao, de *As Aventuras do Pequeno Vagabundo Sanmao*.

Enquanto ajeitava as mechas, explicava: — Basta distribuir parte do cabelo pela testa, em vez de deixar tudo abafando o couro cabeludo. Assim, a mente de Sua Majestade ficará livre e iluminada!

Lu Linyuan permaneceu calado, observando que outra invenção ela ainda seria capaz de apresentar.

Ning Xiaoxiao contemplou-o de frente e não conseguiu conter a risada. — Que lindo! Parece mesmo o Sanmao...

Lu Linyuan franziu a testa. — Parece o quê?

— Nada, nada! Isso não importa! O importante é que Sua Majestade ficou mais inteligente! Vou fazer uma pergunta: quanto é um mais um?

Lu Linyuan lançou-lhe um olhar de quem observava com compaixão alguém completamente desprovido de bom senso. Muito tempo depois, respondeu devagar:

— ...É... dois, não é?

— Acertou! Parabéns, Majestade! — Ning Xiaoxiao quase chorou de felicidade, tão emocionada quanto se o marido em coma tivesse começado a falar de repente.

Apertou com força a mão de Lu Linyuan e declarou com entusiasmo: — Está vendo, Majestade? Sua inteligência reconquistou o território que havia perdido!

Capítulo 154 — O fim da Concubina Shen

Naquele dia, quando arrastaram a Concubina Shen até a câmara escura, os eunucos do Departamento de Punições lhe apresentaram os três tradicionais instrumentos concedidos no palácio a quem recebia a graça de morrer com alguma dignidade:

— Uma faixa de seda branca, uma adaga e uma taça de vinho envenenado.

A Concubina Shen era feroz só na aparência; no fundo, tinha menos coragem que qualquer outra pessoa. Gritou, rasgou a faixa de seda, atirou a adaga para fora da câmara e derramou o vinho pelo chão. Não aceitaria a sentença de jeito nenhum.

Com dor de cabeça por causa do escândalo, um dos eunucos não resistiu a comentar: — Se sabia que podia acabar assim, por que fez aquilo? Não consigo entender. A senhora tinha uma vida tranquila. Por que foi provocar a Nobre Dama Hua? Qualquer pessoa de olhos abertos vê que ela ocupa o lugar mais precioso no coração do imperador, e a senhora resolveu se meter com ela mesmo assim.

Shen agarrou a manga do eunuco. — Eu imploro, senhor, deixe-me ver o imperador uma vez! Passei tantos anos no palácio obedecendo às regras. Cometi um único erro! Não acredito que Sua Majestade seja tão cruel!

Enquanto falava, tirava pulseiras, brincos e grampos de cabelo, enfiando tudo nas mãos do eunuco. — Fique com isto! Dou todas as joias e toda a prata e ouro que tenho em meus aposentos. Só me ajude a encontrar o imperador uma vez!

A fúria de Lu Linyuan naquele dia já era conhecida por todo o palácio.

Até a imperatriz-viúva quase fora punida. Quem ousaria irritá-lo agora?

O eunuco pousou as joias sobre a mesa e fez um gesto de recusa. — Talvez eu até consiga receber esse presente, mas temo não viver para gastá-lo. Sua Majestade levou em conta todos os anos em que a senhora o serviu. Por isso permitiu que morresse com o corpo intacto. Ah, senhora... Seu pai mal havia sido inocentado e recuperado o cargo, e a senhora foi procurar desgraça para si mesma...

Ao ouvir aquilo, Shen ficou imóvel. — Inocentado? O que quer dizer com isso...?

— A senhora ainda não sabe? A Censoria investigou seu pai por corrupção, recebimento de subornos e indicações indevidas de funcionários. O senhor Gu apurou os fatos cuidadosamente e demonstrou sua inocência. Para compensá-lo pela prisão injusta, o imperador ainda lhe concedeu cem taéis de ouro.

Shen agarrou a gola do eunuco com tanta força que os olhos quase saltaram das órbitas. — Isso é verdade?!

Assustado, ele respondeu: — Como eu poderia brincar com uma coisa dessas? Seu pai não mencionou o assunto em nenhuma carta?

Mesmo alguém tão obtusa quanto Shen deveria compreender tudo àquela altura.

Depois de refletir por um instante, entendeu o que de fato acontecera naquele dia: fora a imperatriz quem a manipulara e instigara.

Ela havia sido usada como arma sem sequer perceber!

Cerrando os punhos, sentiu as veias saltarem no pescoço fino, pulsando de ódio.

Se não poderia continuar viva, tampouco deixaria em paz a pessoa que armara tudo pelas suas costas!

Após um breve silêncio, lançou-se de repente para a saída como uma louca. O eunuco, ao vê-la naquele estado, ordenou imediatamente que a detivessem.

— Quero ver o imperador! Tenho algo importantíssimo para contar pessoalmente a Sua Majestade! — gritou Shen até ficar rouca.

— Para que insistir? — respondeu o eunuco, constrangido. — O imperador está ao lado da Nobre Dama Hua, consolando-a. Como poderia vir vê-la?

O medo da morte chegara a tal extremo que Shen acabou deixando de temê-la.

Empurrou o guarda que lhe bloqueava o caminho, voltou e sentou-se firmemente numa cadeira de pinho.

— O imperador me ordenou que tirasse a própria vida. Enquanto eu não fizer isso, ninguém pode me obrigar. Digam a ele que, se não me receber hoje, eu me recusarei a morrer.

O eunuco suspirou impotente, curvou-se ao sair e trancou a porta da câmara.

Não havia janelas. Com a porta fechada, nem um raio de luz entrava.

Cenas da primeira metade de sua vida passavam incessantemente pela mente de Shen. De repente, percebeu que sua existência inteira se resumira a servir de arma nas mãos dos outros, ou a caminhar para a próxima ocasião em que a usariam.

Soltou uma risada desvairada, zombando de si mesma por ter se tornado uma piada completa.

Mais tarde, depois de uma espera de duração incerta, a porta da câmara se abriu.

Uma luz ofuscante entrou, fazendo-a sentir tontura.

Primeiro enxergou uma figura de amarelo-vivo caminhando contra a claridade. Estava prestes a exclamar «Majestade!» quando seus olhos se habituaram à luz e ela reconheceu a visitante.

Era a imperatriz.

Vestia um traje cerimonial amarelo-vivo, bordado com cem aves reverenciando a fênix. Parecia o próprio retrato da nobreza e da magnificência.

Com um sorriso sombrio nos lábios, aproximou-se passo a passo.

Seu rosto costumava transmitir bondade, e sua voz era doce e delicada: a imagem perfeita de uma mãe de toda a nação.

Mas, aos olhos de Shen, a presença invisível daquela mulher agora era sinistra e opressiva, a ponto de lhe arrepiar os pelos.

Enfrentando seu olhar, Shen reuniu forças para perguntar: — Tudo isso foi um plano seu, não foi? Meu pai nunca esteve em perigo! Você escondeu as cartas que ele me enviou e inventou mentiras para me deixar aterrorizada. Depois me atiçou para que fizesse o seu serviço e eliminasse Gu Sijin e Ning Xiaoxiao. Não foi isso?!

A imperatriz sentou-se tranquilamente ao lado dela e, com o indicador, ergueu-lhe o queixo para examinar aquela beleza aparentemente impecável.

— Quer ver o imperador? — perguntou.

Shen afastou sua mão com um tapa, cerrou os dentes e a encarou com olhos injetados de sangue. — Por que fez isso comigo? Entramos no palácio juntas! Sempre obedeci a todas as suas ordens, sempre a tratei com respeito! Eu a considerava sinceramente minha irmã mais velha! Por que quis me destruir?

— Fui eu que a destruí? — A imperatriz riu baixinho e balançou a cabeça. — Você é que é idiota. Este harém sempre foi um ninho de enganos e intrigas. Se consegui usá-la e enganá-la, foi porque você não tinha habilidade suficiente. É burra feito uma porca!

A proteção de unha no dedo mínimo da imperatriz raspou de leve a mesa, produzindo um som semelhante ao das garras de um gato arranhando madeira.

Ao perceber o sorriso triunfante em seu rosto, Shen ficou ainda mais enfurecida.

De um salto, atirou-se contra a imperatriz, prestes a apertar-lhe o pescoço. Xiangling e vários eunucos do Palácio Fengluan avançaram rapidamente e a imobilizaram.

Shen cuspiu na direção da imperatriz e berrou: — Desgraçada! Você vai ter uma morte horrível!

A imperatriz não se irritou. Pelo contrário, sorriu. — Se tivesse permanecido idiota até o fim, eu ao menos respeitaria sua constância. Quando precisava ser esperta, você era burra; quando não deveria perceber nada, resolveu ficar inteligente. Que criatura irritante.

Em seguida, lançou um olhar a Xiangling. Segurando a faixa de seda branca, a criada estrangulou Shen até a morte diante da imperatriz.

Quando Shen parou de respirar, a imperatriz cobriu com a palma da mão os olhos que continuavam abertos e sorriu de leve.

— Trocar sua vida pela perda da criança que Ning carregava no ventre... até que valeu a pena.

Um tanto assustada, Xiangling perguntou: — Majestade, o imperador ordenou que a Concubina Shen se suicidasse. Nós a estrangulamos. E se o legista examinar o corpo e perceber que há algo errado...?

— O imperador queria que ela morresse. Quem se importará com a maneira? Mandem o Departamento de Punições informar que a Concubina Shen cumpriu a sentença e tirou a própria vida. Enterrem o corpo no cemitério das consortes ainda esta noite.

Com um sorriso frio, a imperatriz pegou um lenço, limpou as mãos e foi embora sem olhar para trás.

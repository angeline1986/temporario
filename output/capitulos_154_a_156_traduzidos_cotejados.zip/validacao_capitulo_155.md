# Validação — capítulo 155

- Fonte: `novel_capitulos_121_a_180(20261103-233558).docx`, chinês tradicional.
- Limites: índices de parágrafo DOCX 2355 a 2430 (base zero).
- Unidades não vazias, incluindo título: **73**.
- Linhas de cotejo: **73**.
- Índices duplicados, ausentes ou campos vazios: **0**.
- Correspondência 1:1 por parágrafo não vazio, incluindo título.
- Revisão editorial realizada durante a tradução; **não houve auditoria semântica independente integral**. A contagem igual não garante, por si só, ausência de omissões internas ou equívocos interpretativos.

## Notas editoriais

O palanquim reservado às consortes transporta o próprio imperador: preservado o humor da inversão social. A suposta perda da criança continua sendo uma farsa conhecida por Lu Linyuan e Ning. A expressão 「刑趣」 é um jogo sonoro com 「情趣」, adaptado pelo contraste entre graça conjugal e desgraça penal. Sanmao refere-se ao personagem ficcional de três mechas.

Capítulo 155 — O tirano vira a “consorte favorita” de Xiaoxiao

Sem aquela «criança», Ning Xiaoxiao passou a ter ainda mais motivos para não fazer absolutamente nada no palácio.

Todos os dias dormia até o sol já estar alto. Nem sequer ia cumprimentar a imperatriz.

Por ordem de Lu Linyuan, as cozinhas imperiais preparavam as três refeições de acordo com seu gosto, enviando iguarias sem parar. Bastava ela pedir. Até Sanfu brincava: — Se a Nobre Dama Hua pedisse uma estrela do céu, aposto que Sua Majestade a arrancaria para ela.

Uns seis ou sete dias depois, Lu Linyuan acumulava uma pilha de memoriais sobre assuntos de desfecho incerto. Resolveu convocar Ning Xiaoxiao para que usasse seu «talento especial» e previsse o que aconteceria.

Naquela noite, portanto, escolheu a placa com o nome dela.

Quando os funcionários do Departamento de Assuntos do Leito chegaram ao Palácio Zhongcui com o palanquim Luanming, reservado às consortes convocadas para passar a noite com o imperador, o eunuco Xiao Xiazi entrou todo contente para anunciar a novidade:

— Parabéns, Nobre Dama Hua! Faz dez dias, talvez até quinze, que Sua Majestade não escolhia nenhuma placa. E a primeira que escolheu foi a sua! Que bênção imensa! Prepare-se depressa!

Para qualquer outra mulher, seria uma notícia maravilhosa. Ning Xiaoxiao, porém, não sentiu absolutamente nada. Até bocejou.

Continuou largada no assento aquecido, sem vontade de se mexer.

Com aquele frio lá fora, não era muito melhor ficar no quarto tomando chá com leite, comendo doces e chamando Qiqi, QiaQia e as outras para algumas rodadas de Dou Dizhu? Por que teria de encarar aquele tirano azarado?

Assim, dispensou o convite com um aceno:

— Diga ao imperador que estou cansada e sem ânimo para essa trabalheira. Fica para outro dia.

— Certinho! Vou esperar a senhora lá fora enquanto... Hein?

Só depois de começar a responder foi que Xiao Xiazi percebeu que Ning Xiaoxiao não seguira o roteiro esperado.

— I-isso... A Nobre Dama Hua não deve brincar assim comigo! Não ousaria repetir essas palavras ao imperador! Sua Majestade arrancaria minha cabeça!

— Então invente alguma desculpa por mim. — Abraçando uma almofada macia de penas de ganso, Ning virou-se preguiçosamente no assento aquecido. — Valeu, viu?

Xiao Xiazi: «...»

Se quer que eu morra, é só dizer! Precisa mesmo atormentar um pobre eunuco indefeso desse jeito?!

Uma vez que o palanquim Luanming saía para buscar uma consorte, não existia a possibilidade de regressar vazio ao Palácio Chaoyang.

Se Ning Xiaoxiao se mostrasse arrogante por receber tanto carinho, talvez Lu Linyuan interpretasse aquilo como uma birra da esposa: uma brincadeira íntima do casal.

Mas, se fosse Xiao Xiazi a transmitir a «brincadeira», ela poderia virar motivo de execução. A graça conjugal acabaria em desgraça penal.

Depois de pensar muito, concluiu que, se Ning lhe mandara encontrar uma desculpa, ele precisava escolher uma que não o comprometesse.

Assim, ao voltar ao Palácio Chaoyang, informou:

— Majestade, a Nobre Dama Hua disse que não está se sentindo bem por causa do aborto espontâneo e que hoje não poderá servi-lo durante a noite.

Lu Linyuan: «???»

Você só pode estar de sacanagem comigo.

Ela tomou gosto por essa encenação, foi?

Já não bastaram tantos dias de drama por ter eliminado um intestino cheio de fezes acumuladas?

Agora se atreve até a não vir quando eu a convoco?

Que absurdo!

Há limites para tudo!

Ela acha que minha tolerância lhe dá licença para fazer o que bem entende?

Com o rosto tomado pela fúria, tomou uma decisão que demonstrava sua inabalável dignidade:

— Se ela não vem, eu vou!

Sanfu, porém, pareceu preocupado. — Majestade, a liteira imperial foi enviada à oficina para receber óleo de pinho e manutenção. Com a neve, os caminhos estão enlameados e difíceis de percorrer. Talvez não seja conveniente sair esta noite.

Lu Linyuan fez um gesto grandioso. — Não importa. Se a liteira imperial não está aqui, o palanquim Luanming não continua parado à entrada? Irei nele.

Mas o palanquim Luanming era destinado exclusivamente a transportar consortes chamadas para servir o imperador! Que sentido fazia o próprio imperador embarcar ali?

Sanfu, vendo-o tão determinado, não teve coragem de impedi-lo. Restou-lhe acompanhar a decisão.

Lu Linyuan entrou no palanquim. A meio caminho do Palácio Zhongcui, cruzou com a liteira da Consorte Yun, que regressava aos próprios aposentos.

A criada Bilian anunciou através da cortina: — Minha senhora, é o palanquim Luanming.

— Ah? — Yun ergueu a cortina e espiou. Pela direção em que seguia, provavelmente estava voltando ao Palácio Zhongcui.

Em princípio, depois de toda a comoção de Ning Xiaoxiao pela perda da criança, o Departamento de Assuntos Internos ainda não deveria ter recolocado sua placa verde à disposição do imperador.

A Consorte Duan praticamente nunca era convocada para passar a noite com ele. Portanto, a ocupante daquele palanquim só poderia ser Gu Sijin.

Depois de inventar uma série de explicações, Yun perguntou a Bilian: — Que horas são? Por que o palanquim Luanming está devolvendo alguém tão cedo?

Bilian cobriu a boca para rir. — Ainda estamos na quarta marca da hora Xu, pouco depois das oito da noite. Parece que alguém vai ser devolvida intacta, sem sequer ter sido tocada.

Yun também sorriu. — Ning acabou de perder a criança. Gu Sijin era sua senhora quando Ning ainda trabalhava como criada. Ao olhar para Gu Sijin, o imperador certamente se lembrará dela. Se eu estivesse no lugar de Gu, não apareceria diante dele agora só para provocar irritação.

Enquanto conversavam, os dois palanquins se cruzaram.

Pela etiqueta, Gu Sijin deveria mandar parar para cumprimentar a Consorte Yun. Contudo, o palanquim Luanming passou direto, sem qualquer sinal de que fosse parar.

Uma coisa era Ning Xiaoxiao não respeitar ninguém. Agora Gu Sijin também não a levava a sério?

Indignada, Yun ordenou: — Pare aí! Onde estão seus modos? Passa diante de mim sem sequer me cumprimentar?

Lu Linyuan ergueu lentamente a cortina e lançou-lhe um olhar sombrio.

O belo rosto de Yun perdeu toda a cor. Ela praticamente rolou para fora da própria liteira e caiu de joelhos diante dele:

— M-Majestade?! Fui desrespeitosa! Peço que me perdoe!

Lu Linyuan lançou-lhe um olhar impaciente. — Mandou interromper minha viagem porque quer voltar a discutir comigo se é possível produzir o som de uma palma batendo sozinha?

Yun ficou tão assustada que mal conseguia falar. Deu vários tapas seguidos no próprio rosto. — Faz barulho! Faz, sim! Muito barulho!

Quando voltou a levantar a cabeça, o palanquim Luanming já estava longe.

Bilian ajudou-a a se erguer. Ainda aterrorizada, Yun ofegou: — O que está acontecendo? Por que o imperador está sentado no palanquim das consortes? Ele... está indo ao Palácio Zhongcui?

Sempre se ouvira falar de consortes transportadas ao Palácio Chaoyang. Mas um imperador levado ao aposento de uma consorte? Aquilo era inédito.

Yun talvez conseguisse manter a boca fechada. Mas muitas outras pessoas tinham testemunhado o «grande feito» de Lu Linyuan. E criados desocupados, quando começavam a fofocar, tornavam qualquer história mais extravagante.

Mais tarde, depois de passar de boca em boca, o episódio assumiu esta versão:

— Para agradar à Nobre Dama Hua, o imperador entrou pessoalmente no palanquim Luanming, fez de si mesmo uma «consorte favorita» e mandou que o transportassem ao Palácio Zhongcui!

Mas isso viria depois. Naquela noite, assim que chegou ao Palácio Zhongcui, Lu Linyuan parou diante do quarto de Ning Xiaoxiao e se preparou para abrir a porta. Antes, porém, ouviu um pensamento dela:

【Xiao Qi, seu desgraçado! Como diabos vou convencer o tirano a ir à corte com aquele penteado do Sanmao?!】

Lu Linyuan: «???»

Que nova loucura essa mulher está planejando?

Ela não consegue viver sem me atormentar até a morte?

Passou a mão pelos cabelos negros, lisos e sedosos. Depois de pensar por um instante, mudou de ideia:

— É melhor fugir!

Mas não tinha dado dois passos quando Gu Sijin saiu de um dos aposentos laterais e o cumprimentou de longe: — Majestade! O que o traz aqui com toda esta neve?

Então gritou na direção do aposento lateral oeste: — Xiaoxiao! O imperador veio visitá-la!

Lu Linyuan: «...»

Muito obrigado mesmo!

# Validação — capítulo 156

- Fonte: `novel_capitulos_121_a_180(20261103-233558).docx`, chinês tradicional.
- Limites: índices de parágrafo DOCX 2431 a 2503 (base zero).
- Unidades não vazias, incluindo título: **70**.
- Linhas de cotejo: **70**.
- Índices duplicados, ausentes ou campos vazios: **0**.
- Correspondência 1:1 por parágrafo não vazio, incluindo título.
- Revisão editorial realizada durante a tradução; **não houve auditoria semântica independente integral**. A contagem igual não garante, por si só, ausência de omissões internas ou equívocos interpretativos.

## Notas editoriais

A missão vale +4 pontos percentuais no índice de desvio da trama e -10% de vitalidade em caso de fracasso; estes são valores da missão, não total acumulado. A alteração do clima no documento causa granizo. O capítulo termina antes de a condição de comparecer à corte com o penteado ser cumprida. A expressão “1 1” no DOCX foi interpretada como 1+1 pelo contexto da resposta 2; manter ressalva em auditoria futura.

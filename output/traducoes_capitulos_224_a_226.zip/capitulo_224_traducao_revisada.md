# Capítulo 224 — Especial de Qixi: o azarado de plantão × a pequena fada

Qingyang era do tipo que adorava assistir a uma confusão e ainda atiçar o fogo. Dessa vez, porém, empenhava-se como nunca em convencer Ning Xiaoxiao a parar de fazer birra e voltar logo.

Afinal, se Xiaoxiao não voltasse, acabaria atrapalhando os planos que ela tinha para aquela noite com Huanü.

Ela a aconselhou com toda a sua suposta sinceridade: — É melhor você voltar. Se está insatisfeita, vá tirar satisfações com ele cara a cara. E, se ele ousar levantar a voz, eu mesma defenderei você!

Com aquela garantia, Ning Xiaoxiao arregaçou as mangas e se preparou para ir acertar as contas com Lu Linyuan.

Só que, ao retornar ao quarto, encontrou dois lanternins vermelhos que pareciam ter brotado do nada à porta.

Confusa, empurrou a porta e ficou completamente boquiaberta.

Quando saíra, o quarto era perfeitamente comum. Fora o espaço generoso, não havia nada de especial nele.

Agora, dísticos vermelhos com inscrições negras emolduravam a entrada. Sobre a cama repousava uma colcha vermelha com dragão e fênix auspiciosos, salpicada de tâmaras-vermelhas, amendoins, longanas e sementes de lótus. Nem era preciso explicar o significado daquilo.

As velas vermelhas acesas no quarto traziam o caractere de dupla felicidade, 囍. Por mais que olhasse, tudo parecia decoração de quarto de núpcias!

Enquanto ainda tentava entender a surpresa, Lu Linyuan surgiu atrás dela sem que percebesse e se inclinou para murmurar ao seu ouvido:

— Agora que o leite chegou, ainda dá tempo?

Ning Xiaoxiao: — ￣□￣｜｜

O estranho era que ele falara em beber, mas não havia nele o menor cheiro de álcool.

Será que...?

— Vossa Majestade me mandou embora de propósito para preparar tudo isso?

— Vejo que não é tão boba assim.

Lu Linyuan tomou-lhe a mão e se sentou com ela na beira da cama.

Ning Xiaoxiao ainda não se recuperara do espanto. Não era nenhuma data especial. Por que ele deixara o quarto tão festivo?

— Majestade... que história é essa que você inventou hoje...?

Acariciando-lhe o lóbulo da orelha, Lu Linyuan respondeu baixinho: — Achei bonito e festivo. Perguntei ao príncipe Duan como ele e a esposa mantêm o relacionamento. Ele me disse que a novidade acaba se dissipando e, então, resta a tranquilidade de serem uma família.

— Não quero que essa tal novidade desapareça entre nós. Por isso decidi que, quando voltarmos ao palácio, teremos um casamento pequeno a cada três dias e um grande a cada cinco. Hoje é só o ensaio.

Ele a envolveu nos braços e, de repente, assumiu uma seriedade incomum:

— Andei pensando em algumas coisas e percebi que não tenho sido justo com você.

— Você se dedica exclusivamente a mim, e eu sinto o mesmo por você. Mas, para quem olha de fora, continuo sendo um homem com três esposas e quatro concubinas.

— Prometo que, quando os assuntos da corte estiverem resolvidos, deporei a imperatriz, dissolverei o harém e mandarei apagar dos registros oficiais, tanto da corte quanto dos aposentos internos, todas as referências a elas. Você será minha única imperatriz.

Abaixou a cabeça e roçou de leve o queixo nos cabelos junto à testa de Ning Xiaoxiao. Sua voz tornou-se perigosamente sedutora:

— Então, quando eu pedir aquilo de novo, você não poderá me negar.

Ning Xiaoxiao: — ???

【Caralho! Mas que conversa indecente é essa?!】

【Meu irmão, se você pedisse agora mesmo, eu daria! Daria, daria, daria!】

【Hum... espera... ele acabou de se chamar de “eu”?】

Ao perceber isso, Ning Xiaoxiao ficou olhando para ele com expectativa. Antes que pudesse dizer qualquer coisa, Lu Linyuan perguntou:

— Por que está me encarando assim?

Ela soltou uma risadinha às escondidas e não perguntou por que ele havia mudado sua forma de se referir a si mesmo.

Porque sabia que, diante dela, ele já deixara de lado a identidade de imperador.

Naquele momento, era apenas um homem comum, de dedos entrelaçados aos da mulher amada, desfrutando serenamente da vida.

A paisagem noturna de Minxiang era belíssima. Acima da cama dos dois havia uma claraboia por onde se viam incontáveis estrelas.

Ficaram contemplando a lua e as estrelas, conversando sem pressa sobre o que tinham visto durante a viagem.

De repente, Lu Linyuan teve uma ideia: — Que tal jogarmos pedra, papel e tesoura? Quem perder terá de responder a uma pergunta do outro.

Ning Xiaoxiao arregaçou as mangas, animada: — Vamos! Acha que tenho medo de você?

Lu Linyuan carregava consigo uma verdadeira ferramenta para trapacear. Se não quisesse perder, Ning Xiaoxiao poderia jogar a noite inteira sem ganhar uma rodada sequer.

Na primeira partida, não houve surpresa: Ning Xiaoxiao mostrou pedra; Lu Linyuan, papel. Vitória dele.

— Quando foi que você se apaixonou por mim? E quero a verdade.

Apoiando o queixo na mão, Ning Xiaoxiao refletiu um pouco antes de responder com seriedade:

— Para ser sincera, nem eu sei direito. Só sei que, quando percebi que talvez estivesse apaixonada por Vossa Majestade, você já se tornara alguém muito importante para mim...

Ao terminar, viu no rosto dele um sorriso de absoluta satisfação e acabou ficando envergonhada.

Querendo encerrar o assunto, logo começou a agitar o punho: — Outra! Outra!

Dessa vez, Lu Linyuan perdeu de propósito e a deixou vencer.

Como ele previra, Ning Xiaoxiao devolveu exatamente a mesma pergunta:

— E Vossa Majestade? Quando começou a gostar de mim?

Ele sorriu. — Muito, muito tempo atrás. E, desde então, gosto cada vez mais. Se me perguntar quanto eu a amo, a resposta é que amanhã sempre a amarei mais do que hoje.

Ao ouvir aquilo, um terço do coração de Ning Xiaoxiao se encheu de emoção; os outros dois terços, de vontade de fazer piada:

【Socorro... lá vem ele todo meloso de novo!】

【Então essas cantadas cafonas já existiam desde a Antiguidade?!】

Era óbvio que ela não acreditava naquela declaração.

— Combinamos de falar a verdade, Majestade! Por que está inventando? Muito tempo atrás? Quanto tempo? Desde que Pangu separou o céu da terra?

— Aposto que você não se apaixonou antes de mim!

Casais que descobrem aos poucos as qualidades um do outro durante a convivência e acabam se apaixonando parecem sempre fazer essa pergunta.

É infantil e desnecessário. Mesmo assim, os dois insistem em decidir quem ganhou.

Como se ter amado primeiro fosse prova de um sentimento mais profundo e desse alguma vantagem naquela discussão.

Lu Linyuan provocou, sorrindo: — Então você quer provas?

Tomou-lhe a mão e passou suavemente os dedos sobre o bracelete de jade em seu pulso. — Lembra quando lhe dei este bracelete?

Claro que lembrava.

Por causa daquele bracelete, Lu Linyuan contraíra uma epidemia e quase perdera a vida.

Sem entender aonde ele queria chegar, Ning Xiaoxiao assentiu e retrucou: — Não vai me dizer que já gostava de mim naquela época, vai? Ah, fala sério! Essa é difícil de engolir...

【Eu passava o dia pensando em maneiras de atormentá-lo, e ele vivia dizendo que ia me matar! Que amor o quê! Ele era masoquista, por acaso?】

Lu Linyuan não discutiu. Com extremo cuidado, tirou-lhe o bracelete do pulso.

Sustentou-lhe os dedos na palma da mão e guiou suas pontas pela superfície interna da joia.

Desde que o recebera, Ning Xiaoxiao nunca o havia tirado. Agora, ao tocá-lo, percebeu que a parte interna apresentava pequenas irregularidades, quase imperceptíveis.

Vendo seu olhar surpreso, Lu Linyuan sorriu de leve. — Olhe com atenção o que há aí dentro.

Ning Xiaoxiao aproximou o bracelete da luz da vela e examinou o interior.

E descobriu quatro caracteres gravados ali, em traços claros, perfeitamente legíveis:

— Meu coração ama você.

*

Por hoje é só~ Feliz Qixi para vocês~

ღ( ´･ᴗ･` ) Um coraçãozinho para vocês!

# Validação — Capítulo 225

- **Fonte:** `novel_capitulos_212_a_270(20261105-204934).docx`, original chinês tradicional.
- **Limites no DOCX:** parágrafos de índice 952 até 1017 (base zero), antes do título do capítulo seguinte.
- **Unidades não vazias cotejadas:** 63 (inclui título, sinais divisórios e notas autorais).
- **Cabeçalho CSV:** `indice_docx,original_chines,traducao_portugues`.
- **Índices duplicados:** 0.
- **Unidades sem correspondência:** 0.
- **Campos traduzidos vazios:** 0.
- **Tradução integral:** tradução elaborada diretamente a partir de cada parágrafo do chinês, com preservação estrutural 1:1.

## Observações editoriais

Título “A morte do príncipe Jing” preserva o anúncio do original, embora a sequência seguinte ofereça uma reversão temporal. O termo 私湯 foi traduzido como “banho privativo” e sua nota explicativa foi mantida. 癸水 / 來小日子 / 親戚來了 são eufemismos para menstruação e foram adaptados conforme o registro. 一個時辰 corresponde a aproximadamente duas horas. “Onde Ren Duanli se hospedou?” é uma provocação da autora, não informação narrativa. “Pavilhão de Estudos Bitong”, “Pavilhão da Chuva”, “Recanto das Flores Ébrias” e “Pavilhão da Liberdade” são traduções funcionais dos topônimos, sujeitas a glossário de projetos anteriores.

## Limites da validação

A auditoria automática verifica índices, quantidade de unidades, campos e coerência estrutural dos arquivos. Não constitui uma segunda revisão independente integral do sentido em chinês. Passagens ambíguas foram indicadas acima.

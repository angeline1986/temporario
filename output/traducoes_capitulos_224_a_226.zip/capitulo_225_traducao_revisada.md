# Capítulo 225 — A morte do príncipe Jing

Então ele já tinha se apaixonado por ela tanto tempo antes.

Tudo aquilo fora cuidadosamente planejado. Havia muito tempo que ele nutria aquelas intenções.

Aninhada nos braços dele, Ning Xiaoxiao não fez nenhuma declaração sentimental ou exageradamente comovida.

Sabia que, daquele momento em diante, provavelmente passaria o resto da vida rendida àquele homem que, afinal de contas, era um personagem de ficção.

Mas...

Era uma rendição da qual não se arrependia nem um pouco.

*

Partiram de Minxiang e chegaram à estância termal na tarde do dia seguinte.

Comparada à residência imperial de verão, a estância termal era muito menor.

Havia apenas vinte e um aposentos onde se podia hospedar alguém.

E, entre eles, só quatro eram um pouco mais amplos e adequados aos senhores de posição elevada.

Lu Linyuan ficou no Pavilhão de Estudos Bitong, onde poderia lidar facilmente com os memoriais enviados do palácio. O lugar era espaçoso e também permitia receber os oficiais da região para tratar de assuntos do governo.

Ning Xiaoxiao instalou-se no Pavilhão da Chuva, atrás do Pavilhão de Estudos Bitong, a apenas uma centena de passos de distância. Em todas as dinastias anteriores, aquela residência fora reservada exclusivamente à imperatriz.

A princesa mais velha e Huanü ficaram no Recanto das Flores Ébrias, o lugar mais florido de toda a estância e também o mais afastado dos demais aposentos, muito tranquilo. As duas gostavam de plantar e cuidar de flores e não apreciavam agitação; não poderia haver lugar mais adequado para elas.

Lu Yiqiu hospedou-se no Pavilhão da Liberdade, o mais próximo da saída da estância e das vilas vizinhas. Como ele adorava passear e se divertir, era a escolha ideal.

Havia, porém, um detalhe: as outras residências possuíam fontes termais privativas atrás dos dormitórios. O Pavilhão da Liberdade, por ficar muito longe da nascente, não tinha nenhuma.

(PS: “Banho privativo” é uma expressão usada nas estâncias termais para designar o banho em uma fonte termal reservada. A água quente é conduzida até uma piscina interna, o que torna tudo mais cômodo.)

Quanto ao lugar onde Ren Duanli estava hospedado... adivinhem vocês mesmos. (Carinha maliciosa.)

*

Depois de se instalarem, todos estavam com o corpo dolorido e cansado por causa da longa viagem.

Nada melhor que um banho termal para aliviar a fadiga. A piscina privativa do Pavilhão de Estudos Bitong, onde Lu Linyuan estava hospedado, chamava-se Piscina do Dragão: grande, luxuosamente decorada e espaçosa. Os criados da estância haviam começado os preparativos um mês antes, deixando tudo pronto.

Durante a segunda metade da viagem, Lu Linyuan só conseguia pensar em entrar numa fonte termal com sua esposinha e aproveitar a oportunidade para umas safadezas.

Mas os planos nem sempre sobrevivem à realidade. Mal haviam chegado à estância e descarregado a bagagem, a visita mensal de Ning Xiaoxiao apareceu...

Ela recusou delicadamente o convite para o banho a dois. — Majestade, por que não vai primeiro sozinho? Hoje não estou me sentindo muito bem...

Ao perceber que ela estava menstruada, Lu Linyuan perdeu imediatamente qualquer vontade de se divertir sozinho.

Começou a remexer na bagagem, e Ning Xiaoxiao perguntou, curiosa: — O que está procurando, Majestade?

Pouco depois, ele retirou um enorme saco de papel cheio até a boca de açúcar mascavo e gengibre em pó.

— Sei que a estância também tem esses ingredientes, mas não se comparam aos do palácio. Por isso pedi a Sanfu que os preparasse antes de sairmos. Trouxe estes comigo para o caso de você passar mal durante a viagem. Na última carruagem da comitiva há mais uma carga inteira. Acho que será suficiente.

— ...

Ning Xiaoxiao lembrou-se de quando Gu Sijin ficara menstruada e Lu Linyuan preparara para ela um panelão daquele “remédio milagroso contra cólicas”. Um pouco enciumada, provocou: — Quando Sijin estava naqueles dias, Majestade, você também mandou preparar um caldeirão de ervas fortificantes para ela.

— Mas é claro! — Lu Linyuan dobrou o indicador e deu-lhe uma leve batida com o nó do dedo na testa. — Naquela época você ainda era uma criada do palácio. Eu não podia presenteá-la abertamente. Mandei sete dias seguidos uma panela de remédio para o Palácio Zhongcui porque sabia que Gu Sijin não conseguiria beber tudo e que uma parte acabaria sobrando para você. Entendeu?

Esfregando a testa, Ning Xiaoxiao mostrou-lhe a língua com travessura. — Quem diria! Majestade, você é um pervertidinho muito discreto~

— Quem você está chamando de pervertido?

— ...

— Irmããão~~!

A voz de Lu Yiqiu chegou antes dele.

Chamando Lu Linyuan com seu jeitinho infantil, veio correndo e abriu a porta do dormitório sem pedir licença ou esperar que o anunciassem.

Vestia um roupão de banho. Ren Duanli vinha logo atrás, com uma expressão visivelmente ressentida.

— Irmão~! Por que o Pavilhão da Liberdade não tem banho privativo? Não posso simplesmente entrar na piscina pública e deixar todo mundo ver minhas partes íntimas!

Lu Linyuan fechou a cara. — Se vier me procurar outra vez sem bater à porta, arranco seu couro.

— Ah, irmão! — Lu Yiqiu agarrou-lhe o braço, fazendo manha. — Já perguntei! Os únicos aposentos com banho privativo são o Recanto das Flores Ébrias da nossa irmã mais velha, o Pavilhão da Chuva da minha cunhada e o seu!

— Não tenho coragem de pedir à nossa irmã mais velha, porque ela vai me bater. E, além disso, homens e mulheres têm de manter certa distância; não posso ficar mergulhado na piscina particular dela, não é?

— A da cunhada nem se fala, está cheia de criadas atendendo...

Ele abaixou a cabeça e começou a encostar as pontas dos indicadores uma na outra. — Então... posso ficar um pouquinho na sua? Só um pouquinho!

— Não. — Lu Linyuan nem se deu ao trabalho de discutir. Fez um gesto de dispensa e disse a Ren Duanli: — O que está esperando? Leve-o daqui.

— Às ordens de Vossa Majestade.

Ren Duanli o ergueu como quem carregava um cachorrinho teimoso. Ele tentava sair, enquanto Lu Yiqiu chutava o ar e se debatia:

— Aaaah! Cunhada! Cunhadinha, você é a melhor! Me deixa ir, vai! Minha cunhada é linda e bondosa, tenho certeza de que vai concordar! Cunhadinha, me dá um abraço!

Ning Xiaoxiao nem queria se meter no assunto. Mas ele a chamara de cunhada! E ainda dissera que era linda e bondosa...

Uma criança de língua doce sempre ganha um agrado. Assim, ela intercedeu casualmente: — A água das piscinas privativas é trocada todos os dias. Os criados já prepararam pétalas e essências, e seria desperdício não aproveitar. Viemos passear para nos divertir. Que tal deixá-lo usar a piscina só desta vez, Majestade?

Como era de esperar, a palavra da esposinha funcionou. Bastaram aquelas poucas frases para virar o jogo.

Lu Linyuan lançou um olhar atravessado a Lu Yiqiu e respondeu, resignado: — Já que sua cunhada pediu por você, permitirei essa travessura, mas só hoje.

Seu olhar foi de Lu Yiqiu a Ren Duanli. Depois, indicou com a cabeça a piscina privativa atrás do quarto.

— Duas horas. E não façam muito barulho, ou vão me ouvir.

Ao ouvir aquilo, Ren Duanli corou ligeiramente. Já Lu Yiqiu, com sua inocência de bobo, não captou a insinuação do imperador. Pegou a mão de Ren Duanli e saiu saltitando de felicidade em direção à piscina.

Ao vê-lo assim, Lu Linyuan suspirou, sem saber o que fazer. — Um homem feito e continua agindo como uma criança, fazendo algazarra o dia inteiro.

Ning Xiaoxiao sorriu. — A inocência e a sinceridade são justamente as qualidades mais singulares do príncipe Jing. Outros nobres talvez estejam ocupados tramando maneiras de conquistar poder, mas ele só quer levar uma vida livre e feliz. É por isso que Vossa Majestade lhe concede um tratamento tão especial, não é?

Lu Linyuan esfregou as mãos para aquecê-las e as pousou sobre o baixo-ventre de Ning Xiaoxiao. — Que ele faça a bagunça que quiser. Não vou me incomodar. Por que não vai se deitar um pouco? Vou à cozinha pequena preparar chá de gengibre com açúcar mascavo para você se aquecer.

— AAAAAH!!!

Mal acabara de falar quando um grito lancinante veio da Piscina do Dragão.

Logo depois, os gritos aterrorizados de Xiao Yinzi chegaram aos ouvidos dos dois:

— O-o que aconteceu?! Rápido! Rápido, tirem Sua Alteza da água!

# Capítulo 226 — Regicídio

O Pavilhão de Estudos Bitong mergulhou imediatamente no caos.

Gritos e lamentos de dor se sucediam sem parar.

Lu Linyuan e Ning Xiaoxiao correram para ver o que estava acontecendo. A cena diante deles era estarrecedora...

A Piscina do Dragão estava tomada por uma nuvem de vapor. A água do banho privativo borbulhava violentamente, soltando enormes quantidades de vapor escaldante.

Lu Yiqiu boiava no meio da piscina. A pele e a carne de seu corpo já haviam sido cozidas e destruídas pelo calor. A cena era horrivelmente sangrenta.

Ning Xiaoxiao soltou um grito, levando a mão à boca. Lu Linyuan conteve a própria dor e cobriu os olhos dela.

Os criados que tinham tentado entrar na água para resgatar o príncipe Jing ficaram cheios de bolhas de queimadura assim que a ponta de seus pés a tocou.

Era fácil imaginar o quanto aquela água estava quente. E, com Lu Yiqiu flutuando na superfície de uma piscina que parecia uma panela fervente, que possibilidade de sobrevivência poderia haver?

Ren Duanli não planejara entrar na fonte termal. Sua intenção era apenas fazer companhia a Lu Yiqiu e observá-lo se divertir.

Quando Lu Yiqiu entrou na água, estava tudo normal. Mas, num piscar de olhos, a superfície começou a ferver. Ele soltou um único grito antes de afundar completamente e ficar imóvel.

Ren Duanli mergulhou imediatamente para salvá-lo. Felizmente, Xiao Yinzi ordenou que o puxassem para fora depressa. Mesmo tendo ficado na água apenas um instante, suas pernas, das panturrilhas às coxas, já estavam marcadas por queimaduras e sangue. Provavelmente jamais voltariam a funcionar direito.

Ainda assim, ele rangia os dentes e tentava se arrastar novamente para dentro da piscina, como se não se importasse em morrer...

Se Lu Linyuan não tivesse mandado os criados contê-lo, ele provavelmente acabaria tão destruído quanto Lu Yiqiu.

Tudo acontecera rápido demais. Ning Xiaoxiao ficou paralisada, com as lágrimas escorrendo sem parar.

Nunca vira uma cena tão aterrorizante. Pior ainda: a pessoa que acabara de morrer daquela maneira era alguém que ela conhecia!

Um instante antes, Lu Yiqiu estava ali, fazendo gracinhas com aquele jeito irritante, mas adorável. Agora não passava de um cadáver irreconhecível...

Ela respirou fundo e se esforçou para se recompor. Ainda bem. Ainda havia tempo.

Fechou os olhos, abriu o documento da trama e começou a apertar freneticamente a tecla Retroceder.

Três minutos antes:

Lu Linyuan esfregou as mãos para aquecê-las e as pousou sobre o baixo-ventre de Ning Xiaoxiao. — Que ele faça a bagunça que quiser. Não vou me incomodar. Por que não vai se deitar um pouco? Vou à cozinha pequena preparar chá de gengibre com açúcar mascavo para você se aquecer.

Sem esperar que ele terminasse de falar, Ning Xiaoxiao apertou decididamente a tecla Pausar. Quando todas as coisas ficaram imóveis no tempo, disparou em direção à piscina privativa como uma flecha.

Lu Yiqiu estava congelado no ar, numa posição ridícula de salto, parecendo um enorme sapo verde.

Se Ning Xiaoxiao tivesse se atrasado apenas um segundo, ele teria mergulhado na água e sua morte seria inevitável...

Parada à beira da piscina, agarrou Lu Yiqiu pelas roupas e o puxou de volta. Só então apertou Reproduzir.

A trama prosseguiu:

Lu Yiqiu completou o salto e caiu violentamente sobre o piso de mármore. Gritou de dor sem parar:

— Aaaaaah! Vou morrer, vou morrer, vou morrer!

Ren Duanli correu para examiná-lo. Era apenas um braço deslocado.

Sem sequer avisar, recolocou o braço de Lu Yiqiu no lugar à força. A dor fez o príncipe chorar e soltar um palavrão.

Ainda no dormitório, Lu Linyuan vira Ning Xiaoxiao desaparecer diante de seus olhos e reaparecer junto à piscina. Esfregou os olhos, sem acreditar no que vira.

Os criados que serviam na piscina também ficaram perplexos. Tinham visto claramente Lu Yiqiu saltar em direção à água. Como, então, ele aparecera de repente no chão, tão longe da piscina?

Ning Xiaoxiao deu uma olhada nos próximos trechos da trama. Todos estavam cheios de perguntas sobre seu súbito “teletransporte”.

Ela não tinha paciência para explicar — nem saberia como. Por isso, resolveu usar o poder de Modificar a trama e apagou o incidente da memória de todos eles.

Com o braço recolocado, Lu Yiqiu continuou sem aprender a lição e quis saltar de novo para a fonte termal.

Dessa vez, Ning Xiaoxiao o deteve. — Alteza, príncipe Jing, espere um pouco. Tenho a impressão de que há algo errado com essa piscina.

【Não entre aí de novo! Se você pular e acabar cozido vivo, acho que vou ter pesadelos...】

Fazia tanto tempo que Lu Linyuan não ouvia os pensamentos de Ning Xiaoxiao prevendo o futuro que quase se esquecera de que sua querida possuía aquela “habilidade”.

Segundo o que Ning Xiaoxiao acabara de pensar, Lu Yiqiu seria cozido vivo caso entrasse na água?

Mas a água termal estava numa temperatura agradável; no máximo, faria alguém suar bastante. Como poderia cozinhar uma pessoa?

Lu Linyuan conhecia, porém, a precisão das previsões da esposa. Por isso, impediu Lu Yiqiu de entrar e ordenou aos criados que verificassem primeiro a temperatura da água, em busca de qualquer anormalidade.

Xiao Yinzi encheu um balde de madeira com a água termal. Lu Linyuan mergulhou a mão e constatou que estava perfeitamente normal, na temperatura esperada de uma fonte termal.

Ning Xiaoxiao também a testou e ficou ainda mais intrigada:

【Mas basta o fofinho do príncipe Jing pular aí que a água começa a ferver... Como isso funciona?!】

Se a água não tinha problema, a armadilha só podia estar na própria Piscina do Dragão.

Lu Linyuan ordenou que os criados esvaziassem a piscina e a examinassem cuidadosamente.

Assim que a água foi retirada, Ren Duanli entrou no tanque vazio e começou a bater nos ladrilhos do fundo. Não demorou a descobrir que havia algo escondido ali.

Um dos ladrilhos emitia um som nítido e oco quando golpeado, evidenciando que não havia terra firme por baixo, mas um espaço vazio.

Lu Linyuan ordenou que quebrassem os ladrilhos do fundo da piscina. Foi então que todos viram uma quantidade incontável de cal virgem escondida sob eles.

Os ladrilhos também faziam parte de um mecanismo interligado.

A água da piscina exercia pressão sobre o piso. Como o volume de água colocado ali era sempre previamente determinado, também era fixo o limite de pressão que o mecanismo suportava.

Quando alguém entrasse na piscina, mesmo que o nível da água subisse apenas uma fração de milímetro, o mecanismo seria acionado. Os ladrilhos se afastariam ligeiramente e revelariam canais repletos de cal virgem.

Uma enorme quantidade de cal virgem entraria em contato com a água, absorvendo-a e liberando calor. Bastariam alguns instantes para transformar a água da fonte termal em água fervente.

Uma armadilha tão meticulosamente calculada só podia ter sido preparada com a intenção de matar quem entrasse naquela piscina.

Evidentemente, Lu Yiqiu não era o alvo de quem planejara tudo aquilo.

Afinal, aquela era a Piscina do Dragão. Além do imperador, ninguém tinha permissão para usá-la.

O fato de Lu Yiqiu ter ido até ali naquele dia fora puro acaso.

Se Ning Xiaoxiao não tivesse menstruado naquele dia, certamente seriam ela e Lu Linyuan a entrar na fonte termal.

O rosto de Lu Linyuan ficou sombrio como nunca. Todos prenderam a respiração, sem ousar emitir um som.

Depois de um longo silêncio, ouviram-no ordenar com uma voz fria até os ossos:

— Transmitam meu decreto: prendam todos os criados que servem nesta estância termal e levem-nos à sala de interrogatório. Quero que arranquem deles a verdade, custe o que custar!

(PS: Hoje preciso pegar um avião, então vão ser só duas atualizações. Compenso amanhã a que ficou faltando. Amo vocês~)

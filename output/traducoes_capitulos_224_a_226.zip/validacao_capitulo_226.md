# Validação — Capítulo 226

- **Fonte:** `novel_capitulos_212_a_270(20261105-204934).docx`, original chinês tradicional.
- **Limites no DOCX:** parágrafos de índice 1018 até 1082 (base zero), antes do título do capítulo seguinte.
- **Unidades não vazias cotejadas:** 62 (inclui título, sinais divisórios e notas autorais).
- **Cabeçalho CSV:** `indice_docx,original_chines,traducao_portugues`.
- **Índices duplicados:** 0.
- **Unidades sem correspondência:** 0.
- **Campos traduzidos vazios:** 0.
- **Tradução integral:** tradução elaborada diretamente a partir de cada parágrafo do chinês, com preservação estrutural 1:1.

## Observações editoriais

A morte e as queimaduras da primeira linha temporal não foram tratadas como definitivas após o uso de Retroceder, Pausar, Reproduzir e Modificar. A cal virgem reage exotermicamente com água; preservada a explicação narrativa, sem endossar sua precisão técnica. “Regicídio” traduz 弑君 como título, embora o crime seja tentativa de assassinato do imperador, não morte confirmada. O original traz 無比要, aparentemente erro por 務必要, e o comando foi vertido pelo sentido contextual. Preservada a nota da autora sobre viagem e atualização.

## Limites da validação

A auditoria automática verifica índices, quantidade de unidades, campos e coerência estrutural dos arquivos. Não constitui uma segunda revisão independente integral do sentido em chinês. Passagens ambíguas foram indicadas acima.

# Capítulo 185 — Só depois percebi o quanto já estava perdida

A alegria daquele reencontro após tantos anos, intensificada pelo álcool, cresceu sem limites. Chu Xingran avançou e envolveu Gu Sijin num abraço tão apertado que parecia querer fundi-la ao próprio corpo.

Aquele abraço fez Gu Sijin duvidar por um instante de que tudo fosse real.

Ela também o abraçou com força, enquanto lágrimas enormes rolavam por seu rosto como pérolas.

Com o coração apertado, Chu Xingran inclinou a cabeça e depositou um beijo suave nas pálpebras dela.

Os sentimentos que os dois haviam reprimido por anos se libertaram de uma vez. Chu Xingran segurou Gu Sijin pela parte de trás das coxas e a ergueu nos braços, beijando-a na boca sem hesitar.

Seu beijo foi intenso. Como Gu Sijin correspondeu, ele se tornou ainda mais ousado, aprofundando o beijo.

Mas aquele arrebatamento não durou muito: Gu Sijin o interrompeu.

Ela o empurrou pelo peito, e seus lábios se separaram devagar. — Primeiro, me ponha no chão.

Seu rosto e sua voz estavam frios, como se quisesse apagar com aquela frieza o fogo que ardia no peito de Chu Xingran.

A luz fria da lua banhava seu corpo. Os fios especiais com que os bordados de seu manto haviam sido feitos refletiam a luz como ondulações sobre a água.

Aquela era uma vestimenta reservada às consortes imperiais.

O embriagado Chu Xingran recuperou aos poucos a lucidez. Uma pergunta surgiu em sua mente, cuja resposta já parecia evidente:

Que posição poderia ocupar uma mulher capaz de aparecer naquela hora nos aposentos internos do palácio?

Antes que ele perguntasse, Gu Sijin disse: — Você não morreu naquela guerra de quatro anos atrás. Mas por quê...? Por que não entrou em contato comigo nenhuma vez durante esses quatro anos inteiros?

Chu Xingran explicou tudo, do começo ao fim. Mas aquela resposta evidentemente não satisfez Gu Sijin.

Sua expressão foi esfriando à medida que ele falava, até que ela soltou uma risada amarga. — Por mim? Quando foi que eu disse que precisava que você conquistasse fama e poder? Que precisava viver cercada de luxo ao seu lado?

Ela baixou os cílios, fria e desdenhosa. — Você sabe quem eu sou, não sabe? Sabe de que família venho. Sou filha legítima de um censor do Tribunal de Fiscalização. Se quisesse uma vida de luxo, bastaria entrar no palácio. Com minha origem e minha aparência, certamente despertaria o interesse do imperador.

Abriu os braços e olhou para as próprias roupas, com um ar de satisfação. — Pois é, como pode ver, já conquistei tudo o que queria.

Chu Xingran observou aquela mulher que de repente lhe parecia um pouco estranha. Não acreditou numa única palavra do que ela dizia.

Ele conhecia bem demais a mulher que ocupava seu coração inteiro.

Também sabia que, durante os quatro anos em que vivera escondido entre os piratas japoneses, nenhum dia nem noite fora fácil para Gu Sijin.

Talvez o sofrimento dela tivesse sido ainda maior que o seu.

Ele se aproximou para abraçá-la, mas dessa vez ela se esquivou.

Seus olhos estavam cheios de ternura e dor. — Sei que você não entrou no palácio porque queria. Mesmo que tivesse escolhido se tornar consorte por vontade própria, em busca de riqueza, eu não a culparia. Mas sei que você não é esse tipo de pessoa...

— Não sou esse tipo de pessoa? Ah... — Gu Sijin o interrompeu. — Então que tipo de pessoa você acha que eu sou? Acha que eu deveria ter guardado as tais virtudes femininas e esperado eternamente? Esperado que você, cujo paradeiro e cuja vida eram desconhecidos, voltasse para me procurar?

— Você vive dizendo que sou diferente das outras, que não ligo para riquezas. No entanto, foi embora justamente para conseguir títulos e prestígio e depois veio dizer que fez isso para me oferecer uma vida melhor. Não percebe a contradição?

Ela encarou Chu Xingran diretamente, articulando cada palavra com firmeza:

— Vou lhe dizer com toda a clareza: entrei no palácio por vontade própria. Sou igual a todas as mulheres que sonham em ascender na vida e se tornar uma fênix.

— Não gosto apenas de luxo e riqueza. Gosto também de ter poder nas mãos. O que eu quero, ninguém mais pode me oferecer. Nem você. Só o imperador!

— Sou uma mulher vaidosa e interesseira. Sempre fui uma mulher vaidosa e interesseira!

Assim que terminou, virou-se depressa, temendo que as lágrimas começassem a cair outra vez.

Na verdade, Gu Sijin havia entrado no palácio exclusivamente por causa de sua família.

O cargo de seu pai no Tribunal de Fiscalização parecia prestigioso, mas seu trabalho consistia em desagradar aos outros ministros.

O tribunal investigava e expunha funcionários corruptos da corte. Só que, por trás deles, havia redes de proteção e cumplicidade entre autoridades.

Ao desmascarar um, acabava-se atingindo os interesses de muitos. Mais cedo ou mais tarde, seu pai poderia se tornar alvo de perseguições e acusações fabricadas.

Para garantir a segurança dele pelo resto da vida, era necessário haver no harém alguém cuja voz alcançasse o imperador.

Gu Sijin decidira entrar no palácio porque, naquela época, acreditava de todo o coração que Chu Xingran já estava morto. Seu próprio coração parecera morrer com ele.

Se não podia passar a vida com o homem que amava, ao menos protegeria seus familiares.

Embora sempre desejasse que Chu Xingran estivesse vivo, no íntimo considerava esse desejo impossível.

Nunca imaginara que voltariam a se encontrar. Muito menos que o reencontro seria assim.

Quando Chu Xingran lhe explicara o motivo de seu desaparecimento, ela não sentira raiva dele, nem por um instante.

Os deveres para com o país vinham antes do romance. Além disso, ele procurara uma carreira melhor justamente para oferecer a ela uma vida tranquila. Como poderia culpá-lo?

A pessoa que ela culpava sempre fora ela mesma.

Conhecia Chu Xingran bem demais. Ele era um louco completo: se percebesse nela o menor traço de arrependimento por ter entrado no palácio, faria qualquer coisa para levá-la embora.

Mas ela não podia acompanhá-lo.

Embora nunca tivesse consumado uma relação conjugal com Lu Linyuan, desde que entrara no palácio ela pertencia oficialmente ao imperador.

Desejar a mulher do soberano era crime gravíssimo, punível com a execução de nove gerações de parentes.

Mesmo que Lu Linyuan, em nome da amizade de tantos anos com Chu Xingran, aceitasse unir os dois, os velhos ministros da corte levantariam tamanha condenação que suas palavras bastariam para afogar Chu Xingran.

Gu Sijin nunca esquecera seu desejo mais antigo: que Chu Xingran continuasse vivo, são e salvo.

O céu tivera piedade dela e realizara esse desejo. Não ousava exigir também uma vida inteira ao lado de quem amava.

Ninguém pode querer tudo ao mesmo tempo. A vida muda como a lua, que ora cresce, ora mingua. A imperfeição é parte da existência.

Só havia uma coisa que Gu Sijin não considerara: como Chu Xingran poderia deixar de acreditar na mulher que amara por tantos anos só porque ela dissera algumas palavras contrárias ao próprio coração?

Um calor a envolveu pelas costas. Chu Xingran a abraçou por trás e murmurou junto ao ouvido dela:

— Me perdoe. Fiz você sofrer.

— Achei que só conquistando cargos e honrarias poderia lhe dar a melhor vida. Minha presunção a fez sofrer por todos esses anos.

Ele a virou lentamente para ficar de frente e declarou, com absoluta firmeza:

— Amanhã vou procurar o imperador. Não quero mais o alto cargo de comandante dos Nove Portões. Vou pedir a ele que me entregue você!

— Jin'er, dessa vez não vou deixar você escapar de mim outra vez.

# Capítulo 186 — Gu Sijin vomita sangue e perde os sentidos

(Nota da autora: nem eu sei por que o capítulo anterior ficou travado. Já faz uma hora e meia que estou presa nisso. Leiam quando ele finalmente sair; já estou completamente sem forças.)

Por um instante, Gu Sijin desejou largar tudo e simplesmente partir com ele.

Que importava o que o palácio diria depois? Poderiam espalhar que ela virara uma borboleta e voara para longe, ou que se jogara no lago e desaparecera sem deixar corpo. Ela queria viver a vida que deveria ter sido sua.

Queria se livrar de todos os fardos que se obrigara a carregar e viver, uma única vez, verdadeiramente por si mesma.

Mas aquilo não passava de um desejo.

Ao ver Qiqi voltar ao longe carregando uma lanterna, Gu Sijin se desvencilhou dos braços de Chu Xingran, arrumou os cabelos despenteados e tentou parecer perfeitamente normal.

Quando Qiqi se aproximou, examinou Chu Xingran por um instante. Não o conhecia. Achou-o elegante e bonito demais para ser guarda ou eunuco dos aposentos internos, mas não lhe dirigiu a palavra. Apenas entregou a bolsa de água quente a Gu Sijin.

— Minha senhora, já está tarde. Não seria melhor voltarmos ao palácio?

Gu Sijin assentiu e, amparada por Qiqi, seguiu em direção ao Palácio Zhongcui.

Chu Xingran avançou a passos largos, agarrou o braço de Gu Sijin e não se dispôs a deixá-la partir assim.

— Venha comigo. Vou explicar tudo ao imperador agora mesmo.

— Me solte!

Gu Sijin tentou se libertar, enquanto Qiqi também empurrava Chu Xingran. — Quem é você? Solte minha senhora! Se continuar assim, vou chamar alguém!

Se Qiqi chamasse outras pessoas naquele momento, a situação seria ainda mais difícil de explicar.

Gu Sijin lhe lançou um olhar significativo e, em seguida, disse a Chu Xingran em voz baixa e firme: — Você está me machucando.

Ela sabia que bastava dizer aquilo para que Chu Xingran a soltasse.

Esfregou o pulso dolorido e o encarou com frieza. — Senhor Chu, comporte-se. Se não valoriza sua vida, eu ainda quero continuar vivendo.

— Se realmente se importa comigo, nunca mais volte a falar desse assunto. De agora em diante, vamos agir como se nunca tivéssemos nos conhecido.

Só colocando a própria segurança em jogo ela conseguiria fazê-lo recuperar a razão.

Dessa vez, ele não tentou impedi-la. Ficou parado, acompanhando-a com os olhos enquanto ela se afastava.

Depois de voltar da trilha para a avenida principal, Gu Sijin permaneceu em silêncio.

Qiqi só ousou perguntar quando chegaram a um lugar com menos gente: — Minha senhora, quem era aquele homem?

Gu Sijin respondeu sem emoção: — Só um louco desvairado. Não lhe dê importância. — Então advertiu: — Guarde segredo absoluto sobre o que aconteceu hoje. Se alguém mal-intencionado descobrir e usar isso contra mim, ficarei presa numa armadilha da qual não conseguirei me defender.

Qiqi nunca fora tagarela. Concordou e não fez outras perguntas.

Senhora e criada seguiram juntas pela noite. Gu Sijin sentia um frio extremo, embora a bolsa de água quente em seus braços estivesse fervendo. Para ela, parecia não ter calor algum.

Lágrimas escorriam sem controle, silenciosas, pelas faces pálidas. Estava tão entorpecida que nem notava que chorava.

Pensou que o homem por quem tanto ansiara estava vivo. Aquilo já era o maior presente que o céu poderia lhe dar.

Mas os presentes do destino sempre trazem consigo um preço, marcado de antemão em algum lugar invisível.

Talvez a vida de Chu Xingran tivesse sido comprada ao custo do irmão Chu e da Jin'er de antigamente.

As lembranças voltaram a inundá-la. As memórias felizes pareciam lâminas que lhe revolviam os órgãos, entrando e saindo ensanguentadas, como se quisessem despedaçá-la de dentro para fora.

Doía tanto que não havia uma única parte de seu corpo em paz.

Apoiando-a, Qiqi sentiu seu corpo tremer violentamente e se apressou a perguntar: — Minha senhora, o que houve? Está sentindo alguma coisa?

Gu Sijin quis responder, mas, ao abrir a boca, sentiu como se algo lhe obstruísse a garganta.

Um forte gosto metálico e adocicado subiu, fazendo-a se curvar junto ao muro, tomada por ânsias de vômito.

Ela vomitou um líquido espesso, vermelho-vivo, que cobriu uma pedra saliente na neve.

Sob o luar, aquele vermelho parecia especialmente intenso, como um rubi de sangue de pombo, numa visão aterradora.

Qiqi ficou apavorada. Enquanto limpava a boca de Gu Sijin com um lenço e lhe acariciava as costas, repetia: — Minha senhora! O que está acontecendo? Não me assuste assim...

O vento no corredor ficou mais forte e arrancou o último galho de folha seca que ainda pendia da magnólia acima delas.

A folha morta rodopiou e caiu diante de Gu Sijin. Ela deu um sorriso amargo e, em seguida, perdeu a consciência, tombando sobre a neve.

*

Palácio Zhongcui.

— Uau! Que cheiro maravilhoso!

Qiaqia não poupava elogios à sopa para aliviar a embriaguez que Ning Xiaoxiao preparara. — Quando o imperador chegar, nem vai precisar beber! Só de sentir o aroma, metade da bebedeira já vai embora!

A habilidade culinária sempre fora o ponto de maior insegurança de Ning Xiaoxiao. Como Qiaqia era a melhor cozinheira do Palácio Zhongcui, o elogio a deixou radiante. — Claro! Aprendi diretamente com minha mãe! Quer provar?

Serviu uma tigelinha e dividiu a sopa com Qiaqia.

Era doce sem enjoar, com uma leve acidez, e estava deliciosa.

Chamou Qiaqia para pegar um recipiente com tampa, despejou a sopa nele, guardou-o numa cesta de comida e se preparou para ir ao Palácio Chaoyang procurar Lu Linyuan.

Mal chegou à entrada, viu vários criados trazendo Gu Sijin nos braços. Qiqi vinha atrás, chorando sem parar.

Ao notar os vestígios de sangue nos cantos da boca de Gu Sijin, Ning Xiaoxiao correu até ela. — Irmã! Irmã, acorde!

Como Gu Sijin não reagia, voltou-se para Qiqi: — Pare de chorar um instante! O que aconteceu? Ela só foi ver os lótus brancos. Como acabou vomitando sangue?

— Buááá... Eu também não sei... — soluçou Qiqi. — Minha senhora começou a tremer sem parar no caminho de volta e, de repente, vomitou sangue...

Ning Xiaoxiao mandou chamar imediatamente um médico imperial. Após examiná-la, ele concluiu que a profunda angústia e a dor emocional haviam provocado uma perturbação intensa, fazendo-a vomitar sangue.

O médico aplicou acupuntura e receitou uma decocção para restaurar o sangue e a energia vital. Quando a paciente se estabilizou, explicou: — A condição da Nobre Dama Gu exige repouso absoluto. Nobre Dama Hua, seria melhor que saísse por enquanto.

Sem alternativa, Ning Xiaoxiao deixou o pavilhão lateral leste. Chamou Qiqi para perguntar o que acontecera, mas a criada se esquivava, sem querer contar.

Ning Xiaoxiao ficou contrariada. — Numa hora dessas você ainda esconde coisas de mim? Se não esclarecer o que aconteceu e isso atrasar o tratamento da minha irmã, o que faremos?

Depois de ponderar bastante, Qiqi enfim contou em voz baixa: — Não sei exatamente o que aconteceu. Saí por um tempo para trocar a bolsa de água quente. Quando voltei, minha senhora parecia estar discutindo com um homem à beira do lago imperial.

— Um homem? — Ning Xiaoxiao franziu a testa. — A essa hora, os portões do palácio já estão trancados. De onde apareceu um homem?

— Não sei, minha senhora. Só sei que... acho que ela o chamou de senhor Chu.

Senhor Chu?

Chu Xingran?

A respiração de Ning Xiaoxiao pareceu falhar por um instante.

Ela quase se esquecera da existência daquele segundo protagonista masculino do romance original. Se Gu Sijin o encontrara, não era difícil entender por que ficara naquele estado.

Enquanto seus pensamentos se embaralhavam, Xiao Yinzi chegou às pressas ao Palácio Zhongcui, em plena noite: — Nobre Dama Hua, Sua Majestade bebeu demais e não para de chamar por você. Meu mestre pediu que fosse até lá.

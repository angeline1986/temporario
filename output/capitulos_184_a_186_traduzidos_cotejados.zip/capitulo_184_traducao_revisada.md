# Capítulo 184 — O homem que ela ama voltou

Tong Guowei estava tão acostumado a agir com arrogância na corte que, exceto por Ren Duanli, que vivia lhe lançando olhares gelados, nenhum outro ministro ousava falar com ele daquele jeito.

A indignação o fez elevar ainda mais a voz: — Que insolência! Majestade, esse sujeito late e esbraveja diante do trono, insultando este seu súdito! Vossa Majestade não vai fazer nada?

Chu Xingran rebateu: — Eu o insulto simplesmente porque me falta educação. O imperador não tem nada a ver com isso.

Lu Linyuan não conseguiu conter o riso. Não tinha a menor intenção de interferir.

Tong Guowei não era páreo para Chu Xingran nem na luta, nem na troca de farpas. Sem conseguir levar vantagem e sentindo-se humilhado, disse contrariado a Lu Linyuan: — Não me sinto bem. Peço licença para me retirar.

Dito isso, nem terminou direito a reverência antes de sair bufando.

Assim que ele partiu, Lu Linyuan e Chu Xingran trocaram um olhar e desataram a rir em perfeita sintonia.

Lu Linyuan ergueu a taça, levantou-se e foi até ele. Deu-lhe um tapinha no ombro e brincou:

— Você não muda mesmo. Passaram-se tantos anos e continua com essa sua língua afiada.

Chu Xingran ergueu a própria taça e brindou com ele. Só depois de ambos esvaziarem os copos falou:

— Tong Guowei é arrogante e não respeita ninguém. Agora que os piratas japoneses foram derrotados, ele é a única grande ameaça que resta ao império. Se eu fosse ele, baixaria a bola e ficaria quietinho. Mas insiste em procurar a própria desgraça. Depois não pode culpar ninguém.

Lu Linyuan respondeu: — Hoje nós, irmãos, finalmente nos reencontramos. Não vamos falar de cães e porcos, para não atrair azar. Sanfu, vá chamar Ren Duanli. [Nota: o original explica que “zhi” significa porco.]

Chu Xingran não era um homem qualquer que Lu Linyuan escolhera ao acaso para se infiltrar entre os piratas. Assim como Ren Duanli, ele era um irmão de coração do imperador, uma das raras pessoas em quem Lu Linyuan verdadeiramente confiava.

Quando Lu Linyuan ainda era príncipe, Ren Duanli e Chu Xingran, da mesma faixa etária, eram seus companheiros de treinamento nas artes marciais.

Mas quanto tempo três meninos juntos realmente passavam treinando às escondidas?

Na maior parte do tempo, corriam até os campos de caça para pegar ovos nos ninhos, assar batatas e brincar até não poder mais.

Sob a tirania da imperatriz-viúva, praticamente todas as alegrias da infância de Lu Linyuan tinham vindo daqueles dois amigos.

— Quando subi ao trono, você e Duanli eram meus braços direito e esquerdo. Ambos são excelentes lutadores, mas ele é frio como gelo e pouco flexível. Você, por outro lado, sabe improvisar e pensar depressa. Na época, os piratas japoneses ameaçavam nossas fronteiras; como se encontravam em ilhas, uma campanha naval frontal seria desvantajosa para Qi. Não tive escolha a não ser lhe confiar aquela missão.

Havia uma ponta de culpa na voz de Lu Linyuan, mas Chu Xingran não dava importância a isso.

— Minha família caiu em desgraça no passado. Sem a ajuda de Vossa Majestade, nem sei como teria sobrevivido à miséria. Além disso, faço parte de Qi. É uma honra poder contribuir para a prosperidade e a paz do país.

A missão de espionagem era um dos segredos mais bem guardados do Estado.

Se a informação vazasse, o agente correria perigo extremo.

Por isso, antes do retorno de Chu Xingran, pouquíssimas pessoas conheciam a história inteira.

Em nome do país, Chu Xingran não havia contado nem mesmo a Gu Sijin.

E, durante as incontáveis noites e dias em que permaneceu infiltrado entre os piratas, foi a lembrança de uma pessoa querida que lhe permitiu suportar uma solidão capaz de engolir o mundo.

Felizmente, ele conseguira.

Lu Linyuan declarou: — Agora que voltou, não lhe negarei as honras e riquezas que prometi. Na audiência de amanhã, anunciarei oficialmente aos ministros que o posto de comandante dos Nove Portões, vago até hoje, sempre esteve reservado para você.

O posto de comandante dos Nove Portões tinha o grau de primeiro escalão adjunto. Quatro anos de juventude em troca de uma vida de riqueza e segurança para gerações: para qualquer um, seria uma felicidade extraordinária.

Chu Xingran dobrou os joelhos para agradecer, mas Lu Linyuan o amparou. — Hoje vamos beber à vontade. Neste banquete, não há soberano e súdito, apenas amigos íntimos. Dispensemos as formalidades.

Mais tarde, enquanto conversavam e bebiam, Lu Linyuan quis apresentar a Chu Xingran algumas jovens de famílias ilustres, para que escolhesse uma esposa.

Chu Xingran recusou sem a menor hesitação.

Ao pensar em uma pessoa que guardava no coração, sorriu. Até sua voz se tornou involuntariamente mais terna:

— Há uma moça que sempre ocupou meu coração. Sei que ela passou todo esse tempo esperando que eu voltasse para casa coberto de honras.

Lu Linyuan riu. — Então me meti onde não devia! Venha, vamos beber!

Ren Duanli acabou se juntando à bebedeira.

Os três amigos de infância se reuniram, conversaram sobre tudo, sem reservas, e deixaram de lado seus cargos. Era como se tivessem voltado a algum verão distante da juventude, quando descansavam à sombra de uma árvore e caçavam cigarras.

Depois de várias rodadas de bebida, todos estavam um pouco embriagados.

Ao ver o rosto de Chu Xingran corado pelo álcool, Lu Linyuan disse: — Você bebeu bastante. Passe a noite no palácio para não precisar sair nesse estado.

Chamou Sanfu e mandou que levasse Chu Xingran para se hospedar na ilha no meio do lago.

Ren Duanli perguntou, brincando: — E eu, Majestade? Já resolveu a hospedagem dele. E a minha?

— A sua? — Lu Linyuan o examinou com um sorriso. — Procure o príncipe Jing e resolva com ele onde vai comer e dormir. Não venha me perguntar.

Então trocou um olhar com Chu Xingran, e os dois caíram na gargalhada. Ren Duanli, com seu habitual rosto de gelo, exibiu uma rara expressão envergonhada.

*

Os lótus brancos cultivados pelo Departamento de Flores e Aves não pareciam tão bonitos quanto Gu Sijin imaginara. Ou talvez, desde que um pedaço de seu coração ficara vazio, todas as belezas do mundo tivessem perdido a cor para ela.

Parada à margem do lago imperial, sentiu que a bolsa de água quente que segurava nos braços estava esfriando. Pediu a Qiqi que fosse trocá-la por outra nas proximidades.

A lua estava especialmente bonita naquela noite. Ao contemplá-la no céu, Gu Sijin viu as cenas do passado ressurgirem uma a uma diante dos olhos.

Sem perceber, avançou um passo. A neve recente ainda não derretera à beira do lago imperial e, com o frio noturno, formara uma camada de gelo escorregadia.

Ela perdeu o equilíbrio e quase caiu no lago. Nesse instante, uma mão forte agarrou seu braço e a puxou de volta com um movimento brusco.

Levado pelo impulso, seu corpo foi parar nos braços de um desconhecido.

Sentiu o cheiro de álcool vindo dele. Naquela hora, pensou que o único homem autorizado a beber no interior do palácio fosse o imperador.

Instintivamente, acreditou que era Lu Linyuan. Temendo se envolver em alguma situação ambígua com ele e provocar um mal-entendido com Xiaoxiao, deu dois passos rápidos para trás.

Só depois de se afastar ousou erguer a cabeça, hesitante.

O homem diante dela vestia um manto azul-claro bordado com garças entre bambus, preso à cintura por uma faixa vermelha. Permanecia imóvel, um tanto rígido.

Seus olhos tinham um tom castanho-claro. Gu Sijin vira aqueles olhos incontáveis vezes em sonhos, sempre os procurando com saudade.

Agora, porém, um turbilhão de assombro e incredulidade agitava aquele olhar.

Gu Sijin apertou desajeitadamente o lenço nas mãos. Uma onda de calor transbordou em seu peito e golpeou repetidamente a montanha de gelo que se formara em seu coração, até derretê-la.

De tanta alegria, braços e pernas ficaram fracos, e lágrimas quentes se acumularam em seus olhos.

O homem à sua frente não estava diferente.

Como se estivessem em sintonia, ambos piscaram com força. Então, reunindo aparentemente toda a coragem que possuíam, pronunciaram ao mesmo tempo, em vozes baixíssimas, o nome um do outro:

— Irmão Chu...

— Jin'er?

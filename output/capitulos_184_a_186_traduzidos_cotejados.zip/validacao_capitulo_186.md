# Validação do capítulo 186

- Fonte primária: `novel_capitulos_181_a_211(20261105-152737).docx`, chinês tradicional.
- Limites de parágrafos DOCX (base zero): início 303, fim exclusivo 370.
- Unidades não vazias incluindo título e notas: **64**.
- Unidades no CSV: **64**.
- Duplicatas de índices: **0**. Índices ausentes: **0**. Campos vazios: **0**.
- Coerência: diferenciação de narração, falas, memória, intenções e fatos; preservação de títulos e notas originais.
- Verificação semântica: tradução elaborada a partir do original, com revisão contextual; **não foi feita segunda auditoria semântica independente integral**. A correspondência 1:1 é uma validação estrutural, não prova de fidelidade absoluta.

# Validação do capítulo 285

- **Original primário:** `novel_capitulos_271_a_300(20261106-202946).docx` (chinês tradicional).
- **Tradução-base:** `novel capitulos 271 a 300 - ch.epub`, capítulo 285.
- **Intervalo de parágrafos do DOCX:** 985–1053, índices base zero; 66 unidades não vazias, incluindo título.
- **Corpo do EPUB:** 65 parágrafos não vazios; os títulos estão em H1, separadamente.
- **Cotejo:** 66 correspondências 1:1 com os índices reais do DOCX, sem lacunas de unidade no mapeamento.

## Ajustes editoriais focalizados

Corrigidos a duplicação “édito imperial juntamente com o decreto”, a falsa tradução do feudo de Maodu, o cargo de Gu Yanchuan e, especialmente, a inversão no EPUB da escolha de Chu Xingran: ele priorizaria os deveres com o Estado em relação ao amor. Corrigida a ironia sobre Gu Sijin poder não aceitar o casamento.

## Limites importantes

O cotejo documenta a correspondência estrutural das unidades. O texto em português deriva da versão EPUB, com correções focalizadas verificadas contra o chinês. **Não houve uma auditoria semântica integral independente de todas as frases**, portanto não é possível garantir ausência total de outros erros, omissões dentro de parágrafos ou escolhas lexicais discutíveis. Os trechos de poesia/canção merecem atenção específica em qualquer nova rodada editorial.

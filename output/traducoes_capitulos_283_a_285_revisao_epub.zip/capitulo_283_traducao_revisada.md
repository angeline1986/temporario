# Capítulo 283 — Eu sou seu pai, capaz de mudar de mil maneiras

Os assassinos de elite dançavam com tanto entusiasmo e requebros tão sedutores que pareciam verdadeiras Barbies musculosas fazendo uma apresentação na internet.

Quando o acompanhamento chegou ao refrão, todos cantaram em uníssono. Acenando para Tong Guowei no estrado, entoaram com toda a força:

“Venha~ vamos nos divertir~ afinal, ainda temos~ tanto tempo pela frente~”

“Venha~ vamos aprontar~ afinal, ainda há~ tanta insensatez~”

Tong Guowei: “?????????”

Ele desejou poder arrancar os próprios olhos ali mesmo e jogá-los no galinheiro para alimentar as galinhas.

Antes mesmo que pudesse reagir, sentiu uma coceira repentina no pescoço.

Ele ficou surpreso ao descobrir que fora sua própria esposa quem desatara o cinto e o pendurara em seu pescoço.

A senhora Huo enroscou uma perna nele, esfregou-se de um lado para o outro e falou com voz dengosa:

— Ah~~~~Que coceira~~~~~~~

Vai se foder!

Tong Guowei estremeceu e, como que por reflexo, chutou a senhora Huo para longe.

Ao despencar do estrado, a senhora Huo não soltou o cinto preso ao pescoço de Tong Guowei e o levou junto em seu voo involuntário.

— Aaaaah!

'Bang!'

Os dois caíram no chão. Madame Huo não morreu com a queda, mas Tong Guowei, que caiu em cima dela, fez com que ela vomitasse o jantar da noite anterior e morresse instantaneamente.

Embora Tong Guowei tenha sobrevivido, ele quebrou a perna. O osso ficou exposto, uma visão horrível.

A apresentação de música e dança "sedutora" dos assassinos continuou, sem dar sinais de que iria parar.

O Guarda Tigre deu um tapinha no atônito Chu Xingran e perguntou timidamente: "Comandante, o que está acontecendo aqui?"

A expressão de Chu Xingran dizia: “Porra, não me pergunte! Eu também não faço ideia!”

— Que tal... você tentar cortá-lo e ver se ele reage?

— Seu subordinado obedece!

O soldado da Guarda Tigre, carregando sua faca, aproximou-se do assassino mais próximo e sussurrou: "Irmão, meu chefe me ordenou que o matasse."

O assassino tirou o dudou e o pendurou no rosto do guarda: “Venha~ vamos nos divertir~ afinal, há~ er...”

Com um único golpe de sabre, o guarda o mandou diretamente para o além.

— Comandante, parece que eles enlouqueceram...

Chu Xingran fez uma pausa por um momento e então disse, impotente: "Ah, então vamos acabar com todos eles."

Tong Guowei, com a perna quebrada, jazia no chão praguejando de dor: "Feitiçaria! Deve ser a feitiçaria maligna lançada por aquele imperador cão! Com um imperador demônio como esse no comando, o Grande Qi está condenado!"

Chu Xingran aproximou-se dele com uma expressão fria e pisou no osso quebrado da perna que estava exposto.

— Ah!!! Seu escravo canino! Ah!! Você se atreve a me matar?

Chu Xingran sorriu com ar insolente, a língua pressionada contra a parte interna do maxilar. Agachou-se devagar, apoiou uma mão no joelho e, com a outra, começou a dar tapinhas estalados no rosto de Tong Guowei:

Chu Xingran sorriu presunçosamente, com a língua pressionada contra o queixo, e lentamente se agachou, apoiando-se em um joelho com uma mão e desferindo repetidos tapas no rosto de Tong Guowei com um estalo alto.

— Eu não vou te matar. Estou planejando te levar à presença do imperador e te fazer dançar para o Imperador e a Consorte Nobre!

Em seguida, agarrou-o pelos cabelos e o arrancou à força do chão ensanguentado.

— Guardas, prendam o velho ladrão e levem-no ao palácio para ser julgado pessoalmente pelo Imperador.

— Todos os parentes, diretos e indiretos, da família Tong serão presos e levados à justiça. Quem resistir será morto na hora!

*

Essa farsa em Kyoto continuou até quase quatro da manhã.

Os moradores da vizinhança passaram a noite em claro, ocupados demais em acompanhar a fofoca diante da mansão Tong.

Quando Tong Guowei foi levado de volta ao palácio, faltava cerca de uma hora para a audiência matinal da corte.

Lu Linyuan instruiu Chu Xingran a levar Tong Guowei diretamente ao Palácio Dourado, onde ele o interrogaria pessoalmente na frente dos oficiais reunidos.

Logicamente falando, Tong Guowei já deveria estar no seu limite, mas ele não estava com medo nenhum.

Mesmo quando foi detido no Palácio Dourado e forçado a ajoelhar-se no chão, ele sempre manteve a cabeça erguida e o peito estufado, com os olhos e as sobrancelhas cheios de desdém.

Os ministros da corte o evitavam como se fosse uma praga, temendo ser atingidos por sua má sorte.

Ao entrar na corte, Lu Linyuan recebeu as saudações dos oficiais e, em seguida, sentou-se no trono do dragão, olhando para eles de sua posição elevada.

— Ministro Tong, sabe por que ordenei ao Governador Chu que o prendesse no meio da noite?

Tong Guowei respondeu friamente: “Ouvi dizer que a Concubina Tong cometeu um grave crime no palácio. Ela drogou Vossa Majestade às escondidas para seduzi-lo e ter relações com ele.”

— Drogar o Imperador é um crime capital, portanto, ao saber disso, resolvi imediatamente romper todos os laços com ela. Quanto a como Vossa Majestade deseja lidar com ela, se deseja matá-la ou torturá-la, isso depende inteiramente de Vossa Majestade; não há necessidade de me informar.

Nem mesmo os tigres comem seus filhotes, mas Tong Guowei ousou dizer tais coisas abertamente diante do imperador, causando alvoroço entre os funcionários da corte.

Sanfu disse em voz grave: "Silêncio", silenciando os murmúrios.

Na parte inferior do salão, Gu Yanchuan, censor do Censorado, entregou a Xiao Yinzi uma grossa pilha de documentos para que fossem levados a Lu Linyuan.

— Vossa Majestade, tenho algo a relatar.

— O general Tong Guowei de Zhenyuan é presunçoso e desrespeitoso, desafia o imperador, conspira com oficiais estrangeiros, usurpa o poder, desafia a autoridade do imperador, forma panelinhas secretas, manipula eleições oficiais, interfere nas nomeações de pessoal da corte, conspira com comerciantes de sal para vender sal contrabandeado e explora o povo da fronteira. Ele se estabeleceu como rei em Lingnan e Chongbei, arrogante e indisciplinado, e seu coração é digno de condenação!

— Os documentos apresentados a Vossa Majestade são provas dos vários crimes cometidos pela família Tong, que recolhi ao longo de três meses com todo o rigor da Censura. Cada prova é irrefutável.

— A família Tong cometeu nada menos que noventa e três crimes, dos quais Tong Guowei esteve envolvido em setenta e seis, e cada um deles é um crime grave punível com a pena de morte!

— De acordo com as leis da Dinastia Qi, essa pessoa é extremamente perversa e deve ser severamente punida!

Gu Yanchuan falou com um tom firme e ressonante, sem sequer olhar para Tong Guowei uma vez.

Ele mal havia terminado de falar quando Tong Guowei repentinamente cuspiu nele:

— Bah! Seu velho tolo! Eu sou o general fundador da Dinastia Qi e fiz inúmeras contribuições para a Dinastia Qi com conquistas militares extraordinárias!

Ao dizer isso, voltou os olhos para Lu Linyuan, com uma ameaça evidente no tom de voz:

— Será que Vossa Majestade ouviu as calúnias desse velho patife? Vossa Majestade não deve esquecer que tenho uma profunda amizade com o general da fronteira. Se Vossa Majestade me detiver sem motivo, não posso garantir o que poderão fazer!

Nesse momento, Tong Guowei ainda desconhecia completamente a situação.

Ele pensava que os funcionários da corte e os generais que haviam formado uma aliança com ele se juntariam ao seu lado.

Ele tinha certeza de que Lu Linyuan não lhe faria nada, então tornou-se ainda mais indisciplinado na frente do imperador.

Enquanto ele gritava, Lu Linyuan de repente pegou a pedra de tinta que estava sobre a mesa do dragão e a esmagou contra sua boca que tagarelava incessantemente.

'Bang!'

Com um estalo seco, Tong Guowei gritou e cuspiu um bocado de sangue e tinta quando uma fileira de seus dentes foi arrancada.

Lu Linyuan levou levemente o dedo indicador aos lábios, fazendo um gesto para que ele ficasse em silêncio:

— Psiu. Não faça escândalo.

Após terminar de falar e bater palmas três vezes, os dezesseis oficiais de alta patente e generais de fronteira que haviam sido recrutados por Tong Guowei apareceram e ficaram de cada lado dele.

Lu Linyuan levantou a mão para dar o sinal, e os dezesseis homens se moveram em uníssono, dando um bom 'tui' no rosto ensanguentado de Tong Guowei.

Tong Guowei olhou incrédulo, completamente chocado: "Você... você voltou atrás na sua palavra! Você é tão inconstante! Você... ah!"

Antes que ele pudesse terminar de falar, cada um dos dezesseis homens deu um passo à frente e enfiou um grande pano nas calças, dizendo em uníssono:

— Eu sou seu pai, e estou em constante mudança!

# Validação do capítulo 284

- **Original primário:** `novel_capitulos_271_a_300(20261106-202946).docx` (chinês tradicional).
- **Tradução-base:** `novel capitulos 271 a 300 - ch.epub`, capítulo 284.
- **Intervalo de parágrafos do DOCX:** 905–984, índices base zero; 77 unidades não vazias, incluindo título.
- **Corpo do EPUB:** 76 parágrafos não vazios; os títulos estão em H1, separadamente.
- **Cotejo:** 77 correspondências 1:1 com os índices reais do DOCX, sem lacunas de unidade no mapeamento.

## Ajustes editoriais focalizados

Restaurada a comparação cômica explícita com as férias escolares, omitida no EPUB. Revisados o título de extermínio das nove relações familiares e a lógica jurídica da incriminação de Tong Guowei.

## Limites importantes

O cotejo documenta a correspondência estrutural das unidades. O texto em português deriva da versão EPUB, com correções focalizadas verificadas contra o chinês. **Não houve uma auditoria semântica integral independente de todas as frases**, portanto não é possível garantir ausência total de outros erros, omissões dentro de parágrafos ou escolhas lexicais discutíveis. Os trechos de poesia/canção merecem atenção específica em qualquer nova rodada editorial.

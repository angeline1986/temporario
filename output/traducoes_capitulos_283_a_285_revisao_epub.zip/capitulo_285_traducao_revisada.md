# Capítulo 285 — Um presente de patos-mandarins (Estrelas e Brocado)

Os dezesseis foram de fato enganados por Lu Linyuan.

Afinal, quando Chu Xingran os procurou, levou consigo até mesmo um decreto imperial.

Eles jamais imaginaram que, depois de emitir um decreto, Lu Linyuan fosse brincar com as palavras num momento tão crucial.

Vendo a hesitação deles, Tong Guowei pensou que sua chance havia chegado e rapidamente os incentivou: "General Chen! Você é habilidoso, e já que vai morrer de qualquer maneira, por que não lutar comigo hoje para escapar? Eu prometo, se eu conseguir... ah ah!"

'Bang!'

Antes que ele pudesse terminar de falar, o General Chen lhe deu um soco no rosto. O punho, do tamanho de um saco de areia, estava cheio de força e quebrou o nariz de Tong Guowei com um só golpe.

Eles não eram estúpidos. Se Lu Linyuan foi capaz de armar uma armadilha dessas, certamente já havia arqueiros guardando o Palácio de Chaoyang há muito tempo. Se ousassem sair correndo, provavelmente seriam mortos por uma chuva de flechas.

A única opção agora é seguir as ordens de Lu Linyuan: dezesseis homens devem espancar Tong Guowei e ver quem acerta o último soco antes que ele morra.

Alguns eram generais, enquanto outros eram funcionários comuns do palácio.

O mais velho entre eles tinha mais de sessenta anos e mal conseguia andar com firmeza, mas mesmo assim conseguiu dar dois socos na cara de Tong Guowei.

A multidão avançou em massa, e Tong Guowei não tinha a menor chance contra tanta gente que o espancava.

Em pouco tempo, um grito estrondoso ecoou da multidão, vindo do Senhor Ele: "Fui eu! Eu o matei! Vossa Majestade, o senhor viu! Este humilde súdito desferiu o golpe final e expirou!"

Assim que terminou de falar, Tong Guowei se contraiu mais duas vezes. Vendo isso, o General Chen, rápida e decisivamente, sentou-se sobre o rosto dele.

Boom shakalaka!

GG.

Lu Linyuan bateu palmas calmamente e elogiou Chen generosamente: "O general Chen é realmente corajoso."

Antes que os quinze restantes pudessem sequer refutar suas palavras, Ren Duanli desembainhou sua espada e cortou-lhes a garganta num instante, deixando o General Chen sozinho, tremendo em meio ao sangue.

Em consideração à deserção dessas pessoas, Lu Linyuan apenas lhes tirou a vida, mas perdoou suas famílias e proibiu seus parentes, por três gerações, de servirem como funcionários na corte.

Quanto ao General Chen, ele de fato cumpriu sua promessa:

— Minha palavra será cumprida. Concederei Maodu como seu feudo. Quanto ao comando militar em suas mãos, eu o retomarei. Afinal, daqui em diante você será o senhor de Maodu. Para que precisaria de tropas?

Ao ouvirem isso, alguns cortesãos que assistiam ao espetáculo não conseguiram conter o riso.

Que lugar era esse tal de Maodu?

Na remota região fronteiriça da Dinastia Qi, toda a cidade tinha uma população de menos de 800 habitantes, mas criava dezenas de milhares de porcos, tornando-se uma importante fornecedora de carne suína para a Dinastia Qi.

O que mais o General Chen poderia fazer além de criar porcos naquele lugar?

Ao se deparar com seu olhar surpreso, Lu Linyuan pegou um livro da mesa em forma de dragão e o atirou para ele.

O General Chen pegou o livro e viu que a capa dizia claramente:

“Cuidados pós-parto com porcas”. Eram essas as palavras estampadas em letras enormes.

Vendo que ele estava ali imóvel, Sanfu retrucou: "General Chen, o Imperador concedeu-lhe pessoalmente este feudo. Esta é uma honra sem precedentes desde a fundação da Dinastia Qi. Por que não se ajoelha e expressa sua gratidão?"

Em resposta, o General Chen ajoelhou-se, rangendo os dentes enquanto dizia:

— Vossa Majestade, sou profundamente grato por sua grande gentileza! Certamente farei o meu melhor para cuidar dos porcos, auxiliar as porcas no parto e limpar os leitões. Não falharei com a confiança de Vossa Majestade!

*

Com isso, a dinastia anterior foi pacificada.

Toda ação tem tanto punição quanto recompensa.

A eliminação bem-sucedida de Tong Guowei foi inseparável da forte aliança de várias partes, voluntária ou involuntariamente.

Lu Linyuan recompensou o pai da Imperatriz, Zhu Zhenshan, o Grande Ministro da Guarda Imperial, e a família Guo, a família materna da Imperatriz Viúva.

No entanto, eles foram recompensados apenas com ouro e prata, mas não receberam nenhuma promoção ou título oficial.

Pelo contrário, Gu Yanchuan, o Censor do Censorado, Chu Xingran, o Comandante dos Nove Portões, e Ren Duanli, o Comandante dos Dois Exércitos, foram todos promovidos.

Gu Yanchuan conservaria seu cargo de censor e acumularia funções no Tribunal de Assuntos dos Povos Fronteiriços. Passaria do segundo escalão da primeira categoria ao primeiro escalão, enquanto sua esposa legítima receberia o título honorífico de dama de primeira categoria.

Ren Duanli e Chu Xingran receberam títulos e o mesmo tratamento que o Príncipe Jing.

Durante a entrega das recompensas, ficou evidente que Zhu Zhenshan e a família Guo, a família materna da Imperatriz Viúva, não pareciam muito satisfeitos.

Lu Linyuan, no entanto, ignorou-os completamente, optando por desconsiderá-los sem oferecer uma única palavra de consolo.

Após o término da sessão do tribunal naquele dia, Lu Linyuan manteve Chu Xingran no escritório para conversar com ele.

Ele dispensou os que estavam ao seu redor, deu um tapinha no ombro de Chu Xingran e disse: "Você merece todo o crédito por ter eliminado Tong Guowei com sucesso desta vez."

— Nem mesmo o teu humilde servo ousaria!

— Aqui não há forasteiros, portanto você e eu não precisamos observar as formalidades entre governante e súdito.

Ele instruiu Chu Xingran a sentar-se, onde vinhos finos de safras antigas estavam dispostos à sua frente.

Os dois irmãos beberam e conversaram alegremente como faziam na infância, desconsiderando a distinção entre governante e súdito, e demonstrando apenas seu afeto fraternal.

Lu Linyuan perguntou: "Diga-me, quando você e a filha da família Gu se apaixonaram?"

Chu Xingran bebeu uma xícara inteira e relatou a Lu Linyuan todo o seu passado com Gu Sijin, do começo ao fim.

Ao ouvir isso, Lu Linyuan pegou um amendoim com seus hashis e atirou nele, dizendo: "Seu pirralho, se você tivesse me explicado isso antes, eu não teria te mandado lutar contra os piratas japoneses."

— Vossa Majestade me conhece. Entre os assuntos do Estado e o amor, eu escolheria o primeiro sem hesitar. Quanto ao que devo a Jin’er, só poderei compensá-la com o resto da minha vida.

— Se você... tivesse me contado, eu poderia ter cuidado secretamente da sua amante, e não teria sido tão absurdo deixá-la entrar no palácio e se tornar minha concubina.

Chu Xingran sorriu. Ele não se importava nem um pouco com esse assunto. Não culpava Lu Linyuan nem Gu Sijin. A culpa era apenas sua.

Ele disse: "Jin'er pensou que eu havia morrido no campo de batalha e escolheu entrar no palácio para cumprir os desejos de sua família. Não a culpo por isso. Se eu retornar à corte com sucesso e descobrir que ela se apaixonou pelo Imperador, a deixarei em paz imediatamente e não a importunarei mais."

— Gostar de alguém nunca tem a ver com posse, mas sim com desejar-lhe tudo de bom, paz e felicidade.

Os dois eram de fato amigos de infância com interesses semelhantes, e compartilhavam muitas das mesmas opiniões sobre assuntos do coração.

E Ren Duanli, naturalmente, pensava da mesma forma.

Lu Linyuan: "Tratarei do seu assunto com Gu Sijin o mais breve possível. No entanto, entregá-la diretamente a você seria prejudicial à reputação da família Gu e à sua posição na corte. Portanto, decidi que ela fingirá a própria morte e deixará o palácio."

— Mas isso pode ser injusto para ela. No futuro, enquanto você estiver em Kyoto, ela só poderá viver uma vida reclusa como esposa e mãe.

— Gu Yanchuan ama sua filha. Ele sabe disso e certamente realizará seu desejo. A família materna dela mora em Kyoto, e ela poderá ver seus pais com frequência. É uma bênção disfarçada.

Ao ouvir isso, Chu Xingran ficou radiante, levantou-se e curvou-se para se ajoelhar diante de Lu Linyuan, expressando sua profunda gratidão.

Lu Linyuan rapidamente o ajudou a se levantar e provocou: "Dizem que os joelhos de um homem valem ouro, mas você gastou todo esse ouro com sua esposa. Não tem vergonha?"

— E não fique muito convencido.

Ele deu um soco amistoso no ombro de Chu Xingran e abriu ainda mais o sorriso: — Você quer se casar com ela, mas quem disse que ela necessariamente quer se casar com você? Pedi a Xiaoxiao que conversasse com ela. Se não aceitar, você terá de passar o resto da vida sozinho~

Eles se entreolharam e caíram na gargalhada.

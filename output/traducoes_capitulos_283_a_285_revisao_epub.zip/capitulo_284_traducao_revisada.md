# Capítulo 284 — O clã Tong — extermínio das nove gerações familiares

A expressão de Tong Guowei era como a de alguém que chega ao fim das férias sem ter feito a lição: queria chorar, mas não saía uma lágrima.

Ele não conseguia entender de jeito nenhum. Ele vinha tramando para tomar o trono desde que Lu Linyuan ascendeu ao poder. Cada passo de seu plano havia sido meticulosamente calculado. Ele havia considerado a possibilidade de fracasso, mas jamais imaginou que perderia de forma tão completa.

Neste momento, as palavras ameaçadoras de Tong Guowei a Lu Linyuan na frente do imperador já confirmaram sua culpa.

Assim, nem sequer seria necessário verificar as provas apresentadas por Gu Yanchuan: já não havia saída para ele.

Seu olhar estava vago, ele balançou a cabeça atordoado e murmurou para si mesmo:

— Impossível... Como isso pôde acontecer!?

— Planejei e executei cada passo meticulosamente com o máximo cuidado! Como eu poderia perder para você!?

Ao ouvir isso, Lu Linyuan zombou: "Você tramou e conspirou? Planejou cada passo do caminho? Oh, você é mesmo uma figura!"

Ele lançou um olhar desdenhoso para Tong Guowei e disse: "Acho que você é um completo idiota!"

Tong Guo Wei: “???”

Os ministros da corte: "!!!"

Todos baixaram a cabeça, resmungando secretamente entre si:

Por que isso me soa tão familiar?

Não é esse o tom da Consorte Nobre?

Hum... A última vez que ouvi a expressão "grande idiota" foi quando a concubina imperial e o imperador estavam flertando.

O quê? Isso não é, na verdade, um termo carinhoso usado pela concubina imperial para se referir ao imperador?

￣□￣｜｜

Tendo as coisas chegado a esse ponto, Tong Guowei não tinha como se defender.

Lu Linyuan, com as mangas esvoaçando ao vento, transmitiu solenemente o decreto imperial:

— Por decreto imperial, Tong Guowei conspirou com funcionários estrangeiros, tomou o poder, desafiou a autoridade do imperador e formou uma facção. Seus crimes são numerosos demais para serem listados.

— A família Tong, em vez de oferecer conselhos, tornou-se cúmplice dos perversos, valendo-se de seu poder para cometer atos malignos em vários ramos há muitos anos. Suas ações são ultrajantes e seus crimes são imperdoáveis!

— Por decreto imperial, Tong Guowei e todo o seu clã devem ser presos e levados à justiça imediatamente. Homens, mulheres e crianças serão executados!

“Os bebês recebem um perdão especial e são confiados aos homens armados para serem criados e crescidos, para serem escravos por gerações.”

Após a publicação do édito imperial, todos os funcionários da corte se curvaram e disseram em uníssono:

— Vossa Majestade é sábia!

— Hahahaha! Bah!

Tong Guowei estava agindo de forma errática, com o rosto coberto de sangue, mas ria como se seus pais tivessem saído do chão na noite anterior e lhe preparado um prato de frango cozido com arroz.

Ele apontou para Lu Linyuan e cuspiu um bocado de catarro com sangue, gritando a plenos pulmões:

— Imperador Demônio! Seu imperador demônio!

— Você sabe perfeitamente bem quais métodos usou para me capturar e por que meus assassinos de repente ficaram possuídos e começaram a dançar em Kyoto!

— Você deve ter usado alguma magia negra e traiçoeira para enfeitiçar as pessoas. Governar o país com essa lei é um desastre para o mundo!

Suportando a dor da perna quebrada, ele cambaleou até se levantar e encarou os cortesãos que o consideravam louco, com os olhos vermelhos de raiva:

— Todos vocês veem isso claramente! Esse imperador-cão no trono do dragão é um monstro completo!

— Esta noite, muitas pessoas na capital testemunharam como você usou sua feitiçaria! Com um imperador demônio como você, a Dinastia Qi está fadada a perecer mais cedo ou mais tarde!

Na noite passada, muitas pessoas testemunharam os assassinos realizando uma dança frenética em frente à residência dos Tong durante o cerco.

Os rumores que circulavam entre os funcionários da corte já haviam sido ouvidos antes de eles entrarem no palácio hoje.

Outros podem não saber porquê, mas Lu Linyuan entende perfeitamente bem.

Ele sabia que esses truques definitivamente haviam sido orquestrados por Xiaoxiao para ajudá-lo.

Ele também era bastante apaixonado por essa pessoa, e agora, quando pensa nela, não consegue esconder o sorriso no rosto.

Ele esboçou um leve sorriso, o olhar fixo em Tong Guowei, as sobrancelhas ligeiramente arqueadas:

— Ouvi falar dos seus casos. É realmente surpreendente que você tenha um gosto tão refinado a ponto de assistir homens musculosos vestidos com trajes de Dudu realizando danças eróticas.

— No entanto, desde que ascendi ao trono, sempre defendi a tolerância e a aceitação. Não há vergonha nenhuma em você ter um hobby tão especial. Eu te entendo perfeitamente.

Seus dedos, finos como jade, batiam levemente na mesa em forma de dragão, produzindo um som de "tap-tap".

Ela baixou os olhos como se fosse refletir por um instante, e então continuou:

— Eu não só te entendo, como também realizarei o seu desejo.

— Para garantir sua jornada pacífica, deixarei você com um cadáver completo e o enterrarei junto com seus ferozes guerreiros.

— É claro que você estará lá embaixo, e eles estarão pressionando você. Dessa forma, você se sentirá aquecido e não estará sozinho em sua jornada para o submundo.

A boca de Lu Linyuan, assim como a de sua esposa, aprendeu sete décimos da essência de Ning Xiaoxiao.

Ele deixou Tong Guowei sem palavras, fazendo-o parecer um psicopata.

Até mesmo os dezesseis oficiais de alta patente e generais que outrora serviram ao seu lado riam dele secretamente, bem de perto.

Tong Guowei avançou e começou a empurrá-los, mas foi derrubado no chão por alguém.

Ele estava extremamente agitado, cuspindo enquanto falava:

— Seus covardes! Pensem em tudo o que me tiraram e em quantas coisas inescrupulosas fizeram pelas minhas costas! Agora que o prédio está desmoronando e os macacos se espalharam com a queda da árvore, fui humilhado e ridicularizado por vocês, covardes!

— Vocês realmente acham que esse imperador canino vai deixar vocês escaparem impunes?! Bah! Sonhem! Assim que ele se livrar de mim, a primeira coisa que ele fará será lidar com vocês, bando de idiotas que trocaram de cabeça e de traseiro!

"Ei, não diga isso", brincou Lu Linyuan. "Quem te disse que eu lidaria com eles depois de te eliminar?"

Ao ouvirem isso, os dezesseis homens suspiraram de alívio e começaram a conversar entre si:

— Exatamente! Como o Imperador pôde voltar atrás na sua palavra?

— Seu velho ladrão, você ainda se atreve a fazer acusações infundadas mesmo em seu leito de morte? Você merece acabar assim!

Lu Linyuan bateu palmas três vezes para interromper a conversa, com um sorriso malicioso nos lábios.

Ele acariciou suavemente o anel de jade negro no polegar e disse casualmente:

— Decidi eliminá-los juntamente com você.

— ???

Lu Linyuan ignorou as expressões de choque das dezesseis pessoas, apenas erguendo as sobrancelhas e piscando para Ren Duanli, que guardava a entrada do salão principal.

Ren Duanli compreendeu imediatamente e, num instante, dezenas de guardas imperiais, trajando armaduras e portando espadas, entraram e cercaram os dezesseis homens e Tong Guowei.

— Majestade! Como pode quebrar sua promessa dessa maneira?

— Quando é que eu quebrei a minha palavra? Eu disse que se vocês estivessem dispostos a abandonar as trevas e abraçar a luz, eu lhes concederia a vida e a terra. Mas tudo isso vem com condições.

— ??? Por que o Imperador não disse isso na época?

Lu Linyuan deu de ombros e disse: "Você também não perguntou?"

┓( ´∀` )┏

— ...Então, posso perguntar a Vossa Majestade, quais são exatamente essas tais condições?

Lu Linyuan declarou firmemente: "É simples. Quem conseguir tirar a vida de Tong Guowei hoje, viverá, e eu lhe concederei o feudo e as recompensas que prometi. Quanto aos outros quinze..."

— Então eles o seguiram e partiram juntos!

— Majestade! Como pôde fazer isso? Quebrou claramente a sua promessa!

— Sou um homem de palavra. Que tipo de confiança posso ter com você? Por que está me encarando assim? Você não está gostando?

Ao ver os traidores pulando de raiva, Lu Linyuan não pôde deixar de esboçar um sorriso de escárnio:

— Se você não está feliz, guarde isso para si mesmo!

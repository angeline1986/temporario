# Validação do capítulo 283

- **Original primário:** `novel_capitulos_271_a_300(20261106-202946).docx` (chinês tradicional).
- **Tradução-base:** `novel capitulos 271 a 300 - ch.epub`, capítulo 283.
- **Intervalo de parágrafos do DOCX:** 827–904, índices base zero; 75 unidades não vazias, incluindo título.
- **Corpo do EPUB:** 74 parágrafos não vazios; os títulos estão em H1, separadamente.
- **Cotejo:** 75 correspondências 1:1 com os índices reais do DOCX, sem lacunas de unidade no mapeamento.

## Ajustes editoriais focalizados

Corrigidos o falso equivalente “dudu” para dudou, o título hierárquico Concubina Tong, o cálculo temporal de 半個時辰 (cerca de uma hora), a expressão chinesa 吃瓜 (acompanhar fofoca), o tratamento de Chu Xingran e imagens cômicas. O original inclui referências a letras de canção, adaptadas de forma contextual.

## Limites importantes

O cotejo documenta a correspondência estrutural das unidades. O texto em português deriva da versão EPUB, com correções focalizadas verificadas contra o chinês. **Não houve uma auditoria semântica integral independente de todas as frases**, portanto não é possível garantir ausência total de outros erros, omissões dentro de parágrafos ou escolhas lexicais discutíveis. Os trechos de poesia/canção merecem atenção específica em qualquer nova rodada editorial.

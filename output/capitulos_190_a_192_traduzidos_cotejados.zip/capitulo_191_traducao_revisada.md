# Capítulo 191 — Felizmente, ela ainda tinha Xiaoxiao

Assim que Lu Linyuan pronunciou aquelas palavras, a atmosfera do salão pareceu congelar.

Qualquer um entenderia sua intenção: se ele estava concedendo o Palácio Fengyi a Ning Xiaoxiao, era apenas questão de tempo até promovê-la a Consorte Imperial Nobre.

Mas, pelo menos por enquanto, isso ainda não era possível.

Além de cuidar da rotina de Lu Linyuan e supervisionar as tarefas do Departamento de Assuntos Internos, o eunuco-chefe pessoal do imperador também exercia parte das funções de um conselheiro da corte.

Precisava advertir o soberano quando necessário, para impedir que decisões impulsivas atraíssem críticas.

Percebendo pelo tom de Lu Linyuan que ele pretendia promover Ning Xiaoxiao novamente, Sanfu se arriscou a receber uma bofetada e aconselhou: — Majestade, a senhora Ning ainda é apenas uma Nobre Dama. Uma Nobre Dama não pode ser a senhora principal de um palácio. Além disso, na última promoção, ela passou diretamente de Dama para Nobre Dama, ultrapassando os postos intermediários. Isso já provocou muitas críticas dos censores na corte. Se agora...

Antes que terminasse, sentiu a temperatura ao redor despencar.

Lu Linyuan lançou-lhe um olhar tão cortante e opressivo que Sanfu sentiu as palavras entalarem na garganta e não ousou prosseguir.

Como Lu Linyuan poderia não compreender esses argumentos?

Na corte, Tong Guowei tinha cada vez mais aliados. No harém, as famílias de origem da imperatriz e da imperatriz-viúva conspiravam entre si.

A dinastia Qi parecia tranquila à superfície, mas sob a água corriam correntes violentíssimas. Quem fosse arrastado para aquele redemoinho poderia acabar despedaçado.

Se dependesse apenas de sua vontade, ele coroaria Ning Xiaoxiao imperatriz imediatamente. Ela seria sua esposa legítima, com o direito de permanecer ao seu lado diante de todos.

Mas ele era o imperador. Sobre seus ombros repousava o bem-estar de dezenas de milhões de súditos.

Havia muitas coisas que não podia fazer apenas por desejar fazê-las. Insistir nelas poderia prejudicar justamente as pessoas que queria proteger.

A Concubina Tong só tinha recuperado sua posição e sido promovida a consorte graças à influência de Tong Guowei, depois de um longo período de confinamento.

Se naquele momento Lu Linyuan elevasse novamente Ning Xiaoxiao, diretamente a consorte ou Consorte Nobre, causaria a ela muito mais mal do que bem.

No harém, ela se tornaria o alvo de todas. Na corte, a família Zhu, da imperatriz, e a família Tong se agarrariam à questão e não a soltariam.

Ele precisava esperar. Esperar a oportunidade certa, quando as peças que movera no tabuleiro fossem capazes de conter todos os seus inimigos. Só então teria poder suficiente para proteger, por toda a vida, a mulher que amava.

Na verdade, qualquer título não passava de uma formalidade.

O importante era que, em seu coração, ele sabia perfeitamente quem era a esposa com quem desejava compartilhar a vida inteira, os dois dedicados exclusivamente um ao outro.

Após um longo silêncio, ordenou: — Mais tarde, leve um decreto ao Palácio Fengluan e anuncie aos seis palácios: na noite passada, embriagado, recebi os cuidados atenciosos da Nobre Dama Hua e fiquei muito satisfeito. Por isso, ela será promovida imediatamente a Concubina Hua e receberá o Palácio Fengyi como residência.

Sanfu compreendeu que aquele era o posto mais alto que Lu Linyuan podia lhe dar naquele momento.

A concessão do Palácio Fengyi ainda provocaria um alvoroço na corte e no harém, mas ele não podia continuar argumentando.

Afinal, insistir mais seria falta de educação... e talvez de instinto de sobrevivência.

*

Palácio Zhongcui.

Depois de uma noite de repouso, o estado de Gu Sijin havia melhorado um pouco.

Sabendo que ela certamente não queria muita gente por perto, Ning Xiaoxiao pegou das mãos de Qiqi a bandeja com o remédio e entrou sozinha.

Gu Sijin estava meio sentada na cama, apoiada na cabeceira. Assim que viu Ning, perguntou com urgência: — O que aconteceu lá fora? Ouvi uma confusão enorme!

Ning sentou-se à beira da cama, soprou uma colherada do remédio quente e a aproximou dos lábios dela. — Não se preocupe, irmã. Só pisei na pata de uma cachorra, e ela começou a latir.

Gu Sijin não era tola. Imaginou que Ning havia entrado em conflito novamente com a Consorte Duan e a aconselhou: — Ela ainda é a senhora principal do Palácio Zhongcui e ocupa um posto muito acima dos nossos. Não convém irritá-la demais. Se disser alguma coisa que a enfureça, não leve a sério. Finja que é só um peido.

— Pfff!

Ouvir a palavra “peido” saindo da boca de Gu Sijin, uma dama culta e delicada, tornava tudo duas vezes mais engraçado.

Era verdade: quando se convive muito tempo com alguém, acabamos assimilando alguns de seus hábitos.

A Gu Sijin desinibida de agora era bem mais divertida do que a de antes.

Mas Ning Xiaoxiao sabia que aquilo era apenas uma tentativa de encontrar algum humor no sofrimento, para não preocupá-la.

Depois que Gu Sijin terminou o remédio, Ning sacudiu a manga diante dela. — Irmã, quer ver um truque de mágica?

Gu Sijin assentiu em silêncio, os olhos enevoados acompanhando as mãos que se moviam diante de seu rosto.

Ning começou a murmurar palavras misteriosas, toda solene, parecendo uma feiticeira de feira. Gu Sijin não conseguiu conter um novo sorriso.

Então Ning levou a mão direita até a orelha de Gu Sijin, fechou os dedos com ar misterioso e trouxe lentamente o punho diante dela. — Assopre aqui, irmã!

Gu Sijin soprou de leve. Ning abriu a palma da mão devagar, revelando um caramelo de leite com sabor de morango da marca Alpenliebe, ainda dentro da embalagem.

Gu Sijin nunca tinha visto plástico. Curiosa, pegou o doce para examiná-lo. — O que é isso? É colorido e liso. Parece papel, mas ao mesmo tempo não parece.

— Uma delícia! — Ning abriu a embalagem e deixou o caramelo cair na palma de Gu Sijin. — Experimente!

Desconfiada, Gu Sijin colocou o doce na boca. Assim que sua língua tocou a superfície açucarada, uma combinação intensa de leite e morango se espalhou por seu paladar.

Seus olhos brilharam. — É doce! Mas diferente das frutas cristalizadas e do açúcar comum. A textura é muito melhor!

Ning sorriu. — Aquele remédio já parece amargo só pelo cheiro. Com um docinho para tirar o gosto, fica mais fácil suportar.

A boca de Gu Sijin estava cheia de doçura, e seu coração também se aqueceu.

Ela acabara de atravessar uma dor imensa. Felizmente, ainda tinha Xiaoxiao.

Encontrar alguém que a tratasse com tanta sinceridade naquele palácio profundo era, afinal, uma bênção.

Talvez nunca pudesse retomar seu romance com Chu Xingran, mas, com Xiaoxiao ao lado, até os dias mais amargos pareciam um pouco mais suportáveis.

Gu Sijin sempre fora muito sensível. Bastava pensar em algo comovente para que as lágrimas viessem com facilidade.

Ao vê-la com os olhos vermelhos, Ning achou que estivesse novamente pensando em Chu Xingran e tentou consolá-la:

— Se gostou desse doce, irmã, posso separar mais alguns para você.

Depois de pensar um instante, acrescentou:

— Quando a boca fica doce, o coração parece um pouco menos amargo.

Ning Xiaoxiao achou que aquela frase melodramática, digna de uma postagem sentimental na internet, agradaria em cheio a Gu Sijin.

Gu Sijin jamais lhe contaria o que havia acontecido entre ela e Chu Xingran. Precisava levar aquele segredo para o túmulo, a fim de proteger o amado e sua família.

Decidiu parar de pensar no assunto. Segurou a mão de Ning e anunciou que se levantaria para apresentar seus cumprimentos à imperatriz.

Ning a impediu. — Você acabou de melhorar, irmã. Precisa descansar. Vou mandar Qiqi avisar à imperatriz que não poderá comparecer.

Gu Sijin balançou a cabeça. — Esqueceu que dia é hoje? É a primeira manhã desde que a Consorte Tong recuperou sua posição. Se não formos, ela vai achar que estamos nos escondendo e terá ainda mais motivos para nos perseguir.

Por mais que Ning tentasse convencê-la, Gu Sijin insistia em visitar a imperatriz.

Sem alternativa, Ning decidiu acompanhá-la, para evitar qualquer problema.

# Capítulo 190 — Não seria conveniente para o que eu quero fazer com ela

Agora, o Palácio Zhongcui estava uma verdadeira festa.

Qiqi, Qiaqia, Bengbeng e Lala corriam de um lado para outro, carregando mesas de nanmu dourado, cadeiras de freixo, penteadeiras e gavetas de mogno, além das roupas de brocado de Sichuan da Consorte Duan, coletes bordados ao estilo de Suzhou e até um corpete vermelho com patos-mandarins.

Primeiro, partiram os móveis de madeira em pedaços. Depois, acenderam as roupas inflamáveis com um acendedor e as jogaram embaixo para iniciar o fogo. Quando as chamas cresceram, acrescentaram a madeira de primeira qualidade.

Aquilo ardia muito melhor do que lenha comum.

Os criados do salão principal ficaram boquiabertos ao ver o que Ning Xiaoxiao estava fazendo. Quem já tinha visto uma coisa daquelas?

De início, tentaram impedi-la, mas Ning os ameaçou: — Quem se atrever a me impedir vai parar dentro do fogão, para queimar junto!

Quem no Palácio Zhongcui ainda não sabia que Ning Xiaoxiao era completamente maluca?

Ela não tinha medo nem da Consorte Duan. Quem a irritasse certamente acabaria se dando muito mal.

Por outro lado, se não a impedissem, quando a Consorte Duan voltasse de apresentar seus cumprimentos e encontrasse o salão principal esvaziado pelo fogo, eles também estariam condenados.

Depois de conversarem entre si, mandaram discretamente um eunuco de pernas rápidas correr até o Palácio Fengluan para avisar à Consorte Duan.

Quando ela voltou às pressas, quase todas as suas roupas luxuosas já tinham virado cinzas.

Furiosa a ponto de entortar a boca, apontou para Ning Xiaoxiao e soltou uma torrente de insultos: — Ning Xiaoxiao! Por acaso eu assassinei sua família inteira na vida passada?! Você...!

— Por que está latindo? — Ning olhou para ela de lado e atirou seu corpete ao fogo. — Você não consegue se comportar como gente e insiste em fazer maldades todos os dias, só para arrumar confusão. Vai culpar quem?

— Sua... sua insolente! — A Consorte Duan arfava, o rosto vermelho de tanta raiva. — Tudo isso foi concedido a mim pelo imperador! São presentes imperiais! Como você ousa? Como ousa?!

— Ah, poupe-me dessa conversa fiada. — Ning falou com sarcasmo. — Presentes do imperador? Desde que entrou no palácio, além das duas bofetadas que ele lhe deu, o que mais recebeu dele?

A Consorte Duan ficou momentaneamente sem reação.

De fato, tudo o que parecia ter sido presente imperial fora comprado por ela mesma no Departamento de Assuntos Internos.

Gastava fortunas e mandava os funcionários entregarem os objetos com toda a pompa, para que os outros acreditassem que desfrutava do favor especial de Lu Linyuan.

As únicas coisas que Lu Linyuan realmente lhe dera foram as duas bofetadas, quando descobriu que ela passava informações do harém para os ministros da corte.

Em tese, ninguém deveria saber desses acontecimentos. Na época, Gu Sijin nem sequer tinha entrado no palácio, e Ning Xiaoxiao devia estar varrendo algum canto esquecido. Como ela sabia de tudo aquilo? Teria sido Lu Linyuan quem lhe contou?

A Consorte Duan se recompôs. Com tantos criados olhando, como a consorte de mais alta posição poderia aceitar uma derrota diante de uma simples Nobre Dama? Que cara teria para continuar vivendo ali?

— Eu continuo sendo a senhora principal do Palácio Zhongcui! Quer dizer que preciso da sua autorização até para usar a cozinha um pouco mais?

Ning bateu a poeira das mãos e se levantou. — Você consumiu toda a lenha. Estava preparando a primeira cremação da sua mãe ou um banquete funerário para o seu pai?

Nota da autora: “Primeira cremação” refere-se ao primeiro corpo cremado no forno de um crematório, quando a queima é mais completa.

A Consorte Duan ficou transtornada e ameaçou procurar Lu Linyuan para exigir justiça. Ning fez um gesto convidando-a a ir. — Vá logo! De preferência, traga o imperador aqui. Aproveito para contar a ele o que você colocou naquela pulseira que deu à Sijin!

A Consorte Duan sentiu um aperto no peito, mas ficou aliviada por ter recuperado a pulseira antes, numa jogada de precaução.

Ela apontou para Ning com arrogância: — Calúnia! Sem provas, não pode macular minha honra com acusações inventadas! Você... Ai!!!

Antes que terminasse de falar, Ning agarrou o indicador que a apontava e o dobrou violentamente para trás. O grito de dor da Consorte Duan foi tão lastimável quanto o miado de uma gata no cio.

— O remédio está pronto. Não tenho tempo para perder com você.

— De agora em diante, cada uma segue seu caminho. Se voltar a me provocar, eu mesma vou rachá-la ao meio para usar como lenha!

Depois da ameaça, largou a mão da Consorte Duan e ordenou friamente: — Peguem o remédio. Vamos.

Empurrou os criados amontoados na porta e foi direto aos aposentos de Gu Sijin.

Ao ver o dedo da senhora quase deformado, Xiuer começou a chorar sem parar. — Senhora, precisamos contar isso ao imperador! Ela é só uma Nobre Dama e já está querendo virar o mundo de cabeça para baixo!

A Consorte Duan não era cega. Sabia muito bem o quanto Lu Linyuan mimava Ning Xiaoxiao.

Se o procurasse, na melhor das hipóteses ele daria uma repreensão sem importância em Ning. E, caso Ning voltasse a mencionar a pulseira, a Consorte Duan acabaria se prejudicando ainda mais.

Por isso, não ousou fazer nada. Depois de tantas provocações, só lhe restava engolir a humilhação, mesmo com os dentes quebrados.

*

A confusão no Palácio Zhongcui atraiu muitos curiosos. Se havia algo que nunca faltava no palácio, eram fofocas.

Logo, a notícia chegou aos ouvidos do imperador.

Xiao Yinzi adorava uma fofoca e, ao saber do caso, foi comentá-lo com Sanfu.

— Por mais favorecida que seja, a Nobre Dama Hua continua sendo apenas uma Nobre Dama. A Consorte Duan ocupa o posto mais alto entre as consortes. Como foi tão humilhada sem revidar? Não parece nada com ela.

Sanfu soltou uma risada fria. — Uma consorte sem o favor do imperador vale menos que uma criada. E nós conhecemos bem a senhora Ning. Ela trata até a nós, servos, com sinceridade. Por que iria provocar a Consorte Duan sem motivo? Já aquela serpente de língua doce e coração venenoso mereceu cada segundo!

Terminou cuspindo no chão, indignado.

Xiao Yinzi sabia que Sanfu tinha uma antiga desavença com a Consorte Duan. Ela o chamara de inútil castrado diante de várias concubinas, e ele nunca esquecera a ofensa.

Por isso, quando Lu Linyuan os flagrou cochichando e perguntou sobre o assunto, Sanfu imediatamente distorceu os fatos para contar a versão que seu senhor gostaria de ouvir.

— Pelo que dizem, a Consorte Duan e a Nobre Dama Hua discutiram por uma bobagem. Enfim... A Nobre Dama Hua é muito favorecida, então é natural que a Consorte Duan fique enciumada. Morando sob o mesmo teto, alguns atritos acabam acontecendo.

Xiao Yinzi ficou pasmo. Agora entendia como seu mestre havia chegado ao posto de eunuco-chefe: contando daquele jeito, parecia que Ning Xiaoxiao tinha sido a grande vítima!

Lu Linyuan sabia que Ning era temperamental demais para aceitar ser maltratada. Mas, pensando melhor, percebeu que ela ainda dividia o Palácio Zhongcui com a Consorte Duan. Aquilo realmente era pouco conveniente.

Não para Ning. Era pouco conveniente para aquilo que ele talvez quisesse *fazer* com ela no futuro.

Então ordenou a Sanfu: — Nesse caso, que parem de morar juntas. Mande o Departamento de Assuntos Internos preparar o Palácio Fengyi. Xiaoxiao vai se mudar para lá.

Ao ouvir o nome Fengyi, Sanfu estremeceu. Levou alguns segundos até recuperar a voz.

— Majestade... Só uma palavra diferencia o Palácio Fengyi do Palácio Fengluan, residência da imperatriz. Ao longo das dinastias, Fengyi sempre foi reservado à Consorte Imperial Nobre. Nossa dinastia ainda nem sequer tem uma Consorte Imperial Nobre, então...

Nota da autora: a Consorte Imperial Nobre ocupa um posto abaixo apenas da imperatriz, equivalente ao de uma vice-imperatriz.

Lu Linyuan pousou o pincel, levantou os olhos para ele e perguntou:

— E quem disse que ela não pode vir a ser a Consorte Imperial Nobre?

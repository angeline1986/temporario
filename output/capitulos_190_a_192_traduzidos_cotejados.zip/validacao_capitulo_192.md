# Validação — Capítulo 192

- **Fonte primária:** `novel_capitulos_181_a_211(20261105-152737).docx`, chinês tradicional.
- **Título original:** 第192章 華嬪娘娘萬福金安
- **Limites dos parágrafos DOCX:** índices 712 até 780 (base zero), inclusive; capítulo seguinte começa em 781.
- **Unidades não vazias cotejadas, incluindo título:** 66.
- **Índices reais:** sem ausências, reordenações ou duplicações na sequência extraída.
- **Campos obrigatórios:** todos preenchidos e CSV reaberto com sucesso.
- **Correspondência estrutural:** uma tradução para cada parágrafo chinês não vazio, inclusive títulos e notas existentes; texto traduzido exportado para Markdown.
- **Decisões editoriais:** Nobre Dama Hua até a publicação do decreto no capítulo 192; título **Concubina Hua** para 華嬪 após a promoção. Preservadas falas interiores 【 】, sarcasmo, referências modernas e distinção entre decreto anunciado ao leitor e anúncio público.
- **Limitação:** conferência de cobertura estrutural e revisão contextual; não foi realizada auditoria semântica independente integral. Erros de nuances ainda podem subsistir.

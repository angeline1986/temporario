# Capítulo 192 — Saudações e vida longa à Concubina Hua

No harém, as consortes que conseguiam agir com arrogância geralmente contavam com uma de duas vantagens.

Ou tinham uma família poderosa, ou desfrutavam do favor do imperador.

Bastava ver a Consorte Duan, que pouco antes quase tivera o dedo quebrado por Ning Xiaoxiao e agora corria para o palácio da imperatriz, para perceber o quanto a Consorte Tong intimidava as outras mulheres.

Na prática, naquele dia as consortes pareciam ir apresentar seus cumprimentos mais à Consorte Tong do que à própria imperatriz.

Quando Ning Xiaoxiao e Gu Sijin chegaram à entrada do Palácio Fengluan, deram de cara com a Consorte Tong.

Embora agora ocupasse apenas o posto de consorte, ela continuava viajando com a pompa reservada às Consortes Nobres.

As liteiras não podiam parar diante dos portões da residência da imperatriz. As concubinas deveriam descer no Portão Fengjing e seguir a pé até o Palácio Fengluan.

Mas a Consorte Tong não se importava com nenhuma dessas regras. Mandou parar sua liteira bem diante da entrada principal, bloqueando metade da passagem.

Com aquele temperamento, se as portas fossem largas o bastante, teria mandado a procissão entrar e estacionar a liteira bem em cima da cara da imperatriz.

Assim que a viu, Gu Sijin puxou Ning Xiaoxiao para prestar-lhe reverência.

Fazia meses que não se viam. A Consorte Tong estava muito mais magra. Antes, tinha bochechas cheias, um rosto ligeiramente arredondado e uma beleza voluptuosa.

Agora, emagrecida, seus traços pareciam mais angulosos e severos, combinando perfeitamente com seu ar arrogante.

Como sempre, ignorou as duas por completo, sem sequer dirigir-lhes o olhar.

Ao passar por elas, alisou afetadamente os cabelos junto às têmporas e soltou um muxoxo desdenhoso.

Só depois que ela entrou no salão principal do Palácio Fengluan é que Gu Sijin e Ning Xiaoxiao a seguiram.

Apresentaram seus cumprimentos à imperatriz, que sorriu e indicou que se sentassem.

Já a Consorte Tong nem se deu ao trabalho de cumprimentar a imperatriz: foi direto ao lugar ocupado pela Consorte Duan.

Durante essas audiências, a distribuição dos lugares também seguia a regra de que a esquerda era mais honrosa que a direita.

Quando ainda era Consorte Nobre, Tong sempre se sentava no primeiro lugar à esquerda. Depois de seu confinamento e rebaixamento, aquele lugar passara legitimamente à Consorte Duan, a mais graduada entre as consortes.

A Consorte Tong parou diante dela e a examinou pelo canto dos olhos. — Se já terminou de esquentar esse lugar com sua bunda fria, levante-se logo e vá sentar onde lhe cabe.

A Consorte Duan ficou sem saber o que fazer. Do assento de honra, a imperatriz interveio com voz firme e controlada: — Consorte Tong, você já não é Consorte Nobre. A Consorte Duan é a primeira entre as consortes. Por que deveria ceder o lugar?

— Humpf! — A Consorte Tong virou lentamente os olhos para a imperatriz, revirou-os e deu uma risada irônica. — A primeira entre as consortes? Ela? Como se tivesse capacidade para isso!

A expressão da imperatriz escureceu, e sua voz ficou mais severa. — O imperador acabou de suspender seu confinamento. Você já se esqueceu da lição? Não se esqueça de que...

Antes que terminasse, a Consorte Duan se levantou voluntariamente e cedeu o assento. Ainda fez uma reverência à Consorte Tong, submissa como se não tivesse espinha dorsal.

Assim que Tong se sentou, uma criada lhe serviu chá fresco. Ela tomou um gole e, mal o líquido entrou na boca, cuspiu-o no chão sem qualquer cerimônia.

Depois, enxugou os lábios com um lenço de seda e comentou com malícia: — Faz tanto tempo que não saio, mas o chá do palácio da imperatriz continua velho e adstringente. Dizem que o chá se parece com quem o serve. Então...

Interrompeu-se, cobriu a boca com o lenço e fingiu corrigir uma gafe. — Ah, olhem só! Falei demais. Vossa Majestade não vai se incomodar, vai?

O que a imperatriz poderia responder?

Só lhe restava engolir a raiva e dizer: — Não me incomodo.

Mas a Consorte Tong passara meses reprimida. Agora que estava frente a frente com uma inimiga, não se contentaria com duas ou três provocações.

Depois de examiná-la por um longo instante, Tong sorriu novamente. — Faz meses que não nos vemos, e Vossa Majestade está cada vez mais velha e sem viço... Ah, não, não! Como li tão poucos livros, não encontro a expressão certa para elogiá-la.

Fingiu pensar e, de repente, bateu palmas. — Já sei! Em vez de velha e sem viço, devo dizer que Vossa Majestade ainda conserva certo charme da juventude!

Essa expressão costuma ser usada para mulheres de meia-idade que ainda preservam alguma graça e beleza. A insinuação era tão insultuosa que não ficava muito atrás de chamá-la de velha e acabada.

O rosto da imperatriz mudou de cor várias vezes. Ninguém no salão ousava fazer barulho: temiam que, na luta entre duas tigresas, até uma respiração um pouco mais alta os transformasse em vítimas.

A única que estava se divertindo de verdade com o espetáculo era Ning Xiaoxiao.

A Consorte Tong era um verdadeiro desastre ambulante, mas sabia provocar a imperatriz como ninguém.

Às vezes, só alguém ruim consegue dar conta de outra pessoa ruim. Sem ela, o harém teria bem menos entretenimento.

A imperatriz levou um bom tempo para recuperar as palavras. — Agora que seu confinamento acabou e sua posição foi restituída, imagino que esses meses lhe tenham dado tempo para refletir. Reconhecer os próprios erros e corrigi-los é uma grande virtude. De agora em diante, cumpra as regras do palácio com rigor. Entendeu?

A Consorte Tong respondeu com indiferença: — Entendi. — E logo acrescentou: — Vossa Majestade continua tão justa ao distribuir recompensas e punições. Mas Gu e Hua chegaram atrasadas para os cumprimentos. Não pretende perguntar a razão?

Olha só! Mal saiu do confinamento e já estava arrumando confusão!

Maravilha. Pelo visto, a ficha criminal dela só iria crescer.

Ning Xiaoxiao ainda guardava rancor porque Tong quebrara o bracelete que Qi Meijuan lhe dera.

Pena que seu poder especial não permitia matar diretamente personagens importantes do romance original. Caso contrário, ela já teria feito Tong em pedacinhos incontáveis vezes.

【Não posso tirá-la de cena de vez, mas ainda posso obrigá-la a fazer uma acrobacia de trezentos e sessenta graus, com espacate e pirueta, mergulhando de cara na sujeira como uma cachorra faminta — e ainda fazê-la sentir dor nos mamilos!】

Estava prestes a modificar o enredo quando, surpreendentemente, a imperatriz começou a falar em sua defesa:

— A Nobre Dama Hua é a nova favorita do imperador. Você estava confinada, Consorte Tong, e não sabe. Em um único mês, ela chega a servir Sua Majestade na cama mais de dez vezes, recebendo ainda mais atenção do que a Nobre Dama Gu no passado. Seu serviço é exaustivo. Desde que agrade ao imperador, não me importo se deixar de comparecer aos cumprimentos.

A imperatriz era mesmo uma jogadora experiente. Manipular os sentimentos alheios era a coisa mais fácil do mundo para ela.

Quanto mais exaltasse Ning Xiaoxiao, mais ciúmes a Consorte Tong sentiria. E, cedo ou tarde, começaria a persegui-la.

Se Tong destruísse Ning ou Ning derrubasse Tong, a imperatriz sairia ganhando de qualquer jeito.

Não precisaria fazer nada além de mexer a língua para colher os benefícios da briga.

A Consorte Tong era feroz e autoritária, mas também não sabia esconder suas emoções. Assim que ouviu aquilo, voltou sua hostilidade contra Ning Xiaoxiao.

— Favorita? E daí? Por mais que receba o favor imperial, continua sendo uma simples Nobre Dama. Nem sequer conseguiu se tornar senhora principal de um palácio.

Avaliou Ning dos pés à cabeça, cheia de desprezo. — Mas, pensando bem, você veio de uma família insignificante e começou como criada. Usou bajulações, sedução e todos os truques mais baixos para subir até aqui. Suponho que isso também seja algum tipo de talento.

Sua boca parecia envenenada.

Mal terminou de falar, um criado anunciou da porta: — Chegou o eunuco Sanfu!

Vendo que Sanfu trazia um decreto imperial, todas se levantaram e se ajoelharam para recebê-lo.

Ning também ia se ajoelhar, mas Sanfu a deteve. — Senhora Ning, não precisa. O imperador disse que pode receber este decreto sentada.

— Eu? — Ning apontou para si mesma, surpresa. — O decreto tem alguma coisa a ver comigo?

Sanfu apenas sorriu, abriu o pergaminho e, depois de limpar a garganta, leu solenemente:

— Decreto imperial: a Nobre Dama Hua é bela, belíssima, de uma beleza sem igual. Determino sua promoção imediata a Concubina Hua e concedo-lhe o Palácio Fengyi como residência. Cumpram-se estas ordens!

Direto ao ponto, curto e claro.

As palavras mais simples também podiam produzir a bofetada mais sonora.

Era como se Ning Xiaoxiao tivesse amarrado um foguete à própria bunda: nunca se vira alguém subir de posto tão depressa.

Em apenas dois meses, passara de criada a concubina, com direito a ser a senhora principal de um palácio. Já era algo de deixar qualquer um de boca aberta.

Mas, quando Sanfu pronunciou as palavras “Palácio Fengyi”, foi como se um trovão tivesse atravessado o telhado do Palácio Fengluan e atingido em cheio todas as concubinas presentes. Ficaram paralisadas, atônitas, sem saber o que dizer.

# Validação — capítulo 236

- **Fonte:** `novel_capitulos_212_a_270(20261105-204934).docx` (original chinês tradicional).
- **Intervalo de parágrafos do DOCX:** 1700 a 1780, índices base zero.
- **Parágrafos não vazios (título/notas incluídos):** 78.
- **Correspondência estrutural:** 78 linhas de cotejo 1:1; índices originais preservados; nenhuma duplicata, ausência ou tradução vazia identificada.
- **Título e notas autorais:** preservados como unidades de cotejo.
- **Decisões editoriais e dúvidas:** A possessão de Tong Guowei é executada por Ning; as ações ocorridas enquanto ela ocupa o corpo não são escolhas conscientes dele. A promoção de Ning a Consorte Nobre, o rebaixamento de Tong a Consorte e a transferência de autoridade foram anunciados no capítulo anterior e confirmados aqui. O sistema indica +5 pontos percentuais, total 45%. O texto chinês da fala imperial sobre vinho contém formulação aparentemente contraditória (還是要飲酒的好), traduzida de acordo com a situação narrativa de proibir vinho; revisar contra outra edição se disponível. “Shrek” preserva a comparação pop. O medo do fim do livro é conjectura de Ning.
- **Limitação:** conferência integral das unidades e leitura contextual; não houve segunda auditoria semântica independente completa.

# Capítulo 238 — Pergunta do dia: a imperatriz já saiu de cena hoje?

(Deixem-me explicar uma coisa: antes eu escrevi “Consorte Tong”, mas deveria ter sido “Concubina Tong”. Foi um erro meu. Se eu corrigir agora, os comentários de vocês podem sair do lugar, então vou deixar como está, tá?~)

Enquanto isso, em outro lugar.

Depois de sair do palácio, Gu Sijin não voltou diretamente para casa. Em vez disso, passou dois dias a sós com Chu Xingran.

Como ainda era uma das mulheres do harém imperial, Chu Xingran não podia lhe dar um título ou reconhecê-la oficialmente como esposa.

Por isso, embora a paixão entre os dois estivesse em chamas, não ultrapassaram a última fronteira da intimidade.

Ao dormirem, Chu Xingran a abraçava com força, como se temesse perdê-la mais uma vez.

E aqueles foram os dois dias em que Gu Sijin dormiu mais tranquilamente em muitos anos.

Mais tarde, Chu Xingran a acompanhou até a residência da família Gu, mas não entrou.

Gu Yanchuan conhecia a história antiga dos dois. Desde que Chu voltara à corte como comandante dos Nove Portões, Gu Yanchuan o procurara repetidas vezes e lhe pedira que não importunasse a filha.

Para não agravar o conflito, Chu ficou à distância, observando Gu Sijin partir.

Mesmo quando já não conseguia avistar sua silhueta, continuou parado por muito tempo antes de finalmente ir embora.

O reencontro familiar foi caloroso. Ao verem Gu Sijin chegar, seus pais ficaram tão emocionados que os olhos de ambos se encheram de lágrimas.

Antes disso, Zhu Yunshan, pai da imperatriz, procurara Gu Yanchuan duas vezes para propor que unissem forças contra Tong Guowei. Em ambas, Gu Yanchuan recusara.

Agora, ao ouvir da filha que ela só pudera voltar para casa graças à intervenção da imperatriz, entendeu que a família Zhu estava tentando conquistar sua boa vontade.

A mãe de Gu preparou uma mesa inteira com os pratos preferidos da filha e lamentou o quanto ela havia emagrecido e sofrido no palácio.

Os adultos geralmente evitam contar aos pais suas próprias mágoas, receosos de fazê-los sofrer de preocupação.

Assim, Gu Sijin manteve o sorriso durante toda a refeição e só compartilhou com os pais histórias divertidas da vida palaciana.

Depois do jantar, sua mãe entrelaçou o braço no dela, querendo acompanhá-la ao quarto para continuarem a conversar.

Mas mal a tocou, ouviu um — Ai! — e viu as sobrancelhas delicadas da filha se contraírem de dor.

A senhora Gu se assustou: — Minha filha! O que houve?

Apesar da resistência de Gu Sijin, insistiu em arregaçar sua manga. Ao encontrar as marcas terríveis deixadas pelos castigos da Consorte Nobre, seus olhos se encheram imediatamente de lágrimas.

Na verdade, graças aos cuidados atenciosos de Chu Xingran nos últimos dois dias, os ferimentos já haviam melhorado mais da metade.

Mas as crostas e cicatrizes pareciam punhais afiados que continuavam atravessando o coração dos pais.

— Como isso aconteceu? De onde vieram essas marcas?

Enquanto soprava delicadamente os ferimentos, a senhora Gu mandou chamar um médico.

Gu Sijin não contou a verdade; disse apenas que se machucara por descuido.

Mas uma explicação tão simples não justificava ferimentos por todo o corpo. Gu Yanchuan reconheceu de imediato as marcas de uma régua disciplinar ou instrumento semelhante de punição palaciana e perguntou, reprimindo a dor: — Diga ao seu pai: quem bateu em você?

Percebendo que não conseguiria esconder o assunto, Gu Sijin finalmente mencionou a Consorte Nobre, com muita hesitação.

Temendo, porém, que o pai tentasse vingá-la, apressou-se a justificar:

— Na verdade, a Consorte Nobre não teve culpa. Eu a ofendi sem querer e me comportei indevidamente no palácio. Como tinha autoridade para auxiliar na administração dos Seis Palácios, era direito dela punir as mulheres do harém. Além disso, eu realmente errei...

Como aqueles dois, que a haviam criado, não conheceriam a personalidade da própria filha?

Qualquer pessoa poderia cometer uma grosseria no palácio, menos Gu Sijin.

Gu Yanchuan não disse mais nada. Apenas ordenou que o médico usasse os melhores remédios para tratar os ferimentos da filha.

Mas naquela mesma noite, quando Gu Sijin adormeceu, ele saiu sozinho e às escondidas rumo à residência da família Zhu.

Zhu Yunshan ficou radiante ao recebê-lo: — Ministro Gu! Que prazer! Entre, sente-se!

Mandou trazer chá e petiscos, mas Gu Yanchuan não pretendia se demorar. Disse apenas, friamente:

— Pensei cuidadosamente sobre a proposta que me fez. Decidi aceitá-la.

— Hahahaha! — Zhu Yunshan soltou uma gargalhada. — O ministro Gu sabe distinguir o certo do errado e se preocupa com o futuro do reino. Isso é uma bênção para a dinastia Qi!

Ergueu a própria xícara e ofereceu chá recém-preparado a Gu Yanchuan. — Então, brindemos à nossa cooperação e à eliminação dos traidores!

*

Palácio Fengluan.

Depois do jantar, a imperatriz praticava caligrafia no gabinete. Com pinceladas firmes e cortantes, escreveu uma frase:

“O destino dá voltas; a retribuição nunca falha.”

Mal terminara quando Xiangling entrou para anunciar:

— Majestade, a Concubina Tong voltou.

— Ah? A Concubina Tong? Hahaha!

A imperatriz deu duas risadinhas de escárnio, ergueu a folha de papel de arroz, sacudiu-a levemente e contemplou a própria caligrafia, muito satisfeita:

— Que maravilha. Como imaginei, ela foi à propriedade de águas termais procurar a própria ruína.

Xiangling informou: — Sua Majestade também lhe retirou a autoridade para auxiliar na administração dos Seis Palácios. Desde que voltou, a Concubina Tong se escondeu e não ousa receber visitas. Nossos informantes viram ferimentos em seu rosto; parece que foi espancada.

A imperatriz bufou com desprezo: — Aquela desgraçada merecia apanhar até morrer. Eu sabia que a viagem lhe traria problemas, mas não esperava notícias tão boas. A retribuição nunca falha, mesmo!

Normalmente, quando a imperatriz estava feliz, Xiangling aproveitava para dizer algumas palavras bajuladoras e agradá-la.

Naquele dia, porém, a criada permanecia calada, abatida e com uma expressão de medo.

A imperatriz lançou-lhe um olhar. — Por que está com essa cara? Há mais alguma coisa? Fale!

Xiangling gaguejou: — Sua Majestade... Sua Majestade promoveu a Concubina Hua...

— Deu a ela o posto de Consorte, não foi? Isso não é nada. Desde que ninguém ameace minha autoridade sobre o harém nem fique no meu caminho, que diferença faz conceder-lhe o título de Consorte?

— Majestade... o imperador lhe concedeu o título de Consorte Nobre e... e também lhe entregou a autoridade para auxiliar na administração dos Seis Palácios...

— Mentira!

A imperatriz explodiu de raiva. O sorriso desapareceu imediatamente, substituído por uma expressão feroz. — As regras ancestrais determinam como devem ocorrer as promoções! Ela não tem filhos nem família influente e, em poucos meses, passou de criada palaciana a Consorte Nobre?! O imperador enlouqueceu?!

Xiangling não sabia se Lu Linyuan havia enlouquecido. Mas a mulher diante dela, essa sim, parecia estar perdendo a razão.

A imperatriz rasgou o papel de arroz em pedaços e os espalhou pelo chão. Ofegava sem parar, consumida pela fúria.

Xiangling tentou acalmá-la durante um bom tempo, até que finalmente ouviu a imperatriz dizer, num tom gelado:

— Já que ela recebeu uma notícia tão maravilhosa, naturalmente preciso lhe oferecer uma bela recompensa. Entre as criadas do Palácio Fengyi, qual é a mais próxima dela?

Xiangling pensou um pouco. — Parece ser Qiqi. Ela e a Nobre Dama Hua...

Antes que conseguisse pronunciar “Consorte Nobre”, recebeu da imperatriz um olhar cortante como uma espada.

Corrigiu-se imediatamente: — Qiqi é próxima tanto de Ning Xiaoxiao quanto de Gu Sijin. Já ouvi Gu Sijin chamá-la de irmãzinha. Além disso, assim que Ning Xiaoxiao se instalou no Palácio Fengyi, nomeou Qiqi chefe das criadas. No dia em que a Concubina Tong foi causar confusão lá, Qiqi foi a primeira a correr para a frente e proteger sua senhora.

Ao ouvir tudo, a imperatriz respirou fundo. Depois de recuperar a compostura, sentou-se no trono e falou com a serenidade de quem não se abala:

— Agora que a Concubina Tong perdeu a autoridade sobre os Seis Palácios, é natural que eu restitua ao Palácio Fengyi os presentes de Ano-Novo que ela havia retido, para que todos possam celebrar as festas como merecem.

— Amanhã cedo, avise o Palácio Fengyi. Mande que a chefe das criadas vá ao Departamento de Assuntos Internos buscar os presentes de Ano-Novo.

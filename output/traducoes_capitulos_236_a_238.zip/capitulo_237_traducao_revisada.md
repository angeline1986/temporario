# Capítulo 237 — Vou comprar umas coisinhas boas para você

Xiaoxiao era corajosa e nunca tivera medo de dificuldades.

Desde que entrara no livro, já mudara incontáveis acontecimentos e alterara o destino de inúmeras pessoas.

Se podia mudar o destino dos outros, por que não conseguiria mudar o final de Lu Linyuan?

Na obra original, ele morria subitamente aos trinta e quatro anos, sem um fim digno.

Era consequência das disputas pelo poder, mas o romance quase não descrevia os acontecimentos políticos da corte. Ele parecia morrer de repente, sem motivo aparente. Depois, Gu Sijin assumia o controle do governo na posição de imperatriz-viúva e acabava se tornando imperatriz reinante, governando por trás da cortina.

A julgar, porém, pela história atual, Lu Linyuan dedicava seu amor exclusivamente a Ning, e Chu Xingran era seu grande amigo. Se Gu Sijin e Chu Xingran pudessem ficar juntos e viver felizes, não haveria motivo para ela se transformar na vilã que se tornaria mais tarde.

O único obstáculo que parecia restar diante de Lu Linyuan era Tong Guowei.

Será que ainda surgiriam mudanças inesperadas no futuro?

Ning não sabia. Só tinha certeza de que, acontecesse o que acontecesse, faria tudo ao seu alcance para reescrever o destino dele.

Por que um imperador tão humano, aparentemente brutal, mas no fundo preocupado com o bem-estar do povo, deveria sofrer o final descrito no livro?

Quando entrou no salão principal, Lu Linyuan ainda estava examinando memoriais.

Conhecia Ning Xiaoxiao tão bem que bastou ouvir seus passos para saber que era ela.

Deixou o pincel imperial de lado, alongou o pescoço dolorido e voltou lentamente o olhar para Ning.

Ela se aproximou pelas costas, pensando em massagear seus ombros. Mas ele se virou de repente e apontou com o indicador para a própria bochecha:

— Uma demonstração de gratidão.

— Hã?

— Você saiu para se divertir e eu a promovi a Consorte Nobre. Não é pedir demais querer um beijo em troca, é?

Ning provocou: — Mas eu nem pedi esse título. Foi você que insistiu em me dar. Agora quer tirar vantagem disso?

Os olhos de Lu Linyuan se arregalaram. Ele reuniu todo o fôlego, prestes a lançar uma resposta sarcástica.

Mas Ning aproveitou o instante: inclinou-se, segurou a nuca dele e, num gesto dominador, selou seus lábios com os dela.

A provocação de Lu ficou presa na garganta. O perfume doce e singular da jovem o encheu de alegria, mas aquela posição lhe pareceu esquisita.

Ele estava sentado; Ning, em pé. E ela ainda segurava sua nuca daquele jeito?!

Ao perceber que talvez tivesse perdido a iniciativa, seu instinto possessivo despertou imediatamente.

Enlaçou a cintura de Ning, levantou-se de repente e, invertendo as posições, deitou-a sobre a escrivaninha imperial.

Aproximou-se pouco a pouco, fazendo cócegas suaves na lateral da cintura dela, com um sorriso irresistível:

— Minha Xiaoxiao está aprendendo cada vez mais coisas.

Ela o encarou com um olhar sedutor. — Já pensou que talvez eu sempre soubesse? Só não tinha mostrado a você.

Lu se inclinou para o pescoço esguio dela e soprou delicadamente contra sua pele. Sua voz saiu baixa, persuasiva:

— Então, de agora em diante, mostre tudo o que tiver para mostrar. Não fique se reprimindo.

Ning Xiaoxiao, que só era rainha da sedução da boca para fora, ainda há pouco se fazia passar por especialista em romances. Bastaram duas frases dele para ficar vermelha até as orelhas.

Ao ver a timidez da amada, Lu sentiu como se uma pena delicada lhe roçasse o coração, provocando uma coceira deliciosa.

Na verdade, ele sabia havia muito tempo que Ning possuía habilidades extraordinárias.

Poderia muito bem explorá-las para fortalecer o próprio governo, mas escolhera continuar fingindo que não sabia de nada.

O amor não deveria se misturar a nenhuma outra ambição — salvo ao desejo carnal e à vontade de possuir o outro.

Ele ajudou Ning a se levantar e a abraçou naturalmente. — Daqui a dois dias será o Ano-Novo. Amanhã vou terminar os assuntos de Estado mais cedo e acompanhar você... Não, espere. Você vai me acompanhar para comprar algumas coisas para a festa, está bem?

— A uns dez quilômetros daqui fica a cidade de Xifeng. Ouvi dizer que as roupas vendidas pelos comerciantes de lá são excelentes. Quero comprar mais algumas para você.

Ao ouvir o nome Xifeng, Ning entendeu imediatamente o que Lu Linyuan estava tramando.

A princesa mais velha e Huanü tinham ido até lá alguns dias antes. A cidade tinha fama de ser bastante liberal e, sobretudo, de vender lingeries sensuais e peças íntimas do tipo dudou.

A princesa comprara várias para Huanü. Quando Ning visitara o quarto delas, vira algumas por acidente e ficara tão constrangida que quase cavara um buraco no chão com os dedos dos pés.

Era óbvio: dizer que pretendia comprar produtos de Ano-Novo num lugar daqueles não passava de uma desculpa transparente. Qualquer um perceberia as intenções de Lu.

Mas Ning não recusou. Pelo contrário, aceitou toda animada: — Claro! Vamos sim!

【Quando chegarmos em casa, faço você vestir o que comprarmos. Humm... só de imaginar, já estou ansiosa!】

Ao ouvir o pensamento, Lu Linyuan ficou todo arrepiado e se apressou a dizer:

— Bem... pensando melhor, acho que é longe demais. Não quero mais ir...

— Ah, Majestade, não faça isso! Vamos, vamos!

— Eu não vou! Pare de me agarrar!

— Ué? Por que está fugindo, Majestade? Volte aqui!!

Ele fugia, ela corria atrás.

E ele não escaparia nem se criasse asas!

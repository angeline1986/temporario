# Validação — capítulo 238

- **Fonte:** `novel_capitulos_212_a_270(20261105-204934).docx` (original chinês tradicional).
- **Intervalo de parágrafos do DOCX:** 1834 a 1905, índices base zero.
- **Parágrafos não vazios (título/notas incluídos):** 69.
- **Correspondência estrutural:** 69 linhas de cotejo 1:1; índices originais preservados; nenhuma duplicata, ausência ou tradução vazia identificada.
- **Título e notas autorais:** preservados como unidades de cotejo.
- **Decisões editoriais e dúvidas:** A observação inicial da autora corrige uma variante de cargo de Tong em texto anterior (佟嬪 em lugar de 佟妃), e foi preservada como nota independente; nenhuma correção retroativa foi feita. A imperatriz nomeia Tong como Concubina Tong neste capítulo apesar de o capítulo 236 referir-se ao rebaixamento a Consorte, discrepância expressa no original. No original, a mãe toca “他” (pronome masculino) ao segurar o braço de Gu Sijin; português mantém referente feminino como decisão de concordância contextual, sem tratar isso como mudança de gênero. A acusação da imperatriz e o pedido de retirada de presentes no final são iniciativas dela; intenção futura ainda não é ação concluída.
- **Limitação:** conferência integral das unidades e leitura contextual; não houve segunda auditoria semântica independente completa.

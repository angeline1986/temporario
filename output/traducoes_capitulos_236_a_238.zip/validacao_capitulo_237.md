# Validação — capítulo 237

- **Fonte:** `novel_capitulos_212_a_270(20261105-204934).docx` (original chinês tradicional).
- **Intervalo de parágrafos do DOCX:** 1781 a 1833, índices base zero.
- **Parágrafos não vazios (título/notas incluídos):** 50.
- **Correspondência estrutural:** 50 linhas de cotejo 1:1; índices originais preservados; nenhuma duplicata, ausência ou tradução vazia identificada.
- **Título e notas autorais:** preservados como unidades de cotejo.
- **Decisões editoriais e dúvidas:** A morte de Lu aos 34 anos e a futura ascensão de Gu Sijin são acontecimentos previstos no romance original, não fatos consumados na linha atual. No trecho sobre Xifeng, o original traz expressões potencialmente corrompidas (“解放父女” e “青趣，杜兜”); a tradução escolhe um sentido contextual de cidade liberal, roupas íntimas sensuais e dudou, sujeito a conferência contra outra edição. A intenção final de Ning de vestir Lu, e não a si mesma, sustenta a inversão humorística. A frase sobre mistura de amor com desejo possessivo foi mantida sem sanitização.
- **Limitação:** conferência integral das unidades e leitura contextual; não houve segunda auditoria semântica independente completa.

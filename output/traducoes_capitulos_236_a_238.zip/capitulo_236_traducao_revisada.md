# Capítulo 236 — Mas... Xiaoxiao queria tanto ficar...

A Consorte Tong foi carregada para fora. Ninguém se importou em saber se estava desmaiada ou morta.

Lu Linyuan tratou Tong Guowei com toda a cortesia: — Ministro Tong, não é sempre que o senhor visita nossa propriedade de águas termais. Preciso recebê-lo como merece. Mais tarde ofereceremos um banquete; por favor, não faça cerimônia.

A propriedade de águas termais jamais havia oferecido um banquete a um ministro. Tong Guowei era o primeiro a receber tal distinção.

Quando mais tarde viu os pratos dispostos à mesa, seus olhos brilharam e ele não pôde deixar de estalar os lábios.

Ning Xiaoxiao: 【Caramba! É tudo o que eu mais gosto de comer!】

O olhar de Lu Linyuan permaneceu fixo em Tong Guowei, como se pudesse atravessar aquela carcaça imunda e contemplar a bela alma de sua amada.

Sem perceber, abriu um sorriso cheio de ternura.

Sanfu viu aquele sorriso e levou um susto. Sua imaginação começou a preencher lacunas com coisas que nem ousava dizer em voz alta...

Ning Xiaoxiao havia adotado também a arrogância de Tong Guowei: sem esperar o imperador dar início à refeição, já pegou os pauzinhos.

Realmente, aquela gatinha gulosa jamais esquecia a comida, não importava onde estivesse.

Os criados puseram vinho diante do imperador e dos ministros; apenas o lugar de Tong Guowei ficou sem uma gota.

Depois de engolir com esforço o camarão enorme que tinha na boca, ele perguntou: — E por que não trouxeram o meu?

Lu Linyuan respondeu: — Lembro-me de quantos anos o ministro Tong passou em campanhas militares e de quantos ferimentos antigos deve carregar. É melhor que não beba.

Desde quando Lu Linyuan se preocupava com os ferimentos de Tong Guowei?

Na verdade, temia que sua amada bebesse demais, esquecesse que estava ocupando outro corpo e se atirasse nos braços dele exigindo beijinhos.

Só imaginar a cena já lhe arrepiava até a alma.

Claro que havia ainda outra razão, relacionada ao ciúme possessivo.

Na última vez, Ning Xiaoxiao havia possuído um gato persa — e uma fêmea, o que não era tão problemático.

Mas desta vez ela estava ocupando o corpo de um homem perfeitamente funcional.

E se bebesse demais e precisasse ir ao banheiro?

Para urinar, teria de segurar aquilo com a mão, não teria?

Como poderia permitir que sua esposa pusesse a mão naquela coisa imunda?

Tong Guowei, entretanto, estava animadíssimo. Agradeceu a preocupação do imperador e acrescentou: — Então acompanharei Vossa Majestade com chá no lugar de vinho!

Dito isso, apanhou um bule da mesa vizinha e fez no ar um brinde na direção de Lu Linyuan:

— Eu viro tudo; Vossa Majestade beba o quanto quiser!

Despejou o bule inteiro garganta abaixo, em grandes goles, deixando Lu Linyuan à beira de um ataque.

E ainda não se deu por satisfeito. Pegou outro bule e uma xícara e foi oferecer brindes de chá a todos os ministros, um por um.

Enquanto brindava, pedia desculpas:

— No passado, me comportei como um canalha. Se alguma vez o ofendi, peço que releve.

— Se não conseguir relevar, pode me dar um tapa na cara também.

— ...

Quando terminou a rodada, já havia engolido três bules de chá. Lu Linyuan estava quase morrendo de aflição.

Franziu o cenho e levou a mão à testa, chegando a planejar que Sanfu e Xiao Yinzi acompanhassem Tong Guowei ao banheiro.

Um ajudaria a segurá-lo; o outro cobriria os olhos dela.

Mas!

Ning Xiaoxiao já tinha bolado uma solução:

Afinal, aquele corpo nem era dela! Se precisasse fazer xixi, faria. Nem precisava abaixar as calças: bastava se aliviar ali mesmo!

E foi assim que Tong Guowei molhou as calças diante de todo mundo.

A mancha era impossível de disfarçar. Exceto Lu Linyuan, que finalmente sossegou e elogiou mentalmente a ótima decisão da esposa, todos os presentes ficaram com o constrangimento estampado na cara.

Alguém, movido pela boa vontade, aconselhou-o a trocar de roupa e voltar depois. Tong Guowei retrucou:

— Trocar de calça por quê? Eu gosto desse calorzinho! No inverno, aquece que é uma beleza! O que você tem com isso?!

— ...

Numa única visita às águas termais, Tong Guowei perdeu toda a dignidade; a Consorte Tong perdeu o posto de Consorte Nobre e a autoridade para auxiliar na administração dos Seis Palácios. A família saiu de lá perdendo dos dois lados.

No dia seguinte, durante o regresso, chegou também a hora de Ning Xiaoxiao deixar aquele corpo.

Tong Guowei estremeceu outra vez. Assim que a própria alma retornou ao corpo, sentiu a virilha úmida, a testa dolorida e um mal-estar generalizado.

Quando ergueu os olhos e viu a filha sentada diante de si, quase soltou um grito.

Ela havia apanhado tanto dele no dia anterior que ficara com o rosto inchado como o de um porco. O inchaço diminuíra um pouco, mas ela ainda parecia o Shrek.

Tong Guowei só a reconheceu pelas roupas. Entre a aflição e a raiva, perguntou: — O que aconteceu?!

O tom irritado fez a Consorte Tong estremecer. Ela mal ousava respirar.

— Minha querida filha, quem fez isso com você?

Tong Guowei estendeu a mão para acariciar seu rosto, mas as agressões haviam deixado a filha em estado de alerta.

Com medo de apanhar novamente durante a viagem de volta ao palácio, ela escondera de antemão uma barra de ferro atrás das costas.

Assim que o pai estendeu a mão, sacou a barra e acertou-lhe uma pancada na cabeça, derrubando-o inconsciente...

*

Concluída a possessão, um clarão azul cintilou e Ning Xiaoxiao reapareceu na entrada da propriedade de águas termais.

Por acaso, avistou a princesa mais velha e Huanü voltando de mãos dadas. Cumprimentou-as e disse que havia saído especialmente para recebê-las. Então as três regressaram conversando e rindo.

Quando chegou ao Pavilhão Tingyu, encontrou Xiao Yinzi à porta. Sem perder tempo, ele fez uma reverência profunda:

— Parabéns, Consorte Nobre! Muitas felicidades! Que Vossa Alteza desfrute de bênçãos e paz!

Ning se divertira tanto no dia anterior que quase esquecera o assunto, não fosse o lembrete de Xiao Yinzi.

Fingiu surpresa: — Consorte Nobre? Que Consorte Nobre? Tem uma Consorte Nobre aqui? Onde?

Xiao Yinzi riu às escondidas. — É uma notícia maravilhosa! Vossa Alteza passou a noite acampando com a princesa mais velha e as outras, por isso ainda não sabe. Ontem Sua Majestade a promoveu ao posto de Consorte Nobre! A antiga Consorte Nobre Tong foi rebaixada a Consorte, e a autoridade que exercia sobre os Seis Palácios também passou para suas mãos!

— Sua Majestade mandou que eu a esperasse desde cedo para transmitir a notícia. Venha comigo à Academia Bitong para agradecer pessoalmente a graça imperial, sim?

Tong Guowei acabara de ser humilhado; Lu Linyuan certamente estava satisfeito.

Ela também queria compartilhar a alegria com ele, então acompanhou Xiao Yinzi até a liteira.

No caminho, Xiao Qi apareceu para dar os parabéns:

【Bip, bip, bip! Parabéns, anfitriã, por concluir a missão “deixar a boca da Consorte Nobre torta”! A missão rendeu mais 5 pontos percentuais de desvio da trama, elevando o índice acumulado a 45%! Continue se esforçando!】

【Além disso, não precisa se preocupar demais com as consequências de ter possuído Tong Guowei. O sistema ajustará automaticamente a trama para que tudo se encaixe!】

Ning Xiaoxiao achou aquilo cada vez mais estranho. Desde quando aquele safado do Xiao Qi era tão bonzinho com ela?

O sistema abandonara seu jeito debochado de sempre e estava excepcionalmente prestativo, até se oferecendo com entusiasmo para ajudá-la nas missões.

Ela não conseguia entender. Só quando a liteira parou diante da Academia Bitong é que deu um tapa na própria coxa e, de repente, compreendeu tudo!

O índice de desvio da trama já se aproximava da metade. Quando chegasse a 100%, ela seria enviada de volta ao mundo moderno...

Mas agora... agora ela não queria voltar...

Seus pais a haviam incentivado a seguir corajosamente o amor que sentia, sem receios.

Eles já tinham encontrado uma forma de estudar o sistema de transmigração e podiam visitá-la quando quisessem. Ela também conseguia trocar bilhetes com eles pelo espaço particular. Não era muito diferente de uma filha que se casara e fora morar longe.

Mas, se o índice chegasse mesmo a 100%, ela voltaria ao mundo moderno e a história daquele livro desmoronaria por completo.

Nesse caso... Lu Linyuan, que afinal era um personagem de papel, desapareceria para sempre da vida dela?

Só de pensar nisso, toda a felicidade que sentira instantes antes se dissipou. O peito ficou apertado e seus olhos começaram a arder.

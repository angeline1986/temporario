# Capítulo 264 — O rosto da Consorte Li é desfigurado pelo fogo

De repente, o olhar de Gu Sijin oscilou e seu rosto ficou sombrio.

As lições pacientes que a mãe lhe dera no passado voltaram à memória, assim como aquele rosto sempre sorridente.

Sua mãe, tal como ela, era uma mulher bondosa até a medula.

Por mais que os outros humilhassem sua posição e a constrangessem, nunca levava isso em conta.

Desde pequena, Gu Sijin vira que, na família Gu, ninguém além de seu pai tratava sua mãe com gentileza.

E era justamente a tolerância e a bondade ilimitadas da mãe que faziam os outros abusarem cada vez mais dela.

Como ela própria costumava fazer: suportava tudo em silêncio, acreditando que ceder lhe traria paz.

Por isso, Gu Sijin sentia profunda pena da mãe.

Sua mãe era uma pessoa tão boa! Com que direito a Consorte Li a insultara?

Além disso, desde que entrara no palácio, Gu Sijin já perdera a conta de quantas vezes a consorte a obrigara a se ajoelhar e quantos tapas recebera.

Já suportara o bastante. Não queria suportar mais.

Desta vez, tiraria da Consorte Li aquilo que ela mais prezava.

— Ai...

Uma fisgada intensa na ponta do dedo a arrancou de seus pensamentos. À luz do luar, olhou para baixo e viu uma pequena gota de sangue brotar de seu indicador delicado.

Então percebeu um brilho metálico entre os doces esfarelados.

Era uma agulha de prata quase imperceptível, escondida dentro do doce.

Se Gu Sijin tivesse levado aqueles doces de volta e os dividido com Ning Xiaoxiao, as consequências poderiam ter sido terríveis.

Hã. Era o que imaginava.

Antes, ela se perguntara como alguém cuja maldade estava entranhada nos ossos poderia mudar de personalidade só porque recebera duas palavras de apoio.

Agora via que as duas apenas haviam encenado seus papéis diante uma da outra.

Gu Sijin levou o indicador aos lábios e sentiu o gosto de sangue espalhar-se pela boca.

Ergueu ligeiramente as sobrancelhas. Em vez de ficar furiosa, sorriu.

O pó que misturara à maquiagem da Consorte Li era fósforo branco.

O fósforo branco tem um ponto de ignição muito baixo: segundo a narrativa, até o vapor que sobe da água fervente é suficiente para fazê-lo pegar fogo.

A Consorte Li valorizava tanto a própria aparência que, ao ir cumprimentar a imperatriz, costumava aplicar várias camadas de pó facial para deixar a pele luminosa e branca.

Gu Sijin recomendara intencionalmente a Chuntao que preparasse um mingau quente no café da manhã da consorte. Quando ela tomasse o mingau, o vapor certamente chegaria ao rosto.

O fósforo branco, ao entrar em combustão, não era fácil de apagar com água.

Na ocasião, pequenas chamas se espalhariam pelo rosto dela: certamente um espetáculo ainda mais brilhante e bonito do que o luar daquela noite.

*

Na manhã seguinte, quando Ning Xiaoxiao e Gu Sijin foram prestar reverência à imperatriz, todas as mulheres do harém estavam presentes, à exceção da Concubina Tong e da Consorte Li.

Assim que Ning se sentou, todas as consortes, menos a imperatriz, levantaram-se ao mesmo tempo e fizeram uma reverência.

— Parabéns a Vossa Alteza pela gloriosa promoção a Consorte Nobre.

Era a etiqueta devida no harém. Ning Xiaoxiao ergueu a mão com indiferença, autorizando-as a se levantar e se sentar. Em seguida, olhou para os lugares vazios de Tong e Li e soltou uma risada fria.

— Hoje é meu primeiro dia de volta ao palácio depois de receber o título de Consorte Nobre. O correto seria que todas viessem me prestar reverência.

— A Concubina Tong sempre foi preguiçosa. Até à imperatriz ela só vem cumprimentar quando lhe dá vontade. Não me surpreende sua ausência.

— Mas por que a Consorte Li também não apareceu? Foi o rosto dela que levou tapas; as pernas continuam funcionando.

Então ordenou a Qiqi: — Vá à residência da Consorte Li e veja se ela quebrou as pernas.

Qiqi acabara de receber a ordem e ia sair quando quase esbarrou em Chuntao, que chegava correndo, desesperada.

Com o rosto lívido de terror, Chuntao entrou, lançou-se ao chão diante de todas e começou a chorar e bater a testa no piso. — Imperatriz, por favor, venha ver nossa senhora! A Consorte Li... ela... ela...

A imperatriz detestava criadas que perdiam a compostura por qualquer coisa. Irritada, repreendeu-a: — Fale logo! Pare de engasgar com as palavras!

Chuntao enxugou as lágrimas e, entre soluços, conseguiu dizer:

— Hoje de manhã, enquanto nossa senhora tomava café, não sei como, mas o rosto dela de repente pegou fogo...

Todos no salão ficaram chocados.

A Consorte Duan logo perguntou: — Explique direito! Como assim o rosto pegou fogo enquanto ela comia? Você serviu um braseiro de café da manhã à sua senhora?!

Os lábios de Chuntao tremiam sem parar, como se ela tivesse presenciado algo apavorante.

— Eu... eu não sei... Nossa senhora só estava tomando um mingau comum. Mas, depois de duas goladas, chamas enormes irromperam de seu rosto! Parecia que um espírito maligno a possuíra. Foi horrível...

A imperatriz franziu a testa. — E como está a Consorte Li agora?

Chuntao respondeu: — Tivemos um trabalho imenso para apagar o fogo, mas o rosto de nossa senhora... O rosto dela... ficou completamente queimado!

Naquela manhã, depois que a Consorte Li se lavou e se maquiou, Chuntao levou o café da manhã.

A consorte não gostava de mingau de galinha preta com inhame, mas Chuntao explicou que a receita nutria o sangue e a energia vital, acelerando a recuperação dos ferimentos.

Só então, meio a contragosto, ela aceitou tomar um pouco.

Sem vontade de usar a colher, levou a tigela diretamente aos lábios.

O vapor do mingau alcançou seu rosto e, naquele instante, incendiou o fósforo branco misturado ao pó de maquiagem.

A Consorte Li gritou e atirou a tigela no chão. Com o rosto envolto em chamas, caiu e começou a rolar de um lado para o outro.

O fogo se espalhou depressa, atingindo também seus cabelos e roupas.

Chuntao ficou paralisada de terror, mas logo começou a chamar as outras criadas para que apagassem o incêndio.

O fósforo branco, porém, não se apagava facilmente com água. Bacia após bacia foi despejada sobre a Consorte Li.

As chamas dos cabelos e das roupas se extinguiram, mas o fogo em seu rosto parecia sobrenatural.

Assim que o apagavam, voltava a surgir sem explicação. A consorte gritou de dor duas vezes; as chamas alcançaram sua boca, e o ar que ela aspirou fez o calor queimar-lhe também a garganta. Nem gritar conseguiu mais.

Quando as mulheres do harém chegaram à residência da Consorte Li, o médico imperial aplicava remédios em suas feridas.

Mais da metade de seu cabelo havia queimado, expondo grandes áreas do couro cabeludo.

O rosto era uma massa de carne viva; crostas carbonizadas aderiam à pele. Ela parecia um fantasma vingativo recém-saído do inferno.

Gemendo, com a voz extremamente rouca devido às queimaduras na garganta, murmurou:

— Meu rosto... Ah! Meu rosto dói tanto...

Ao ver aquela cena, muitas das consortes tiveram ânsias de vômito. Ning Xiaoxiao chegou a cobrir os olhos de Gu Sijin com as mãos, temendo que sua coelhinha inocente ficasse aterrorizada.

O incêndio inexplicável no rosto da Consorte Li, tão difícil de apagar, deixou todos no palácio em pânico.

Quando não se sabe explicar alguma coisa, a culpa sempre sobra para os fantasmas.

Alguém entre as mulheres exclamou: — Será que a Consorte Li foi assombrada por algum espírito?

O ambiente já assustador e sufocante pareceu ficar ainda mais gelado.

Gu Sijin levou a mão ao peito, empalideceu e disse baixinho a Ning Xiaoxiao: — Xiaoxiao, não consigo olhar para isso. Vou voltar ao palácio primeiro.

Como Consorte Nobre, Ning tinha o dever de colaborar na investigação de um incidente envolvendo uma integrante do harém. Por isso, concordou e recomendou a Gu que tivesse cuidado no caminho.

Mas a expressão angustiada de Gu Sijin desapareceu assim que ela saiu do aposento lateral. Ao deixar a residência da Consorte Li, ergueu a cabeça tranquilamente, e o sorriso discreto em seus lábios tornou-se mais evidente.

No meio da confusão, aproveitara um instante em que ninguém prestava atenção para trocar discretamente a caixa de pó facial da Consorte Li por outra.

Em vez de voltar ao Palácio Fengyi pela alameda principal, tomou uma passagem por onde necessariamente circulavam os carros que levavam os dejetos das residências para fora do palácio.

Com um lenço sobre o rosto, passou ao lado de um desses carros e lançou a caixa de pó contaminado com fósforo branco dentro de um balde de dejetos.

Depois parou e olhou para trás, observando o recipiente ser levado para fora do palácio.

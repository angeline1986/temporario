# Validação — Capítulo 263

- **Fonte:** `novel_capitulos_212_a_270(20261105-204934).docx`, original chinês tradicional.
- **Intervalo de parágrafos no DOCX (base zero):** 3629–3688, com próximo título fora do intervalo.
- **Unidades não vazias:** 57, incluindo título e marcadores/notas presentes no capítulo.
- **Cotejo:** 57 linhas, cabeçalho `indice_docx,original_chines,traducao_portugues`.
- **Checagens estruturais:** índices reais, únicos, ordenados e integralmente cobertos; sem tradução vazia; correspondência dos textos chineses recuperados.
- **Arquivo de leitura:** `capitulo_263_traducao_revisada.md`, gerado na mesma ordem das entradas do cotejo.

## Decisões editoriais e observações

O original traz “寧瀟瀟” (Ning Xiaoxiao) no trecho 3664, apesar de o contexto ser uma proposta de aliviar a dor da Consorte Li. Preservei o nome escrito na fonte, sem substituição silenciosa. O texto apresenta Gu Sijin armando uma vingança escondida de Ning, e também a tentativa de envenenamento/ferimento nos doces preparados para Gu; nenhuma das duas ações foi atribuída equivocadamente a Ning. “聖母” foi adaptado para “santinha” com sentido crítico de heroína excessivamente altruísta. A posição de Gu Sijin na fala de Chuntao está como Nobre Dama Gu no original.

## Limites da validação

A correspondência 1:1 de parágrafos foi verificada programaticamente. Foi realizada revisão editorial durante a tradução, mas **não** houve auditoria semântica integral independente por segundo tradutor, nem comprovação automatizada de equivalência de sentido. Passagens ambíguas permanecem identificadas acima.

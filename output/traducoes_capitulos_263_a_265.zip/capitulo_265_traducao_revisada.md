# Capítulo 265 — Sua recompensa será algo delicioso

Gu Sijin era extremamente meticulosa. Agia sem deixar vestígios, com precisão e eficiência.

Embora a família da Consorte Li não fosse especialmente poderosa na corte, seu pai e seu irmão ocupavam, afinal, cargos oficiais de segundo grau subordinado.

Depois que o caso veio a público, Lu Linyuan não podia simplesmente ignorá-lo.

Mandou que o Tribunal de Revisão Judicial entrasse no palácio e investigasse tudo minuciosamente.

Os investigadores só conseguiram determinar que o rosto da Consorte Li se incendiara por causa de fósforo branco. Quanto à origem da substância, procuraram por toda a residência Yuxiu, sem encontrar nenhum indício.

O caso se arrastou por quatro ou cinco dias sem que aparecesse uma pista. No fim, foi deixado de lado, sem uma conclusão.

Desde que a Consorte Li sofrera os graves ferimentos e ficara desfigurada, Lu Linyuan não fora visitá-la uma única vez.

Quando se tratava de mulheres que não fossem Xiaoxiao, permitir que os médicos imperiais a tratassem com todo o cuidado já era o máximo de consideração que ele se dispunha a demonstrar.

A verdadeira responsável, Gu Sijin, porém, vinha sendo atormentada pela consciência naqueles dias.

Não porque achasse errado o que fizera à Consorte Li, mas porque via Ning Xiaoxiao, na condição de Consorte Nobre, correndo de um lado para o outro todos os dias para investigar o ferimento e sentia que causara trabalho à amiga.

Depois que o caso foi temporariamente suspenso, Gu Sijin tocou no assunto durante uma conversa com Ning.

— Xiaoxiao, você andou tão ocupada com o caso da Consorte Li nos últimos dias que meu coração dói só de ver. Vocês nem eram amigas, e você não é de se meter em problemas alheios. Por que está se dedicando tanto a isso?

Ning Xiaoxiao se espreguiçou, massageando a nuca dolorida, e respondeu preguiçosamente:

— Acha que eu quero cuidar dessa confusão? Nem sei quem aprontou essa desgraça. A família da Consorte Li vai à audiência matinal todos os dias exigir uma explicação do imperador. Com tantos ministros de olho no caso, se eu não fizer nada, vão dizer que recebi o título de Consorte Nobre e o poder de auxiliar na administração do harém, mas fujo das minhas responsabilidades e não me esforço por nada.

Gu Sijin brincou: — Desde quando você se importa com o que os outros dizem? Além disso, falem o que quiserem, Sua Majestade sempre vai protegê-la.

Ning sorriu. — É justamente porque ele me protege que não posso continuar criando problemas para ele. Todos os dias ele me diz para não me envolver, e sei que é porque não quer me ver cansada. Mas, se eu não agir, mais cedo ou mais tarde ele vai acabar discutindo novamente com os ministros por minha causa.

— Ele leva tudo em consideração por mim. Não posso simplesmente fechar os olhos, bancar a idiota e aceitar toda a bondade dele sem retribuir nada, posso?

Ela baixou as pálpebras finas, deixando os cílios longos projetarem sombra sobre o rosto, e disse em voz baixa: — Ele quer o meu bem. E, já que gosto dele, naturalmente também quero o bem dele. Não é nada demais ter de correr de um lado para o outro e me cansar um pouco.

Ao ouvir isso, Gu Sijin apenas sorriu em silêncio, sem responder.

❤

Depois da soneca da tarde, Xiao Yinzi veio ao Palácio Fengyi transmitir um recado e acompanhar Ning Xiaoxiao até o Palácio Chaoyang.

Quando chegou, Lu Linyuan estava escrevendo alguma coisa. Como de costume, ela se aproximou devagar, pretendendo ficar ao lado dele e fazer-lhe companhia.

Mas só havia dado dois passos quando ele levantou os olhos e a interrompeu com uma repreensão:

— Fique onde está! Não vê que estou tratando de assuntos de Estado?

— Mulheres do harém não devem interferir na política. De agora em diante, sem minha permissão, você está proibida de ficar ao meu lado enquanto eu trabalho.

As palavras atingiram Ning Xiaoxiao em cheio, e a raiva imediatamente subiu à cabeça.

Ela não fazia ideia de que diabos havia dado em Lu Linyuan naquele dia, mas não estava disposta a aceitar aquilo.

— Você está doente da cabeça? Não foi sempre você quem ficava implorando, com essa cara de pau, para eu permanecer ao seu lado? Acha que estou morrendo de vontade de ler esses seus importantíssimos assuntos de Estado?

Virou-se e saiu, sem lhe dirigir mais uma palavra.

Na verdade, Lu Linyuan pensara em tratar Ning com dureza primeiro e depois lhe oferecer uma recompensa, acreditando que um agrado seria mais doce depois de um desgosto.

Ren Duanli lhe ensinara aquela técnica. Pensando bem, o sujeito devia estar completamente maluco!

Ele sabia perfeitamente que não podia se dar ao luxo de provocar aquela pequena tirana. Por que fora inventar de agir como um idiota sem motivo?

Largou a pena e correu atrás de Ning Xiaoxiao. Quando a alcançou, segurou seu pulso e disse com um sorriso desavergonhado:

— Já ficou brava? Eu estava só brincando! Errei, errei...

Sua voz ficou manhosa, parecida com a de Ning quando fazia charme.

A raiva que ela sentira se dissipou num instante, embora mantivesse o rosto fechado.

— Você errou? Imagine! Como poderia errar? Até as brincadeiras têm um fundo de verdade. Você tem razão: mulheres do harém não podem interferir na política. Só de olhar para seus memoriais, eu devia ter os olhos arrancados. Eu...

— Mulheres do harém não podem interferir na política, mas minha pequena tirana pode.

Lu Linyuan a interrompeu e continuou a se desculpar, descaradamente: — Se quiser culpar alguém, culpe Ren Duanli. Foi ele que me deu essa ideia absurda, dizendo que era uma brincadeira romântica entre marido e mulher...

Ning Xiaoxiao revirou os olhos. — Se não desse ouvidos às bobagens dele, nunca faria uma coisa tão ridícula! O que ele entende de convivência conjugal? Aposto que nem aprendeu direito a conviver como casal com outro homem!

Vendo que a raiva de Ning passara, Lu Linyuan segurou sua mão e a conduziu até a mesa imperial.

— Pronto, não fique mais brava. Vou mostrar os memoriais de hoje.

— Não quero ver.

— São sobre você.

Lu Linyuan abriu o documento sobre a mesa e o mostrou a Ning. Ela lançou um olhar distraído, e seu rosto ficou vermelho na mesma hora.

Aquilo não era um memorial de Estado coisa nenhuma! Estava claro que havia um “espião” em seus aposentos.

O documento continha, palavra por palavra, tudo o que ela dissera a Gu Sijin naquele dia.

Ela mal conseguia olhar, mas Lu Linyuan afinou a voz de propósito, imitando o jeito dela e lendo com a maior cara de pau:

— Cof, cof! “Ele leva tudo em consideração por mim. Não posso simplesmente fechar os olhos, bancar a idiota e aceitar toda a bondade dele sem retribuir nada, posso?”

— “Ele quer o meu bem. E, já que gosto dele, naturalmente também quero o bem dele. Não é nada demais ter de correr de um lado para o outro e me cansar um pouco.”

Ning Xiaoxiao estava tão constrangida que se arrepiou inteira. Estendeu a mão e tapou a boca de Lu Linyuan para fazê-lo parar.

Mas ele já decorara aquelas palavras de trás para a frente. Mesmo com a boca coberta pela esposa, continuou a recitá-las, murmurando sons abafados.

Como tapar a boca dele não adiantava, Ning só pôde cobrir as próprias orelhas, com as bochechas vermelhas.

De repente, sentiu o calor da mão do homem em seus pulsos. Ele fez um pouco de força e afastou delicadamente as mãos com que ela tampava os ouvidos.

Então se inclinou junto à sua orelha e soltou uma expiração quente que a fez estremecer involuntariamente.

Com a mão grande envolvendo a cintura fina da moça, aproximou os lábios de sua orelha macia e murmurou:

— Gosto de ouvir palavras tão bonitas.

— Da próxima vez, não diga essas coisas escondida. Diga-as para mim com frequência. Vai ganhar uma recompensa.

Ao terminar, abraçou Ning Xiaoxiao, sentou-se novamente e a manteve firmemente acomodada sobre suas coxas.

Com a chegada da primavera, as roupas ficavam mais leves, e todas as coisas despertavam e cresciam: assim, era ainda mais fácil perceber aquela vigorosa agitação.

As bochechas de Ning Xiaoxiao ganharam um rubor de embriaguez. Os dedos elegantes de Lu Linyuan passearam inquietos, enquanto sua voz se tornava cada vez mais grave e sedutora:

— Como recompensa, tenho uma coisa deliciosa para você provar.

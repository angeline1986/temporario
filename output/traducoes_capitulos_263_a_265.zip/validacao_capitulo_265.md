# Validação — Capítulo 265

- **Fonte:** `novel_capitulos_212_a_270(20261105-204934).docx`, original chinês tradicional.
- **Intervalo de parágrafos no DOCX (base zero):** 3769–3834, com próximo título fora do intervalo.
- **Unidades não vazias:** 63, incluindo título e marcadores/notas presentes no capítulo.
- **Cotejo:** 63 linhas, cabeçalho `indice_docx,original_chines,traducao_portugues`.
- **Checagens estruturais:** índices reais, únicos, ordenados e integralmente cobertos; sem tradução vazia; correspondência dos textos chineses recuperados.
- **Arquivo de leitura:** `capitulo_265_traducao_revisada.md`, gerado na mesma ordem das entradas do cotejo.

## Decisões editoriais e observações

“大理寺” foi vertido como Tribunal de Revisão Judicial, órgão histórico de revisão de processos. A consciência de Gu Sijin a incomoda por sobrecarregar Ning, não por remorso explícito contra a Consorte Li. A brincadeira “夫妻/夫夫” foi preservada como contraste entre casal heterossexual e casal formado por dois homens. No encerramento, mantive a insinuação sexual e a imagem metafórica da primavera sem explicitá-las além do original.

## Limites da validação

A correspondência 1:1 de parágrafos foi verificada programaticamente. Foi realizada revisão editorial durante a tradução, mas **não** houve auditoria semântica integral independente por segundo tradutor, nem comprovação automatizada de equivalência de sentido. Passagens ambíguas permanecem identificadas acima.

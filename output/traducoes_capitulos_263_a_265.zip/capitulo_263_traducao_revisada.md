# Capítulo 263 — Uma bela mulher de coração venenoso

Naquele dia, depois de voltarem ao palácio, as duas amigas conversaram sobre muitas coisas.

Havia um mês que não se viam e sentiam muita saudade uma da outra. Não importava o assunto: ambas conversavam sorrindo.

Gu Sijin devolveu a Ning Xiaoxiao a medalha de imunidade à morte, embrulhada em um lenço de seda. — Agora que você voltou, é hora de pegar de volta o que deixou comigo.

Pôs a medalha nas mãos de Ning. — Afinal, foi um presente de Sua Majestade. É valioso demais para você desprezar a consideração dele.

Ning Xiaoxiao sorriu. — Enquanto eu estiver no palácio, serei sua própria medalha de imunidade à morte, irmã. Comigo aqui, ninguém mais vai ousar maltratar você.

Quando acabara de transmigrar para o romance e começara a acompanhar Gu Sijin, Ning Xiaoxiao não tinha uma opinião muito boa dela.

A descrição de seu complexo de santa no romance original era de dar vergonha alheia. Numa época em que histórias de protagonistas que dão o troco estavam em alta, uma personagem santinha só atraía críticas sem fim.

Mas, depois de passar a conviver com Gu Sijin, sempre que Ning aprontava alguma coisa e se metia em encrencas, Gu era a primeira a se colocar à frente dela para protegê-la.

Mesmo sabendo que, na situação em que se encontrava, mal tinha forças para proteger a si mesma, Gu continuava disposta a dividir as dificuldades com Ning, assumindo sua responsabilidade como senhora.

Certa vez, dissera à Concubina Tong — que na época ainda ocupava o posto de Consorte Nobre — que, se quisesse bater em Ning Xiaoxiao, teria de bater primeiro nela.

Naquele momento, Ning compreendeu que não detestava as santinhas: detestava apenas quando não era ela a beneficiária daquela bondade.

Antes, Gu Sijin arriscara a vida para protegê-la. Agora que Ning tinha poder para retribuir, jamais permitiria que a amiga fosse humilhada novamente.

*

Mais tarde naquela noite, depois de terminar os assuntos de Estado, Lu Linyuan chamou Ning Xiaoxiao ao Palácio Chaoyang para jantarem juntos. Ela não voltaria naquela noite.

Depois que Ning partiu no palanquim cerimonial reservado às favoritas imperiais, Gu Sijin disse a Qiqi e às demais que queria dar um passeio para espairecer e proibiu que alguém a acompanhasse.

Na verdade, assim que saiu do palácio, dirigiu-se sem desvios à residência da Consorte Li.

Quando chegou, o inchaço e a vermelhidão do rosto da consorte já haviam diminuído bastante.

Bastou um olhar para Gu Sijin identificar, sobre a penteadeira, um pote de unguento de ouro-púrpura para ativar a circulação, cujo valor chegava a mil peças de ouro.

Era um remédio excelente: uma colherinha sobre a área avermelhada bastava para tirar a vermelhidão em meia hora, reduzir o inchaço em três horas e, em cinco, devolver a aparência normal a ferimentos sem a pele rompida.

Nada importava mais à Consorte Li do que sua beleza. Praticamente toda a mesada mensal, mais o auxílio de sua família, era gasto com aquele rosto.

Depois de se sentar, Gu Sijin tentou consolá-la: — Não leve isso tão a sério, Consorte Li. A Consorte Nobre não quis realmente criar dificuldades para você hoje. Não guarde rancor dela...

A Consorte Li soltou uma risada amarga. — Rancor? Que direito tenho de guardar rancor? O que fiz vocês sofrerem no passado foi muito pior do que o que me aconteceu hoje. Se terminei humilhada e ridicularizada, só posso culpar a mim mesma.

Abandonando a habitual expressão feroz, ela de repente segurou a mão de Gu Sijin.

— Obrigada pelo que fez hoje.

— Há tantas pessoas neste palácio! Sempre fui próxima da Consorte Duan, da Concubina Jia e das outras. Mas, quando algo aconteceu comigo, nenhuma delas disse uma palavra em minha defesa.

— Antes de você chegar, umas dez consortes, de todos os escalões, vieram anunciar que queriam me visitar. Depois disso, finalmente entendi: que verdadeira irmandade existe no harém? No fim das contas, só você se dispôs a deixar o passado para trás e me ajudar.

Mal conseguiu dizer mais algumas frases antes de seus olhos ficarem vermelhos. — Eu a tratei mal, procurei briga e fui grosseira com você tantas vezes... Devo um pedido de desculpas. Perdoe-me...

Gu Sijin sorriu com gentileza, sem sinal algum de censura. — Entramos todas neste palácio e passamos a nos chamar de irmãs. Longe da família, só podemos contar umas com as outras. Por que haveríamos de guardar rancores de um dia para o outro?

— Sempre admirei a personalidade decidida da senhora. Se estiver disposta a se aproximar de mim, ficarei feliz em sermos boas amigas.

Um brilho frio passou pelos olhos da Consorte Li, que apertou ainda mais a mão dela. — É verdade? Nesse caso, seria uma bênção para mim. Depois de apanhar da Consorte Nobre hoje, também vi como são frios os corações neste palácio. O modo como tratei os outros um dia acabaria voltando contra mim.

— Pensando bem, o que ganhei com isso? Sua Majestade nunca vai se importar comigo. Posso lutar e competir à vontade, mas, no fim, não me restará nada...

Ouvindo aquela tristeza, Gu Sijin mudou de assunto. — Os ferimentos do rosto da senhora já estão bem melhores. Amanhã provavelmente estarão curados. Esse unguento é mesmo extraordinário, mas, embora faça a pele parecer recuperada, a dor demora mais a passar.

— Conheço um método que talvez ajude a aliviar a dor de Ning Xiaoxiao. A senhora gostaria de experimentar?

A bochecha da Consorte Li ainda ardia, então ela concordou.

Gu Sijin pediu que trouxessem uma solução refrescante de hortelã e solicitou à consorte que fechasse os olhos.

Embebeu um lenço de seda no líquido de hortelã e soprou de leve através do tecido, na direção do rosto dela.

O frescor suave realmente ajudava a amortecer a dor. A Consorte Li permaneceu de olhos fechados, ergueu ligeiramente as sobrancelhas e sorriu satisfeita.

— Você sempre tem uma solução.

— Se a ferida já não dói, a senhora também não deve guardar mágoa. A Consorte Nobre realmente não quis persegui-la.

— Ah, você! Sei que é tão próxima da Consorte Nobre quanto uma irmã e que veio me apaziguar por temer que eu queira me vingar dela no futuro. Se eu tivesse uma irmã tão sincera quanto você no palácio, já estaria satisfeita.

Gu Sijin riu com leveza. — A senhora não acabou de dizer que, daqui em diante, seríamos irmãs também?

Enquanto trocavam amabilidades, a Consorte Li manteve os olhos delicadamente fechados.

Gu Sijin conversava e soprava o rosto dela, mas suas mãos não ficaram paradas.

Sem chamar atenção, abriu a caixa de pó facial junto à gaveta da penteadeira e despejou nela um pacotinho de fósforo branco em pó que trouxera consigo. Com um grampo de prata, misturou os dois pós de coloração semelhante.

Quando já não era possível perceber nada de estranho, tampou a caixa novamente.

Ela sorriu. — Está se sentindo melhor, senhora?

A Consorte Li abriu lentamente os olhos. A dor havia de fato diminuído muito, e sua gratidão por Gu Sijin só aumentou.

Mais tarde, mandou Chuntao acompanhá-la até a saída e ainda lhe deu uma porção de doces finos preparados em sua residência.

Antes de sair, Gu Sijin recomendou a Chuntao: — Cuide bem de sua senhora. Embora o ferimento esteja melhor, ela precisa evitar certos alimentos nestes próximos dias. Amanhã cedo, faça um mingau de galinha preta com inhame. Algo leve e nutritivo.

Chuntao assentiu. — Não esquecerei as recomendações da Nobre Dama Gu. Tenha cuidado no caminho de volta.

Depois de sair da residência da Consorte Li, Gu Sijin caminhou sem pressa pela longa alameda.

Em vez de voltar diretamente ao palácio, fez um desvio até o Lago Imperial.

Retirou os doces que recebera da caixa de comida, quebrou-os e esfarelou-os, lançando as migalhas às carpas coloridas do lago.

A lua estava especialmente bonita naquela noite. O crescente refletido na superfície ondulante parecia uma pedra prateada caída dentro d'água.

A luz fria do luar iluminava seu rosto, tornando ainda mais estranhamente bela a expressão entre sorriso e ausência de sorriso.

Ela já era deslumbrante por natureza. Vista assim, parecia que a expressão “bela mulher de coração venenoso” havia sido criada especialmente para ela.

# Validação — Capítulo 264

- **Fonte:** `novel_capitulos_212_a_270(20261105-204934).docx`, original chinês tradicional.
- **Intervalo de parágrafos no DOCX (base zero):** 3689–3768, com próximo título fora do intervalo.
- **Unidades não vazias:** 77, incluindo título e marcadores/notas presentes no capítulo.
- **Cotejo:** 77 linhas, cabeçalho `indice_docx,original_chines,traducao_portugues`.
- **Checagens estruturais:** índices reais, únicos, ordenados e integralmente cobertos; sem tradução vazia; correspondência dos textos chineses recuperados.
- **Arquivo de leitura:** `capitulo_264_traducao_revisada.md`, gerado na mesma ordem das entradas do cotejo.

## Decisões editoriais e observações

A narrativa descreve a suposta ignição do fósforo branco pelo vapor do mingau; esta é uma afirmação do texto ficcional, não uma orientação técnica nem uma verificação científica do mecanismo. Foi mantida a brutalidade dos ferimentos sem omissão. Gu Sijin efetua a troca da caixa de pó facial; Ning não sabe da autoria. “遇事不決，鬼怪背鍋” foi adaptado para uma ironia natural sobre culpar fantasmas quando falta explicação.

## Limites da validação

A correspondência 1:1 de parágrafos foi verificada programaticamente. Foi realizada revisão editorial durante a tradução, mas **não** houve auditoria semântica integral independente por segundo tradutor, nem comprovação automatizada de equivalência de sentido. Passagens ambíguas permanecem identificadas acima.

# Capítulo 41 — Eu mal consigo deixar de mimá-la. Como poderia castigá-la?

Naquela noite, Lu Linyuan e Ning Xiaoxiao passaram metade da madrugada observando as estrelas no mirante.

Ning Xiaoxiao não era uma coruja: não tinha a resistência do imperador para ficar acordada até tão tarde.

Além disso, bebera um pouco de vinho e, com a brisa da montanha, acabou adormecendo, sonolenta.

Sua cabeça tombou involuntariamente para a direita e foi repousar, bem certinha, sobre o ombro de Lu Linyuan.

Ele ergueu o ombro, tentando fazer a cabeça dela escorregar.

Mas parecia que ela havia grudado nele. Por mais que se remexesse, a cabeça não saía do lugar.

Ning Xiaoxiao já não se lembrava exatamente do que acontecera naquela noite.

Quando despertou, sentiu o pescoço um pouco dolorido. Ao tentar movimentá-lo, percebeu que passara a noite inteira dormindo apoiada no ombro de Lu Linyuan.

E, para completar, estava coberta com o manto imperial dele!

Despertou de uma vez:

【Como foi que eu dormi? Por que passei a noite inteira encostada no ombro dele?】

【E de onde saiu esse manto? Ele ficou descoberto para me cobrir?】

Encostou o dorso da mão na testa, tentando verificar se tinha febre.

【Ele ficou maluco ou fui eu?】

Olhou para Lu Linyuan, que ainda dormia.

Suas pálpebras eram finas, deixando entrever as veias azuladas. Os cílios longos, retos e densos repousavam sobre os olhos. A marca vermelha, cor de cinábrio, sob o canto do olho esquerdo tornava o rosto ainda mais delicado e inconfundível.

O nariz elegante tinha apenas uma ligeira saliência sobre o dorso. Os lábios finos, num tom saudável de rosa queimado, não apresentavam uma única pele solta nem ruguinhas; pareciam tão macios e úmidos que davam vontade de mordê-los.

O rosto inteiro era limpo como uma tela sem defeitos, como se alguém tivesse aplicado dezoito camadas de filtro de suavização.

Era essa a diferença entre um personagem de livro e uma pessoa de verdade, não era?

Na vida real, por mais absurdamente bonito que fosse um homem, ao acordar ele certamente estaria descabelado, com o rosto oleoso e toda a aura de galã feita em pedaços.

Ning Xiaoxiao passou algum tempo fantasiando com a beleza divina de Lu Linyuan. Quando recuperou o juízo, a vontade de descobrir o que ocorrera depois de se embebedar na noite anterior ficou ainda maior.

Invocou então o documento na mente e descobriu que, ao tentar reler eventos já ocorridos, todo o conteúdo correspondente aparecia coberto por um mosaico.

Será que, depois que alguma coisa acontecia, o documento não permitia mais consultá-la?

【Socorro! Alguém pode me contar o que aconteceu ontem à noite?】

Segurando o manto do tirano, convenceu-se de uma explicação que lhe pareceu perfeitamente razoável:

【Ele deve ter adormecido antes de mim. Por isso consegui passar a noite apoiada no ombro dele.】

【O manto devia estar cobrindo o próprio imperador, só que tenho mania de roubar a coberta enquanto durmo. Devo ter puxado o manto para mim, não é?】

【Não pode ser! Preciso devolver esse manto antes que ele perceba, ou estou acabada outra vez!】

Ela sacudiu o manto e estava prestes a cobri-lo quando Lu Linyuan espirrou de repente e acordou.

Ao abrir os olhos, viu Ning Xiaoxiao segurando seu manto imperial como uma rede, com os braços abertos, numa postura que parecia indicar que pretendia atirá-lo sobre sua cabeça para sufocá-lo.

Imediatamente ficou alerta. — O que está fazendo?

— Ah? Isto... Bem, esta serva viu que o manto de Vossa Majestade tinha caído no chão e estava tentando cobri-lo de novo!

— Atchim!

Lu Linyuan espirrou várias vezes seguidas. Pelo visto, tinha pegado um resfriado.

【Estou perdida! Se ele descobrir que roubei o manto dele para me cobrir ontem à noite, estou morta!】

Então resolveu se antecipar à acusação, como uma culpada que aponta o dedo primeiro: — Mas, Majestade! Um homem feito o senhor e ainda deixa o manto escorregar para o chão enquanto dorme! Ontem à noite ele caiu três vezes. Nas três, fui eu quem o pegou e tornou a cobri-lo!

Lu Linyuan a examinou com a testa franzida. Parecia prestes a dizer alguma coisa, mas se conteve.

Na verdade, fora Ning Xiaoxiao quem derrubara o manto no chão três vezes naquela noite. E, nas três, ele o recolhera para cobri-la novamente.

Aquela mulher era mesmo uma especialista em mentir com a maior cara de pau!

Ele arrancou o manto das mãos dela, vestiu-o e saiu.

Ao passar por Ning Xiaoxiao, disse friamente: — O que aconteceu esta noite não pode ser contado a ninguém. Caso contrário...

— Caso contrário, Vossa Majestade mandará cortar minha cabeça, certo? Esta serva já entendeu! Não vai contar nada!

Vejam só: o coitado do ser humano já aprendera até a completar as ameaças antes de ouvi-las.

De volta ao Palácio Chaoyang, Lu Linyuan lavou o rosto com água fria.

Pensava que, na noite anterior, devia mesmo ter enlouquecido.

Com leitos macios e travesseiros dourados à disposição no palácio, ele preferira passar a noite inteira dormindo na montanha com aquela mulher maluca!

Ainda deixara que ela se apoiasse em seu ombro, cobrira-a três vezes com a própria roupa e acabara pegando um resfriado!

Quanto mais pensava, mais irritado ficava. Foi justamente nessa hora que Sanfu entrou.

Sanfu fez uma reverência formal. Antes que pudesse dizer qualquer coisa, Lu Linyuan disparou, tomado de raiva:

— Aquela Ning Xiaoxiao do Palácio Zhongcui... Transmita minha ordem ao Departamento de Assuntos Internos: não devem pagar o estipêndio mensal dela durante três meses! Não! Durante seis meses!

Sanfu arregalou os olhos, sem saber como reagir.

Que maluquice era aquela do seu senhor, logo de manhã?

Antigamente, quando alguém o ofendia, o imperador não resolvia tudo com um aceno da mão, mandando cortar a cabeça do infeliz?

Era a primeira vez que Sanfu o ouvia falar em punir alguém cortando seu pagamento mensal...

Para o imperador, aquela punição chegava até a ser meio bonitinha.

— Certo, Majestade, não se irrite mais. Este humilde servo tem outra questão urgente para informar.

— A comitiva do soberano de Xiliang já chegou à passagem de Shamen. Calculamos que ele estará no palácio dentro de três dias. Quanto ao banquete, a imperatriz e a Consorte Nobre certamente estarão presentes. Restam duas vagas entre as mulheres do harém. Quem Vossa Majestade deseja convidar? Assim poderei providenciar os preparativos.

Xiliang era o Estado estrangeiro que representava a maior ameaça à dinastia Qi.

Nos últimos anos, seu poder crescera vertiginosamente, e agora tinha força suficiente para negociar de igual para igual com Lu Linyuan.

A visita pessoal de seu soberano à capital quase certamente traria exigências desfavoráveis à dinastia Qi.

Portanto, pouco importava se as mulheres do harém compareceriam ao banquete. Mas Ning Xiaoxiao precisava estar lá!

Com ela presente, Lu Linyuan poderia saber de antemão o que estava por vir.

Então ordenou: — A Consorte Duan ocupa a posição mais elevada entre as quatro consortes. Convide-a. E convide também a Respondente Gu, que vive em seus aposentos.

— Bem... — Sanfu hesitou. — Majestade, Respondente é o posto mais baixo entre as concubinas imperiais. Uma Respondente não pode participar de um banquete de Estado. Mesmo que seu nome conste da lista de convidadas, a imperatriz-viúva provavelmente o riscará.

— Se uma Respondente não pode ir, uma Atendente pode, não é? Transmita minha ordem: Gu Sijin fica imediatamente promovida de Respondente Gu a Atendente Gu.

Com o favor imperial que Gu Sijin parecia receber a cada poucos dias, era questão de tempo até alcançar essa posição.

Sanfu recebeu a ordem e já se preparava para sair quando Lu Linyuan o deteve:

— Espere. Quanto àquela Ning Xiaoxiao... Continue pagando o estipêndio normalmente. Finja que eu nunca falei em castigá-la.

Afinal, naquele momento ele não ousava provocar aquela sua pequena ancestral temperamental!

Ao ouvir isso, Sanfu voltou a exibir aquela expressão de quem acabara de flagrar um romance. Bem que desconfiava: Lu Linyuan «mimava» tanto Ning Xiaoxiao... Como teria coragem de castigá-la?

---

## Notas editoriais

- Os três episódios em que Lu Linyuan recolhe o manto para cobrir Ning Xiaoxiao foram mantidos; o relato invertido dela é uma mentira consciente, não discrepância narrativa.
- O imperador primeiro ordena suspender os pagamentos por seis meses e depois revoga a ordem. Ambas as decisões estão preservadas.
- Os postos Respondente e Atendente são distintos: Gu Sijin é promovida para viabilizar sua presença no banquete.
- 西涼 (Xiliang), 沙門關 (passagem de Shamen), 啟朝 (dinastia Qi) mantidos como topônimos e denominação dinástica, sujeitos a padronização do glossário anterior.

# Conferência do capítulo 40

Fonte primária: `novel_capitulos_1_a_60(20261103-131325).docx`, capítulo 40 até antes do título do capítulo 41.

## Correspondência estrutural

- Unidades chinesas, incluindo título: 85.
- Unidades portuguesas: 85.
- Correspondência ordenada: 85/85.
- Células vazias: zero.

## Revisão e observações

Tradução redigida diretamente das unidades do chinês tradicional, respeitando o encadeamento narrativo, diálogos, gênero, contagens e mudanças de focalização.

- O signo 楚女座 é grafia deliberadamente alterada de 處女座 (Virgem), confirmada pela nota da autora sobre contornar a censura. No português, o duplo sentido de 'Virgem' sustenta a cena.
- 射 em 射手座 (Sagitário) também permite alusão sexual, conservada na reação 'Atirar aonde?' e na distinção de um arqueiro.
- 野外格鬥 ('combate ao ar livre') funciona como eufemismo insinuante da narração; mantido entre aspas.
- A canção 本草綱目 é referida no contexto de exercícios e mantida como título traduzido, não como instrução médica.

## Limitações

A correspondência foi conferida programaticamente e o conteúdo revisado na tradução. Não houve uma segunda auditoria semântica independente, nem certificação de equivalência absoluta. O cotejo permite revisão posterior de cada parágrafo.

**Estado:** tradução revisada, cotejo estrutural completo, segunda auditoria linguística pendente.

# Capítulo 39 — O passado trágico do tirano

As palavras de Cailian eram de uma insolência extrema. Mas foi justamente por ela falar com tanta firmeza que a Atendente Xiao começou a temer as consequências.

E se...?

E se, na próxima vez que Gu Sijin fosse chamada para passar a noite com Lu Linyuan, ela lhe soprasse algumas palavras ao ouvido? Quem acabaria se dando mal não seria a própria Xiao?

Enquanto hesitava, sem saber se devia avançar ou recuar, ouviu atrás de si uma voz preguiçosa:

— Ora, ora. Que animação por aqui.

Quem chegava era a Consorte Li. Não era tão arrogante e indomável quanto a Consorte Nobre, mas tampouco era fácil de lidar.

Desde que entrara no palácio, três anos antes, Lu Linyuan não havia posto os pés uma única vez em seus aposentos. Nem sequer sabia seu nome.

Por isso, ouvir Cailian dizer que «quem não recebe o favor imperial é inferior» lhe ferira os ouvidos.

— Com a imperatriz adoentada, vocês acham que não há mais ninguém para pôr ordem aqui? Quem estava fazendo essa algazarra?

A Atendente Xiao correu para recebê-la com um sorriso bajulador e apontou para Cailian. — Respondendo à Consorte Li, foi essa criada sem-vergonha! A Respondente Gu recebeu algum favor do imperador nos últimos dias e agora suas servas se acham no direito de fazer o que bem entendem!

A Consorte Li ergueu a sobrancelha na direção de Cailian. Bastou um olhar para fazê-la cair de joelhos.

— Consorte Li, tenha piedade! Esta serva... esta serva não fez por mal! A Atendente Xiao falou de maneira ofensiva e insultou minha senhora. Fiquei tão indignada que...

*Pá!*

A Consorte Li lhe deu uma bofetada e zombou: — Xiao é uma Atendente, enquanto Gu Sijin é uma Respondente. Desde quando uma Atendente repreender uma Respondente é uma ofensa à hierarquia? E, mesmo que Xiao tenha dito algo desagradável, uma serva como você não tem o direito de gritar com sua superior!

— Sim... A Consorte Li tem razão. Esta serva...

*Pá!*

Outra bofetada.

— Eu lhe dei permissão para responder? — O olhar afiado da Consorte Li voltou-se para Gu Sijin. — É assim que a Respondente Gu costuma educar seus criados?

Gu Sijin ajoelhou-se respeitosamente. — Perdoe-me, Consorte Li. Falhei em discipliná-la, e ela a desrespeitou. Quando voltarmos aos aposentos, cuidarei de corrigi-la.

— Ela é criada da sua família desde pequena. Depois de tantos anos sob seus cuidados, continua sem aprender as boas maneiras.

*Brrrrrum!*

O trovão ribombou e uma tempestade desabou sem qualquer aviso.

Uma criada abriu imediatamente um guarda-chuva para a Consorte Li. Ela estendeu a mão para além da borda, aparou algumas gotas e disse, sombria: — Essa chuva veio em boa hora. Vocês duas vão ficar ajoelhadas aqui, debaixo d'água, refletindo cuidadosamente sobre seus erros.

***

Um eunuco do Departamento dos Aposentos Imperiais chegou ao Palácio Zhongcui debaixo da chuva, mais uma vez trazendo um recado imperial.

Naquela noite, Lu Linyuan havia escolhido novamente a placa de Gu Sijin.

— Meus parabéns à sua senhora! Ser escolhida pelo imperador em duas noites seguidas é uma alegria imensa! Nesse ritmo, aposto que dentro de poucos dias ela será promovida de posição!

Qiqi, Qiaqia, Bengbeng e Lala sorriam de orelha a orelha. Só Ning Xiaoxiao suspirou.

*Ai... Pelo visto, Gu Sijin terá de fazer mais umas setenta ou oitenta séries de ginástica esta noite...*

Como Gu Sijin iria «servir o imperador» à noite, precisava começar a se preparar desde já.

Mas ainda não havia voltado. Ning Xiaoxiao então pegou um guarda-chuva e saiu para buscá-la nos aposentos da imperatriz.

A chuva parou no meio do caminho. De longe, ela avistou Gu Sijin e Cailian encharcadas como duas galinhas molhadas, apoiando-se uma na outra enquanto se aproximavam.

Correu até elas e, enquanto secava a água do corpo de Gu Sijin, perguntou o que havia acontecido.

Gu Sijin se recusou a falar. Cailian, porém, estava cheia de queixas e não parava de tagarelar.

Ao ver Gu Sijin tão magoada e, ainda assim, contendo as emoções, Ning Xiaoxiao sentiu uma inesperada pontada de pena.

Aquela protagonista forte e destinada a grandes feitos... Em que sua vida havia se transformado por causa da chegada de Ning Xiaoxiao ao livro?

Assim que voltou ao palácio, Gu Sijin começou a apresentar febre alta.

Os criados perguntaram duas vezes ao Departamento dos Aposentos Imperiais se ela poderia ser dispensada da visita noturna. Nas duas vezes a resposta foi não.

Naquela noite, mais uma vez coube a Ning Xiaoxiao ficar de vigília durante o serviço imperial.

Ela espiava pelo vão da porta, tentando ouvir o que acontecia lá dentro.

Como era de esperar, Lu Linyuan estava ensinando a Gu Sijin uma nova série de exercícios.

E aquela boba de Gu Sijin nem mencionava que estava passando mal: simplesmente acompanhava os movimentos do imperador.

Ning Xiaoxiao tinha medo de que ela acabasse morrendo de repente por causa do esforço intenso.

Assim, correndo o risco de cometer uma grave falta de respeito, abriu a porta dos aposentos, ajoelhou-se e suplicou a Lu Linyuan:

— Majestade! Minha senhora realmente não pode fazer mais ginástica hoje!

— Ela ficou debaixo da chuva esta tarde e agora está com febre alta. Se Vossa Majestade insistir em fazê-la se exercitar, alguma coisa grave pode acontecer!

Na verdade, à tarde, os funcionários do departamento já haviam informado ao imperador sobre a febre de Gu Sijin. Só que ele achara que eram desculpas inventadas para escapar da ginástica.

Por isso recusara o pedido sem pensar duas vezes.

Afinal, se Gu Sijin não viesse «servi-lo», ele não teria um pretexto legítimo para chamar Ning Xiaoxiao.

Mas, olhando agora para o rosto pálido e os lábios ressecados de Gu Sijin, parecia que ela realmente estava muito mal.

Ning Xiaoxiao se levantou por conta própria e ajudou Gu Sijin a se sentar na cama para descansar.

Lu Linyuan perguntou: — Por que ficou na chuva?

— Foi descuido meu, Majestade. Eu...

— Que descuido seu, coisa nenhuma!

Ning Xiaoxiao não tinha a mesma inclinação de Gu Sijin para bancar a santa. Contou ao imperador tudo o que acontecera naquele dia, sem deixar de carregar nas tintas e atiçar sua indignação.

Ao ouvi-la, Lu Linyuan deixou transparecer um leve traço de raiva no olhar.

Ele disse a Gu Sijin: — Você não precisa voltar esta noite. Daqui a pouco mandarei chamar um médico imperial. Dormirá aqui, nos meus aposentos. Quero ver até onde essas mulheres do harém ainda são capazes de chegar!

Ser imperador não era necessariamente a maior sorte do mundo.

As pessoas achavam que Lu Linyuan nascera com a vida ganha: tinha uma imperatriz por mãe, fora nomeado príncipe herdeiro aos catorze anos e subira ao trono sem dificuldades aos vinte e um. Possuía incontáveis belas mulheres no harém e, com uma ordem, podia decidir a vida e a morte de qualquer pessoa sob o céu.

Mas só ele sabia que nada daquilo era o que realmente desejara.

Quando a atual imperatriz-viúva o dera à luz, tivera uma hemorragia grave e um parto difícil. Sobrevivera, mas perdera para sempre a capacidade de ter filhos.

Por isso depositara todas as suas esperanças e esforços naquele que era seu único filho.

Sua necessidade doentia de controle transformara toda a infância de Lu Linyuan numa existência sufocante.

Quando ele tinha apenas três anos, ela já o obrigava a frequentar a sala de estudos do palácio, vigiando diariamente suas recitações e recorrendo a tapas e insultos ao menor erro.

Mais velho, Lu Linyuan aprendera a resistir. Mas toda tentativa de resistência provocava na mãe acessos histéricos de choro.

Ela sempre dizia: — Sua mãe arriscou a vida para trazer você ao mundo. Por sua causa, nunca mais poderei dar outro herdeiro ao seu pai, e foi por isso que ele deixou de me favorecer. Se nem você se esforçar, como espera que sua mãe continue vivendo?

A imperatriz-viúva atribuía ao filho todas as desgraças da própria vida. Em termos modernos, Lu Linyuan sofrera desde pequeno uma verdadeira manipulação psicológica por parte da própria mãe — aquilo que hoje se chama de PUA.

Só depois de tornar-se imperador é que conseguiu se rebelar pela primeira vez.

Todas as mulheres de seu harém haviam sido escolhidas pela imperatriz-viúva.

Era por isso que, durante todos aqueles anos, ele não tocara em nenhuma delas.

Com os próprios atos, queria mostrar à mãe que já não era o boneco de fios que ela podia manipular à vontade.

E, naturalmente, observara tudo o que aquelas mulheres do harém vinham fazendo ao longo dos anos.

Aquilo lhe causava uma repulsa profunda, e ele se sentia aliviado por jamais ter tido qualquer envolvimento íntimo com elas.

---

## Notas editoriais

- Conservei as categorias de harém Respondente (答應), Atendente (常在), Consorte Li (麗妃) e Consorte Nobre (貴妃).
- A expressão PUA aparece no original como referência moderna a manipulação psicológica; não é um diagnóstico clínico.
- A expressão 跳槽 no contexto da dança parece um lapso gráfico por 跳操; foi traduzida como 'escapar da ginástica'.
- O capítulo revela abuso emocional materno na infância de Lu Linyuan sem atribuir a Ning Xiaoxiao a percepção que pertence ao narrador.

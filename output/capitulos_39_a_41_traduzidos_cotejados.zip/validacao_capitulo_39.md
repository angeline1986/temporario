# Conferência do capítulo 39

Fonte primária: `novel_capitulos_1_a_60(20261103-131325).docx`, capítulo 39 até antes do título do capítulo 40.

## Correspondência estrutural

- Unidades chinesas, incluindo título: 74.
- Unidades portuguesas: 74.
- Correspondência ordenada: 74/74.
- Células vazias: zero.

## Revisão e observações

Tradução redigida diretamente das unidades do chinês tradicional, respeitando o encadeamento narrativo, diálogos, gênero, contagens e mudanças de focalização.

- Conservei as categorias de harém Respondente (答應), Atendente (常在), Consorte Li (麗妃) e Consorte Nobre (貴妃).
- A expressão PUA aparece no original como referência moderna a manipulação psicológica; não é um diagnóstico clínico.
- A expressão 跳槽 no contexto da dança parece um lapso gráfico por 跳操; foi traduzida como 'escapar da ginástica'.
- O capítulo revela abuso emocional materno na infância de Lu Linyuan sem atribuir a Ning Xiaoxiao a percepção que pertence ao narrador.

## Limitações

A correspondência foi conferida programaticamente e o conteúdo revisado na tradução. Não houve uma segunda auditoria semântica independente, nem certificação de equivalência absoluta. O cotejo permite revisão posterior de cada parágrafo.

**Estado:** tradução revisada, cotejo estrutural completo, segunda auditoria linguística pendente.

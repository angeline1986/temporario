# Capítulo 40 — Que horror! O tirano é de Virgem?

Depois de acomodar Gu Sijin, Lu Linyuan levou Ning Xiaoxiao ao escritório, como de costume.

Naquele dia, enquanto lia os memoriais, ela percebeu claramente que ele estava distraído.

O imperador mantinha os olhos apagados, fixos num mesmo ponto, sem sequer piscar.

Seu rosto não revelava qualquer mudança de expressão, mas alguém tão empática quanto Ning Xiaoxiao conseguia sentir com facilidade a tristeza que o dominava.

Ning Xiaoxiao deu uma olhada nos próximos acontecimentos do livro e encontrou longos trechos descrevendo os pensamentos de Lu Linyuan.

Ela crescera numa família feliz e harmoniosa. Nunca soubera que tipo de cicatriz psicológica carregava alguém criado sob tamanha opressão.

Talvez aquela fosse uma das razões pelas quais ele se tornaria um tirano no futuro.

Quando vivia no mundo moderno, Ning Xiaoxiao era a animadora da turma.

Fazia parte da natureza de uma sagitariana não deixar o clima morrer em lugar nenhum.

Por mais triste que alguém estivesse, ela sempre encontrava um jeito de fazê-lo sorrir.

Então perguntou, com cautela: — Majestade, no que está pensando?

Lu Linyuan foi arrancado dos pensamentos. Lançou-lhe um olhar e respondeu casualmente: — Estou pensando que tipo de pervertido seria capaz de correr pelado pelo palácio.

Ning Xiaoxiao: — ...

*Você nunca vai superar essa história, não é?*

A chuva da tarde havia lavado o céu.

Naquela noite, o firmamento azul-escuro estava salpicado de estrelas, belo como uma pintura.

Ning Xiaoxiao apoiou o queixo nas mãos e ficou contemplando o céu, completamente absorta.

Quando voltou a si, descobriu que o tirano estava sentado a seu lado havia não se sabia quanto tempo, também admirando o mar de estrelas.

Só então se lembrou de que, na obra original, Lu Linyuan gostava muito de observar estrelas.

Ele chegara até a construir um Pavilhão das Estrelas dentro do palácio.

No livro, ele também levara Gu Sijin para vê-las.

Fora numa noite como aquela, com o céu repleto de estrelas que pareciam diamantes espalhados. Depois de admirá-las, os dois ainda haviam travado um certo «combate ao ar livre».

Só de pensar nisso, Ning Xiaoxiao estremeceu.

Mas mal terminara o arrepio quando ouviu a voz do imperador, que lhe soou desconcertante: — Vou levar você a um lugar.

— Hã?

— Ao Pavilhão das Estrelas.

Ning Xiaoxiao: — !!!

【Nem pensar! Eu não vou! Não quero fazer esse «combate ao ar livre» com você!】

Lu Linyuan não fazia ideia do que seria aquela batalha ao ar livre.

Só sabia que Ning Xiaoxiao não queria ir com ele.

E, quanto menos ela quisesse, mais ele faria questão de obrigá-la!

Assim, depois de ouvir os pensamentos dela, nem esperou que abrisse a boca para recusar: agarrou-a e saiu arrastando-a.

***

O Pavilhão das Estrelas era uma construção isolada atrás do Palácio Chaoyang. Não era muito alto: tinha apenas três andares.

Sua vantagem era a vista ampla, sem nada obstruindo a paisagem.

Só que, para alguém com um caso terminal de preguiça como Ning Xiaoxiao, ser impedida de dormir àquela hora para passar a noite inteira olhando estrelas era pior que fazer uma série de ginástica ao som de «Compêndio de Matéria Médica» ao lado de Gu Sijin.

Infelizmente, Lu Linyuan estava animadíssimo e insistiu em levá-la.

Quando chegaram, sentaram-se numa plataforma elevada do lado de fora. Como não tinham muito assunto em comum, acabaram erguendo a cabeça para o céu ao mesmo tempo.

Curiosa para saber no que Lu Linyuan pensava, Ning Xiaoxiao espiou às escondidas o texto da história.

Naquele instante, a mente dele estava tomada por lembranças da infância: incontáveis episódios em que fora castigado pela imperatriz-viúva, insultado pelo imperador e maltratado pelos irmãos.

Só de ler as descrições, ela já se sentia oprimida, como se lhe faltasse o ar.

Imagine então como deveria ser para Lu Linyuan, que havia vivido tudo aquilo na própria pele.

Era a primeira vez que Ning Xiaoxiao achava verdadeiramente cruel o autor ter dado a ele um passado assim e ainda lhe reservado um final trágico.

Querendo mudar de assunto para ajudá-lo a esquecer as preocupações, apontou para as estrelas e perguntou:

— Majestade, sabe o que é um signo do zodíaco?

Lu Linyuan balançou a cabeça. — O que seria isso?

— É algo relacionado a essas estrelas. Olhe só!

Ning Xiaoxiao desenhou no ar com o dedo, ligando imaginariamente algumas estrelas. — Está vendo, Majestade? Essas que estou ligando com uma linha formam a constelação do meu signo!

Lu Linyuan soltou uma risada fria. — Tudo o que vejo é você gesticulando feito uma bêbada.

— Ah, Majestade, não estou brincando! Todo mundo tem um signo. Nasci em 28 de novembro, então esse desenho é o da minha constelação.

Ning Xiaoxiao tornou a desenhá-lo. — Olhe: não parece uma criatura metade homem, metade cavalo, segurando um arco e flechas?

Dessa vez, Lu Linyuan observou com mais atenção.

Seguindo os gestos de Ning Xiaoxiao, pareceu realmente distinguir a figura. — De fato... há alguma semelhança.

— Viu só? — sorriu ela. — É Sagitário, símbolo de liberdade e otimismo.

Lu Linyuan hesitou e lançou um olhar involuntário para a sua «pequena dama do polegar».

— Atirar aonde?

Ning Xiaoxiao: — ... Não é esse tipo de «atirar»! É um arqueiro, alguém que usa arco e flecha!

— Ah...

Ning Xiaoxiao deu de ombros, desconsolada, e voltou a desenhar no ar. — O aniversário de Vossa Majestade é em 16 de setembro. Esta aqui é a figura do seu signo. As pessoas desse signo costumam ser perfeccionistas, assim como o senhor.

A segunda parte do pensamento ficou guardada para si:

Lu Linyuan, com aquela obsessão extrema por limpeza, combinava quase cem por cento com o signo de «Virgem».

Mas acrescentou: — Esse signo se chama Virgem.

Lu Linyuan: — ???

Seu rosto fechou e ele franziu as sobrancelhas. — Quem você está chamando de virgem?

— É o nome do signo! Não fui eu que disse que Vossa Majestade é virgem!

【E qual é o problema? No máximo, você é um homem virgem!】

Lu Linyuan: — ...

*E daí se sou virgem?*

*Isso é motivo de vergonha?*

Ele estava prestes a perder a paciência quando Ning Xiaoxiao lhe perguntou, de repente, com toda a seriedade:

— Acabei de falar das qualidades do seu signo. Sabe quais são os defeitos?

Lu Linyuan respondeu friamente: — Não tenho o menor interesse.

Ning Xiaoxiao fez ouvidos moucos e continuou:

— Entre os doze signos, o seu é o mais rigoroso e disciplinado. As pessoas desse signo costumam se examinar e se criticar o tempo todo. Por isso podem parecer frias e distantes.

— Mas, no fundo, elas também desejam muito ser felizes.

Quanto mais a ouvia, mais impaciente Lu Linyuan ficava. Por fim, interrompeu-a:

— Não tenho interesse nessas suas bobagens. Se você...

— O que quero dizer é que meu signo complementa perfeitamente o de Vossa Majestade. Então, se algum dia o senhor estiver triste, pode muito bem conversar comigo!

— Conversar com você? Hmph... — Lu Linyuan recusou, gelado. — Nunca tive motivo para ficar triste. E, mesmo que tivesse, não lhe contaria.

— Ah... — Ning Xiaoxiao não quis perder mais tempo com aquele cabeçudo mais teimoso que um pato. Voltou a admirar as estrelas, sem lhe dirigir a palavra.

Mas Lu Linyuan a observava discretamente pelo canto dos olhos.

Diante da pele delicada da jovem iluminada pelo luar e de seus traços pequenos e harmoniosos,

por um instante ele teve a impressão de que o próprio coração batera um pouquinho mais depressa.

(Nota da autora: todos os caracteres trocados neste capítulo foram usados para evitar uma visitinha à «salinha escura» da censura. Meus amores, corrijam mentalmente, tá? Amo vocês!)

---

## Notas editoriais

- O signo 楚女座 é grafia deliberadamente alterada de 處女座 (Virgem), confirmada pela nota da autora sobre contornar a censura. No português, o duplo sentido de 'Virgem' sustenta a cena.
- 射 em 射手座 (Sagitário) também permite alusão sexual, conservada na reação 'Atirar aonde?' e na distinção de um arqueiro.
- 野外格鬥 ('combate ao ar livre') funciona como eufemismo insinuante da narração; mantido entre aspas.
- A canção 本草綱目 é referida no contexto de exercícios e mantida como título traduzido, não como instrução médica.

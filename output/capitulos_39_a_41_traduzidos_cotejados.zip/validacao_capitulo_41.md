# Conferência do capítulo 41

Fonte primária: `novel_capitulos_1_a_60(20261103-131325).docx`, capítulo 41 até antes do título do capítulo 42.

## Correspondência estrutural

- Unidades chinesas, incluindo título: 71.
- Unidades portuguesas: 71.
- Correspondência ordenada: 71/71.
- Células vazias: zero.

## Revisão e observações

Tradução redigida diretamente das unidades do chinês tradicional, respeitando o encadeamento narrativo, diálogos, gênero, contagens e mudanças de focalização.

- Os três episódios em que Lu Linyuan recolhe o manto para cobrir Ning Xiaoxiao foram mantidos; o relato invertido dela é uma mentira consciente, não discrepância narrativa.
- O imperador primeiro ordena suspender os pagamentos por seis meses e depois revoga a ordem. Ambas as decisões estão preservadas.
- Os postos Respondente e Atendente são distintos: Gu Sijin é promovida para viabilizar sua presença no banquete.
- 西涼 (Xiliang), 沙門關 (passagem de Shamen), 啟朝 (dinastia Qi) mantidos como topônimos e denominação dinástica, sujeitos a padronização do glossário anterior.

## Limitações

A correspondência foi conferida programaticamente e o conteúdo revisado na tradução. Não houve uma segunda auditoria semântica independente, nem certificação de equivalência absoluta. O cotejo permite revisão posterior de cada parágrafo.

**Estado:** tradução revisada, cotejo estrutural completo, segunda auditoria linguística pendente.

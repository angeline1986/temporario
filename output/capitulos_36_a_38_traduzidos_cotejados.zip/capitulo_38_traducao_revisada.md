# Capítulo 38 — Ontem, sem nada a esconder; hoje, estamos quites

Enquanto atravessava o bosque de bambus roxos, Lu Linyuan ouviu, a alguma distância, o farfalhar de passos sobre as folhas de bambu caídas.

Todos os bambus daquele bosque eram da variedade «escamas de dragão», espécimes de excelente qualidade.

Por serem caríssimos, já acontecera de servos do palácio roubarem bambus para vendê-los fora dos muros.

Desde então, Lu Linyuan decretara que o bosque de bambus roxos seria uma área proibida, onde os servos não poderiam entrar sem autorização.

Naquele dia, queria ver quem ousava desobedecer ao decreto imperial e cometer um ato tão grave que poderia custar a própria cabeça.

Seguiu o som e, quando se aproximou, viu uma figura familiar.

*Ning Xiaoxiao??*

*O que ela veio fazer aqui?*

*Espere...*

Como os seios tamanho D de Ning Xiaoxiao costumavam chamar tanta atenção, a redução repentina naquele dia saltava ainda mais aos olhos.

Lu Linyuan ficou parado observando por um instante. Lembrou-se da provocação que fizera na noite anterior e mergulhou em reflexão:

*Será que... aquelas coisas podem mesmo ser achatadas de tanto bater?*

Ning Xiaoxiao achava que já tinha corrido tão fundo para dentro do bosque que ninguém viria atrás dela.

Por isso, desabotoou a roupa sem receio, levou as mãos às costas e procurou às cegas o nó da faixa que a apertava.

Foi nesse exato momento que Lu Linyuan apareceu de repente, assustando-a a ponto de quase fazer sua alma abandonar o corpo.

— O que está fazendo aqui?

Como se a situação já não fosse azarada o bastante, assim que Lu Linyuan terminou de falar, Ning Xiaoxiao conseguiu desatar o nó da faixa.

Livre da amarração, a faixa se soltou imediatamente, e seus dois seios tamanho D «desabrocharam» diante dela.

Como gelatina, macios, elásticos e saltitantes, ainda balançaram duas vezes.

Havia cinco metros entre os dois. Lu Linyuan fitava aquela «gelatina gigante», enquanto Ning Xiaoxiao fitava os olhos dele, arregalados como sinos de bronze.

Três segundos depois, os dois soltaram um grito em perfeita sincronia:

— Aaaaaah~~~~~!

Ning Xiaoxiao levou as mãos à frente dos seios. Mas, antes que pudesse dizer alguma coisa, Lu Linyuan explodiu primeiro:

— Ning Xiaoxiao! Você perdeu o juízo?! Este bosque de bambus roxos é meu, não é a sua casa! Como... como ousa fazer uma coisa tão indecente aqui?!

Estava furioso, como se tivesse visto algo tão horrível que lhe ferira os olhos.

Vermelha de vergonha, Ning Xiaoxiao foi se vestindo enquanto reclamava em silêncio:

【Seu velho tarado! Pra que fingir? Se achou tão indecente, por que não para de olhar? E por que está vermelho? Quem devia estar corada era eu, não você! Pare de bancar o garotinho inocente!】

A «visão sem disfarces» da véspera terminava, naquele dia, com os dois finalmente quites.

Ela tinha algo enorme; ele também. Melhor assim...

— Xiaoxiao~ Você está bem?

A voz de Gu Sijin se aproximava. Ela provavelmente ouvira o grito e, preocupada com Ning Xiaoxiao, viera verificar o que acontecera.

*Não pode ser! Se Gu Sijin me encontrar aqui com o tirano agora, vai acabar imaginando alguma coisa.*

*Se a protagonista passar a me ver como inimiga, sobreviver aqui vai ficar muito mais difícil.*

Ning Xiaoxiao estava prestes a pedir a Lu Linyuan que se escondesse. Antes que abrisse a boca, porém, viu-o escapulir como um coelhinho assustado.

Para evitar as poças de lama, ele corria aos pulinhos, ora para a esquerda, ora para a direita.

E ainda...

*...ficou até fofinho??*

Mal suas costas desapareceram de vista, Gu Sijin chegou.

— Xiaoxiao? O que houve? Acho que ouvi você gritar.

Gu Sijin olhou para os lados, procurando alguma coisa. — Acho que... também ouvi uma voz masculina?

Ning Xiaoxiao se apressou: — Não tinha homem nenhum! Esta serva... esta serva viu uma cobra! Levei um susto e gritei!

— Ah! Uma cobra? — Gu Sijin tinha pavor de cobras. Agarrou a mão de Ning Xiaoxiao e saiu correndo do bosque de bambus roxos.

De volta ao palácio, Ning Xiaoxiao deitou-se em sua cama e começou a se remoer.

【Eu sou uma anta!】

A ficha caiu atrasada. Ela se sentou de um salto e começou a bater nas coxas, furiosa:

【Por que sempre esqueço que tenho uma vantagem especial justo na hora em que preciso dela?!】

【Quando aquele imperador maldito me viu, eu podia ter apertado Retroceder, e nada disso teria acontecido!】

【Agora pronto! Passei a maior vergonha da minha vida! Aaaaaaaah!】

Ela ficou tendo um chilique sozinha no quarto das criadas. À tarde, quando suas roupas finalmente secaram, trocou-se imediatamente, lavou o uniforme de Qiaqia e o devolveu.

Quando terminou, nuvens escuras começaram a cobrir o céu. Tudo indicava que outro temporal estava prestes a cair.

*

Naquele momento, Gu Sijin e Cailian caminhavam em direção ao palácio da imperatriz.

Embora a imperatriz tivesse dispensado as consortes dos cuidados durante a doença, Gu Sijin não conseguia deixar de se preocupar. Pensou que, mesmo de longe, seria bom vê-la e confirmar que estava bem.

Mas, no meio do caminho, percebeu a mudança repentina no tempo e decidiu que era melhor voltar primeiro.

No trajeto, encontraram a Atendente Xiao.

Ela entrara no palácio na mesma seleção que Gu Sijin. Como recebera o título de Atendente logo ao chegar, as senhoras dos vários palácios acreditavam que se destacaria entre as recém-chegadas e, no início, fizeram de tudo para conquistar sua simpatia.

Mas já havia passado mais de um mês desde a entrada delas no palácio. Quem conquistara a atenção do imperador fora Gu Sijin; Xiao nem sequer recebera uma visita imperial.

Vendo que ela não servia para nada, as consortes que antes lhe haviam estendido a mão passaram a tratá-la como algo descartável.

Era natural que Xiao guardasse ressentimento.

Por isso, ao cruzar com Gu Sijin naquele dia, não fez a menor questão de disfarçar o desprezo.

Ao passar ao lado dela, insultou-a deliberadamente: — Essas sedutoras sabem mesmo usar todo tipo de truque. Tal mãe, tal filha.

Gu Sijin ouviu com clareza. A mão que segurava o lenço se fechou um pouco mais.

Ela não pretendia discutir com a Atendente Xiao, mas Cailian não conseguiu engolir a provocação e retrucou na hora:

— Atendente Xiao, o que foi que a senhora disse?

Xiao soltou um riso de escárnio: — Falei tão alto e você não ouviu? Ou vocês duas, senhora e criada, são tão descaradas que precisam ouvir duas vezes uma ofensa para se sentirem satisfeitas?

Ela pigarreou e repetiu deliberadamente: — Eu disse que essas sedutoras têm truques de sobra. Tal mãe, tal filha!

Cailian: — Você...!

Quando Cailian avançou para discutir, Gu Sijin a segurou.

Quanto menos problemas, melhor. Ela não queria criar confusão no harém imperial.

Mas a Atendente Xiao não se deu por satisfeita: — Estou mentindo? Já ouvia falar dos escândalos da família Gu quando ainda vivia em casa. Sua mãe não passava de uma criada que lavava os pés do seu pai. Depois, sabe-se lá como, de tanto servi-lo, conseguiu subir à cama do patrão e virou concubina.

— Mais tarde, a esposa principal morreu num parto difícil, e sua mãe tomou o lugar dela. E você ainda tem coragem de sair por aí dizendo que é filha da esposa legítima? Uma diabinha nascida de uma sedutora sem-vergonha como ela? Quem você pensa que é?!

Antes, Gu Sijin parecia tímida e receosa de problemas. Mas, ao ouvir Xiao humilhar sua mãe daquele jeito, começou imediatamente a discutir:

— Não fale assim da minha mãe! Minha mãe não é esse tipo de pessoa! Não admito que fale dela desse jeito!

A Atendente Xiao zombou: — Não é esse tipo de pessoa? Então é que tipo? Ora, se você não quer que eu diga, vou dizer justamente por isso.

Ela se aproximou de Gu Sijin e pronunciou cada palavra com firmeza: — Sua mãe é uma vagabunda sem nenhuma vergonha na cara!

Cailian empurrou Xiao para longe e protestou, indignada: — Atendente Xiao, não vá longe demais!

— E quem é você para ousar me pôr as mãos? Eu sou Atendente e ela não passa de uma Respondente. Agora nem falar dela eu posso?

Como se tivesse ouvido a coisa mais ridícula do mundo, Cailian soltou um riso frio: — A Atendente Xiao realmente acha que o respeito dentro deste palácio depende apenas do título? A senhora entrou há um mês; minha senhora também. Minha senhora já foi chamada três vezes para servir o imperador. E a senhora? Sua Majestade sequer se lembra de quem você é?

A cada frase, Cailian ficava mais atrevida, como se fosse ela própria a senhora de posição superior:

— Quem não recebe o favor imperial não vale nada!

---

## Notas de tradução

- LSP é gíria de internet chinesa para um tarado ou velho pervertido; vertida como «velho tarado».
- 果動 remete à textura tremelicante de gelatina; conservou-se a comparação cômica.
- «Tal mãe, tal filha» adapta 上梁不正下梁歪, imagem proverbial de vigas tortas que produzem estrutura torta.
- 答應 (Respondente) e 常在 (Atendente) são títulos hierárquicos distintos.
- O capítulo termina com a fala arrogante de Cailian, sem antecipar as consequências do capítulo 39.

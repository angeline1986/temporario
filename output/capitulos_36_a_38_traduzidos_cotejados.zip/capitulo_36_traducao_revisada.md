# Capítulo 36 — O tirano rouba o chá com leite dela

A coisa mais constrangedora do mundo não é um homem e uma mulher acabarem se vendo completamente nus sem estar preparados para isso.

É você estar pelado da cabeça aos pés, enquanto a outra pessoa está inteiramente vestida — e ainda olha para o seu... aquilo e engole em seco.

O rubor nas faces de Lu Linyuan se espalhou como nuvens incendiadas pelo pôr do sol, descendo pelo pescoço e pelo peito.

Quem visse aquela cena sem saber de nada provavelmente acharia que ele tinha tomado banho com água fervente e acabado cozinhando a si mesmo.

Sentindo a intenção assassina no ar ficar cada vez mais intensa, Ning Xiaoxiao ergueu o biombo às pressas e escapuliu para trás dele.

Ainda tentou se explicar, embora suas palavras soassem pateticamente pouco convincentes:

— Para falar a verdade, Majestade, esta serva nasceu com um problema nos olhos. Sofro de cegueira seletiva, por isso não vi absolutamente nada agora há pouco!

Lu Linyuan: — Cale a boca! Não quero ouvir sua voz!

Ning Xiaoxiao: — Ah... certo...

【Que grosso! Mas... será que o autor não tem noção das coisas? É mesmo razoável que ele seja tão grande? Não é à toa que consegue remexer os órgãos internos. É assustador a ponto de dar aflição...】

Nas cenas picantes do romance original, a extraordinária «dotação» de Lu Linyuan havia sido descrita com uma riqueza impressionante de detalhes.

Ning Xiaoxiao até reclamara que o autor insistia em equipar o homem com um negócio do tamanho do de um touro.

Agora que vira com os próprios olhos, só lhe restava admitir que o autor evidentemente conhecia muito mais do mundo do que ela. Quem tinha horizontes limitados era ela!

Ao imaginar Gu Sijin tendo de enfrentar aquele objeto descomunal no futuro, Ning Xiaoxiao estremeceu, quase sentindo a dor por antecipação.

Lu Linyuan nunca tinha visto a intimidade de outro homem. Desde pequeno, acreditava que, à parte a própria beleza, não havia nada de diferente nele.

Ao ouvir Ning Xiaoxiao elogiá-lo secretamente, sentiu uma pontinha de satisfação, acompanhada de certa perplexidade:

*Grande?*

*Mas não é assim com todo mundo?*

Terminou de vestir a roupa de dormir e saiu de trás do biombo.

Temendo que o tirano decidisse matá-la para impedir que espalhasse o que vira, Ning Xiaoxiao se adiantou: — Bem... já que Vossa Majestade terminou o banho e não precisa de mais nada, esta serva vai se retirar~

— Fique onde está.

Lu Linyuan a deteve: — Você ainda não fez o que veio fazer.

Evidentemente, ele também não queria mencionar o episódio humilhante. Mudou de assunto sem demora e mandou Ning Xiaoxiao acompanhá-lo ao escritório para ler os memoriais.

Recostou-se preguiçosamente na cadeira de encosto alto, parecendo descansar de olhos fechados.

Na verdade, estava mais ocupado do que qualquer outra pessoa.

Com um ouvido, precisava escutar Ning Xiaoxiao ler os memoriais; com o outro, os pensamentos dela. Não tinha um instante de sossego.

Só que, naquele dia, ela mal pensava em assuntos de Estado.

*Parece que ela não para de cobiçar... a minha cabeça?*

【Ah... que vontade de tomar chá com leite! Se eu chegar perto e arrancar um punhado do cabelo dele, será que ele me mata?】

Ela lançou um olhar fingidamente casual a Lu Linyuan. A expressão era a de quem avaliava uma presa!

O couro cabeludo do imperador se contraiu sem motivo aparente.

*Experimente fazer isso e verá se eu não raspo sua cabeça e a mando para um convento de monjas!*

【Não, não! Não vale a pena perder a vida por um copo de chá com leite... E se eu o obrigar a passar a noite acordado?】

【Isso! Virar a noite faz o cabelo cair!】

【Afinal, como sempre, ele não vai dormir enquanto eu não terminar de ler os memoriais.】

Ning Xiaoxiao observou a pilha de memoriais alta como uma montanha sobre a mesa e fez as contas mentalmente:

【Se eu ler devagar, gastando dez minutos por memorial, o sol já vai ter nascido quando terminar.】

【Ele me obriga a ler memoriais de vez em quando, então vou fazê-lo passar a noite em claro de vez em quando também! Daqui a algum tempo, a cabeça dele vai parecer uma árvore no outono: nem vai precisar ventar; depois de dois passos, todos os fios terão caído! E então poderei comprar o que quiser!】

Assim que traçou o plano, Ning Xiaoxiao reduziu a velocidade da leitura.

Incomodado com a lentidão dela, Lu Linyuan foi se deitar para cochilar.

A voz de Ning Xiaoxiao, lendo os memoriais naquele ritmo arrastado, parecia uma cantiga de ninar. Pouco depois, a respiração de Lu Linyuan ficou mais profunda.

— Majestade? Majestade?

Ela o chamou duas vezes, experimentalmente. Sem resposta. Devia ter adormecido.

Já que mantê-lo acordado não funcionara, que tal aproveitar o sono para procurar dois fios de cabelo no travesseiro?

Pensado e feito!

Dessa vez, porém, ela não montou em cima de Lu Linyuan: tinha medo de ser «mordida» pela cobra enorme dele...

Felizmente, o escritório estava bem iluminado, e logo ela conseguiu recolher dois fios de cabelo.

*O suficiente para pagar um chá com leite!*

Então abriu mentalmente a loja de conveniência e se preparou para comprar uma bebida daquelas para saborear.

Mal sabia ela que Lu Linyuan estava apenas fingindo dormir.

E a razão para a encenação era muito simples:

*Que diabos é esse tal chá com leite para ela pensar tanto nele?*

*Eu também quero experimentar!*

Depois que Ning Xiaoxiao pagou com dois fios de cabelo do tirano, um brilho azul cintilou por um instante na palma de sua mão. De repente, apareceu ali um copo de chá com leite!

E era justamente seu favorito: chá com leite, purê de taro e bolinhas mastigáveis!

Só que a loja lhe dera o copo lacrado com plástico, sem canudo!

*Avaliação negativa!*

Ning Xiaoxiao arrancou o lacre. O aroma encorpado da bebida chegou às suas narinas, e ela ficou tão empolgada que suas mãozinhas chegaram a tremer.

Quando estava prestes a tomar o primeiro gole, a voz do tirano soou às suas costas:

— O que está fazendo aí parada?

Ning Xiaoxiao: 【Caramba! Como foi que ele acordou?】

De costas para Lu Linyuan, escondeu apressadamente o chá com leite atrás da cortina da janela.

— N-nada... Majestade, quer que eu continue lendo os memoriais?

【Deixe-me continuar embalando seu sono! Durma logo! Virar a noite pode até matar!】

Lu Linyuan bocejou e disse preguiçosamente: — Não precisa mais ler. Estou com sono. Pelas minhas contas, sua senhora já está fazendo exercícios há quase dois *shichen*. Vá chamá-la e voltem juntas ao palácio.

— Hã? — Ning Xiaoxiao ficou sem reação. — Majestade... esta serva acha que minha senhora... talvez ainda aguente se exercitar mais um pouquinho?

Lu Linyuan: — Se gosta tanto de exercícios, que os faça no próprio palácio. Eu vou descansar.

— Ah... — Ning Xiaoxiao olhou com saudade para o chá com leite. Seus pés pareciam cheios de chumbo; não conseguia dar um passo.

Lu Linyuan a apressou: — Ainda não foi? Está esperando que eu mande alguém «convidá-la» a sair?

Ning Xiaoxiao conhecia bem o temperamento do tirano. Se não saísse, ele realmente mandaria guardas agarrá-la pelos braços e pelas pernas e jogá-la para fora...

*Meu querido chá com leite! Adeus!!!*

Ela deixou o escritório quase chorando e, em pensamento, amaldiçoou Lu Linyuan e dezoito gerações de seus antepassados:

【Imperador fedorento! Imperador maldito! Imperador imprestável! Um dia vou arrancar todo o seu cabelo e transformá-lo num abutre careca, sem uma pena sequer!】

Ao sair do escritório imperial, cerrou os punhos e começou a esmurrar o próprio peito, num acesso de frustração diante da porta.

Esquecera-se de fechá-la. Quando Lu Linyuan foi fazer isso, viu-a descontando a raiva nos próprios seios, tamanho D, e zombou:

— Pare de bater. Se continuar, eles vão acabar ficando achatados.

Ning Xiaoxiao, vermelha de vergonha e raiva, cobriu o rosto e fugiu.

Depois de voltar ao escritório, Lu Linyuan caminhou diretamente até a janela com assento aquecido e treliça, ergueu a cortina e pegou o copo de chá com leite, purê de taro e bolinhas.

Examinou a bebida por alguns instantes e aproximou o nariz para cheirá-la.

*O cheiro é esquisito, e a cor também não parece grande coisa. Será que isso é mesmo gostoso?*

Decidido a experimentar, tomou um gole pequeno.

Não esperava que aquele único gole lhe abrisse as portas de um mundo inteiramente novo:

*Ora, ora... Que delícia!*

Depois de admirar o sabor em silêncio, virou o copo e bebeu tudo de uma vez...

---

## Notas de tradução

- A alusão sexual do original usa eufemismos e linguagem de internet; a tradução preserva o subentendido e o humor, sem apresentar as comparações como descrições objetivas.
- 芋泥波波奶茶: chá com leite com purê de taro e bolinhas mastigáveis.
- Dois fios de cabelo equivalem ao preço de uma bebida na loja de conveniência do sistema.
- A expressão 兩個大D é referência explícita ao tamanho dos seios da protagonista.

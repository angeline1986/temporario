# Relatório de conferência — Capítulo 37

## Fonte e delimitação

Original chinês tradicional: `novel_capitulos_1_a_60(20261103-131325).docx`. Delimitação: do cabeçalho do capítulo 37 até antes do cabeçalho do capítulo 38.

## Conferência estrutural

- Unidades chinesas não vazias, incluindo título: **66**.
- Unidades traduzidas em ordem: **66**.
- Correspondência de unidades: **66/66**.
- Ausências formais e células vazias no CSV: **0**.

## Revisão semântica e editorial

Tradução redigida diretamente a partir das unidades chinesas, comparando os sujeitos, falas, ações e fatos na elaboração. Foram preservados os marcadores 【 】 para pensamentos audíveis pelo imperador, quando presentes. A obra usa comicidade sexual e gírias modernas: a adaptação buscou manter o registro sem inventar ações.

### Observações

- 兩個時辰: aproximadamente quatro horas, pois um shichen equivale a cerca de duas horas; a unidade foi preservada.
- 顧答應: Gu Sijin é tratada pelo título de Respondente, posto inferior ao de Atendente (常在).
- 凶 no diálogo é grafia substitutiva informal de 胸, seios.
- O ressentimento da imperatriz-viúva por mulheres de seios grandes decorre da história da Consorte Xi e do antigo imperador, conforme o texto ficcional.

## Limites da verificação

O alinhamento de 66 linhas foi conferido programaticamente. A tradução recebeu revisão editorial durante a elaboração, mas **não foi submetida a uma segunda auditoria bilíngue independente**. A correspondência estrutural não prova que toda nuance esteja livre de erro. Não há trecho assinalado como intraduzível; eventuais decisões interpretativas estão registradas nas notas.

**Status: tradução revisada com cotejo estrutural completo; auditoria independente pendente.**

# Capítulo 37 — Se ter seios grandes fosse crime, ela pegaria prisão perpétua

Naquela noite, depois de voltar ao Palácio Zhongcui, Ning Xiaoxiao se deitou e derramou lágrimas de arrependimento.

*Como sou burra!*

*Bem na hora H, sempre esqueço que tenho uma vantagem especial!*

*Eu podia simplesmente ter pausado o tempo, bebido meu chá com leite e jogado o copo fora!*

*Por que não pensei nisso antes?*

*Mas talvez ainda dê tempo. Afinal, Lu Linyuan nem sabe que escondi um chá com leite naquele lugar.*

Ela enxugou as lágrimas, apertou Pausar e correu a toda velocidade de volta ao escritório do Palácio Chaoyang.

Assim que entrou, ficou boquiaberta.

Lu Linyuan estava congelado numa posição completamente absurda.

Sentado junto à janela aquecida, usava uma colherinha para pescar as bolinhas de taro e as pérolas que restavam no fundo do copo de chá com leite...

— V-v-você! Sua mãe nunca ensinou que não se deve sair comendo qualquer coisa que encontra por aí? E se estivesse envenenado?!

Mas, como ele já tinha bebido tudo, não adiantava reclamar.

Ning Xiaoxiao arrancou grosseiramente a colher das mãos do tirano e, enquanto comia as bolinhas de taro e as pérolas, xingava-o por jogar sujo.

...

Embora a chuva tivesse parado quando ela e Gu Sijin voltaram ao palácio naquela noite, o chão ficara especialmente lamacento depois do temporal.

A saia e a roupa de Ning Xiaoxiao estavam salpicadas de barro, por isso ela aproveitou para lavá-las antes de dormir.

As criadas tinham dois conjuntos de uniforme, para alternar durante as lavagens. Mas, na manhã seguinte, quando Ning Xiaoxiao abriu o armário, não encontrou o conjunto reserva.

Depois de perguntar a todo mundo, descobriu que Qiqi o confundira com roupa suja e o lavara junto com as outras peças.

Qiqi agira por boa vontade; Ning Xiaoxiao não a culpou.

Mas logo teria de acompanhar Gu Sijin numa visita de cortesia à imperatriz. Não podia aparecer de roupa de dormir, podia?

Enquanto ela tentava resolver o problema, Qiaqia passou pelas duas e perguntou: — O que foi? Por que essas caras preocupadas logo cedo?

Qiqi explicou: — Ontem lavei a roupa reserva da Xiaoxiao. E, como choveu quando ela voltou de acompanhar nossa senhora à noite, ela também lavou o conjunto que estava usando. Agora não tem uniforme para vestir...

Qiaqia sugeriu: — Xiaoxiao, por que não veste o meu por enquanto? Os uniformes são todos iguais, e meu conjunto reserva acabou de ser lavado. Está limpinho. Só que sou mais baixa que você, então talvez fique um pouco apertado.

Naquela situação, quem se importava com o tamanho? Bastava ter algo para vestir e não atrapalhar os compromissos.

Mas, depois de pôr o uniforme de Qiaqia, Ning Xiaoxiao descobriu que tamanho importava, sim — e muito!

A roupa de Qiaqia lhe apertava tanto o corpo que seus seios tamanho D pareciam prestes a virar tamanho E.

Qiqi e as outras brincaram: — Ter uma mulher como Xiaoxiao entre nós é motivo de orgulho para todas~

Em meio às risadas, chegou uma mensagem do Palácio Fengluan para Gu Sijin: a imperatriz estava indisposta naquele dia e dispensara as visitas de reverência de todos os seis palácios.

Gu Sijin perguntou, preocupada: — O que houve com Sua Majestade, a imperatriz? As consortes precisam ir cuidar dela?

— Choveu na segunda metade da noite, e a imperatriz se esqueceu de fechar a janela antes de dormir. Pegou uma corrente de ar. O médico imperial já a examinou, receitou remédios e, depois de tomá-los, ela adormeceu. A própria imperatriz mandou dizer que as consortes não precisam visitá-la. É muita gentileza de sua parte se preocupar.

A «ginástica» que Lu Linyuan impusera a Gu Sijin algumas vezes aparentemente estava dando resultado.

Na véspera, ela passara quase dois *shichen* fazendo exercícios, e naquela manhã sentia apenas um pouco de dor nas pernas e nos pés.

Os olhos de Ning Xiaoxiao brilharam: — Minha senhora, já que a imperatriz dispensou os cumprimentos, por que não dorme um pouco mais?

Se Gu Sijin dormisse, ela também poderia tirar um cochilo. Afinal, Lu Linyuan a fizera passar por tanta coisa na noite anterior que ela não descansara muito mais do que sua senhora.

Mas Gu Sijin sorriu e balançou a cabeça: — Não. Já estamos lavadas e arrumadas. Se não vamos ao palácio da imperatriz, podemos ir prestar nossos respeitos à imperatriz-viúva.

Ning Xiaoxiao: *... Ah, muito obrigada mesmo!*

Ela achava que visitar a imperatriz-viúva seria apenas uma formalidade para marcar presença. Mas, assim que entrou no Palácio Xianshou, todos — da própria imperatriz-viúva aos eunucos e criadas — voltaram os olhos para Ning Xiaoxiao.

Mais precisamente, para seus seios tamanho D.

Enquanto Gu Sijin conversava com a imperatriz-viúva, a senhora fixou o olhar no busto de Ning Xiaoxiao por algum tempo. Sua expressão se tornou cada vez mais sombria.

— Você. Aproxime-se.

Ning Xiaoxiao avançou, confusa. A imperatriz-viúva franziu o cenho e ordenou severamente: — Criada insolente! Ajoelhe-se!

Ning Xiaoxiao ficou sem entender nada, mas a senhora parecia tão furiosa que achou melhor se ajoelhar primeiro e perguntar depois.

Gu Sijin não percebera qualquer falta da parte de Ning Xiaoxiao. Por isso interveio: — Imperatriz-viúva, posso saber o que ela fez para despertar sua ira?

— Que criatura indecente! — A imperatriz-viúva lançou outro olhar feroz às curvas generosas da criada. — Gu, Atendente, você mantém ao seu lado uma criada tão provocadora e sem decoro e nem percebe?

Gu Sijin respondeu: — Imperatriz-viúva, Xiaoxiao nunca se comportou de maneira indecorosa. Pelo contrário, sempre me serviu com toda a dedicação. Ela...

— Os peitos dela estão quase saltando para fora da roupa! Vestir-se assim é pior do que andar nua! — interrompeu a imperatriz-viúva, fuzilando Ning Xiaoxiao com os olhos. — O quê? Pretende seduzir o imperador com esses métodos vulgares?

Ning Xiaoxiao: 【Socorro... Quem é que ia querer seduzir esse seu filho que parece ter os dias contados?! É culpa minha ser peituda? Só porque a senhora não tem, ninguém mais pode ter?】

A imperatriz-viúva detestava mulheres de busto avantajado.

O antigo imperador ficara completamente enfeitiçado pela Consorte Xi, do reinado anterior, em grande parte porque ela possuía dois verdadeiros «gigantes».

O antigo imperador chegara a dizer à imperatriz-viúva que o toque dos seios de Xi era maravilhoso: ele seria capaz de passar um ano inteiro brincando com eles.

Se a Consorte Xi não tivesse morrido jovem, vítima de tuberculose, talvez fosse ela quem estivesse hoje sentada no lugar da imperatriz-viúva.

Desde então, bastava ver uma mulher voluptuosa para a senhora ferver de raiva.

Lembrando-se dessa informação do romance original, Ning Xiaoxiao se apressou a explicar: — Imperatriz-viúva, por favor, acredite em mim! Esta serva não tem essa intenção...

Gu Sijin acrescentou: — Imperatriz-viúva, o uniforme de Xiaoxiao foi lavado e ainda não secou. Por isso, hoje ela precisou vestir o de outra criada. A roupa não serviu direito, e ela acabou ficando assim. Não foi de propósito; não havia outra saída...

— Não havia outra saída? Se não quisesse chamar atenção, encontraria alguma solução — retrucou a imperatriz-viúva, chamando Qingzhu, a aia que a acompanhava de perto.

— Qingzhu, leve-a daqui e enfaixe aqueles dois montes de carne no peito dela! Quero ver se existe neste mundo algum peito que não se possa apertar com faixas!

Qingzhu levou Ning Xiaoxiao embora e enrolou grosseiramente a faixa em torno de seu peito cinco ou seis vezes.

Mesmo quase sem conseguir respirar, Ning Xiaoxiao só conseguiu reduzir o busto de D para algo próximo de B. E, depois de se vestir, ainda parecia ter muito mais seios do que a imperatriz-viúva.

Ao vê-la, a imperatriz-viúva alegou estar com dor de cabeça e mandou Gu Sijin levar Ning Xiaoxiao embora imediatamente, ordenando que não ficasse mais aparecendo diante dela.

Ao sair do Palácio Xianshou com Gu Sijin, Ning Xiaoxiao mal conseguia respirar de tão apertada.

Gu Sijin perguntou, preocupadíssima: — Xiaoxiao, você está bem?

Vendo como Ning Xiaoxiao estava pálida, acrescentou às pressas: — Há um bosque de bambus roxos mais adiante. Vá lá e tire essas faixas! Se esperar até voltarmos ao palácio, a circulação do sangue pode ficar prejudicada, e isso vai acabar mal...

Ning Xiaoxiao agradeceu e disparou para dentro do bosque de bambus roxos.

O que ela jamais poderia imaginar era que...

...aquele bosque quase deserto ficava justamente no atalho por onde Lu Linyuan sempre passava quando ia prestar seus respeitos à imperatriz-viúva.

---

## Notas de tradução

- 兩個時辰: aproximadamente quatro horas, pois um shichen equivale a cerca de duas horas; a unidade foi preservada.
- 顧答應: Gu Sijin é tratada pelo título de Respondente, posto inferior ao de Atendente (常在).
- 凶 no diálogo é grafia substitutiva informal de 胸, seios.
- O ressentimento da imperatriz-viúva por mulheres de seios grandes decorre da história da Consorte Xi e do antigo imperador, conforme o texto ficcional.

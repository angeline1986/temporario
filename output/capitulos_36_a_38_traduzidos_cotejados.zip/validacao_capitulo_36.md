# Relatório de conferência — Capítulo 36

## Fonte e delimitação

Original chinês tradicional: `novel_capitulos_1_a_60(20261103-131325).docx`. Delimitação: do cabeçalho do capítulo 36 até antes do cabeçalho do capítulo 37.

## Conferência estrutural

- Unidades chinesas não vazias, incluindo título: **85**.
- Unidades traduzidas em ordem: **85**.
- Correspondência de unidades: **85/85**.
- Ausências formais e células vazias no CSV: **0**.

## Revisão semântica e editorial

Tradução redigida diretamente a partir das unidades chinesas, comparando os sujeitos, falas, ações e fatos na elaboração. Foram preservados os marcadores 【 】 para pensamentos audíveis pelo imperador, quando presentes. A obra usa comicidade sexual e gírias modernas: a adaptação buscou manter o registro sem inventar ações.

### Observações

- A alusão sexual do original usa eufemismos e linguagem de internet; a tradução preserva o subentendido e o humor, sem apresentar as comparações como descrições objetivas.
- 芋泥波波奶茶: chá com leite com purê de taro e bolinhas mastigáveis.
- Dois fios de cabelo equivalem ao preço de uma bebida na loja de conveniência do sistema.
- A expressão 兩個大D é referência explícita ao tamanho dos seios da protagonista.

## Limites da verificação

O alinhamento de 85 linhas foi conferido programaticamente. A tradução recebeu revisão editorial durante a elaboração, mas **não foi submetida a uma segunda auditoria bilíngue independente**. A correspondência estrutural não prova que toda nuance esteja livre de erro. Não há trecho assinalado como intraduzível; eventuais decisões interpretativas estão registradas nas notas.

**Status: tradução revisada com cotejo estrutural completo; auditoria independente pendente.**

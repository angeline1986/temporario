# Validação — Capítulo 211

- Fonte: `novel_capitulos_181_a_211(20261105-152744).docx` (chinês tradicional).
- Intervalo DOCX: parágrafos de índice base zero 1993 a 2063; 69 parágrafos não vazios, título e nota autoral incluídos.
- Cotejo: 69 linhas de dados com `indice_docx,original_chines,traducao_portugues`; índices únicos, sem lacunas em relação aos parágrafos não vazios da faixa.
- Tradução: cada parágrafo original tem correspondente textual em português; preservados pensamentos, transições, asterisco separador e nota final da autora.

## Decisões editoriais
- `21` foi mantido como eufemismo numérico do original para genitália/ereção, sem substituí-lo por palavra explícita. A cena descreve masturbação de Lu, observada por Ning enquanto invisível.
- A piada sobre `三十而立` (estabelecer-se aos trinta) foi adaptada para conservar os trinta anos e o comentário sobre coração aumentado.
- `本書完。（啊不是我開個玩笑...）` é brincadeira explícita da autora: não comprova fim da obra.
- A cena não confirma relação sexual entre os dois.

## Limitação
Cotejo estrutural 1:1 e revisão contextual realizados. Não houve uma auditoria semântica independente integral por um segundo tradutor.

# Capítulo 211 — Um espetáculo ao vivo. Seria desperdício não assistir.

Depois de concluir que Ning Xiaoxiao havia “fugido bem na hora H”, Lu Linyuan não saiu atrás dela.

Ela era livre. Tinha todo o direito de recusá-lo.

Lu Linyuan sentou-se à beira da cama, com as mãos repousando sobre as coxas e os braços relaxados. Seu semblante deixava transparecer certa tristeza.

Ning Xiaoxiao, sentada ao lado dele, achou que naquele instante ele parecia um lobão que havia perdido uma disputa por um osso para outros cachorros e, depois de voltar para casa encharcado pela chuva, nem sequer encontrara alguém para abrir a porta. Era a própria imagem da injustiça sofrida.

Mas, para sua surpresa, ele não descarregou nela a frustração por sua “fuga na hora H”.

Depois de ficar abatido por um breve momento, pareceu compreender alguma coisa de repente. Deu um tapinha na própria testa e murmurou, com a voz cheia de mágoa:

— Será que fui apressado demais e acabei assustando-a?

— ...

O coração de Ning Xiaoxiao se apertou. Depois daquela onda de ternura, foi tomada por uma sensação esmagadora de não merecer tamanha felicidade.

Ela não entendia o que havia feito para merecer um amor tão profundo de Lu Linyuan.

Ele era um imperador de tempos antigos, alguém que, em teoria, deveria encarnar todos os vícios do feudalismo. No entanto, quando se tratava de respeitar as mulheres e a pessoa que amava, superava de longe — cem, mil vezes — tantos homens modernos.

O mundo inteiro precisava se curvar à vontade dele. Ele, porém, fazia questão de respeitar a vontade dela em tudo.

Lu Linyuan já havia retornado ao mundo moderno com Ning Xiaoxiao por causa de um acidente inesperado.

E foi somente ao chegar lá que descobriu que o mundo de Ning Xiaoxiao adotava a monogamia — algo que, para as pessoas de sua época, seria absolutamente incompreensível.

Na Antiguidade, os homens ocupavam uma posição superior, e as mulheres, inferior.

Mesmo que um homem fosse tão imprestável quanto o lixo de um lixão, bastava ter umas moedas no bolso para conseguir esposa e concubinas com a maior facilidade.

Quanto a isso, Lu Linyuan nunca conseguira entender qual era, afinal, a vantagem de ter três esposas e quatro concubinas.

Por que uma mulher tinha de ser fiel a um único homem, mantendo o marido como centro de seu mundo, enquanto o sujeito podia, sem o menor constrangimento, reservar espaço no coração para tantas outras?

Eram todos seres humanos, ora! Por acaso o coração dos homens era maior que o das mulheres? Tinha tanto espaço assim, a ponto de comportar trinta pessoinhas enfileiradas ao chegar aos trinta anos?

— Coração aumentado é doença. E pode matar.

Ter uma multidão de esposas e concubinas talvez parecesse uma bênção aos olhos dos outros. Para Lu Linyuan, porém, aquilo só significava mulheres fazendo barulho.

Claro, com exceção de Ning Xiaoxiao, que falava mais do que todas elas juntas.

A maioria das mulheres de seu harém recebera títulos porque a situação política era instável, e ele precisava conquistar o apoio das famílias delas.

Seria justamente isso que atormentava Ning Xiaoxiao?

Embora ele não tivesse, na prática, qualquer relação íntima com as demais consortes, a simples presença delas continuaria sendo uma pedra no sapato, mesmo que Xiaoxiao se tornasse imperatriz algum dia.

A única saída era resolver o mais depressa possível todos os problemas da corte, dissolver o harém e manter apenas Xiaoxiao ao seu lado, como imperatriz.

Talvez só então tivesse, de verdade, a segurança necessária para dizer à mulher amada:

— Você é a única que eu desejo. Agora pode entregar-se inteiramente a mim, sem medo.

O amor se sustentava quando os dois eram capazes de oferecer segurança um ao outro. Por isso, após a decepção inicial, Lu Linyuan conseguiu recuperar o equilíbrio sem se conceder privilégio algum só por ser imperador.

Um amor arrancado à força, pela imposição do poder, era como aguardente misturada com água: só dava vontade de vomitar.

Bom, a teoria era muito bonita. Mas agora surgia um pequeno problema!

Ele baixou os olhos para seu “21”. A situação era urgente: a flecha já estava na corda e precisava ser disparada!

Depois de alguns instantes em silêncio, tomou uma atitude capaz de deixar espantadas quinhentas gerações da família de Ning Xiaoxiao.

Acendeu uma vela no quarto e retirou um rolo de papel escondido num compartimento do guarda-roupa.

Curiosa, Ning Xiaoxiao se aproximou para descobrir o que era. Quando ele desenrolou a pintura, a pessoa retratada era ninguém menos que ela mesma.

Então, bem diante dos olhos dela, Lu Linyuan usou seus dedos longos e belos, semelhantes a peças de jade esculpido, para proporcionar ao próprio “21” um contato bastante íntimo.

????????

Ning Xiaoxiao ficou de queixo caído!

Sua primeira reação foi virar as costas e ir embora. Mas, quando já estava chegando à porta, seus passos diminuíram involuntariamente.

Humm...

Uma oportunidade dessas não aparecia duas vezes na vida.

Ela hesitou por um segundo, só para constar, e então tomou sua decisão:

Já que era de graça, seria um desperdício não assistir!

Assim, sentou-se em frente a Lu Linyuan e passou a “observar” a cena com toda a atenção do mundo.

*

O pó da invisibilidade durava uma hora. Ning Xiaoxiao foi acompanhando o relógio mecânico para calcular o tempo. Lu Linyuan levou pouco mais de quarenta minutos para resolver seus assuntos particulares; depois, cheio de energia, voltou a se sentar no assento aquecido e a examinar memoriais, sem demonstrar a menor intenção de dormir.

Enquanto limpava o sangue que escorria de seu nariz, Ning Xiaoxiao pensou:

Se fosse embora de verdade naquele momento, talvez estivesse sendo um pouco “cruel” com Lu Linyuan.

Afinal, parecia que ele havia passado por algo ruim naquela noite, na câmara secreta. Ela devia ficar ao lado dele.

Assim como ele sempre permanecia ao lado dela quando alguma coisa acontecia.

Então ela vestiu as roupas, atravessou a parede e saiu. Recolheu um punhado de neve e fez um pequeno boneco. Quando o tempo da invisibilidade se esgotou e ela reapareceu, aproximou-se da janela de treliça do quarto e bateu de leve.

Lu Linyuan franziu a testa, achando que Sanfu resolvera inventar mais alguma confusão. Estava com a irritação entalada e precisava de alguém em quem descontá-la. Se o eunuco tivesse mesmo a ousadia de bater à janela no meio da noite, ganharia um belo tapa.

Mas, quando abriu a janela com raiva, viu Ning Xiaoxiao parada na neve, com um sorriso radiante no rosto.

À vista da expressão surpresa dele, Ning Xiaoxiao ergueu o bonequinho de neve que havia feito e o mostrou a Lu Linyuan.

— Majestade, olhe! Não ficou bonito?

Lu Linyuan: — ??? Você saiu daqui para fazer um boneco de neve?

— Saí! — Ning Xiaoxiao assentiu com vigor, fazendo-se de inocente. — Logo vamos para a residência das fontes termais, e lá nem neva. Quando voltarmos à capital, o inverno já terá acabado. Se eu quiser brincar na neve de novo, vou ter de esperar um ano inteiro.

Lu Linyuan ficou tão exasperado que não sabia se ria ou chorava. Arrancou-lhe o boneco das mãos, atirou-o na neve e, pela janela de treliça, puxou Ning Xiaoxiao para dentro num abraço.

As mãos dele estavam quentes. Esfregou-as para aquecê-las ainda mais e então as encostou nas palmas e nas bochechas dela. Havia uma leve repreensão em sua voz:

— Seu corpo não aguenta o frio, e mesmo assim você sai para brincar na neve?

— Ah, entendi. Majestade, não fique bravo. Da próxima vez, não vou fazer isso nunca mais~

Na verdade, Lu Linyuan estava muito feliz.

Feliz porque sua Xiaoxiao não o havia evitado nem ficado com medo dele por causa de sua pressa.

Ainda bem. Caso contrário, passaria a noite inteira acordado, preocupado com a maneira de explicar tudo a ela no dia seguinte.

No rosto, porém, continuou exibindo uma expressão gelada: — Vá lavar as mãos. Está na hora de dormir~

Naquela noite, Ning Xiaoxiao abraçou Lu Linyuan com ainda mais força do que costumava abraçar, no mundo moderno, aquele seu enorme e peludo “urso horroroso”.

A fina barreira que ainda existia entre eles finalmente se rasgou um pouco. Um raio de sol iluminou a abertura e aqueceu, ao mesmo tempo, os dois corações.

Fim do livro. (Ah, não! Estou brincando, hahahahaha~)

# Capítulo 160 — Majestade! Tem uma folha de cebolinha presa nos seus dentes!

A liteira imperial estava parada não muito longe do Palácio Zhongcui. Sanfu esperava o seu tirano no frio e na neve, segurando uma bolsa de água quente.

Ao ver Xiao Yinzi andando em círculos para se aquecer, entregou-lhe a bolsa. — Esquente-se e fique atento. Sua Majestade veio visitar a Nobre Dama Hua. Não vai sair de lá em menos de uma ou duas horas!

Xiao Yinzi olhou por cima do ombro de Sanfu, constrangido. — Desta vez foi diferente. Não levou nem quinze minutos para sair...

Sanfu se virou e viu Lu Linyuan vindo a passos largos. Imaginou que Ning Xiaoxiao tivesse mais uma vez fechado a porta na cara do imperador, que agora descontaria nele o mau humor.

Ainda nem havia recebido o castigo imposto na audiência daquela manhã. Melhor se fazer de coitado até o fim!

Quando Lu Linyuan estendeu a mão, Sanfu prontamente deu uma bofetada em si mesmo. — Perdoe-me, Majestade! Este servo reconhece seu erro!

Lu Linyuan: — ??? Que diabo deu em você? Eu mandei trazer o orvalho de jade com hortelã!

O orvalho de jade com hortelã era parecido com um enxaguante bucal moderno: limpava a boca e mantinha o hálito fresco por bastante tempo.

Lu Linyuan, porém, quase nunca o utilizava.

Primeiro, porque não gostava muito do cheiro de hortelã, forte demais para seu nariz.

Segundo, porque seu hálito já tinha naturalmente um aroma de orquídeas. Ao conversar bem perto de alguém, ele literalmente exalava perfume a cada palavra. Não havia hálito algum a refrescar.

Por isso, Sanfu ficou perplexo com o pedido inesperado. — Mas Vossa Majestade não detesta hortelã?

Lu Linyuan ergueu lentamente os olhos e o fulminou. Sanfu fechou a boca na mesma hora e, respeitoso, retirou o frasco da liteira.

O imperador destampou-o, tomou dois goles com uma careta, bochechou e cuspiu numa pequena bacia vermelha de madeira que Xiao Yinzi lhe ofereceu. Limpou a boca e voltou ao Palácio Zhongcui.

Sem entender, Xiao Yinzi cochichou com Sanfu: — Mestre, que história é essa agora?

— O que você entende dessas coisas? — Sanfu conteve o riso e bateu de leve na cabeça dele com o espanador. — Depois de tanto preparo, é claro que Sua Majestade vai aproveitar uma felicidade de fazer esquecer o céu e a terra!

— Vá pedir mais duas bolsas de água quente. Hoje nossa espera vai ser longa!

*

Parado discretamente à porta do pavilhão oriental, Lu Linyuan descobriu uma coisa impressionante.

Bastou sair por um instante para enxaguar a boca e Ning Xiaoxiao já havia imaginado umas dez mil maneiras de fazê-lo perder os sentidos.

Acertá-lo na cabeça, golpeá-lo na nuca, atingi-lo com um objeto pesado, drogá-lo, envenená-lo, enfiar-lhe um saco plástico na cabeça!

Era um verdadeiro festival de loucura!

Lu Linyuan rangeu os dentes, furioso.

【Maldita seja! Você não consegue me beijar acordado, é isso? Tem vergonha desta minha cara bonita?!】

Irritado, levantou a perna para arrombar a porta. Mas lembrou que depois teria de pagar pelo conserto. Baixou obedientemente o pé imperial e empurrou a porta com força.

Ning Xiaoxiao estava tão concentrada em descobrir como desmaiar o tirano que, ao vê-lo aparecer de repente, levou um susto e soltou uma besteira:

— Majestade, veio se entregar de bandeja?

— ...

— Ah, não! Quero dizer... Majestade, comeu peixe refogado com pinhão?

【... Que diabo eu estou falando?!】

Lu Linyuan aproximou-se devagar e, parando ao lado dela, ordenou: — Levante esse traseiro.

Ning Xiaoxiao: — ???

— Levante o traseiro e abra um espaço para mim.

— Ah...

O assento aquecido era espaçoso, com um lugar de cada lado.

Mas Lu Linyuan insistiu em se espremer ao lado dela. Talvez sofresse de deficiência renal e sentisse frio; por isso queria se encostar para dividir o calor.

Estavam tão próximos que os braços quase se tocavam através das roupas, produzindo um leve farfalhar de tecido.

Ning Xiaoxiao olhava em volta, como se procurasse alguma coisa.

— O que está espiando com essa cara de ladra? — perguntou ele.

— Hum? Nada, não!

【Estou procurando algo que dê para agarrar e usar para te apagar com uma pancada!】

【Hmm... Este incensário serve. Mas não será duro demais? Ah, tanto faz. Vai ser este!】

Ela estendeu a mão para pegá-lo, mas Lu Linyuan foi mais rápido. — Este incensário está caindo aos pedaços e você ainda o deixa aqui?

Ele abriu a janela de treliça e, como quem arremessa uma bola de três pontos, jogou o objeto para fora. — Depois mando o Departamento de Assuntos Internos trazer outro.

Ning Xiaoxiao: — ???

【Você está bem da cabeça? Não foi você que mandou entregar essa porcaria depois do meu “aborto”? Então resolveu me dispensar com uma coisa velha mesmo?!】

Sem incensário, ela não tinha nenhum objeto à mão.

Só lhe restava usar o próprio corpo: disfarçadamente, esticou a mão aberta atrás da cabeça dele, preparando um golpe na nuca que lhe ensinaria uma lição.

Mas, quando estava prestes a tocar o pescoço dele, Lu Linyuan segurou-lhe o pulso. Ergueu preguiçosamente os olhos e curvou os lábios num sorriso malicioso.

— Quer me acariciar?

Aquele sorriso de sedutor exagerado arrepiou Ning Xiaoxiao inteira.

【Socorro! Será que você pode parar de sorrir assim?! Parece um príncipe mergulhado em óleo de tão cafona!】

Ela não respondeu. Mas, depois de fitá-lo tão de perto por alguns instantes, corou sem saber por quê e começou a desviar os olhos.

Lu Linyuan soltou seu pulso e, delicadamente, segurou o queixo dela entre o polegar e o indicador, obrigando-a a erguer o rosto.

Então aquele rosto bonito se aproximou, centímetro a centímetro, até as feições de ambos ficarem desfocadas. Só então ele perguntou, num murmúrio rouco:

— Comigo tão perto assim, o que passa pela sua cabeça?

Uma lufada de ar quente trouxe o frescor da hortelã misturado ao perfume intenso de orquídeas.

Ning Xiaoxiao estremeceu. Tímida, tentou recuar, mas os dedos dele apertaram mais seu queixo, forçando-a a sustentar o olhar.

Ele sorriu, elevando o tom. — Estou fazendo uma pergunta.

— Eu... tenho algo para dizer... Mas fico sem graça... Tenho medo de deixar Vossa Majestade constrangido...

Vendo seu jeito delicado, Lu Linyuan sorriu ainda mais confiante. — Pode falar.

— Foi Vossa Majestade quem pediu, hein...

Hesitante, Ning Xiaoxiao levantou a mão e apontou para a fileira de dentes brancos que aparecia no sorriso perfeito dele.

— Majestade, tem uma folha de cebolinha presa nos seus dentes da frente!

Lu Linyuan: — ???

Ele fechou o sorriso na mesma hora e passou a ponta da língua pelos dentes.

Droga! Uma folha de hortelã havia ficado presa ali quando bochechou!

Para salvar a dignidade, tratou de explicar: — Não é cebolinha! É HORTELÃ!

E mastigou a folhinha duas vezes antes de engoli-la.

Ning Xiaoxiao o observou com uma pontinha de repulsa. — Majestade, está mesmo passando tanta fome? Se estiver, é só me dizer. Eu posso fazer alguma coisa para comer. Não precisa chegar a esse estado lamentável...

Lu Linyuan levou a mão à testa. Uma longa sequência de reticências parecia pairar sobre sua cabeça.

O que fazer? Acho que já não quero viver de novo...

(Nota da autora: Na missão não vale usar trapaças como Pausar ou Modificar. Se ela parar o tempo para roubar 99 beijos do tirano, só vai satisfazer a vontade de beijá-lo: Xiao Qi considerará a missão fracassada! Já expliquei isso várias vezes antes, então não vou repetir depois!)

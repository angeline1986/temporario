# Capítulo 161 — Beijar o tirano 99 vezes

A melhor maneira de aliviar um constrangimento é fazer a outra pessoa passar vergonha também.

Como imperador, Lu Linyuan tinha obrigação de dominar suas expressões.

Por mais que desejasse se enfiar num buraco, seu rosto continuava sereno e imperturbável.

Após um longo silêncio, soltou uma risadinha e provocou:

— Que delícia você poderia preparar para mim? No máximo, explodiria a cozinha outra vez.

Teimosa como sempre, Ning Xiaoxiao não admitiria derrota. — Majestade, não me subestime! Desde o fracasso da pizza de durião, venho me dedicando de corpo e alma à culinária, estudando cuidadosamente como...

— Como me envenenar até a morte? — Lu Linyuan completou a frase dela, ainda mais zombeteiro.

— Aceite um conselho: há coisas que só depois de muito esforço a pessoa percebe o quanto talento faz falta.

Atiçada pela provocação, Ning Xiaoxiao esqueceu por um momento os planos de nocauteá-lo. Arregaçou as mangas. — Então espere! Vou cozinhar agora mesmo! Desta vez vai comer e admitir que sou boa!

Sem dar ouvidos aos protestos dele, disparou para a cozinha como se tivesse asas nos pés.

Lu Linyuan sorriu ainda mais ao ver sua silhueta se afastar tão determinada e murmurou:

— Gatinha boba.

Na verdade, pouco lhe importava se Ning Xiaoxiao andava estudando culinária ou se sabia cozinhar.

Se fosse algo preparado por ela, mesmo com gosto de cera, ele o engoliria com prazer.

(Eu sei que a expressão “ter gosto de cera” não se usa bem assim. Não precisam me corrigir, quero usar desse jeito! ╭(╯^╰)╮)

Ele só dissera aquelas coisas porque estava mesmo com fome e pretendia provocá-la até fazê-la cozinhar por vontade própria.

Achava sua estratégia impecável, sem imaginar que Ning Xiaoxiao não estava nem aí para aqueles truquezinhos de homem sem jeito.

Ela apenas queria experimentar outra maneira de fazê-lo desmaiar.

Se a força não funcionava, bastava usar drogas!

Ainda tinha dez fios de cabelo do tirano guardados. Era a quantidade exata para trocar na loja de conveniência por uma dose de sonífero incolor e sem cheiro.

O efeito, porém, durava pouco: cerca de uma hora.

Ning Xiaoxiao fez uma conta aproximada: seria preciso dar um beijo e meio por minuto. Daria tempo.

Como o tirano havia dito, não possuía talento para cozinhar. Mas, tendo seu espaço especial à disposição, tinha o mundo nas mãos!

Com tantas panelinhas instantâneas e pacotes de macarrão no espaço, qualquer um deles seria uma iguaria divina na Antiguidade.

Entrou no espaço e pegou um pacote de macarrão instantâneo de carne bovina refogada da marca Kang Shuaifu. Havia também um pacote de Tang Daren ao lado, mas queria guardá-lo para si e não estava disposta a oferecê-lo ao tirano.

Trabalhou com desenvoltura e, cinco minutos depois, foi reivindicar seus méritos diante de Lu Linyuan com uma tigela de macarrão fumegante.

A apresentação não era das melhores, mas o aroma era irresistível.

Lu Linyuan nunca havia visto macarrão tão fino, comprido, ondulado e ainda por cima amarelo.

Ergueu uma porção com os pauzinhos e sacudiu: as tiras fizeram um movimento elástico, como se fossem extremamente firmes.

— Como se prepara este macarrão? — perguntou, curioso.

Ning Xiaoxiao fez uma careta brincalhona, fingindo mistério. — Segredo! Coma enquanto está quente, Majestade. Frio não fica tão gostoso!

【Isso, coma! Depois você dorme por uma hora inteira e eu faço o que bem entender!】

Ela observou, ansiosa, enquanto ele levava o macarrão à boca. Mas, a um instante dos lábios, os pauzinhos pararam. Lu Linyuan estremeceu de leve.

Olhando para a janela de treliça, que estava entreaberta para ventilar, ordenou: — Vá fechar a janela. Você ainda está fraca depois do aborto. Não quero que apanhe um resfriado.

— Está bem... — Ning Xiaoxiao obedeceu a contragosto. Porém, bastou virar as costas para fechar a janela e, quando tornou a olhar, Lu Linyuan já estava debruçado sobre a mesa, dormindo...

【Caramba! O remédio é tão forte assim?!】

Ela o chamou com cautela: — Majestade? Majestade, acorde!

Sem resposta, ganhou coragem e bateu duas vezes no braço dele. — Lu Linyuan? Está dormindo?

Nada. Então abusou da sorte: apertou as bochechas macias e elásticas do imperador, abrindo um sorriso cada vez mais atrevido.

— Trouxa! Adormeceu mesmo, seu trouxa? Acorda aí!

— ...

— Hehehe!

Seus olhos passaram a brilhar de uma cobiça inexplicável enquanto encarava Lu Linyuan. Era como...

Como um pica-pau faminto havia um dia inteiro, babando diante de um tronco de árvore!

Ning Xiaoxiao já esfregava os lábios e preparava os dentes para começar a “se aproveitar” de Lu Linyuan quando Xiao Qi surgiu com um aviso gentil:

【Anfitriã, anfitriã! Esqueci de dizer ontem! Sei que você vai procurar alguma brecha no meu sistema, então preciso avisar: não importa como você dê os primeiros 98 beijos, mas o último precisa ser bem nos lábios dele, está bem?】

Ning Xiaoxiao: 【... Entendi. Pode se retirar!】

*

No começo, por estar concentrada em concluir a missão, Ning Xiaoxiao não achava que fazia algo especialmente vergonhoso.

Mas, quando finalmente depositou um beijo na bochecha de Lu Linyuan, seu coração estremeceu de repente, como se tivesse levado um golpe, e ela ficou terrivelmente nervosa.

Depois de tanto tempo juntos, quantos beijos acidentais já não haviam trocado? Em teoria, ela deveria estar acostumadíssima.

Ainda assim, ficou tão constrangida que suas mãos começaram a suar.

Mas tudo se aprende com a prática: a primeira vez é estranha, a segunda fica mais fácil.

Repetiu mentalmente que fazia aquilo apenas para voltar para casa. Cerrou os dentes, tomou coragem e se inclinou outra vez.

Quando cansava de beijar a bochecha esquerda, passava para a direita; depois, voltava para a esquerda.

Contava mentalmente cada beijo. Ao final, seus lábios já estavam dormentes, mas a libertação se aproximava.

【Noventa e cinco, noventa e seis, noventa e sete, noventa e oito... Hmm... O último tem que ser na boca...】

Lembrando-se da advertência de Xiao Qi, fechou os olhos, reuniu toda a coragem e encostou os lábios nos dele.

Mas então sentiu algo parecido com um peixinho deslizando sobre seus lábios?!

Arregalou os olhos e recuou vários passos. Enquanto esfregava a boca, pensou, horrorizada:

【I-isso... Que pervertido!】

【Como alguém consegue pôr a língua para fora até dormindo?!】

Na verdade, havia muitos outros detalhes nessa cena. Mas, no instante em que a pessoa diante da tela digitava essa linha, Xiao Qi apareceu para lhe dizer:

【Ultimamente a fiscalização anda rigorosa. Pegue leve e não procure encrenca!】

A humilde autora: 【Entendido, buááá...】

Ning Xiaoxiao observou Lu Linyuan, ainda aparentemente adormecido. As bochechas dele estavam levemente vermelhas. Talvez fossem os tantos beijos que as tivessem deixado assim.

Olhando desse jeito, por que ele parecia até um pouco fofo?

Antes que acordasse, ela correu para destruir as provas: levou para fora e descartou a tigela de macarrão da qual ele só havia comido uma garfada.

Mal saiu, Lu Linyuan, que “dormia” debruçado sobre a mesa, abriu os olhos de repente.

Passou a ponta da língua pelos lábios, estalou-os como quem saboreia algo e sorriu, satisfeito.

Sabor de cereja. Bem docinho.

Não foi suficiente. Quero mais.

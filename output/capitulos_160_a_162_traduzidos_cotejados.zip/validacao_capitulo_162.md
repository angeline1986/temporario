# Validação do capítulo 162

## Fonte e limites

- Fonte primária: `novel_capitulos_121_a_180(20261103-233558).docx` (chinês tradicional).
- Intervalo de parágrafos DOCX (base zero): 2877 a 2952; próximo capítulo começa no índice 2953.
- Parágrafos não vazios, incluindo título: **73**.
- Cotejo: **73 linhas** de dados; campos completos.
- Índices duplicados: **0**. Índices de origem não contemplados: **0**.
- Cabeçalho CSV: `indice_docx,original_chines,traducao_portugues`.

## Decisões editoriais e continuidade

O nome 李萬姬 soa como 日理萬機, expressão que Ning acabou de usar ao falar dos assuntos imperiais. Adaptou-se o efeito como humor involuntário de rima, mas a homofonia chinesa fica registrada aqui. A pílula só funciona no aniversário, permite um dia no mundo moderno e paralisa o mundo do livro. A nota sobre 神經 é um jogo fonético, identificado como nota autoral, não uma etimologia real.

## Limitações

A conferência automatizada valida a correspondência 1:1, os índices de parágrafo e campos preenchidos. Houve revisão editorial durante a tradução e conferência de pontos narrativos sensíveis, mas **não foi realizada auditoria linguística independente integral**. Igualdade de contagens não demonstra, por si só, ausência de erros semânticos dentro de cada parágrafo.

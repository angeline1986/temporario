# Capítulo 162 — Os dois avançam um para o outro... e acabam batendo de cara na parede

【Bip, bip, bip! Parabéns, anfitriã, por concluir a missão “Beijar o tirano 99 vezes”! Sua recompensa é uma “Pílula de Volta à Terra Natal”. Pode recebê-la!】

Ning Xiaoxiao mal entrara na cozinha e fechara a porta quando Xiao Qi começou a entregar a recompensa.

Após um breve lampejo azul, uma pequena pílula cor-de-rosa surgiu na palma de sua mão.

Xiao Qi: 【Vou explicar rapidinho! Você precisa dissolver a pílula em água, como um comprimido efervescente. Quando estiver completamente dissolvida, é só beber: assim poderá voltar ao mundo moderno e viver lá durante um dia.】

【Atenção: a pílula só funciona se for tomada no dia do seu aniversário.】

【Quando você voltar ao mundo moderno, o tempo no mundo do livro ficará temporariamente congelado. A trama só continuará depois do seu retorno.】

Era dia 26 de novembro. Faltavam apenas dois dias para seu aniversário.

Embora estivesse louca de vontade de voltar, podia esperar mais um pouquinho.

Afinal, como diz o ditado:

Comida boa pode esperar; o perigo é alguém roubá-la antes!

Lu Linyuan era feito um bobalhão que nunca cresceu: queria comer frango frito, beber chá com leite e se apossava à força de qualquer novidade que ela tivesse.

Era melhor guardar bem a pílula. Se o tirano a engolisse e fosse parar no mundo moderno, aí a situação ficaria interessante!

Assim, Ning Xiaoxiao entrou no espaço e guardou a pílula na gaveta reservada aos seus lanches, assegurando-se de que ninguém a encontraria.

Ao voltar à cozinha, jogou fora rapidamente o macarrão com sonífero.

Lembrou que Lu Linyuan dissera estar com fome, mas adormecera depois de apenas uma garfada. Ficou com pena e preparou outra tigela.

Quando voltou ao quarto, ele já estava acordado.

Sentado à mesa de madeira vermelha, examinava-a com um olhar penetrante, que a deixou com a consciência pesada.

— Majestade, com tantos assuntos de Estado para resolver, acabou cochilando de cansaço. Preparei outra tigela para o senhor!

Ela colocou a tigela e os pauzinhos diante dele, mas, de repente, Lu Linyuan segurou seu pulso.

A pressão não era forte a ponto de machucá-la, mas também não permitia que se soltasse facilmente.

Ning Xiaoxiao se assustou. — Majestade?

Lu Linyuan abriu um sorriso travesso, aproximou-se do ouvido dela e murmurou, com o hálito quente e a voz rouca:

— Não conheço nenhum Li Wanji, mas hoje você foi muito atenciosa.

Ning Xiaoxiao: — ???

【Você está bem da cabeça? Resolveu fazer rap agora? Mandou até uma rima, parceiro!】

Ela tentou girar o pulso para escapar. — Majestade, vá comer o seu macarrão! Está me machucando!

Ning Xiaoxiao só era valente da boca para fora. Bastava Lu Linyuan ficar um pouquinho atrevido diante dela para a vermelhidão subir até a ponta das orelhas.

Ele riu e a soltou. Apertou levemente os lábios e estalou a língua.

— Curioso... Cochilei tão pouco. Por que será que meus lábios estão molhados?

Como uma criança prestes a ser apanhada depois de fazer algo errado, Ning Xiaoxiao entrou em pânico.

— Talvez Vossa Majestade tenha babado enquanto dormia?

— Será? — Lu Linyuan passou o polegar pelo contorno dos lábios e soltou uma risadinha fria. — Também tive um sonho. Sonhei com uma gatinha selvagem de olhos de cores diferentes, que passava aquela língua cheia de pequenas farpas lambendo meu rosto sem parar...

Enquanto falava, levantou-se de repente e avançou, passo a passo, na direção dela.

A cada passo dele, Ning Xiaoxiao recuava outro. Sem perceber, chegou à beirada da cama. A panturrilha bateu na estrutura, ela perdeu o equilíbrio e caiu de costas, com braços e pernas abertos, como se tivesse se preparado automaticamente.

O tirano inclinou-se sobre a gatinha, parando a poucos centímetros dela. Primeiro, esfregou a barba recém-crescida nas clavículas salientes de Ning Xiaoxiao, fazendo-a se contorcer de cócegas entre risos e protestos.

— Hahahaha! Majestade, solte! Hahaha! Faz muita cócega!

Só depois de ouvi-la implorar é que ele ergueu a cabeça, satisfeito, e aproveitou para segurar-lhe o queixo, pressionando levemente com os dedos.

Parecia querer usar alguma técnica para fazê-la abrir a boca, enquanto Ning Xiaoxiao mantinha os dentes cerrados, resistindo à pressão.

Até que o sorriso dele desapareceu e seu tom ficou subitamente sério:

— Seja boazinha. Não se mexa.

— Quero ver se sua língua tem mesmo farpinhas.

Ning Xiaoxiao: — ???

【Você enlouqueceu? Está parecendo a própria Rainha-Mãe celestial de TPM... Uma verdadeira neurose divina!】

(Nota da autora: É um trocadilho chinês absurdo: a “menstruação de uma divindade” é abreviada de forma a soar como “nervosismo/loucura”.)

O polegar dele tocou os lábios de Ning Xiaoxiao e finalmente conseguiu fazê-la abrir a boca. Mas a visão daquela fileira de dentinhos brancos arreganhados acabou de vez com sua pose.

— Pff!

Ele deixou escapar uma risada e só então percebeu o extremo desconforto da jovem.

Ela franzia as sobrancelhas, agarrava nervosamente a colcha com as mãos e tinha as bochechas tão vermelhas quanto as de quem acabara de beber uma dose generosa de bebida fortíssima.

Por algum motivo, aquela expressão de desamparo e vergonha se transformou numa chicotada invisível que atingiu em cheio o coração de Lu Linyuan.

Ele franziu a testa, perdeu o sorriso e soltou-a imediatamente.

Estava brincando com Ning Xiaoxiao. Gostava de provocá-la.

Mas, se a brincadeira a deixava desconfortável, não era mais brincadeira: tornava-se algo grosseiro e vulgar.

Ele não gostava dessa sensação e gostava menos ainda de provocá-la nela.

As mulheres do palácio eram como pássaros aprisionados em sua gaiola; ele, como uma árvore frondosa, coberta de flores douradas.

Todas queriam correr para ele e rodear seu tronco, buscando ao menos um galho onde se apoiar.

Mas, embora tivesse inúmeros galhos, ele reservara todos eles para abrigar apenas a pessoa que amava, esperando que ela escolhesse pousar ali.

Se, no entanto, Ning Xiaoxiao estava realmente desamparada e envergonhada, suportando algo contra a vontade, ou se apenas se fazia de difícil por timidez e desejo, provavelmente só ela mesma sabia.

Afinal, ela tinha tantos recursos extraordinários! Pausar, Retroceder ou Modificar a trama bastariam para escapar com facilidade daquela situação constrangedora.

Ela não havia esquecido seus poderes, tão incompatíveis com aquele mundo que pareciam pertencer a uma dimensão superior. Ainda assim, dessa vez escolheu não fazer nada.

Suas intenções eram óbvias para qualquer um. Qualquer um, menos aquele grande idiota do Lu Trouxa.

O grande idiota... digo, Lu Linyuan, soltou uma risadinha e falou com toda a seriedade à Ning Xiaoxiao, que continuava imóvel na cama:

— Parece que você anda desocupada nestes dias. Vou deixar a reforma do Palácio Xianshou, da imperatriz-viúva, sob sua responsabilidade.

Antes que ela pudesse reagir, ele próprio fugiu de fininho.

Ning Xiaoxiao ficou sozinha, completamente atônita.

Como assim?

Por que foi embora?

Não sabe brincar até o fim?

Ou não dá conta do recado?

Que raiva! (╬◣д◢)

*

Mais tarde, ao anoitecer, funcionários da Oficina Imperial de Manufaturas e do Departamento de Assuntos Internos foram procurá-la juntos, perguntando que ideias tinha para reformar o Palácio Xianshou.

Só de pensar naquela velha insuportável da imperatriz-viúva, Ning Xiaoxiao ficava irritada. Assim, num acesso de birra, respondeu sem pensar: — Já que Sua Majestade mandou fazer uma reforma grande, então comecem arrancando o telhado!

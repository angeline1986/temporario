# Capítulo 230 — Gu Sijin finalmente mostrou sua firmeza

Agora que Lu Linyuan estava ausente e a imperatriz alegava doença para não se ocupar dos assuntos do harém, a Consorte Nobre naturalmente reinava absoluta: sua palavra era lei.

A Guarda Imperial representava Lu Linyuan. Se Chu Xingran ousasse enfrentá-la, estaria metido numa enorme encrenca.

Os guardas avançaram, cercaram Chu Xingran e imobilizaram-lhe os braços às costas, sem conceder qualquer consideração ao seu cargo de comandante dos Nove Portões.

Gu Sijin viu, impotente, quando estavam prestes a arrastá-lo para fora do Palácio Fengyi. O coração lhe subiu à garganta.

Sua mente ficou em branco. Restava-lhe um único pensamento:

Não podia deixá-los levá-lo assim!

Caso contrário, antes que Lu Linyuan retornasse ao palácio, a Consorte Nobre certamente o submeteria a toda espécie de tortura.

Quem passava pelos suplícios da prisão imperial, mesmo que não morresse, saía de lá meio inválido.

Após um breve conflito interior, Gu Sijin nem soube de onde tirou coragem.

Correu até os guardas, bloqueou-lhes o caminho e disse, com voz fria: — Vocês não podem levá-lo.

A Consorte Nobre soltou uma risadinha, como se tivesse ouvido a maior piada do mundo, e foi até ela. — Uma simples Nobre Dama ousa questionar uma ordem minha?

Com um dedo delicado, ergueu-lhe o queixo, arrogante e insolente. — O quê? Quer que eu mande você também para a prisão imperial?

A expressão de Gu Sijin mudou de repente.

O medo de instantes antes desapareceu por completo, substituído por uma ferocidade que ninguém jamais vira nela.

Ela afastou com um tapa a mão da Consorte Nobre. Furiosa, a mulher explodiu: — Dei liberdade demais a você, não foi? Guardas! Joguem essa Gu também na prisão imperial!

Os guardas se aproximaram de Gu Sijin. Chu Xingran, com os braços imobilizados, contraiu os músculos em silêncio; veias saltaram-lhe nos antebraços, e ele franziu as sobrancelhas.

Já estava preparado para o pior. Se a Consorte Nobre ousasse tocar novamente em Gu Sijin, ele promoveria um banho de sangue no palácio e a levaria para bem longe.

Quando os guardas chegaram diante dela, no exato momento em que Chu Xingran ia agir, Gu Sijin tirou da cintura uma placa dourada reluzente.

Ning Xiaoxiao lhe dera aquele objeto. Com medo de perdê-lo, Gu Sijin o mantinha sempre junto ao corpo.

Então gritou a plenos pulmões: — Quem se atreve?!

Assim que viu a placa de ouro em suas mãos, o guarda à frente ficou aterrorizado. Sem hesitar por um segundo, ajoelhou-se e começou a bater a testa no chão:

— Dez mil anos ao imperador! Dez mil anos! Dez mil vezes dez mil anos!

Quando ele se ajoelhou, os homens atrás dele também puderam ver o que Gu Sijin segurava.

Não era um objeto qualquer, mas a única medalha de imunidade à morte de toda a dinastia!

Todos caíram de joelhos ao mesmo tempo, clamando longa vida ao imperador. Só a Consorte Nobre ficou parada, atônita, como se ainda não compreendesse o que ocorria.

Gu Sijin deu dois passos à frente e empurrou a medalha bem diante do rosto dela:

— Estar diante desta medalha é como estar diante de Sua Majestade. Por que ainda não se ajoelhou?!

Era como se Gu Sijin tivesse se transformado em outra pessoa. Sua imponência superava em muito a da Consorte Nobre, que há anos fazia o que queria no harém.

De queixo erguido, lançou à outra um olhar de soslaio.

Percebeu cada traço de espanto nos olhos da Consorte Nobre e, por alguma razão, achou aquela sensação estranhamente prazerosa.

Era a primeira vez que experimentava o que significava ter poder nas mãos.

Com ele, podia proteger facilmente quem desejava proteger, sem sofrer humilhações nem deixar que outros padecessem em seu lugar.

A Consorte Nobre ficou pasma por um bom tempo antes de gaguejar: — C-como essa medalha de imunidade à morte foi parar nas suas mãos?

Gu Sijin não respondeu. Apenas repetiu, impassível:

— Ajoelhe-se.

— Você...

— Eu o quê? — Gu Sijin arqueou uma sobrancelha. — Pretende desobedecer a uma ordem imperial?

Usando contra ela a mesma prepotência com que fora tratada, Gu Sijin a encurralou. Sem saída, a Consorte Nobre teve de se ajoelhar, contrariada.

Gu Sijin olhou para ela de cima e continuou a dar ordens: — Comandante Chu, o senhor recebeu uma ordem verbal de Sua Majestade. Hoje apenas cumpriu seu dever, não invadiu o harém sem autorização. Não há mais nada para o senhor aqui. Pode se retirar.

Chu Xingran sabia que Lu Linyuan dera a medalha a Ning Xiaoxiao, mas ignorava que Ning a havia passado adiante para Gu Sijin.

Conhecia bem a personalidade de Gu Sijin: ela jamais gostara de causar problemas a ninguém. Mesmo depois de ter sido castigada daquela maneira, não exibira a medalha para se salvar. Isso demonstrava que nem sequer pretendia recorrer àquele poder.

Por ele, porém, abrira uma exceção.

Por mais frias que fossem suas palavras, seus atos revelavam a verdade.

Chu Xingran sorriu para ela com o mesmo calor dos velhos tempos.

Protegida pela medalha, Gu Sijin estava fora do alcance da Consorte Nobre.

Chu Xingran sabia que, se continuasse ali, despertaria suspeitas sobre sua relação com ela. Por isso, agradeceu a graça imperial e partiu depressa.

— Pare! — gritou a Consorte Nobre. — Basta ele dizer que recebeu uma ordem verbal do imperador para ser verdade? Onde está a prova?

Gu Sijin replicou severamente: — Sua Majestade saiu do palácio para a propriedade das fontes termais, mas um dia voltará. Quando isso acontecer, bastará perguntar-lhe se deu ou não a ordem. Quem é você para questioná-la agora?

A Consorte Nobre ficou sem palavras.

Depois que Chu Xingran saiu, Gu Sijin também ordenou à Guarda Imperial que deixasse o Palácio Fengyi.

Só quando a situação ficou sob controle ela guardou a medalha de imunidade à morte.

A Consorte Nobre se levantou imediatamente e disse, entre dentes: — Quando eu a castiguei, você não mostrou a medalha. Mas bastou eu castigá-lo para você reagir como se tivesse pisado no seu rabo.

Aproximou-se e comentou, com insinuação: — Nobre Dama Gu, parece que sua relação com ele é bem especial, não é?

Gu Sijin lhe lançou um olhar e respondeu serenamente:

— Sou uma das mulheres de Sua Majestade. Acusar minha honra sem prova alguma também mancha a reputação do imperador. Se repetisse essas palavras diante dele, temo que Sua Majestade mandaria arrebentar sua boca.

— Você...!

— A imperatriz chegou!

O anúncio do eunuco soou do lado de fora. A imperatriz finalmente apareceu e, ao encontrar o Palácio Fengyi em completa desordem, demonstrou claro desagrado:

— Que confusão é esta? Nem enquanto estou doente vocês conseguem deixar de provocar tumultos?

Após interrogar as criadas e conhecer os acontecimentos, balançou a cabeça, resignada. — Consorte Nobre, com o imperador fora do palácio, você deveria se conter um pouco.

Então se aproximou, ergueu a manga de Gu Sijin e revelou ferimentos profundos, de carne dilacerada, capazes de arrepiar qualquer um.

— Feridas tão profundas... talvez até deixem cicatrizes. O que estão esperando? Chamem depressa um médico imperial!

A imperatriz mandou a Consorte Nobre se retirar. Esta, que nunca lhe demonstrara respeito, ficou ainda mais agressiva ao vê-la proteger Gu Sijin:

— A medalha pode livrá-la da morte, mas não a isenta das punições do harém. Hoje ela deixou de vir me saudar sem motivo e desrespeitou uma superior, algo proibido pelas regras palacianas. A imperatriz pode ser bondosa e perdoá-la, mas a sua bondade não torna as regras inexistentes, torna?

Gu Sijin se defendeu: — Hoje eu realmente não estava me sentindo bem e pedi dispensa seguindo todos os procedimentos exigidos pelas regras. A senhora sabe perfeitamente por que decidiu me atacar sem motivo.

Com o temperamento da Consorte Nobre, seria impossível que ela desistisse depois de tamanho espetáculo sem conseguir o que queria e ainda perder a pose.

A imperatriz então declarou: — Nesse caso, a Nobre Dama Gu ficará confinada em seus aposentos por um mês. Está satisfeita agora, Consorte Nobre?

A Consorte Nobre ajeitou o adorno na têmpora e, em atitude insolente, soltou um "Serve" antes de ir embora, muito satisfeita consigo mesma.

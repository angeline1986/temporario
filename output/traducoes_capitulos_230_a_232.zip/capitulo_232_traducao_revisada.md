# Capítulo 232 — Estrelas e Brocado: eu a seguiria até os confins do mundo

De fato, aquela “recompensa” oferecida pela imperatriz era uma tentação enorme para Gu Sijin, que havia passado tanto tempo encerrada no palácio, carregando tantas preocupações.

E a imperatriz não estava mentindo.

Se Gu Sijin realmente deixasse o palácio levando a autorização e a ordem imperial da imperatriz, seria como se esta assumisse todos os riscos em seu lugar.

Em outras palavras, se alguma coisa lhe acontecesse do lado de fora, a imperatriz teria abusado de sua autoridade ao substituir um decreto do imperador por uma ordem sua para permitir que uma concubina deixasse o palácio. Se o assunto chegasse à corte, poderia até perder o posto de imperatriz.

Uma mulher que tanto prezava a própria posição não brincaria com algo assim.

Enquanto Gu Sijin se perguntava por que a imperatriz faria semelhante oferta, ouviu-a dizer tranquilamente: — Ainda espero que converse pessoalmente com seu pai sobre a família Tong.

Gu Sijin compreendeu na hora. Era esse o verdadeiro cálculo da imperatriz.

Seu pai, Gu Yanchuan, trabalhava havia muitos anos como censor no Tribunal de Supervisão, órgão encarregado de investigar funcionários corruptos e subordinado diretamente a Lu Linyuan. Por isso, mantinha sempre uma expressão severa, não cultivava amizades com ministros e tampouco permitia aproximações interesseiras.

Era um homem íntegro e inflexível, para poder lidar com as sujeiras que se escondiam sob a superfície da corte com imparcialidade absoluta, sem deixar sentimentos pessoais interferirem.

Sem a colaboração do Tribunal de Supervisão, o plano da imperatriz contra Tong Guowei certamente fracassaria. Como não tinha acesso à instituição, precisava conquistar Gu Sijin para que a jovem servisse de ponte.

Gu Sijin fez suas contas em silêncio: a boca era sua, e a imperatriz não podia controlar o que ela diria ou deixaria de dizer.

Já que a imperatriz era tão calculista, ela podia fingir concordar e prometer ajudá-la.

Assim, conseguiria sair mais cedo do palácio e se reunir com seus pais.

Portanto, decidiu usar o plano da outra em benefício próprio: — Também acho que a Consorte Nobre passou de todos os limites. Tong Guowei ainda roubou os méritos de meu pai e o deixou tão indignado que ele adoeceu. Se permitirmos que a família Tong continue agindo assim, cedo ou tarde os inocentes também sofrerão as consequências.

Levantou-se e fez uma reverência à imperatriz: — Estou disposta a seguir a liderança de Vossa Majestade.

— Levante-se, depressa. Está ferida! Para que tanta formalidade? — A imperatriz a ajudou a erguer-se. O sorriso que lhe escapou denunciava a satisfação de seus cálculos. — Fico feliz que pense assim. Vou providenciar tudo o quanto antes para que você possa sair do palácio.

*

A imperatriz parecia incapaz de tolerar a Consorte Nobre por mais um instante. Usou a autoridade de seu posto e mobilizou os contatos necessários. Pouco depois, entregou a Gu Sijin a autorização e a ordem escrita, combinando que ela deixaria o palácio discretamente à meia-noite daquela mesma noite.

Gu Sijin separou apenas algumas peças de roupa e advertiu Qiqi e as outras criadas a manterem absoluto sigilo, sem deixar que ninguém percebesse nada.

À meia-noite, uma carruagem providenciada pela imperatriz a levou para fora às escondidas. Além dos guardas do Portão Shenwu, ninguém soube de coisa alguma. A saída passou despercebida até pela Consorte Nobre.

Sentada na carruagem, Gu Sijin percebeu que, depois de atravessar os portões do palácio, o veículo parou por um breve instante e então voltou a andar.

Durante todo o trajeto, não ousou levantar a cortina para espiar o lado de fora, temendo ser reconhecida.

A residência dos Gu ficava ao sul da capital, relativamente perto do Portão Shenwu.

No entanto, a carruagem já avançava havia o tempo de queima de um bastão de incenso sem dar qualquer sinal de que iria parar.

Percebendo que havia algo errado, ela ergueu um canto da cortina e descobriu que o veículo já estava nos arredores da cidade — e continuava correndo a toda velocidade!

Gu Sijin não era tola. Não gritou de imediato para que o cocheiro parasse.

Se ele pretendesse parar, já o teria feito. Não haveria motivo para continuar disparando depois de deixar a capital.

Respirou fundo por um momento até recuperar a calma. Depois ergueu cuidadosamente a cortina, decidida a se arriscar saltando da carruagem.

Mas, no instante em que reuniu coragem para pular, o condutor gritou “ôô!” e puxou as rédeas do cavalo em disparada. Pelo impulso da freada, Gu Sijin foi atirada de volta para o interior do veículo.

Felizmente, a cabine era toda acolchoada. Ela bateu em uma das paredes, mas não se feriu.

E aquela voz que acabara de ouvir, soltando o “ôô!”, era familiar demais.

Houve um tempo em que ainda era uma jovem donzela, e Chu Xingran a levava para cavalgar pelas extensas pradarias, contemplando juntos a beleza da primavera.

Ele cavalgava depressa; quanto mais ela lhe pedia para diminuir, mais ele estalava o chicote.

Só quando Gu Sijin ficava apavorada e o agarrava com os dois braços pela cintura esguia é que ele soltava um sorriso travesso, gritava “ôô!” e detinha o cavalo.

Como esperava, a portinhola da carruagem se abriu. Chu Xingran a ajudou a se levantar e tentou erguer-lhe a manga para verificar se a pancada havia agravado o ferimento. Gu Sijin, porém, afastou sua mão com frieza.

— Por que é você?

— Passei dia e noite, sem dormir nem descansar, vigiando os movimentos do Palácio Fengyi. Por que não poderia ser eu?

Gu Sijin viu as olheiras escuras sob seus olhos; nem imaginava quantas noites ele passara acordado.

Quanto mais ele a amava com uma obstinação que beirava a loucura, mais facilmente derrubava as defesas que ela tanto se esforçara para erguer no coração.

Contendo as lágrimas, ela o repreendeu:

— Por que continua alimentando ilusões? Eu já disse que não amo mais você. Não consegue entender?!

— Por que insiste em me perseguir? Você é um homem feito! Não consegue viver sem amor? Precisa mesmo se humilhar desse jeito por causa de uma mulher?!

Gu Sijin fora criada como uma dama de família distinta, com modos impecáveis. Aquelas eram as palavras mais cruéis que conseguira imaginar para ferir Chu Xingran.

Mas ele era descarado. Deu um sorriso despreocupado e respondeu: — Sim. Sou mesmo um caso perdido.

Gu Sijin cerrou os dentes e cuspiu as palavras: — Você não tem vergonha na cara!

— Isso mesmo. Não tenho vergonha na cara.

Chu Xingran entrou na carruagem e encurralou Gu Sijin num canto. Fitando-a com os olhos ardentes, declarou:

— Só quero você.

— Você... hm?!

Gu Sijin não teve oportunidade de terminar a frase.

Chu Xingran lhe calou os lábios com um beijo dominador.

Gu Sijin tentou se debater, mas ele lhe prendeu os dois pulsos com uma das mãos. Com a outra, enquanto a beijava, acariciou delicadamente seu...

Sentimentos reprimidos por tanto tempo, uma vez descontrolados, eram difíceis de conter.

Pouco a pouco, Gu Sijin deixou de resistir, passou a encarar os próprios sentimentos e a viver aquele instante, correspondendo ao beijo com intensidade.

O beijo durou muito tempo. Chu Xingran só se afastou quando ouviu seus soluços abafados.

Sabia muito bem o dilema de Gu Sijin e quantas injustiças ela suportara.

Abraçou-a com força e deixou que chorasse desamparada, como uma criança.

Quando ela se acalmou um pouco, ele recolheu com os lábios uma lágrima quente que escorria por seu rosto e murmurou numa voz grave e suave:

— Venha comigo.

— Você acha que eu não gostaria de abandonar tudo e partir com você? Mas, se eu for embora agora, o que será de meu pai e de minha mãe? Se nós dois fugirmos, todos os parentes do meu clã pagarão com a vida.

Chu Xingran ficou em silêncio por um momento e então perguntou, com seriedade: — Dê-me algum tempo. Vou garantir a segurança da família Gu. Quando isso acontecer, você aceitará partir comigo?

Dessa vez, Gu Sijin não fugiu da resposta.

Assentiu com força, enterrando o rosto no peito de Chu Xingran:

— Se esse dia chegar, eu o seguirei até os confins do mundo.

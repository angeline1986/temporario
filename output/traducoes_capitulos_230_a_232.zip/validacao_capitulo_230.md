# Validação — Capítulo 230

- Fonte: `novel_capitulos_212_a_270(20261105-204934).docx`, texto original chinês tradicional.
- Limites reais (índice base zero, parágrafos DOCX): [1292, 1364).
- Unidades não vazias, incluindo título: **69**.
- Correspondência estrutural 1:1: **69/69**.
- Índices duplicados: 0. Índices de parágrafos não vazios ausentes no cotejo: 0.
- Campos de tradução vazios: 0. Cabeçalho CSV: `indice_docx,original_chines,traducao_portugues`.
- Texto `.md` gerado na mesma ordem e com os mesmos conteúdos traduzidos do CSV.

## Decisões editoriais

A medalha de imunidade à morte é exibida por Gu Sijin, que a recebeu de Ning Xiaoxiao; não é um novo presente do imperador. Consorte Nobre designa 貴妃; Nobre Dama Gu designa 顧貴人. A saudação 萬歲 foi adaptada como fórmula solene de longa vida.

## Alcance da revisão

Foi feita uma tradução direta e verificação automatizada da integridade e correspondência estrutural das unidades. **Não foi realizada segunda auditoria semântica independente, linha a linha**, portanto a contagem não certifica ausência absoluta de desvios interpretativos.

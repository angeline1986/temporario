# Capítulo 231 — Uma disputa de estratégias

A imperatriz amparou Gu Sijin até os aposentos, mandou Xiangling acender o braseiro e pessoalmente a envolveu em outra coberta.

Convocado pela imperatriz, o médico imperial não demorou a chegar. Tratou cuidadosamente dos ferimentos de Gu Sijin, mas, quando espalhou o pó medicinal sobre as lesões, a dor foi lancinante.

Gu Sijin cerrou os dentes com força, enquanto uma fina camada de suor surgia em sua testa.

Mesmo assim, quando o médico terminou, ela ainda pensou nas pessoas ao seu redor: — Poderia deixar comigo um pouco desse remédio para feridas? Agora que estou confinada, não convém que o senhor fique entrando e saindo. Amanhã mesmo posso trocar meus curativos.

A imperatriz adivinhou suas intenções: — Está pedindo esse remédio para tratar das criadas do seu palácio, não é? Mesmo ferida desse jeito, só pensa nos outros. Em todo o harém, você é a única tão bondosa e sensata que chega a partir o coração.

Resolveu então fazer-lhe um favor e autorizou, excepcionalmente, que o médico também atendesse às criadas. Depois disse a Gu Sijin:

— Você sofreu uma injustiça hoje. Quando ordenei seu confinamento, também estava pensando no seu bem.

— Sem o confinamento, teria de se apresentar diante dela todos os dias. Quem sabe quantas outras humilhações enfrentaria?

— Você mesma viu. A família dela domina a corte, e até eu preciso ceder em certas questões. Neste momento, quanto mais longe se mantiver, melhor.

As palavras da imperatriz soavam sinceras. Seus olhos demonstravam tanta pena e impotência que parecia realmente a mãe benevolente de toda a nação, compadecida das mulheres do harém.

Mas Gu Sijin enxergava perfeitamente a situação: a Consorte Nobre era uma pessoa desprezível, e a imperatriz também estava longe de ser inocente.

Com tantos informantes no palácio, como poderia não ter ouvido a enorme confusão no Palácio Fengyi?

Se quisesse socorrê-la, teria chegado bem antes, e não apenas depois que o espetáculo terminara.

Por isso, não levou a sério a gentileza da imperatriz. Limitou-se a manter as aparências: — Agradeço a preocupação de Vossa Majestade.

— Ah, de que adianta minha preocupação? — A imperatriz suspirou, lamentando-se. — É um fracasso meu como imperatriz. A Consorte Nobre é arrogante e tirânica. Enquanto a família Tong não cair, ela não terá sossego. Tong Guowei tem tanto poder que já ameaça a autoridade do soberano; várias vezes ultrapassou os limites diante do imperador, que fingiu não perceber.

— Veja o caso de seu pai. Trabalhou arduamente por um ano inteiro e, no fim, Tong Guowei tomou todos os seus méritos com apenas algumas palavras. Quando soube disso, também achei seu pai terrivelmente injustiçado.

A imperatriz foi sondando Gu Sijin passo a passo, até finalmente revelar o verdadeiro propósito de toda aquela solicitude inesperada:

Queria convencê-la a envolver o próprio pai, um censor do Tribunal de Supervisão, nas disputas políticas da corte.

— Se a família Tong continuar crescendo assim, não será apenas o harém: em breve, toda a corte parecerá pertencer aos Tong.

A imperatriz pousou a mão sobre a de Gu Sijin e falou com solenidade: — No momento, nossa única saída é unir forças e encontrar um meio de nossos familiares derrubarem Tong Guowei na corte. Assim também cortaremos pela raiz a arrogância da Consorte Nobre.

— Ela é ferozmente ciumenta, e a Concubina Hua continua desfrutando do favor imperial. Nesta viagem, o imperador levou apenas a Concubina Hua. Quem garante que ela não voltará com boas notícias? Vocês duas são amigas íntimas. Depois de ver como a Consorte Nobre a atormentou hoje, imagine o que fará com a Concubina Hua no futuro.

Deu leves tapinhas na mão de Gu Sijin e baixou ainda mais a voz: — Afinal, ela nem sequer tem uma família influente para protegê-la.

A imperatriz sabia que Gu Sijin e Ning Xiaoxiao eram próximas como irmãs e que a jovem prezava profundamente seus vínculos afetivos. Cada argumento que apresentava, portanto, atingia um de seus pontos fracos.

A humilhação daquele dia, a injustiça sofrida pelo pai e a segurança de Xiaoxiao: tudo isso lhe importava enormemente.

Gu Sijin permaneceu calada por longo tempo, com os olhos baixos, ponderando em segredo.

A imperatriz tampouco era confiável, mas, diante do poder da Consorte Nobre, unir-se a ela para eliminar o clã Tong talvez não fosse de todo mau.

Além disso, a imperatriz e a imperatriz-viúva eram aliadas. O pai da imperatriz ocupava o posto de duque de primeira classe e comandante da guarda interna, enquanto a família da imperatriz-viúva controlava as tropas das doze divisões da região interior. A união dessas três forças poderia fazer frente a Tong Guowei, talvez até superá-lo.

Gu Yanchuan, censor do Tribunal de Supervisão, investigaria e reuniria provas dos crimes de Tong Guowei. Em seguida, o comandante da guarda interna contataria os ministros influentes para denunciá-lo, e as tropas das doze divisões controladas pela família da imperatriz-viúva conteriam seu poder militar.

Seria uma armadilha sem saída, a menos que Tong Guowei decidisse levar tudo consigo à ruína e lançasse contra a dinastia Qi as tropas particulares que recrutara secretamente.

Mas isso equivaleria a uma rebelião.

Lu Linyuan não agira contra ele até então não apenas porque Tong Guowei possuía enorme influência e tropas sob seu comando, mas sobretudo porque o apoio dele fora indispensável à sua ascensão ao trono.

Se o imperador o punisse sem justificativa legítima, ficaria conhecido como alguém que descarta seus benfeitores assim que deixam de ser úteis.

Para um soberano, semelhante ingratidão e falta de honra bastariam para atrair o desprezo e as críticas dos súditos de todo o império.

Mas, se surgissem provas incontestáveis dos inúmeros crimes de Tong Guowei, puni-lo seria atender à vontade do povo.

Mesmo depois de ponderar tudo cuidadosamente, Gu Sijin não aceitou o pedido da imperatriz.

Não queria que o pai se aliasse à imperatriz e à imperatriz-viúva nessa empreitada.

Se o plano desse certo, tudo bem; caso fosse descoberto, os primeiros a sofrer seriam os membros de sua família.

Assim, respondeu: — Não entendo dos assuntos da corte, tampouco seria apropriado escrever a meu pai sobre isso. As mulheres do harém não devem interferir na política. Peço a compreensão de Vossa Majestade.

A imperatriz não a pressionou. Sorriu e balançou a cabeça: — Tem razão. Fui apressada e acabei dizendo algo que ultrapassa os limites de minha posição. Deixemos isso de lado. A decisão cabe ao imperador; nós, mulheres do harém, não deveríamos nos preocupar com tais assuntos.

Uma servidora entrou trazendo a decocção preparada para Gu Sijin. A imperatriz esperou que ela bebesse o remédio e prosseguiu:

— Hoje, se você não tivesse mostrado a medalha de imunidade à morte e impedido a Consorte Nobre a tempo, nem sei até onde a situação poderia ter chegado.

— Afinal, sou responsável pelo harém. Se um tumulto aqui envolvesse a corte, a imperatriz-viúva e o imperador certamente me responsabilizariam primeiro. Portanto, hoje você me livrou de um enorme problema.

— Vossa Majestade exagera. Eu não ousaria atribuir a mim esse mérito...

— Sempre governei o harém recompensando e punindo com justiça. Você me ajudou a resolver a situação, e naturalmente merece uma recompensa. Ouro, prata e joias, porém, são coisas triviais, que uma pessoa de suas aspirações nem apreciaria.

— Pensei que, desde que entrou no palácio, você nunca mais viu sua família e certamente sente saudades. Agora que está confinada e afastada por doença, a Consorte Nobre não vai importuná-la por algum tempo. Posso lhe dar minha autorização escrita e minha ordem oficial para que saia discretamente do palácio e visite seus familiares.

O coração de Gu Sijin deu um salto. Por pouco não derrubou a tigela ao seu lado.

Sentia verdadeiras saudades do pai e da mãe, mas receava cair numa armadilha da imperatriz. Por isso, demorou a responder.

A imperatriz sorriu com gentileza: — Não precisa se preocupar. Você sairá com minha autorização escrita e uma ordem assinada de próprio punho. Se algum dia isso vier à tona, o imperador só poderá responsabilizar a mim.

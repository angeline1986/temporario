# Validação — Capítulo 231

- Fonte: `novel_capitulos_212_a_270(20261105-204934).docx`, texto original chinês tradicional.
- Limites reais (índice base zero, parágrafos DOCX): [1364, 1416).
- Unidades não vazias, incluindo título: **49**.
- Correspondência estrutural 1:1: **49/49**.
- Índices duplicados: 0. Índices de parágrafos não vazios ausentes no cotejo: 0.
- Campos de tradução vazios: 0. Cabeçalho CSV: `indice_docx,original_chines,traducao_portugues`.
- Texto `.md` gerado na mesma ordem e com os mesmos conteúdos traduzidos do CSV.

## Decisões editoriais

A imperatriz demonstra aparente solicitude, mas busca envolver o pai de Gu Sijin na disputa política. Preservada a diferença entre plano de conspiração, avaliação hipotética e ações realizadas. Termos administrativos vertidos funcionalmente.

## Alcance da revisão

Foi feita uma tradução direta e verificação automatizada da integridade e correspondência estrutural das unidades. **Não foi realizada segunda auditoria semântica independente, linha a linha**, portanto a contagem não certifica ausência absoluta de desvios interpretativos.
